/* ==========================================================
 * Modul: js/core/renderer.js
 * Sahna, kamera, renderer va sifat (AVTO/YUQORI/PAST) rejimlari
 * ========================================================== */
/* ---------- renderer / sifat ---------- */
const scene=new T.Scene();scene.background=new T.Color(0x0a1118);scene.fog=new T.Fog(0x0a1118,11,26);
const camera=new T.PerspectiveCamera(72,innerWidth/innerHeight,.05,27);
const lowEnd=mobile||(navigator.hardwareConcurrency||4)<=4||(navigator.deviceMemory||4)<=2;
const renderer=new T.WebGLRenderer({antialias:!lowEnd&&devicePixelRatio<1.5,powerPreference:"high-performance",stencil:false,depth:true,precision:lowEnd?"mediump":"highp"});
renderer.outputEncoding=T.sRGBEncoding;$("game").appendChild(renderer.domElement);
let baseW=innerWidth,baseH=innerHeight,qMode=0,pr=Math.min(devicePixelRatio,lowEnd?1:1.5),cap=pr;
const qn=["AVTO","YUQORI","PAST"];
function applyRes(){renderer.setPixelRatio(pr);renderer.setSize(baseW,baseH)}
function setQ(m){qMode=m;cap=Math.min(devicePixelRatio,lowEnd?1:1.5);pr=m===2?.55:m===1?Math.min(devicePixelRatio,1.5):cap;$("qbtn").textContent="SIFAT: "+qn[m];applyRes()}
$("qbtn").onclick=()=>setQ((qMode+1)%3);setQ(0);
