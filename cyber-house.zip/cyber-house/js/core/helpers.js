/* ==========================================================
 * Modul: js/core/helpers.js
 * Material, canvas, tekstura va box() yordamchi funksiyalari
 * ========================================================== */
/* ---------- yordamchilar ---------- */
const L=(c,o)=>new T.MeshLambertMaterial(Object.assign({color:c},o||{})),B=c=>new T.MeshBasicMaterial({color:c});
function cv(w,h){const c=document.createElement("canvas");c.width=w;c.height=h;return c}
function tex(c,rx,ry){const t=new T.CanvasTexture(c);t.encoding=T.sRGBEncoding;t.anisotropy=lowEnd?1:4;if(rx){t.wrapS=t.wrapT=T.RepeatWrapping;t.repeat.set(rx,ry)}return t}
const cols=[];
function box(x,y,z,w,h,d,m,col){const sg=v=>v>5?Math.min(24,Math.ceil(v/.6)):1;const o=new T.Mesh(new T.BoxGeometry(w,h,d,sg(w),sg(h),sg(d)),m);o.position.set(x,y,z);scene.add(o);if(col)cols.push({x,z,hw:w/2,hd:d/2});o.matrixAutoUpdate=false;o.updateMatrix();return o}
