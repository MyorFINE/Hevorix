/* ==========================================================
 * Modul: js/core/globals.js
 * Global o'zgaruvchilar: THREE, $ yordamchisi, mobil aniqlash, o'lchamlar
 * ========================================================== */
const T=THREE,$=id=>document.getElementById(id),mobile=matchMedia("(pointer:coarse)").matches;
const W=1024,H=576;

/* ikki monitor: virtual ish stoli kengligi (2 ta ekran yonma-yon) */
const VW=W*2;
