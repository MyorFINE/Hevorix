/* ==========================================================
 * Modul: js/core/text-utils.js
 * Matn yordamchilari: lab() yorliq teksturasi va wrapT() matn o'rash (erta chaqirilgani uchun shu yerda e'lon qilingan)
 * ========================================================== */
function lab(t,x,y,z){const c0=cv(128,48),g=c0.getContext("2d");g.fillStyle="#f6f3ea";g.fillRect(0,0,128,48);g.fillStyle="#2a4f8a";g.font="bold 26px sans-serif";g.textAlign="center";g.fillText(t,64,34);const m=new T.Mesh(new T.PlaneGeometry(.18,.068),new T.MeshBasicMaterial({map:tex(c0)}));m.position.set(x,y,z);scene.add(m)}
function wrapT(s,n){const o=[];let l="";s.split(" ").forEach(x=>{if((l+" "+x).trim().length>n){o.push(l);l=x}else l=(l+" "+x).trim()});if(l)o.push(l);return o}
