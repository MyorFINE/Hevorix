/* ==========================================================
 * Modul: js/kali/scrolling.js
 * Skroll tizimi va terminal/editor chizish
 * ========================================================== */
/* ---------- skroll tizimi (Kali/XFCE kabi: silliq + scrollbar) ---------- */
function sbar(w,x,y,h,total,view,get,set){if(total<=view+.001||h<24)return;const mx=total-view,th=Math.max(22,h*view/total),pos=Math.max(0,Math.min(1,get()/mx)),ty=y+(h-th)*pos,act=!!sbDrag&&sbDrag.sb.x===x&&sbDrag.sb.y===y;c.fillStyle="rgba(255,255,255,.05)";c.fillRect(x,y,8,h);rr(x+1,ty,6,th,3,act?accent():"#566678");w.sbs.push({x,y,w:8,h,th,mx,get,set})}
function sbMove(y){if(!sbDrag)return;const sb=sbDrag.sb,r=Math.max(0,Math.min(1,(y-sb.y-sbDrag.off)/Math.max(1,sb.h-sb.th)));sb.set(r*sb.mx,true);dirty=true}
function sbDown(w,x,y){for(const sb of(w.sbs||[])){if(x>=sb.x-4&&x<=sb.x+sb.w+4&&y>=sb.y&&y<=sb.y+sb.h){const pos=Math.max(0,Math.min(1,sb.get()/sb.mx)),ty=sb.y+(sb.h-sb.th)*pos;sbDrag={w,sb,off:(y>=ty&&y<=ty+sb.th)?y-ty:sb.th/2};sbMove(y);return true}}return false}
function pgRows(){const w=wins.find(x=>x.id==="terminal");return w?Math.max(3,Math.floor((w.h-47)/TLH)-1):10}
function wheelWin(w,ln,h){
 if(w.id==="terminal"){termOff=Math.max(0,termOff-ln)}
 else if(w.id==="files"){if(w.view==="icon")ln/=2.5;w.wacc=(w.wacc||0)+ln;const r=w.wacc>0?Math.floor(w.wacc):Math.ceil(w.wacc);if(r){w.scroll=Math.max(0,(w.scroll||0)+r);w.wacc-=r}}
 else if(w.id==="editor"){edS=Math.max(0,edS+ln)}
 else if(w.id==="ide"){const ey=w.y+64,eh=Math.floor((w.h-65)*.6);if(h.y<ey+eh)ideS=Math.max(0,ideS+ln);else ideOutS=Math.max(0,ideOutS-ln)}
 else if(w.id==="atkmon"){w.as=Math.max(0,(w.as||0)+ln)}
}
function scrollTick(dt){const k=Math.min(1,dt*16);let mv=false;const sm=(t,cu)=>{const d=t-cu;if(Math.abs(d)<.004)return t;mv=true;return cu+d*k};
 const n=termLines.length;if(n!==lastTL){const d=n-lastTL;if(d>0&&termOff>.05&&lastTL>0){termOff+=d;termC+=d}lastTL=n}
 termC=sm(termOff,termC);edC=sm(edS,edC);ideC=sm(ideS,ideC);ideOutC=sm(ideOutS,ideOutC);
 for(const w of wins)if(w.id==="atkmon"&&!w.min)w.ac=sm(w.as||0,w.ac||0);
 const t=(performance.now()/125)|0;if(t!==atkT&&S.stage===3&&wins.some(w=>w.id==="atkmon"&&!w.min)&&SEC.list.some(a=>a.state==="active")){atkT=t;mv=true}
 if(mv)dirty=true}
function drawTerm(w,cx,top,blink){
 const ih=w.h-33;rr(w.x+2,top,w.w-4,ih,0,"#0a0e14");
 const cols=Math.max(12,Math.floor((w.w-44)/TCW)),rows=[];
 const put=(t,col)=>{if(!t.length){rows.push(["",col]);return}for(let i=0;i<t.length;i+=cols)rows.push([t.slice(i,i+cols),col])};
 termLines.forEach(l=>put(l.t,l.c));
 put("┌──(kali㉿kali)-["+cwd+"]","#5fa8ff");
 const full="└─$ "+termIn;put(full,"#e6edf3");if(full.length%cols===0)rows.push(["","#e6edf3"]);
 const R=rows.length,viewH=ih-14,contentH=R*TLH,maxS=Math.max(0,contentH-viewH);
 termOff=Math.max(0,Math.min(termOff,maxS/TLH));termC=Math.max(0,Math.min(termC,maxS/TLH));
 const y0=top+7-(maxS>0?maxS-termC*TLH:0);
 c.save();c.beginPath();c.rect(w.x+2,top,w.w-4,ih);c.clip();
 for(let i=0;i<R;i++){const y=y0+i*TLH;if(y<top-TLH||y>top+ih)continue;tx(rows[i][0],cx,y+TLH-4,rows[i][1],"14px monospace")}
 if(blink&&termC<.05){const y=y0+(R-1)*TLH,col=full.length%cols;c.fillStyle="#3df0a0";c.fillRect(cx+col*TCW,y+2,8,15)}
 c.restore();
 sbar(w,w.x+w.w-12,top+3,ih-6,contentH,viewH,()=>maxS-termOff*TLH,(v,imm)=>{termOff=(maxS-v)/TLH;if(imm)termC=termOff})}
function drawEditor(w,cx,top,blink){
 const ih=w.h-33;rr(w.x+2,top,w.w-4,ih,0,"#161b22");tx(edFile||"(nomi yo'q) — Ctrl+S: saqlash",cx,top+16,"#7f95a8","12px monospace");c.fillStyle="#2a3340";c.fillRect(w.x+2,top+24,w.w-4,1);
 const ls=edText.split("\n"),LH=20,ey=top+28,eh=ih-30,vis=Math.max(1,Math.floor(eh/LH)),
 cp=focusId==="editor"&&seated?Math.min(ta.selectionStart,edText.length):edText.length,pre=edText.slice(0,cp),cl=pre.split("\n").length-1,cc=cp-pre.lastIndexOf("\n")-1;
 if(edFollow){if(cl<edS)edS=cl;else if(cl>edS+vis-1)edS=cl-vis+1;edFollow=false}
 const mxE=Math.max(0,ls.length-vis);edS=Math.max(0,Math.min(edS,mxE));edC=Math.max(0,Math.min(edC,mxE));
 const f0=Math.floor(edC),fr=edC-f0,mc=Math.max(10,Math.floor((w.w-70)/TCW)),hx=Math.max(0,cc-(mc-2));
 c.save();c.beginPath();c.rect(w.x+2,ey,w.w-4,eh);c.clip();
 for(let i=0;i<=vis&&f0+i<ls.length;i++){const y=ey+(i-fr)*LH+15;tx(String(f0+i+1).padStart(3," "),cx,y,"#4b5a68","14px monospace");tx(ls[f0+i].slice(hx,hx+mc),cx+38,y,"#d5dde5","14px monospace")}
 if(blink){c.fillStyle="#e0a93a";c.fillRect(cx+38+(cc-hx)*TCW,ey+(cl-edC)*LH+2,2,17)}
 c.restore();
 sbar(w,w.x+w.w-12,ey+2,eh-4,ls.length,vis,()=>edS,(v,imm)=>{edS=v;if(imm)edC=v})}
