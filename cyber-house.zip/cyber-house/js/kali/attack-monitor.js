/* ==========================================================
 * Modul: js/kali/attack-monitor.js
 * Attack Monitor oynasi
 * ========================================================== */
/* ---------- Attack Monitor: hujumchi IP manzillari alohida oynada ---------- */
const ATKST={active:["FAOL","#ff7b72"],blocked:["BLOKLANDI","#3dd8a0"],failed:["YENGILDI","#3dd8a0"],breached:["BUZILDI","#ff4d4d"],done:["RAZVEDKA","#e5c15d"],stopped:["TO'XTADI","#3dd8a0"]};
function atkShow(a){return;const w0=wins.find(x=>x.id==="atkmon");
 if(w0){if(w0.min){w0.min=false;dirty=true}w0.as=0;return}
 const pf=focusId,ss=ta.selectionStart,se=ta.selectionEnd;ATKM.auto=true;openApp("atkmon");ATKM.auto=false;
 if(pf&&wins.some(x=>x.id===pf)){focusId=pf;syncInput();try{ta.setSelectionRange(ss,se)}catch(e){}}dirty=true}
function drawAtk(w,cx,top){
 const X=w.x,Y=top,Wd=w.w,Ht=w.h-33,hits=w.hits=[],bw=Wd-28,list=SEC.list,act=list.filter(a=>a.state==="active"),seen={};list.forEach(a=>{seen[a.ip]=1});
 rr(X+2,Y,Wd-4,Ht,0,"#0f131a");
 const hot=act.length>0,pulse=((performance.now()/400)|0)%2===0;
 c.fillStyle=hot?(pulse?"#ff4d4d":"#7a2020"):"#2dff88";c.beginPath();c.arc(cx+6,Y+17,5,0,7);c.fill();
 tx("ATTACK MONITOR",cx+18,Y+22,hot?"#ff9a9a":"#9fe8c4","bold 14px monospace");
 tx(hot?"HUJUM BO'LYAPTI":"hozircha xavfsiz — kuzatuvda",cx+170,Y+22,hot?"#ff7b72":"#6b9a85","12px monospace");
 tx("Hujum qilish: "+offLeft()+"/"+OFF_MAX,cx+bw-130,Y+22,"#7fd4ff","11px monospace");const tl=[["Faol hujum",act.length,hot?"#ff7b72":"#3dd8a0"],["Hamyon · seyf "+SEC.vault,SEC.score,"#ffd166"],["Bloklangan IP",SEC.blocked.length,"#3dd8a0"],["Buzilgan",SEC.breaches,SEC.breaches?"#ff4d4d":"#8fa3b5"]],tw=Math.floor((bw-18)/4);
 tl.forEach((t,i)=>{const x=cx+i*(tw+6);rr(x,Y+34,tw,42,6,"#161b24");tx(String(t[1]),x+10,Y+57,t[2],"bold 20px monospace");tx(t[0],x+10,Y+70,"#7f95a8","10px monospace")});
 const hy=Y+84;rr(cx,hy,bw,18,0,"#1d2230");[["VAQT",8],["MANBA IP",62],["MAQSAD",178],["TURI / JARAYON",302],["HOLAT",440]].forEach(h=>tx(h[0],cx+h[1],hy+13,"#8fa3b5","11px monospace"));
 const RH=30,ry0=hy+20,ry1=Y+Ht-56,vis=Math.max(1,Math.floor((ry1-ry0)/RH)),mxA=Math.max(0,list.length-vis);
 w.as=Math.max(0,Math.min(w.as||0,mxA));w.ac=Math.max(0,Math.min(w.ac||0,mxA));
 const f0=Math.floor(w.ac),fr=w.ac-f0;
 if(!list.length)tx("Hozircha hujum yo'q — botlar kuzatuvda...",cx+10,ry0+28,"#6b7a8a","12px monospace");
 c.save();c.beginPath();c.rect(X+2,ry0,Wd-4,Math.max(10,ry1-ry0));c.clip();
 for(let i=0;i<=vis&&f0+i<list.length;i++){const a=list[f0+i],y=ry0+(i-fr)*RH,s=ATKST[a.state]||["?","#8fa3b5"],ty=ATYP[a.ty],pc=a.tg==="pc",tg=TG[a.tg];
  if(a.state==="active")rr(cx,y,bw,RH-2,4,"rgba(255,70,70,.10)");else if(((f0+i)&1)===0)rr(cx,y,bw,RH-2,4,"rgba(255,255,255,.025)");
  if(pc){c.fillStyle="#ff4d4d";c.fillRect(cx,y+2,3,RH-6)}
  tx(new Date(a.t0).toTimeString().slice(0,8),cx+8,y+19,"#8fa3b5","11px monospace");
  tx(a.ip,cx+62,y+19,a.state==="active"?"#ff9a9a":"#e6edf3","bold 13px monospace");
  tx(tg.n,cx+178,y+13,pc?"#ffb4b4":"#c5d3e0","12px monospace");tx(tg.ip(),cx+178,y+25,"#7f95a8","10px monospace");
  tx(ty.n,cx+302,y+13,ty.sev>=3?"#ff9a5f":"#c5d3e0","12px monospace");rr(cx+302,y+18,96,6,3,"#0b0f14");rr(cx+302,y+18,Math.max(2,96*a.prog/100),6,3,a.state==="breached"?"#ff4d4d":"#e5c15d");
  tx(s[0],cx+440,y+13,s[1],"bold 11px monospace");{const _r=ty.rate*(a.ty!=="scan"&&SEC.recon[a.tg]?1.2:1),cw=Math.ceil(((SEC.cwin[a.c2]||0)-Date.now())/1000);if(a.state==="active")tx("⏱ "+Math.ceil((100-a.prog)/_r)+"s qoldi",cx+440,y+25,"#ffb84a","10px monospace");else if(a.loot)tx("-"+a.loot+" ball",cx+440,y+25,"#ff7b72","10px monospace");else if(SEC.traced[a.c2])tx("C2 "+a.c2,cx+440,y+25,"#e5c15d","10px monospace")}
  const okY=y+4>=ry0&&y+24<=ry1;
  if(a.state==="active"){rr(cx+bw-100,y+4,46,20,4,"#7a2b2b");tx("Block",cx+bw-93,y+18,"#fff","11px monospace");if(okY)hits.push({x:cx+bw-100,y:y+4,w:46,h:20,fn:()=>{if(!SEC.blocked.includes(a.ip))SEC.blocked.push(a.ip);toast("IP bloklandi: "+a.ip)}})}
  if(true){rr(cx+bw-50,y+4,48,20,4,"#2b4a7a");tx("Trace",cx+bw-42,y+18,"#fff","11px monospace");if(okY)hits.push({x:cx+bw-50,y:y+4,w:48,h:20,fn:()=>uiTry(()=>startTrace(a.ip))})}}
 c.restore();
 sbar(w,X+Wd-14,ry0,Math.max(10,ry1-ry0),list.length,vis,()=>w.as,(v,imm)=>{w.as=v;if(imm)w.ac=v});
 const by=Y+Ht-52;c.fillStyle="#2a3340";c.fillRect(cx,by-2,bw,1);
 tx("BLOKLANGAN IP:",cx,by+16,"#7fd4ff","bold 11px monospace");let bx=cx+112;if(!SEC.blocked.length)tx("yo'q",bx,by+16,"#6b7a8a","11px monospace");
 SEC.blocked.slice(0,5).forEach(ip=>{const wd=ip.length*6.8+22;if(bx+wd>cx+bw)return;rr(bx,by+3,wd,18,9,"#1f3a30");tx(ip+" ×",bx+8,by+16,"#a8f0c8","11px monospace");hits.push({x:bx,y:by+3,w:wd,h:18,fn:()=>{SEC.blocked=SEC.blocked.filter(q=>q!==ip);toast("Blok olib tashlandi: "+ip)}});bx+=wd+6});
 const cy=by+28;
 if(act.length){rr(cx+bw-150,cy,150,22,5,"#7a2b2b");tx("Faollarni bloklash",cx+bw-142,cy+15,"#fff","11px monospace");hits.push({x:cx+bw-150,y:cy,w:150,h:22,fn:()=>{act.forEach(a=>{if(!SEC.blocked.includes(a.ip))SEC.blocked.push(a.ip)});toast("Faol hujumchilar bloklandi")}})}}
