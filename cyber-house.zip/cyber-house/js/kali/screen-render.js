/* ==========================================================
 * Modul: js/kali/screen-render.js
 * Ekran render: draw, drawWin, blit
 * ========================================================== */
function draw(){
 c.fillStyle="#040506";c.fillRect(0,0,VW,H);
 if(!S.on||S.stage===0||(!S.mplug&&!S.mplug2))return;
 if(S.stage===4){const t=(performance.now()-S.boot)/1000,k=Math.min(SD.length,Math.floor(t*3.2)+1);c.fillStyle="#05080c";c.fillRect(0,0,W,H);SD.slice(0,k).forEach((l,i)=>{if(i<SD.length-1){tx("[  OK  ]",40,50+i*22,"#2fe39a");tx(l,130,50+i*22,"#a8c9d8")}else tx(l,40,50+i*22,"#a8c9d8")});if(t>2.8){wins.length=0;focusId=null;dirty=true;if(S.restart){S.restart=false;S.stage=1;S.boot=performance.now()}else{S.on=false;S.stage=0}}return}
 if(S.stage===1){const t=(performance.now()-S.boot)/1000,M2="14px monospace";c.fillStyle="#05080c";c.fillRect(0,0,W,H);
  if(t<1.3){tx("CyberBIOS v2.4  (C) Cyber House Labs",40,50,"#cfd8e0",M2);tx("CPU: AMD Ryzen 7 5800X 8-Core @ 3.8GHz",40,80,"#9fb0be",M2);tx("Memory Test: "+Math.floor(Math.min(1,t)*16384)+" MB OK",40,110,"#9fb0be",M2);if(t>.7){tx("Detected: NVMe0 CYBER-SSD 512GB",40,140,"#9fb0be",M2);tx("Press DEL to enter SETUP",40,540,"#cfd8e0",M2)}}
  else if(t<3){c.strokeStyle="#aaa";c.lineWidth=2;c.strokeRect(80,70,860,330);tx("GNU GRUB  version 2.12-5",400,50,"#ddd",M2);
   ["Kali GNU/Linux","Advanced options for Kali GNU/Linux","Memtest86+"].forEach((l,i)=>{if(!i){c.fillStyle="#ccc";c.fillRect(82,90,856,22)}tx((i?" ":"*")+l,100,106+i*24,i?"#ccc":"#000",M2)});
   tx("Use the ↑ and ↓ keys to select which entry is highlighted.",80,440,"#ccc",M2);tx("The highlighted entry will be executed automatically in "+Math.max(0,Math.ceil(3-t))+"s.",80,465,"#ccc",M2)}
  else if(t<6){const k=Math.min(KL.length,Math.floor((t-3)*KL.length/2.7)),b=Math.max(0,k-34);KL.slice(b,k).forEach((l,i)=>tx("[ "+((b+i)*.173+.01).toFixed(6).padStart(9)+"] "+l,16,20+i*16,"#c9d2da","13px monospace"))}
  else{tx("KALI LINUX",60,100,"#3b9aff","bold 40px monospace");tx("the quieter you become, the more you can hear",60,130,"#4a6a80","14px monospace");c.fillStyle="#12262f";c.fillRect(60,500,900,10);c.fillStyle="#3b9aff";c.fillRect(60,500,900*Math.min(1,(t-6)/1.8),10)}
  if(t>7.8){S.stage=2;dirty=true}return}
 c.drawImage(wp,0,0,W,H);if(extOn())c.drawImage(wp,W,0,W,H);
 if(S.stage===2){c.fillStyle="rgba(5,8,14,.6)";c.fillRect(0,0,W,H);c.beginPath();c.arc(512,190,44,0,7);c.fillStyle="#1c3a66";c.fill();tx("K",500,205,"#9fd0ff","bold 42px monospace");tx("player",476,272,"#e6edf3","bold 22px monospace");rr(392,290,240,34,6,"#0e1522");tx(termIn?"•".repeat(termIn.length):"Parol (kali)",408,313,termIn?"#e6edf3":"#5d7385","16px monospace");rr(412,340,200,38,8,"#2b6bd6");tx("Kirish",484,365,"#fff","bold 16px monospace");if(loginErr)tx(loginErr,420,402,"#ff7b72","13px monospace");
  tx(new Date().toLocaleTimeString("uz-UZ",{hour:"2-digit",minute:"2-digit"}),470,540,"#9fb6c8","bold 28px monospace");return}
  monFix();drawDesk();
  wins.forEach(w=>{if(!w.min)drawWin(w)});
  drawCoach();drawPanel();drawMenu();drawPlaces();drawPop();drawDskDlg();drawCtx();
}
function drawWin(w){
 w.sbs=[];const f=w.id===focusId;rr(w.x,w.y,w.w,w.h,8,f?"#0e1218":"#11151b");rr(w.x,w.y,w.w,30,8,f?"#2b3347":"#1d2230");c.fillStyle=f?"#2b3347":"#1d2230";c.fillRect(w.x,w.y+18,w.w,12);
 tx(winTitle(w),w.x+14,w.y+20,"#c5d3e0","13px monospace");
 [[62,"#e5c15d","–"],[42,"#58c26a","□"],[22,"#ff5f56","×"]].forEach(b=>{c.beginPath();c.arc(w.x+w.w-b[0],w.y+15,9,0,7);c.fillStyle=b[1];c.fill();tx(b[2],w.x+w.w-b[0]-4,w.y+19,"#111","bold 12px monospace")});
 c.save();c.beginPath();c.rect(w.x+2,w.y+31,w.w-4,w.h-33);c.clip();const cx=w.x+14,top=w.y+32,blink=f&&seated&&((performance.now()/500)|0)%2===0;
 if(w.id==="terminal")drawTerm(w,cx,top,blink);
  else if(w.id==="ide"){rr(w.x+2,top,w.w-4,w.h-33,0,"#12161d");
 [["▶ Run",10,70,"#2f9a5a"],["Tab",86,44,"#33425a"],["Saqlash",138,70,"#33425a"],["Tozalash",216,78,"#33425a"]].forEach(b=>{rr(w.x+b[1],top+4,b[2],22,5,b[3]);tx(b[0],w.x+b[1]+8,top+19,"#fff","12px monospace")});
 tx(ideFile,w.x+w.w-14-ideFile.length*7.2,top+19,"#7f95a8","12px monospace");
 const ey=top+32,eh=Math.floor((w.h-65)*.6),vis=Math.max(1,Math.floor(eh/16)),ls=ideText.split("\n"),cp=focusId==="ide"&&seated?Math.min(ta.selectionStart,ideText.length):ideText.length,pre=ideText.slice(0,cp),cl=pre.split("\n").length-1,cc=cp-pre.lastIndexOf("\n")-1;
 if(ideFollow){if(cl<ideS)ideS=cl;else if(cl>ideS+vis-2)ideS=cl-vis+2;ideFollow=false}
 const mxI=Math.max(0,ls.length-vis+1);ideS=Math.max(0,Math.min(ideS,mxI));ideC=Math.max(0,Math.min(ideC,mxI));
 const f0=Math.floor(ideC),fr0=ideC-f0,mc=Math.max(10,Math.floor((w.w-70)/7.8)),hx=Math.max(0,cc-(mc-3));
 c.save();c.beginPath();c.rect(w.x+2,ey,w.w-4,eh);c.clip();
 for(let i=0;i<=vis&&f0+i<ls.length;i++){const l=ls[f0+i],y=ey+14+(i-fr0)*16;tx(String(f0+i+1).padStart(2," "),cx,y,"#4b5a68","13px monospace");tx(l.slice(hx,hx+mc),cx+30,y,/^\s*#/.test(l)?"#6b8a7a":/^\s*(def|for|while|if|elif|else|import|return)\b/.test(l)?"#c9a6ff":"#d5dde5","13px monospace")}
 if(blink){c.fillStyle="#e0a93a";c.fillRect(cx+30+(cc-hx)*7.8,ey+2+(cl-ideC)*16,2,15)}
 c.restore();
 sbar(w,w.x+w.w-12,ey+2,eh-4,ls.length+1,vis,()=>ideS,(v,imm)=>{ideS=v;if(imm)ideC=v});
 const oy=ey+eh;c.fillStyle="#2a3340";c.fillRect(w.x+2,oy,w.w-4,1);tx("NATIJA",cx,oy+16,"#3dd8ff","bold 11px monospace");
 const n2=Math.max(1,Math.floor((w.h-33-eh-52)/15)),L2=ideOut.length,mxO=Math.max(0,L2-n2);ideOutS=Math.max(0,Math.min(ideOutS,mxO));ideOutC=Math.max(0,Math.min(ideOutC,mxO));
 const st0=L2<=n2?0:L2-n2-ideOutC,g0=Math.max(0,Math.floor(st0)),oh=w.h-33-eh-52;
 c.save();c.beginPath();c.rect(w.x+2,oy+20,w.w-4,Math.max(10,oh));c.clip();
 for(let i=g0;i<L2&&i<=g0+n2+1;i++){const l=ideOut[i];tx(l,cx,oy+34+(i-st0)*15,l.startsWith("Xato")?"#ff7b72":"#b8e6c8","13px monospace")}
 c.restore();
 sbar(w,w.x+w.w-12,oy+20,Math.max(10,oh)-2,L2,n2,()=>mxO-ideOutS,(v,imm)=>{ideOutS=mxO-v;if(imm)ideOutC=ideOutS})}
  else if(w.id==="editor")drawEditor(w,cx,top,blink);
  else if(w.id==="files")drawFiles(w,cx,top);
  else if(w.id==="monitor")drawMon(w,cx,top);
  else if(w.id==="settings")drawSet(w,cx,top);
  else if(w.id==="ids")drawIds(w,cx,top);
  else if(w.id==="atkmon")drawAtk(w,cx,top);
  else if(w.id==="usb"){rr(w.x+2,top,w.w-4,w.h-33,0,"#101820");w.hits=[];
   if(!usbOn()){tx("USB flesh ulanmagan",cx,top+30,"#6b7a8a","13px monospace");tx("Flesh-xotirani kompyuter portiga suqing",cx,top+54,"#6b7a8a","13px monospace")}
   else{tx("CYBERKEY  /media/usb",cx,top+22,"#3dd8ff","bold 13px monospace");let y=top+44,ks=[];try{ks=F.ls("/media/usb")}catch(e){}ks.forEach(n=>{tx("▤ "+n,cx+8,y,"#c5d3e0","13px monospace");w.hits.push({x:cx,y:y-14,w:260,h:18,fn:()=>openPath("/media/usb/"+n)});rr(cx+280,y-14,70,18,4,"#3b2f0d");tx("← Uy",cx+292,y,"#e0a93a","12px monospace");w.hits.push({x:cx+280,y:y-14,w:70,h:18,fn:()=>{try{F.cp("/media/usb/"+n,HOME+"/"+n,true);toast("Nusxalandi: ~/"+n)}catch(e){toast(e.message)}}});y+=22})}}
 else{rr(w.x+2,top,w.w-4,w.h-33,0,"#fff");rr(w.x+14,top+8,w.w-28,26,13,"#e8edf3");tx("https://cyberhouse.local",w.x+30,top+26,"#32404f");
  tx("Cyber House",cx+10,top+90,"#0c2a44","bold 36px monospace");tx("Xavfsizlik laboratoriyasi portali",cx+10,top+120,"#4a5d70");
  [["Tarmoq","#2b6bd6"],["Veb","#1fa37a"],["Parol","#d6552b"]].forEach((o,i)=>{rr(cx+10+i*190,top+150,170,90,8,o[1]);tx(o[0],cx+26+i*190,top+200,"#fff","bold 20px monospace")})}
 c.restore();if(!w.max){c.strokeStyle="#4b5a68";c.lineWidth=1;for(let g=0;g<3;g++){c.beginPath();c.moveTo(w.x+w.w-4-g*4,w.y+w.h-3);c.lineTo(w.x+w.w-3,w.y+w.h-4-g*4);c.stroke()}}
}
function cursorAt(g,x,y){g.save();g.scale(K,K);g.fillStyle="#fff";g.strokeStyle="#000";g.lineWidth=1.5;g.beginPath();g.moveTo(x,y);g.lineTo(x,y+18);g.lineTo(x+5,y+14);g.lineTo(x+9,y+22);g.lineTo(x+12,y+20);g.lineTo(x+8,y+13);g.lineTo(x+14,y+12);g.closePath();g.fill();g.stroke();g.restore()}
/* ikki ekran: katta kanvasning chap yarmi — 1-monitor, o'ng yarmi — 2-monitor (yoki dublikatda chap yarmining nusxasi) */
function blit(){const wk=W*K,hk=H*K,x=cur.x,y=cur.y,sg=m2Sig();
 if(S.mplug)sx.drawImage(bc,0,0,wk,hk,0,0,wk,hk);else{sx.fillStyle="#040506";sx.fillRect(0,0,wk,hk)}
 if(S.on&&S.mplug&&S.stage>=2&&x<W+14)cursorAt(sx,x,y);
 const key=sg+"|"+(S.mplug2?1:0)+"|"+SET.dmode;
 if(sg===0&&blit.k===key){}else{
  if(sg===1)sx2.drawImage(bc,wk,0,wk,hk,0,0,wk,hk);
  else if(sg===2)sx2.drawImage(bc,0,0,wk,hk,0,0,wk,hk);
  else{sx2.fillStyle="#040506";sx2.fillRect(0,0,wk,hk);
   if(S.mplug2){sx2.save();sx2.scale(K,K);sx2.fillStyle="#0b1118";sx2.fillRect(W/2-110,H/2-26,220,52);sx2.fillStyle="#8fa3b5";sx2.font="bold 18px monospace";sx2.textAlign="center";sx2.fillText("SIGNAL YO'Q",W/2,H/2+6);sx2.restore()}}
  if(sg===1&&x>W-14)cursorAt(sx2,x-W,y);else if(sg===2&&x<W+14)cursorAt(sx2,x,y);
  scrTex2.needsUpdate=true}
 blit.k=key;scrTex.needsUpdate=true}
