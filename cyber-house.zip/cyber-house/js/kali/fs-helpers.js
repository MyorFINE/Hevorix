/* ==========================================================
 * Modul: js/kali/fs-helpers.js
 * Fayl tizimi yordamchilari (format, ikonka, sarlavha)
 * ========================================================== */
/* ---- yordamchilar ---- */
const dstr=t=>{const d=new Date(t);return d.toLocaleDateString("en-US",{month:"short",day:"2-digit"})+" "+String(d.getHours()).padStart(2,"0")+":"+String(d.getMinutes()).padStart(2,"0")};
function modeStr(n){return(n.t==="d"?"d":"-")+[0,1,2].map(i=>{const d=bits(n.m,i);return(d&4?"r":"-")+(d&2?"w":"-")+(d&1?"x":"-")}).join("")}
function fiType(n,nm){if(n.t==="d")return"Folder";const e=(nm.split(".").pop()||"").toLowerCase();if(n.c&&n.c.charAt(0)==="["&&/^\[[a-z ]+\]$/i.test(n.c))return"Binary";return({py:"Python",sh:"Shell",txt:"Text",md:"Markdown",conf:"Config",log:"Log",html:"HTML"})[e]||"File"}
function fSize(n){if(n.t==="d")return Object.keys(n.k).length+" items";const l=n.c.length;return l<1024?l+" B":(l/1024).toFixed(1)+" KB"}
const up=p=>p==="network:///"?HOME:(p.replace(/\/[^\/]*$/,"")||"/"),inTrash=p=>p===TRASH||p.indexOf(TRASH+"/")===0;
function uniq(p){if(!nd(p))return p;let i=2,b=p.replace(/(\.[^\/.]+)?$/,""),e=(p.match(/(\.[^\/.]+)$/)||[""])[0];while(nd(b+" ("+i+")"+e))i++;return b+" ("+i+")"+e}
function fIcon(x,y,n,nm,s){const col=n.t==="d"?"#e0a93a":({Python:"#9b7bff",Shell:"#3df0a0",Binary:"#c0643a",Markdown:"#5fa8ff"})[fiType(n,nm)]||"#c5d3e0";if(n.t==="d"){rr(x,y+3*s,18*s,13*s,2,col);rr(x,y,9*s,6*s,2,col)}else{rr(x+3*s,y,13*s,17*s,2,col);c.fillStyle="rgba(0,0,0,.25)";c.fillRect(x+6*s,y+5*s,7*s,1.5*s);c.fillRect(x+6*s,y+9*s,7*s,1.5*s)}}
function winTitle(w){if(w.id==="terminal")return USER+"@"+HOST+": "+pd();if(w.id==="files")return"Thunar — "+(w.path==="network:///"?"Network":(w.path.split("/").pop()||"/"));if(w.id==="editor")return"Mousepad"+(edFile?" — "+edFile.split("/").pop():"");return APPS.find(a=>a.id===w.id).n}
function pd(){return cwd===HOME?"~":cwd.indexOf(HOME+"/")===0?"~"+cwd.slice(HOME.length):cwd}
function logout(){S.stage=2;wins.length=0;focusId=null;termIn="";menuOpen=false;placesOpen=false;POP=null;CTX=null;if(typeof ta!=="undefined")ta.value="";dirty=true}
function termCd(p){try{const n=nd(p);if(n&&n.t==="d")cwd=abs(p)}catch(e){}openApp("terminal")}
