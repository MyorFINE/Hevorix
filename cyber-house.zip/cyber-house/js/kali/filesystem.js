/* ==========================================================
 * Modul: js/kali/filesystem.js
 * Fayl tizimi (ruxsatlar, saqlash, yuklash)
 * ========================================================== */
/* ---- fayl tizimi (ruxsatlar bilan, saqlanadi) ---- */
let FS=null,_sv=0;
const ho=(o,k)=>Object.prototype.hasOwnProperty.call(o,k),bits=(m,i)=>parseInt((m||"000")[i],8)||0;
function fsErr(m){throw new Error(m)}
function abs(p,base){p=String(p==null?"":p).trim();if(p===""||p==="~")p=HOME;else if(p.slice(0,2)==="~/")p=HOME+p.slice(1);else if(p[0]!=="/")p=(base||cwd)+"/"+p;const o=[];for(const s of p.split("/")){if(!s||s===".")continue;if(s==="..")o.pop();else o.push(s)}return"/"+o.join("/")}
function nd(p){const a=abs(p);if((a==="/media/usb"||a.indexOf("/media/usb/")===0)&&!usbOn())fsErr("USB ulanmagan (/media/usb)");if(a==="/")return FS;let n=FS;for(const s of a.slice(1).split("/")){if(n.t!=="d"||!ho(n.k,s))return null;n=n.k[s]}return n}
const can=(n,b)=>ASROOT||((n.o===USER?bits(n.m,0):bits(n.m,2))&b)>0;
const join=(a,b)=>(a==="/"?"":a)+"/"+b;
function par(a){const i=a.lastIndexOf("/");return[nd(a.slice(0,i)||"/"),a.slice(i+1)]}
const nowO=()=>ASROOT?"root":USER;
function chk(){try{const n=nd("/media/usb/flag.txt");if(n&&n.t==="f"&&/FLAG\{/.test(n.c))M.s[5]=true}catch(e){}}
function chmodSpec(old,s){if(/^[0-7]{3}$/.test(s))return s;const m=s.match(/^([ugoa]*)([+\-=])([rwx]+)$/);if(!m)fsErr("invalid mode: '"+s+"'");const who=m[1]||"a",d=old.split("").map(Number),v=(m[3].includes("r")?4:0)+(m[3].includes("w")?2:0)+(m[3].includes("x")?1:0);[["u",0],["g",1],["o",2]].forEach(([k,i])=>{if(who.includes(k)||who.includes("a"))d[i]=m[2]==="+"?(d[i]|v):m[2]==="-"?(d[i]&~v&7):v});return d.join("")}
const F={abs,
 rd(p){const n=nd(p);if(!n)fsErr(p+": No such file or directory");if(n.t==="d")fsErr(p+": Is a directory");if(!can(n,4))fsErr(p+": Permission denied");return n.c},
 wr(p,v,app){const a=abs(p),n=nd(a);if(n){if(n.t==="d")fsErr(a+": Is a directory");if(!can(n,2))fsErr(a+": Permission denied");n.c=app?n.c+String(v):String(v);n.mt=Date.now()}else{const[d,nm]=par(a);if(!d||d.t!=="d")fsErr(a+": No such file or directory");if(!nm)fsErr("fayl nomi kerak");if(!can(d,2))fsErr(a+": Permission denied");d.k[nm]={t:"f",o:nowO(),m:"644",mt:Date.now(),c:String(v)};d.mt=Date.now()}fsSave();chk()},
 ls(p){const n=nd(p||cwd);if(!n)fsErr((p||"")+": No such file or directory");if(n.t!=="d")return[abs(p).split("/").pop()];if(!can(n,4))fsErr((p||"")+": Permission denied");return Object.keys(n.k).sort()},
 mkdir(p,rec){const a=abs(p);if(nd(a)){if(rec)return;fsErr(a+": File exists")}const i=a.lastIndexOf("/"),pp=a.slice(0,i)||"/";if(!nd(pp)){if(rec)F.mkdir(pp,true);else fsErr(a+": No such file or directory")}const[d,nm]=par(a);if(d.t!=="d")fsErr(a+": Not a directory");if(!can(d,2))fsErr(a+": Permission denied");d.k[nm]={t:"d",o:nowO(),m:"755",mt:Date.now(),k:{}};fsSave()},
 rm(p,rec){const a=abs(p),n=nd(a);if(!n)fsErr(p+": No such file or directory");if(a==="/")fsErr("it is dangerous to operate recursively on '/'");if(n.t==="d"&&!rec)fsErr(p+": Is a directory");const[d,nm]=par(a);if(!can(d,2))fsErr(p+": Permission denied");delete d.k[nm];fsSave()},
 cp(s,d,rec){const sa=abs(s),sn=nd(sa);if(!sn)fsErr(s+": No such file or directory");if(sn.t==="d"&&!rec)fsErr("-r not specified; omitting directory '"+s+"'");if(!can(sn,4))fsErr(s+": Permission denied");let da=abs(d);const dn=nd(da);if(dn&&dn.t==="d")da=join(da,sa.split("/").pop());if(da===sa)fsErr("'"+s+"' and '"+d+"' are the same file");if(da.indexOf(sa+"/")===0)fsErr("cannot copy a directory into itself");const[pp,nm]=par(da);if(!pp||pp.t!=="d")fsErr(d+": No such file or directory");if(!can(pp,2))fsErr(d+": Permission denied");const c2=JSON.parse(JSON.stringify(sn));c2.o=nowO();c2.mt=Date.now();pp.k[nm]=c2;fsSave();chk();return da},
 mv(s,d){const sa=abs(s);if(abs(d)===sa)return;const sn=nd(sa);if(!sn)fsErr(s+": No such file or directory");const[sp]=par(sa);if(!can(sp,2))fsErr(s+": Permission denied");F.cp(s,d,true);F.rm(sa,true)},
 chmod(p,m){const n=nd(p);if(!n)fsErr(p+": No such file or directory");if(!ASROOT&&n.o!==USER)fsErr(p+": Operation not permitted");n.m=chmodSpec(n.m,m);fsSave()},
 stat:p=>nd(p)};
function fsSave(){clearTimeout(_sv);_sv=setTimeout(()=>{try{localStorage.setItem("hs_fs_v1",JSON.stringify(FS))}catch(e){}},400)}
function fsBuild(){const T0=Date.now()-259200000,D=(o,m)=>({t:"d",o:o||"root",m:m||"755",mt:T0,k:{}}),Fl=(c,o,m)=>({t:"f",o:o||"root",m:m||"644",mt:T0,c:c||""}),r=D();
 const mk=(p,n)=>{let d=r;const s=p.split("/").filter(Boolean),l=s.pop();for(const x of s){if(!d.k[x])d.k[x]=D();d=d.k[x]}d.k[l]=n},EB="[ELF binary]";
 ["bin","boot","dev","etc","home","media","opt","usr","usr/bin","usr/lib","usr/share","usr/local","var","var/log","var/www","var/tmp"].forEach(p=>mk(p,D()));
 mk("root",D("root","700"));mk("tmp",D("root","777"));
 ["bash","cat","cp","echo","ls","mv","ping","rm","zsh"].forEach(x=>mk("bin/"+x,Fl(EB,"root","755")));
 ["nmap","nikto","sqlmap","whois","python3","hydra","john","nc"].forEach(x=>mk("usr/bin/"+x,Fl(EB,"root","755")));
 mk("boot/grub",D());mk("boot/vmlinuz-6.12.0-kali1-amd64",Fl("[kernel image]"));mk("boot/initrd.img-6.12.0-kali1-amd64",Fl("[initramfs]"));
 ["null","urandom","tty0"].forEach(x=>mk("dev/"+x,Fl("")));mk("dev/nvme0n1",Fl("[block device]"));mk("dev/sda",Fl("[block device]"));
 mk("etc/hostname",Fl(HOST+"\n"));mk("etc/hosts",Fl("127.0.0.1\tlocalhost\n127.0.1.1\t"+HOST+"\n"));
 mk("etc/passwd",Fl("root:x:0:0:root:/root:/usr/bin/zsh\n"+USER+":x:1000:1000:Player,,,:"+HOME+":/usr/bin/zsh\n"));
 mk("etc/shadow",Fl("root:!:19900:0:99999:7:::\n"+USER+":$y$j9T$simulyatsiya$Zk3x:19900:0:99999:7:::\n","root","640"));
 mk("etc/os-release",Fl('PRETTY_NAME="Kali GNU/Linux Rolling"\nNAME="Kali GNU/Linux"\nID=kali\n'));mk("etc/resolv.conf",Fl("nameserver 192.168.1.1\n"));
 mk("var/log/syslog",Fl(HOST+" systemd[1]: Started Session 1 of user "+USER+".\n"+HOST+" kernel: usb 1-2: new high-speed USB device\n","root","640"));
 mk("var/log/auth.log",Fl(HOST+" sshd[731]: Server listening on 0.0.0.0 port 22.\n"+HOST+" sudo: "+USER+" : TTY=pts/0 ; USER=root ; COMMAND=/usr/bin/nmap\n","root","640"));
 mk("var/log/dpkg.log",Fl("status installed nmap:amd64 7.95\n"));mk("var/www/html",D());mk("var/www/html/index.html",Fl("<h1>It works!</h1>\n"));
 mk("root/secret.txt",Fl("FAQAT ROOT UCHUN. 'sudo cat /root/secret.txt' ishlaydi.\n","root","600"));mk("root/.zshrc",Fl("# root zshrc\n","root","644"));
 const H=(p,n)=>mk("home/player/"+p,n),DH=()=>D(USER),FH=(c,m)=>Fl(c,USER,m||"644");
 mk("home/player",DH());["Desktop","Documents","Downloads","Pictures","Music","Videos","Projects","Scripts","Tools","Wordlists","Captures","Logs","Backups","Reports",".config",".config/xfce4",".local",".local/share",".local/share/Trash"].forEach(p=>H(p,DH()));
 H("notes.txt",FH("- nmap bilan tarmoqni tekshirish\n- hisobot yozish\n"));H("payload.py",FH(STARTER));H("scan_results.txt",FH(""));H(".zshrc",FH("# zsh config\nalias ll='ls -l'\n"));
 H("Desktop/Welcome.txt",FH("Kali Linux ish stoliga xush kelibsiz.\n"));H("Documents/todo.txt",FH("1. 192.168.1.10 ni skanerlash\n2. Hisobot yozish\n3. Flesh-xotiraga FLAG saqlash\n"));
 H("Documents/readme.md",FH("# Hujjatlar\nBu yerda ish hujjatlari saqlanadi.\n"));H("Scripts/hello.py",FH('print("Salom, Kali!")\n',"755"));
 H("Tools/README.txt",FH("Qo'shimcha vositalar shu yerda.\n"));H("Wordlists/common.txt",FH("admin\npassword\n123456\nletmein\nqwerty\nkali\nroot\n"));
 H("Reports/template.md",FH("# Penetratsion test hisoboti\n## Xulosa\n## Topilmalar\n"));H(".config/xfce4/panel.conf",FH("position=top\nlength=100\n"));
 mk("media/usb",{t:"d",o:USER,m:"755",mt:T0,k:{"readme.txt":Fl("CYBERKEY 8GB flesh-xotira\n",USER)}});
 return r}
function fsLoad(){let f=null;try{f=JSON.parse(localStorage.getItem("hs_fs_v1")||"null")}catch(e){}if(f&&f.t==="d"&&f.k&&f.k.home&&f.k.media)return f;return fsBuild()}
