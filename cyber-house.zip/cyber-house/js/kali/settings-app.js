/* ==========================================================
 * Modul: js/kali/settings-app.js
 * Settings ilovasi
 * ========================================================== */
/* ---- Settings ---- */
const PG=["Appearance","Network","Sound","Keyboard","Users","Displays","Power"];
function drawSet(w,cx,top){const X=w.x,Y=top,Wd=w.w,Ht=w.h-33,hits=w.hits=[];rr(X+2,Y,Wd-4,Ht,0,"#161b22");rr(X+2,Y,150,Ht,0,"#11151b");
 PG.forEach((p,i)=>{const y=Y+10+i*28,sel=w.pg===i;if(sel)rr(X+8,y,138,24,5,accent());tx(p,X+18,y+17,sel?"#fff":"#c5d3e0","13px monospace");hits.push({x:X+8,y,w:138,h:24,fn:()=>{w.pg=i}})});
 const px=X+172,py=Y+14,T=(s,y,col,f)=>tx(s,px,y,col||"#c5d3e0",f||"13px monospace"),H2=(s,y)=>tx(s,px,y,"#7fd4ff","bold 13px monospace");
 const radio=(y,on,lab,fn)=>{c.beginPath();c.arc(px+7,y+7,7,0,7);c.strokeStyle="#6b7a8a";c.lineWidth=1.5;c.stroke();if(on){c.beginPath();c.arc(px+7,y+7,4,0,7);c.fillStyle=accent();c.fill()}tx(lab,px+22,y+12,"#e6edf3","13px monospace");hits.push({x:px,y:y-2,w:280,h:20,fn})};
 const chb=(y,on,lab,fn)=>{rr(px,y,16,16,3,on?accent():"#2b3347");if(on)tx("✓",px+2,y+13,"#fff","bold 13px monospace");tx(lab,px+26,y+13,"#e6edf3","13px monospace");hits.push({x:px,y:y-2,w:300,h:20,fn})};
 const pg=w.pg;
 if(pg===0){H2("Fon rasmi",py+8);WALLS.forEach((p,i)=>{const x=px+i*108,y=py+20,g=c.createLinearGradient(x,y,x+96,y+60);g.addColorStop(0,p[0]);g.addColorStop(1,p[2]);c.fillStyle=g;c.fillRect(x,y,96,60);if(SET.wall===i){c.strokeStyle=accent();c.lineWidth=2;c.strokeRect(x-1,y-1,98,62)}hits.push({x,y,w:96,h:60,fn:()=>{SET.wall=i;paintWall(i);saveSet()}})});
  H2("Mavzu rangi",py+112);ACC.forEach((a,i)=>{const x=px+i*108,y=py+124;rr(x,y,96,26,5,a[0]);tx(a[1],x+8,y+17,"#fff","12px monospace");if(SET.acc===i){c.strokeStyle="#fff";c.lineWidth=2;c.strokeRect(x-1,y-1,98,28)}hits.push({x,y,w:96,h:26,fn:()=>{SET.acc=i;saveSet()}})});
  chb(py+170,SET.icons,"Ish stoli ikonkalarini ko'rsatish",()=>{SET.icons=!SET.icons;saveSet()})}
 else if(pg===1){H2("Wired connection 1 (eth0)",py+8);T("IP manzil:",py+32,"#8fa3b5","12px monospace");["192.168.1.37","192.168.1.50","10.0.0.15"].forEach((ip,i)=>radio(py+40+i*24,SET.ip===ip,ip+"/24",()=>{SET.ip=ip;saveSet()}));
  T("Gateway: 192.168.1.1     DNS: 192.168.1.1",py+130,"#8fa3b5","12px monospace");T("Hostname: "+HOST,py+150,"#8fa3b5","12px monospace");chb(py+172,SET.fw,"Firewall (ufw) yoqilgan",()=>{SET.fw=!SET.fw;saveSet()});T("Firewall yoqilsa, o'z IP'ingizni nmap bilan skanerlash natijasi o'zgaradi.",py+206,"#6b7a8a","11px monospace")}
 else if(pg===2){H2("Ovoz balandligi",py+8);rr(px,py+24,240,10,4,"#0e1218");if(!SET.mute)rr(px,py+24,Math.max(6,240*SET.vol/100),10,4,accent());hits.push({x:px,y:py+18,w:240,h:22,fn:(d,x)=>{SET.vol=Math.max(0,Math.min(100,Math.round((x-px)/240*100)));SET.mute=false;saveSet();beep()}});
  T(SET.mute?"O'chirilgan":SET.vol+"%",py+60);chb(py+80,SET.mute,"Ovozni o'chirish (mute)",()=>{SET.mute=!SET.mute;saveSet()})}
 else if(pg===3){H2("Klaviatura tartibi",py+8);["US","UZ","RU"].forEach((k,i)=>radio(py+28+i*26,SET.kb===k,{US:"English (US)",UZ:"O'zbek (UZ)",RU:"Русский (RU)"}[k],()=>{SET.kb=k;saveSet()}));T("Tanlangan tartib panelda ko'rsatiladi.",py+120,"#6b7a8a","11px monospace")}
 else if(pg===4){H2("Foydalanuvchilar",py+8);T(USER+"   uid=1000   groups: "+USER+", sudo",py+34);T("root     uid=0      (kirish yopiq)",py+56);T("Hostname: "+HOST,py+90,"#8fa3b5","12px monospace");T("Fayl ruxsatlari o'yin ichida amal qiladi: sudo kerak bo'lsa terminalda 'sudo' ishlating.",py+114,"#6b7a8a","11px monospace")}
 else if(pg===5){drawDispPage(w,px,py,T,H2,radio,chb)}
 else{H2("Quvvat boshqaruvi",py+8);[["O'chirish (Shutdown)","#b8472f",()=>power()],["Qayta yoqish (Restart)","#2b6bd6",()=>{S.restart=true;power()}],["Tizimdan chiqish (Log out)","#4b5a68",()=>logout()]].forEach((b,i)=>{const y=py+28+i*40;rr(px,y,230,30,6,b[1]);tx(b[0],px+14,y+20,"#fff","13px monospace");hits.push({x:px,y,w:230,h:30,fn:b[2]})})}}
