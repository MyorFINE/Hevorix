/* ==========================================================
 * Modul: js/kali/panel.js
 * Panel: tarmoq, ovoz, kalendar
 * ========================================================== */
/* ---- panel: tarmoq, ovoz, kalendar ---- */
function popClick(x,y){const p=POP;let r=false;
 if(p.t==="cal"){const bx=W-250;if(x>=bx&&x<bx+240&&y>=32&&y<232){r=true;if(y<58){if(x<bx+44)p.off--;else if(x>bx+196)p.off++}}}
 else if(p.t==="vol"){if(x>=770&&x<990&&y>=32&&y<104){r=true;if(y>=60&&y<80&&x>=784&&x<=960){SET.vol=Math.max(0,Math.min(100,Math.round((x-784)/176*100)));SET.mute=false;saveSet();beep()}else if(y>=84){SET.mute=!SET.mute;saveSet()}}}
 else if(p.t==="net"){if(x>=700&&x<1000&&y>=32&&y<156)r=true}
 if(!r)POP=null;dirty=true;return r}
function drawPop(){if(!POP)return;const p=POP;
 if(p.t==="cal"){const bx=W-250,d=new Date(),m=new Date(d.getFullYear(),d.getMonth()+p.off,1);rr(bx,32,240,200,6,"#161c2a");c.strokeStyle="#2a3345";c.lineWidth=1;c.strokeRect(bx+.5,32.5,239,199);
  tx("‹",bx+16,52,"#c5d3e0","bold 18px monospace");tx("›",bx+212,52,"#c5d3e0","bold 18px monospace");const ttl=m.toLocaleDateString("uz-UZ",{month:"long",year:"numeric"});tx(ttl,bx+120-ttl.length*3.9,50,"#7fd4ff","bold 13px monospace");
  ["Du","Se","Ch","Pa","Ju","Sh","Ya"].forEach((s,i)=>tx(s,bx+12+i*32,76,"#6b7a8a","12px monospace"));
  const f0=(m.getDay()+6)%7,dn=new Date(m.getFullYear(),m.getMonth()+1,0).getDate();for(let i=1;i<=dn;i++){const k=f0+i-1,x=bx+8+(k%7)*32,y=84+Math.floor(k/7)*22,td=p.off===0&&i===d.getDate();if(td)rr(x,y,28,20,4,accent());tx(String(i),x+(i<10?10:6),y+14,td?"#fff":"#c5d3e0","12px monospace")}}
 else if(p.t==="vol"){rr(770,32,220,72,6,"#161c2a");c.strokeStyle="#2a3345";c.lineWidth=1;c.strokeRect(770.5,32.5,219,71);tx("Ovoz: "+(SET.mute?"o'chirilgan":SET.vol+"%"),784,54,"#c5d3e0","13px monospace");rr(784,66,176,8,3,"#2b3347");if(!SET.mute)rr(784,66,Math.max(6,176*SET.vol/100),8,3,accent());tx(SET.mute?"Ovozni yoqish":"Ovozni o'chirish",784,96,"#7fd4ff","12px monospace")}
 else{rr(700,32,300,124,6,"#161c2a");c.strokeStyle="#2a3345";c.lineWidth=1;c.strokeRect(700.5,32.5,299,123);tx("Wired connection 1 — ulangan",714,54,"#3dd8a0","13px monospace");tx("eth0: "+SET.ip+"/24",714,76,"#c5d3e0","13px monospace");tx("Gateway: 192.168.1.1   DNS: 192.168.1.1",714,96,"#8fa3b5","12px monospace");tx("Firewall (ufw): "+(SET.fw?"yoqilgan":"o'chirilgan"),714,116,SET.fw?"#3dd8a0":"#e5c15d","12px monospace");tx("Kirish: "+SIM.rxNow+" KB/s",714,140,"#8fa3b5","12px monospace")}}
function drawPanel(){rr(0,0,W,30,0,"#161a24");c.fillStyle="#2a3345";c.fillRect(0,29,W,1);
 rr(8,4,22,22,5,menuOpen?"#3b7be0":accent());tx("K",14,21,"#fff","bold 16px monospace");
 rr(36,4,56,22,5,placesOpen?"#2a3345":"#1d2230");tx("Places",43,20,"#c5d3e0","12px monospace");
 APPS.forEach((a,i)=>{rr(100+i*30,4,24,22,5,a.col);tx(a.k,106+i*30-(a.k.length>1?2:-3),21,a.fg,"bold 12px monospace")});
 const ws=[...wins].sort((a,b)=>a.seq-b.seq),n=ws.length;if(n){const bw=Math.min(120,Math.floor(280/n));ws.forEach((w,i)=>{const x=404+i*(bw+2),act=w.id===focusId&&!w.min;rr(x,4,bw,22,4,act?"#2b3347":"#1d2230");if(act){c.fillStyle=accent();c.fillRect(x+4,24,bw-8,2)}tx(winTitle(w).slice(0,Math.floor((bw-10)/7.4)),x+6,19,w.min?"#6b7a8a":"#c5d3e0","12px monospace")})}
 if(usbOn()){rr(700,6,34,18,4,"#0d3b4f");tx("USB",706,19,"#3dd8ff","bold 11px monospace")}
 for(let i=0;i<4;i++){c.fillStyle="#7fd4ff";c.fillRect(748+i*5,22-i*4,3,3+i*4)}
 c.fillStyle=SET.mute?"#6b7a8a":"#c5d3e0";c.fillRect(780,12,5,6);c.beginPath();c.moveTo(785,12);c.lineTo(791,8);c.lineTo(791,22);c.lineTo(785,18);c.closePath();c.fill();if(!SET.mute){c.strokeStyle="#c5d3e0";c.lineWidth=1.5;c.beginPath();c.arc(791,15,5,-.9,.9);c.stroke()}
 tx(SET.kb,806,20,"#9fb6c8","11px monospace");
 const d=new Date();tx(d.toLocaleDateString("uz-UZ",{day:"2-digit",month:"short"})+"  "+d.toLocaleTimeString("uz-UZ",{hour:"2-digit",minute:"2-digit"}),840,20,"#c5d3e0","13px monospace");
 tx("⏻",1000,21,"#ff7b72","bold 16px monospace")}
function panelClick(x,y,wp0){
 if(x>=8&&x<=32){menuOpen=!menuOpen;placesOpen=false;if(menuOpen){menuQ="";menuCat=0}return}
 if(x>=36&&x<=92){placesOpen=!placesOpen;menuOpen=false;return}
 if(x>=100&&x<100+APPS.length*30){const i=Math.floor((x-100)/30);if((x-100)%30<26)openApp(APPS[i].id);return}
 const ws=[...wins].sort((a,b)=>a.seq-b.seq),n=ws.length;
 if(n&&x>=404&&x<404+280+n*2){const bw=Math.min(120,Math.floor(280/n)),i=Math.floor((x-404)/(bw+2));if(i<n){const w=ws[i];if(w.id===focusId&&!w.min){w.min=true;const o=wins.filter(q=>!q.min).pop();focusId=o?o.id:null;ta.blur()}else{w.min=false;front(w)}}return}
 if(x>=744&&x<=772){POP=wp0==="net"?null:{t:"net"};return}
 if(x>=776&&x<=800){POP=wp0==="vol"?null:{t:"vol"};return}
 if(x>=836&&x<=960){POP=wp0==="cal"?null:{t:"cal",off:0};return}
 if(x>990)power()}
