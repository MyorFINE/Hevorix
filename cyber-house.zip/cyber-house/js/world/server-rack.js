/* ==========================================================
 * Modul: js/world/server-rack.js
 * Server rack
 * ========================================================== */
/* server rack */
box(-5.2,1.0,-5.6,.8,2.0,.9,L(0x0f1318),true);
const rl=new T.InstancedMesh(new T.BoxGeometry(.02,.03,.04),B(0xffffff),20);rl.position.set(0,0,0);
{const d=new T.Object3D();for(let i=0;i<20;i++){d.position.set(-4.79,.35+Math.floor(i/2)*.16,-5.8+(i%2)*.3);d.updateMatrix();rl.setMatrixAt(i,d.matrix);rl.setColorAt(i,new T.Color(0x00ff88))}scene.add(rl)}
box(-4.78,1.0,-5.6,.02,1.8,.8,L(0x1c232b));
box(-4.7,.3,-1.2,.7,.6,.9,L(0x4a4136),true);box(-4.8,.8,-1.1,.5,.4,.6,L(0x5a4f42));
box(4.6,.35,-6.0,.8,.7,.8,L(0x2c3a46),true);
