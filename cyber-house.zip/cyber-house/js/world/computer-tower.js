/* ==========================================================
 * Modul: js/world/computer-tower.js
 * Kompyuter korpusi (tower) modeli
 * ========================================================== */
/* ---------- kompyuter ---------- */
const pc=new T.Group();pc.position.set(1.0,0,-3.0);scene.add(pc);
const pm=new T.Mesh(new T.BoxGeometry(.42,.85,.6),L(0x14181d));pm.position.y=.43;pc.add(pm);
const pg=new T.Mesh(new T.BoxGeometry(.01,.62,.5),new T.MeshLambertMaterial({color:0x1a2a35,transparent:true,opacity:.55}));pg.position.set(-.215,.45,0);pc.add(pg);
const fans=[];for(let i=0;i<3;i++){const f=new T.Mesh(new T.RingGeometry(.03,.095,7),B(0x111111));f.position.set(0,.22+i*.22,.302);pc.add(f);fans.push(f)}
const pb=new T.Mesh(new T.CylinderGeometry(.03,.03,.02,12),B(0xff3b3b));pb.rotation.x=Math.PI/2;pb.position.set(.12,.8,.305);pc.add(pb);
