/* ==========================================================
 * Modul: js/world/monitor-details.js
 * Monitor detallari: bezel, panel, stand, HDMI/DP, ventilyatsiya
 * ========================================================== */
/* ===== MONITOR: Bezel, Display Panel, Stand, Stand Neck, HDMI, DisplayPort, Power Connector, Ventilation Grilles ===== */
{const M=MG(),k=M.c(0x1a2028),kg=M.c(0x2a3138),ks=M.c(0xa7b0b8),kb=M.c(0x020304,true),kc=M.c(0x1d252c),zf=-3.7785;
 /* Bezel: ko'tarilgan old ramka, pastki chin, logotip, tugmalar, veb-kamera */
 M.box(1.02,.03,.008,k,0,1.585,zf);M.box(1.02,.03,.008,k,0,1.015,zf);M.box(.03,.54,.008,k,-.495,1.3,zf);M.box(.03,.54,.008,k,.495,1.3,zf);
 M.box(.07,.006,.002,ks,0,1.015,-3.7737);for(let i=0;i<4;i++)M.box(.014,.008,.004,kc,.26+i*.03,1.012,-3.7745);
 M.add(new T.CircleGeometry(.0065,10),kb,0,1.585,-3.7739);M.add(new T.RingGeometry(.0065,.0095,10),kc,0,1.585,-3.7741);
 part(null,0,1.3,-3.8,1.02,.6,.035,"Bezel — Monitor ramkasi");part(null,0,1.585,zf,1.02,.03,.008,"Bezel — Monitor ramkasi");part(null,0,1.015,zf,1.02,.03,.008,"Bezel — Monitor ramkasi");part(null,-.495,1.3,zf,.03,.54,.008,"Bezel — Monitor ramkasi");part(null,.495,1.3,zf,.03,.54,.008,"Bezel — Monitor ramkasi");
 part(null,0,1.3,-3.7805,.96,.54,.004,"Display Panel — Ekran paneli");
 /* orqa korpus */
 part(null,0,1.3,-3.84,.5,.4,.06,"Monitor orqa korpusi");
 /* Monitor Stand: oval taglik */
 M.add(new T.CylinderGeometry(.15,.16,.014,28),kg,0,.907,-3.84,0,0,0,1,1,.75);M.add(new T.CylinderGeometry(.152,.152,.002,28),ks,0,.9145,-3.84,0,0,0,1,1,.75);
 part(null,0,.907,-3.84,.32,.014,.24,"Monitor Stand — Monitor oyoqchasi");
 /* Stand Neck: bo'yin, yoqa, sharnir, kabel teshigi */
 M.box(.07,.17,.032,kg,0,1.012,-3.855);M.add(new T.CylinderGeometry(.04,.05,.02,16),kg,0,.925,-3.84);M.add(new T.CylinderGeometry(.02,.02,.1,12),ks,0,1.1,-3.85,0,0,Math.PI/2);M.box(.02,.05,.002,kb,0,1.0,-3.8715);
 part(null,0,1.01,-3.855,.07,.18,.034,"Stand Neck — Monitor bo'yni");
 /* orqa portlar: HDMI, DisplayPort, Power Connector */
 M.box(.036,.014,.008,ks,-.15,1.14,-3.874);M.box(.028,.008,.002,kb,-.15,1.14,-3.8785);
 M.box(.03,.012,.008,ks,.05,1.14,-3.874);M.box(.022,.007,.002,kb,.05,1.14,-3.8785);M.box(.004,.004,.002,kb,.0635,1.1445,-3.8785);
 M.box(.04,.02,.01,kg,-.04,1.14,-3.875);M.box(.004,.008,.002,kb,-.05,1.14,-3.8805);M.box(.004,.008,.002,kb,-.03,1.14,-3.8805);
 part(null,-.15,1.14,-3.875,.04,.02,.012,"HDMI Port");part(null,.05,1.14,-3.875,.034,.016,.012,"DisplayPort");part(null,-.04,1.14,-3.876,.044,.024,.012,"Power Connector — Quvvat porti");
 /* Ventilation Grilles: orqa teshiklar */
 for(const sd of[-1,1]){for(let r=0;r<8;r++)M.box(.07,.006,.002,kb,sd*.14,1.33+r*.016,-3.8708);part(null,sd*.14,1.39,-3.8715,.08,.13,.004,"Ventilation Grilles — Orqa ventilyatsiya teshiklari")}
 M.done()}

