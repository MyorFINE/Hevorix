/* ==========================================================
 * Modul: js/world/keyboard-mouse.js
 * Klaviatura va sichqoncha modellari
 * ========================================================== */
/* klaviatura + sichqoncha */
box(0,.9125,-2.95,1.12,.025,.36,L(0x1c2128));
const KB_U=.0555,KDEF=[],KIDX={};
{const mk=t=>t.split("").map(c=>[c,1]);
 const rows=[[...mk("`1234567890-="),["⌫",2]],[["Tab",1.5],...mk("QWERTYUIOP[]"),["\\",1.5]],[["Caps",1.75],...mk("ASDFGHJKL;'"),["Enter",2.25,"E"]],[["Shift",2.25,"S"],...mk("ZXCVBNM,./"),["Shift",2.75,"S"]],[["Ctrl",1.25],["Win",1.25],["Alt",1.25],["SPACE",6.25,"B"],["Alt",1.25],["Fn",1.25],["Menu",1.25],["Ctrl",1.25]]];
 rows.forEach((row,r)=>{let x=-.535;const z=-3.085+r*.058;row.forEach(k=>{const w=k[1]*KB_U,cx=x+w/2;x+=w;const lb=k[0],nm=k[2]==="B"?"Spacebar — katta bo'sh joy tugmasi":k[2]==="E"?"Enter Key — Enter":k[2]==="S"?"Shift Key — Shift":"Keycap — alohida tugma ("+lb+")";KDEF.push({x:cx,z,w:w-.004,l:lb,n:nm});if(KIDX[lb.toUpperCase()]==null)KIDX[lb.toUpperCase()]=KDEF.length-1})});
 [["↑",.4185,-2.911],["←",.363,-2.853],["↓",.4185,-2.853],["→",.474,-2.853]].forEach(q=>{KDEF.push({x:q[1],z:q[2],w:KB_U-.004,l:q[0],n:"Arrow Keys — yo'nalish tugmalari ("+q[0]+")"});KIDX[q[0]]=KDEF.length-1})}
function keyIdx(k){k=k==null?"":String(k);const m={" ":"SPACE",Backspace:"⌫",CapsLock:"CAPS",Control:"CTRL",Meta:"WIN",ArrowUp:"↑",ArrowDown:"↓",ArrowLeft:"←",ArrowRight:"→",Escape:"`"},q=KIDX[(m[k]||k).toUpperCase()];return q!=null?q:((k.length?k.charCodeAt(0)*7:13)%KDEF.length)}
const KGEO=new T.BoxGeometry(1,1,1);{const p=KGEO.attributes.position;for(let i=0;i<p.count;i++)if(p.getY(i)>0){p.setX(i,p.getX(i)*.82);p.setZ(i,p.getZ(i)*.82)}KGEO.computeVertexNormals()}
const keys=new T.InstancedMesh(KGEO,L(0x3a4350),KDEF.length);
{const d=new T.Object3D();KDEF.forEach((k,n)=>{d.position.set(k.x,.933,k.z);d.scale.set(k.w,.016,.05);d.updateMatrix();keys.setMatrixAt(n,d.matrix);keys.setColorAt(n,new T.Color(1,1,1));part(null,k.x,.933,k.z,k.w,.016,.05,k.n)});scene.add(keys)}
part(null,0,.9125,-2.95,1.12,.025,.36,"Keyboard — klaviatura korpusi");
/* tugma yozuvlari */
{const cw=1024,ch=Math.round(cw*.36/1.12),c2=cv(cw,ch),g=c2.getContext("2d");g.textAlign="center";g.textBaseline="middle";g.fillStyle="#d7e6f2";
 KDEF.forEach(k=>{g.font=(k.l.length>2?"bold 13px":"bold 22px")+" monospace";g.fillText(k.l,(k.x+.56)/1.12*cw,(k.z+3.13)/.36*ch)});
 const lg=new T.Mesh(new T.PlaneGeometry(1.12,.36),new T.MeshBasicMaterial({map:tex(c2),transparent:true,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-2}));lg.rotation.x=-Math.PI/2;lg.position.set(0,.9418,-2.95);scene.add(lg)}
/* Keyboard Cable: himoya mufta + nom */
{const M=MG();M.add(new T.CylinderGeometry(.0085,.0085,.03,8),M.c(0x0b0d10),-.4,.9125,-3.145,Math.PI/2,0,0);M.done();part(null,-.4,.912,-3.665,.03,.024,1.07,"Keyboard Cable — klaviatura kabeli")}
box(.85,.906,-3.0,.45,.012,.36,L(0x141a20));
const mouse=new T.Group();mouse.position.set(.85,.912,-3.0);scene.add(mouse);
/* MOUSE: korpus, Scroll Wheel, Side Buttons, Sensor */
{const M=MG(mouse),kb=M.c(0x2a323a),kd=M.c(0x11161b),ks=M.c(0xaab4bd),kw=M.c(0x59636e),hy=(x,z)=>.034*Math.sqrt(Math.max(.02,1-(z/.055)**2-(x/.031)**2));
 M.add(new T.SphereGeometry(1,18,10,0,Math.PI*2,0,Math.PI/2),kb,0,.003,0,0,0,0,.031,.031,.055);M.add(new T.CylinderGeometry(1,1,.006,18),kd,0,.003,0,0,0,0,.031,1,.055);
 for(let z=-.048;z<=-.011;z+=.006)M.box(.0018,.0012,.007,kd,0,hy(0,z)+.003+.0002,z);
 for(let x=-.028;x<=.029;x+=.007)M.box(.008,.0012,.0018,kd,x,hy(x,-.012)+.003+.0002,-.012);
 M.add(new T.CylinderGeometry(.0075,.0075,.01,14),ks,0,.0315,-.03,0,0,Math.PI/2);M.add(new T.TorusGeometry(.0075,.0013,5,14),kd,0,.0315,-.03,0,Math.PI/2,0);
 M.box(.005,.009,.016,kw,-.0295,.016,-.002);M.box(.005,.009,.016,kw,-.0275,.014,.019);
 M.done();
 const gl=new T.Mesh(new T.CircleGeometry(1,22),new T.MeshBasicMaterial({color:0xff2a2a,transparent:true,opacity:.4,depthWrite:false}));gl.scale.set(.04,.065,1);gl.rotation.x=-Math.PI/2;gl.position.y=.0008;mouse.add(gl);
 part(mouse,0,.0008,0,.08,.0016,.13,"Mouse Sensor — optik sensor (pastki qizil nur)");
 part(mouse,0,.021,0,.062,.036,.11,"Mouse — sichqoncha korpusi");
 part(mouse,0,.0335,-.03,.012,.022,.017,"Mouse Scroll Wheel — sichqoncha g'ildiragi");
 part(mouse,-.0295,.016,-.002,.009,.012,.018,"Mouse Side Buttons — yon tugmalar");part(mouse,-.0275,.014,.019,.009,.012,.018,"Mouse Side Buttons — yon tugmalar")}
