/* ==========================================================
 * Modul: js/cables/cable-simulation.js
 * Kabel simulyatsiyasi (cableInit, cable)
 * ========================================================== */
function cableInit(d,end){const w=[d.A].concat(d.via(end),[end]),N=d.N;let tot=0;const sg=[];for(let i=1;i<w.length;i++){const l=w[i].distanceTo(w[i-1]);sg.push(l);tot+=l}
 for(let i=0;i<=N;i++){let t=i/N*tot,j=0;while(j<sg.length-1&&t>sg[j]){t-=sg[j];j++}d.pts[i].lerpVectors(w[j],w[j+1],sg[j]>0?Math.min(1,t/sg[j]):0);d.pv[i].copy(d.pts[i])}d.init=1;d.slp=0}
function cable(dt){dt=Math.min(dt||.016,.033);for(const k in DV){const d=DV[k],pl=S[d.s],hd=S.hold===k,end=hd?hand:pl?d.out:d.rest,pts=d.pts,pv=d.pv,N=d.N,sl=d.L/N;
 if(hd)for(const a of CBH)colBox(hand,a);
 if(!d.init||end.distanceTo(d.last)>1||d.str>40){cableInit(d,end);d.str=0}
 const moved=end.distanceToSquared(d.last)>1e-8;d.last.copy(end);if(moved)d.slp=0;
 if(d.slp<40){const bx=d.bx||(d.bx=CBI.filter(a=>a.tag!==d.tag)),nb=bx.length,sub=lowEnd?1:2,h=dt/sub;let ke=0;
  const colPass=()=>{for(let j=0;j<nb;j++){const a=bx[j];
     for(let i=0;i<N;i++){const A=pts[i],Bp=pts[i+1],fa=i?1:0,fb=i+1<N?1:0;if(!fa&&!fb)continue;
      for(let s=0;s<3;s++){const t=s===0?0:s===1?.34:.67,x=A.x+(Bp.x-A.x)*t,y=A.y+(Bp.y-A.y)*t,z=A.z+(Bp.z-A.z)*t;
       if(t===0&&!fa)continue;if(boxOut(x,y,z,a,_o)){const wa=fa*(1-t),wb=fb*t,ws=wa*wa+wb*wb;if(ws<1e-6)continue;const ka=wa/ws,kb=wb/ws;
        if(fa){A.x+=_o.x*ka;A.y+=_o.y*ka;A.z+=_o.z*ka;const q=pv[i];q.x+=(A.x-q.x)*.25;q.y+=(A.y-q.y)*.25;q.z+=(A.z-q.z)*.25}
        if(fb&&t>0){Bp.x+=_o.x*kb;Bp.y+=_o.y*kb;Bp.z+=_o.z*kb;const q=pv[i+1];q.x+=(Bp.x-q.x)*.25;q.y+=(Bp.y-q.y)*.25;q.z+=(Bp.z-q.z)*.25}}}}}};
  for(let st=0;st<sub;st++){
   for(let i=1;i<N;i++){const p=pts[i],q=pv[i],x=p.x,y=p.y,z=p.z;p.x+=(x-q.x)*.97;p.y+=(y-q.y)*.97-9.8*h*h;p.z+=(z-q.z)*.97;q.set(x,y,z)}
   pts[0].copy(d.A);pts[N].copy(end);
   for(let it=0;it<14;it++){
    for(let i=0;i<N;i++){const a=pts[i],b=pts[i+1],dx=b.x-a.x,dy=b.y-a.y,dz=b.z-a.z,l=Math.hypot(dx,dy,dz);if(l>sl){const c=(l-sl)/l,ia=i?1:0,ib=i+1<N?1:0,n=ia+ib;if(n){a.x+=dx*c*ia/n;a.y+=dy*c*ia/n;a.z+=dz*c*ia/n;b.x-=dx*c*ib/n;b.y-=dy*c*ib/n;b.z-=dz*c*ib/n}}}
    for(let i=1;i<N;i++){const p=pts[i];if(p.y<FY){p.y=FY;const q=pv[i];q.x+=(p.x-q.x)*.2;q.z+=(p.z-q.z)*.2}}
    colPass();}
   for(let k2=0;k2<3;k2++){colPass();for(let i=1;i<N;i++){const p=pts[i];if(p.y<FY)p.y=FY}}
  }
  for(let i=1;i<N;i++){const p=pts[i];if(p.y<FY)p.y=FY}
  for(let i=1;i<N;i++){const p=pts[i],q=pv[i];ke+=(p.x-q.x)**2+(p.y-q.y)**2+(p.z-q.z)**2}
  d.slp=ke<1e-9?d.slp+1:0}
 let mxl=0;for(let i=0;i<N;i++)mxl=Math.max(mxl,pts[i].distanceTo(pts[i+1]));d.str=mxl>sl*1.8?(d.str||0)+1:0;
 for(let i=0;i<N;i++){const a=pts[i],b=pts[i+1];dm2.position.copy(a).add(b).multiplyScalar(.5);dm2.lookAt(b);dm2.scale.set(1,1,a.distanceTo(b)+.006);dm2.updateMatrix();d.cab.setMatrixAt(i,dm2.matrix)}
 d.cab.instanceMatrix.needsUpdate=true;d.pl.position.copy(end);if(hd)d.pl.quaternion.copy(camera.quaternion);else d.pl.rotation.set(0,pl?d.rot:1.2,0)}}
