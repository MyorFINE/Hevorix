/* ==========================================================
 * Modul: js/education/notebook-ui.js
 * Blaknot interfeysi
 * ========================================================== */
/* blaknot nusxasi kompyuterda: ~/Desktop/Qollanma (Thunar/Mousepad/cat bilan ochiladi) */
function installGuide(){try{const wrap=(t,n)=>t.split("\n").map(l=>{const ind=l.startsWith("→ ")?"    ":"";return wrapT(l,n).map((x,i)=>i?ind+x:x).join("\n")}).join("\n");
 asRoot(()=>{[HOME+"/Desktop/Qollanma",HOME+"/Qollanma"].forEach(d=>{F.mkdir(d,true);let all="QO'LLANMA — barcha buyruqlar (yodlash uchun)\n"+"=".repeat(44)+"\n";LESSONS.forEach((l,i)=>{const nm=String(i+1).padStart(2,"0")+"-"+l.t.replace(/^\d+\.\s*/,"").toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"")+".txt",body=l.t+"\n"+"-".repeat(l.t.length)+"\n"+wrap(l.b,86)+"\n";F.wr(d+"/"+nm,body);all+="\n"+body});F.wr(d+"/00-hammasi.txt",all)});fsSave()})}catch(e){}}
installGuide();
function renderNote(){const l=LESSONS[notePg],esc=q=>q.replace(/&/g,"&amp;").replace(/</g,"&lt;");$("nt").textContent="📓 "+l.t;$("nb").innerHTML=l.b.split("\n").map(x=>x.startsWith("$ ")?'<span class="cm">'+esc(x)+"</span>":x.startsWith("→ ")?'<span class="ex">'+esc(x)+"</span>":esc(x)).join("\n");$("nb").scrollTop=0;$("ni").textContent=(notePg+1)+" / "+LESSONS.length}
function openNote(){noteOpen=true;document.exitPointerLock&&document.exitPointerLock();renderNote();$("note").style.display="flex"}
function closeNote(){noteOpen=false;$("note").style.display="none";if(started&&!mobile&&!seated)cvEl.requestPointerLock&&cvEl.requestPointerLock()}
function noteGo(d){notePg=(notePg+d+LESSONS.length)%LESSONS.length;renderNote()}
$("np").onclick=()=>noteGo(-1);$("nn").onclick=()=>noteGo(1);$("nx").onclick=closeNote;
const nbG=new T.Group();{nbG.add(new T.Mesh(new T.BoxGeometry(.16,.014,.22),L(0x8a1f2b)));const pg=new T.Mesh(new T.BoxGeometry(.15,.008,.205),L(0xf3efe2));pg.position.set(.004,.009,0);nbG.add(pg);const sp=new T.Mesh(new T.BoxGeometry(.012,.02,.22),L(0x5a1219));sp.position.set(-.08,.004,0);nbG.add(sp)}
nbG.position.set(0,-.045,-.38);nbG.rotation.y=.12;dr.add(nbG);
const nbW=()=>dr.localToWorld(new T.Vector3(0,-.04,-.38));
function noteUpd(){nbG.visible=S.dp>.05}
Object.assign(C,{audit:a=>{const n=parseInt(a[0]);if(!n)return"O'rgatuvchi auditlar:\n"+LESSONS.map(l=>"  audit "+(LESSONS.indexOf(l)+1)+"  — "+l.t.replace(/^\d+\.\s*/,"")).join("\n")+"\n\nTo'liq yozuvlar stol tortmasidagi blaknotda ham bor.";if(n<1||n>LESSONS.length)throw new Error("1-"+LESSONS.length+" oralig'ida tanlang");return LESSONS[n-1].t+"\n\n"+LESSONS[n-1].b}});
const h1=C.help;C.help=()=>h1()+"\nQo'llanma: audit  |  audit <1-"+LESSONS.length+">";
Object.assign(C,{wallet:a=>{const s=a[0]||"status",open=SEC.score,v=SEC.vault,n=a[1]==="all"?null:parseInt(a[1]);
 if(s==="lock"){const x=n==null?Math.max(0,open):n;if(!(x>0)||x>open)throw new Error("wallet lock <son|all> — ochiq ballingiz: "+open);SEC.score-=x;SEC.vault+=x;SEC.vaultT=Date.now();return x+" ball seyfga qulflandi (shifrlangan). Bot o'g'irlay olmaydi. Qaytarish: 60 soniyadan keyin."}
 if(s==="unlock"){const w=60000-(Date.now()-SEC.vaultT);if(w>0)throw new Error("Seyf vaqt-qulfi: yana "+Math.ceil(w/1000)+" soniya");const x=n==null?v:n;if(!(x>0)||x>v)throw new Error("Seyfda "+v+" ball bor");SEC.vault-=x;SEC.score+=x;return x+" ball ochiq hamyonga qaytdi (endi o'g'irlanishi mumkin)"}
 return"HAMYON\n  Ochiq ball : "+open+"   <- hujumda bot o'g'irlashi mumkin\n  Seyf       : "+v+"   <- o'g'irlanmaydi\n\nwallet lock <son|all>    ochiq ballni seyfga yashiradi\nwallet unlock <son|all>  seyfdan qaytaradi (60s vaqt-qulfi)"},
 man:a=>{const n=a[0];if(!n)return"usage: man <buyruq>   (masalan: man nmap).  Ro'yxat: audit";const out=[];LESSONS.forEach(l=>{let on=false;l.b.split("\n").forEach(x=>{if(x.startsWith("$ "))on=x.slice(2).split(" ")[0]===n;else if(x==="")on=false;if(on)out.push(x)})});if(!out.length)throw new Error("No manual entry for "+n+" — 'audit' ro'yxatiga qarang");return out.join("\n")}});
const h3=C.help;C.help=()=>h3()+"\nYordam: man <buyruq>  |  wallet [lock|unlock]  — ballni himoyalash";
