/* ==========================================================
 * Modul: js/interaction/ports-aim.js
 * Portlar ro'yxati va nigoh nuri (aim)
 * ========================================================== */
const cd=v=>camera.position.distanceTo(v);
const PORTS=[[-.05,.55],[.05,.55]],PM=[],FV=new V(),DFL=new V(.3,.907,-3.3),zOff=new V(0,0,.04),fl=new T.Group();
{const a=(w,h,d,z,c)=>{const m=new T.Mesh(new T.BoxGeometry(w,h,d),L(c));m.position.z=z;fl.add(m)};a(.03,.012,.06,.01,0x00bce9);a(.018,.006,.025,-.032,0xc0ccd4)}scene.add(fl);
const portW=i=>{pc.updateMatrixWorld();return pc.localToWorld(new V(PORTS[i][0],PORTS[i][1],.32))};
const _d=new V(),_f=new V();function aim(v){camera.getWorldDirection(_f);_d.copy(v).sub(camera.position).normalize();return Math.acos(Math.max(-1,Math.min(1,_f.dot(_d))))}
