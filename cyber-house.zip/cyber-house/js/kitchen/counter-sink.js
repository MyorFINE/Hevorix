/* ==========================================================
 * Modul: js/kitchen/counter-sink.js
 * Ish stoli oshxona: tokcha, kran
 * ========================================================== */
/* ish stoli oshxona: tokcha, kran */
cols.push({x:-4.925,z:-13.5,hw:1.575,hd:.375});
box(-6.1,.45,-13.5,.8,.9,.7,kcab);box(-5.3,.45,-13.14,.8,.9,.02,kcab);
box(-6.1,.92,-13.5,.8,.05,.75,ktop);box(-4.125,.92,-13.5,1.55,.05,.75,ktop);box(-5.3,.92,-13.1875,.8,.05,.125,ktop);box(-5.3,.92,-13.8125,.8,.05,.125,ktop);
box(-5.3,.75,-13.5,.78,.02,.48,kmet);box(-5.69,.8475,-13.5,.02,.195,.5,kmet);box(-4.91,.8475,-13.5,.02,.195,.5,kmet);box(-5.3,.8475,-13.26,.78,.195,.02,kmet);box(-5.3,.8475,-13.74,.78,.195,.02,kmet);
kcyl(.03,.03,.005,L(0x1a1d20),-5.3,.762,-13.5,10);
const KWS=new T.Mesh(new T.CylinderGeometry(.009,.009,.58,6),new T.MeshBasicMaterial({color:0x8fd8ff,transparent:true,opacity:.6}));KWS.position.set(-5.3,1.05,-13.56);scene.add(KWS);
const KWP=new T.Mesh(new T.RingGeometry(.02,.05,14),new T.MeshBasicMaterial({color:0xbfe9ff,transparent:true,opacity:.5,side:T.DoubleSide,depthWrite:false}));KWP.rotation.x=-Math.PI/2;KWP.position.set(-5.3,.775,-13.56);scene.add(KWP);
const KWL=new T.Mesh(new T.BoxGeometry(.76,.012,.46),new T.MeshBasicMaterial({color:0x5fb8e8,transparent:true,opacity:.5,depthWrite:false}));KWL.position.set(-5.3,.775,-13.5);scene.add(KWL);KWS.visible=KWP.visible=KWL.visible=false;box(-2.9,.45,-13.5,.9,.9,.75,L(0x2c3137),true);box(-2.9,.92,-13.5,.9,.04,.75,L(0x1b1e22));cols.push({x:-1.15,z:-13.5,hw:1.35,hd:.35});box(-1.15,.92,-13.5,2.7,.05,.75,ktop);
box(-5.3,1.12,-13.78,.05,.45,.05,kmet);box(-5.3,1.33,-13.68,.05,.05,.25,kmet);box(-5.3,1.36,-13.56,.04,.03,.04,kmet);
for(let i=0;i<5;i++){const px=-4.55+i*.075,pl=kcyl(.09,.09,.012,kpl,px,1.05,-13.55,16);pl.rotation.x=Math.PI/2;const rg2=new T.Mesh(new T.TorusGeometry(.072,.007,6,16),kpr);rg2.position.set(px,1.05,-13.55+.008);scene.add(rg2)}
box(-4.45,.96,-13.55,.5,.03,.2,L(0x59636e));
