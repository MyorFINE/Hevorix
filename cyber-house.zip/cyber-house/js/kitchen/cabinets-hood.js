/* ==========================================================
 * Modul: js/kitchen/cabinets-hood.js
 * Dimohod va shkaflar
 * ========================================================== */
/* dimohod + shkaflar */
{const m=kmet,dk=L(0x15181b);box(-3.36,2.1,-13.5925,.03,.18,.565,m);box(-2.44,2.1,-13.5925,.03,.18,.565,m);box(-2.9,2.175,-13.5925,.95,.03,.565,m);box(-2.9,2.1,-13.325,.95,.18,.03,m);box(-2.9,2.1,-13.86,.88,.17,.02,dk);
 const gc=cv(128,64),g=gc.getContext("2d");g.fillStyle="#3a4048";g.fillRect(0,0,128,64);g.globalCompositeOperation="destination-out";for(let r=0;r<6;r++)for(let k=0;k<9;k++)g.fillRect(6+k*13.5,6+r*9.5,9,5);
 const gr=new T.Mesh(new T.PlaneGeometry(.78,.4),new T.MeshBasicMaterial({map:tex(gc),transparent:true,side:T.DoubleSide,depthWrite:false}));gr.rotation.x=Math.PI/2;gr.position.set(-2.9,2.11,-13.58);scene.add(gr);
 window.KFAN=new T.Group();KFAN.position.set(-2.9,2.15,-13.58);[0,1.05,2.1].forEach(a=>{const b=new T.Mesh(new T.BoxGeometry(.3,.004,.05),B(0x7a8591));b.rotation.y=a;KFAN.add(b)});scene.add(KFAN)}
box(-2.9,2.8,-13.78,.3,1.25,.3,kmet);const KHL=box(-2.9,2.163,-13.5,.46,.01,.16,L(0x2a2d31,{emissive:0x000000}));box(-2.9,2.1,-13.31,.12,.06,.03,L(0xd23b3b));

const KHM=L(0x2b3036),_hp=new V(),_hq=new V();
function kInst(g,m,a){const o=new T.InstancedMesh(g,m,a.length),d=new T.Object3D(),c1=new T.Color();a.forEach((p,i)=>{d.position.set(p[0],p[1],p[2]);d.scale.set(p[3]||1,p[4]||1,p[5]||1);d.rotation.set(p[6]||0,p[7]||0,p[8]||0);d.updateMatrix();o.setMatrixAt(i,d.matrix);o.setColorAt(i,c1.setHex(p[9]||0xffffff))});o.frustumCulled=false;scene.add(o);return o}
function mkCab(x0,x1,y0,y1,zb,zf,nd,sh){const t=.025,w=x1-x0,h=y1-y0,d=zf-zb,zc=(zb+zf)/2,ym=(y0+y1)/2,xm=(x0+x1)/2,o={doors:[],pts:[],open:false,p:0};
 box(x0+t/2,ym,zc,t,h,d,kcab);box(x1-t/2,ym,zc,t,h,d,kcab);box(xm,y1-t/2,zc,w,t,d,kcab);box(xm,y0+t/2,zc,w,t,d,kcab);box(xm,ym,zb+t/2,w,h,t,L(0xb9c1c7));
 sh.forEach(y=>box(xm,y,zc,w-2*t,.02,d-.04,L(0xdfe5e9)));
 const dw=w/nd;
 for(let i=0;i<nd;i++){const lf=i%2===0,hx=lf?x0+i*dw:x0+(i+1)*dw,g=new T.Group();g.position.set(hx,ym,zf+.012);
  const m=new T.Mesh(new T.BoxGeometry(dw-.006,h-.01,.02),kcab);m.position.x=lf?dw/2:-dw/2;g.add(m);
  const hd=new T.Mesh(new T.BoxGeometry(.024,Math.min(.22,h*.4),.03),KHM);hd.position.set(lf?dw-.05:-dw+.05,y1<1.5?h/2-.14:-h/2+.14,.03);g.add(hd);scene.add(g);
  o.doors.push({g,hd,s:lf?-1:1,x0:x0+i*dw,x1:x0+(i+1)*dw,o:0,p:0,pt:new V(x0+(i+.5)*dw,ym,zf)})}
 return o}
const KC=[mkCab(-6.6,-3.4,1.9,2.7,-13.875,-13.5,4,[2.3]),mkCab(-2.2,.27,1.9,2.7,-13.875,-13.5,3,[2.3]),mkCab(-4.9,-3.35,0,.9,-13.85,-13.15,2,[.46]),mkCab(-2.45,.2,0,.9,-13.85,-13.15,3,[.46])];
KP.ctom=new V(-4.55,.52,-13.33);KP.cegg=new V(-1.9,.55,-13.3);KP.plate=new V(-4.4,1.03,-13.55);
