/* ==========================================================
 * Modul: js/kitchen/eating.js
 * Sirt tanlash va ovqat yeyish
 * ========================================================== */
function surfHit(){camera.getWorldDirection(_sd);if(_sd.y>-.05)return null;const S1=[.945,-6.4,.1,-13.8,-13.2],S2=[.79,-4.65,-2.55,-10.9,-9.9];
 for(const s of [S1,S2]){const t=(s[0]-camera.position.y)/_sd.y;if(t<=0||t>2.0)continue;const x=camera.position.x+_sd.x*t,z=camera.position.z+_sd.z*t;
  if(x<s[1]||x>s[2]||z<s[3]||z>s[4]||Math.hypot(P.x-x,P.z-z)>1.6)continue;if(s===S1&&((x>-5.8&&x<-4.8)||Math.hypot(x+6.1,z+13.45)<.18||Math.hypot(x+2.05,z+13.45)<.22||BLK.some(b=>Math.hypot(x-b[0],z-b[1])<b[2])))continue;
  if(KT.pls.some(p=>Math.hypot(p.x-x,p.z-z)<.24)||KT.bws.some(p=>Math.hypot(p.x-x,p.z-z)<.2)||(KT.ld.w==="surf"&&Math.hypot(KT.ld.x-x,KT.ld.z-z)<.27))continue;return{x,y:s[0]+.0075,z}}return null}
const KCH=[[-4.3,-9.55,0],[-2.9,-9.55,0],[-4.3,-11.25,1],[-2.9,-11.25,1]],KTV=new V(),KSp=new V(-5.3,1.2,-13.6);
const FDC=[0,1,2,3].map(()=>{const o={x:999,z:999,hw:.1,hd:.1};cols.push(o);return o});
const frOK=()=>P.x<-6.62&&P.x>-7.3&&P.z<-12.0&&P.z>-13.0;
let eatT=0;const eatPos=new V(),eatQ=new T.Quaternion(),dm3=new T.PerspectiveCamera();
function startEat(){let bi=0,bd=9;KCH.forEach((c,i)=>{const d=Math.hypot(P.x-c[0],P.z-c[1]);if(d<bd){bd=d;bi=i}});const c=KCH[bi],pz=-10.4+(c[2]?-.3:.3);
 KT.eat={ci:bi,t:0,k:KT.item};KT.item=null;KT.tbl=null;P.vx=P.vz=0;TPL.position.set(c[0],.7975,pz);TPw.visible=TPy.visible=true;TPw.scale.set(1,1,1);TPy.scale.set(1,.55,1);if(KT.eat.k==="posh"){TPw.visible=TPy.visible=false;TPO.position.set(c[0],.7975,pz);TPOm.scale.set(1,1,1)}
 dm3.position.set(c[0],1.22,c[1]+(c[2]?.05:-.05));dm3.lookAt(c[0],.8,pz);eatPos.copy(dm3.position);eatQ.copy(dm3.quaternion);toast("🪑 Stulga o'tirdingiz — yeyapsiz…")}
function kBounds(lim){const open=KT.dp>.6,dw=P.x>-4.15&&P.x<-3.05;if(P.z>-6)P.k=false;
 if(P.k){P.z=Math.max(P.z,-13.4);if(P.z>-7.3){if(open&&dw)P.x=Math.max(-4.15,Math.min(-3.05,P.x));else P.z=-7.3}
  if(P.z>-6.5){P.k=false;P.x=lim(P.x,5.55)}else if(P.z<=-7.3)P.x=Math.max(-7.1,Math.min(-.1,P.x))}
 else{P.x=lim(P.x,5.55);P.z=Math.min(P.z,6.5);if(P.z<-6.5){if(open&&dw){P.x=Math.max(-4.15,Math.min(-3.05,P.x));if(P.z<-7.3)P.k=true}else P.z=-6.5}}}
function eatItem(){const v={bread:28,fried:50,apple:16,egg:8,tomato:12,carrot:10}[KT.item]||10,tb=Math.hypot(P.x+3.6,P.z+10.4)<2.6,g=Math.round(v*(tb?1:.6));LF.hunger=Math.max(0,LF.hunger-g);toast("🍽 "+KN[KT.item]+" yedingiz (−"+g+" ochlik)"+(tb?"":" · stol yonida yesangiz ko'proq to'yasiz"));KT.item=null}
const togGas=()=>{KT.gas=!KT.gas;toast(KT.gas?"🔥 Gaz yoqildi":"Gaz o'chirildi")};
