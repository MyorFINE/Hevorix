/* ==========================================================
 * Modul: js/kitchen/kitchen-helpers.js
 * Oshxona: silindr yordamchisi va asosiy qiymatlar
 * ========================================================== */
/* ---------- OSHXONA ---------- */
const _k0=scene.children.length;window.ROOMG=new T.Group();scene.children.slice(0).filter(o=>(o.isMesh||o.isGroup||o.isPoints||o.isLine)&&Math.abs(o.position.z+6.85)>=.55).forEach(o=>ROOMG.add(o));scene.add(ROOMG);const _k1=scene.children.length;
const KT={open:false,dp:0,fr:false,fdp:0,gas:false,hood:false,item:null,pan:null,apples:3,at:0,tap:false,tapT:0,eat:null,tbl:null,smk:0,warn:false,pls:[],pot:[],potT:0,wash:null,get lid(){return this.ld.w!=="pot"},lidp:0,potP:0,kp:3,bws:[],fz:[0,0,0,0],ld:{w:"pot"},water:0,bd:null,cutT:null,chop:"carrot",pi:[],dish:""};
const KP={door:new V(-3.6,1.05,-6.8),fr:new V(-6.9,1.2,-13.05),egg:new V(-6.9,1.5,-13.45),bread:new V(-6.9,.9,-13.45),pan:new V(-3.1,1.0,-13.35),knob:new V(-3.15,.8,-13.1),hood:new V(-2.9,2.1,-13.3),sink:new V(-5.3,1.15,-13.6),fruit:new V(-.6,1.0,-13.5)};
const KN={egg:"xom tuxumni",bread:"nonni",fried:"tuxum qovurmasini",apple:"olmani",tomato:"pomidorni"};
const kw=L(0xd9d2c3),kcab=L(0xbcc5cc),ktop=L(0x3b3f45),kmet=L(0x9aa4ad),kwh=L(0xdcdfe0),kpl=L(0xe9e2cc),kpr=L(0x2d5fae),kwell=L(0xc3cbd2,{polygonOffset:true,polygonOffsetFactor:-1});
function kcyl(rt,rb,h,m,x,y,z,sg){const o=new T.Mesh(new T.CylinderGeometry(rt,rb,h,sg||14),m);o.position.set(x,y,z);scene.add(o);return o}
const kcv=cv(128,128),kcx=kcv.getContext("2d");kcx.fillStyle="#c9cfd4";kcx.fillRect(0,0,128,128);kcx.strokeStyle="#8d969d";kcx.lineWidth=3;[[0,0],[64,0],[0,64],[64,64]].forEach(a=>kcx.strokeRect(a[0],a[1],64,64));
box(-3.6,-.15,-10.5,8,.3,7,L(0xdde2e6,{map:tex(kcv,8,7)}));box(-3.6,3.4,-10.5,8.2,.2,7.2,L(0xe9e6df));
box(-7.6,1.7,-10.5,.25,3.4,7.2,kw);box(.4,1.7,-10.5,.25,3.4,7.2,kw);box(-3.6,1.7,-14,8.2,3.4,.25,kw);box(-6.875,1.7,-7,1.5,3.4,.25,kw);
{const kL=new T.PointLight(0xfff0d8,.7,12);kL.position.set(-3.6,3.0,-10.5);scene.add(kL);box(-3.6,3.28,-10.5,1.2,.04,.5,B(0xfff6dd));
 /* deraza */const wp2=new T.Mesh(new T.PlaneGeometry(2,1.2),B(0x8fb8e0));wp2.position.set(-7.46,2.0,-10.4);wp2.rotation.y=Math.PI/2;scene.add(wp2);box(-7.47,2.0,-10.4,.04,.05,2.1,L(0x2a2f35));box(-7.47,2.0,-10.4,.04,1.3,.05,L(0x2a2f35));
 /* qizil gilam, axlat quti */box(-3.6,.01,-10.4,3.2,.02,2.2,L(0x5a3030));kcyl(.18,.15,.5,L(0x4b5560),-.3,.25,-7.7);cols.push({x:-.3,z:-7.7,hw:.2,hd:.2});
 /* muzlatkich */box(-6.9,.95,-13.82,.8,1.9,.04,kwh);box(-7.28,.95,-13.45,.04,1.9,.8,kwh);box(-6.52,.95,-13.45,.04,1.9,.8,kwh);box(-6.9,1.9,-13.45,.8,.04,.8,kwh);box(-6.9,.04,-13.45,.8,.04,.8,kwh);box(-6.9,1.4,-13.45,.72,.02,.7,L(0xdfe9ee));box(-6.9,.8,-13.45,.72,.02,.7,L(0xdfe9ee));cols.push({x:-6.9,z:-13.45,hw:.4,hd:.42});
 box(-6.9,1.43,-13.52,.3,.04,.2,L(0xc9b48a));for(let i=0;i<6;i++){const e=new T.Mesh(new T.SphereGeometry(.026,8,6),L(0xf2e6cf));e.scale.y=1.25;e.position.set(-7.0+(i%3)*.06,1.49,-13.57+(i>2?.07:0));scene.add(e)}
 box(-6.9,.85,-13.5,.32,.1,.16,L(0xd9a85b));box(-6.65,.9,-13.6,.1,.2,.1,L(0x4a78c2));}
