/* ==========================================================
 * Modul: js/kitchen/osh.js
 * Osh: likopcha, retsept, qozon bo'laklari
 * ========================================================== */
/* ---- OSH: likopcha, retsept kartasi, qozondagi bo'laklar ---- */
const TPO=mkPlate(false),TPOm=mkOsh();TPO.add(TPOm);TPO.visible=false;scene.add(TPO);
const hpo=mkPlate(false);hpo.add(mkOsh());hpo.name="posh";KH.add(hpo);
{const c0=cv(512,576),x=c0.getContext("2d");x.fillStyle="#f6f1e3";x.fillRect(0,0,512,576);x.strokeStyle="#8a5a2b";x.lineWidth=8;x.strokeRect(8,8,496,560);x.fillStyle="#8a3b12";x.font="bold 52px sans-serif";x.textAlign="center";x.fillText("OSH (PLOV)",256,76);x.font="22px sans-serif";x.fillStyle="#3a2a1c";x.textAlign="left";
 ["Retsept:","1. Sabzi va piyozni taxtada pichoq","    bilan o'zingiz mayda kesing","2. Qozon qopqog'ini oling, stolga qo'ying","3. Sabzi, piyozni qozonga soling","4. Guruch: pastki shkafdan piyola bilan","5. Suv: kranga kosa tutib, 3 marta","6. Gazni yoqing — taxminan 20 soniya","7. Likopchaga soling, stolga o'tirib yeng"].forEach((t,i)=>{x.font=i?"22px sans-serif":"bold 26px sans-serif";x.fillText(t.replace("kranдан","kran"),30,130+i*48)});
 const rc=new T.Mesh(new T.PlaneGeometry(.55,.62),new T.MeshBasicMaterial({map:tex(c0)}));rc.position.set(-4.0,1.5,-13.866);scene.add(rc)}
const PKIND={carrot:[14,.024,.012,.024,0xe8791e],onion:[14,.022,.008,.022,0xf0e4b0],potato:[12,.025,.016,.025,0xd9b97a],tomato:[12,.024,.01,.024,0xd8392b],guruch:[44,.011,.007,.02,0xf7f0d8],egg:[4,.03,.012,.03,0xfff3c0],un:[16,.01,.006,.01,0xffffff],sugar:[16,.01,.006,.01,0xffffff]};
function potAddViz(k){const d=PKIND[k]||PKIND.un;for(let i=0;i<d[0]&&KT.pi.length<190;i++){const a=Math.random()*6.283,r=Math.sqrt(Math.random())*.115;KT.pi.push({x:Math.cos(a)*r,z:Math.sin(a)*r,sx:d[1]*(.85+Math.random()*.3),sy:d[2],sz:d[3]*(.85+Math.random()*.3),ry:Math.random()*3.14,dy:Math.random()*.012,c:d[4]})}}
function potServe(){const P2=KT.potP;KT.pi.splice(0,Math.ceil(KT.pi.length/Math.max(1,P2)));KT.potP--;if(KT.potP<=0){KT.pot=[];KT.potT=0;KT.water=0;KT.pi=[];KT.dish=""}}
const potLv=()=>KT.potP>0?.975+.07*(KT.potP/4):.958+.03*KT.water+(KT.pot.length?.004:0);
const KPI=new T.InstancedMesh(new T.BoxGeometry(1,1,1),L(0xffffff),200),kd3=new T.Object3D(),kc3=new T.Color();KPI.count=0;KPI.frustumCulled=false;KPI.setColorAt(0,kc3.setHex(0xffffff));KPI.visible=false;scene.add(KPI);
const potInfo=()=>{const n=KT.pot.length;if(KT.potP>0)return(KT.dish==="osh"?"OSH tayyor: ":"taom tayyor: ")+KT.potP+" porsiya ("+(KT.dish==="osh"?"likopcha yoki kosa":"kosa")+" bilan soling)";if(!n&&!KT.water)return"qozon bo'sh — retsept devorda";const has=k=>KT.pot.includes(k),ck=v=>v?"✓":"✗";let s="Osh: sabzi "+ck(has("carrot"))+" piyoz "+ck(has("onion"))+" guruch "+ck(has("guruch"))+" · suv "+KT.water+"/3";if(n>=3&&KT.water>=3)s+=" · "+(KT.gas?"pishmoqda… "+Math.max(0,Math.ceil(20-KT.potT))+" s":"tayyor — gazni yoqing");return s};
const potToast=()=>toast("🥘 Masalliq "+KT.pot.length+"/3 · suv "+KT.water+"/3 kosa"+(KT.pot.length>=3&&KT.water>=3?" — gazni yoqing":""));
const _sd=new V(),_pv=new V(),BLK=[[-3.1,-13.35,.2],[-2.7,-13.35,.22],[-2.7,-13.65,.18]];
