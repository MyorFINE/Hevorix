/* ==========================================================
 * Modul: js/kitchen/kitchen-update.js
 * Oshxona yangilanishi
 * ========================================================== */
function kitchenUpd(dt){KT.dp+=((KT.open?1:0)-KT.dp)*Math.min(1,dt*4);if(window.KDOOR)KDOOR.rotation.y=-1.55*KT.dp;KT.fdp+=((KT.fr?1:0)-KT.fdp)*Math.min(1,dt*4);KFR.rotation.y=1.5*KT.fdp;
 KFL.forEach(f=>{f.visible=KT.gas;if(KT.gas)f.scale.y=.8+Math.random()*.6});KHL.material.emissive.setHex(KT.hood?0xfff3c4:0);
 const q=KT.pan;KEW.visible=KEY.visible=!!q;if(q){const pk=Math.floor(q.t*2);if(pk!==q.pk){q.pk=pk;eggPaint(eX,q.t);eTx.needsUpdate=true;KEY.material.color.copy(yolk(q.t))}}if(q){if(KT.gas){q.t+=dt;if(!q.cooked&&q.t>=14){q.cooked=true;toast("🍳 Tuxum pishdi! Likopchaga soling (likopcha — lavabo yonida)")}if(!q.burnt&&q.t>=40){q.burnt=true;toast("💨 Tuxum kuyib ketdi!")}}
  }
 KT.at+=dt;if(KT.at>60){KT.at=0;if(KT.apples<3)KT.apples++}KAP.forEach((m,i)=>m.visible=i<KT.apples);
 KH.visible=!!KT.item&&!seated&&!LF.sleeping;if(KH.visible){camera.getWorldDirection(fw);rg.set(1,0,0).applyQuaternion(camera.quaternion);KH.position.copy(camera.position).addScaledVector(fw,.5).addScaledVector(rg,.2);KH.position.y-=.2;KH.children.forEach(c=>c.visible=c.name===KT.item)}benchUpd(dt);kitchenUpd2(dt)}
