/* ==========================================================
 * Modul: js/repair/part-operations.js
 * Burash, kabel, tutqich, qism olish/qo'yish qoidalari
 * ========================================================== */
function unscrew(id){BN.sc[id]=0;const c=bcn(id);BN.cont[c]++;BN.done=false;bnSync();toast("🔩 Bolt «"+CN[c]+"» idishiga tushdi ("+BN.cont[c]+")")}
function screwIn(id){const c=bcn(id);let src=c;if(BN.cont[src]<=0)src=["k","a","v"].find(q=>BN.cont[q]>0);if(!src){toast("Idishlarda bolt yo'q");return}
 BN.cont[src]--;BN.sc[id]=1;bnSync();toast("🔩 Bolt mahkamlandi"+(src!==c?" (boshqa idishdan olindi)":""));bnCheck()}
function cabToggle(k){BN.cab[k]=BN.cab[k]?0:1;BN.done=false;bnSync();toast(BN.cab[k]?"🔌 "+CAB[k].lab+" ulandi":"🔌 "+CAB[k].lab+" uzildi");bnCheck()}
function leverToggle(){BN.lever=BN.lever?0:1;BN.done=false;bnSync();toast(BN.lever?"Dasta ko'tarildi — protsessorni olish/qo'yish mumkin":"Dasta tushirildi — protsessor mahkamlandi");bnCheck()}
function toolSwap(k){BN.tool=k;bnSync();toast("🪛 "+(k==="ph"?"Krestovoy otvyorka":"Yassi otvyorka")+" qo'lingizda")}
function bnCheck(){const ok=Object.values(BN.pt).every(p=>p.in)&&SCR.every(s=>BN.sc[s[0]]===1)&&Object.values(BN.cab).every(v=>v)&&!BN.lever&&BN.where!=="hand";if(ok&&!BN.done){BN.done=true;toast("🖥 Kompyuter to'liq yig'ildi! "+(BN.paste==="new"?"Termopasta yangi ✓":"Termopasta eski ⚠"))}}
/* --- qaysi qismni olish / qo'yish mumkin --- */
const sIn=a=>a.some(i=>BN.sc[i]===1),cPl=a=>a.some(k=>BN.cab[k]===1);
function remBlock(k){const P2=BN.pt;
 if(k==="panel")return sIn(["p1","p2"])?"qopqoq 2 ta bolt bilan mahkamlangan — otvyorka bilan burab chiqaring":"";
 if(P2.panel.in)return"avval yon qopqoqni oching";
 if(k==="psu")return sIn(["u1","u2","u3","u4"])?"PSU 4 ta bolt bilan mahkamlangan":cPl(["atx","cpu8","pcie"])?"avval PSU kabellarini uzing":"";
 if(k==="gpu")return sIn(["g1","g2"])?"video karta 2 ta bolt bilan mahkamlangan":cPl(["pcie"])?"avval PCIe quvvat kabelini uzing":"";
 if(k==="cooler")return sIn(["c1","c2","c3","c4"])?"kuller 4 ta bolt bilan mahkamlangan":cPl(["cfan"])?"avval kuller kabelini uzing":"";
 if(k==="cpu")return P2.cooler.in?"avval kullerni oling":!BN.lever?"avval qisqich dastasini ko'taring":"";
 if(k==="mb"){const b=["gpu","ram1","ram2","cooler","cpu"].filter(q=>P2[q].in);if(b.length)return"avval "+b.map(q=>BLAB[q]).join(", ")+" ni oling";if(cPl(["atx","cpu8"]))return"avval 24-pin va 8-pin kabellarni uzing";return sIn(["m1","m2","m3","m4","m5","m6"])?"anakart 6 ta bolt bilan mahkamlangan":""}
 if(k==="fan1")return sIn(["f1_1","f1_2","f1_3","f1_4"])?"ventilyator 4 ta bolt bilan mahkamlangan":"";
 if(k==="fan2")return sIn(["f2_1","f2_2","f2_3","f2_4"])?"ventilyator 4 ta bolt bilan mahkamlangan":"";return""}
function plBlock(k){const P2=BN.pt;
 if(k==="gpu"||k==="ram1"||k==="ram2")return P2.mb.in?"":"avval anakartni o'rnating";
 if(k==="cpu")return !P2.mb.in?"avval anakartni o'rnating":!BN.lever?"avval qisqich dastasini ko'taring":"";
 if(k==="cooler")return !P2.mb.in?"avval anakartni o'rnating":!P2.cpu.in?"avval protsessorni o'rnating":BN.lever?"avval qisqich dastasini tushiring":"";return""}
