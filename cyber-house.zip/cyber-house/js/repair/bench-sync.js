/* ==========================================================
 * Modul: js/repair/bench-sync.js
 * Holatni ko'rinishga yozish
 * ========================================================== */
/* --- holatni ko'rinishga yozish --- */
const BLAB={panel:"yon qopqoq",psu:"blok pitaniya",gpu:"video karta",ram1:"RAM (1)",ram2:"RAM (2)",cooler:"kuller",cpu:"protsessor",mb:"anakart",fan1:"ventilyator (1)",fan2:"ventilyator (2)"},CN={k:"Korpus",a:"Anakart",v:"Video karta"};
function bnSync(){
 SCR.forEach(s=>{const inn=BN.sc[s[0]]===1,pi=BN.pt[s[1]].in;BN.scm[s[0]].visible=inn&&pi;BN.hole[s[0]].visible=!inn&&pi});
 for(const k in CAB){const m=BN.cabm[k],p=BN.cab[k]===1;m[0].visible=m[1].visible=p;m[2].visible=m[3].visible=!p}
 BN.lev.rotation.z=BN.lever?-1.3:0;
 const cpuIn=BN.pt.cpu.in,clIn=BN.pt.cooler.in;BN.pasteM.visible=BN.paste!=="none"&&!(clIn&&cpuIn&&BN.pt.cooler.at==="case");
 if(BN.paste==="old"){BN.pasteM.scale.set(.014,.0007,.014);BN.pasteM.material.color.setHex(0x5b5f63)}else if(BN.paste==="new"){BN.pasteM.scale.set(.011,.0035,.011);BN.pasteM.material.color.setHex(0xd2d7dc)}
 mbg.children.forEach(c=>{if(c.name==="pins")c.visible=!cpuIn});
 for(const k in TRM){const n=BN.cont[k];TRM[k].forEach((m,i)=>m.visible=i<Math.min(16,n))}
 for(const k in DRM)DRM[k].visible=BN.tool!==k;
  STANDS.forEach(s=>s.visible=BN.where==="table"&&!!BN.tilt)}
bnSync();
