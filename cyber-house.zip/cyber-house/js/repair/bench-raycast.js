/* ==========================================================
 * Modul: js/repair/bench-raycast.js
 * Nur bo'yicha tanlash
 * ========================================================== */
/* --- yordamchi: nurga qarab tanlash --- */
const _bv1=new V(),_bv2=new V(),_bv3=new V();
function rayN(id,pf,r){const p=pf();camera.getWorldDirection(_bv1);_bv2.copy(p).sub(camera.position);const t=_bv2.dot(_bv1);if(t<.08||Math.hypot(p.x-camera.position.x,p.z-camera.position.z)>1.7)return 9;_bv3.copy(_bv1).multiplyScalar(t);const d=_bv2.sub(_bv3).length();return d<=r?d/r:9}
function tblHit(){camera.getWorldDirection(_bv1);if(_bv1.y>-.02)return 9;const t=(BTOP-camera.position.y)/_bv1.y;if(t<0||t>1.9)return 9;_bv2.set(camera.position.x+_bv1.x*t,BTOP,camera.position.z+_bv1.z*t);BG.worldToLocal(_bv2);return(_bv2.x>-3.45&&_bv2.x<-.85&&_bv2.z>5.95&&_bv2.z<6.75)?.95:9}
const rcw=(x,y,z)=>RC.localToWorld(new V(x,y,z));
