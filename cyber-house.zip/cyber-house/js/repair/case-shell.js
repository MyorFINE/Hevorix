/* ==========================================================
 * Modul: js/repair/case-shell.js
 * Yonboshlab yotgan korpus va qism ro'yxatga olish
 * ========================================================== */
/* --- korpus (yonboshlab yotgan): x = tower balandligi, y = yon tomon (yuqori), z = chuqurlik --- */
const RC=new T.Group();RC.name="b_case";BN.root.add(RC);RC.position.set(-2.35,BTOP+.006,6.35);RC.visible=false;
{const S0=0x2a2f36;bbx(RC,.5,.006,.45,S0,0,-.003,0);bbx(RC,.5,.21,.01,S0,0,.105,-.22);bbx(RC,.5,.21,.01,0x23272d,0,.105,.22);bbx(RC,.01,.21,.45,S0,-.245,.105,0);bbx(RC,.01,.21,.45,S0,.245,.105,0)}
const STANDS=[-1,1].map(q=>{const m=new T.Mesh(new T.BoxGeometry(.05,1,.05),L(0x3a3f47));m.visible=false;BN.root.add(m);return m});
const PSUO=new V(-.195,.075,-.1375),CPUO=new V(.125,.0255,-.09);
function regPart(k,g,ip,lab,tab,tr,hs,hr,cOff,rad){g.position.copy(ip);RC.add(g);g.name="b_"+k;BN.pt[k]={g,ip,in:true,at:"case",lab,tab,tr,hs,hr,cOff,rad}}
