/* ==========================================================
 * Modul: js/repair/motherboard.js
 * Anakart
 * ========================================================== */
/* anakart */
const MBO=new V(.0875,.016,-.083),mbg=new T.Group();
{const g=mbg,mx=x=>x-MBO.x,mz=z=>z-MBO.z;bbx(g,.305,.004,.244,0x14463a,0,-.002,0);
 bbx(g,.009,.008,.15,0x1a1d21,mx(0),.004,mz(-.105));
 bbx(g,.06,.004,.06,0x2c3036,mx(.125),.002,mz(-.09));const pins=bbx(g,.036,.0006,.036,0xc9a24a,mx(.125),.0043,mz(-.09));pins.name="pins";
 [-.005,.007].forEach(z=>{bbx(g,.14,.008,.006,0x1a1d21,mx(.125),.004,mz(z));[-1,1].forEach(q=>bbx(g,.006,.01,.006,0x8a8f95,mx(.125)+q*.07,.005,mz(z)))});
 bbx(g,.05,.02,.012,0xe8e8e8,mx(.13),.01,mz(.028));bbx(g,.012,.02,.03,0xe8e8e8,mx(.228),.01,mz(-.13));bbx(g,.01,.007,.014,0xe8e8e8,mx(.192),.0035,mz(-.035));
 bbx(g,.07,.03,.025,0x5d646c,mx(.17),.015,mz(-.175));bbx(g,.11,.03,.008,0x9aa1a8,mx(.17),.015,mz(-.207));
 const lv=new T.Group();lv.position.set(mx(.1555),.0055,mz(-.06));bbx(lv,.05,.003,.003,0xaeb4ba,-.025,0,0);g.add(lv);BN.lev=lv}
regPart("mb",mbg,MBO,"anakart",[-1.55,6.3],[0,0,0],.7,[.3,.6,0],new V(0,0,0),.11);
