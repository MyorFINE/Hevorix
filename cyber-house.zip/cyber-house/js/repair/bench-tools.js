/* ==========================================================
 * Modul: js/repair/bench-tools.js
 * Otvyorkalar, pasta, idishlar
 * ========================================================== */
/* --- otvyorkalar, pasta, idishlar --- */
function mkDriver(kind,dir){const g=new T.Group(),h=kind==="ph"?0xd8362b:0x2b6bd6;g.name=kind;
 bcy(g,.012,.012,.09,h,0,0,-.05*dir,"z");bcy(g,.0135,.0135,.012,0x15171a,0,0,-.085*dir,"z");bcy(g,.003,.003,.1,0xaeb4ba,0,0,.05*dir,"z");
 if(kind==="ph"){bbx(g,.007,.0012,.004,0x888e94,0,0,.101*dir);bbx(g,.0012,.007,.004,0x888e94,0,0,.101*dir)}else bbx(g,.008,.0016,.004,0x888e94,0,0,.101*dir);return g}
const DRS={ph:[-3.3,6.2],flat:[-3.22,6.2]},DRM={};
for(const k in DRS){const g=mkDriver(k,1);g.position.set(DRS[k][0],BTOP+.0125,DRS[k][1]);BN.root.add(g);DRM[k]=g}
const TOOLG=new T.Group();{const a=mkDriver("ph",-1),b=mkDriver("flat",-1);[a,b].forEach(m=>{m.position.set(-.18,-.2,-.5);m.rotation.set(.35,.3,0)});TOOLG.add(a,b)}TOOLG.visible=false;scene.add(TOOLG);
const PASTE=new T.Group();{PASTE.name="b_paste";bcy(PASTE,.009,.009,.075,0xf2f2f2,0,0,0,"z");bcy(PASTE,.007,.007,.025,0x15171a,0,0,-.048,"z");bcy(PASTE,.004,.0025,.02,0xc9ced3,0,0,.047,"z");bcy(PASTE,.0095,.0095,.02,0xd8362b,0,0,.0,"z")}
PASTE.position.set(-3.1,BTOP+.0095,6.2);BN.root.add(PASTE);const PSPOT=[-3.1,6.2];
const TRS={k:[-3.3,6.62,0xd8362b,"Korpus"],a:[-3.12,6.62,0x2b6bd6,"Anakart"],v:[-2.94,6.62,0x2fa35a,"Video karta"]},TRM={},SPG=new T.CylinderGeometry(.0035,.0035,.009,6),SPM=L(0xc0c6cc);
for(const k in TRS){const t=TRS[k],g=new T.Group();bcy(g,.055,.05,.004,0x24282d,0,.002,0);bcy(g,.06,.052,.024,0x30353b,0,.014,0,"y",{side:T.DoubleSide});const rm=new T.Mesh(new T.TorusGeometry(.06,.003,6,20),L(t[2]));rm.rotation.x=Math.PI/2;rm.position.y=.026;g.add(rm);
 g.position.set(t[0],BTOP,t[1]);BN.root.add(g);const pile=[];for(let i=0;i<16;i++){const m=new T.Mesh(SPG,SPM),a=i*2.4,r=.034*Math.sqrt((i+1)/16);m.position.set(Math.cos(a)*r,.0075+(i%3)*.002,Math.sin(a)*r);m.rotation.set(Math.random()*3,Math.random()*3,Math.random()*3);m.visible=false;g.add(m);pile.push(m)}TRM[k]=pile}
