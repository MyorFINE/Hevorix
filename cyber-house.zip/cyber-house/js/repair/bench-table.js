/* ==========================================================
 * Modul: js/repair/bench-table.js
 * Ta'mirlash stoli modeli
 * ========================================================== */
/* --- stol --- */
bbx(BN.root,2.6,.04,.8,0x8a6a45,-2.15,.78,6.35);
[[-3.4,6],[-.9,6],[-3.4,6.67],[-.9,6.67]].forEach(a=>bbx(BN.root,.06,.76,.06,0x4a3a2a,a[0],.38,a[1]));
bbx(BN.root,2.5,.03,.7,0x6b5238,-2.15,.25,6.33);bbx(BN.root,2.5,.06,.03,0x6b5238,-2.15,.73,6.02);bbx(BN.root,2.5,.06,.03,0x6b5238,-2.15,.73,6.65);
{const c0=cv(1024,400),x=c0.getContext("2d");x.fillStyle="#1d2a36";x.fillRect(0,0,1024,400);x.strokeStyle="#6fb1e0";x.lineWidth=8;x.strokeRect(8,8,1008,384);x.fillStyle="#7fd4ff";x.font="bold 54px sans-serif";x.textAlign="center";x.fillText("ISH STOLI — KOMPYUTER TA'MIRI",512,80);x.textAlign="left";x.fillStyle="#e8f3fb";
 ["1. Korpusni yerdan oling va stolga qo'ying","2. Otvyorka oling, qopqoq boltlarini burab chiqaring","3. Kabellarni uzing, qismlarni bittalab ajrating","4. Protsessorga termopasta surting","5. Teskari tartibda yig'ing, boltlarni mahkamlang"].forEach((t,i)=>{x.font="36px sans-serif";x.fillText(t,44,150+i*54)});
 const sg=new T.Mesh(new T.PlaneGeometry(1.5,.586),new T.MeshBasicMaterial({map:tex(c0)}));sg.rotation.y=Math.PI;sg.position.set(-2.15,1.75,6.765);BN.root.add(sg)}
