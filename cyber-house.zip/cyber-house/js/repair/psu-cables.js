/* ==========================================================
 * Modul: js/repair/psu-cables.js
 * Blok pitaniya va kabellar
 * ========================================================== */
/* blok pitaniya + kabellar */
const psg=new T.Group();{bbx(psg,.086,.15,.155,0x30343a,0,0,0);bbx(psg,.07,.001,.1,0xd8362b,0,.0755,0);bcy(psg,.05,.05,.001,0x101214,0,.0761,0,"y")}
regPart("psu",psg,PSUO,"blok pitaniya (PSU)",[-1.2,6.1],[0,0,0],.9,[.3,.6,0],new V(0,0,0),.07);
function bnTube(par,orig,pts,r,col){const c=new T.CatmullRomCurve3(pts.map(p=>new V(p[0]-orig.x,p[1]-orig.y,p[2]-orig.z)));const m=new T.Mesh(new T.TubeGeometry(c,Math.max(10,pts.length*8),r,6,false),L(col));par.add(m);return m}
const CAB={
 atx:{own:"psu",need:["mb"],lab:"24-pin anakart kabeli",r:.0085,pl:[[-.195,.05,-.062],[-.19,.05,.01],[-.14,.05,.085],[0,.05,.09],[.13,.05,.085],[.13,.04,.05],[.13,.034,.03]],un:[[-.195,.05,-.062],[-.19,.03,0],[-.16,.012,.05],[-.15,.011,.075]],pp:[.13,.036,.028,.05,.016,.014],up:[-.15,.011,.078,.05,.016,.014],sock:[.13,.03,.028]},
 cpu8:{own:"psu",need:["mb"],lab:"protsessor 8-pin kabeli",r:.005,pl:[[-.195,.11,-.062],[-.195,.13,-.035],[-.18,.17,-.05],[-.1,.18,-.17],[.05,.18,-.195],[.2,.17,-.2],[.228,.1,-.19],[.228,.04,-.14],[.228,.033,-.13]],un:[[-.195,.11,-.062],[-.19,.08,0],[-.2,.02,.09],[-.2,.011,.15]],pp:[.228,.042,-.13,.012,.016,.03],up:[-.2,.011,.152,.02,.014,.03],sock:[.228,.035,-.13]},
 pcie:{own:"psu",need:["gpu"],lab:"video karta quvvat kabeli (PCIe)",r:.005,pl:[[-.195,.09,-.062],[-.18,.14,-.03],[-.1,.175,0],[-.04,.162,-.005],[-.02,.156,-.015]],un:[[-.195,.09,-.062],[-.19,.06,0],[-.16,.02,.06],[-.1,.011,.12]],pp:[-.02,.154,-.015,.02,.014,.036],up:[-.1,.011,.123,.02,.014,.036],sock:[-.02,.152,-.015]},
 cfan:{own:"cooler",need:["cooler"],lab:"kuller ventilyator kabeli",r:.0016,pl:[[.186,.052,-.0655],[.2,.04,-.055],[.195,.026,-.04],[.192,.0215,-.035]],un:[[.186,.052,-.0655],[.2,.05,-.075],[.205,.04,-.085]],pp:[.192,.022,-.035,.01,.007,.012],up:[.205,.038,-.088,.01,.007,.012],sock:[.192,.0215,-.035]}};
for(const k in CAB){const c=CAB[k],o=c.own==="psu"?PSUO:CPUO,par=BN.pt[c.own].g,col=k==="atx"?0x1b1d20:k==="cfan"?0x15171a:0x25282c;
 const a=bnTube(par,o,c.pl,c.r,col),b=bnTube(par,o,c.un,c.r,col),p1=bbx(par,c.pp[3],c.pp[4],c.pp[5],0x101214,c.pp[0]-o.x,c.pp[1]-o.y,c.pp[2]-o.z),p2=bbx(par,c.up[3],c.up[4],c.up[5],0x101214,c.up[0]-o.x,c.up[1]-o.y,c.up[2]-o.z);
 BN.cab[k]=1;BN.cabm[k]=[a,p1,b,p2]}
