/* ==========================================================
 * Modul: js/main/loop.js
 * Asosiy o'yin sikli
 * ========================================================== */
/* ---------- asosiy sikl ---------- */
let qOk=0,htT=0,prev=0,fAcc=0,fN=0,rackT=0,hue=0;const tmpC=new T.Color(),fw=new T.Vector3(),rg=new T.Vector3();
function loop(now){
 requestAnimationFrame(loop);const raw=(now-prev)/1000;prev=now;if(raw>1)return;const dt=Math.min(raw,.05);
 fAcc+=raw;fN++;if(fAcc>1.2){const fps=fN/fAcc;if(qMode===0){if(fps<(lowEnd?36:44)&&pr>.45){pr=Math.max(.45,pr*.82);applyRes();qOk=0}else if(fps>57&&pr<cap){if(++qOk>=4){pr=Math.min(cap,pr*1.08);applyRes();qOk=0}}else qOk=0}fAcc=fN=0}
 updatePlayer(dt);updateCam(dt);window.gfxTick(dt,now);ROOMG.visible=!(P.z<-7.45&&KT.dp<.04&&!seated);
 if(S.hold){camera.getWorldDirection(fw);rg.set(1,0,0).applyQuaternion(camera.quaternion);hand.copy(camera.position).addScaledVector(fw,.55).addScaledVector(rg,.26);hand.y-=.3;hand.y=Math.max(.06,hand.y);hand.x=Math.max(-5.8,Math.min(5.8,hand.x));hand.z=Math.max(-6.8,Math.min(6.8,hand.z));for(const a of CB)colBox(hand,a)}
 cable(dt);flashUpd(dt);tick2();simTick(now);lifeTick(dt,now);atkTick(dt);cupUpd();kitchenUpd(dt);noteUpd();dcupUpd();coachTick();scrollTick(dt);monTick(dt);
 if(now-htT>110){htT=now;const h=hintText();$("cross").className=hintText.act?"on":"";$("mE").className=hintText.act?"on":"";if(h!==lastHint){lastHint=h;$("hint").textContent=h;$("hint").style.display=h?"block":"none"}}
 const on=S.on,disp=on&&S.mplug,tgt=disp?(S.stage===3?.9:.55):(m2Sig()?.7:0);mLight.intensity+=(tgt-mLight.intensity)*Math.min(1,dt*5);
 mled.material.color.setHex(disp?0x1fe39a:0xff9a1f);pb.material.color.setHex(on?0x1fe39a:0xff3b3b);
 if(on){hue=(hue+dt*.4)%1;fans.forEach((f,i)=>{f.rotation.z+=dt*(9+i*2);f.material.color.setHSL((hue+i*.18)%1,1,.55)})}else fans.forEach(f=>f.material.color.setHex(0x111111));
 rackT-=dt;if(rackT<0){rackT=.3;for(let i=0;i<20;i++){const r=Math.random();rl.setColorAt(i,tmpC.setHex(SEC.srvAlert?(r<.7?0xff2020:0x3a0808):(r<.55?0x00ff88:r<.8?0xffaa22:0x113322)))}rl.instanceColor.needsUpdate=true}
 mouse.position.x=.85+(cur.x/vwNow()-.5)*.2;mouse.position.z=-3.0+(cur.y/H-.5)*.14;
 const m=new Date().getMinutes();if(m!==lastMin){lastMin=m;dirty=true}
 if(S.on&&(S.stage===1||S.stage===4))dirty=true;
 if(seated&&S.on&&S.stage===3&&((now/500)|0)!==lastDraw){lastDraw=(now/500)|0;dirty=true}
 if(dirty){if(S.on||!draw.off){draw();draw.off=!S.on}blit();dirty=false}
 renderer.render(scene,camera)}
requestAnimationFrame(loop);
