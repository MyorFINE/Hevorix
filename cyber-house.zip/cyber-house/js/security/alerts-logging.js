/* ==========================================================
 * Modul: js/security/alerts-logging.js
 * Sirena, ogohlantirish, loglar
 * ========================================================== */
function siren(good){if(SET.mute)return;try{AC=AC||new(window.AudioContext||window.webkitAudioContext)();const t0=AC.currentTime,fq=good?[660,880]:[880,520,880,520];fq.forEach((f,i)=>{const o=AC.createOscillator(),g=AC.createGain();o.type=good?"sine":"square";o.frequency.value=f;g.gain.value=SET.vol/100*(good?.05:.04);o.connect(g);g.connect(AC.destination);o.start(t0+i*.16);o.stop(t0+i*.16+.14)})}catch(e){}}
function alertMsg(t,good){if(!good||!(seated&&S.on&&S.stage===3))return;const e=$("alert");e.textContent=t;e.className=good?"good":"";e.style.display="block";clearTimeout(alertMsg.t);alertMsg.t=setTimeout(()=>e.style.display="none",5200);siren(good)}
function asRoot(fn){const sv=ASROOT;ASROOT=true;try{return fn()}finally{ASROOT=sv}}
function uiTry(fn){try{const r=fn();if(r)toast(String(r).replace(/\n+/g," · ").slice(0,120))}catch(e){toast(e.message)}dirty=true}
function logLine(f,t){asRoot(()=>{try{F.wr(f,new Date().toTimeString().slice(0,8)+" "+t+"\n",true)}catch(e){}})}
function logAtk(a,ev){const ty=ATYP[a.ty],ip=TG[a.tg].ip();logLine("/var/log/ids.log","[IDS] "+ev.toUpperCase()+" "+ty.n+" src="+a.ip+" dst="+ip+" sev="+ty.sev);
 if(a.ty==="ssh"){if(ev==="start")for(let i=0;i<3;i++)logLine("/var/log/auth.log","sshd[731]: Failed password for root from "+a.ip+" port "+(40000+(Math.random()*20000|0))+" ssh2");if(ev==="breached")logLine("/var/log/auth.log","sshd[731]: Accepted password for root from "+a.ip+" port 51822 ssh2")}
 if(a.ty==="web"&&ev==="start")logLine("/var/log/syslog","apache2[880]: suspicious request from "+a.ip+" GET /cgi-bin/.%2e/%2e%2e/bin/sh")}
function notify(a){}
