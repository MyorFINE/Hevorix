/* ==========================================================
 * Modul: js/graphics/graphics-plus.js
 * Qo'shimcha grafika
 * ========================================================== */
/* ---------- grafika+ ---------- */
let gMin=-1,gRt=0;const gLed=[];
{
 for(let i=0;i<24;i++){fx.strokeStyle="rgba(255,255,255,.05)";fx.lineWidth=1;fx.beginPath();const a=Math.random()*256,b=Math.random()*256;fx.moveTo(a,b);fx.lineTo(a+Math.random()*50-25,b+Math.random()*50-25);fx.stroke()}
 fx.fillStyle="rgba(255,255,255,.035)";fx.fillRect(0,0,128,128);fx.fillRect(128,128,128,128);
 wx.fillStyle="#222b35";[[8,8],[116,8],[8,244],[116,244],[136,8],[244,8],[136,244],[244,244]].forEach(p=>wx.fillRect(p[0],p[1],4,4));
 wx.strokeStyle="rgba(255,255,255,.08)";wx.lineWidth=2;wx.strokeRect(4,4,120,248);wx.strokeRect(132,4,120,248);
 /* soyalar (AO) */
 const bc2=cv(128,128),b2=bc2.getContext("2d"),g=b2.createRadialGradient(64,64,4,64,64,62);g.addColorStop(0,"rgba(0,0,0,.7)");g.addColorStop(1,"rgba(0,0,0,0)");b2.fillStyle=g;b2.fillRect(0,0,128,128);
 const bm=new T.MeshBasicMaterial({map:tex(bc2),transparent:true,depthWrite:false});
 [[0,-3.3,4.6,2.8],[0,-2.2,1.2,1.2],[1,-3.0,1,1.2],[-5.2,-5.6,1.7,1.9],[-4.7,-1.2,1.6,1.7],[4.6,-6,1.5,1.5],[-4.9,3.2,.8,.8]].forEach(a=>{const m=new T.Mesh(new T.PlaneGeometry(a[2],a[3]),bm);m.rotation.x=-Math.PI/2;m.position.set(a[0],.012,a[1]);m.renderOrder=2;scene.add(m)});
 const ac=cv(4,64),a2=ac.getContext("2d"),ag=a2.createLinearGradient(0,0,0,64);ag.addColorStop(0,"rgba(0,0,0,.55)");ag.addColorStop(1,"rgba(0,0,0,0)");a2.fillStyle=ag;a2.fillRect(0,0,4,64);
 const am=new T.MeshBasicMaterial({map:tex(ac),transparent:true,depthWrite:false});
 [[0,-6.42,12,0],[0,6.42,12,Math.PI],[-5.42,0,14,Math.PI/2],[5.42,0,14,-Math.PI/2]].forEach(a=>{const m=new T.Mesh(new T.PlaneGeometry(a[2],.9),am);m.rotation.x=-Math.PI/2;m.rotation.z=a[3];m.position.set(a[0],.011,a[1]);m.renderOrder=1;scene.add(m)});
 /* gilam */
 const rc2=cv(256,180),r2=rc2.getContext("2d");r2.fillStyle="#1b2a42";r2.fillRect(0,0,256,180);r2.strokeStyle="#35598a";r2.lineWidth=4;r2.strokeRect(8,8,240,164);r2.lineWidth=2;r2.strokeRect(18,18,220,144);
 for(let i=0;i<9;i++){r2.beginPath();r2.moveTo(28+i*25,90);r2.lineTo(40+i*25,50);r2.lineTo(52+i*25,90);r2.lineTo(40+i*25,130);r2.closePath();r2.strokeStyle="#2a4670";r2.stroke()}
 const rug=new T.Mesh(new T.PlaneGeometry(3.4,2.4),L(0xffffff,{map:tex(rc2)}));rug.rotation.x=-Math.PI/2;rug.position.set(0,.008,-2.9);scene.add(rug);
 /* eshik, EXIT, soat */
 box(-4.2,1.15,-6.9,.1,2.3,.3,L(0x141a21));box(-3.0,1.15,-6.9,.1,2.3,.3,L(0x141a21));
 {const g=new T.Group();g.position.set(-4.15,0,-6.82);scene.add(g);const a=(w,h,d,x,y,z,m)=>{const o=new T.Mesh(new T.BoxGeometry(w,h,d),m);o.position.set(x,y,z);g.add(o)};a(1.1,2.2,.06,.55,1.1,0,L(0x2c3644));a(.16,.04,.05,.95,1.05,.05,L(0xd9dee3));a(.16,.04,.05,.95,1.05,-.05,L(0xd9dee3));a(.05,.2,.02,.95,1.05,.035,L(0x2b3036));a(.05,.2,.02,.95,1.05,-.035,L(0x2b3036));a(.3,.5,.01,.55,1.7,.035,B(0x1d3a4f));window.KDOOR=g}
 const ec=cv(128,48),e2=ec.getContext("2d");e2.fillStyle="#06140d";e2.fillRect(0,0,128,48);e2.fillStyle="#2dff88";e2.font="bold 34px monospace";e2.textAlign="center";e2.fillText("EXIT",64,37);
 const ex=new T.Mesh(new T.PlaneGeometry(.45,.17),B(0xffffff));ex.material.map=tex(ec);ex.position.set(-3.6,2.5,-6.78);scene.add(ex);
 const clk=cv(128,128),cx2=clk.getContext("2d"),clt=tex(clk);
 const cm2=new T.Mesh(new T.CircleGeometry(.3,28),B(0xffffff));cm2.material.map=clt;cm2.position.set(4.2,3.1,-6.84);scene.add(cm2);
 const cr=new T.Mesh(new T.RingGeometry(.3,.34,28),B(0x14181d));cr.position.set(4.2,3.1,-6.838);scene.add(cr);
 function drawClock(){const d=new Date(),m=d.getMinutes(),h=d.getHours()%12,x=cx2;x.fillStyle="#e9eef3";x.fillRect(0,0,128,128);x.strokeStyle="#222";x.lineCap="round";
  for(let i=0;i<12;i++){const a=i*Math.PI/6;x.lineWidth=i%3?2:4;x.beginPath();x.moveTo(64+Math.sin(a)*52,64-Math.cos(a)*52);x.lineTo(64+Math.sin(a)*60,64-Math.cos(a)*60);x.stroke()}
  const hd=(a,l,w)=>{x.lineWidth=w;x.beginPath();x.moveTo(64,64);x.lineTo(64+Math.sin(a)*l,64-Math.cos(a)*l);x.stroke()};hd((h+m/60)*Math.PI/6,30,5);hd(m*Math.PI/30,46,3);clt.needsUpdate=true}
 /* shift quvurlari, ventilyatsiya */
 const pm2=L(0x59636e);[[4.3,-6.4,.07],[4.2,-6.15,.04]].forEach(a=>{const m=new T.Mesh(new T.CylinderGeometry(a[2],a[2],11.6,8),pm2);m.rotation.z=Math.PI/2;m.position.set(0,a[0],a[1]);scene.add(m)});
 box(3.8,4.37,3.2,1.2,.06,.8,L(0x1a1f26));for(let i=0;i<5;i++)box(3.8,4.33,2.9+i*.15,1.1,.02,.04,L(0x07090c));
 /* o’simlik */
 const pot=new T.Mesh(new T.CylinderGeometry(.17,.12,.3,10),L(0x8a4b32));pot.position.set(-4.9,.15,3.2);scene.add(pot);
 for(let i=0;i<9;i++){const a=i*2.4,l=new T.Mesh(new T.ConeGeometry(.05,.5,4),L(i%2?0x2f8f4e:0x3aa85c));l.position.set(-4.9+Math.sin(a)*.1,.55,3.2+Math.cos(a)*.1);l.rotation.set(Math.cos(a)*.6,0,-Math.sin(a)*.6);scene.add(l)}
 cols.push({x:-4.9,z:3.2,hw:.18,hd:.18});
 /* stol detallari */
 [-.72,.72].forEach(x=>{box(x,1.04,-3.85,.14,.28,.16,L(0x15191e));const w=new T.Mesh(new T.CircleGeometry(.045,12),B(0x2a3138));w.position.set(x,1.0,-3.769);scene.add(w);const t=new T.Mesh(new T.CircleGeometry(.018,10),B(0x3a444d));t.position.set(x,1.11,-3.769);scene.add(t)});
 
 box(1.05,.92,-3.55,.26,.04,.19,L(0x3b5b9a));box(1.05,.9575,-3.55,.24,.035,.18,L(0x9a3b3b));
 /* rak va router */
 for(let i=0;i<5;i++)box(-4.785,.5+i*.32,-5.6,.012,.05,.66,L(0x07090c));
 box(-5.2,2.03,-5.6,.42,.06,.3,L(0x20262d));
 for(let i=0;i<4;i++){const a=new T.Mesh(new T.BoxGeometry(.012,.22,.012),L(0x111111));a.position.set(-5.38+i*.12,2.17,-5.7);scene.add(a);const l=new T.Mesh(new T.BoxGeometry(.015,.015,.015),B(0x2dff88));l.position.set(-5.34+i*.07,2.04,-5.44);scene.add(l);gLed.push(l)}
 /* stul detallari */
 box(.3,.74,-2.2,.04,.04,.35,L(0x1f262d));box(-.3,.74,-2.2,.04,.04,.35,L(0x1f262d));box(0,1.3,-1.93,.3,.14,.06,L(0x2b3640));
 [[.33,-2.2],[-.33,-2.2],[0,-1.87],[0,-2.53]].forEach(a=>box(a[0],.025,a[1],.06,.05,.06,L(0x111111)));
 /* klaviatura harflari */
 const kc=cv(560,144),k2=kc.getContext("2d");k2.fillStyle="#9fd0e8";k2.font="bold 15px monospace";k2.textAlign="center";k2.textBaseline="middle";
 [["Es"].concat("1234567890-=".split(""),["⌫"]),["Tb"].concat("QWERTYUIOP[]\\".split("")),["Cp"].concat("ASDFGHJKL;'".split(""),["↵"]),["Ct","⇧"].concat("ZXCVBNM,./".split(""),["▲","Fn"])].forEach((r,i)=>r.forEach((s,j)=>k2.fillText(s,j*40+20,i*36+19)));
 const kp=new T.Mesh(new T.PlaneGeometry(1.078,.28),new T.MeshBasicMaterial({map:tex(kc),transparent:true,opacity:.8,depthWrite:false}));kp.rotation.x=-Math.PI/2;kp.position.set(0,.9413,-2.945);scene.add(kp);
 /* monitor oynasi (yaltiroq) */
 const gc=cv(64,64),g3=gc.getContext("2d"),gg=g3.createLinearGradient(0,0,64,64);gg.addColorStop(0,"rgba(255,255,255,.16)");gg.addColorStop(.45,"rgba(255,255,255,.02)");gg.addColorStop(1,"rgba(255,255,255,0)");g3.fillStyle=gg;g3.fillRect(0,0,64,64);
 const gl=new T.Mesh(new T.PlaneGeometry(.96,.54),new T.MeshBasicMaterial({map:tex(gc),transparent:true,depthWrite:false,blending:T.AdditiveBlending}));gl.position.set(0,1.3,-3.78);scene.add(gl);
 const wcm=new T.Mesh(new T.CircleGeometry(.009,8),B(0x2a4a5a));wcm.position.set(0,1.585,-3.783);scene.add(wcm);
 const rlg=new T.PointLight(0x3d7bff,.7,4.5);rlg.position.set(-4.4,1.2,-5.6);scene.add(rlg);
 window.gfxTick=function(dt,now){const m=new Date().getMinutes();if(m!==gMin){gMin=m;drawClock()}gRt-=dt;if(gRt<0){gRt=.18;gLed.forEach(l=>l.material.color.setHex(Math.random()>.35?0x2dff88:0x063018))}};
}
