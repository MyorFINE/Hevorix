/* Durak (podkidnoy): qoidalar + bot. window.TCDurak. Qoidalar server (app/games/durak_engine.py) bilan bir xil.
   Karta: daraja ("6789TJQKA") + mast ("SHDC"), masalan "TH" = ♥10. Harakat: {t:"atk",c} {t:"def",c,i} {t:"take"} {t:"pass"}. */
(function (root) {
  "use strict";
  const RANKS = "6789TJQKA", SUITS = "SHDC", HAND = 6;
  const rank = c => RANKS.indexOf(c[0]);
  // Pagon: durak qo'lida 1 ta oltilik (6) qolsa — 1 pagon, 2 va undan ko'p bo'lsa — 2 pagon (server bilan bir xil)
  const pagonOf = hand => Math.min(2, hand.filter(c => c[0] === "6").length);
  const fullDeck = () => { const d = []; for (const s of SUITS) for (const r of RANKS) d.push(r + s); return d; };
  const shuffle = a => { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };

  class State {
    constructor(n, deck) {
      if (!(n >= 2 && n <= 4)) throw new Error("O'yinchilar soni 2 dan 4 gacha");
      this.n = n; this.deck = deck ? deck.slice() : shuffle(fullDeck());
      this.hands = Array.from({length: n}, () => []);
      for (let k = 0; k < HAND; k++) for (let i = 0; i < n; i++) this.hands[i].push(this.deck.pop());
      this.trumpCard = this.deck[0]; this.trump = this.trumpCard[1];
      this.out = new Array(n).fill(false); this.finish = []; this.discard = 0; this.over = null;
      this.gone = new Set();                              // bito bo'lib o'yindan chiqqan kartalar (bot hisoblab boradi)
      this.known = Array.from({length: n}, () => new Set());   // oshkor bo'lgan (olingan) kartalar: kimning qo'lida ekani ma'lum
      let best = 99, first = 0;
      this.hands.forEach((h, i) => h.forEach(c => { if (c[1] === this.trump && rank(c) < best) { best = rank(c); first = i; } }));
      this.att = first; this.dfn = this._next(first);
      this._startRound();
    }
    _next(seat) { let s = (seat + 1) % this.n; while (this.out[s] && s !== seat) s = (s + 1) % this.n; return s; }
    _startRound() { this.table = []; this.phase = "attack"; this.passed = new Set(); this.cap = Math.min(HAND, this.hands[this.dfn].length); this.turn = this.att; }
    beats(att, c) { return c[1] === att[1] ? rank(c) > rank(att) : (c[1] === this.trump && att[1] !== this.trump); }
    _unbeaten() { const o = []; this.table.forEach((p, i) => { if (p[1] == null) o.push(i); }); return o; }
    _attackers() { const o = []; let s = this.att; for (let k = 0; k < this.n; k++) { if (s !== this.dfn && !this.out[s]) o.push(s); s = (s + 1) % this.n; } return o; }
    throwable(seat) {
      if (this.over || this.out[seat] || seat === this.dfn) return [];
      const h = this.hands[seat];
      if (!this.table.length) return seat === this.att ? h.slice() : [];
      if (this.table.length >= this.cap) return [];
      if (this.phase === "attack" && this.hands[this.dfn].length <= this._unbeaten().length) return [];
      const ranks = new Set(); this.table.forEach(p => p.forEach(c => { if (c) ranks.add(c[0]); }));
      return h.filter(c => ranks.has(c[0]));
    }
    _setTurn() {
      if (this.phase === "attack" && this._unbeaten().length) { this.turn = this.dfn; return; }
      if (!this.table.length) { this.turn = this.att; return; }
      for (const s of this._attackers()) if (!this.passed.has(s) && this.throwable(s).length) { this.turn = s; return; }
      this._endRound();
    }
    _endRound() {
      const took = this.phase === "take", cards = [];
      this.table.forEach(p => p.forEach(c => { if (c) cards.push(c); }));
      const trk = this.track !== false;
      if (took) { this.hands[this.dfn].push(...cards); if (trk) cards.forEach(c => this.known[this.dfn].add(c)); }
      else { this.discard += cards.length; if (trk) cards.forEach(c => this.gone.add(c)); }
      this.table = [];
      for (const s of this._attackers().concat([this.dfn])) {
        if (this.out[s]) continue;
        while (this.hands[s].length < HAND && this.deck.length) {
          const c = this.deck.pop(); this.hands[s].push(c);
          if (!this.deck.length && c === this.trumpCard && this.track !== false) this.known[s].add(c);   // ochiq kozer kartasini olgan — hamma biladi
        }
      }
      for (let s = 0; s < this.n; s++) if (!this.out[s] && !this.hands[s].length && !this.deck.length) { this.out[s] = true; this.finish.push(s); }
      const alive = []; for (let s = 0; s < this.n; s++) if (!this.out[s]) alive.push(s);
      if (alive.length <= 1) { const l = alive.length ? alive[0] : null; this.over = {loser: l, pagon: l === null ? 0 : pagonOf(this.hands[l])}; this.turn = -1; return; }
      const d = this.dfn;
      this.att = took ? this._next(d) : (!this.out[d] ? d : this._next(d));
      this.dfn = this._next(this.att);
      this._startRound();
    }
    clone() {   // bot qidiruvi uchun tez nusxa
      const o = Object.create(State.prototype);
      o.n = this.n; o.deck = this.deck.slice(); o.hands = this.hands.map(h => h.slice()); o.trumpCard = this.trumpCard; o.trump = this.trump;
      o.out = this.out.slice(); o.finish = this.finish.slice(); o.discard = this.discard; o.over = this.over; o.gone = this.gone; o.known = this.known; o.track = false;
      o.att = this.att; o.dfn = this.dfn; o.table = this.table.map(p => p.slice()); o.phase = this.phase; o.passed = new Set(this.passed); o.cap = this.cap; o.turn = this.turn;
      return o;
    }
    legal(seat) {
      const res = {cards: [], take: false, pass: false, def: {}};
      if (this.over || seat !== this.turn) return res;
      if (seat === this.dfn) {
        res.take = true;
        for (const c of this.hands[seat]) { const idx = this._unbeaten().filter(i => this.beats(this.table[i][0], c)); if (idx.length) res.def[c] = idx; }
        res.cards = Object.keys(res.def); return res;
      }
      res.cards = this.throwable(seat); res.pass = this.table.length > 0; return res;
    }
    act(seat, a) {
      if (this.over) throw new Error("o'yin tugagan");
      if (seat !== this.turn) throw new Error("navbat sizda emas");
      const t = a && a.t; let info;
      if (t === "atk") {
        if (!this.throwable(seat).includes(a.c)) throw new Error("bu kartani tashlab bo'lmaydi");
        this.hands[seat].splice(this.hands[seat].indexOf(a.c), 1); if (this.track !== false) this.known[seat].delete(a.c); this.table.push([a.c, null]); this.passed.clear(); info = {t, seat, c: a.c};
      } else if (t === "def") {
        if (seat !== this.dfn || this.phase !== "attack") throw new Error("siz himoyachi emassiz");
        if (!Number.isInteger(a.i) || !this._unbeaten().includes(a.i) || !this.hands[seat].includes(a.c) || !this.beats(this.table[a.i][0], a.c)) throw new Error("bu karta urmaydi");
        this.hands[seat].splice(this.hands[seat].indexOf(a.c), 1); if (this.track !== false) this.known[seat].delete(a.c); this.table[a.i][1] = a.c; info = {t, seat, c: a.c, i: a.i};
      } else if (t === "take") {
        if (seat !== this.dfn || this.phase !== "attack" || !this._unbeaten().length) throw new Error("hozir olib bo'lmaydi");
        this.phase = "take"; this.passed.clear(); info = {t, seat};
      } else if (t === "pass") {
        if (seat === this.dfn || !this.table.length) throw new Error("hozir pas qilib bo'lmaydi");
        this.passed.add(seat); info = {t, seat};
      } else throw new Error("noma'lum harakat");
      this._setTurn();
      return info;
    }
  }

  // ======================= BOT =======================
  // Odamdek o'ynaydi: kartalarni sanaydi (nima chiqib ketgan, raqib nimani olgani), ehtimollarni baholaydi,
  // kozerni asraydi, 6 (pagon) bilan qolib ketmaslikka harakat qiladi, oxirgi bosqichda (2 kishi, kolodasiz) mukammal hisoblaydi.
  const nowMs = () => (typeof performance !== "undefined" ? performance : Date).now();
  const ALL = fullDeck();
  const isT = (s, c) => c[1] === s.trump;
  const byRank = (a, b) => rank(a) - rank(b);
  // Qo'l sifati: Σ qiymat − B·(kartalar soni)². Karta soni kvadratik og'irlik beradi: qo'l shishsa yutqazish xavfi tez oshadi.
  const worth = (s, c) => isT(s, c) ? 6.5 + rank(c) + (s.deck.length > 6 ? 1.2 : 0) : 1 + 0.5 * rank(c) - (c[0] === "6" && s.deck.length <= 4 ? 0.8 : 0);   // oxirida oltiliklar xavfli (pagon)
  const BB = s => 0.45 * (s.deck.length === 0 ? 1.35 : s.deck.length < 6 ? 1.15 : 1);
  const shed = (s, c, m) => BB(s) * (2 * m - 1) - worth(s, c);                 // bitta kartani qo'ldan chiqarish foydasi (m — qo'ldagi kartalar soni)
  const rnd = k => (Math.random() - 0.5) * 2 * k;
  const PERSONA = {noise: 0, chat: 0.4};

  function tableCards(s) { const o = []; s.table.forEach(p => p.forEach(c => { if (c) o.push(c); })); return o; }
  function alive(s) { const o = []; for (let i = 0; i < s.n; i++) if (!s.out[i]) o.push(i); return o; }
  // Noma'lum kartalar: hech kimning qo'lida ko'rinmagan (kolodada yoki raqiblar qo'lida)
  function unknownPool(s, seat) {
    const mine = new Set(s.hands[seat]), tb = new Set(tableCards(s)), kn = new Set();
    s.known.forEach((k, i) => { if (i !== seat) k.forEach(c => kn.add(c)); });
    return ALL.filter(c => !s.gone.has(c) && !mine.has(c) && !tb.has(c) && !kn.has(c) && !(s.deck.length && c === s.trumpCard));
  }
  // Himoyachi `d` shu hujum kartasini ura olish ehtimoli
  function pBeat(s, seat, d, att, pool) {
    for (const c of s.known[d]) if (s.hands[d].includes(c) && s.beats(att, c)) return 1;
    const h = Math.max(0, s.hands[d].length - s.known[d].size);
    if (!h || !pool.length) return 0;
    const k = pool.filter(c => s.beats(att, c)).length;
    return 1 - Math.pow(1 - k / pool.length, h);
  }

  // ---- oxirgi bosqich: 2 kishi qolgan va kolodada karta yo'q — raqib qo'li aniq ma'lum, to'liq qidiruv ----
  function solveEnd(s, seat) {
    const al = alive(s);
    if (s.deck.length || al.length !== 2 || s.over) return null;
    const opp = al.find(x => x !== seat), mine = new Set(s.hands[seat]), tb = new Set(tableCards(s));
    const derived = ALL.filter(c => !s.gone.has(c) && !mine.has(c) && !tb.has(c));
    if (derived.length !== s.hands[opp].length) return null;
    const sim0 = s.clone(); sim0.hands[opp] = derived;
    let nodes = 0; const LIMIT = 9000, memo = new Map(), tEnd = nowMs() + 45;
    const movesOf = sim => {
      const st = sim.turn, L = sim.legal(st), out = [];
      if (st === sim.dfn) {
        const defs = [];
        for (const c of Object.keys(L.def)) for (const i of L.def[c]) defs.push({t: "def", c, i});
        defs.sort((a, b) => worth(sim, a.c) - worth(sim, b.c));
        out.push(...defs, {t: "take"});
      } else {
        out.push(...L.cards.slice().sort((a, b) => worth(sim, a) - worth(sim, b)).map(c => ({t: "atk", c})));
        if (L.pass) out.push({t: "pass"});
      }
      return out;
    };
    const key = sim => sim.turn + "|" + sim.phase + "|" + sim.att + "|" + sim.dfn + "|" + sim.hands.map(h => h.slice().sort().join("")).join("/") + "|"
      + sim.table.map(p => p[0] + (p[1] || "-")).join(",") + "|" + [...sim.passed].join("");
    const search = sim => {   // aniq minimax (qiymatlar -1/0/1); ildiz bo'yicha kesish faqat «yaxshiroq bo'lishi mumkin emas» holatida
      if (sim.over) return sim.over.loser == null ? 0 : (sim.over.loser === seat ? -1 : 1);
      if (sim.out[seat]) return 1;
      if (sim.out[opp]) return -1;
      if (++nodes > LIMIT || ((nodes & 255) === 0 && nowMs() > tEnd)) throw new Error("budget");
      const k = key(sim), hit = memo.get(k); if (hit !== undefined) return hit;
      const maxing = sim.turn === seat; let best = maxing ? -2 : 2;
      for (const m of movesOf(sim)) {
        const nx = sim.clone();
        try { nx.act(nx.turn, m); } catch (_) { continue; }
        const v = search(nx);
        if (maxing) { if (v > best) best = v; if (best === 1) break; } else { if (v < best) best = v; if (best === -1) break; }
      }
      memo.set(k, best); return best;
    };
    try {
      const L = sim0.legal(seat); if (seat !== sim0.turn) return null;
      let bestV = -2, bestM = [];
      for (const m of movesOf(sim0)) {
        const nx = sim0.clone();
        try { nx.act(seat, m); } catch (_) { continue; }
        const v = search(nx);
        if (v > bestV) { bestV = v; bestM = [m]; } else if (v === bestV) bestM.push(m);
      }
      return bestM.length ? {move: bestM[0], value: bestV} : null;
    } catch (e) { return null; }
  }

  // ---- himoya: kerakli kartalarni eng arzon usulda ajratish ----
  function bestDefense(s, seat) {
    const un = s._unbeaten().sort((a, b) => (isT(s, s.table[b][0]) - isT(s, s.table[a][0])) || (rank(s.table[b][0]) - rank(s.table[a][0])));
    const hand = s.hands[seat]; let best = null, steps = 0;
    const rec = (k, used, cost, plan) => {
      if (++steps > 4000) return;
      if (k === un.length) { if (!best || cost < best.cost) best = {cost, plan: plan.slice()}; return; }
      const i = un[k];
      const opts = hand.filter(c => !used.has(c) && s.beats(s.table[i][0], c)).sort((a, b) => worth(s, a) - worth(s, b)).slice(0, 4);
      for (const c of opts) { used.add(c); plan.push({i, c}); rec(k + 1, used, cost + worth(s, c), plan); plan.pop(); used.delete(c); }
    };
    rec(0, new Set(), 0, []);
    return best;
  }
  function defend(s, seat, P) {
    const bd = bestDefense(s, seat);
    if (!bd) return {t: "take"};                                    // urib bo'lmaydi
    const first = bd.plan[0], tb = tableCards(s), m = s.hands[seat].length;
    // Tajriba (o'z-o'zi bilan o'ynatib o'lchangan): ixtiyoriy olish deyarli har doim yutqazdiradi. Faqat bitta holat oqilona:
    // kolodada karta ko'p, stolda faqat past oddiy kartalar, urish uchun esa yuqori kozer kerak — kozerni asrab, past kartalarni olamiz.
    const usesBig = bd.plan.some(p => isT(s, p.c) && !isT(s, s.table[p.i][0]) && rank(p.c) >= 4);
    const cheap = tb.every(c => !isT(s, c) && rank(c) <= 2);
    if (usesBig && cheap && s.deck.length >= 8 && m <= 7 && tb.length <= 2 && Math.random() < 0.85 - P.noise * 0.3) return {t: "take"};
    return {t: "def", c: first.c, i: first.i};
  }

  // ---- hujum / qo'shib tashlash ----
  const TUNE = {leadPb: 0.6, leadPair: 0.9, throwPb: 0.45, passP: 0.8};
  function attack(s, seat, P) {
    const L = s.legal(seat), cards = L.cards; if (!cards.length) return {t: "pass"};
    const d = s.dfn, pool = unknownPool(s, seat), lead = !s.table.length;
    const plain = cards.filter(c => !isT(s, c)).sort(byRank);
    if (lead) {
      if (!plain.length) return {t: "atk", c: cards.slice().sort(byRank)[0]};     // faqat kozer qolgan: eng pasti
      const cnt = {}; s.hands[seat].forEach(c => { cnt[c[0]] = (cnt[c[0]] || 0) + 1; });
      let best = null;
      for (const c of plain) {
        // past karta oldin; juft bo'lsa qo'shib tashlash imkoni; raqib urolmaydigan karta — raqibga yuk
        const sc = -rank(c) + TUNE.leadPair * Math.min(2, cnt[c[0]] - 1) + TUNE.leadPb * (1 - pBeat(s, seat, d, c, pool)) * 3 + rnd(P.noise);
        if (!best || sc > best.sc) best = {c, sc};
      }
      return {t: "atk", c: best.c};
    }
    // qo'shib tashlash (podkidka)
    let pl = plain;
    if (!pl.length && !s.deck.length) pl = cards.slice().sort(byRank);              // kolodasiz: kozerni ham tashlab, qo'lni bo'shatamiz
    if (!pl.length) return {t: "pass"};
    const c = pl[0];
    if (s.phase !== "take" && rank(c) >= 7 && s.deck.length > 0 && s.hands[s.dfn].length > 2) {
      // yuqori kartani himoyachi urib qo'yishi ehtimoli katta bo'lsa — saqlaymiz
      if (pBeat(s, seat, d, c, pool) > TUNE.throwPb && Math.random() < TUNE.passP) return {t: "pass"};
    }
    return {t: "atk", c};
  }


  // ---- tez «o'ylamasdan» o'ynaydigan siyosat: simulyatsiyalar (rollout) uchun ----
  function quickAct(s, seat) {
    const L = s.legal(seat);
    if (seat === s.dfn) {
      const hand = s.hands[seat].slice(), plan = [];
      const idx = s._unbeaten().sort((a, b) => (isT(s, s.table[b][0]) - isT(s, s.table[a][0])) || (rank(s.table[b][0]) - rank(s.table[a][0])));
      for (const i of idx) {
        const opts = hand.filter(c => s.beats(s.table[i][0], c)).sort((a, b) => (isT(s, a) - isT(s, b)) || byRank(a, b));
        if (!opts.length) return {t: "take"};
        plan.push({i, c: opts[0]}); hand.splice(hand.indexOf(opts[0]), 1);
      }
      return {t: "def", c: plan[0].c, i: plan[0].i};
    }
    const cards = L.cards, plain = cards.filter(c => !isT(s, c)).sort(byRank);
    if (!s.table.length) {
      if (!plain.length) return {t: "atk", c: cards.slice().sort(byRank)[0]};
      const cnt = {}; plain.forEach(c => { cnt[c[0]] = (cnt[c[0]] || 0) + 1; });
      return {t: "atk", c: plain.find(c => cnt[c[0]] > 1) || plain[0]};
    }
    let pl = plain;
    if (!pl.length && !s.deck.length) pl = cards.slice().sort(byRank);
    if (!pl.length) return {t: "pass"};
    return {t: "atk", c: pl[0]};
  }
  // Raqiblar qo'lini va kolodani ma'lumotlarga mos ravishda tasodifiy to'ldirib, «mumkin bo'lgan dunyo» yaratadi
  function sampleWorld(s, seat, pool) {
    const w = s.clone(); const need = [];
    for (let o = 0; o < s.n; o++) if (o !== seat && !s.out[o]) {
      const kn = s.hands[o].filter(c => s.known[o].has(c)), unk = s.hands[o].length - kn.length;
      w.hands[o] = kn.slice(); need.push([o, unk]);
    }
    const p = pool.slice(); for (let i = p.length - 1; i > 0; i--) { const j = (Math.random() * (i + 1)) | 0; const t = p[i]; p[i] = p[j]; p[j] = t; }
    let k = 0;
    for (const [o, u] of need) for (let q = 0; q < u; q++) w.hands[o].push(p[k++]);
    if (s.deck.length) { for (let q = 1; q < s.deck.length; q++) w.deck[q] = p[k++]; }
    if (k !== p.length) return null;
    return w;
  }
  function candidatesOf(s, seat) {
    const L = s.legal(seat), out = [];
    if (seat === s.dfn) {
      for (const c of Object.keys(L.def)) { const ix = L.def[c]; out.push({t: "def", c, i: ix[0]}); if (ix.length > 1) out.push({t: "def", c, i: ix[ix.length - 1]}); }
      out.push({t: "take"});
    } else {
      L.cards.forEach(c => out.push({t: "atk", c}));
      if (L.pass) out.push({t: "pass"});
    }
    return out;
  }
  function rollout(w, seat) {
    let steps = 0;
    while (!w.over && steps++ < 500) {
      const t = w.turn; if (t < 0) break;
      try { w.act(t, quickAct(w, t)); } catch (_) { return 0; }
    }
    if (!w.over) return 0;
    const l = w.over.loser; return l == null ? 0 : l === seat ? -1 - 0.3 * (w.over.pagon || 0) : 1;
  }
  // PIMC: har bir nomzod yurishni ko'p «mumkin bo'lgan dunyo»da oxirigacha o'ynab ko'radi, o'rtachasi eng yaxshisi tanlanadi
  function pimc(s, seat, cands, P, budget) {
    const pool = unknownPool(s, seat), sum = cands.map(() => 0); let n = 0; const t0 = nowMs();
    const MIN = P.minN || 10, MAX = 160;
    while (n < MAX && (n < MIN || nowMs() - t0 < budget)) {
      const w = sampleWorld(s, seat, pool); if (!w) return null;
      for (let i = 0; i < cands.length; i++) {
        const sim = w.clone();
        try { sim.act(seat, cands[i]); } catch (_) { sum[i] -= 5; continue; }
        sum[i] += rollout(sim, seat);
      }
      n++;
    }
    return {mean: sum.map(x => x / n), n};
  }

  function botAct(s, seat, persona) {
    const P = persona || PERSONA, L = s.legal(seat);
    const e = solveEnd(s, seat);
    if (e && (e.move.t !== "pass" || L.pass)) return e.move;
    const cands = candidatesOf(s, seat);
    if (cands.length === 1) return cands[0];
    if (P.budget !== 0) {
      const r = pimc(s, seat, cands, P, P.budget || 14);
      if (r) {
        let order = r.mean.map((v, i) => i).sort((a, b) => r.mean[b] - r.mean[a]);
        // odamdek: deyarli teng ikkinchi yurishni ba'zan tanlaydi (xato emas, uslub)
        if (order.length > 1 && r.mean[order[0]] - r.mean[order[1]] < 0.04 && Math.random() < 0.3 + P.noise * 0.4) order = [order[1], order[0]];
        return cands[order[0]];
      }
    }
    if (seat === s.dfn) return defend(s, seat, P);
    return attack(s, seat, P);
  }
  // Odamdek «o'ylash» vaqti (ms): oson/yagona yurishda tez, qiyin tanlovda sekinroq
  function botThink(s, seat) {
    const L = s.legal(seat), opts = seat === s.dfn ? Object.keys(L.def).length + 1 : L.cards.length + (L.pass ? 1 : 0);
    if (opts <= 1) return 380 + Math.random() * 260;
    return 620 + Math.min(opts, 7) * 95 + Math.random() * 700;
  }
  function makePersona() { return {noise: 0.25 + Math.random() * 0.45, chat: 0.15 + Math.random() * 0.6}; }
  const api = {State, rank, fullDeck, botAct, botThink, makePersona, solveEnd, pagonOf, RANKS, SUITS};
  root.TCDurak = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof self !== "undefined" ? self : this);
