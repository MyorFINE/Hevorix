"use strict";
/* Ishlash rejimi (kuchsiz qurilmalar uchun). Sinflar <html> ga qo'yiladi: «lite» (bezaklar o'chadi), «ultra» (cheksiz animatsiyalar to'xtaydi).
   Rejim: «auto» (qurilma + jonli kuzatuv), «full» (hech narsa o'chmaydi), «lite». Faqat shu qurilmada saqlanadi (termchat_perf).
   Avto kuzatuv: aylantirish paytida kadrlar sekin chiqsa, rejim bosqichma-bosqich yengillashadi va eslab qolinadi. */
(() => {
  const root = document.documentElement, KEY = "termchat_perf", LKEY = "termchat_perf_lvl";
  const get = k => { try { return localStorage.getItem(k); } catch (_) { return null; } };
  const put = (k, v) => { try { v == null ? localStorage.removeItem(k) : localStorage.setItem(k, v); } catch (_) {} };
  const LV = ["full", "lite", "ultra"];
  let mode = ["auto", "full", "lite"].includes(get(KEY)) ? get(KEY) : "auto";

  function deviceLevel() {
    let lvl = 0;
    try {
      const mem = navigator.deviceMemory || 4, cores = navigator.hardwareConcurrency || 8, c = navigator.connection || {};
      if (mem <= 2 || cores <= 4 || c.saveData || /(^|-)2g$|3g/.test(c.effectiveType || "")) lvl = 1;
      if (mem <= 1 || cores <= 2) lvl = 2;
      const m = /Android (\d+)/.exec(navigator.userAgent || "");
      if (m && +m[1] <= 8) lvl = Math.max(lvl, 1);
      if (matchMedia("(prefers-reduced-motion: reduce)").matches) lvl = Math.max(lvl, 1);
    } catch (_) {}
    return lvl;
  }
  let learned = Math.min(2, Math.max(0, +get(LKEY) || 0));
  const level = () => mode === "full" ? 0 : mode === "lite" ? Math.max(1, learned) : Math.max(deviceLevel(), learned);
  function apply() {
    const l = level();
    root.classList.toggle("lite", l >= 1);
    root.classList.toggle("ultra", l >= 2);
  }

  // Jonli kuzatuv: aylantirish paytida 1.2 s davomida kadr vaqtlarini o'lchaymiz
  let sampling = false, bad = 0, lastRun = 0;
  function sample() {
    if (mode !== "auto" || sampling || document.hidden || level() >= 2 || Date.now() - lastRun < 4000) return;
    sampling = true; lastRun = Date.now();
    let prev = 0, n = 0, slow = 0;
    const tick = t => {
      if (prev) { n++; if (t - prev > 45) slow++; }
      prev = t;
      if (n < 70 && !document.hidden) return requestAnimationFrame(tick);
      sampling = false;
      if (n >= 40 && slow / n > 0.22) {
        if (++bad >= 2) { bad = 0; learned = Math.min(2, Math.max(learned, level()) + 1); put(LKEY, String(learned)); apply(); }
      } else if (bad) bad--;
    };
    requestAnimationFrame(tick);
  }
  let st = 0;
  const onScroll = () => { if (st) return; st = setTimeout(() => { st = 0; sample(); }, 300); };
  addEventListener("scroll", onScroll, {passive: true, capture: true});

  // Sahifa ko'rinmasa, animatsiyalar to'xtaydi (batareya)
  const vis = () => root.classList.toggle("tab-hidden", document.hidden);
  document.addEventListener("visibilitychange", vis); vis();

  window.Perf = {
    mode: () => mode, level: () => LV[level()],
    set(m) { if (!["auto", "full", "lite"].includes(m)) return; mode = m; put(KEY, m === "auto" ? null : m); if (m !== "auto") { learned = 0; put(LKEY, null); } apply(); },
    reset() { learned = 0; put(LKEY, null); apply(); },
  };
  apply();
})();
