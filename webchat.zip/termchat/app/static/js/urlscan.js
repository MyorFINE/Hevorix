/* Havola skaneri paneli (mijoz). «Scan» bosilganda havola yonida ochiladi va FAQAT shu foydalanuvchining ekranida ko'rinadi:
   xabar matni boshqalarga o'zgarmaydi, hech narsa yuborilmaydi/saqlanmaydi (natija xotirada qisqa muddat keshlanadi).
   Server: POST /api/urlscan (tahlil) va POST /api/urlscan/shot (skrinshot) — ikkalasi parallel, skrinshot kech kelsa panel kutmaydi.
   Barcha matn textContent orqali qo'yiladi (innerHTML yo'q), serverdan kelgan qiymatlar ham shunday. */
(function (root) {
  "use strict";
  const U = {};
  const cache = new Map();          // href -> {scan, scanErr, shot, shotErr, sp, hp}
  const panels = new WeakMap();     // Scan tugmasi -> panel
  const MAX_CACHE = 30;
  const ICON = {ok: "✓", warn: "!", bad: "✕", na: "–"};
  const SEV = {bad: "⚠", warn: "!", info: "i"};
  const IMG_OK = /^data:image\/jpeg;base64,[A-Za-z0-9+\/=]+$/;

  function el(tag, cls, text) {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  }

  function entry(href) {
    let e = cache.get(href);
    if (!e) {
      e = {scan: null, scanErr: "", shot: null, shotErr: "", sp: null, hp: null};
      cache.set(href, e);
      while (cache.size > MAX_CACHE) cache.delete(cache.keys().next().value);
    }
    return e;
  }

  // Server so'rovlari: bir xil havola uchun bitta so'rov (bir nechta panel bo'lsa ham)
  function ensure(href, deps, fresh) {
    const e = entry(href);
    if (fresh) { e.scan = null; e.shot = null; e.scanErr = e.shotErr = ""; e.sp = e.hp = null; }
    if (!e.sp && !e.scan) {
      e.scanErr = "";
      e.sp = deps.api("/urlscan", {method: "POST", body: {url: href, fresh: !!fresh}})
        .then(r => { e.scan = r; }).catch(err => { e.scanErr = (err && err.message) || "Tekshirib bo'lmadi"; }).then(() => { e.sp = null; });
    }
    if (!e.hp && !e.shot) {
      e.shotErr = "";
      e.hp = deps.api("/urlscan/shot", {method: "POST", body: {url: href, fresh: !!fresh}})
        .then(r => { e.shot = r; }).catch(err => { e.shotErr = (err && err.message) || "Skrinshot olinmadi"; }).then(() => { e.hp = null; });
    }
    return e;
  }

  function build(href, btn, deps) {
    const root_ = el("div", "scan-panel");
    root_.setAttribute("role", "region");
    root_.setAttribute("aria-label", "Havola xavfsizlik tekshiruvi");
    const head = el("div", "sp-head");
    const dot = el("span", "sp-dot wait");
    const title = el("span", "sp-title", "Tekshirilmoqda…");
    head.append(dot, title);
    const prev = el("div", "sp-prev");
    prev.append(el("span", "sp-prev-label", "URL PREVIEW"));
    const prevBody = el("div", "sp-prev-body", "Skrinshot olinmoqda…");
    prev.append(prevBody);
    const grid = el("div", "sp-grid");
    const detail = el("div", "sp-detail hidden");
    const finds = el("div", "sp-finds");
    const foot = el("div", "sp-foot");
    const note = el("span", "sp-note", "Havola ochilmaydi — server tomonidan tekshiriladi");
    const again = el("button", "sp-min", "Qayta");
    again.type = "button";
    const min = el("button", "sp-min", "Min");
    min.type = "button";
    foot.append(note, again, min);
    root_.append(head, prev, grid, detail, finds, foot);
    const st = {sel: null};

    const stop = fn => ev => { ev.stopPropagation(); ev.preventDefault(); fn(); };
    min.addEventListener("click", stop(() => U.collapse(btn)));
    again.addEventListener("click", stop(() => { ensure(href, deps, true); paint(); watch(); }));
    root_.addEventListener("click", ev => ev.stopPropagation());

    function paintDetail(c) {
      detail.textContent = "";
      if (!c) { detail.classList.add("hidden"); return; }
      detail.classList.remove("hidden");
      detail.append(el("div", "sp-d-title", c.name));
      for (const row of c.details || []) {
        const r = el("div", "sp-d-row");
        r.append(el("span", "sp-d-k", String(row[0])), el("span", "sp-d-v", String(row[1])));
        detail.append(r);
      }
    }

    function paint() {
      const e = cache.get(href) || {};
      const scan = e.scan;
      grid.textContent = "";
      finds.textContent = "";
      // sarlavha
      if (scan && scan.verdict) {
        dot.className = "sp-dot " + scan.verdict.level;
        title.textContent = scan.verdict.label;
      } else if (e.scanErr) {
        dot.className = "sp-dot na";
        title.textContent = e.scanErr;
      } else {
        dot.className = "sp-dot wait";
        title.textContent = "Tekshirilmoqda…";
      }
      // skrinshot
      if (e.shot && e.shot.ok && typeof e.shot.image === "string" && IMG_OK.test(e.shot.image)) {
        prevBody.textContent = "";
        const img = document.createElement("img");
        img.className = "sp-img"; img.alt = "Sayt skrinshoti"; img.decoding = "async"; img.draggable = false;
        img.src = e.shot.image;
        prevBody.append(img);
      } else if (e.shot && !e.shot.ok) {
        prevBody.textContent = e.shot.message || "Skrinshot olinmadi";
      } else if (e.shotErr) {
        prevBody.textContent = e.shotErr;
      } else {
        prevBody.textContent = "Skrinshot olinmoqda…";
      }
      // natijalar katakchalari
      const checks = scan && scan.checks ? scan.checks : null;
      const names = ["WHOIS / RDAP", "DNS", "SSL / TLS", "Redirects", "Threat Intel", "Final URL", "Sahifa", "URL tahlili"];
      const list = checks || names.map(n => ({name: n, status: "wait", value: e.scanErr ? "—" : "…", details: []}));
      list.forEach((c, i) => {
        const b = el("button", "sp-cell" + (st.sel === i ? " on" : ""));
        b.type = "button";
        b.append(el("span", "sp-cname", c.name), el("span", "sp-cval " + c.status, (ICON[c.status] ? ICON[c.status] + " " : "") + c.value));
        if (checks) b.addEventListener("click", stop(() => { st.sel = st.sel === i ? null : i; paint(); }));
        grid.append(b);
      });
      paintDetail(checks && st.sel != null ? checks[st.sel] : null);
      // topilmalar
      if (scan && scan.findings && scan.findings.length) {
        for (const f of scan.findings) {
          const r = el("div", "sp-find " + f.sev);
          r.append(el("span", "sp-find-i", SEV[f.sev] || "i"), el("span", "sp-find-t", f.text));
          finds.append(r);
        }
      } else if (scan) {
        finds.append(el("div", "sp-find ok", "Hech qanday xavfli belgi topilmadi"));
      }
      if (scan) note.textContent = (scan.note || "") + (e.shot && e.shot.ok && e.shot.via ? " Skrinshot: " + e.shot.via : "");
      again.disabled = !!(e.sp || e.hp);
    }

    function watch() {
      const e = cache.get(href);
      if (!e) return;
      [e.sp, e.hp].filter(Boolean).forEach(p => p.then(() => paint()));
    }
    paint();
    return {root: root_, paint, watch};
  }

  U.collapse = function (btn) {
    const p = panels.get(btn);
    if (!p) return;
    p.root.classList.add("hidden");
    btn.classList.remove("on");
    btn.setAttribute("aria-expanded", "false");
  };

  // deps: {api(path, {method, body}) -> Promise<json>}
  U.toggle = function (href, btn, deps) {
    let p = panels.get(btn);
    if (p) {
      const hidden = p.root.classList.contains("hidden");
      if (hidden) { p.root.classList.remove("hidden"); btn.classList.add("on"); btn.setAttribute("aria-expanded", "true"); p.paint(); }
      else U.collapse(btn);
      return;
    }
    p = build(href, btn, deps);
    panels.set(btn, p);
    btn.classList.add("on");
    btn.setAttribute("aria-expanded", "true");
    if (btn.parentNode) btn.parentNode.insertBefore(p.root, btn.nextSibling);
    ensure(href, deps, false);
    p.paint();
    p.watch();
  };

  U._cache = cache;
  if (typeof module !== "undefined" && module.exports) module.exports = U; else root.UrlScan = U;
})(typeof window !== "undefined" ? window : globalThis);
