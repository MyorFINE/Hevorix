/* Havola skaneri paneli (mijoz). «Scan» bosilganda havola yonida ochiladi va FAQAT shu foydalanuvchining ekranida ko'rinadi:
   xabar matni boshqalarga o'zgarmaydi, hech narsa yuborilmaydi/saqlanmaydi (natija xotirada qisqa muddat keshlanadi).
   Server: POST /api/urlscan (tahlil) va POST /api/urlscan/shot (skrinshot) — ikkalasi parallel, skrinshot kech kelsa panel kutmaydi.
   Barcha matn textContent orqali qo'yiladi (innerHTML yo'q), serverdan kelgan qiymatlar ham shunday. */
(function (root) {
  "use strict";
  const U = {};
  const cache = new Map();          // href -> {scan, scanErr, shot, shotErr, sp, hp}
  const panels = new WeakMap();     // Scan tugmasi -> panel
  const MAX_CACHE = 30;
  const ICON = {ok: "✓", warn: "!", bad: "✕", na: "–"};
  const SEV = {bad: "⚠", warn: "!", info: "i"};
  const IMG_OK = /^data:image\/jpeg;base64,[A-Za-z0-9+\/=]+$/;

  function el(tag, cls, text) {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  }

  function entry(href) {
    let e = cache.get(href);
    if (!e) {
      e = {scan: null, scanErr: "", shot: null, shotErr: "", sp: null, hp: null, os: null, osErr: "", osp: null};
      cache.set(href, e);
      while (cache.size > MAX_CACHE) cache.delete(cache.keys().next().value);
    }
    return e;
  }

  // Server so'rovlari: bir xil havola uchun bitta so'rov (bir nechta panel bo'lsa ham)
  function ensure(href, deps, fresh) {
    const e = entry(href);
    if (fresh) { e.scan = null; e.shot = null; e.scanErr = e.shotErr = ""; e.sp = e.hp = null; }
    if (!e.sp && !e.scan) {
      e.scanErr = "";
      e.sp = deps.api("/urlscan", {method: "POST", body: {url: href, fresh: !!fresh}})
        .then(r => { e.scan = r; }).catch(err => { e.scanErr = (err && err.message) || "Tekshirib bo'lmadi"; }).then(() => { e.sp = null; });
    }
    if (!e.hp && !e.shot) {
      e.shotErr = "";
      e.hp = deps.api("/urlscan/shot", {method: "POST", body: {url: href, fresh: !!fresh}})
        .then(r => { e.shot = r; }).catch(err => { e.shotErr = (err && err.message) || "Skrinshot olinmadi"; }).then(() => { e.hp = null; });
    }
    return e;
  }

  // Chuqur OSINT (SpiderFoot uslubida, passiv, kalitsiz): faqat tugma bosilganda so'raladi
  function ensureOsint(href, deps, fresh) {
    const e = entry(href);
    if (fresh) { e.os = null; e.osErr = ""; e.osp = null; }
    if (!e.os && !e.osp) {
      e.osErr = "";
      e.osp = deps.api("/osint", {method: "POST", body: {url: href, fresh: !!fresh}})
        .then(r => { e.os = r; }).catch(err => { e.osErr = (err && err.message) || "OSINT bajarilmadi"; }).then(() => { e.osp = null; });
    }
    return e;
  }

  const SVGNS = "http://www.w3.org/2000/svg";
  const svgEl = (tag, attrs) => {
    const n = document.createElementNS ? document.createElementNS(SVGNS, tag) : document.createElement(tag);
    for (const k in attrs || {}) n.setAttribute(k, String(attrs[k]));
    return n;
  };
  // Aloqalar grafi: markazda domen, atrofida halqalar (IP → ASN/NS/MX/email → subdomenlar). Animatsiyasiz, ≤70 tugun.
  function graphEl(g) {
    const W = 360, H = 320, cx = W / 2, cy = H / 2;
    const svg = svgEl("svg", {viewBox: "0 0 " + W + " " + H, class: "os-graph", role: "img", "aria-label": "Aloqalar grafi"});
    const nodes = (g && g.nodes) || [], pos = {};
    const rings = [["ip"], ["asn", "ns", "mx", "email", "org"], ["sub"]], radius = [62, 108, 148];
    nodes.forEach(n => { if (n.type === "domain") pos[n.id] = [cx, cy]; });
    rings.forEach((types, ri) => {
      const ring = nodes.filter(n => types.includes(n.type));
      ring.forEach((n, i) => { const a = (i / Math.max(1, ring.length)) * Math.PI * 2 - Math.PI / 2 + ri * 0.4; pos[n.id] = [cx + radius[ri] * Math.cos(a), cy + radius[ri] * Math.sin(a) * 0.9]; });
    });
    for (const e of (g && g.edges) || []) {
      const a = pos[e.a], b = pos[e.b];
      if (a && b) svg.append(svgEl("line", {x1: a[0].toFixed(1), y1: a[1].toFixed(1), x2: b[0].toFixed(1), y2: b[1].toFixed(1), class: "os-edge"}));
    }
    for (const n of nodes) {
      const p = pos[n.id]; if (!p) continue;
      const grp = svgEl("g", {class: "os-n t-" + String(n.type).replace(/[^a-z]/g, "")});
      const t = svgEl("title"); t.textContent = n.label; grp.append(t);
      grp.append(svgEl("circle", {cx: p[0].toFixed(1), cy: p[1].toFixed(1), r: n.type === "domain" ? 8 : n.type === "ip" ? 5.5 : 4}));
      if (n.type === "domain" || n.type === "ip" || n.type === "email" || n.type === "ns" || n.type === "mx") {
        const tx = svgEl("text", {x: p[0].toFixed(1), y: (p[1] + (n.type === "domain" ? 19 : -8)).toFixed(1), "text-anchor": "middle"});
        tx.textContent = n.label.length > 22 ? n.label.slice(0, 21) + "…" : n.label; grp.append(tx);
      }
      svg.append(grp);
    }
    return svg;
  }

  function renderOsint(box, e, st) {
    box.textContent = "";
    if (!e.os && !e.osp && !e.osErr) return;
    box.append(el("div", "os-title", "OSINT — chuqur tahlil"));
    if (e.osp) { box.append(el("div", "os-wait", "Ochiq manbalar so'ralmoqda (15–25 soniya)…")); return; }
    if (e.osErr) { box.append(el("div", "sp-find warn", e.osErr)); return; }
    const r = e.os, sum = r.summary || {}, fc = sum.findings || {};
    const chips = el("div", "os-sum");
    [["🔎", (sum.subdomains || 0) + " subdomen"], ["🌍", (sum.ips || 0) + " IP"], ["⚠", (fc.bad || 0) + " xavfli"], ["!", (fc.warn || 0) + " ogohlantirish"]]
      .forEach(c => chips.append(el("span", "os-chip", c[0] + " " + c[1])));
    box.append(chips);
    for (const m of r.modules || []) {
      const card = el("div", "os-mod " + m.status + (st.os.has(m.id) ? " open" : ""));
      const hd = el("button", "os-mh"); hd.type = "button";
      hd.append(el("span", "os-mi", m.icon || ""), el("span", "os-mt", m.title), el("span", "os-mv " + m.status, (ICON[m.status] ? ICON[m.status] + " " : "") + m.value));
      hd.addEventListener("click", ev => { ev.stopPropagation(); ev.preventDefault(); st.os.has(m.id) ? st.os.delete(m.id) : st.os.add(m.id); renderOsint(box, e, st); });
      card.append(hd, el("div", "os-sub", m.sub || ""));
      if (st.os.has(m.id)) {
        const body = el("div", "os-body");
        if (m.id === "graph") body.append(graphEl(r.graph));
        for (const row of m.rows || []) { const rr = el("div", "os-r"); rr.append(el("span", "os-k", String(row[0])), el("span", "os-v", String(row[1]))); body.append(rr); }
        if (m.list && m.list.length) { const ls = el("div", "os-list"); m.list.slice(0, 80).forEach(x => ls.append(el("div", "os-li", String(x)))); body.append(ls); }
        card.append(body);
      }
      box.append(card);
    }
    box.append(el("div", "os-note", r.note || ""));
  }

  function build(href, btn, deps) {
    const root_ = el("div", "scan-panel");
    root_.setAttribute("role", "region");
    root_.setAttribute("aria-label", "Havola xavfsizlik tekshiruvi");
    const head = el("div", "sp-head");
    const dot = el("span", "sp-dot wait");
    const title = el("span", "sp-title", "Tekshirilmoqda…");
    head.append(dot, title);
    const prev = el("div", "sp-prev");
    prev.append(el("span", "sp-prev-label", "URL PREVIEW"));
    const prevBody = el("div", "sp-prev-body", "Skrinshot olinmoqda…");
    prev.append(prevBody);
    const grid = el("div", "sp-grid");
    const detail = el("div", "sp-detail hidden");
    const finds = el("div", "sp-finds");
    const osBox = el("div", "sp-os");
    const foot = el("div", "sp-foot");
    const note = el("span", "sp-note", "Havola ochilmaydi — server tomonidan tekshiriladi");
    const again = el("button", "sp-min", "Qayta");
    again.type = "button";
    const osBtn = el("button", "sp-min os-btn", "🕵 OSINT");
    osBtn.type = "button";
    const min = el("button", "sp-min", "Min");
    min.type = "button";
    foot.append(note, osBtn, again, min);
    root_.append(head, prev, grid, detail, finds, osBox, foot);
    const st = {sel: null, os: new Set(["domain", "security"])};

    const stop = fn => ev => { ev.stopPropagation(); ev.preventDefault(); fn(); };
    min.addEventListener("click", stop(() => U.collapse(btn)));
    again.addEventListener("click", stop(() => { ensure(href, deps, true); const had = cache.get(href); if (had && (had.os || had.osp)) ensureOsint(href, deps, true); paint(); watch(); }));
    osBtn.addEventListener("click", stop(() => { const had = cache.get(href); if (had && (had.os || had.osErr) && !had.osp) { ensureOsint(href, deps, !!had.osErr); } else ensureOsint(href, deps, false); paint(); watch(); }));
    root_.addEventListener("click", ev => ev.stopPropagation());

    function paintDetail(c) {
      detail.textContent = "";
      if (!c) { detail.classList.add("hidden"); return; }
      detail.classList.remove("hidden");
      detail.append(el("div", "sp-d-title", c.name));
      for (const row of c.details || []) {
        const r = el("div", "sp-d-row");
        r.append(el("span", "sp-d-k", String(row[0])), el("span", "sp-d-v", String(row[1])));
        detail.append(r);
      }
    }

    function paint() {
      const e = cache.get(href) || {};
      const scan = e.scan;
      grid.textContent = "";
      finds.textContent = "";
      // sarlavha
      if (scan && scan.verdict) {
        dot.className = "sp-dot " + scan.verdict.level;
        title.textContent = scan.verdict.label;
      } else if (e.scanErr) {
        dot.className = "sp-dot na";
        title.textContent = e.scanErr;
      } else {
        dot.className = "sp-dot wait";
        title.textContent = "Tekshirilmoqda…";
      }
      // skrinshot
      if (e.shot && e.shot.ok && typeof e.shot.image === "string" && IMG_OK.test(e.shot.image)) {
        prevBody.textContent = "";
        const img = document.createElement("img");
        img.className = "sp-img"; img.alt = "Sayt skrinshoti"; img.decoding = "async"; img.draggable = false;
        img.src = e.shot.image;
        prevBody.append(img);
      } else if (e.shot && !e.shot.ok) {
        prevBody.textContent = e.shot.message || "Skrinshot olinmadi";
      } else if (e.shotErr) {
        prevBody.textContent = e.shotErr;
      } else {
        prevBody.textContent = "Skrinshot olinmoqda…";
      }
      // natijalar katakchalari
      const checks = scan && scan.checks ? scan.checks : null;
      const names = ["WHOIS / RDAP", "DNS", "SSL / TLS", "Redirects", "Threat Intel", "Final URL", "Sahifa", "Kontent", "Cloaking", "URL tahlili"];
      const list = checks || names.map(n => ({name: n, status: "wait", value: e.scanErr ? "—" : "…", details: []}));
      list.forEach((c, i) => {
        const b = el("button", "sp-cell" + (st.sel === i ? " on" : ""));
        b.type = "button";
        b.append(el("span", "sp-cname", c.name), el("span", "sp-cval " + c.status, (ICON[c.status] ? ICON[c.status] + " " : "") + c.value));
        if (checks) b.addEventListener("click", stop(() => { st.sel = st.sel === i ? null : i; paint(); }));
        grid.append(b);
      });
      paintDetail(checks && st.sel != null ? checks[st.sel] : null);
      // topilmalar
      if (scan && scan.findings && scan.findings.length) {
        for (const f of scan.findings) {
          const r = el("div", "sp-find " + f.sev);
          r.append(el("span", "sp-find-i", SEV[f.sev] || "i"), el("span", "sp-find-t", f.text));
          finds.append(r);
        }
      } else if (scan) {
        finds.append(el("div", "sp-find ok", "Hech qanday xavfli belgi topilmadi"));
      }
      // tavsiyalar va ishonchni oshiruvchi belgilar (serverdan: matn sifatida)
      const box = (cls, head, items) => {
        if (!Array.isArray(items) || !items.length) return;
        const b = el("div", cls);
        b.append(el("div", "sp-box-h", head));
        for (const t of items.slice(0, 5)) b.append(el("div", "sp-box-i", String(t)));
        finds.append(b);
      };
      if (scan) {
        box("sp-box adv " + (scan.verdict ? scan.verdict.level : ""), "Nima qilish kerak", scan.advice);
        box("sp-box good", "Ijobiy belgilar", scan.good);
      }
      if (scan) {
        const cov = scan.coverage && scan.coverage.total ? " Tekshiruv: " + scan.coverage.done + "/" + scan.coverage.total + "." : "";
        note.textContent = (scan.note || "") + cov + (e.shot && e.shot.ok && e.shot.via ? " Skrinshot: " + e.shot.via : "");
      }
      renderOsint(osBox, e, st);
      osBtn.disabled = !!e.osp;
      again.disabled = !!(e.sp || e.hp);
    }

    function watch() {
      const e = cache.get(href);
      if (!e) return;
      [e.sp, e.hp, e.osp].filter(Boolean).forEach(p => p.then(() => paint()));
    }
    paint();
    return {root: root_, paint, watch};
  }

  U.collapse = function (btn) {
    const p = panels.get(btn);
    if (!p) return;
    p.root.classList.add("hidden");
    btn.classList.remove("on");
    btn.setAttribute("aria-expanded", "false");
  };

  // deps: {api(path, {method, body}) -> Promise<json>}
  U.toggle = function (href, btn, deps) {
    let p = panels.get(btn);
    if (p) {
      const hidden = p.root.classList.contains("hidden");
      if (hidden) { p.root.classList.remove("hidden"); btn.classList.add("on"); btn.setAttribute("aria-expanded", "true"); p.paint(); }
      else U.collapse(btn);
      return;
    }
    p = build(href, btn, deps);
    panels.set(btn, p);
    btn.classList.add("on");
    btn.setAttribute("aria-expanded", "true");
    if (btn.parentNode) btn.parentNode.insertBefore(p.root, btn.nextSibling);
    ensure(href, deps, false);
    p.paint();
    p.watch();
  };

  U._cache = cache;
  if (typeof module !== "undefined" && module.exports) module.exports = U; else root.UrlScan = U;
})(typeof window !== "undefined" ? window : globalThis);
