"""«Scan» → chuqur OSINT (SpiderFoot uslubida), KALITSIZ va faqat PASSIV manbalar.

Modullar (panelda shu nomlar bilan chiqadi):
  🌐 Domain OSINT        — DNS yozuvlari (A/AAAA/NS/MX/TXT/CAA/SOA), DNSSEC, WHOIS/RDAP, aloqa emaillari
  🌍 IP Intelligence     — IP manzil, hosting/CDN, ASN, geolokatsiya, reverse DNS, RDAP tarmoq ma'lumoti
  🔎 Subdomain discovery — sertifikat shaffofligi (crt.sh, CertSpotter) + passiv DNS (Anubis, AlienVault OTX)
  🛡️ Security analysis   — HTTP xavfsizlik sarlavhalari, TLS, SPF/DMARC/DKIM/MTA-STS, subdomain takeover (dangling CNAME)
  🔗 Relationship mapping — domen ↔ subdomen ↔ IP ↔ ASN ↔ NS/MX ↔ email grafi
  📂 Data leaks          — Wayback Machine'da arxivlangan nozik fayl izlari (.env, .sql, .bak, .git ...)

Qoidalar: port skanerlash yo'q, zaiflikni ekspluatatsiya qilish yo'q, nozik yo'llarni (/.git, /.env) nishonga SO'RAMAYDI.
Nishonga faqat bitta oddiy GET (bosh sahifa) va http→https tekshiruvi boradi. Qolganlari — ochiq ma'lumot manbalari.
Nishon nomi uchinchi tomon manbalariga (crt.sh, OTX, ipwho.is, Wayback) yuboriladi — panelda ogohlantirish bor.
Ma'lumot buzilgan/yo'q bo'lsa modul «na» bo'ladi; hech qachon taxmin qilib to'ldirilmaydi.
"""
from __future__ import annotations

import ipaddress
import json
import re
import threading
import time
from concurrent.futures import Future, ThreadPoolExecutor
from urllib.parse import quote

from app.errors import ChatError
from app.services import urlscan as U
from app.services import urlscan_rules as R

TOTAL_BUDGET = 28.0
MAX_SUBS_KEEP = 500
MAX_SUBS_SHOW = 80
_OPOOL = ThreadPoolExecutor(max_workers=14, thread_name_prefix="osint")
_SEM = threading.BoundedSemaphore(2)
_inflight: "dict[str, Future]" = {}
_lock = threading.Lock()

_HOST_RE = re.compile(r"^(?=.{1,253}$)(?:[a-z0-9_](?:[a-z0-9_-]{0,61}[a-z0-9_])?\.)+[a-z0-9-]{2,63}$")

# Bu provayderlarga dangling CNAME (nishon NXDOMAIN) — subdomain takeover xavfi
TAKEOVER_SUFFIXES = (
    "github.io", "herokuapp.com", "herokudns.com", "azurewebsites.net", "cloudapp.net", "cloudapp.azure.com", "trafficmanager.net",
    "blob.core.windows.net", "azureedge.net", "s3.amazonaws.com", "s3-website", "elasticbeanstalk.com", "fastly.net", "myshopify.com",
    "ghost.io", "surge.sh", "bitbucket.io", "pantheonsite.io", "zendesk.com", "unbouncepages.com", "readme.io", "cargocollective.com",
    "helpjuice.com", "helpscoutdocs.com", "statuspage.io", "uservoice.com", "wpengine.com", "netlify.app", "vercel.app", "tumblr.com",
)
HOSTING = (   # (belgi, nom) — ASN/org matnida qidiriladi
    ("cloudflare", "Cloudflare (CDN/himoya)"), ("amazon", "Amazon AWS"), ("google", "Google Cloud"), ("microsoft", "Microsoft Azure"),
    ("akamai", "Akamai (CDN)"), ("fastly", "Fastly (CDN)"), ("hetzner", "Hetzner"), ("ovh", "OVH"), ("digitalocean", "DigitalOcean"),
    ("linode", "Linode/Akamai"), ("vultr", "Vultr"), ("contabo", "Contabo"), ("alibaba", "Alibaba Cloud"), ("tencent", "Tencent Cloud"),
    ("oracle", "Oracle Cloud"), ("github", "GitHub Pages"), ("fly.io", "Fly.io"), ("render", "Render"), ("vercel", "Vercel"),
    ("netlify", "Netlify"), ("ucell", "Ucell (UZ)"), ("uztelecom", "Uztelecom (UZ)"), ("sarkor", "Sarkor Telecom (UZ)"), ("uzonline", "UzOnline (UZ)"),
)
DKIM_SELECTORS = ("default", "google", "selector1", "selector2", "k1", "mail", "dkim", "s1")
SENSITIVE = re.compile(
    r".*(?:\.env|\.sql|\.bak|\.backup|\.old|\.swp|\.zip|\.tar\.gz|\.tgz|\.7z|\.rar|\.log|\.pem|\.key|\.htpasswd|\.DS_Store"
    r"|wp-config[^/]*|phpinfo[^/]*|id_rsa|credentials|dump[^/]*)(?:\?.*)?$|.*/\.(?:git|svn)/.*", re.I)
SENS_KIND = (("Muhit/kalit fayllari", re.compile(r"\.env|\.pem|\.key|id_rsa|credentials|\.htpasswd", re.I)),
             ("Ma'lumotlar bazasi/zaxira nusxalar", re.compile(r"\.sql|\.bak|\.backup|dump|\.zip|\.tar|\.tgz|\.7z|\.rar|\.old", re.I)),
             ("Versiya nazorati (.git/.svn)", re.compile(r"\.git/|\.svn/", re.I)),
             ("Konfiguratsiya/log", re.compile(r"wp-config|phpinfo|\.log|\.swp|\.DS_Store", re.I)))


# ------------------------------------------------------------------------------------------ yordamchilar

def _get(url: str, *, timeout: float = 9, max_bytes: int = 1_500_000, accept: str = "application/json") -> bytes | None:
    try:
        r = U.http_request(url, headers={"Accept": accept, "Accept-Encoding": "gzip"}, max_bytes=max_bytes, max_out=max_bytes * 3,
                           timeout=timeout, trusted=True, max_hops=2)
    except Exception:
        return None
    return r.body if r.status == 200 and r.body else None


def _get_json(url: str, **kw):
    raw = _get(url, **kw)
    if not raw:
        return None
    try:
        return json.loads(raw.decode("utf-8", "replace"))
    except ValueError:
        return None


def _doh(name: str, rtype: str) -> dict | None:
    return U._doh("cloudflare-dns.com", "/dns-query", name, rtype)


def _answers(j: dict | None, rtype: int) -> list[str]:
    out = []
    for a in (j or {}).get("Answer", []) or []:
        if isinstance(a, dict) and a.get("type") == rtype:
            out.append(str(a.get("data", "")).strip().strip('"').rstrip("."))
    return out


def _txt_all(j: dict | None) -> list[str]:
    return [re.sub(r'"\s*"', "", str(a.get("data", ""))).strip().strip('"') for a in (j or {}).get("Answer", []) or []
            if isinstance(a, dict) and a.get("type") == 16]


def norm_sub(name: str, dom: str) -> str | None:
    n = name.strip().lower().rstrip(".")
    while n.startswith("*."):
        n = n[2:]
    if not n or (n != dom and not n.endswith("." + dom)) or not _HOST_RE.match(n):
        return None
    return n


def host_label(org: str) -> str:
    low = (org or "").lower()
    for key, name in HOSTING:
        if key in low:
            return name
    return ""


def parse_spf(txts: list[str]) -> dict:
    spf = [t for t in txts if t.lower().startswith("v=spf1")]
    if not spf:
        return {"present": False}
    rec = spf[0].lower()
    mech = re.search(r"\s([-~?+]?)all\b", rec)
    lookups = len(re.findall(r"\b(?:include:|a\b|mx\b|ptr\b|exists:|redirect=)", rec))
    return {"present": True, "multiple": len(spf) > 1, "all": mech.group(1) or "+" if mech else "", "lookups": lookups,
            "includes": re.findall(r"include:([^\s]+)", rec)[:8], "raw": spf[0][:200]}


def parse_dmarc(txts: list[str]) -> dict:
    d = [t for t in txts if t.lower().startswith("v=dmarc1")]
    if not d:
        return {"present": False}
    tags = {k.strip().lower(): v.strip() for k, _, v in (x.partition("=") for x in d[0].split(";")) if k.strip()}
    return {"present": True, "p": tags.get("p", "").lower(), "sp": tags.get("sp", "").lower(), "pct": tags.get("pct", "100"),
            "rua": tags.get("rua", "")[:120], "raw": d[0][:200]}


def audit_headers(h: dict, *, https: bool) -> list[dict]:
    """Javob sarlavhalari bo'yicha topilmalar: {"sev","text"}."""
    f: list[dict] = []
    h = {str(k).lower(): str(v) for k, v in h.items()}

    def add(sev, text):
        f.append({"sev": sev, "text": text})
    hs = h.get("strict-transport-security", "")
    if https:
        if not hs:
            add("warn", "HSTS yo'q — brauzer har doim https ga o'tishga majburlanmaydi")
        else:
            m = re.search(r"max-age=(\d+)", hs, re.I)
            if m and int(m.group(1)) < 15552000:
                add("info", f"HSTS muddati qisqa ({int(m.group(1)) // 86400} kun, tavsiya ≥180)")
            if "includesubdomains" not in hs.lower():
                add("info", "HSTS includeSubDomains siz")
    csp = h.get("content-security-policy", "")
    if not csp:
        add("warn", "Content-Security-Policy yo'q — XSS ga qarshi himoya qatlami yo'q")
    elif re.search(r"script-src[^;]*('unsafe-inline'|'unsafe-eval'|\s\*(\s|;|$))", csp, re.I):
        add("info", "CSP zaif: script-src da 'unsafe-inline'/'unsafe-eval'/* bor")
    if "x-frame-options" not in h and "frame-ancestors" not in csp.lower():
        add("warn", "Clickjacking himoyasi yo'q (X-Frame-Options yoki CSP frame-ancestors)")
    if h.get("x-content-type-options", "").lower() != "nosniff":
        add("info", "X-Content-Type-Options: nosniff yo'q")
    if "referrer-policy" not in h:
        add("info", "Referrer-Policy yo'q")
    if "permissions-policy" not in h and "feature-policy" not in h:
        add("info", "Permissions-Policy yo'q")
    srv = h.get("server", "")
    if re.search(r"\d+\.\d+", srv):
        add("warn", f"Server versiyasi oshkor: {srv[:60]} — ma'lum zaifliklarni qidirishni osonlashtiradi")
    for k in ("x-powered-by", "x-aspnet-version", "x-aspnetmvc-version", "x-generator"):
        if h.get(k):
            add("info", f"{k}: {h[k][:50]} — texnologiya oshkor")
    if h.get("access-control-allow-origin", "").strip() == "*" and h.get("access-control-allow-credentials", "").lower() == "true":
        add("bad", "CORS: Allow-Origin * va Allow-Credentials true birga — xavfli sozlama")
    sc = h.get("set-cookie", "")
    if sc:
        cookies = [c for c in re.split(r"\n|,(?=\s*[A-Za-z0-9_.-]+=)", sc) if "=" in c]
        miss = {"Secure": 0, "HttpOnly": 0, "SameSite": 0}
        for c in cookies:
            for k in miss:
                if k.lower() not in c.lower():
                    miss[k] += 1
        bad = [f"{k} ({n}/{len(cookies)})" for k, n in miss.items() if n and (k != "Secure" or https)]
        if bad:
            add("warn", "Cookie bayroqlari yetishmaydi: " + ", ".join(bad))
    return f


def takeover_match(cname: str) -> str | None:
    c = cname.lower().rstrip(".")
    for s in TAKEOVER_SUFFIXES:
        if c.endswith(s) or (s == "s3-website" and "s3-website" in c):
            return s
    return None


def classify_wayback(urls: list[str]) -> dict[str, list[str]]:
    out: dict[str, list[str]] = {}
    for u in urls:
        if not SENSITIVE.match(u):
            continue
        for name, rx in SENS_KIND:
            if rx.search(u):
                out.setdefault(name, []).append(u)
                break
    return out


def build_graph(dom: str, ips: dict, subs: list[str], sub_ips: dict, ns: list[str], mx: list[str], emails: list[str], org: str = "") -> dict:
    nodes: dict[str, dict] = {}
    edges: list[dict] = []

    def node(i, label, typ):
        if i not in nodes and len(nodes) < 70:
            nodes[i] = {"id": i, "label": label[:40], "type": typ}
        return i in nodes

    def edge(a, b, rel):
        if a in nodes and b in nodes and a != b and not any(e["a"] == a and e["b"] == b for e in edges):
            edges.append({"a": a, "b": b, "rel": rel})
    node("d:" + dom, dom, "domain")
    for ip, info in ips.items():
        if node("i:" + ip, ip, "ip"):
            edge("d:" + dom, "i:" + ip, "A")
            asn = (info or {}).get("asn")
            if asn and node("a:" + asn, asn + (" " + info["org"][:18] if info.get("org") else ""), "asn"):
                edge("i:" + ip, "a:" + asn, "ASN")
    for s in subs[:24]:
        if s != dom and node("s:" + s, s, "sub"):
            edge("d:" + dom, "s:" + s, "sub")
            for ip in sub_ips.get(s, [])[:2]:
                if node("i:" + ip, ip, "ip"):
                    edge("s:" + s, "i:" + ip, "A")
    for n in ns[:6]:
        if node("n:" + n, n, "ns"):
            edge("d:" + dom, "n:" + n, "NS")
    for m in mx[:6]:
        if node("m:" + m, m, "mx"):
            edge("d:" + dom, "m:" + m, "MX")
    for e in emails[:5]:
        if node("e:" + e, e, "email"):
            edge("d:" + dom, "e:" + e, "kontakt")
    if org and node("o:" + org, org, "org"):
        edge("d:" + dom, "o:" + org, "egasi")
    return {"nodes": list(nodes.values()), "edges": edges}


# ------------------------------------------------------------------------------------------ manbalar

def subdomains_step(dom: str) -> dict:
    """Sertifikat shaffofligi va passiv DNS orqali subdomenlar. Qaytadi: {"subs": set, "sources": {nom: soni|None}, "pdns": {host: [ip]}}"""
    found: dict[str, set[str]] = {}
    pdns: dict[str, set[str]] = {}

    def crt():
        j = _get_json(f"https://crt.sh/?q=%25.{quote(dom)}&output=json", timeout=14, max_bytes=6_000_000)
        if not isinstance(j, list):
            return None
        out = set()
        for row in j[:20000]:
            for n in str((row or {}).get("name_value", "")).split("\n"):
                s = norm_sub(n, dom)
                if s:
                    out.add(s)
        return out

    def spotter():
        j = _get_json(f"https://api.certspotter.com/v1/issuances?domain={quote(dom)}&include_subdomains=true&expand=dns_names", timeout=12)
        if not isinstance(j, list):
            return None
        return {s for row in j[:5000] for n in (row or {}).get("dns_names", []) or [] if (s := norm_sub(str(n), dom))}

    def anubis():
        j = _get_json(f"https://jldc.me/anubis/subdomains/{quote(dom)}", timeout=10)
        if not isinstance(j, list):
            return None
        return {s for n in j[:5000] if (s := norm_sub(str(n), dom))}

    def otx():
        j = _get_json(f"https://otx.alienvault.com/api/v1/indicators/domain/{quote(dom)}/passive_dns", timeout=12)
        rows = (j or {}).get("passive_dns") if isinstance(j, dict) else None
        if not isinstance(rows, list):
            return None
        out = set()
        for r in rows[:5000]:
            s = norm_sub(str((r or {}).get("hostname", "")), dom)
            if s:
                out.add(s)
                addr = str((r or {}).get("address", ""))
                try:
                    ipaddress.ip_address(addr)
                    pdns.setdefault(s, set()).add(addr)
                except ValueError:
                    pass
        return out

    srcs = {"crt.sh": crt, "CertSpotter": spotter, "Anubis": anubis, "AlienVault OTX": otx}
    futs = {k: _OPOOL.submit(fn) for k, fn in srcs.items()}
    counts: dict[str, int | None] = {}
    for k, f in futs.items():
        try:
            res = f.result(timeout=18)
        except Exception:
            res = None
        counts[k] = None if res is None else len(res)
        for s in res or ():
            found.setdefault(s, set()).add(k)
    subs = sorted(found, key=lambda s: (s.count("."), s))[:MAX_SUBS_KEEP]
    return {"subs": subs, "sources": counts, "by": {s: sorted(found[s]) for s in subs[:MAX_SUBS_SHOW]},
            "pdns": {k: sorted(v)[:4] for k, v in pdns.items()}}


def dns_step(dom: str) -> dict:
    types = {"A": 1, "AAAA": 28, "NS": 2, "MX": 15, "TXT": 16, "CAA": 257, "SOA": 6}
    futs = {k: _OPOOL.submit(_doh, dom, k) for k in types}
    futs["DNSKEY"] = _OPOOL.submit(_doh, dom, "DNSKEY")
    futs["_dmarc"] = _OPOOL.submit(_doh, "_dmarc." + dom, "TXT")
    futs["_mta"] = _OPOOL.submit(_doh, "_mta-sts." + dom, "TXT")
    dk = {s: _OPOOL.submit(_doh, f"{s}._domainkey.{dom}", "TXT") for s in DKIM_SELECTORS}
    res = {}
    for k, f in futs.items():
        try:
            res[k] = f.result(timeout=8)
        except Exception:
            res[k] = None
    out = {"A": _answers(res["A"], 1), "AAAA": _answers(res["AAAA"], 28), "NS": _answers(res["NS"], 2),
           "MX": [re.sub(r"^\d+\s+", "", x) for x in _answers(res["MX"], 15)], "TXT": _txt_all(res["TXT"]),
           "CAA": _answers(res["CAA"], 257), "SOA": _answers(res["SOA"], 6), "dnssec": bool(_answers(res["DNSKEY"], 48)) or bool((res["A"] or {}).get("AD")),
           "dmarc_txt": _txt_all(res["_dmarc"]), "mta_sts": _txt_all(res["_mta"]), "ok": res["A"] is not None, "nxdomain": (res["A"] or {}).get("Status") == 3,
           "dkim": []}
    for s, f in dk.items():
        try:
            if any("p=" in t for t in _txt_all(f.result(timeout=6))):
                out["dkim"].append(s)
        except Exception:
            pass
    return out


def ip_step(ip: str) -> dict:
    info: dict = {"ip": ip}
    f_geo = _OPOOL.submit(_get_json, f"https://ipwho.is/{ip}", timeout=8, max_bytes=60000)
    f_rdap = _OPOOL.submit(_get_json, f"https://rdap.org/ip/{ip}", timeout=9, max_bytes=300000)
    f_asn = _OPOOL.submit(U.asn_step, ip) if ":" not in ip else None
    ptr = None
    if ":" not in ip:
        rev = ".".join(reversed(ip.split("."))) + ".in-addr.arpa"
        f_ptr = _OPOOL.submit(_doh, rev, "PTR")
        try:
            ptr = _answers(f_ptr.result(timeout=6), 12)
        except Exception:
            ptr = None
    info["ptr"] = ptr or []
    try:
        g = f_geo.result(timeout=10)
    except Exception:
        g = None
    if isinstance(g, dict) and g.get("success") is not False and g.get("country"):
        c = g.get("connection") or {}
        info.update({"country": g.get("country", ""), "cc": g.get("country_code", ""), "region": g.get("region", ""), "city": g.get("city", ""),
                     "lat": g.get("latitude"), "lon": g.get("longitude"), "tz": (g.get("timezone") or {}).get("id", ""),
                     "isp": c.get("isp", ""), "org": c.get("org", ""), "asn": ("AS" + str(c["asn"])) if c.get("asn") else ""})
    if f_asn is not None:
        try:
            a = f_asn.result(timeout=9)
        except Exception:
            a = None
        if a:
            info.setdefault("asn", a["asn"])
            info["asn"] = info.get("asn") or a["asn"]
            info["prefix"] = a.get("prefix", "")
            info["asn_name"] = a.get("name", "")
            info.setdefault("cc", a.get("country", ""))
    try:
        r = f_rdap.result(timeout=10)
    except Exception:
        r = None
    if isinstance(r, dict):
        info["net_name"] = str(r.get("name", ""))[:60]
        info["net_range"] = (str(r.get("startAddress", "")) + " – " + str(r.get("endAddress", ""))).strip(" –")[:80]
        info["net_type"] = str(r.get("type", ""))[:40]
    info["host_label"] = host_label(" ".join(str(info.get(k, "")) for k in ("org", "isp", "asn_name", "net_name")))
    return info


def web_step(host: str) -> dict:
    out: dict = {"findings": [], "ok": False}
    f_http = _OPOOL.submit(lambda: U.http_request(f"http://{host}/", max_hops=0, timeout=6, cert_fallback=True, max_bytes=20000))
    f_tls = _OPOOL.submit(U.tls_step, host, 443)
    f_sec = _OPOOL.submit(_get, f"https://{host}/.well-known/security.txt", timeout=6, max_bytes=20000, accept="text/plain")
    f_rob = _OPOOL.submit(_get, f"https://{host}/robots.txt", timeout=6, max_bytes=60000, accept="text/plain")
    try:
        r = U.http_request(f"https://{host}/", max_hops=3, timeout=8, cert_fallback=True, max_bytes=60000)
    except Exception:
        r = None
    if r is not None and r.status:
        out["ok"] = True
        out["status"], out["final"] = r.status, r.url
        out["server"] = str(r.headers.get("server", ""))[:60]
        fh = urllib_host(r.url)
        out["findings"] += audit_headers(r.headers, https=r.url.startswith("https://"))
        m = re.search(rb'<meta[^>]+name=["\']generator["\'][^>]+content=["\']([^"\']{1,60})', r.body[:60000], re.I)
        if m:
            out["generator"] = m.group(1).decode("utf-8", "replace")
            out["findings"].append({"sev": "info", "text": f"Generator: {out['generator']} — CMS/texnologiya oshkor"})
        out["final_host"] = fh
    try:
        h = f_http.result(timeout=8)
        if h.status in (200, 204) and not str(h.headers.get("location", "")):
            out["findings"].append({"sev": "warn", "text": "http:// ochiq va https ga yo'naltirmaydi — ma'lumotlar shifrlanmasdan uzatilishi mumkin"})
        elif h.status in (301, 302, 307, 308) and str(h.headers.get("location", "")).lower().startswith("https://"):
            out["http_redirect"] = True
    except Exception:
        pass
    try:
        t = f_tls.result(timeout=8)
        out["tls"] = {k: t.get(k) for k in ("version", "cipher", "issuer", "subject", "verified", "error", "self_signed")}
        out["tls"]["not_after"] = t["not_after"].strftime("%Y-%m-%d") if t.get("not_after") else ""
        if t.get("not_after"):
            days = (t["not_after"] - U._now()).days
            out["tls"]["days_left"] = days
            if days < 0:
                out["findings"].append({"sev": "bad", "text": "SSL sertifikat muddati tugagan"})
            elif days < 14:
                out["findings"].append({"sev": "warn", "text": f"SSL sertifikat {days} kundan keyin tugaydi"})
        if t.get("version") in ("TLSv1", "TLSv1.1", "SSLv3"):
            out["findings"].append({"sev": "bad", "text": f"Eskirgan TLS versiyasi: {t['version']}"})
        if t.get("error") and not t.get("verified"):
            out["findings"].append({"sev": "bad", "text": "SSL sertifikat tekshiruvdan o'tmadi: " + str(t["error"])[:80]})
    except Exception:
        out["tls"] = None
    try:
        sec = f_sec.result(timeout=8)
        if sec and b"contact:" in sec.lower():
            out["security_txt"] = True
            out["emails"] = sorted(set(re.findall(r"(?i)contact:\s*mailto:([^\s]+)", sec.decode("utf-8", "replace"))))[:4]
        else:
            out["findings"].append({"sev": "info", "text": "security.txt yo'q — zaiflik haqida xabar berish kanali ko'rsatilmagan"})
    except Exception:
        pass
    try:
        rob = f_rob.result(timeout=8)
        if rob:
            dis = [x.split(":", 1)[1].strip() for x in rob.decode("utf-8", "replace").splitlines() if x.lower().startswith("disallow:") and x.split(":", 1)[1].strip() not in ("", "/")]
            hot = [d for d in dis if re.search(r"admin|backup|private|secret|internal|config|\.git|dump|staging|test", d, re.I)]
            out["robots_hot"] = hot[:6]
            if hot:
                out["findings"].append({"sev": "info", "text": "robots.txt nozik ko'rinadigan yo'llarni ko'rsatadi: " + ", ".join(hot[:4])})
    except Exception:
        pass
    return out


def urllib_host(url: str) -> str:
    m = re.match(r"^https?://([^/:?#]+)", url or "", re.I)
    return (m.group(1) if m else "").lower()


def email_findings(d: dict) -> tuple[list[dict], dict]:
    f: list[dict] = []
    spf, dm = parse_spf(d["TXT"]), parse_dmarc(d["dmarc_txt"])
    has_mail = bool(d["MX"])
    if has_mail or spf["present"]:
        if not spf["present"]:
            f.append({"sev": "warn", "text": "SPF yo'q — domen nomidan soxta xat yuborish osonlashadi"})
        else:
            if spf["all"] in ("+", "?", ""):
                f.append({"sev": "bad" if spf["all"] == "+" else "warn", "text": "SPF zaif: ‘all’ mexanizmi qat'iy emas (-all kerak)"})
            elif spf["all"] == "~":
                f.append({"sev": "info", "text": "SPF ~all (softfail) — -all tavsiya etiladi"})
            if spf["lookups"] > 10:
                f.append({"sev": "warn", "text": f"SPF DNS so'rovlari limitdan oshgan ({spf['lookups']} > 10)"})
            if spf.get("multiple"):
                f.append({"sev": "warn", "text": "Bir nechta SPF yozuvi bor — bu SPF ni buzadi"})
        if not dm["present"]:
            f.append({"sev": "warn", "text": "DMARC yo'q — soxta xatlar rad etilmaydi va hisobot kelmaydi"})
        elif dm["p"] == "none":
            f.append({"sev": "info", "text": "DMARC p=none — faqat monitoring, soxta xatlar baribir o'tadi"})
        if not d["dkim"]:
            f.append({"sev": "info", "text": "Keng tarqalgan DKIM selektorlari topilmadi (boshqa nom ishlatilayotgan bo'lishi mumkin)"})
    if not d["dnssec"]:
        f.append({"sev": "info", "text": "DNSSEC yoqilmagan"})
    if not d["CAA"]:
        f.append({"sev": "info", "text": "CAA yozuvi yo'q — istalgan sertifikat markazi sertifikat chiqara oladi"})
    return f, {"spf": spf, "dmarc": dm}


def takeover_step(subs: list[str]) -> list[dict]:
    cand = [s for s in subs if s.count(".") >= 1][:40]
    futs = {s: _OPOOL.submit(_doh, s, "CNAME") for s in cand}
    chk = {}
    for s, f in futs.items():
        try:
            cn = _answers(f.result(timeout=8), 5)
        except Exception:
            cn = []
        if cn:
            prov = takeover_match(cn[0])
            if prov:
                chk[s] = (cn[0], prov, _OPOOL.submit(_doh, cn[0], "A"))
    out = []
    for s, (cn, prov, f) in chk.items():
        try:
            j = f.result(timeout=8)
        except Exception:
            continue
        if j and j.get("Status") == 3:
            out.append({"sev": "bad", "text": f"Subdomain takeover xavfi: {s} → {cn} ({prov}) mavjud emas (NXDOMAIN)"})
    return out


def wayback_step(dom: str) -> dict | None:
    flt = quote(SENSITIVE.pattern.replace("(?i)", ""), safe="")
    raw = _get(f"https://web.archive.org/cdx/search/cdx?url={quote(dom)}&matchType=domain&fl=original&collapse=urlkey&limit=3000&filter=original:{flt}",
               timeout=14, max_bytes=800_000, accept="text/plain")
    if raw is None:
        return None
    urls = [u.strip() for u in raw.decode("utf-8", "replace").splitlines() if u.strip()]
    return {"total": len(urls), "kinds": classify_wayback(urls)}


# ------------------------------------------------------------------------------------------ yig'ish

def _mod(mid, title, icon, sub, status, value, rows=None, lst=None):
    return {"id": mid, "title": title, "icon": icon, "sub": sub, "status": status, "value": value, "rows": rows or [], "list": lst or []}


def _worst(fs):
    return "bad" if any(x["sev"] == "bad" for x in fs) else "warn" if any(x["sev"] == "warn" for x in fs) else "ok"


def run(raw: str) -> dict:
    t0 = time.monotonic()
    t = U.parse_target(raw)
    host = t.host
    if t.is_ip:
        try:
            U.resolve_public(host)
        except Exception:
            raise ChatError("Ichki yoki noto'g'ri IP manzilni tekshirib bo'lmaydi", 400) from None
    elif "." not in host:
        raise ChatError("Domen noto'g'ri", 400)
    kind = "ip" if t.is_ip else "domain"
    dom = host if kind == "ip" else (host if R.free_host_root(host) else R.registrable(host))
    left = lambda: max(1.0, TOTAL_BUDGET - (time.monotonic() - t0))

    findings: list[dict] = []
    mods: list[dict] = []
    emails: set[str] = set()
    ips: dict[str, dict] = {}
    sub_ips: dict[str, list[str]] = {}
    subs: list[str] = []
    ns: list[str] = []
    mx: list[str] = []
    org = ""

    f_sub = _OPOOL.submit(subdomains_step, dom) if kind == "domain" else None
    f_dns = _OPOOL.submit(dns_step, dom) if kind == "domain" else None
    f_web = _OPOOL.submit(web_step, host) if kind == "domain" else None
    f_way = _OPOOL.submit(wayback_step, dom) if kind == "domain" else None
    f_who = _OPOOL.submit(U.whois_step, U.parse_target(dom)) if kind == "domain" else None

    def get(f, default=None, to=None):
        if f is None:
            return default
        try:
            return f.result(timeout=min(left(), to or left()))
        except Exception:
            return default

    # ---------- DNS / WHOIS
    dns = get(f_dns, None, 14)
    who = get(f_who, None, 14) or {}
    if kind == "domain":
        if dns and dns["ok"] and not dns["nxdomain"]:
            ns, mx = dns["NS"], dns["MX"]
            for ip in (dns["A"] + dns["AAAA"])[:6]:
                ips[ip] = {}
            rows = [["Domen", dom], ["A", ", ".join(dns["A"]) or "—"], ["AAAA", ", ".join(dns["AAAA"]) or "—"], ["NS", ", ".join(ns) or "—"],
                    ["MX", ", ".join(mx) or "—"], ["SOA", (dns["SOA"][0] if dns["SOA"] else "—")[:90]], ["CAA", ", ".join(dns["CAA"]) or "yo'q"],
                    ["DNSSEC", "yoqilgan" if dns["dnssec"] else "yoqilmagan"]]
            txt_show = [x[:90] for x in dns["TXT"] if not x.lower().startswith(("v=spf1", "google-site", "ms=", "facebook-domain"))][:4]
            if txt_show:
                rows.append(["TXT", " | ".join(txt_show)])
            org = str(who.get("registrar") or who.get("org") or "")[:40]
            for k, lab in (("registrar", "Registrator"), ("created", "Yaratilgan"), ("expires", "Tugaydi"), ("org", "Tashkilot"), ("country", "Davlat")):
                v = who.get(k)
                if v:
                    rows.append([lab, str(v.date() if hasattr(v, "date") else v)[:60]])
            for em in who.get("emails", []) or []:
                emails.add(str(em)[:60])
            if emails:
                rows.append(["Aloqa emaillari", ", ".join(sorted(emails)[:4])])
            if not (who.get("registrar") or who.get("created")):
                rows.append(["WHOIS", "ma'lumot topilmadi (ccTLD yoki yashirilgan)"])
            mods.append(_mod("domain", "Domain OSINT", "🌐", "Domen nomi, DNS yozuvlari, egasi va aloqa ma'lumotlari", "ok", f"{len(ips)} IP · {len(ns)} NS", rows))
        else:
            mods.append(_mod("domain", "Domain OSINT", "🌐", "Domen nomi, DNS yozuvlari, egasi va aloqa ma'lumotlari", "na" if not (dns and dns["nxdomain"]) else "bad",
                             "DNS topilmadi" if dns and dns["nxdomain"] else "—", [["Holat", "domen mavjud emas" if dns and dns["nxdomain"] else "DNS so'rovi javob bermadi"]]))
    else:
        ips[host] = {}
        mods.append(_mod("domain", "Domain OSINT", "🌐", "Domen nomi, DNS yozuvlari, egasi va aloqa ma'lumotlari", "na", "IP", [["Holat", "IP manzil kiritilgan — domen ma'lumotlari yo'q"]]))

    # ---------- IP Intelligence
    ip_list = list(ips)[:4]
    ip_res = {ip: get(_OPOOL.submit(ip_step, ip), {"ip": ip}, 16) for ip in ip_list}
    if kind == "ip":
        j = _get_json(f"https://otx.alienvault.com/api/v1/indicators/IPv4/{host}/passive_dns", timeout=10) if ":" not in host else None
        rows_p = (j or {}).get("passive_dns") if isinstance(j, dict) else None
        if isinstance(rows_p, list):
            names = sorted({str(r.get("hostname", ""))[:60] for r in rows_p[:500] if r.get("hostname")})[:25]
            if names:
                ip_res[host]["passive"] = names
    rows, ipmods = [], []
    for ip, info in ip_res.items():
        ips[ip] = info
        if not info.get("country") and not info.get("asn"):
            rows.append([ip, "ma'lumot topilmadi"])
            continue
        lab = info.get("host_label")
        rows.append([ip, " · ".join(x for x in (info.get("country"), info.get("city"), info.get("asn"), info.get("org") or info.get("asn_name"), lab) if x)[:140]])
        if info.get("ptr"):
            rows.append(["  Reverse DNS", ", ".join(info["ptr"])[:100]])
        if info.get("net_name"):
            rows.append(["  Tarmoq (RDAP)", f"{info['net_name']} · {info.get('net_range', '')}"[:120]])
        if info.get("prefix"):
            rows.append(["  Prefiks", info["prefix"]])
        if info.get("lat") is not None:
            rows.append(["  Koordinata", f"{info['lat']}, {info['lon']} ({info.get('tz', '')})"])
        if info.get("passive"):
            rows.append(["  Shu IP dagi domenlar", ", ".join(info["passive"][:8])])
        if lab and "CDN" in lab:
            findings.append({"sev": "info", "module": "ip", "text": f"{ip}: {lab} orqasida — haqiqiy server IP si yashirin bo'lishi mumkin"})
    countries = sorted({i.get("cc") for i in ip_res.values() if i.get("cc")})
    mods.append(_mod("ip", "IP Intelligence", "🌍", "IP manzil, hosting, ASN va geolokatsiya ma'lumotlarini izlaydi", "ok" if rows and any("topilmadi" not in r[1] for r in rows) else "na",
                     f"{len(ip_res)} IP" + (" · " + "/".join(countries) if countries else ""), rows or [["Holat", "IP topilmadi"]]))

    # ---------- Subdomains
    sd = get(f_sub, None, 22)
    if kind == "domain":
        if sd is not None and any(v is not None for v in sd["sources"].values()):
            subs = sd["subs"]
            sub_ips = {k: v for k, v in sd["pdns"].items()}
            rows = [["Topildi", f"{len(subs)} ta"]] + [[k, "ishlamadi" if v is None else f"{v} ta"] for k, v in sd["sources"].items()]
            lst = [f"{s}  ·  {', '.join(sd['by'].get(s, []))}" for s in subs[:MAX_SUBS_SHOW]]
            interesting = [s for s in subs if re.search(r"(^|[.-])(admin|dev|test|stage|staging|beta|internal|vpn|jenkins|git|gitlab|panel|old|backup|db|sql|phpmyadmin|ftp)([.-]|\d|$)", s)]
            if interesting:
                rows.append(["Qiziq nomlar", ", ".join(interesting[:8])])
                findings.append({"sev": "info", "module": "subs", "text": f"Ichki/test xizmatlarga o'xshash subdomenlar: {', '.join(interesting[:4])} — tashqariga ochiq bo'lmasligi kerak"})
            mods.append(_mod("subs", "Subdomain discovery", "🔎", "Domenning subdomenlarini aniqlaydi", "ok", f"{len(subs)} ta", rows, lst))
        else:
            mods.append(_mod("subs", "Subdomain discovery", "🔎", "Domenning subdomenlarini aniqlaydi", "na", "—", [["Holat", "ochiq manbalar javob bermadi (keyinroq urinib ko'ring)"]]))
    else:
        mods.append(_mod("subs", "Subdomain discovery", "🔎", "Domenning subdomenlarini aniqlaydi", "na", "IP", [["Holat", "IP uchun subdomen yo'q"]]))

    # subdomen IP lari (munosabat grafi uchun): passiv DNS da bo'lmaganlarni qisqa DoH bilan
    if subs:
        need = [s for s in subs[:14] if s not in sub_ips]
        fut = {s: _OPOOL.submit(_doh, s, "A") for s in need[:10]}
        for s, f in fut.items():
            try:
                a = _answers(f.result(timeout=6), 1)
                if a:
                    sub_ips[s] = a[:2]
            except Exception:
                pass

    # ---------- Security analysis
    web = get(f_web, None, 20)
    sec_rows, sec_f = [], []
    if kind == "domain":
        if web and web.get("ok"):
            sec_f += web["findings"]
            sec_rows += [["HTTP holat", str(web.get("status"))], ["Yakuniy URL", str(web.get("final", ""))[:100]]]
            if web.get("server"):
                sec_rows.append(["Server", web["server"]])
            if web.get("http_redirect"):
                sec_rows.append(["http → https", "yo'naltiradi ✓"])
            tl = web.get("tls")
            if tl:
                sec_rows.append(["TLS", f"{tl.get('version', '')} · {tl.get('issuer', '')} · {tl.get('not_after', '')}"[:100]])
            if web.get("emails"):
                emails.update(web["emails"])
        if dns and dns["ok"] and not dns["nxdomain"]:
            ef, ed = email_findings(dns)
            sec_f += ef
            sec_rows += [["SPF", ed["spf"].get("raw", "yo'q")[:100] if ed["spf"]["present"] else "yo'q"],
                         ["DMARC", ed["dmarc"].get("raw", "yo'q")[:100] if ed["dmarc"]["present"] else "yo'q"],
                         ["DKIM", ", ".join(dns["dkim"]) or "topilmadi"], ["MTA-STS", "bor" if dns["mta_sts"] else "yo'q"]]
        if subs:
            sec_f += get(_OPOOL.submit(takeover_step, subs), [], 14)
    for x in sec_f:
        findings.append({"sev": x["sev"], "module": "security", "text": x["text"]})
        sec_rows.append([{"bad": "⚠", "warn": "!", "info": "i"}[x["sev"]], x["text"]])
    st = _worst(sec_f)
    mods.append(_mod("security", "Security analysis", "🛡️", "Ochiq zaifliklar va xavfsizlik muammolarini izlaydi", st if (sec_rows or sec_f) else "na",
                     "Toza" if st == "ok" and sec_rows else (f"{len([x for x in sec_f if x['sev'] != 'info'])} muammo" if sec_f else "—"),
                     sec_rows or [["Holat", "tekshirib bo'lmadi"]]))

    # ---------- Data leaks (Wayback)
    wb = get(f_way, None, 16)
    if kind == "domain":
        if wb is None:
            mods.append(_mod("leaks", "Data leaks", "📂", "Ochiq manbalardagi sizib chiqqan ma'lumotlar izlarini tekshiradi", "na", "—",
                             [["Holat", "Wayback Machine javob bermadi"]]))
        else:
            rows = [["Manba", "Wayback Machine (arxiv)"], ["Nozik fayl izlari", f"{wb['total']} ta"]]
            lst = []
            for kname, urls in wb["kinds"].items():
                rows.append([kname, f"{len(urls)} ta"])
                lst += [u[:140] for u in urls[:4]]
            if wb["total"]:
                findings.append({"sev": "warn", "module": "leaks", "text": f"Wayback arxivida nozik fayllar izi: {wb['total']} ta ({', '.join(wb['kinds'])}) — hozir ham ochiq-yo'qligini egasi tekshirishi kerak"})
            rows.append(["Eslatma", "arxivdagi iz ≠ hozir ochiq degani; parol/email bazalari (HIBP va b.) kalit talab qiladi — kiritilmagan"])
            mods.append(_mod("leaks", "Data leaks", "📂", "Ochiq manbalardagi sizib chiqqan ma'lumotlar izlarini tekshiradi",
                             "warn" if wb["total"] else "ok", f"{wb['total']} iz" if wb["total"] else "Iz topilmadi", rows, lst[:16]))
    else:
        mods.append(_mod("leaks", "Data leaks", "📂", "Ochiq manbalardagi sizib chiqqan ma'lumotlar izlarini tekshiradi", "na", "IP", [["Holat", "IP uchun tekshirilmaydi"]]))

    # ---------- Relationship mapping
    graph = build_graph(dom, ips, subs, sub_ips, ns, mx, sorted(emails), org)
    kinds = {}
    for n in graph["nodes"]:
        kinds[n["type"]] = kinds.get(n["type"], 0) + 1
    names = {"domain": "domen", "sub": "subdomen", "ip": "IP", "asn": "ASN", "ns": "NS", "mx": "MX", "email": "email", "org": "tashkilot"}
    rows = [["Obyektlar", str(len(graph["nodes"]))], ["Aloqalar", str(len(graph["edges"]))]] + [[names.get(k, k), str(v)] for k, v in kinds.items()]
    mods.append(_mod("graph", "Relationship mapping", "🔗", "Domen, IP, email va boshqa obyektlar o'rtasidagi aloqalarni ko'rsatadi",
                     "ok" if len(graph["nodes"]) > 1 else "na", f"{len(graph['nodes'])} obyekt", rows))

    order = {"bad": 0, "warn": 1, "info": 2}
    findings.sort(key=lambda x: order[x["sev"]])
    cnt = {s: len([x for x in findings if x["sev"] == s]) for s in ("bad", "warn", "info")}
    order_ids = ["domain", "ip", "subs", "security", "graph", "leaks"]
    mods.sort(key=lambda m: order_ids.index(m["id"]))
    return {"ok": True, "target": host, "domain": dom, "kind": kind, "modules": mods, "findings": findings[:40], "graph": graph,
            "summary": {"subdomains": len(subs), "ips": len(ips), "findings": cnt}, "scanned_at": int(time.time()),
            "took_ms": int((time.monotonic() - t0) * 1000),
            "note": "Passiv OSINT: ochiq manbalar (crt.sh, CertSpotter, Anubis, OTX, ipwho.is, RDAP, Wayback). Nishon nomi shu manbalarga yuboriladi."}


def scan(raw: str, fresh: bool = False) -> dict:
    t = U.parse_target(raw)
    key = ("osint", t.host)
    if not fresh:
        hit = U._cget(key)
        if hit:
            return hit
    with _lock:
        fut = _inflight.get(key[1])
        owner = fut is None
        if owner:
            fut = _inflight[key[1]] = Future()
    if not owner:
        try:
            return fut.result(timeout=45)
        except ChatError:
            raise
        except Exception:
            raise ChatError("OSINT tekshiruvi bajarilmadi, qayta urinib ko'ring", 503) from None
    try:
        if not _SEM.acquire(timeout=3):
            raise ChatError("OSINT band, bir ozdan keyin urinib ko'ring", 503)
        try:
            res = run(raw)
        finally:
            _SEM.release()
        U._cput(key, res)
        fut.set_result(res)
        return res
    except BaseException as e:
        fut.set_exception(e)
        raise
    finally:
        with _lock:
            _inflight.pop(key[1], None)
