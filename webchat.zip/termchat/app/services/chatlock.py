"""Suhbat qulfi (lichka).

- Egasi (A) suhbatni parol bilan qulflaydi. Qulf faqat A tomonida: B parol so'ralmaydi va yozishda davom eta oladi.
- Rejim «ask»: A chatdan chiqsa / ilovani yopsa suhbat qayta qulflanadi (parol har doim so'raladi).
  Rejim «auto»: A bir marta ochgach, qo'lda qulflaguncha parolsiz ochiladi.
- «hide_peer» yoqilgan bo'lsa, suhbat QULFLANGAN paytida A yozgan xabarlar va mediasi B uchun ko'rinmaydi;
  A ochgach yana ko'rinadi. Yashirish serverda bajariladi (tarix, media, so'nggi xabar), faqat ekranda emas.
"""
import time

from app.errors import ChatError
from app.repositories import chat_locks as repo
from app.security import hash_password, limiter, verify_password

MIN_PW, MAX_PW = 4, 64
LOCKED_STATUS = 423


def _clean_mode(mode) -> str:
    return mode if mode in repo.MODES else "ask"


def _check_pw_shape(pw) -> str:
    if not isinstance(pw, str) or not (MIN_PW <= len(pw) <= MAX_PW):
        raise ChatError(f"Parol {MIN_PW}–{MAX_PW} belgidan iborat bo'lishi kerak")
    return pw


def state(user_id: int) -> dict:
    return {
        "mine": [{"peer": r["peer_id"], "mode": r["mode"], "hide": bool(r["hide_peer"]), "locked": bool(r["locked"])}
                 for r in repo.mine(user_id)],
        "theirs": repo.hidden_from(user_id),
    }


def is_locked(owner: int, peer: int) -> bool:
    r = repo.get(owner, peer)
    return bool(r and r["locked"])


def hides_from(viewer: int, partner: int) -> bool:
    """partner suhbatni qulflab, o'z xabarlarini viewer'dan yashirib turibdimi?"""
    r = repo.get(partner, viewer)
    return bool(r and r["locked"] and r["hide_peer"])


def ensure_open(owner: int, peer: int) -> None:
    if is_locked(owner, peer):
        raise ChatError("Bu suhbat qulflangan. Ochish uchun parolni kiriting", LOCKED_STATUS)


def _throttle(owner: int, peer: int) -> None:
    limiter.check(f"clk:{owner}:{peer}", 6, 300, "Parol ko'p marta noto'g'ri kiritildi, 5 daqiqadan keyin urinib ko'ring")


def verify(owner: int, peer: int, password) -> None:
    row = repo.get(owner, peer)
    if row is None:
        raise ChatError("Bu suhbat qulflanmagan", 404)
    _throttle(owner, peer)
    if not isinstance(password, str) or not verify_password(password, row["pw_hash"]):
        raise ChatError("Parol noto'g'ri", 403)


def create_or_update(owner: int, peer: int, password, mode, hide_peer, current=None) -> dict:
    mode = _clean_mode(mode)
    row = repo.get(owner, peer)
    if row is None:
        pw_hash = hash_password(_check_pw_shape(password))
        repo.put(owner, peer, pw_hash, mode, bool(hide_peer), locked=False)
    else:
        verify(owner, peer, current)
        pw_hash = hash_password(_check_pw_shape(password)) if password else None
        repo.put(owner, peer, pw_hash, mode, bool(hide_peer))
    return _entry(owner, peer)


def _entry(owner: int, peer: int) -> dict:
    r = repo.get(owner, peer)
    return {"peer": peer, "mode": r["mode"], "hide": bool(r["hide_peer"]), "locked": bool(r["locked"])}


def lock_now(owner: int, peer: int) -> bool:
    if repo.get(owner, peer) is None:
        raise ChatError("Avval suhbatga parol qo'ying", 404)
    return repo.set_locked(owner, peer, True)


def unlock(owner: int, peer: int, password) -> bool:
    verify(owner, peer, password)
    return repo.set_locked(owner, peer, False)


def remove(owner: int, peer: int, password) -> bool:
    """Qulfni olib tashlaydi. Qulflangan bo'lsa ham parol talab qilinadi. Qaytadi: yashirish tugadimi (B yangilanishi kerakmi)."""
    verify(owner, peer, password)
    was_hiding = hides_from(peer, owner)
    repo.delete(owner, peer)
    return was_hiding


def reset_with_account_password(user, peer: int, account_auth) -> bool:
    """Chat paroli unutilsa: akkaunt (login) paroli bilan qulf olib tashlanadi (suhbat tarixi o'zgarmaydi)."""
    if repo.get(user["id"], peer) is None:
        raise ChatError("Bu suhbat qulflanmagan", 404)
    limiter.check(f"clkreset:{user['id']}", 5, 600, "Juda ko'p urinish, biroz kuting")
    if not isinstance(account_auth, str) or not verify_password(account_auth, user["password_hash"]):
        raise ChatError("Akkaunt paroli noto'g'ri", 403)
    was_hiding = hides_from(peer, user["id"])
    repo.delete(user["id"], peer)
    return was_hiding
