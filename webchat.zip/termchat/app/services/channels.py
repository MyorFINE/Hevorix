from __future__ import annotations

import re
import secrets
import time

from app.config import settings
from app.errors import ChatError
from app.repositories import channels as repo
from app.repositories import messages, users
from app.roles import is_admin
from app.security import hash_password, limiter, verify_password
from app.services import avatars as avatar_svc
from app.services import chat, media, views

USERNAME = re.compile(r"^[a-z0-9_]{3,20}$")
_CTRL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")
PAGE = 20
COMMENT_PAGE = 30


def _ensure_can_write(user) -> None:
    left = views.mute_left(user)
    if left > 0:
        raise ChatError(f"Siz mute holatidasiz (~{int(left // 60) + 1} daqiqa qoldi)")


def _admin(user) -> None:
    if not is_admin(user):
        raise ChatError("Bu amal faqat adminlar uchun", 403)


def _nick(raw) -> str:
    n = _CTRL.sub("", raw if isinstance(raw, str) else "").strip()
    if not 1 <= len(n) <= 40:
        raise ChatError("Kanal nomi 1–40 belgi bo'lishi kerak")
    return n


def _uname(raw) -> str:
    u = (raw if isinstance(raw, str) else "").strip().lstrip("@").lower()
    if not USERNAME.match(u):
        raise ChatError("Kanal username'i 3–20 belgi: a-z, 0-9, _")
    return u


def _pw(raw) -> str:
    p = raw if isinstance(raw, str) else ""
    if not 4 <= len(p) <= 64:
        raise ChatError("Shaxsiy kanal paroli 4–64 belgi bo'lishi kerak")
    return p


def channel_view(r, user) -> dict:
    staff = is_admin(user)
    last = messages.get(r["last_post"]) if r["last_post"] else None
    return {"last": views.message_view(last) if last else None, "id": r["id"], "username": r["username"], "nickname": r["nickname"],
            "avatar": f"/avatars/{r['avatar']}" if r["avatar"] else None,
            "private": bool(r["is_private"]), "posts": r["posts"] or 0, "last_post": r["last_post"] or 0,
            "joined": bool(r["joined"]), "can_manage": staff, "members": (r["members"] or 0) if staff else None,
            "last_ts": r["last_ts"] or 0, "created": r["created_at"]}


def comment_view(c) -> dict:
    out = {"id": c["id"], "post": c["post_id"], "user": views.user_view(c["user_id"]), "ts": c["created_at"]}
    if c["e2e"]:
        out["e2e"] = c["content"]
    else:
        from app import crypto
        out["content"] = crypto.open_(c["content"], "chcom")
        out["legacy"] = True
    return out


def can_see(ch, user) -> bool:
    if not ch["is_private"] or is_admin(user):
        return True
    return repo.is_member(ch["id"], user["id"])


def get_visible(cid: int, user):
    ch = repo.get(cid, user["id"])
    if not ch or not can_see(ch, user):
        raise ChatError("Kanal topilmadi", 404)
    return ch


def audience(ch) -> list[int] | None:
    if not ch["is_private"]:
        return None
    return list(dict.fromkeys(users.staff_ids() + repo.member_ids(ch["id"])))


def list_channels(user) -> list[dict]:
    return [channel_view(r, user) for r in repo.list_for(user["id"], is_admin(user))]


def create(user, username, nickname, private: bool, password) -> dict:
    _admin(user)
    uname, nick = _uname(username), _nick(nickname)
    if repo.get_by_username(uname):
        raise ChatError("Bu kanal username'i band")
    pw_hash = hash_password(_pw(password)) if private else None
    cid = repo.create(uname, nick, private, pw_hash, user["id"], time.time())
    return channel_view(repo.get(cid, user["id"]), user)


def update(user, cid: int, *, username=None, nickname=None, private=None, password=None) -> dict:
    _admin(user)
    ch = repo.get(cid, user["id"])
    if not ch:
        raise ChatError("Kanal topilmadi", 404)
    fields: dict = {}
    if username is not None:
        u = _uname(username)
        other = repo.get_by_username(u)
        if other and other["id"] != cid:
            raise ChatError("Bu kanal username'i band")
        fields["username"] = u
    if nickname is not None:
        fields["nickname"] = _nick(nickname)
    new_private = bool(ch["is_private"]) if private is None else bool(private)
    if new_private:
        if password:
            fields["pw_hash"] = hash_password(_pw(password))
        elif not ch["pw_hash"]:
            raise ChatError("Shaxsiy kanal uchun parol qo'ying")
        fields["is_private"] = 1
    else:
        fields["is_private"] = 0
        fields["pw_hash"] = None
        repo.clear_members(cid)
    repo.update(cid, **fields)
    if new_private and password and ch["is_private"]:
        repo.clear_members(cid)
    return channel_view(repo.get(cid, user["id"]), user)


def set_avatar(user, cid: int, raw: bytes) -> dict:
    _admin(user)
    ch = repo.get(cid, user["id"])
    if not ch:
        raise ChatError("Kanal topilmadi", 404)
    if len(raw) > settings.max_avatar_bytes:
        raise ChatError(f"Rasm {settings.max_avatar_bytes // (1024 * 1024)} MB dan oshmasligi kerak")
    if not avatar_svc.sniff_image(raw):
        raise ChatError("Faqat PNG, JPG, WEBP yoki GIF rasmlar mumkin")
    from app.services import imgclean
    img = imgclean.clean(raw)
    name = f"ch_{secrets.token_hex(12)}.{img.ext}"
    (settings.avatars_dir / name).write_bytes(img.data)
    _drop_file(ch["avatar"])
    repo.update(cid, avatar=name)
    return channel_view(repo.get(cid, user["id"]), user)


def clear_avatar(user, cid: int) -> dict:
    _admin(user)
    ch = repo.get(cid, user["id"])
    if not ch:
        raise ChatError("Kanal topilmadi", 404)
    _drop_file(ch["avatar"])
    repo.update(cid, avatar=None)
    return channel_view(repo.get(cid, user["id"]), user)


def _drop_file(name) -> None:
    if name:
        try:
            (settings.avatars_dir / name).unlink()
        except OSError:
            pass


def delete(user, cid: int) -> None:
    _admin(user)
    ch = repo.get(cid, user["id"])
    if not ch:
        raise ChatError("Kanal topilmadi", 404)
    _drop_file(ch["avatar"])
    for r in messages.channel_clear(cid):
        media.remove_row(r)
        repo.drop_post_data(r["id"])
    repo.delete(cid)


def join(user, username, password) -> dict:
    limiter.check(f"chjoin:{user['id']}", 8, 300, "Juda ko'p urinish. Bir necha daqiqadan so'ng qayta urining")
    uname = (username if isinstance(username, str) else "").strip().lstrip("@").lower()
    ch = repo.get_by_username(uname) if USERNAME.match(uname) else None
    bad = ChatError("Kanal topilmadi yoki parol noto'g'ri", 404)
    if not ch or not ch["is_private"] or not ch["pw_hash"]:
        verify_password("x", "00$00")
        raise bad
    if not verify_password(password if isinstance(password, str) else "", ch["pw_hash"]):
        raise bad
    repo.add_member(ch["id"], user["id"], time.time())
    return channel_view(repo.get(ch["id"], user["id"]), user)


def leave(user, cid: int) -> None:
    ch = repo.get(cid, user["id"])
    if not ch or not ch["is_private"]:
        raise ChatError("Kanal topilmadi", 404)
    repo.remove_member(cid, user["id"])


def posts(user, cid: int, before: int = 0, limit: int = 0) -> tuple[list[dict], bool]:
    get_visible(cid, user)
    n = max(1, min(limit or PAGE, 50))
    rows = messages.channel_page(cid, n, max(0, before))
    more = len(rows) > n
    rows = rows[-n:] if more else rows
    out = [views.message_view(m) for m in rows]
    from app.repositories import polls as polls_repo
    for v in out:
        if v.get("poll"):
            v["poll"]["my"] = polls_repo.mine(v["id"], user["id"])
    return out, more


def _post(user, cid: int, pid: int):
    ch = get_visible(cid, user)
    p = messages.get_active(pid) if isinstance(pid, int) else None
    if not p or p["channel_id"] != cid:
        raise ChatError("Post topilmadi", 404)
    return ch, p


def mark_viewed(user, cid: int, ids) -> tuple[dict, dict[int, int]]:
    ch = get_visible(cid, user)
    clean = [i for i in (ids if isinstance(ids, list) else [])[:50] if isinstance(i, int) and not isinstance(i, bool)]
    return ch, repo.view_posts(cid, user["id"], clean)


def comments(user, cid: int, pid: int, before: int = 0, limit: int = 0) -> tuple[list[dict], bool]:
    _post(user, cid, pid)
    n = max(1, min(limit or COMMENT_PAGE, 60))
    rows = repo.comments_page(pid, max(0, before), n + 1)
    more = len(rows) > n
    return [comment_view(c) for c in reversed(rows[:n])], more


def add_comment(user, cid: int, pid: int, envelope) -> tuple[dict, dict, int]:
    ch, _ = _post(user, cid, pid)
    _ensure_can_write(user)
    chat._check_envelope(user, envelope, None, chan=True)
    limiter.check(f"chcom:{user['id']}", 6, 30, "Sekinroq yozing (spam himoyasi)")
    kid = repo.add_comment(pid, user["id"], envelope, time.time(), e2e=True)
    return ch, comment_view(repo.comment(kid)), repo.comment_count(pid)


def delete_comment(user, cid: int, pid: int, kid: int) -> tuple[dict, int]:
    ch, _ = _post(user, cid, pid)
    c = repo.comment(kid)
    if not c or c["post_id"] != pid:
        raise ChatError("Izoh topilmadi", 404)
    if c["user_id"] != user["id"] and not is_admin(user):
        raise ChatError("Faqat o'z izohingizni o'chira olasiz", 403)
    repo.delete_comment(kid)
    return ch, repo.comment_count(pid)


def vote(user, cid: int, pid: int, opts) -> tuple[dict, dict]:
    from app.repositories import polls as polls_repo
    ch, _ = _post(user, cid, pid)
    pl = polls_repo.get(pid)
    if not pl:
        raise ChatError("Bu post so'rovnoma emas", 404)
    if pl["closed"]:
        raise ChatError("So'rovnoma yopilgan")
    clean = sorted({o for o in (opts if isinstance(opts, list) else []) if isinstance(o, int) and not isinstance(o, bool)})
    if any(not 0 <= o < pl["n"] for o in clean):
        raise ChatError("Variant noto'g'ri")
    if len(clean) > (pl["n"] if pl["multi"] else 1):
        raise ChatError("Faqat bitta variant tanlash mumkin")
    limiter.check(f"pvote:{user['id']}", 20, 60, "Juda tez-tez ovoz berilyapti")
    polls_repo.set_votes(pid, user["id"], clean)
    pv = views.poll_view(polls_repo.get(pid))
    return ch, {**pv, "my": clean}


def close_poll(user, cid: int, pid: int) -> tuple[dict, dict]:
    from app.repositories import polls as polls_repo
    _admin(user)
    ch, _ = _post(user, cid, pid)
    if not polls_repo.get(pid):
        raise ChatError("Bu post so'rovnoma emas", 404)
    polls_repo.close(pid)
    return ch, views.poll_view(polls_repo.get(pid))
