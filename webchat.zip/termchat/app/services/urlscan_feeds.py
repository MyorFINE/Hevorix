"""Havola skaneri: KALITSIZ xavf ro'yxatlari (mahalliy tekshiruv).

Ro'yxatlar serverga bir marta yuklab olinadi va xotirada ixcham saqlanadi (har yozuv — 8 baytli xesh, saralangan massiv),
shuning uchun 500 MB RAMli bepul serverda ham ortiqcha yuk bermaydi. Foydalanuvchi havolasi hech qayerga YUBORILMAYDI:
solishtirish serverning o'zida bo'ladi (Cloudflare/Quad9 DNS tekshiruvidan farqli o'laroq, u domen nomini tashqariga yuboradi).

Manbalar:
  * OpenPhish Community feed (https://openphish.com/feed.txt) — to'liq fishing URL'lar. Kalit yo'q; shartlariga ko'ra FAQAT NOTIJORAT.
  * Phishing.Database (MIT) — faol fishing domenlari (phishing-domains-ACTIVE.txt).
  * Tranco top domenlar — mashhur saytlarni aniqlash (yolg'on ogohlantirishlarni kamaytiradi, «mashhur sayt» belgisi).
O'chirish: TERMCHAT_FEEDS=0. Hech qaysi manba kerak bo'lmasa skaner baribir ishlaydi (holat «na» bo'ladi).
"""
from __future__ import annotations

import hashlib
import io
import logging
import threading
import time
import zipfile
from array import array
from bisect import bisect_left
from pathlib import Path
from typing import Callable

log = logging.getLogger("termchat.feeds")

HOUR = 3600
SOURCES: dict[str, dict] = {
    "openphish": {"name": "OpenPhish", "url": "https://openphish.com/feed.txt", "kind": "urls", "max_bytes": 4_000_000, "ttl": 6 * HOUR,
                  "max_entries": 60_000},
    "phishdb": {"name": "Phishing.Database", "kind": "domains", "max_bytes": 16_000_000, "ttl": 12 * HOUR, "max_entries": 600_000,
                "url": "https://raw.githubusercontent.com/mitchellkrogza/Phishing.Database/master/phishing-domains-ACTIVE.txt"},
    "tranco": {"name": "Tranco", "url": "https://tranco-list.eu/top-1m.csv.zip", "kind": "rank", "max_bytes": 24_000_000, "ttl": 7 * 24 * HOUR,
               "max_entries": 50_000},
}


def h64(s: str) -> int:
    return int.from_bytes(hashlib.blake2b(s.encode("utf-8", "ignore"), digest_size=8).digest(), "big")


class HashSet:
    """Saralangan 64-bitli xeshlar massivi: ~8 bayt/yozuv, qidiruv O(log n)."""
    __slots__ = ("arr",)

    def __init__(self, values=()):
        self.arr = array("Q", sorted(set(values)))

    def __contains__(self, h: int) -> bool:
        a = self.arr
        i = bisect_left(a, h)
        return i < len(a) and a[i] == h

    def __len__(self) -> int:
        return len(self.arr)


def norm_url(u: str) -> str:
    """Sxema va #fragmentsiz, host kichik harfda, oxiridagi / olib tashlangan ko'rinish."""
    u = u.strip()
    u = u.split("#", 1)[0]
    low = u.lower()
    for pre in ("https://", "http://"):
        if low.startswith(pre):
            u = u[len(pre):]
            break
    host, sep, rest = u.partition("/")
    out = host.lower() + sep + rest
    return out.rstrip("/")


def host_of_norm(n: str) -> str:
    h = n.split("/", 1)[0].split("?", 1)[0]
    h = h.rsplit("@", 1)[-1]
    if h.startswith("["):
        return h.split("]", 1)[0] + "]"
    return h.rsplit(":", 1)[0] if h.count(":") == 1 else h


def parse_urls(raw: bytes, cap: int):
    urls: set[int] = set()
    hosts: set[int] = set()
    n = 0
    for line in io.BytesIO(raw):
        s = line.decode("utf-8", "ignore").strip()
        if not s or s.startswith("#") or "." not in s:
            continue
        nu = norm_url(s)
        urls.add(h64(nu))
        hosts.add(h64(host_of_norm(nu)))
        n += 1
        if n >= cap:
            break
    return HashSet(urls), HashSet(hosts), n


def parse_domains(raw: bytes, cap: int):
    out: set[int] = set()
    n = 0
    for line in io.BytesIO(raw):
        s = line.decode("utf-8", "ignore").strip().lower()
        if not s or s[0] in "#!;" or " " in s or "." not in s:
            continue
        s = s.lstrip("*.").rstrip(".")
        out.add(h64(s))
        n += 1
        if n >= cap:
            break
    return HashSet(out), n


def parse_tranco_zip(raw: bytes, cap: int):
    out: set[int] = set()
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        name = next((n for n in z.namelist() if n.endswith(".csv")), z.namelist()[0])
        with z.open(name) as fh:
            for i, line in enumerate(fh):
                if i >= cap:
                    break
                parts = line.decode("utf-8", "ignore").strip().split(",", 1)
                if len(parts) == 2 and parts[1]:
                    out.add(h64(parts[1].strip().lower()))
    return HashSet(out), len(out)


class Feeds:
    """fetch(url, max_bytes, timeout) -> bytes | None  (SSRF-xavfsiz yuklovchi urlscan.py dan beriladi)."""

    def __init__(self, fetch: Callable[[str, int, float], "bytes | None"], *, enabled: bool = True, cache_dir: "Path | None" = None,
                 sources: "dict[str, dict] | None" = None, clock: Callable[[], float] = time.time):
        self._fetch = fetch
        self.enabled = enabled
        self.cache_dir = cache_dir
        self.sources = {k: dict(v) for k, v in (sources or SOURCES).items()}
        self._clock = clock
        self._lock = threading.Lock()
        self._data: dict[str, dict] = {}       # key -> {"urls": HashSet, "hosts": HashSet} | {"set": HashSet}; + "at", "n"
        self._fail: dict[str, float] = {}
        self._first = threading.Event()        # kichik (OpenPhish) ro'yxat yuklandi yoki urinish tugadi
        self._thread: "threading.Thread | None" = None
        self._stop = threading.Event()

    # ------------------------------------------------------------------ yuklash
    def _cache_path(self, key: str) -> "Path | None":
        return (self.cache_dir / f"{key}.cache") if self.cache_dir else None

    def _read_cache(self, key: str, ttl: float) -> "bytes | None":
        p = self._cache_path(key)
        try:
            if p and p.is_file() and self._clock() - p.stat().st_mtime < ttl:
                return p.read_bytes()
        except OSError:
            pass
        return None

    def _write_cache(self, key: str, raw: bytes) -> None:
        p = self._cache_path(key)
        if not p:
            return
        try:
            p.parent.mkdir(parents=True, exist_ok=True)
            tmp = p.with_suffix(".tmp")
            tmp.write_bytes(raw)
            tmp.replace(p)
        except OSError:
            pass

    def _build(self, key: str, raw: bytes) -> dict:
        s = self.sources[key]
        cap = int(s["max_entries"])
        if s["kind"] == "urls":
            u, h, n = parse_urls(raw, cap)
            return {"urls": u, "hosts": h, "n": n}
        if s["kind"] == "domains":
            d, n = parse_domains(raw, cap)
            return {"set": d, "n": n}
        d, n = parse_tranco_zip(raw, cap)
        return {"set": d, "n": n}

    def refresh(self, key: str, *, force: bool = False) -> bool:
        """Bitta manbani yangilaydi. Muvaffaqiyatli bo'lsa True. Xato bo'lsa eski ma'lumot qoladi."""
        s = self.sources[key]
        ttl = float(s["ttl"])
        cur = self._data.get(key)
        if cur and not force and self._clock() - cur["at"] < ttl:
            return True
        if self._fail.get(key, 0) and self._clock() - self._fail[key] < 900:   # xatodan keyin 15 daqiqa kutamiz
            return bool(cur)
        raw = None if force else self._read_cache(key, ttl)
        from_cache = raw is not None
        if raw is None:
            try:
                raw = self._fetch(s["url"], int(s["max_bytes"]), 40.0 if s["max_bytes"] > 5_000_000 else 15.0)
            except Exception as e:   # tarmoq xatosi
                log.warning("feed %s: yuklab bo'lmadi (%s)", key, type(e).__name__)
                raw = None
        if not raw:
            self._fail[key] = self._clock()
            return bool(cur)
        try:
            built = self._build(key, raw)
        except Exception as e:   # buzuq fayl
            log.warning("feed %s: tahlil xatosi (%s)", key, type(e).__name__)
            self._fail[key] = self._clock()
            return bool(cur)
        if built["n"] < 1:
            self._fail[key] = self._clock()
            return bool(cur)
        built["at"] = self._clock()
        with self._lock:
            self._data[key] = built
        self._fail.pop(key, None)
        if not from_cache:
            self._write_cache(key, raw)
        log.info("feed %s: %d yozuv yuklandi", key, built["n"])
        return True

    def _run(self) -> None:
        order = ["openphish", "phishdb", "tranco"]
        first = True
        while not self._stop.is_set():
            for key in order:
                if key not in self.sources or self._stop.is_set():
                    continue
                try:
                    self.refresh(key)
                except Exception:
                    log.exception("feed %s", key)
                if key == "openphish" and first:
                    self._first.set()
                    first = False
                    self._stop.wait(2.0)   # katta ro'yxatlardan oldin biroz kutamiz (birinchi skan tez ketsin)
            self._first.set()
            self._stop.wait(900)

    def start(self) -> None:
        if not self.enabled:
            self._first.set()
            return
        with self._lock:
            if self._thread and self._thread.is_alive():
                return
            self._thread = threading.Thread(target=self._run, name="urlscan-feeds", daemon=True)
            self._thread.start()

    def stop(self) -> None:
        self._stop.set()

    def wait_ready(self, timeout: float = 5.0) -> bool:
        return self._first.wait(timeout)

    # ------------------------------------------------------------------ tekshirish
    def popular(self, domain: str) -> bool:
        d = self._data.get("tranco")
        return bool(d and h64(domain.lower()) in d["set"])

    def check(self, urls: "list[str]", host: str, *, protected: Callable[[str], bool]) -> "list[dict]":
        """Har yoqilgan manba uchun {"name","state","note"}. state: hit | near | clean | na.
        protected(domain) -> True bo'lsa (rasmiy brend/bepul hosting ildizi) domen darajasidagi moslik hisobga olinmaydi."""
        if not self.enabled:
            return []
        res: list[dict] = []
        host = host.lower().rstrip(".")
        for key, s in self.sources.items():
            if s["kind"] == "rank":
                continue
            d = self._data.get(key)
            if not d:
                res.append({"name": s["name"], "state": "na", "note": "baza yuklanmoqda"})
                continue
            if s["kind"] == "urls":
                nus = [norm_url(u) for u in urls]
                if any(h64(n) in d["urls"] for n in nus):
                    res.append({"name": s["name"], "state": "hit", "note": "aynan shu havola fishing deb belgilangan"})
                elif h64(host) in d["hosts"] and not protected(host):
                    res.append({"name": s["name"], "state": "near", "note": "shu domenning boshqa sahifasi fishing deb belgilangan"})
                else:
                    res.append({"name": s["name"], "state": "clean", "note": f"bazada yo'q ({d['n']} ta yozuv)"})
            else:
                labels = host.split(".")
                hit = ""
                for i in range(max(len(labels) - 1, 1)):
                    cand = ".".join(labels[i:])
                    if cand.count(".") < 1:
                        break
                    if h64(cand) in d["set"] and not protected(cand):
                        hit = cand
                        break
                if hit:
                    res.append({"name": s["name"], "state": "hit", "note": f"domen faol fishing bazasida ({hit})"})
                else:
                    res.append({"name": s["name"], "state": "clean", "note": f"bazada yo'q ({d['n']} ta domen)"})
        return res

    def status(self) -> dict:
        now = self._clock()
        return {k: {"n": v["n"], "age_s": int(now - v["at"])} for k, v in self._data.items()}
