from app.repositories import users
from app.roles import is_admin
from app.services import views


def members(viewer) -> list[dict]:
    """Admin hammani ko'radi. Oddiy foydalanuvchi ro'yxatda faqat adminlarni (va o'zini) ko'radi."""
    if is_admin(viewer):
        return [views.member_view(r, admin_view=True) for r in users.list_members(include_banned=True)]
    return [views.member_view(r, admin_view=False) for r in users.list_members()
            if r["role"] in ("owner", "admin") or r["id"] == viewer["id"]]


def total_members() -> int:
    return len(users.list_members())


def known_ids(viewer) -> set[int]:
    """Oddiy foydalanuvchi uchun 'tanish' odamlar: adminlar, umumiy chatda yozganlar, lichka hamkorlari."""
    from app.db import db
    ids = set(users.staff_ids())
    ids.update(r["user_id"] for r in db.all(
        "SELECT DISTINCT user_id FROM messages WHERE recipient_id IS NULL AND channel_id IS NULL"))
    ids.update(r["peer_id"] for r in db.all("SELECT peer_id FROM dm_allow WHERE user_id=?", (viewer["id"],)))
    ids.update(r["user_id"] for r in db.all("SELECT user_id FROM dm_allow WHERE peer_id=?", (viewer["id"],)))
    ids.add(viewer["id"])
    return ids


def visible_online(viewer, online: list[int]) -> list[int]:
    if is_admin(viewer):
        return online
    ok = known_ids(viewer)
    return [i for i in online if i in ok]


def find_by_username(viewer, raw) -> dict | None:
    """Global qidiruv: faqat to'liq username bo'yicha (ro'yxatni sanab chiqib bo'lmasligi uchun)."""
    from app.db import db
    name = (raw if isinstance(raw, str) else "").strip().lstrip("@").lower()
    if not 3 <= len(name) <= 32:
        return None
    r = users.get_by_username(name)
    if not r or r["deleted"] or r["id"] == viewer["id"] or (r["banned"] and not is_admin(viewer)):
        return None
    db.run("INSERT OR IGNORE INTO dm_found(user_id, peer_id) VALUES(?,?)", (viewer["id"], r["id"]))
    row = next((x for x in users.list_members(include_banned=True) if x["id"] == r["id"]), None)
    return views.member_view(row, admin_view=is_admin(viewer)) if row else None
