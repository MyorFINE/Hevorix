"""Havola skaneri (faqat foydalanuvchi «Scan» tugmasini bosganda ishlaydi).

Xabarlar E2EE bo'lgani uchun server havolani o'zi ko'rmaydi: mijoz havolani aynan shu so'rov bilan yuboradi.
Server havolani HECH QACHON saqlamaydi va logga yozmaydi (faqat qisqa muddatli xotira keshi).

Xavfsizlik (SSRF): server begona saytga o'zi ulanadi, shuning uchun
  * faqat http/https va 80/443/8080/8443 portlar;
  * domen IP ga o'zimiz aylantiramiz va HAR BIR manzil global (public) bo'lishi shart — ichki tarmoq, loopback,
    link-local (169.254.x.x, bulut metadata) bloklanadi;
  * ulanish aynan shu tekshirilgan IP ga qilinadi (DNS rebinding bo'lmaydi);
  * har bir redirect qadami qayta tekshiriladi, qadamlar soni cheklangan;
  * javob hajmi va vaqti cheklangan.
"""
from __future__ import annotations

import base64
import html as _html
import http.client
import ipaddress
import json
import re
import socket
import ssl
import threading
import time
import zlib
from collections import OrderedDict
from concurrent.futures import Future, ThreadPoolExecutor
from dataclasses import dataclass, field
from datetime import datetime, timezone
from io import BytesIO
from urllib.parse import quote, urljoin, urlsplit, urlunsplit

from app.config import settings
from app.errors import ChatError
from app.services import urlscan_rules as _rules
from app.services.urlscan_feeds import Feeds

try:
    from PIL import Image
except ImportError:  # pragma: no cover
    Image = None

UA = "Mozilla/5.0 (compatible; TermChatLinkScanner/1.0; +anonymous-safety-check)"
PORTS_OK = {80, 443, 8080, 8443}
MAX_URL = 2048
MAX_HOPS = 8
PAGE_BYTES = 131072
FETCH_TIMEOUT = 8
CACHE_TTL = 600
CACHE_MAX = 48
SHOT_MAX_BYTES = 4 * 1024 * 1024
SHOT_MAX_PIXELS = 24_000_000

MOBILE_UA = "Mozilla/5.0 (Linux; Android 13; SM-A135F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
_POOL = ThreadPoolExecutor(max_workers=12, thread_name_prefix="urlscan")
_SUB = ThreadPoolExecutor(max_workers=10, thread_name_prefix="urlscan-sub")   # ichki (DoH, ro'yxat) vazifalar: _POOL ichida _POOL kutilmasin
_SCAN_SEM = threading.BoundedSemaphore(3)
_SHOT_SEM = threading.BoundedSemaphore(3)


class ScanBlocked(Exception):
    """Manzil ichki/shaxsiy tarmoqqa olib boradi yoki ruxsat etilmagan."""


class ScanNoDNS(Exception):
    """Domen IP ga aylanmadi."""


# --------------------------------------------------------------------------------------------- URL


@dataclass
class Target:
    url: str
    scheme: str
    host: str            # ASCII (punycode)
    uhost: str           # Unicode ko'rinishi
    port: int
    path: str
    query: str
    userinfo: bool
    is_ip: bool

    @property
    def port_ok(self) -> bool:
        return self.port in PORTS_OK

    @property
    def request_path(self) -> str:
        return (self.path or "/") + ("?" + self.query if self.query else "")


def parse_target(raw: str) -> Target:
    raw = (raw or "").strip()
    bad = ChatError("Havola noto'g'ri", 400)
    if not raw or len(raw) > MAX_URL or any(c.isspace() or ord(c) < 32 or ord(c) == 127 for c in raw):
        raise bad
    if "://" in raw:
        if not re.match(r"^https?://", raw, re.I):
            raise ChatError("Faqat http/https havolalar tekshiriladi", 400)
    else:
        raw = "https://" + raw
    try:
        sp = urlsplit(raw)
        host = sp.hostname
        port = sp.port
    except ValueError:
        raise bad from None
    if not host:
        raise bad
    scheme = sp.scheme.lower()
    try:
        ip = ipaddress.ip_address(host)
        is_ip = True
        ascii_host = str(ip)
        uhost = ascii_host
    except ValueError:
        is_ip = False
        if re.fullmatch(r"[0-9a-fx.]+", host):   # 2130706433, 0x7f.1 kabi yashirin IP shakllari
            raise bad from None
        try:
            ascii_host = host.encode("idna").decode("ascii")
            uhost = ascii_host.encode("ascii").decode("idna")
        except UnicodeError:
            raise bad from None
    if len(ascii_host) > 253:
        raise bad
    port = port or (443 if scheme == "https" else 80)
    default = 443 if scheme == "https" else 80
    hostpart = f"[{ascii_host}]" if is_ip and ":" in ascii_host else ascii_host
    netloc = hostpart + ("" if port == default else f":{port}")
    path = sp.path or "/"
    url = urlunsplit((scheme, netloc, path, sp.query, ""))
    return Target(url=url, scheme=scheme, host=ascii_host, uhost=uhost, port=port, path=path, query=sp.query,
                  userinfo="@" in sp.netloc, is_ip=is_ip)


def _ip_ok(ip: ipaddress._BaseAddress) -> bool:
    return ip.is_global and not ip.is_multicast


def resolve_public(host: str, port: int = 443) -> list[str]:
    """Domenni IP ga aylantiradi; bitta bo'lsa ham ichki manzil chiqsa ScanBlocked."""
    try:
        infos = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
    except (socket.gaierror, UnicodeError, OSError):
        raise ScanNoDNS(host) from None
    out: list[str] = []
    for info in infos:
        ip = ipaddress.ip_address(info[4][0].split("%")[0])
        if ip.version == 6 and ip.ipv4_mapped:
            ip = ip.ipv4_mapped
        if not _ip_ok(ip):
            raise ScanBlocked(str(ip))
        if str(ip) not in out:
            out.append(str(ip))
    if not out:
        raise ScanNoDNS(host)
    return out


registrable = _rules.registrable


# ----------------------------------------------------------------------------------------- HTTP(S)


class _PinnedHTTP(http.client.HTTPConnection):
    def __init__(self, host, port, ip, timeout):
        super().__init__(host, port, timeout=timeout)
        self._ip = ip

    def connect(self):
        self.sock = socket.create_connection((self._ip, self.port), self.timeout)


class _PinnedHTTPS(http.client.HTTPSConnection):
    def __init__(self, host, port, ip, timeout, context):
        super().__init__(host, port, timeout=timeout, context=context)
        self._ip = ip

    def connect(self):
        sock = socket.create_connection((self._ip, self.port), self.timeout)
        try:
            self.sock = self._context.wrap_socket(sock, server_hostname=self.host)
        except Exception:
            sock.close()
            raise


def _noverify_ctx() -> ssl.SSLContext:
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx


@dataclass
class Resp:
    url: str
    status: int = 0
    headers: dict = field(default_factory=dict)
    body: bytes = b""
    hops: list = field(default_factory=list)
    ip: str = ""
    tls_error: str = ""
    too_many: bool = False


def _read_limited(r, limit: int, deadline: float) -> bytes:
    buf = bytearray()
    while len(buf) < limit:
        if time.monotonic() > deadline:
            break
        chunk = r.read(min(8192, limit - len(buf)))
        if not chunk:
            break
        buf += chunk
    return bytes(buf)


def http_request(url: str, *, method: str = "GET", headers: dict | None = None, body: bytes | None = None,
                 max_bytes: int = PAGE_BYTES, max_hops: int = 0, timeout: float = FETCH_TIMEOUT,
                 trusted: bool = False, cert_fallback: bool = False, max_out: int | None = None) -> Resp:
    """SSRF-xavfsiz so'rov. trusted=True: ko'rsatilgan servis (DoH, RDAP...) — port cheklovi yo'q, lekin IP baribir public bo'lishi shart."""
    cur = url
    hops: list[dict] = []
    tls_error = ""
    deadline = time.monotonic() + max(timeout * 2, 10)
    for i in range(max_hops + 1):
        t = parse_target(cur)
        if not trusted and not t.port_ok:
            raise ScanBlocked(f"port {t.port}")
        ips = resolve_public(t.host, t.port)
        hdrs = {"User-Agent": UA, "Accept": "*/*", "Accept-Encoding": "identity", "Connection": "close"}
        hdrs.update(headers or {})
        resp = None
        last_exc: Exception | None = None
        for ip in ips[:3]:
            verify_modes = [True, False] if (t.scheme == "https" and cert_fallback) else [True]
            for verify in verify_modes:
                if t.scheme == "https":
                    ctx = ssl.create_default_context() if verify else _noverify_ctx()
                    conn = _PinnedHTTPS(t.host, t.port, ip, timeout, ctx)
                else:
                    conn = _PinnedHTTP(t.host, t.port, ip, timeout)
                try:
                    conn.request(method if i == 0 else "GET", t.request_path, body=body if i == 0 else None, headers=hdrs)
                    r = conn.getresponse()
                    rh = {k.lower(): v for k, v in r.getheaders()}
                    status = r.status
                    hops.append({"url": cur, "status": status, "ip": ip})
                    if not verify:
                        tls_error = tls_error or "sertifikat tekshiruvdan o'tmadi"
                    if status in (301, 302, 303, 307, 308) and rh.get("location") and i < max_hops:
                        resp = ("redirect", urljoin(cur, rh["location"]))
                    else:
                        data = _read_limited(r, max_bytes, deadline)
                        if rh.get("content-encoding", "").lower() == "gzip":
                            try:
                                data = zlib.decompressobj(16 + zlib.MAX_WBITS).decompress(data, max_out or max_bytes)
                            except zlib.error:
                                data = b""
                        resp = ("done", Resp(url=cur, status=status, headers=rh, body=data, hops=hops, ip=ip,
                                             tls_error=tls_error, too_many=status in (301, 302, 303, 307, 308)))
                    break
                except ssl.SSLCertVerificationError as e:
                    tls_error = e.verify_message or str(e)
                    last_exc = e
                    continue
                except (OSError, http.client.HTTPException) as e:
                    last_exc = e
                    break
                finally:
                    conn.close()
            if resp:
                break
        if not resp:
            raise last_exc or OSError("ulanib bo'lmadi")
        kind, val = resp
        if kind == "done":
            return val
        cur = val
    return Resp(url=cur, status=0, hops=hops, tls_error=tls_error, too_many=True)


def _json(resp: Resp):
    try:
        return json.loads(resp.body.decode("utf-8", "replace"))
    except ValueError:
        return None


def _feed_fetch(url: str, max_bytes: int, timeout: float) -> bytes | None:
    """Ro'yxat yuklovchi: SSRF-xavfsiz, gzip qo'llab-quvvatlanadi, xatoda None."""
    try:
        r = http_request(url, headers={"Accept-Encoding": "gzip", "Accept": "*/*"}, max_bytes=max_bytes, max_out=max_bytes,
                         timeout=timeout, trusted=True, max_hops=3)
    except (ScanBlocked, ScanNoDNS, OSError, http.client.HTTPException):
        return None
    return r.body if r.status == 200 and r.body else None


FEEDS = Feeds(_feed_fetch, enabled=settings.threat_feeds, cache_dir=settings.data_dir / "feeds")

_OFFICIAL_ALL: set[str] = set()
for _s in list(_rules.BRANDS.values()) + list(_rules.WEAK_BRANDS.values()):
    _OFFICIAL_ALL |= _s


def _protected(domain: str) -> bool:
    """Domen darajasidagi ro'yxat moslik hisobga olinmaydigan domenlar: rasmiy brendlar va umumiy bepul hosting ildizlari."""
    d = domain.lower()
    return any(d == o or d.endswith("." + o) for o in _OFFICIAL_ALL) or d in _rules.FREE_HOSTS or d.count(".") < 1


# ------------------------------------------------------------------------------------------ vaqt


def _now() -> datetime:
    return datetime.now(timezone.utc)


_DT_FORMATS = ("%Y-%m-%dT%H:%M:%S%z", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%d-%b-%Y", "%Y.%m.%d", "%Y/%m/%d",
               "%d.%m.%Y", "%d-%m-%Y", "%Y-%m-%dT%H:%M:%S.%f%z", "%Y-%m-%d %H:%M:%S%z")


def parse_dt(s: str | None) -> datetime | None:
    if not s:
        return None
    s = s.strip()
    try:
        d = datetime.fromisoformat(s.replace("Z", "+00:00"))
        return d if d.tzinfo else d.replace(tzinfo=timezone.utc)
    except ValueError:
        pass
    for f in _DT_FORMATS:
        try:
            d = datetime.strptime(s[:32], f)
            return d if d.tzinfo else d.replace(tzinfo=timezone.utc)
        except ValueError:
            continue
    return None


def age_text(days: int) -> str:
    if days < 0:
        return "kelajak sanasi"
    if days < 1:
        return "bugun"
    if days < 60:
        return f"{days} kun"
    if days < 730:
        return f"{days // 30} oy"
    y, rest = divmod(days, 365)
    return f"{y} yil" + (f" {rest // 30} oy" if rest // 30 else "")


def _date(d: datetime | None) -> str:
    return d.strftime("%Y-%m-%d") if d else "—"


# ------------------------------------------------------------------------------- WHOIS / RDAP

_rdap_boot: dict = {"ts": 0.0, "map": {}}
_rdap_lock = threading.Lock()


def _rdap_base(tld: str) -> str | None:
    with _rdap_lock:
        if time.time() - _rdap_boot["ts"] > 86400 or not _rdap_boot["map"]:
            try:
                j = _json(http_request("https://data.iana.org/rdap/dns.json", trusted=True, max_bytes=400000, timeout=6, max_hops=2))
                m = {}
                for tlds, urls in (j or {}).get("services", []):
                    for x in tlds:
                        m[x.lower()] = urls[0] if urls else None
                if m:
                    _rdap_boot.update(ts=time.time(), map=m)
            except Exception:
                pass
        return _rdap_boot["map"].get(tld.lower())


def _rdap_domain(domain: str) -> dict | None:
    tld = domain.rsplit(".", 1)[-1]
    base = _rdap_base(tld)
    if not base:
        return None
    r = http_request(base.rstrip("/") + "/domain/" + quote(domain), headers={"Accept": "application/rdap+json"},
                     trusted=True, max_bytes=400000, timeout=7, max_hops=3)
    j = _json(r) if r.status == 200 else None
    if not isinstance(j, dict):
        return None
    ev = {e.get("eventAction"): e.get("eventDate") for e in j.get("events", []) if isinstance(e, dict)}
    registrar = ""
    for ent in j.get("entities", []) or []:
        if isinstance(ent, dict) and "registrar" in (ent.get("roles") or []):
            for p in (ent.get("vcardArray") or [None, []])[1] or []:
                if isinstance(p, list) and len(p) > 3 and p[0] == "fn":
                    registrar = str(p[3])
                    break
    ns = sorted({str(n.get("ldhName", "")).lower() for n in j.get("nameservers", []) or [] if isinstance(n, dict) and n.get("ldhName")})
    return {"source": "RDAP", "created": parse_dt(ev.get("registration")), "expires": parse_dt(ev.get("expiration")),
            "updated": parse_dt(ev.get("last changed")), "registrar": registrar[:100], "status": [str(x) for x in (j.get("status") or [])][:6],
            "ns": ns[:6], "dnssec": bool((j.get("secureDNS") or {}).get("delegationSigned"))}


def _whois_raw(server: str, query: str) -> str:
    ip = resolve_public(server, 43)[0]
    with socket.create_connection((ip, 43), timeout=6) as s:
        s.settimeout(6)
        s.sendall(query.encode("idna", "ignore") + b"\r\n")
        buf = b""
        end = time.monotonic() + 8
        while len(buf) < 65536 and time.monotonic() < end:
            try:
                c = s.recv(4096)
            except OSError:
                break
            if not c:
                break
            buf += c
    return buf.decode("utf-8", "replace")


def _whois_domain(domain: str) -> dict | None:
    tld = domain.rsplit(".", 1)[-1]
    ref = _whois_raw("whois.iana.org", tld)
    m = re.search(r"^(?:refer|whois):\s*(\S+)", ref, re.I | re.M)
    if not m:
        return None
    server = m.group(1).strip().lower()
    if not re.fullmatch(r"[a-z0-9.-]+", server):
        return None
    raw = _whois_raw(server, domain)

    def first(*keys):
        for k in keys:
            mm = re.search(r"^\s*" + k + r"\s*:\s*(.+)$", raw, re.I | re.M)
            if mm:
                return mm.group(1).strip()
        return None

    created = parse_dt(first("Creation Date", "Created", "Created On", "Registered on", "Registration Time", "Domain Registration Date"))
    expires = parse_dt(first("Registry Expiry Date", "Expiration Date", "Expires", "Expires On", "Registrar Registration Expiration Date", "Expiry date"))
    updated = parse_dt(first("Updated Date", "Last Updated", "Last Modified", "Modified"))
    if not (created or expires or first("Registrar", "Sponsoring Registrar")):
        return None
    ns = sorted({x.strip().lower().split()[0] for x in re.findall(r"^\s*(?:Name Server|nserver)\s*:\s*(\S+)", raw, re.I | re.M)})
    st = [x.strip().split()[0] for x in re.findall(r"^\s*(?:Domain )?Status\s*:\s*(.+)$", raw, re.I | re.M)][:6]
    return {"source": "WHOIS", "created": created, "expires": expires, "updated": updated,
            "registrar": (first("Registrar", "Sponsoring Registrar") or "")[:100], "status": st, "ns": ns[:6], "dnssec": False}


def whois_step(t: Target) -> dict:
    if t.is_ip:
        try:
            r = http_request("https://rdap.org/ip/" + quote(t.host), headers={"Accept": "application/rdap+json"},
                             trusted=True, max_bytes=300000, timeout=7, max_hops=3)
            j = _json(r) if r.status == 200 else None
            if isinstance(j, dict):
                return {"ip": True, "name": str(j.get("name", ""))[:80], "country": str(j.get("country", ""))[:8],
                        "range": f"{j.get('startAddress', '')} – {j.get('endAddress', '')}"}
        except Exception:
            pass
        return {"ip": True}
    dom = registrable(t.host)
    info = None
    err = None
    for fn in (_rdap_domain, _whois_domain):
        try:
            info = fn(dom)
        except Exception as e:  # tarmoq xatosi — keyingisini sinaymiz
            err = e
            info = None
        if info:
            break
    if not info:
        return {"domain": dom, "error": "topilmadi" if err is None else "so'rov bajarilmadi"}
    info["domain"] = dom
    return info


# ------------------------------------------------------------------------------------------ DNS


def _doh(host: str, path: str, name: str, rtype: str, port: int = 443) -> dict | None:
    u = f"https://{host}{'' if port == 443 else ':' + str(port)}{path}?name={quote(name)}&type={rtype}"
    r = http_request(u, headers={"Accept": "application/dns-json"}, trusted=True, max_bytes=65536, timeout=5)
    j = _json(r) if r.status == 200 else None
    return j if isinstance(j, dict) else None


def dns_step(t: Target) -> dict:
    out: dict = {"A": [], "AAAA": [], "NS": [], "MX": [], "ttl": None, "system": []}
    try:
        out["system"] = resolve_public(t.host, t.port)
    except ScanBlocked:
        raise
    except ScanNoDNS:
        out["nxdomain"] = True
    if t.is_ip:
        return out
    dom = registrable(t.host)
    jobs = {"A": (t.host, "A"), "AAAA": (t.host, "AAAA"), "NS": (dom, "NS"), "MX": (dom, "MX")}
    futs = {k: _SUB.submit(_doh, "cloudflare-dns.com", "/dns-query", n, ty) for k, (n, ty) in jobs.items()}
    f_asn = None
    v4 = next((ip for ip in out["system"] if ":" not in ip), None)
    if v4:
        f_asn = _SUB.submit(asn_step, v4)
    ttls = []
    for k, f in futs.items():
        try:
            j = f.result(timeout=8)
        except Exception:
            j = None
        for a in (j or {}).get("Answer", []) or []:
            if isinstance(a, dict) and a.get("type") == {"A": 1, "AAAA": 28, "NS": 2, "MX": 15}[k]:
                d = str(a.get("data", "")).rstrip(".").lower()
                if d and d not in out[k]:
                    out[k].append(d[:80])
                if k in ("A", "AAAA") and isinstance(a.get("TTL"), int):
                    ttls.append(a["TTL"])
        out[k] = out[k][:6]
    out["ttl"] = min(ttls) if ttls else None
    if f_asn is not None:
        try:
            out["asn"] = f_asn.result(timeout=8)
        except Exception:
            out["asn"] = None
    return out


def _txt(j: dict | None) -> str:
    for a in (j or {}).get("Answer", []) or []:
        if isinstance(a, dict) and a.get("type") == 16:
            return str(a.get("data", "")).replace('"', "").strip()
    return ""


def asn_step(ip: str) -> dict | None:
    """IP -> ASN/davlat/tarmoq nomi (Team Cymru DNS xizmati, kalitsiz; DoH orqali)."""
    try:
        parts = ipaddress.ip_address(ip).packed
    except ValueError:
        return None
    rev = ".".join(str(b) for b in reversed(parts))
    row = [x.strip() for x in _txt(_doh("cloudflare-dns.com", "/dns-query", rev + ".origin.asn.cymru.com", "TXT")).split("|")]
    if len(row) < 3 or not row[0].split()[:1] or not row[0].split()[0].isdigit():
        return None
    asn = row[0].split()[0]
    info = {"asn": "AS" + asn, "prefix": row[1][:40], "country": row[2][:4], "name": ""}
    try:
        nm = [x.strip() for x in _txt(_doh("cloudflare-dns.com", "/dns-query", f"AS{asn}.asn.cymru.com", "TXT")).split("|")]
        if len(nm) >= 5:
            info["name"] = nm[4][:60]
    except Exception:
        pass
    return info


# -------------------------------------------------------------------------------------------- TLS


def tls_step(host: str, port: int) -> dict:
    out: dict = {"host": host, "verified": False, "error": ""}
    ip = resolve_public(host, port)[0]
    der = None
    for verify in (True, False):
        ctx = ssl.create_default_context() if verify else _noverify_ctx()
        try:
            with socket.create_connection((ip, port), timeout=6) as raw, ctx.wrap_socket(raw, server_hostname=host) as s:
                der = s.getpeercert(binary_form=True)
                out["version"] = s.version() or ""
                c = s.cipher()
                out["cipher"] = c[0] if c else ""
                out["verified"] = verify
            break
        except ssl.SSLCertVerificationError as e:
            out["error"] = (e.verify_message or str(e))
            if "hostname" in str(e).lower():
                out["mismatch"] = True
            continue
        except (ssl.SSLError, OSError) as e:
            out["error"] = out["error"] or (getattr(e, "reason", None) or str(e) or "ulanib bo'lmadi")
            out["fatal"] = True
            return out
    if der:
        try:
            from cryptography import x509
            from cryptography.x509.oid import NameOID
            c = x509.load_der_x509_certificate(der)

            def attr(name, oid):
                v = name.get_attributes_for_oid(oid)
                return v[0].value if v else ""
            out["subject"] = attr(c.subject, NameOID.COMMON_NAME)
            out["issuer"] = attr(c.issuer, NameOID.ORGANIZATION_NAME) or attr(c.issuer, NameOID.COMMON_NAME)
            out["not_before"] = c.not_valid_before_utc
            out["not_after"] = c.not_valid_after_utc
            out["self_signed"] = c.issuer == c.subject
            try:
                out["san"] = c.extensions.get_extension_for_class(x509.SubjectAlternativeName).value.get_values_for_type(x509.DNSName)[:8]
            except x509.ExtensionNotFound:
                out["san"] = []
        except Exception as e:
            out["error"] = out["error"] or f"sertifikatni o'qib bo'lmadi ({type(e).__name__})"
    return out


# ----------------------------------------------------------------------------------- Threat intel


def _threat_feeds(t: Target, final_url: str) -> list[dict]:
    res: list[dict] = []
    host = t.host
    sys_v4 = False
    try:
        sys_v4 = any(":" not in ip for ip in resolve_public(host, t.port))
    except Exception:
        pass

    def cf():
        j = _doh("security.cloudflare-dns.com", "/dns-query", host, "A")
        if j is None:
            return {"name": "Cloudflare Security DNS", "state": "na", "note": "javob yo'q"}
        ans = [str(a.get("data")) for a in j.get("Answer", []) or [] if isinstance(a, dict)]
        if "0.0.0.0" in ans and sys_v4:
            return {"name": "Cloudflare Security DNS", "state": "hit", "note": "zararli/fishing domen sifatida bloklangan"}
        return {"name": "Cloudflare Security DNS", "state": "clean", "note": "bloklanmagan"}

    def q9():
        j = _doh("dns.quad9.net", "/dns-query", host, "A", port=5053)
        if j is None:
            return {"name": "Quad9 Threat DNS", "state": "na", "note": "javob yo'q"}
        if j.get("Status") == 3 and sys_v4:
            return {"name": "Quad9 Threat DNS", "state": "hit", "note": "xavfli domen sifatida bloklangan"}
        return {"name": "Quad9 Threat DNS", "state": "clean", "note": "bloklanmagan"}

    def gsb():
        body = json.dumps({"client": {"clientId": "termchat", "clientVersion": "1.0"},
                           "threatInfo": {"threatTypes": ["MALWARE", "SOCIAL_ENGINEERING", "UNWANTED_SOFTWARE", "POTENTIALLY_HARMFUL_APPLICATION"],
                                          "platformTypes": ["ANY_PLATFORM"], "threatEntryTypes": ["URL"],
                                          "threatEntries": [{"url": final_url}]}}).encode()
        r = http_request("https://safebrowsing.googleapis.com/v4/threatMatches:find?key=" + quote(settings.gsb_key), method="POST",
                         headers={"Content-Type": "application/json"}, body=body, trusted=True, max_bytes=65536, timeout=7)
        j = _json(r)
        if r.status != 200 or not isinstance(j, dict):
            return {"name": "Google Safe Browsing", "state": "na", "note": f"xato ({r.status})"}
        m = j.get("matches") or []
        if m:
            kinds = sorted({str(x.get("threatType", "")) for x in m if isinstance(x, dict)})
            return {"name": "Google Safe Browsing", "state": "hit", "note": ", ".join(kinds)[:80]}
        return {"name": "Google Safe Browsing", "state": "clean", "note": "xavf topilmadi"}

    def vt():
        uid = base64.urlsafe_b64encode(final_url.encode()).decode().rstrip("=")
        r = http_request("https://www.virustotal.com/api/v3/urls/" + uid, headers={"x-apikey": settings.vt_key}, trusted=True,
                         max_bytes=300000, timeout=7)
        if r.status == 404:
            return {"name": "VirusTotal", "state": "na", "note": "bu havola bazada yo'q"}
        j = _json(r)
        st = ((j or {}).get("data", {}).get("attributes", {}) or {}).get("last_analysis_stats") if isinstance(j, dict) else None
        if r.status != 200 or not isinstance(st, dict):
            return {"name": "VirusTotal", "state": "na", "note": f"xato ({r.status})"}
        bad = int(st.get("malicious", 0)) + int(st.get("suspicious", 0))
        total = sum(int(v) for v in st.values() if isinstance(v, int))
        if bad:
            return {"name": "VirusTotal", "state": "hit", "note": f"{bad}/{total} dvigatel xavfli deb topdi"}
        return {"name": "VirusTotal", "state": "clean", "note": f"0/{total}"}

    def uh():
        r = http_request("https://urlhaus-api.abuse.ch/v1/url/", method="POST", body=("url=" + quote(final_url, safe="")).encode(),
                         headers={"Content-Type": "application/x-www-form-urlencoded", "Auth-Key": settings.urlhaus_key},
                         trusted=True, max_bytes=65536, timeout=7)
        j = _json(r)
        if not isinstance(j, dict):
            return {"name": "URLhaus", "state": "na", "note": f"xato ({r.status})"}
        if j.get("query_status") == "ok":
            return {"name": "URLhaus", "state": "hit", "note": str(j.get("threat") or j.get("url_status") or "zararli")[:60]}
        if j.get("query_status") == "no_results":
            return {"name": "URLhaus", "state": "clean", "note": "bazada yo'q"}
        return {"name": "URLhaus", "state": "na", "note": str(j.get("query_status"))[:40]}

    fns = [cf, q9] + ([gsb] if settings.gsb_key else []) + ([vt] if settings.vt_key else []) + ([uh] if settings.urlhaus_key else [])
    futs = [_SUB.submit(f) for f in fns]
    # Mahalliy (kalitsiz) ro'yxatlar: havola tashqariga yuborilmaydi, solishtirish serverning o'zida
    try:
        FEEDS.start()
        FEEDS.wait_ready(4.0)
        res.extend(FEEDS.check(list({t.url, final_url}), t.host, protected=_protected))
    except Exception:
        pass
    for f in futs:
        try:
            res.append(f.result(timeout=12))
        except Exception:
            res.append({"name": "manba", "state": "na", "note": "ulanib bo'lmadi"})
    return res


# ------------------------------------------------------------------------------- Sahifa tahlili

_DL_EXT = (".apk", ".exe", ".msi", ".scr", ".bat", ".cmd", ".jar", ".dmg", ".iso", ".vbs", ".ps1", ".lnk", ".pkg", ".deb")
_ARC_EXT = (".zip", ".rar", ".7z", ".gz")


def page_analysis(resp: Resp) -> dict:
    out: dict = {"status": resp.status, "ctype": resp.headers.get("content-type", "").split(";")[0].strip().lower(),
                 "server": resp.headers.get("server", "")[:60], "title": "", "password": False, "ext_form": [], "meta_refresh": False,
                 "download": "", "hsts": "strict-transport-security" in resp.headers}
    cd = resp.headers.get("content-disposition", "").lower()
    path = urlsplit(resp.url).path.lower()
    if "attachment" in cd or any(path.endswith(e) for e in _DL_EXT + _ARC_EXT) or out["ctype"] in (
            "application/vnd.android.package-archive", "application/x-msdownload", "application/x-msdos-program", "application/java-archive"):
        out["download"] = "exe" if any(path.endswith(e) for e in _DL_EXT) or "android.package" in out["ctype"] or "msdownload" in out["ctype"] else "file"
    if out["ctype"] in ("text/html", "application/xhtml+xml", "") and resp.body:
        txt = resp.body.decode("utf-8", "replace")
        m = re.search(r"<title[^>]*>(.*?)</title>", txt, re.I | re.S)
        if m:
            out["title"] = re.sub(r"\s+", " ", _html.unescape(m.group(1))).strip()[:120]
        out["password"] = bool(re.search(r"<input[^>]+type\s*=\s*[\"']?password", txt, re.I))
        out["meta_refresh"] = bool(re.search(r"<meta[^>]+http-equiv\s*=\s*[\"']?refresh", txt, re.I))
        fhost = (urlsplit(resp.url).hostname or "").lower()
        for a in re.findall(r"<form[^>]*\baction\s*=\s*[\"']?([^\"'\s>]+)", txt, re.I)[:10]:
            try:
                h = (urlsplit(urljoin(resp.url, _html.unescape(a))).hostname or "").lower()
            except ValueError:
                continue
            if h and registrable(h) != registrable(fhost) and h not in out["ext_form"]:
                out["ext_form"].append(h[:80])
    return out


# --------------------------------------------------------------------------------- Evristika
# Qoidalar urlscan_rules.py da (tarmoqsiz, alohida sinaladi). Bu yerda eski nomlar saqlangan.

SHORTENERS = _rules.SHORTENERS
BAD_TLDS = _rules.BAD_TLDS
BRANDS = _rules.BRANDS
KEYWORDS = _rules.KEYWORDS
_lev = _rules._lev


def heuristics(t: Target, popular: bool = False) -> list[dict]:
    return _rules.url_findings(t.host, t.uhost, t.path, t.query, scheme=t.scheme, port_ok=t.port_ok, port=t.port,
                               userinfo=t.userinfo, is_ip=t.is_ip, full_len=len(t.url), popular=popular)


# ----------------------------------------------------------------------------------------- Scan


def _status_of(f: list[dict]) -> str:
    return "bad" if any(x["sev"] == "bad" for x in f) else "warn" if any(x["sev"] == "warn" for x in f) else "ok"


def _chk(cid, name, status, value, details=None):
    return {"id": cid, "name": name, "status": status, "value": value, "details": details or []}


def _safe(fut, timeout):
    try:
        return fut.result(timeout=max(0.5, timeout)), None
    except ScanBlocked as e:
        return None, e
    except Exception as e:
        return None, e


def _scan(t: Target) -> dict:
    t0 = time.monotonic()
    dom = registrable(t.host)
    popular = FEEDS.popular(dom)
    url_findings = heuristics(t, popular=popular)
    findings = list(url_findings)
    blocked = False
    try:
        resolve_public(t.host, t.port)
    except ScanBlocked:
        raise ChatError("Bu havola ichki yoki shaxsiy tarmoq manziliga olib boradi — tekshirilmaydi", 400) from None
    except ScanNoDNS:
        pass

    f_dns = _POOL.submit(dns_step, t)
    f_who = _POOL.submit(whois_step, t)
    f_page = _POOL.submit(lambda: http_request(t.url, max_hops=MAX_HOPS, cert_fallback=True)) if t.port_ok else None
    # Telefon brauzeri sifatida ikkinchi so'rov: skanerga boshqa, foydalanuvchiga boshqa sahifa ko'rsatuvchi (cloaking) saytlarni ushlash uchun
    f_mob = _POOL.submit(lambda: http_request(t.url, max_hops=MAX_HOPS, cert_fallback=True, timeout=6, headers={
        "User-Agent": MOBILE_UA, "Accept-Language": "uz-UZ,uz;q=0.9,ru;q=0.8,en;q=0.6"})) if t.port_ok else None
    f_threat = _POOL.submit(_threat_feeds, t, t.url)
    left = lambda: 25 - (time.monotonic() - t0)

    dns, dns_err = _safe(f_dns, left())
    who, who_err = _safe(f_who, left())
    page: Resp | None = None
    page_err = None
    if f_page:
        page, page_err = _safe(f_page, left())
    mob: Resp | None = None
    if f_mob:
        mob, _mob_err = _safe(f_mob, min(left(), 9))
    # Skaner nomi bot-himoya (WAF) tomonidan bloklangan bo'lsa, haqiqiy foydalanuvchiga yaqin (telefon) ko'rinishni tahlil qilamiz
    bot_blocked = False
    if page is not None and page.status in (401, 403, 429, 503) and mob is not None and mob.status and mob.status < 400:
        page, bot_blocked = mob, True
    feeds, _ = _safe(f_threat, left())
    feeds = feeds or []
    checks: list[dict] = []

    # --- WHOIS / RDAP
    age_days = None
    if who and who.get("ip"):
        d = [["Tur", "IP manzil"]] + ([["Tarmoq", who["name"]]] if who.get("name") else []) + ([["Davlat", who["country"]]] if who.get("country") else [])
        checks.append(_chk("whois", "WHOIS / RDAP", "ok", who.get("country") or "IP", d))
    elif who and (who.get("created") or who.get("registrar") or who.get("expires")):
        cr = who.get("created")
        age_days = (_now() - cr).days if cr else None
        st = "ok"
        if age_days is not None:
            if age_days < 7:
                findings.append({"sev": "bad", "pts": 35, "text": f"Domen juda yangi: {age_text(max(age_days, 0))} oldin ro'yxatdan o'tgan"})
                st = "bad"
            elif age_days < 30:
                findings.append({"sev": "warn", "pts": 25, "text": f"Domen yangi: {age_text(age_days)} oldin ro'yxatdan o'tgan"})
                st = "warn"
            elif age_days < 90:
                findings.append({"sev": "info", "pts": 10, "text": f"Domen nisbatan yangi ({age_text(age_days)})"})
                st = "warn"
        ex = who.get("expires")
        d = [["Domen", who["domain"]], ["Manba", who["source"]], ["Ro'yxatdan o'tgan", _date(cr) + (f" ({age_text(age_days)})" if age_days is not None else "")],
             ["Amal qilish muddati", _date(ex)], ["Yangilangan", _date(who.get("updated"))], ["Registrator", who.get("registrar") or "—"],
             ["Nameserverlar", ", ".join(who.get("ns") or []) or "—"], ["Holat", ", ".join(who.get("status") or []) or "—"]]
        checks.append(_chk("whois", "WHOIS / RDAP", st, age_text(age_days) + " yosh" if age_days is not None else (who.get("registrar") or "Topildi"), d))
    else:
        checks.append(_chk("whois", "WHOIS / RDAP", "na", "Topilmadi", [["Domen", dom], ["Sabab", (who or {}).get("error") or "ma'lumot olinmadi"]]))

    # --- DNS
    if isinstance(dns_err, ScanBlocked):
        raise ChatError("Bu havola ichki yoki shaxsiy tarmoq manziliga olib boradi — tekshirilmaydi", 400)
    if dns and not dns.get("nxdomain"):
        ips = dns["system"] or (dns["A"] + dns["AAAA"])
        d = [["IP manzillar", ", ".join(ips) or "—"], ["A", ", ".join(dns["A"]) or "—"], ["AAAA", ", ".join(dns["AAAA"]) or "—"],
             ["NS", ", ".join(dns["NS"]) or "—"], ["MX", ", ".join(dns["MX"]) or "yo'q"]]
        if dns.get("ttl") is not None:
            d.append(["Eng kichik TTL", f"{dns['ttl']} s"])
        asn = dns.get("asn")
        if asn:
            d += [["ASN", (asn["asn"] + " " + asn.get("name", "")).strip()], ["Tarmoq (prefiks)", asn.get("prefix", "—")], ["Server davlati", asn.get("country", "—")]]
        st = "ok"
        if dns.get("ttl") is not None and dns["ttl"] < 60 and len(ips) > 2:
            findings.append({"sev": "info", "pts": 4, "text": "DNS TTL juda past va IP lar ko'p — tez almashinuvchi hosting belgisi"})
            st = "warn"
        checks.append(_chk("dns", "DNS", st, f"{len(ips)} ta IP", d))
    else:
        findings.append({"sev": "warn", "pts": 15, "text": "Domen IP manzilga aylanmadi — sayt mavjud emas yoki o'chirilgan"})
        checks.append(_chk("dns", "DNS", "bad", "Topilmadi", [["Domen", t.host], ["Natija", "NXDOMAIN / javob yo'q"]]))

    # --- Redirects & final URL
    final_url = t.url
    hops: list[dict] = []
    if page is not None:
        hops = page.hops
        final_url = page.url
    n_red = max(len(hops) - 1, 0)
    ft = None
    try:
        ft = parse_target(final_url)
    except ChatError:
        pass
    if page is None and page_err is not None:
        if isinstance(page_err, ScanBlocked):
            findings.append({"sev": "bad", "pts": 30, "text": "Havola redirect orqali ichki/shaxsiy tarmoq manziliga yo'naltiradi"})
            checks.append(_chk("redirects", "Redirects", "bad", "Bloklandi", [["Sabab", "ichki tarmoq manzili"]]))
            blocked = True
        else:
            msg = "sayt javob bermadi"
            if isinstance(page_err, ssl.SSLError):
                msg = "TLS xatosi"
            elif isinstance(page_err, ScanNoDNS):
                msg = "domen topilmadi"
            elif isinstance(page_err, (TimeoutError, socket.timeout)):
                msg = "vaqt tugadi"
            if not (dns and dns.get("nxdomain")):
                findings.append({"sev": "info", "pts": 3, "text": f"Sahifani ochib bo'lmadi ({msg})"})
            checks.append(_chk("redirects", "Redirects", "na", "Yo'q", [["Holat", msg]]))
    elif page is None:
        checks.append(_chk("redirects", "Redirects", "na", "O'tkazib yuborildi", [["Sabab", f"port {t.port} tekshirilmaydi"]]))
    else:
        cross = ft is not None and registrable(ft.host) != dom
        st = "ok"
        if n_red >= 4 or page.too_many:
            findings.append({"sev": "warn", "pts": 8, "text": f"Juda ko'p yo'naltirish ({n_red} ta)"})
            st = "warn"
        if cross and n_red:
            findings.append({"sev": "info", "pts": 4 if dom not in SHORTENERS else 0, "text": f"Havola boshqa domenga yo'naltiradi: {ft.host}"})
            st = "warn" if dom not in SHORTENERS else st
        if t.scheme == "https" and ft is not None and ft.scheme == "http":
            findings.append({"sev": "warn", "pts": 10, "text": "Redirect HTTPS dan shifrlanmagan HTTP ga tushadi"})
            st = "warn"
        chain = [[f"{i + 1}. [{h['status']}]", h["url"][:180]] for i, h in enumerate(hops)]
        checks.append(_chk("redirects", "Redirects", st, f"{n_red} ta" if n_red else "Yo'q", chain or [["Holat", "redirect yo'q"]]))

    # --- TLS
    tls = None
    tls_target = ft if (ft and ft.scheme == "https" and ft.port_ok) else (t if t.scheme == "https" and t.port_ok else None)
    if tls_target is not None and not (dns and dns.get("nxdomain")) and not blocked:
        try:
            tls = tls_step(tls_target.host, tls_target.port)
        except ScanBlocked:
            tls = None
        except Exception as e:
            tls = {"error": str(e)[:100], "fatal": True, "host": tls_target.host}
    if tls_target is None:
        scheme_note = "sayt HTTPS ishlatmaydi" if (ft or t).scheme == "http" else "tekshirilmadi"
        checks.append(_chk("tls", "SSL / TLS", "warn" if (ft or t).scheme == "http" else "na", "Yo'q" if (ft or t).scheme == "http" else "—", [["Holat", scheme_note]]))
    elif tls is None or tls.get("fatal"):
        err = (tls or {}).get("error") or "ulanib bo'lmadi"
        checks.append(_chk("tls", "SSL / TLS", "warn", "Xato", [["Xato", str(err)]]))
        findings.append({"sev": "warn", "pts": 12, "text": f"TLS ulanish o'rnatilmadi: {err}"})
    else:
        na, nb = tls.get("not_after"), tls.get("not_before")
        days_left = (na - _now()).days if na else None
        el = (tls.get("error") or "").lower()
        st, val = "ok", "Yaroqli"
        if not tls["verified"]:
            if "expired" in el:
                st, val, msg = "bad", "Muddati o'tgan", "SSL sertifikat muddati o'tgan"
            elif tls.get("mismatch") or "hostname" in el:
                st, val, msg = "bad", "Domen mos emas", "SSL sertifikat boshqa domen uchun berilgan"
            elif tls.get("self_signed") or "self-signed" in el or "self signed" in el:
                st, val, msg = "bad", "O'zi imzolagan", "SSL sertifikat o'zi-o'zini imzolagan (ishonchsiz)"
            else:
                st, val, msg = "bad", "Ishonchsiz", f"SSL sertifikat ishonchli emas: {tls.get('error') or 'noma’lum xato'}"
            findings.append({"sev": "bad", "pts": 30, "text": msg})
        elif days_left is not None and days_left < 7:
            st, val = "warn", f"{max(days_left, 0)} kun qoldi"
            findings.append({"sev": "info", "pts": 3, "text": "SSL sertifikat muddati tugashiga bir haftadan kam qoldi"})
        d = [["Domen", tls.get("host", "")], ["Kimga berilgan", tls.get("subject") or "—"], ["Beruvchi", tls.get("issuer") or "—"],
             ["Boshlanish", _date(nb)], ["Tugash", _date(na) + (f" ({days_left} kun)" if days_left is not None else "")],
             ["Protokol", tls.get("version") or "—"], ["Shifr", tls.get("cipher") or "—"], ["Zanjir", "tekshirildi ✓" if tls["verified"] else (tls.get("error") or "xato")]]
        if tls.get("san"):
            d.append(["SAN", ", ".join(tls["san"])])
        checks.append(_chk("tls", "SSL / TLS", st, val, d))

    # --- Threat intel
    if ft is not None and final_url != t.url:
        try:
            for x in FEEDS.check([final_url], ft.host, protected=_protected):
                if x["state"] in ("hit", "near"):
                    feeds.append(dict(x, name=x["name"] + " (yakuniy URL)"))
        except Exception:
            pass
    hits = [x for x in feeds if x["state"] == "hit"]
    near = [x for x in feeds if x["state"] == "near"]
    live = [x for x in feeds if x["state"] != "na"]
    for x in hits:
        findings.append({"sev": "bad", "pts": 80, "text": f"{x['name']}: {x['note']}", "strong": True})
    for x in near:
        findings.append({"sev": "warn", "pts": 30, "text": f"{x['name']}: {x['note']}"})
    td = [[x["name"], {"hit": "⚠ ", "near": "⚠ ", "clean": "✓ ", "na": "— "}[x["state"]] + x["note"]] for x in feeds]
    if popular:
        td.append(["Mashhurlik (Tranco)", "✓ dunyodagi eng ko'p ochiladigan saytlar ro'yxatida"])
    if not (settings.gsb_key or settings.vt_key or settings.urlhaus_key):
        td.append(["Ixtiyoriy manbalar", "GSB / VirusTotal / URLhaus kalitlari kerak emas — kalitsiz ro'yxatlar ishlayapti"])
    if hits:
        checks.append(_chk("threat", "Threat Intel", "bad", f"{len(hits)} ta xavf", td))
    elif near:
        checks.append(_chk("threat", "Threat Intel", "warn", "Shubhali", td))
    elif live:
        checks.append(_chk("threat", "Threat Intel", "ok", f"Toza ({len(live)}/{len(feeds)})", td))
    else:
        checks.append(_chk("threat", "Threat Intel", "na", "Ulanmagan", td or [["Holat", "manbalar javob bermadi"]]))

    # --- Final URL + sahifa tahlili
    pa = None
    if page is not None and page.status:
        pa = page_analysis(page)
        fd = [["Yakuniy URL", final_url[:300]], ["HTTP holat", str(page.status)], ["Turi", pa["ctype"] or "—"], ["Server", pa["server"] or "—"],
              ["HSTS", "bor" if pa["hsts"] else "yo'q"]]
        stf = "ok"
        if ft and registrable(ft.host) != dom:
            stf = "warn"
        if page.status >= 400:
            stf = "warn"
        shown = (ft.uhost if ft else t.uhost)
        checks.append(_chk("final", "Final URL", stf, shown[:40], fd))
        pd = [["Sarlavha (title)", pa["title"] or "—"], ["Parol maydoni", "bor" if pa["password"] else "yo'q"],
              ["Tashqi forma", ", ".join(pa["ext_form"]) or "yo'q"], ["Meta-refresh", "bor" if pa["meta_refresh"] else "yo'q"],
              ["Fayl yuklash", {"exe": "bajariladigan fayl", "file": "fayl/arxiv", "": "yo'q"}[pa["download"]]]]
        sp_ = "ok"
        if pa["download"] == "exe":
            findings.append({"sev": "bad", "pts": 30, "text": "Havola bajariladigan fayl (.apk/.exe va h.k.) yuklab olishga olib boradi"})
            sp_ = "bad"
        elif pa["download"] == "file":
            findings.append({"sev": "warn", "pts": 8, "text": "Havola fayl yoki arxiv yuklab olishga olib boradi"})
            sp_ = "warn"
        if pa["password"] and ft and ft.scheme == "http":
            findings.append({"sev": "bad", "pts": 30, "text": "Parol so'raydigan forma shifrlanmagan (http) sahifada"})
            sp_ = "bad"
        elif pa["password"]:
            findings.append({"sev": "info", "pts": 4, "text": "Sahifada parol kiritish maydoni bor — ma'lumot kiritishdan oldin domenni tekshiring"})
            sp_ = "warn" if sp_ == "ok" else sp_
        if pa["ext_form"]:
            findings.append({"sev": "warn", "pts": 15, "text": "Sahifadagi forma ma'lumotni boshqa domenga yuboradi: " + ", ".join(pa["ext_form"][:2])})
            sp_ = "warn" if sp_ == "ok" else sp_
        if pa["password"] and age_days is not None and age_days < 30:
            findings.append({"sev": "bad", "pts": 20, "text": "Yangi domen + parol so'rovchi sahifa — fishingning odatiy belgisi"})
            sp_ = "bad"
        if pa["meta_refresh"]:
            findings.append({"sev": "info", "pts": 3, "text": "Sahifa avtomatik boshqa joyga o'tkazadi (meta-refresh)"})
        checks.append(_chk("page", "Sahifa", sp_, (pa["title"] or "Sarlavhasiz")[:32], pd))
    else:
        checks.append(_chk("final", "Final URL", "na", (ft.uhost if ft else t.uhost)[:40], [["Yakuniy URL", final_url[:300]], ["Holat", "sahifa ochilmadi"]]))
        checks.append(_chk("page", "Sahifa", "na", "—", [["Holat", "sahifa tahlil qilinmadi"]]))

    # --- Kontent tahlili (HTML: formalar, karta/OTP maydonlari, ma'lumot yuborish manzillari, brend, yashirin kod)
    ca = None
    fdom = registrable(ft.host) if ft else dom
    if pa is not None and page is not None and page.body and pa["ctype"] in ("text/html", "application/xhtml+xml", ""):
        official_for = lambda b: fdom in (_rules.BRANDS.get(b) or _rules.WEAK_BRANDS.get(b) or set())
        try:
            ca = _rules.analyze_html(page.body, final_url, is_official_for=official_for)
        except Exception:   # tahlil xatosi butun skanni to'xtatmasin
            ca = None
    if ca is not None:
        cf, facts = ca["findings"], ca["facts"]
        findings.extend(cf)
        kinds = set(facts.get("kinds") or [])
        if age_days is not None and age_days < 30 and kinds & {"card", "cvv", "otp"} and not facts.get("official"):
            findings.append({"sev": "bad", "pts": 20, "text": "Yangi domen + karta/SMS-kod so'raydigan sahifa — fishingning odatiy belgisi"})
        kind_names = {"card": "karta raqami", "cvv": "CVV/CVC", "expiry": "amal qilish muddati", "otp": "SMS/OTP kod", "passport": "pasport/JSHSHIR", "seed": "seed-ibora"}
        cd = [["Formalar", str(facts["forms"])], ["Kiritish maydonlari", str(facts["inputs"])],
              ["Maxfiy maydonlar", ", ".join(kind_names.get(k, k) for k in sorted(kinds)) + (", parol" if facts["password"] else "") if (kinds or facts["password"]) else "yo'q"],
              ["Ma'lumot yuboriladi", ", ".join(facts["exfil"]) or "oddiy forma"], ["Sahifa brendi", facts["brand"] or "aniqlanmadi"],
              ["Yashirin JS", "bor" if facts.get("obfuscated") else "yo'q"], ["iframe / tashqi skript", f"{facts['iframes']} / {facts.get('ext_script_hosts', 0)}"]]
        cd += [[{"bad": "⚠", "warn": "!", "info": "i"}[x["sev"]], x["text"]] for x in cf]
        st_c = _status_of(cf)
        checks.append(_chk("content", "Kontent", st_c, "Toza" if st_c == "ok" else f"{len([x for x in cf if x['sev'] != 'info'])} belgi", cd))
    else:
        checks.append(_chk("content", "Kontent", "na", "—", [["Holat", "HTML sahifa tahlil qilinmadi"]]))

    # --- Cloaking: skaner va telefon brauzeri ko'rgan sahifa bir xilmi?
    if bot_blocked:
        checks.append(_chk("cloak", "Cloaking", "na", "—", [["Holat", "skaner nomi bloklandi (bot-himoya); telefon ko'rinishi tahlil qilindi"]]))
        findings.append({"sev": "info", "pts": 0, "text": "Sayt skaner nomini bloklaydi (bot-himoya) — tahlil telefon brauzeri ko'rinishi bo'yicha qilindi"})
    elif pa is not None and page is not None and mob is not None and mob.status:
        pm = page_analysis(mob)
        va = {"status": page.status, "host": ft.host if ft else "", "title": pa["title"], "password": pa["password"]}
        vb = {"status": mob.status, "host": (urlsplit(mob.url).hostname or "").lower(), "title": pm["title"], "password": pm["password"]}
        diffs = _rules.compare_views(va, vb)
        cl = [["Skaner ko'rdi", f"HTTP {page.status} · {va['host'][:40]}"], ["Telefon brauzeri ko'rdi", f"HTTP {mob.status} · {vb['host'][:40]}"]]
        cl += [["Farq", d["text"]] for d in diffs] or [["Natija", "ikkala ko'rinish bir xil"]]
        pts = min(30, sum(d["pts"] for d in diffs))
        sev_c = "warn" if any(d["sev"] == "warn" for d in diffs) else "ok"
        if pts and sev_c == "warn":
            findings.append({"sev": "warn", "pts": pts, "text": "Cloaking: sayt skanerga va telefon brauzeriga turlicha ko'rinadi — " + "; ".join(d["text"] for d in diffs[:2])})
        elif diffs:
            findings.append({"sev": "info", "pts": pts, "text": "Skaner va telefon ko'rinishi orasida kichik farq: " + diffs[0]["text"]})
        checks.append(_chk("cloak", "Cloaking", sev_c, "Farq bor" if sev_c == "warn" else "Farq yo'q", cl))
    else:
        checks.append(_chk("cloak", "Cloaking", "na", "—", [["Holat", "solishtirib bo'lmadi"]]))

    # --- URL tahlili
    ucheck = [["Domen", t.uhost], ["Ro'yxatdan o'tadigan qism", dom], ["Port", str(t.port)], ["Sxema", t.scheme.upper()]]
    ucheck += [[{"bad": "⚠", "warn": "!", "info": "i"}[x["sev"]], x["text"]] for x in url_findings] or [["Natija", "URL tuzilishida shubhali belgi yo'q"]]
    st_u = _status_of(url_findings)
    n_u = len([x for x in url_findings if x["sev"] != "info"])
    checks.append(_chk("url", "URL tahlili", st_u, "Toza" if st_u == "ok" else f"{n_u} belgi", ucheck))

    order = ["whois", "dns", "tls", "redirects", "threat", "final", "page", "content", "cloak", "url"]
    checks.sort(key=lambda c: order.index(c["id"]))
    score = min(100, sum(x["pts"] for x in findings))
    strong = any(x.get("strong") for x in findings)
    level = "bad" if (score >= 40 or strong) else "warn" if score >= 15 else "ok"
    label = {"ok": "Xavfli belgilar topilmadi", "warn": "Ehtiyot bo'ling — shubhali belgilar bor", "bad": "Xavfli bo'lishi mumkin — ochmang"}[level]
    sev_order = {"bad": 0, "warn": 1, "info": 2}
    findings.sort(key=lambda x: (sev_order[x["sev"]], -x["pts"]))

    # Foydalanuvchi uchun aniq tavsiyalar
    facts = (ca or {}).get("facts", {})
    asks_secret = bool(facts.get("password") or set(facts.get("kinds") or []) & {"card", "cvv", "otp", "seed", "passport"})
    has_exe = bool((pa or {}).get("download") == "exe" or facts.get("exe_links"))
    advice: list[str] = []
    if level == "bad":
        advice.append("Havolani ochmang. Agar ochgan bo'lsangiz — hech narsa kiritmang va hech narsani o'rnatmang.")
    elif level == "warn":
        advice.append("Ehtiyot bo'ling: ma'lumot kiritishdan oldin domenni rasmiy sayt bilan harfma-harf solishtiring.")
    if asks_secret and level != "ok":
        advice.append("Parol, karta raqami, CVV yoki SMS-kodni kiritmang. Kiritgan bo'lsangiz — parolni darhol almashtiring, kartani bankingizga qo'ng'iroq qilib bloklang.")
    if has_exe:
        advice.append("Dastur (.apk/.exe) yuklamang — faqat Google Play / App Store yoki rasmiy saytdan o'rnating.")
    if dom in SHORTENERS or n_red:
        advice.append("Havola yo'naltiradi: asl manzilni «Final URL» bo'limidan tekshiring.")
    if level == "ok":
        advice.append("Hozircha xavf belgilari topilmadi. Baribir ma'lumot kiritishdan oldin domenni tekshiring.")

    # Ishonchni oshiruvchi belgilar (faqat xavfsiz natijada ko'rsatiladi)
    good: list[str] = []
    if level == "ok":
        if age_days is not None and age_days >= 730:
            good.append(f"Domen {age_text(age_days)} oldin ro'yxatdan o'tgan")
        if popular:
            good.append("Dunyodagi eng mashhur saytlar ro'yxatida")
        if tls is not None and not tls.get("fatal") and tls.get("verified"):
            good.append("SSL sertifikat yaroqli va domenga mos")
        if facts and not facts.get("exfil") and not asks_secret:
            good.append("Sahifa maxfiy ma'lumot so'ramaydi")
        if live and not hits and not near:
            good.append(f"{len(live)} ta xavf ro'yxatida topilmadi")
    ok_checks = len([c for c in checks if c["status"] != "na"])
    return {"ok": True, "url": t.url, "host": t.uhost, "final_url": final_url, "title": (pa or {}).get("title", ""),
            "verdict": {"level": level, "score": score, "label": label}, "checks": checks,
            "findings": [{"sev": x["sev"], "text": x["text"]} for x in findings][:14],
            "advice": advice[:4], "good": good[:5], "coverage": {"done": ok_checks, "total": len(checks)},
            "scanned_at": int(time.time()), "took_ms": int((time.monotonic() - t0) * 1000),
            "note": "Bu avtomatik tekshiruv — 100% kafolat emas."}


# ------------------------------------------------------------------------------------------- Kesh

_cache: "OrderedDict[tuple, tuple[float, dict]]" = OrderedDict()
_cache_lock = threading.Lock()


def _cget(key):
    with _cache_lock:
        v = _cache.get(key)
        if v and time.time() - v[0] < CACHE_TTL:
            _cache.move_to_end(key)
            return v[1]
        _cache.pop(key, None)
    return None


def _cput(key, val):
    with _cache_lock:
        _cache[key] = (time.time(), val)
        _cache.move_to_end(key)
        while len(_cache) > CACHE_MAX:
            _cache.popitem(last=False)


_inflight: "dict[tuple, Future]" = {}
_inflight_lock = threading.Lock()


def scan(raw: str, fresh: bool = False) -> dict:
    t = parse_target(raw)
    key = ("scan", t.url)
    if not fresh:
        hit = _cget(key)
        if hit:
            return hit
    # Bir vaqtning o'zida bir xil havola so'ralsa, ishni takrorlamaymiz — natijani kutamiz (xotira va tarmoq tejaladi)
    with _inflight_lock:
        fut = _inflight.get(key)
        owner = fut is None
        if owner:
            fut = _inflight[key] = Future()
    if not owner:
        try:
            return fut.result(timeout=40)
        except ChatError:
            raise
        except Exception:
            raise ChatError("Tekshirib bo'lmadi, qayta urinib ko'ring", 503) from None
    try:
        if not _SCAN_SEM.acquire(timeout=3):
            raise ChatError("Skaner band, bir ozdan keyin urinib ko'ring", 503)
        try:
            res = _scan(t)
        finally:
            _SCAN_SEM.release()
        _cput(key, res)
        fut.set_result(res)
        return res
    except BaseException as e:
        fut.set_exception(e)
        raise
    finally:
        with _inflight_lock:
            _inflight.pop(key, None)


# ----------------------------------------------------------------------------------- Screenshot


def shot(raw: str, fresh: bool = False) -> dict:
    t = parse_target(raw)
    tpl = settings.shot_url
    if not tpl or "{url" not in tpl:
        return {"ok": False, "reason": "off", "message": "Skrinshot xizmati sozlanmagan"}
    key = ("shot", t.url)
    if not fresh:
        hit = _cget(key)
        if hit:
            return hit
    try:
        resolve_public(t.host, t.port)
    except ScanBlocked:
        raise ChatError("Bu havola ichki yoki shaxsiy tarmoq manziliga olib boradi — tekshirilmaydi", 400) from None
    except ScanNoDNS:
        return {"ok": False, "reason": "nodns", "message": "Domen topilmadi — skrinshot olinmadi"}
    if Image is None:
        return {"ok": False, "reason": "nopil", "message": "Pillow o'rnatilmagan"}
    if not _SHOT_SEM.acquire(timeout=3):
        raise ChatError("Skaner band, bir ozdan keyin urinib ko'ring", 503)
    try:
        u = tpl.replace("{urlenc}", quote(t.url, safe="")).replace("{url}", t.url)
        res = None
        for attempt in range(2):
            try:
                r = http_request(u, headers={"Accept": "image/*"}, max_bytes=SHOT_MAX_BYTES, max_hops=3, timeout=20, trusted=True)
            except (ScanBlocked, ScanNoDNS, OSError, http.client.HTTPException):
                res = {"ok": False, "reason": "provider", "message": "Skrinshot xizmatiga ulanib bo'lmadi"}
                break
            ct = r.headers.get("content-type", "").split(";")[0].lower()
            if r.status == 200 and ct.startswith("image/") and r.body:
                res = _process_shot(r.body)
                break
            res = {"ok": False, "reason": "provider", "message": f"Skrinshot olinmadi (xizmat javobi: {r.status})"}
            if attempt == 0 and r.status in (202, 404, 429, 500, 502, 503, 504):
                time.sleep(2.5)
                continue
            break
    finally:
        _SHOT_SEM.release()
    if res and res.get("ok"):
        res["via"] = (urlsplit(tpl).hostname or "")[:60]
        _cput(key, res)
    return res or {"ok": False, "reason": "provider", "message": "Skrinshot olinmadi"}


def _process_shot(data: bytes) -> dict:
    """Begona rasm: faqat Pillow orqali qayta kodlanadi (metadata/skript qoldirilmaydi), o'lcham cheklanadi."""
    try:
        im = Image.open(BytesIO(data))
        w, h = im.size
        if w < 16 or h < 16 or w * h > SHOT_MAX_PIXELS:
            return {"ok": False, "reason": "bad", "message": "Skrinshot yaroqsiz"}
        im.load()
        if im.mode in ("RGBA", "LA", "P"):
            im = im.convert("RGBA")
            base = Image.new("RGB", im.size, (255, 255, 255))
            base.paste(im, mask=im.getchannel("A"))
            im = base
        else:
            im = im.convert("RGB")
        if im.height > im.width * 0.7:
            im = im.crop((0, 0, im.width, int(im.width * 0.7)))
        im.thumbnail((720, 504))
        out = BytesIO()
        im.save(out, "JPEG", quality=72, optimize=True)
        b = out.getvalue()
        return {"ok": True, "image": "data:image/jpeg;base64," + base64.b64encode(b).decode(), "w": im.width, "h": im.height, "bytes": len(b)}
    except Exception:
        return {"ok": False, "reason": "bad", "message": "Skrinshot yaroqsiz"}
