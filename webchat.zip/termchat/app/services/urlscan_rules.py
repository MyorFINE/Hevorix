"""Havola skaneri: tarmoqsiz (sof) qoidalar — kalit kerak emas.

Bu yerda faqat matn/HTML tahlili bor: tarmoqqa chiqish, fayl yozish yo'q, shuning uchun tez va oson sinaladi.
  * URL evristikasi: brend taqlidi (o'zbek bank/to'lov xizmatlari ham), aralash alifbo (lotin+kirill), bepul hosting,
    tasodifiy (DGA) domenlar, yo'l/so'rovdagi brend, ochiq redirect parametrlari;
  * HTML tahlili (html.parser, regex emas): Telegram-bot/Discord-webhook orqali ma'lumot o'g'irlash, karta/OTP/parol maydonlari,
    sahifa brendi va domen nomuvofiqligi, yashirin iframe, obfuskatsiyalangan JS, kripto-mayner, yuklab olish havolalari.
Natija: [{"sev": "bad|warn|info", "pts": int, "text": str}] — urlscan.py ballarni shu bo'yicha yig'adi.
"""
from __future__ import annotations

import math
import re
import unicodedata
from html.parser import HTMLParser
from urllib.parse import parse_qsl, unquote, urljoin, urlsplit

# ------------------------------------------------------------------------------------------ brendlar

# Kuchli brendlar: domen tarkibida shu nom bo'lsa va domen rasmiy ro'yxatda bo'lmasa — taqlid.
BRANDS: dict[str, set[str]] = {
    "instagram": {"instagram.com", "cdninstagram.com"}, "facebook": {"facebook.com", "fb.com", "fb.me", "fbcdn.net"},
    "google": {"google.com", "google.uz", "goo.gl", "googleapis.com", "gstatic.com", "youtube.com", "youtu.be", "gmail.com"},
    "telegram": {"telegram.org", "t.me", "telegram.me", "telegra.ph", "telegram.dog"}, "whatsapp": {"whatsapp.com", "whatsapp.net", "wa.me"},
    "paypal": {"paypal.com", "paypal.me"}, "apple": {"apple.com", "icloud.com"},
    "microsoft": {"microsoft.com", "live.com", "office.com", "outlook.com"},
    "tiktok": {"tiktok.com", "tiktokcdn.com"}, "binance": {"binance.com"}, "metamask": {"metamask.io"}, "netflix": {"netflix.com"},
    "amazon": {"amazon.com", "amazon.co.uk", "amazonaws.com"}, "steam": {"steampowered.com", "steamcommunity.com"},
    "twitter": {"twitter.com", "x.com"}, "linkedin": {"linkedin.com"},
    # O'zbekiston: to'lov tizimlari va banklar (fishing shularga eng ko'p uriladi)
    "payme": {"payme.uz"}, "uzcard": {"uzcard.uz"}, "paynet": {"paynet.uz"}, "uzum": {"uzum.uz", "uzumbank.uz", "uzum.com"},
    "humans": {"humans.uz"}, "anorbank": {"anorbank.uz"}, "kapitalbank": {"kapitalbank.uz"}, "ipakyulibank": {"ipakyulibank.uz"},
    "tbcbank": {"tbcbank.uz"}, "davrbank": {"davrbank.uz"}, "hamkorbank": {"hamkorbank.uz"}, "xalqbank": {"xb.uz", "xalqbank.uz"},
    "agrobank": {"agrobank.uz"}, "infinbank": {"infinbank.com", "infinbank.uz"}, "asakabank": {"asakabank.uz"},
    "aloqabank": {"aloqabank.uz"}, "turonbank": {"turonbank.uz"}, "ziraat": {"ziraatbank.uz"}, "nbu": {"nbu.uz", "nbu.com"},
    "soliq": {"soliq.uz"}, "mygov": {"my.gov.uz", "gov.uz"}, "uzpost": {"pochta.uz", "uzpost.uz"}, "olx": {"olx.uz", "olx.com"},
    "yandex": {"yandex.ru", "yandex.com", "yandex.uz", "ya.ru"}, "mailru": {"mail.ru", "vk.com", "ok.ru"},
}
# Umumiy so'z bo'lishi mumkin bo'lgan nomlar: faqat xavfli so'z (login, bonus...) yoki shubhali zona bilan birga ogohlantiramiz.
WEAK_BRANDS: dict[str, set[str]] = {
    "click": {"click.uz"}, "vk": {"vk.com"}, "ok": {"ok.ru"}, "visa": {"visa.com"}, "humo": {"humocard.uz"},
    "mastercard": {"mastercard.com"}, "sber": {"sberbank.ru", "sber.ru"}, "tinkoff": {"tinkoff.ru"},
}
KEYWORDS = {"login", "signin", "verify", "verification", "secure", "account", "update", "confirm", "wallet", "password", "bonus",
            "prize", "giveaway", "recovery", "suspend", "unlock", "auth", "billing", "support", "helpdesk", "claim", "airdrop",
            "karta", "kredit", "grant", "yutuq", "aksiya", "sovga", "bepul", "tasdiqlash", "kirish", "parol", "pul", "stipendiya"}
WEAK_TRIGGERS = KEYWORDS - {"support", "update", "account", "secure"}

# Bepul hosting / tunnel / dinamik DNS: kim xohlasa subdomen ochadi — fishing uchun qulay.
FREE_HOSTS = {
    "workers.dev", "pages.dev", "vercel.app", "netlify.app", "github.io", "gitlab.io", "blogspot.com", "weebly.com", "wixsite.com",
    "webflow.io", "ngrok.io", "ngrok-free.app", "ngrok.app", "trycloudflare.com", "loca.lt", "duckdns.org", "no-ip.org", "ddns.net",
    "000webhostapp.com", "firebaseapp.com", "web.app", "glitch.me", "repl.co", "replit.app", "herokuapp.com", "onrender.com", "fly.dev",
    "surge.sh", "framer.website", "carrd.co", "godaddysites.com", "square.site", "myshopify.com", "notion.site", "google.com.sites",
    "sites.google.com", "forms.gle", "r2.dev", "s3.amazonaws.com", "storage.googleapis.com", "blob.core.windows.net",
    "ipfs.io", "dweb.link", "typedream.app", "bubbleapps.io", "wordpress.com", "tilda.ws", "mystrikingly.com", "my.canva.site",
}
SHORTENERS = {"bit.ly", "t.co", "tinyurl.com", "goo.gl", "ow.ly", "is.gd", "cutt.ly", "rb.gy", "shorturl.at", "tiny.cc", "clck.ru",
              "vk.cc", "u.to", "buff.ly", "lnkd.in", "s.id", "qr.ae", "soo.gd", "t.ly", "short.io", "shorte.st", "adf.ly", "bl.ink"}
BAD_TLDS = {"zip", "mov", "tk", "ml", "ga", "cf", "gq", "top", "click", "country", "work", "support", "rest", "fit", "cam", "icu",
            "buzz", "monster", "sbs", "cfd", "loan", "men", "date", "download", "racing", "review", "stream", "gdn", "xin",
            "cyou", "bond", "lol", "quest", "vip", "live", "wang", "kim", "pw", "ws", "su"}

_HOMO = str.maketrans({"0": "o", "1": "l", "3": "e", "5": "s", "$": "s", "@": "a"})
# Kirill/yunon harflari lotinga o'xshash (confusables): 'аррlе' kabi domenlarni ushlash uchun.
_CONFUSABLE = {
    "а": "a", "е": "e", "о": "o", "р": "p", "с": "c", "у": "y", "х": "x", "к": "k", "м": "m", "т": "t", "н": "h", "в": "b",
    "і": "i", "ј": "j", "ѕ": "s", "ԁ": "d", "ɡ": "g", "ο": "o", "α": "a", "ν": "v", "ρ": "p", "τ": "t", "ι": "i", "κ": "k",
    "ӏ": "l", "ɩ": "i", "ı": "i", "ⅼ": "l",
}


def _lev(a: str, b: str) -> int:
    if abs(len(a) - len(b)) > 2:
        return 3
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


def registrable(host: str) -> str:
    labels = host.split(".")
    if len(labels) <= 2:
        return host
    if len(labels[-1]) == 2 and labels[-2] in {"co", "com", "org", "net", "gov", "edu", "ac", "or", "ne", "go", "mil"}:
        return ".".join(labels[-3:])
    return ".".join(labels[-2:])


def free_host_root(host: str) -> str | None:
    """Host bepul hosting zonasi ichidami (a.b.workers.dev -> workers.dev)? Bo'lsa shu zona qaytadi."""
    labels = host.split(".")
    for i in range(len(labels) - 1):
        cand = ".".join(labels[i:])
        if cand in FREE_HOSTS:
            return cand
    return None


def _entropy(s: str) -> float:
    if not s:
        return 0.0
    return -sum((c / len(s)) * math.log2(c / len(s)) for c in (s.count(ch) for ch in set(s)))


def _script_of(ch: str) -> str:
    if ch.isascii():
        return "LATIN" if ch.isalpha() else ""
    try:
        name = unicodedata.name(ch)
    except ValueError:
        return "OTHER"
    for s in ("CYRILLIC", "GREEK", "LATIN", "ARMENIAN", "ARABIC", "HEBREW", "CJK", "HIRAGANA", "KATAKANA", "HANGUL", "THAI", "DEVANAGARI"):
        if name.startswith(s):
            return s
    return "OTHER"


def _skeleton(label: str) -> str:
    return "".join(_CONFUSABLE.get(c, c) for c in label.lower())


def _brand_main(labels: list[str]) -> str:
    if len(labels) >= 2 and not (len(labels[-1]) == 2 and labels[-2] in {"co", "com", "org", "net"}):
        return labels[-2]
    return labels[-3] if len(labels) >= 3 else labels[0]


def url_findings(host: str, uhost: str, path: str, query: str, *, scheme: str, port_ok: bool, port: int, userinfo: bool,
                 is_ip: bool, full_len: int, popular: bool = False) -> list[dict]:
    """URL tuzilishi bo'yicha belgilar. popular=True (mashhur domen ro'yxatida) bo'lsa taqlid/tasodifiylik ogohlantirishlari o'tkazib yuboriladi."""
    f: list[dict] = []

    def add(sev, pts, text, strong=False):
        f.append({"sev": sev, "pts": pts, "text": text, "strong": strong})

    dom = registrable(host)
    labels = host.split(".")
    if userinfo:
        add("bad", 25, "Havolada «login@» qismi bor — manzilni yashirish uchun ishlatiladigan hiyla")
    if is_ip:
        add("warn", 20, "Havola domen o'rniga to'g'ridan-to'g'ri IP manzilga olib boradi")
    if scheme == "http":
        add("warn", 10, "Shifrlanmagan ulanish (http) — ma'lumotlar ochiq uzatiladi")
    if not port_ok:
        add("warn", 10, f"Nostandart port ({port}) — sayt tekshirilmadi")
    if "xn--" in host:
        add("warn", 20, f"Domen punycode (maxsus belgilar) bilan yozilgan: {uhost} — o'xshash harflar bilan aldash mumkin")
    if not is_ip and len(labels) >= 5:
        add("warn", 10, "Subdomenlar juda ko'p — odatda aldamchi saytlarda uchraydi")
    if full_len > 200:
        add("info", 4, "Havola g'ayritabiiy darajada uzun")
    if not is_ip and labels[-1] in BAD_TLDS:
        add("warn", 8, f"«.{labels[-1]}» zonasi suiste'molda ko'p uchraydi")
    if not is_ip and dom in SHORTENERS:
        add("info", 5, "Qisqartirilgan havola — asl manzil quyida (Final URL) ko'rsatiladi")
    if is_ip:
        return f

    tokens = [x for x in re.split(r"[.\-_]", host) if x]
    free_root = free_host_root(host)

    # --- aralash alifbo (lotin + kirill/yunon) va kirill taqlidi
    if not host.startswith("xn--") or any(ord(c) > 127 for c in uhost):
        mixed = False
        for lab in uhost.split("."):
            scripts = {_script_of(c) for c in lab} - {""}
            if "LATIN" in scripts and scripts & {"CYRILLIC", "GREEK", "ARMENIAN"}:
                mixed = True
        if mixed:
            add("bad", 30, f"Domenda lotin va boshqa alifbo harflari aralash ({uhost}) — o'xshash harflar bilan aldash", True)
    if not popular:
        brand_hit = False
        if any(ord(c) > 127 for c in uhost):
            sk = _skeleton(uhost)
            for brand, official in {**BRANDS, **WEAK_BRANDS}.items():
                if len(brand) >= 4 and brand in re.split(r"[.\-_]", sk) and dom not in official and uhost != sk:
                    add("bad", 35, f"Domen «{brand}» nomini o'xshash harflar bilan taqlid qiladi ({uhost})", True)
                    brand_hit = True
                    break
        # --- brend nomi domenda (bepul hostingda faqat subdomen qismi hisobga olinadi)
        if not brand_hit:
            scope = re.split(r"[.\-_]", host[: -len(free_root) - 1]) if free_root and len(host) > len(free_root) else tokens
            for brand, official in BRANDS.items():
                if brand in scope and dom not in official:
                    add("bad", 30, f"Domenda «{brand}» nomi bor, lekin bu rasmiy domen emas ({dom})", True)
                    brand_hit = True
                    break
        if not brand_hit and "gov" in tokens and "uz" in tokens and not host.endswith(".gov.uz"):
            add("bad", 28, f"Domen davlat xizmati (gov.uz) nomini taqlid qiladi, lekin rasmiy emas ({dom})", True)
            brand_hit = True
        if not brand_hit:
            risky = bool(set(tokens) & WEAK_TRIGGERS) or labels[-1] in BAD_TLDS or free_root
            for brand, official in WEAK_BRANDS.items():
                if brand in tokens and dom not in official and risky:
                    add("bad", 25, f"Domenda «{brand}» nomi va ehtiyot so'z/zona bor, lekin bu rasmiy domen emas ({dom})", True)
                    brand_hit = True
                    break
        # --- imlo xatosi bilan taqlid (paypa1, instagrarn)
        if not brand_hit:
            main = _brand_main(labels)
            norm = main.translate(_HOMO).replace("rn", "m").replace("vv", "w")
            for brand, official in BRANDS.items():
                if dom in official or len(brand) < 6:
                    continue
                if main != brand and (norm == brand or _lev(norm, brand) <= 1):
                    add("bad", 30, f"Domen «{brand}» nomiga juda o'xshash ({dom}) — taqlid bo'lishi mumkin", True)
                    brand_hit = True
                    break
        # --- brend yo'lda/so'rovda: evil.com/instagram/login
        if not brand_hit:
            low = (unquote(path) + " " + unquote(query)).lower()
            for brand, official in BRANDS.items():
                if len(brand) >= 5 and dom not in official and re.search(r"(?<![a-z0-9])" + re.escape(brand) + r"(?![a-z0-9])", low) \
                        and (set(re.split(r"[^a-z]+", low)) & WEAK_TRIGGERS or free_root):
                    add("warn", 14, f"Havola yo'lida «{brand}» nomi va kirish/tasdiqlash so'zlari bor, lekin domen rasmiy emas ({dom})")
                    break
        kw = sorted(set(tokens) & KEYWORDS)
        if kw:
            add("warn", 8, "Domenda ehtiyot so'zlar: " + ", ".join(kw))

    # --- bepul hosting / tunnel
    if free_root:
        sub = host[: -len(free_root) - 1]
        if sub and (set(re.split(r"[.\-_]", sub)) & WEAK_TRIGGERS or any(b in re.split(r"[.\-_]", sub) for b in BRANDS)):
            add("warn", 18, f"Bepul hosting ({free_root}) subdomeni va ehtiyot so'zlar — fishing sahifalar ko'pincha shunday joylashtiriladi")
        else:
            add("info", 5, f"Bepul hosting/tunnel xizmati ({free_root}) — egasi noma'lum bo'lishi mumkin")

    # --- tasodifiy (DGA) ko'rinish
    if not popular and free_root is None:
        main = _brand_main(labels)
        letters = re.sub(r"[^a-z]", "", main)
        digits = sum(c.isdigit() for c in main)
        vowels = sum(c in "aeiouy" for c in letters)
        if len(main) >= 12 and _entropy(main) >= 3.5 and letters and vowels / max(len(letters), 1) < 0.25:
            add("warn", 10, f"Domen nomi tasodifiy harflarga o'xshaydi ({main}) — avtomatik yaratilgan bo'lishi mumkin")
        elif len(main) >= 6 and digits / len(main) > 0.45:
            add("info", 5, "Domen nomida raqamlar juda ko'p")
        if main.count("-") >= 3:
            add("info", 5, "Domen nomida defislar juda ko'p")

    # --- ochiq redirect parametri / yashirin manzil
    try:
        for k, v in parse_qsl(query, keep_blank_values=False)[:20]:
            if re.fullmatch(r"(?i)(url|u|redirect|redirect_uri|redir|next|continue|return|returnto|goto|dest|target|link|to)", k) \
                    and re.match(r"(?i)https?://|//", v):
                ov = (urlsplit(v if "://" in v else "https:" + v).hostname or "").lower()
                if ov and registrable(ov) != dom:
                    add("warn", 10, f"Havola boshqa saytga yo'naltiruvchi parametr ichiga olingan ({k}= → {ov[:40]})")
                    break
    except ValueError:
        pass
    if "%25" in path + query or len(re.findall(r"%[0-9a-fA-F]{2}", path)) > 12:
        add("info", 5, "Havola yo'lida ortiqcha kodlangan belgilar (%xx) — manzilni yashirish uchun ishlatilishi mumkin")
    if "@" in path:
        add("info", 4, "Havola yo'lida «@» belgisi bor")
    return f


# ------------------------------------------------------------------------------------ HTML tahlili

_EXFIL = (
    (re.compile(r"api\.telegram\.org/bot", re.I), "Telegram bot"),
    (re.compile(r"discord(?:app)?\.com/api/webhooks/", re.I), "Discord webhook"),
    (re.compile(r"hooks\.slack\.com/services/", re.I), "Slack webhook"),
    (re.compile(r"webhook\.site/|pipedream\.net/|requestbin|ntfy\.sh/", re.I), "test/webhook servisi"),
    (re.compile(r"script\.google\.com/macros/s/", re.I), "Google Apps Script"),
    (re.compile(r"formspree\.io/|getform\.io/|formsubmit\.co/|web3forms\.com/", re.I), "forma-yig'ish servisi"),
)
_MINER = re.compile(r"coinhive|coin-hive|cryptonight|webminer|minero\.cc|authedmine|crypto-loot|cryptoloot|jsecoin", re.I)
_OBFUSC = (
    re.compile(r"eval\s*\(\s*(?:atob|unescape|decodeURIComponent)\s*\(", re.I),
    re.compile(r"document\.write\s*\(\s*unescape\s*\(", re.I),
    re.compile(r"eval\s*\(\s*function\s*\(\s*p\s*,\s*a\s*,\s*c\s*,\s*k\s*,\s*e\s*,\s*[dr]\s*\)", re.I),
    re.compile(r"\bnew\s+Function\s*\(\s*atob", re.I),
)
_SCAM_TEXT = re.compile(
    r"your (?:computer|device|pc|phone) (?:is|has been) (?:infected|blocked|locked)|virus(?:es)? (?:detected|found)|call (?:microsoft|apple) support"
    r"|you(?:'ve| have)? won|congratulations[!, ].{0,40}(?:winner|selected|prize)|claim your (?:prize|reward|bonus)"
    r"|tabriklaymiz.{0,60}(?:yutdingiz|g'olib|sovg'a)|siz yutdingiz|bepul (?:pul|sovg'a|iphone)|yutuqni oling|akkauntingiz (?:bloklandi|cheklandi)"
    r"|kartangiz (?:bloklandi|bloklangan)|ваш (?:аккаунт|карта).{0,20}(?:заблокирован|ограничен)|вы выиграли|поздравляем.{0,40}выиграли",
    re.I)
_WALLET = re.compile(r"eth_requestAccounts|window\.ethereum|solana\.connect|walletconnect|web3modal", re.I)
_WALLET_BAIT = re.compile(r"airdrop|claim|seed phrase|recovery phrase|mnemonic|private key|12[- ]word|24[- ]word|connect wallet", re.I)

# Maydon nomi/placeholder bo'yicha sezgir ma'lumot turlari
_FIELD_KINDS = (
    ("card", re.compile(r"card.?(?:number|num|no)|cc.?num|cc-number|kart[aeiu]?.?(?:raqam|nomer|number)|номер.?карт|pan\b|\bcard\b", re.I)),
    ("cvv", re.compile(r"\bcvv\b|\bcvc\b|cc-csc|security.?code|cvv2|cvc2|код.?безопасност", re.I)),
    ("expiry", re.compile(r"expir|cc-exp|valid.?thru|amal.?qilish|srok|срок.?действ|mm\s*/\s*yy", re.I)),
    ("otp", re.compile(r"\botp\b|one-time-code|sms.?(?:kod|code)|tasdiqlash.?kod|verification.?code|смс|код.?из.?смс|\bpin\b|pin.?kod", re.I)),
    ("passport", re.compile(r"passport|pasport|паспорт|jshshir|pinfl|пинфл", re.I)),
    ("seed", re.compile(r"seed.?phrase|recovery.?phrase|mnemonic|private.?key|secret.?phrase|12.?words|24.?words", re.I)),
)


class _Collector(HTMLParser):
    def __init__(self, base: str):
        super().__init__(convert_charrefs=True)
        self.base = base
        self.title = ""
        self._in_title = False
        self.meta: dict[str, str] = {}
        self.forms: list[dict] = []
        self.inputs: list[dict] = []
        self.iframes: list[dict] = []
        self.scripts: list[str] = []
        self.inline_js: list[str] = []
        self._in_script = False
        self._script_buf: list[str] = []
        self.links: list[str] = []
        self.text: list[str] = []
        self.h1: list[str] = []
        self._in_h1 = False
        self.body_attrs: dict[str, str] = {}
        self.n_tags = 0
        self._skip = 0

    def handle_starttag(self, tag, attrs):
        self.n_tags += 1
        a = {k.lower(): (v or "") for k, v in attrs}
        if tag == "title":
            self._in_title = True
        elif tag == "meta":
            key = (a.get("property") or a.get("name") or a.get("http-equiv") or "").lower()
            if key:
                self.meta[key] = a.get("content", "")[:300]
        elif tag == "form":
            self.forms.append({"action": a.get("action", ""), "method": a.get("method", "get").lower(), "autocomplete": a.get("autocomplete", "")})
        elif tag == "input":
            self.inputs.append(a)
        elif tag == "textarea":
            self.inputs.append({"type": "textarea", **a})
        elif tag in ("iframe", "frame"):
            self.iframes.append(a)
        elif tag == "script":
            if a.get("src"):
                self.scripts.append(a["src"])
            self._in_script = True
            self._script_buf = []
        elif tag == "a" and a.get("href"):
            self.links.append(a["href"])
            if "download" in a:
                self.links.append(a["href"] + "#__download")
        elif tag == "body":
            self.body_attrs = a
        elif tag == "h1":
            self._in_h1 = True
        elif tag in ("style", "noscript", "svg"):
            self._skip += 1
        elif tag == "link" and a.get("rel", "").lower() in ("icon", "shortcut icon") and a.get("href"):
            self.meta["__favicon"] = a["href"][:300]

    def handle_endtag(self, tag):
        if tag == "title":
            self._in_title = False
        elif tag == "script":
            self._in_script = False
            if self._script_buf:
                self.inline_js.append("".join(self._script_buf)[:60000])
            self._script_buf = []
        elif tag == "h1":
            self._in_h1 = False
        elif tag in ("style", "noscript", "svg") and self._skip:
            self._skip -= 1

    def handle_data(self, data):
        if self._in_title:
            self.title += data
        elif self._in_script:
            self._script_buf.append(data)
        elif not self._skip:
            if self._in_h1:
                self.h1.append(data.strip()[:120])
            if sum(len(x) for x in self.text) < 6000:
                self.text.append(data)


def _hostof(url: str, base: str) -> str:
    try:
        return (urlsplit(urljoin(base, url.strip())).hostname or "").lower()
    except ValueError:
        return ""


def _field_blob(a: dict) -> str:
    return " ".join(a.get(k, "") for k in ("name", "id", "placeholder", "autocomplete", "aria-label", "inputmode", "title", "class"))


def analyze_html(body: bytes, final_url: str, *, is_official_for) -> dict:
    """HTML bo'yicha topilmalar va faktlar.
    is_official_for(brand) -> bool: sahifa joylashgan domen shu brendning rasmiy domenimi.
    Qaytaradi: {"findings": [...], "facts": {...}}"""
    txt = body.decode("utf-8", "replace")
    p = _Collector(final_url)
    try:
        p.feed(txt)
        p.close()
    except Exception:  # buzuq HTML — qisman natija bilan davom etamiz
        pass
    host = (urlsplit(final_url).hostname or "").lower()
    dom = registrable(host)
    scheme = urlsplit(final_url).scheme
    f: list[dict] = []

    def add(sev, pts, text, strong=False):
        f.append({"sev": sev, "pts": pts, "text": text, "strong": strong})

    title = re.sub(r"\s+", " ", p.title).strip()[:120]
    site_name = p.meta.get("og:site_name", "")
    visible = re.sub(r"\s+", " ", " ".join(p.text)).strip()
    inputs = [i for i in p.inputs if i.get("type", "text").lower() not in ("hidden", "submit", "button", "checkbox", "radio", "image", "reset")]
    has_pw = any(i.get("type", "").lower() == "password" for i in p.inputs)
    kinds: set[str] = set()
    for i in inputs:
        blob = _field_blob(i)
        ac = i.get("autocomplete", "").lower()
        if ac in ("cc-number", "cc-csc", "cc-exp", "cc-exp-month", "cc-exp-year", "cc-name"):
            kinds.add({"cc-number": "card", "cc-csc": "cvv"}.get(ac, "expiry"))
        if ac == "one-time-code":
            kinds.add("otp")
        for kind, rx in _FIELD_KINDS:
            if rx.search(blob):
                kinds.add(kind)
    card_like = bool(kinds & {"card", "cvv"}) or ("expiry" in kinds and "card" in kinds)
    facts = {"title": title, "forms": len(p.forms), "inputs": len(inputs), "password": has_pw, "kinds": sorted(kinds),
             "iframes": len(p.iframes), "scripts": len(p.scripts), "text_len": len(visible), "exfil": [], "brand": ""}

    # --- ma'lumot o'g'irlash manzillari (HTML + inline JS + forma action)
    corpus = txt[:131072]
    seen = set()
    for rx, name in _EXFIL:
        if rx.search(corpus) and name not in seen:
            seen.add(name)
    facts["exfil"] = sorted(seen)
    strong = [n for n in seen if n in ("Telegram bot", "Discord webhook", "Slack webhook")]
    if strong and (inputs or p.forms):
        add("bad", 40, "Sahifa kiritilgan ma'lumotni " + " / ".join(sorted(strong)) + " orqali yuboradi — fishing to'plamlarining odatiy usuli", True)
    elif strong:
        add("warn", 15, "Sahifa kodida " + " / ".join(sorted(strong)) + " manzili bor")
    elif seen and has_pw:
        add("warn", 14, "Parol so'raydigan sahifa ma'lumotni " + ", ".join(sorted(seen)) + " orqali yuboradi")

    # --- formalar
    ext_form: list[str] = []
    insecure_form = False
    for fm in p.forms[:12]:
        act = fm["action"].strip()
        if not act:
            continue
        h = _hostof(act, final_url)
        if h and registrable(h) != dom and h not in ext_form:
            ext_form.append(h[:80])
        if act.lower().startswith("http://") and (has_pw or card_like):
            insecure_form = True
    facts["ext_form"] = ext_form
    if insecure_form:
        add("bad", 30, "Parol/karta so'raydigan forma shifrlanmagan (http) manzilga yuboriladi")

    # --- sezgir maydonlar (rasmiy brend domenida oddiy holat: faqat http xavfli)
    official_any = any(is_official_for(b) for b in list(BRANDS) + list(WEAK_BRANDS))
    facts["official"] = official_any
    if card_like and scheme == "http":
        add("bad", 35, "Bank kartasi ma'lumotlari shifrlanmagan (http) sahifada so'ralmoqda", True)
    elif card_like and not official_any:
        add("warn", 14, "Sahifa bank kartasi ma'lumotlarini (raqam/CVV) so'raydi — faqat rasmiy to'lov sahifasida kiriting")
    if "otp" in kinds and (has_pw or card_like) and not official_any:
        add("warn", 10, "Sahifa SMS/OTP kod so'raydi — fishing ko'pincha shu kod orqali hisobni egallaydi")
    if "seed" in kinds and not official_any:
        add("bad", 45, "Sahifa seed-ibora (12/24 so'z) yoki shaxsiy kalit so'raydi — hech qachon kiritmang", True)
    if "passport" in kinds and len(inputs) >= 3 and not official_any:
        add("warn", 12, "Sahifa pasport/JSHSHIR kabi shaxsiy ma'lumotlarni so'raydi")

    # --- sahifa brendi va domen nomuvofiqligi
    head_blob = " ".join([title, site_name, p.meta.get("og:title", ""), " ".join(p.h1[:3])]).lower()
    cred = has_pw or card_like or "otp" in kinds
    for brand in {**BRANDS, **WEAK_BRANDS}:
        if len(brand) < 4:
            continue
        if re.search(r"(?<![a-z0-9])" + re.escape(brand) + r"(?![a-z0-9])", head_blob) and not is_official_for(brand):
            facts["brand"] = brand
            if cred:
                add("bad", 35, f"Sahifa «{brand}» deb ko'rsatadi va maxfiy ma'lumot so'raydi, lekin domen rasmiy emas ({dom})", True)
            elif brand in BRANDS and p.forms and len(visible) < 1500:
                add("warn", 12, f"Sahifa sarlavhasida «{brand}» bor, lekin domen rasmiy emas ({dom})")
            break

    # --- yashirin / ustiga qo'yilgan iframe
    hidden_if = 0
    cover_if = 0
    for ifr in p.iframes:
        st = (ifr.get("style", "") + " " + ifr.get("class", "")).lower().replace(" ", "")
        w, h = ifr.get("width", "").strip(), ifr.get("height", "").strip()
        src_h = _hostof(ifr.get("src", ""), final_url) if ifr.get("src") else ""
        if w in ("0", "1") or h in ("0", "1") or "display:none" in st or "visibility:hidden" in st or "opacity:0" in st:
            hidden_if += 1
        elif "position:fixed" in st or "position:absolute" in st:
            if ("100%" in st or "100vw" in st or "100vh" in st) and src_h and registrable(src_h) != dom:
                cover_if += 1
    if hidden_if:
        add("warn", 10, "Sahifada ko'rinmaydigan (yashirin) iframe bor")
    if cover_if:
        add("warn", 14, "Sahifa boshqa domendagi sahifani butun ekranga yopishtirgan (iframe) — aldov belgisi")

    # --- JS: obfuskatsiya, mayner, yo'naltirish, anti-tekshiruv
    js = "\n".join(p.inline_js)[:200000]
    obf = any(rx.search(js) for rx in _OBFUSC) or len(re.findall(r"\\x[0-9a-f]{2}", js, re.I)) >= 60 \
        or len(re.findall(r"String\.fromCharCode", js)) >= 6 or bool(re.search(r"[A-Za-z0-9+/]{2500,}={0,2}", js))
    facts["obfuscated"] = obf
    if obf:
        add("warn", 12, "Sahifadagi JavaScript yashirilgan (obfuskatsiya) — kodini yashirish zararli saytlarda ko'p uchraydi")
    if _MINER.search(corpus):
        add("bad", 40, "Sahifada kripto-mayner (brauzer orqali yashirin qazish) belgilari bor", True)
    if _WALLET.search(js) and _WALLET_BAIT.search(visible + " " + title):
        add("warn", 20, "Sahifa kripto-hamyonni ulashni so'raydi (airdrop/claim) — hamyon bo'shatuvchi aldov bo'lishi mumkin")
    anti = bool(re.search(r"oncontextmenu\s*=\s*[\"']?\s*return\s+false", txt[:20000], re.I)) or "oncontextmenu" in p.body_attrs \
        or bool(re.search(r"keyCode\s*(?:==|===)\s*(?:123|85)\b", js))
    if anti:
        add("info", 6, "Sahifa sichqonchaning o'ng tugmasi/F12 ni bloklaydi — kodni tekshirishga to'sqinlik qiladi")
    short_page = len(visible) < 600 and p.n_tags < 40
    if short_page and re.search(r"(?:window\.|top\.|self\.)?location(?:\.href|\.replace\s*\(|\.assign\s*\(|\s*=)", js):
        add("info", 6, "Sahifa ochilishi bilan JavaScript orqali boshqa manzilga o'tkazadi")
    if re.search(r"onbeforeunload", js) and (has_pw or card_like):
        add("info", 4, "Sahifa yopilayotganda foydalanuvchini ushlab qolishga urinadi")

    # --- aldov matnlari
    scam = _SCAM_TEXT.search(visible + " " + title)
    if scam and (p.forms or inputs or short_page):
        add("warn", 12, "Sahifada aldov/yutuq/bloklash haqidagi shubhali matn bor")

    # --- yuklab olish havolalari
    exe_links = []
    for href in p.links[:200]:
        hh = href.split("#")[0].lower().split("?")[0]
        if hh.endswith((".apk", ".exe", ".msi", ".scr", ".bat", ".cmd", ".jar", ".dmg", ".ps1", ".vbs", ".lnk", ".xapk")):
            exe_links.append(hh.rsplit("/", 1)[-1][:40])
    facts["exe_links"] = exe_links[:3]
    if exe_links:
        if facts["brand"]:
            add("bad", 25, "Sahifa brend nomidan dastur (.apk/.exe) yuklashni taklif qiladi: " + ", ".join(exe_links[:2]), True)
        else:
            add("warn", 15, "Sahifada dastur (.apk/.exe) yuklab olish havolasi bor: " + ", ".join(exe_links[:2]))

    # --- tashqi skriptlar
    ext_js = {h for h in (_hostof(s, final_url) for s in p.scripts[:60]) if h and registrable(h) != dom}
    facts["ext_script_hosts"] = len(ext_js)
    ip_js = [h for h in ext_js if re.fullmatch(r"[0-9.]+|\[[0-9a-f:]+\]", h)]
    if ip_js:
        add("warn", 10, "Sahifa skriptni IP manzildan yuklaydi (domensiz server)")
    facts["ext_form_count"] = len(ext_form)
    return {"findings": f, "facts": facts}


APP_STORES = {"apple.com", "google.com", "onelink.me", "adjust.com", "branch.io", "page.link", "app.link", "appsflyer.com", "microsoft.com"}


def compare_views(a: dict, b: dict) -> list[dict]:
    """Skaner ko'rgan va telefon brauzeri ko'rgan sahifani solishtiradi (cloaking). a/b: {status, host, title, password}."""
    out = []
    if a.get("host") and b.get("host") and registrable(a["host"]) != registrable(b["host"]) and registrable(b["host"]) not in APP_STORES:
        out.append({"sev": "warn", "pts": 18, "text": f"yakuniy domen farq qiladi ({a['host'][:30]} ↔ {b['host'][:30]})"})
    sa, sb = a.get("status", 0), b.get("status", 0)
    if sa and sb and ((sa < 400) != (sb < 400)):
        if sa in (401, 403, 429, 503):   # ko'pincha oddiy bot-himoya (WAF): skaner nomi bloklangan
            out.append({"sev": "info", "pts": 3, "text": f"skaner bloklangan bo'lishi mumkin (HTTP {sa} ↔ {sb})"})
        else:
            out.append({"sev": "warn", "pts": 15, "text": f"HTTP holat farq qiladi ({sa} ↔ {sb})"})
    if a.get("password") != b.get("password"):
        out.append({"sev": "warn", "pts": 12, "text": "parol maydoni faqat bitta ko'rinishda bor"})
    ta, tb = (a.get("title") or "").lower(), (b.get("title") or "").lower()
    if ta and tb and ta != tb and not (ta in tb or tb in ta):
        out.append({"sev": "info", "pts": 4, "text": "sahifa sarlavhasi farq qiladi"})
    return out
