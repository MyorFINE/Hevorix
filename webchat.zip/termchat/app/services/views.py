import time

from app.config import settings
from app.repositories import messages, reactions, users
from app.services import fxstyle, privacy


def _avatar_url(filename):
    return f"/avatars/{filename}" if filename else None


def _ghost(r) -> dict:
    return {"id": r["id"], "username": "", "nickname": "Deleted account", "role": "user", "bio": "",
            "color": None, "joined": None, "avatar": None, "deleted": True, "badge": None, "badge_anim": None,
            "fx": {}, "banner": None, "frame": None, "title": None}


def _is_new(r) -> bool:
    if r["role"] != "user" or not r["created_at"]:
        return False
    if r["trust"] is not None:
        return bool(r["trust"])
    return time.time() - r["created_at"] < settings.new_user_days * 86400


def user_view(uid: int) -> dict:
    r = users.get_view(uid)
    if r["deleted"]:
        return _ghost(r)
    return {
        "id": r["id"],
        "username": r["username"],
        "nickname": r["nickname"],
        "role": r["role"],
        "bio": r["bio"] or "",
        "color": r["color"],
        "joined": r["created_at"],
        "avatar": _avatar_url(r["avatar"]),
        "badge": r["badge"],
        "badge_anim": r["badge_anim"],
        "new": _is_new(r),
        "fx": fxstyle.parse(r["fx"]), "banner": r["banner"], "frame": r["frame"], "title": r["title"],
        "last_seen": None if privacy.seen_hidden(r["id"]) else r["last_seen"],
        "seen_hidden": privacy.seen_hidden(r["id"]),
        "dm_closed": privacy.dm_closed(r["id"]),
    }


def member_view(r, *, admin_view: bool) -> dict:
    v = {
        "id": r["id"],
        "username": r["username"],
        "nickname": r["nickname"],
        "role": r["role"],
        "bio": r["bio"] or "",
        "color": r["color"],
        "joined": r["created_at"],
        "avatar": _avatar_url(r["avatar"]),
        "badge": r["badge"],
        "badge_anim": r["badge_anim"],
        "new": _is_new(r),
        "fx": fxstyle.parse(r["fx"]), "banner": r["banner"], "frame": r["frame"], "title": r["title"],
        "last_seen": None if privacy.seen_hidden(r["id"]) else r["last_seen"],
        "seen_hidden": privacy.seen_hidden(r["id"]),
        "dm_closed": privacy.dm_closed(r["id"]),
    }
    v["ek"], v["sk"] = r["ecdh_pub"], r["sign_pub"]
    if admin_view:
        v["banned"] = bool(r["banned"])
        v["muted"] = r["muted_until"] > time.time()
        v["warns"] = r["warns"] or 0
        v["trust"] = r["trust"]
    return v


def reply_view(rid: int | None) -> dict | None:
    if rid is None:
        return None
    r = messages.get(rid)
    if not r or r["deleted"]:
        return {"id": rid, "deleted": True}
    author = users.get_view(r["user_id"])
    text = "🔒 shifrlangan xabar" if r["e2e"] else " ".join((r["content"] or "").split())
    return {
        "id": rid,
        "uid": r["user_id"],
        "nickname": author["nickname"] if author else "Noma'lum",
        "text": text[:100],
        "image": bool(r["image"]),
        "file": bool(r["file"]),
        "file_name": r["file_name"] if r["file"] else None,
        "deleted": False,
    }


def _channel_fields(view: dict, m) -> dict:
    cid = m["channel_id"]
    if cid:
        from app.repositories import channels as channels_repo
        v, c = channels_repo.post_counts(m["id"])
        view["ch"] = cid
        view["views"] = v
        view["comments"] = c
        from app.repositories import polls as polls_repo
        pl = polls_repo.get(m["id"])
        if pl:
            view["poll"] = poll_view(pl)
    return view


def poll_view(pl) -> dict:
    from app.repositories import polls as polls_repo
    return {"n": pl["n"], "multi": bool(pl["multi"]), "closed": bool(pl["closed"]),
            "counts": polls_repo.counts(pl["post_id"], pl["n"]), "total": polls_repo.voters(pl["post_id"])}


def _expired(m) -> bool:
    try:
        return bool(m["media_expired"])
    except (KeyError, IndexError):
        return False


def _e2e_view(m) -> dict:
    to = m["recipient_id"]
    view = {
        "type": "message", "id": m["id"], "user": user_view(m["user_id"]), "to": to,
        "e2e": m["content"], "ts": m["created_at"], "edited": bool(m["edited_at"]),
        "blob": {"url": f"/uploads/{m['file']}", "size": m["file_size"] or 0} if m["file"] else None,
        "image": None, "file": None, "thumb": None, "w": None, "h": None, "reply": None,
        "expired": _expired(m),
    }
    if to is not None:
        view["read"] = bool(m["read"])
    view["rx"] = reactions.grouped(m["id"])
    return _channel_fields(view, m)


def message_view(m) -> dict:
    if m["e2e"]:
        return _e2e_view(m)
    to = m["recipient_id"]
    view = {
        "legacy": True,
        "type": "message",
        "id": m["id"],
        "user": user_view(m["user_id"]),
        "to": to,
        "content": m["content"],
        "ts": m["created_at"],
        "edited": bool(m["edited_at"]),
        "image": f"/uploads/{m['image']}" if m["image"] else None,
        "file": ({"url": f"/uploads/{m['file']}", "name": m["file_name"] or "fayl", "size": m["file_size"] or 0,
                  "mime": m["file_mime"] or "application/octet-stream"} if m["file"] else None),
        "thumb": f"/uploads/{m['image'].rsplit('.', 1)[0]}_t.jpg" if m["image"] else None,
        "w": m["img_w"] if m["image"] else None,
        "h": m["img_h"] if m["image"] else None,
        "reply": reply_view(m["reply_to"]),
    }
    if to is not None:
        view["read"] = bool(m["read"])
    view["rx"] = reactions.grouped(m["id"])
    return _channel_fields(view, m)


def mute_left(user) -> float:
    return max(0.0, user["muted_until"] - time.time())
