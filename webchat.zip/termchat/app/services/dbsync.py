from __future__ import annotations

import asyncio
import logging
import tempfile
from pathlib import Path

from app import crypto
from app.config import settings
from app.services import r2

log = logging.getLogger("termchat.dbsync")

KEY, PREV = "db/chat.db.enc", "db/chat.db.prev.enc"
CTX = "dbsnap"
_last_changes = -1
_restore_blocked = False
_keep_prev = False


def _valid_sqlite(data: bytes) -> bool:
    """Tiklanayotgan nusxa haqiqiy SQLite bazami (sarlavha, sahifa o'lchami, butunlik)."""
    if len(data) < 512 or data[:16] != b"SQLite format 3\x00":
        return False
    page = int.from_bytes(data[16:18], "big")
    page = 65536 if page == 1 else page
    if page < 512 or len(data) % page:
        return False
    try:
        import sqlite3
        with tempfile.TemporaryDirectory(prefix="dbcheck-") as tmp:
            f = Path(tmp) / "chk.db"
            f.write_bytes(data)
            con = sqlite3.connect(str(f))
            try:
                return con.execute("PRAGMA quick_check").fetchone()[0] == "ok"
            finally:
                con.close()
    except Exception:
        return False


def restore_if_needed() -> bool:
    global _restore_blocked, _keep_prev
    path: Path = settings.db_path
    if not r2.enabled() or (path.is_file() and path.stat().st_size > 0):
        return False
    trouble = False
    for key in (KEY, PREV):
        try:
            blob = r2.get(key)
        except Exception:
            log.exception("R2 dan bazani o'qib bo'lmadi (%s)", key)
            trouble = True
            continue
        if blob is None:
            continue
        data = crypto.open_bytes(blob, CTX)
        if data is None:
            log.error("R2 dagi baza nusxasini ochib bo'lmadi (%s): TERMCHAT_MASTER_KEY o'zgargan bo'lishi mumkin", key)
            trouble = True
            continue
        if not _valid_sqlite(data):
            log.error("R2 dagi baza nusxasi yaroqsiz, SQLite fayl emas (%s, %d bayt): keyingisiga o'tiladi", key, len(data))
            trouble = True
            continue
        if key == PREV:
            _keep_prev = True
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        log.warning("Baza R2 dan tiklandi: %s (%d bayt)", key, len(data))
        return True
    if trouble:
        _restore_blocked = True
        log.error("R2 dagi zaxira tiklanmadi: yangi baza R2 ga YUKLANMAYDI (zaxira ustiga yozilmasligi uchun). "
                  "Kalit/tarmoqni tekshirib, xizmatni qayta ishga tushiring.")
    else:
        log.warning("R2 da baza nusxasi topilmadi: yangi baza yaratiladi")
    return False


def push(force: bool = False) -> bool:
    global _last_changes
    if not r2.enabled():
        return False
    if _restore_blocked:
        log.error("Baza R2 ga yuklanmadi: tiklash muvaffaqiyatsiz bo'lgan, eski zaxira himoyalangan")
        return False
    from app.db import db
    with db._lock:
        changes = db._conn.total_changes
    if not force and changes == _last_changes:
        return False
    with tempfile.TemporaryDirectory(prefix="dbsync-") as tmp:
        snap = Path(tmp) / "chat.db"
        db.snapshot(snap)
        sealed = crypto.seal_bytes(snap.read_bytes(), CTX)
    global _keep_prev
    if _keep_prev:
        log.warning("PREV (oxirgi yaroqli nusxa) saqlab qolindi: yaroqsiz KEY uning ustiga ko'chirilmadi")
    else:
        try:
            r2.copy(KEY, PREV)
        except Exception:
            log.warning("Oldingi nusxani PREV ga ko'chirib bo'lmadi")
    r2.put(KEY, sealed)
    _keep_prev = False
    _last_changes = changes
    return True


async def loop() -> None:
    every = settings.db_sync_seconds
    if every <= 0 or not r2.enabled():
        return
    while True:
        await asyncio.sleep(every)
        try:
            await asyncio.to_thread(push)
        except Exception:
            log.exception("Bazani R2 ga yuklab bo'lmadi")


async def final_push() -> None:
    if settings.db_sync_seconds > 0 and r2.enabled():
        try:
            await asyncio.to_thread(push, True)
            log.info("Baza R2 ga yakuniy yuklandi")
        except Exception:
            log.exception("Yakuniy yuklash xatosi")
