"""Suhbat qulflari: har bir foydalanuvchi har bir lichka suhbatini alohida parol bilan qulflay oladi."""
import time

from app.db import db

MODES = ("ask", "auto")   # ask: chatdan chiqilganda qayta qulflanadi; auto: bir marta ochilgach qo'lda qulflanguncha ochiq


def get(owner: int, peer: int):
    return db.one("SELECT * FROM chat_locks WHERE owner_id=? AND peer_id=?", (owner, peer))


def mine(owner: int) -> list:
    return db.all("SELECT peer_id, mode, hide_peer, locked FROM chat_locks WHERE owner_id=?", (owner,))


def hidden_from(viewer: int) -> list[int]:
    """viewer'dan xabarlarini yashirib turgan (hozir qulflangan) foydalanuvchilar."""
    return [r["owner_id"] for r in db.all(
        "SELECT owner_id FROM chat_locks WHERE peer_id=? AND hide_peer=1 AND locked=1", (viewer,))]


def put(owner: int, peer: int, pw_hash: str | None, mode: str, hide_peer: bool, locked: bool | None = None) -> None:
    now = time.time()
    cur = get(owner, peer)
    if cur is None:
        db.run("INSERT INTO chat_locks(owner_id,peer_id,pw_hash,mode,hide_peer,locked,updated_at) VALUES(?,?,?,?,?,?,?)",
               (owner, peer, pw_hash, mode, int(hide_peer), int(bool(locked)) if locked is not None else 0, now))
        return
    db.run("UPDATE chat_locks SET pw_hash=?, mode=?, hide_peer=?, locked=?, updated_at=? WHERE owner_id=? AND peer_id=?",
           (pw_hash or cur["pw_hash"], mode, int(hide_peer), int(bool(locked)) if locked is not None else cur["locked"], now, owner, peer))


def set_locked(owner: int, peer: int, locked: bool) -> bool:
    cur = get(owner, peer)
    if cur is None or bool(cur["locked"]) == locked:
        return False
    db.run("UPDATE chat_locks SET locked=?, updated_at=? WHERE owner_id=? AND peer_id=?", (int(locked), time.time(), owner, peer))
    return True


def delete(owner: int, peer: int) -> None:
    db.run("DELETE FROM chat_locks WHERE owner_id=? AND peer_id=?", (owner, peer))


def lock_ask_of(owner: int) -> list[int]:
    """owner'ning «har doim so'rash» rejimidagi ochiq suhbatlarini qulflaydi; o'zgarganlar ro'yxatini qaytaradi."""
    rows = db.all("SELECT peer_id FROM chat_locks WHERE owner_id=? AND mode='ask' AND locked=0", (owner,))
    if rows:
        db.run("UPDATE chat_locks SET locked=1, updated_at=? WHERE owner_id=? AND mode='ask' AND locked=0", (time.time(), owner))
    return [r["peer_id"] for r in rows]


def lock_all_ask() -> None:
    """Server ishga tushganda hech kim ulanmagan: barcha «so'rash» suhbatlari qulflanadi."""
    db.run("UPDATE chat_locks SET locked=1 WHERE mode='ask' AND locked=0")
