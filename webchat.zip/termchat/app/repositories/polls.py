from app.db import db


def create(pid: int, n: int, multi: bool) -> None:
    db.run("INSERT OR REPLACE INTO polls(post_id,n,multi,closed) VALUES(?,?,?,0)", (pid, n, int(bool(multi))))


def get(pid: int):
    return db.one("SELECT * FROM polls WHERE post_id=?", (pid,))


def counts(pid: int, n: int) -> list[int]:
    out = [0] * n
    for r in db.all("SELECT opt, COUNT(*) AS c FROM poll_votes WHERE post_id=? GROUP BY opt", (pid,)):
        if 0 <= r["opt"] < n:
            out[r["opt"]] = r["c"]
    return out


def voters(pid: int) -> int:
    return db.one("SELECT COUNT(DISTINCT user_id) AS c FROM poll_votes WHERE post_id=?", (pid,))["c"]


def mine(pid: int, uid: int) -> list[int]:
    return [r["opt"] for r in db.all("SELECT opt FROM poll_votes WHERE post_id=? AND user_id=? ORDER BY opt", (pid, uid))]


def set_votes(pid: int, uid: int, opts: list[int]) -> None:
    with db._lock:
        db._conn.execute("DELETE FROM poll_votes WHERE post_id=? AND user_id=?", (pid, uid))
        for o in opts:
            db._conn.execute("INSERT OR IGNORE INTO poll_votes(post_id,user_id,opt) VALUES(?,?,?)", (pid, uid, o))
        db._conn.commit()


def close(pid: int) -> None:
    db.run("UPDATE polls SET closed=1 WHERE post_id=?", (pid,))


def drop(pid: int) -> None:
    with db._lock:
        db._conn.execute("DELETE FROM poll_votes WHERE post_id=?", (pid,))
        db._conn.execute("DELETE FROM polls WHERE post_id=?", (pid,))
        db._conn.commit()
