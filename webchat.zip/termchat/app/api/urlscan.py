from fastapi import APIRouter, Depends, Request
from fastapi.concurrency import run_in_threadpool
from pydantic import BaseModel, Field

from app.api.deps import client_ip, current_user
from app.security import limiter
from app.services import urlscan

router = APIRouter(prefix="/api", tags=["urlscan"])


class ScanIn(BaseModel):
    url: str = Field(max_length=2048)
    fresh: bool = False


def _limit(user, request: Request, kind: str) -> None:
    limiter.check(f"{kind}:{user['id']}", 12, 60, "Juda tez-tez tekshiryapsiz, biroz kuting")
    limiter.check(f"{kind}-ip:{client_ip(request)}", 40, 60, "Juda tez-tez tekshiryapsiz, biroz kuting")


# Havola matni E2EE xabardan mijozda ajratiladi va faqat foydalanuvchi «Scan» bosganda shu yerga keladi.
# Havola serverda saqlanmaydi va logga yozilmaydi.
@router.post("/urlscan")
async def url_scan(data: ScanIn, request: Request, user=Depends(current_user)):
    _limit(user, request, "uscan")
    return await run_in_threadpool(urlscan.scan, data.url, data.fresh)


@router.post("/urlscan/shot")
async def url_shot(data: ScanIn, request: Request, user=Depends(current_user)):
    _limit(user, request, "ushot")
    return await run_in_threadpool(urlscan.shot, data.url, data.fresh)
