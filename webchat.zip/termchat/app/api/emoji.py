import base64

from fastapi import APIRouter, Depends, File, Form, Request, UploadFile
from fastapi.concurrency import run_in_threadpool
from pydantic import BaseModel, Field

from app.api.deps import admin_user, client_ip, current_user
from app.realtime.manager import manager
from app.services import activity, emoji as svc, emojimaker

router = APIRouter(prefix="/api", tags=["emoji"])


async def _changed() -> None:
    await manager.broadcast({"type": "emoji_update"})


@router.get("/emojis")
def catalog(user=Depends(current_user)):
    return svc.catalog(user)


async def _raw(file: UploadFile) -> bytes:
    return await file.read(emojimaker.MAX_RAW + 1)


@router.post("/emoji/preview")
async def preview(file: UploadFile = File(...), remove_bg: bool = Form(False), tolerance: int = Form(emojimaker.TOL_DEFAULT),
                  user=Depends(current_user)):
    raw = await _raw(file)
    made = await run_in_threadpool(svc.preview, user, raw, remove_bg, tolerance)
    mime = "image/webp" if made.ext == "webp" else "image/png"
    return {"image": f"data:{mime};base64," + base64.b64encode(made.data).decode(), "w": made.width, "h": made.height,
            "transparent": made.transparent, "bg_removed": made.bg_removed, "source_alpha": made.source_alpha, "animated": made.animated}


@router.post("/emoji")
async def create(request: Request, file: UploadFile = File(...), name: str = Form(...), anim: str = Form(""),
                 remove_bg: bool = Form(False), tolerance: int = Form(emojimaker.TOL_DEFAULT),
                 pack_id: str = Form(""), public: bool = Form(True), user=Depends(current_user)):
    raw = await _raw(file)
    r = await run_in_threadpool(lambda: svc.create(user, raw, name, anim=anim, remove_bg=remove_bg, tolerance=tolerance,
                                                    pack_id=pack_id, public=public))
    activity.record("emoji", ip=client_ip(request), user=user, detail=f"yaratdi :{r['name']}:")
    await _changed()
    return {"ok": True, **r}


@router.post("/emoji-pack/zip-preview")
async def zip_preview(file: UploadFile = File(...), user=Depends(current_user)):
    raw = await file.read(svc.MAX_ZIP + 1)
    return await run_in_threadpool(svc.zip_preview, user, raw)


@router.post("/emoji-pack/zip")
async def zip_create(request: Request, file: UploadFile = File(...), pack_name: str = Form(...), public: bool = Form(True),
                     items: str = Form(...), kind: str = Form("emoji"), user=Depends(current_user)):
    raw = await file.read(svc.MAX_ZIP + 1)
    r = await run_in_threadpool(svc.zip_create, user, raw, pack_name, public, items, kind)
    activity.record("emoji", ip=client_ip(request), user=user, detail=f"ZIP to'plam «{r['pack']}»: {len(r['created'])} ta emoji")
    await _changed()
    return {"ok": True, **r}


class EmojiEdit(BaseModel):
    anim: str = Field("", max_length=16)
    pack_id: int | None = None
    public: bool = True


@router.patch("/emoji/{eid}")
async def edit(eid: int, data: EmojiEdit, request: Request, user=Depends(current_user)):
    svc.edit(user, eid, anim=data.anim, pack_id=data.pack_id, public=data.public)
    activity.record("emoji", ip=client_ip(request), user=user, detail=f"tahrirladi #{eid}")
    await _changed()
    return {"ok": True}


@router.delete("/emoji/{eid}")
async def delete(eid: int, request: Request, user=Depends(current_user)):
    e = svc.delete(user, eid)
    activity.record("emoji", ip=client_ip(request), user=user, detail=f"o'chirdi :{e['name']}:")
    await _changed()
    return {"ok": True}


class PackIn(BaseModel):
    name: str = Field(max_length=40)
    public: bool = True
    kind: str | None = Field(None, max_length=8)
    scale: int | None = Field(None, ge=50, le=200)


@router.post("/emoji-packs")
async def pack_create(data: PackIn, request: Request, user=Depends(current_user)):
    pid = svc.create_pack(user, data.name, data.public, data.kind or "emoji")
    activity.record("emoji", ip=client_ip(request), user=user, detail=f"to'plam yaratdi «{data.name}»")
    await _changed()
    return {"ok": True, "id": pid}


@router.patch("/emoji-packs/{pid}")
async def pack_edit(pid: int, data: PackIn, request: Request, user=Depends(current_user)):
    svc.edit_pack(user, pid, data.name, data.public, data.kind, data.scale)
    activity.record("emoji", ip=client_ip(request), user=user, detail=f"to'plamni tahrirladi #{pid}")
    await _changed()
    return {"ok": True}


@router.delete("/emoji-packs/{pid}")
async def pack_delete(pid: int, request: Request, user=Depends(current_user)):
    svc.delete_pack(user, pid)
    activity.record("emoji", ip=client_ip(request), user=user, detail=f"to'plamni o'chirdi #{pid}")
    await _changed()
    return {"ok": True}


@router.put("/emoji-packs/{pid}/mine")
def sticker_add(pid: int, user=Depends(current_user)):
    svc.add_sticker_pack(user, pid)
    return {"ok": True}


@router.delete("/emoji-packs/{pid}/mine")
def sticker_remove(pid: int, user=Depends(current_user)):
    svc.remove_sticker_pack(user, pid)
    return {"ok": True}


class ModeIn(BaseModel):
    mode: str = Field(max_length=8)


@router.put("/emoji-settings")
async def set_mode(data: ModeIn, request: Request, admin=Depends(admin_user)):
    mode = svc.set_global_mode(admin, data.mode)
    activity.record("emoji", ip=client_ip(request), user=admin, detail=f"oddiy foydalanuvchilar emojisi: {mode}")
    await _changed()
    return {"ok": True, "mode": mode}


class PermIn(BaseModel):
    perm: int


@router.put("/emoji-perm/{uid}")
async def set_perm(uid: int, data: PermIn, request: Request, admin=Depends(admin_user)):
    t = svc.set_user_perm(admin, uid, data.perm)
    activity.record("emoji", ip=client_ip(request), user=admin, detail=f"@{t['username']} emoji ruxsati: {data.perm}")
    await _changed()
    return {"ok": True}
