from fastapi import APIRouter, Depends
from fastapi.concurrency import run_in_threadpool
from pydantic import BaseModel, Field

from app.api.deps import current_user
from app.errors import ChatError
from app.realtime.events import publish_chat_lock
from app.repositories import users as users_repo
from app.services import chatlock

router = APIRouter(prefix="/api/chatlock", tags=["chatlock"])


class SetIn(BaseModel):
    password: str | None = Field(None, max_length=128)
    current: str | None = Field(None, max_length=128)
    mode: str = Field("ask", max_length=8)
    hide: bool = False


class PwIn(BaseModel):
    password: str = Field("", max_length=128)


def _peer(user, pid: int):
    p = users_repo.get(pid)
    if not p or pid == user["id"]:
        raise ChatError("Foydalanuvchi topilmadi", 404)
    return p


@router.get("")
def get_state(user=Depends(current_user)):
    return chatlock.state(user["id"])


@router.post("/{pid}/set")
async def set_lock(pid: int, data: SetIn, user=Depends(current_user)):
    _peer(user, pid)
    entry = await run_in_threadpool(chatlock.create_or_update, user["id"], pid, data.password, data.mode, data.hide, data.current)
    await publish_chat_lock(user["id"], pid, entry)
    return entry


@router.post("/{pid}/unlock")
async def unlock(pid: int, data: PwIn, user=Depends(current_user)):
    _peer(user, pid)
    await run_in_threadpool(chatlock.unlock, user["id"], pid, data.password)
    entry = chatlock.state(user["id"])["mine"]
    entry = next((e for e in entry if e["peer"] == pid), None)
    await publish_chat_lock(user["id"], pid, entry)
    return {"ok": True, "lock": entry}


@router.post("/{pid}/lock")
async def lock(pid: int, user=Depends(current_user)):
    _peer(user, pid)
    chatlock.lock_now(user["id"], pid)
    entry = next((e for e in chatlock.state(user["id"])["mine"] if e["peer"] == pid), None)
    await publish_chat_lock(user["id"], pid, entry)
    return {"ok": True, "lock": entry}


@router.post("/{pid}/remove")
async def remove(pid: int, data: PwIn, user=Depends(current_user)):
    _peer(user, pid)
    await run_in_threadpool(chatlock.remove, user["id"], pid, data.password)
    await publish_chat_lock(user["id"], pid, None)
    return {"ok": True}


@router.post("/{pid}/reset")
async def reset(pid: int, data: PwIn, user=Depends(current_user)):
    """Chat paroli unutilgan: akkaunt paroli (brauzerda hosil qilingan «auth» qiymati) bilan qulfni olib tashlash."""
    _peer(user, pid)
    await run_in_threadpool(chatlock.reset_with_account_password, user, pid, data.password)
    await publish_chat_lock(user["id"], pid, None)
    return {"ok": True}
