// "O'zgartirish/Original" tugmasi mantig'ini tekshiradi (app.js dagi tegishli bo'lak soxta DOM bilan ishga tushiriladi).
// Ishlatish: node tests/voice_fx_toggle_test.mjs
import fs from "node:fs"; import assert from "node:assert/strict";
const src = fs.readFileSync(new URL("../app/static/js/app.js", import.meta.url).pathname, "utf8");
const a = src.indexOf('try { S.voiceFx = localStorage'), b = src.indexOf("function resetDragUi()");
assert.ok(a > 0 && b > a, "bo'lak topilmadi");
const snippet = src.slice(a, b);

function el() {
  const e = {cls: new Set(), attrs: {}, text: "", title: "", handlers: {}, kids: {}, textContent: "",
    classList: {toggle: (c, on) => on ? e.cls.add(c) : e.cls.delete(c), contains: c => e.cls.has(c)},
    setAttribute: (k, v) => { e.attrs[k] = v; }, addEventListener: (t, f) => { e.handlers[t] = f; },
    querySelector: s => (e.kids[s] ||= el())};
  return e;
}
const els = {}, $ = id => (els[id] ||= el()), store = {}, toasts = [];
const localStorage = {getItem: k => store[k] ?? null, setItem: (k, v) => { store[k] = v; }};
const S = {rec: null, recBusy: false}, vibrate = () => {}, toast = (t) => toasts.push(t);
const calls = [];
const Voice = {disguise: async b => { calls.push("mask"); return b; }, original: async b => { calls.push("orig"); return b; }};
const run = new Function("S", "$", "localStorage", "vibrate", "toast", "Voice", snippet + "\nreturn {processVoice, fxOrig, lockLabel};");

let api = run(S, $, localStorage, vibrate, toast, Voice);
assert.equal(S.voiceFx, "mask", "standart: o'zgartirish");
assert.equal($("voxBtn").kids[".vox-t"].textContent, "O'zgartirish");
await api.processVoice("x"); assert.deepEqual(calls, ["mask"]);

$("voxBtn").handlers.click();
assert.equal(S.voiceFx, "orig"); assert.equal(store.tc_voicefx, "orig");
assert.equal($("voxBtn").kids[".vox-t"].textContent, "Original"); assert.equal($("voxBtn").attrs["aria-pressed"], "true");
await api.processVoice("x"); assert.deepEqual(calls, ["mask", "orig"]);
assert.match(api.lockLabel(false), /Original/); assert.match(api.lockLabel(true), /original/);

// yozish qulflangan holatda almashtirilsa yozuv yorlig'i yangilanadi
S.rec = {}; $("composer").cls.add("rec-lock"); S.recKind = "voice";
$("voxBtn").handlers.click();
assert.equal(S.voiceFx, "mask"); assert.match($("recLbl").textContent, /o'zgartirilib/);

// tanlov saqlanadi: sahifa qayta ochilganda "original" qoladi
store.tc_voicefx = "orig";
for (const k in els) delete els[k];
api = run({rec: null}, $, localStorage, vibrate, toast, Voice);
assert.equal($("voxBtn").kids[".vox-t"].textContent, "Original");
console.log("voice fx toggle: OK");
