// Node: mergeHistory — server surati ketayotganda WebSocket orqali kelgan yangi xabarlar yo'qolmasligi.
import assert from "node:assert/strict";
import {readFileSync} from "node:fs";
const src = readFileSync(new URL("../app/static/js/app.js", import.meta.url), "utf8");
const i = src.indexOf("function mergeHistory"), j = src.indexOf("async function loadOlder");
const mergeHistory = new Function(src.slice(i, j) + "; return mergeHistory;")();
const M = id => ({id, content: "m" + id});
const ids = st => st.msgs.map(x => x.id);

// 1) oddiy: eski dumi bilan yangi surat birlashadi
let st = {msgs: [M(1), M(2), M(3)], more: false};
mergeHistory(st, [M(3), M(4)], true);
assert.deepEqual(ids(st), [1, 2, 3, 4]);

// 2) poyga: surat 1..5 gacha, lekin so'rov paytida WS 6 va 7 ni yetkazgan -> saqlanadi
st = {msgs: [M(2), M(3), M(4), M(5), M(6), M(7)], more: false};
mergeHistory(st, [M(3), M(4), M(5)], true);
assert.deepEqual(ids(st), [2, 3, 4, 5, 6, 7], "snapshotdan keyingi xabarlar yo'qolmaydi");

// 3) takrorlanish yo'q
st = {msgs: [M(1), M(2), M(3)], more: false};
mergeHistory(st, [M(2), M(3)], false);
assert.deepEqual(ids(st), [1, 2, 3]);

// 4) uzoq uzilish: eski dum yangi suratdan oldin tugasa, surat to'liq almashtiradi
st = {msgs: [M(1), M(2)], more: false};
mergeHistory(st, [M(50), M(51)], true);
assert.deepEqual(ids(st), [50, 51]); assert.equal(st.more, true);

// 5) bo'sh ro'yxatlar
st = {msgs: [], more: false}; mergeHistory(st, [M(1)], false); assert.deepEqual(ids(st), [1]);
st = {msgs: [M(1)], more: false}; mergeHistory(st, [], false); assert.deepEqual(ids(st), [], "server bo'sh desa (chat tozalangan) — bo'sh bo'ladi");
console.log("mergeHistory: OK");
