// Node: Instagram havolasi yonida «Ko'rish» tugmasi chiqishi, embed manzil xavfsiz qurilishi va soxta domenlar rad etilishini tekshiradi.
import {createRequire} from "node:module";
import assert from "node:assert/strict";
class N { constructor(t) { this.tag = t; this._c = []; this.attrs = {}; this.style = {setProperty() {}}; this.dataset = {}; this.listeners = {}; this._text = ""; this.classList = {add() {}, remove() {}}; }
  set className(v) { this.cls = v; } get className() { return this.cls || ""; }
  set textContent(v) { this._text = String(v); this._c = []; } get textContent() { return this._text + this._c.map(c => c.textContent).join(""); }
  append(...k) { for (const c of k) this._c.push(typeof c === "string" ? {textContent: c, text: true} : c); }
  setAttribute(k, v) { this.attrs[k] = v; } addEventListener(e, f) { (this.listeners[e] = this.listeners[e] || []).push(f); }
  get innerHTML() { throw new Error("innerHTML ishlatilmasligi kerak"); } set innerHTML(v) { throw new Error("innerHTML ishlatilmasligi kerak"); } }
globalThis.document = {createElement: t => new N(t), createElementNS: (n, t) => new N(t), createTextNode: t => ({textContent: String(t), text: true}), createDocumentFragment: () => new N("#frag")};
const R = createRequire(import.meta.url)("../app/static/js/richtext.js");
const all = (n, out = []) => { out.push(n); (n._c || []).forEach(c => all(c, out)); return out; };

// 1) turli Instagram havolalari
const ok = {
  "https://www.instagram.com/reel/C8aBcDeFgHi/?igsh=abc": "https://www.instagram.com/reel/C8aBcDeFgHi/embed/",
  "https://instagram.com/reels/C8aBcDeFgHi/": "https://www.instagram.com/reel/C8aBcDeFgHi/embed/",
  "https://www.instagram.com/p/DAbCdEfGh12/": "https://www.instagram.com/p/DAbCdEfGh12/embed/",
  "https://m.instagram.com/tv/DAbCdEfGh12": "https://www.instagram.com/tv/DAbCdEfGh12/embed/",
  "https://www.instagram.com/some.user_1/reel/XyZ12345_-/": "https://www.instagram.com/reel/XyZ12345_-/embed/",
};
for (const [u, e] of Object.entries(ok)) assert.equal(R.instagramOf(u)?.embed, e, u);

// 2) Instagram bo'lmagan yoki yaroqsiz havolalar rad etiladi (embed manzil faqat tekshirilgan qismlardan quriladi)
for (const u of ["https://evil.com/reel/C8aBcDeFgHi/", "https://www.instagram.com.evil.com/reel/C8aBcDeFgHi/",
  "https://evil.com/?u=https://www.instagram.com/reel/C8aBcDeFgHi/", "https://www.instagram.com/stories/x/123/",
  "https://www.instagram.com/reel/ab/", "https://www.instagram.com/reel/C8aBcDeFgHi/../../x", "javascript:alert(1)", "ftp://instagram.com/reel/C8aBcDeFgHi/"])
  assert.equal(R.instagramOf(u), null, u);

// 3) xabar matnida: tugma faqat onInstagram berilganda va faqat Instagram havolasi yonida
const calls = [];
const ctx = {onInstagram: ig => calls.push(ig)};
const msg = "qara: https://www.instagram.com/reel/C8aBcDeFgHi/?igsh=abc ajoyib";
let nodes = all(R.inline(msg, ctx));
const btns = nodes.filter(n => n.tag === "button");
assert.equal(btns.length, 1, "bitta «Ko'rish» tugmasi bo'lishi kerak");
assert.equal(btns[0].className, "ig-view");
assert.equal(btns[0].type, "button");
assert.ok(btns[0].textContent.includes("Ko'rish"));
assert.ok(nodes.some(n => n.tag === "a"), "havolaning o'zi saqlanadi");
let stopped = false, prevented = false;
btns[0].listeners.click[0]({stopPropagation() { stopped = true; }, preventDefault() { prevented = true; }});
assert.ok(stopped && prevented, "tugma bosilganda xabar tanlash/menyu ishlamasligi kerak");
assert.equal(calls.length, 1);
assert.equal(calls[0].embed, "https://www.instagram.com/reel/C8aBcDeFgHi/embed/");
assert.equal(calls[0].kind, "reel");

assert.equal(all(R.inline(msg, {})).filter(n => n.tag === "button").length, 0, "kontekst bermasa tugma yo'q (bio va h.k.)");
assert.equal(all(R.inline("https://example.com/reel/C8aBcDeFgHi/", ctx)).filter(n => n.tag === "button").length, 0);
assert.equal(all(R.inline("https://github.com/x/y", ctx)).filter(n => n.tag === "button").length, 0);

// 3b) matn butunligi: foydalanuvchi yozgan matn o'zgarmaydi (tugma matni qo'shilgani bundan mustasno)
assert.ok(R.inline(msg, ctx).textContent.startsWith("qara: https://www.instagram.com/reel/C8aBcDeFgHi/?igsh=abc"));

// 4) ikki havola = ikki tugma
const two = all(R.inline("https://www.instagram.com/reel/AAAAAAAAAAA/ va https://www.instagram.com/p/BBBBBBBBBBB/", ctx)).filter(n => n.tag === "button");
assert.equal(two.length, 2);


// 5) Scan tugmasi: har qanday havola yonida (faqat onScan berilganda), Instagram havolada «Ko'rish» bilan birga
{
  const sc = [];
  const sctx = {onScan: (href, b) => sc.push([href, b.className]), onInstagram: ig => calls.push(ig)};
  const btnsOf = text => all(R.inline(text, sctx)).filter(n => n.tag === "button");
  // «habar {url} habar2»
  let r = R.inline("salom https://example.com/a?b=1 xayr", sctx);
  let b = all(r).filter(n => n.tag === "button");
  assert.equal(b.length, 1); assert.equal(b[0].className, "lnk-scan");
  assert.ok(r.textContent.startsWith("salom https://example.com/a?b=1") && r.textContent.endsWith(" xayr"), "atrofdagi matn buzilmaydi");
  b[0].listeners.click[0]({stopPropagation() {}, preventDefault() {}});
  assert.deepEqual(sc[0], ["https://example.com/a?b=1", "lnk-scan"]);
  // faqat havolaning o'zi (www. va sxemasiz ham)
  assert.equal(btnsOf("https://example.com").length, 1);
  assert.equal(btnsOf("www.example.com/x").length, 1);
  assert.equal(btnsOf("example.uz").length, 1);
  assert.equal(all(R.inline("www.example.com/x", sctx)).find(n => n.tag === "button") && sc.length >= 1, true);
  // Instagram: ikkala tugma, tartib: havola, Ko'rish, Scan
  const ig = btnsOf("https://www.instagram.com/reel/DWT9EwziPy7/");
  assert.deepEqual(ig.map(x => x.className), ["ig-view", "lnk-scan"]);
  // havola bo'lmasa, tugma yo'q; ikki havola — ikki Scan
  assert.equal(btnsOf("oddiy matn, havola yo'q").length, 0);
  assert.equal(btnsOf("a.com va b.com").filter(x => x.className === "lnk-scan").length, 2);
  // kontekstsiz (bio kabi joylar) — Scan yo'q
  assert.equal(all(R.inline("https://example.com", {})).filter(n => n.tag === "button").length, 0);
}

console.log("richtext Instagram: OK");
