"""OSINT («Scan» → chuqur tahlil): sof yordamchilar va to'liq oqim (barcha tarmoq chaqiruvlari soxta)."""
import datetime as dt
import json
from unittest import mock

import pytest

from app.errors import ChatError
from app.services import osint as O
from app.services import urlscan as U


def test_norm_sub_filters_foreign_and_wildcards():
    assert O.norm_sub("*.API.Example.com.", "example.com") == "api.example.com"
    assert O.norm_sub("example.com", "example.com") == "example.com"
    assert O.norm_sub("evil-example.com", "example.com") is None
    assert O.norm_sub("a.example.com.evil.net", "example.com") is None
    assert O.norm_sub("bad host.example.com", "example.com") is None


def test_spf_and_dmarc_parsing():
    s = O.parse_spf(["google-site-verification=x", "v=spf1 include:_spf.google.com include:mailgun.org -all"])
    assert s["present"] and s["all"] == "-" and s["lookups"] == 2 and "_spf.google.com" in s["includes"]
    assert O.parse_spf(["v=spf1 +all"])["all"] == "+" and O.parse_spf(["v=spf1 a mx"])["all"] == ""
    assert O.parse_spf(["hello"])["present"] is False
    d = O.parse_dmarc(["v=DMARC1; p=Reject; rua=mailto:a@b.uz; pct=100"])
    assert d["present"] and d["p"] == "reject" and d["rua"].startswith("mailto:")
    assert O.parse_dmarc([])["present"] is False


def test_email_findings_levels():
    base = {"MX": ["mx.x.uz"], "TXT": [], "dmarc_txt": [], "dkim": [], "dnssec": False, "CAA": []}
    t = " | ".join(x["text"] for x in O.email_findings(base)[0])
    assert "SPF yo'q" in t and "DMARC yo'q" in t and "DNSSEC" in t and "CAA" in t
    good = {"MX": ["mx.x.uz"], "TXT": ["v=spf1 -all"], "dmarc_txt": ["v=DMARC1; p=reject"], "dkim": ["google"], "dnssec": True, "CAA": ["0 issue x"]}
    assert O.email_findings(good)[0] == []
    weak = dict(good, TXT=["v=spf1 +all"])
    assert [x["sev"] for x in O.email_findings(weak)[0]] == ["bad"]
    nomail = {"MX": [], "TXT": [], "dmarc_txt": [], "dkim": [], "dnssec": True, "CAA": ["x"]}
    assert O.email_findings(nomail)[0] == []              # pochtasiz domenga SPF/DMARC talab qilinmaydi


def test_audit_headers():
    f = O.audit_headers({"Server": "nginx/1.18.0", "X-Powered-By": "PHP/7.4", "Set-Cookie": "sid=1; Path=/"}, https=True)
    t = " | ".join(x["text"] for x in f)
    assert "HSTS yo'q" in t and "Content-Security-Policy yo'q" in t and "Clickjacking" in t and "nginx/1.18.0" in t and "Cookie bayroqlari" in t
    good = O.audit_headers({"Strict-Transport-Security": "max-age=31536000; includeSubDomains", "Content-Security-Policy": "default-src 'self'; frame-ancestors 'none'",
                            "X-Content-Type-Options": "nosniff", "Referrer-Policy": "no-referrer", "Permissions-Policy": "camera=()", "Server": "cloudflare"}, https=True)
    assert good == []
    cors = O.audit_headers({"Access-Control-Allow-Origin": "*", "Access-Control-Allow-Credentials": "true"}, https=True)
    assert any(x["sev"] == "bad" for x in cors)
    assert not any("HSTS" in x["text"] for x in O.audit_headers({}, https=False))


def test_takeover_and_wayback_classification():
    assert O.takeover_match("foo.github.io.") == "github.io" and O.takeover_match("x.s3-website-us-east-1.amazonaws.com")
    assert O.takeover_match("cdn.example.com") is None
    c = O.classify_wayback(["https://a.uz/.env", "https://a.uz/db/backup.sql", "https://a.uz/.git/config", "https://a.uz/wp-config.php.bak", "https://a.uz/index.html"])
    assert set(c) == {"Muhit/kalit fayllari", "Ma'lumotlar bazasi/zaxira nusxalar", "Versiya nazorati (.git/.svn)"} or "Konfiguratsiya/log" in c
    assert not any("index.html" in u for v in c.values() for u in v)


def test_graph_is_bounded_and_linked():
    g = O.build_graph("a.uz", {"1.1.1.1": {"asn": "AS13335", "org": "Cloudflare"}}, [f"s{i}.a.uz" for i in range(100)], {"s0.a.uz": ["2.2.2.2"]}, ["ns1.x"], ["mx.x"], ["a@a.uz"], "Reg")
    ids = {n["id"] for n in g["nodes"]}
    assert len(g["nodes"]) <= 70 and "d:a.uz" in ids and "a:AS13335" in ids and "e:a@a.uz" in ids
    assert all(e["a"] in ids and e["b"] in ids for e in g["edges"])
    assert any(e["rel"] == "ASN" for e in g["edges"])


# ------------------------------------------------------------------ to'liq oqim (soxta tarmoq)

class R:
    def __init__(self, status=200, headers=None, body=b"", url=""):
        self.status, self.headers, self.body, self.url, self.hops = status, headers or {}, body, url, []


def fake_doh(name, rtype):
    A = {"example.uz": ("A", [{"type": 1, "data": "93.184.216.34"}]), "dev.example.uz": ("A", [{"type": 1, "data": "93.184.216.35"}])}
    if rtype == "A" and name in A:
        return {"Status": 0, "AD": False, "Answer": A[name][1]}
    if rtype == "A":
        return {"Status": 3}
    if rtype == "NS":
        return {"Answer": [{"type": 2, "data": "ns1.example.uz."}]}
    if rtype == "MX":
        return {"Answer": [{"type": 15, "data": "10 mail.example.uz."}]}
    if rtype == "TXT" and name == "example.uz":
        return {"Answer": [{"type": 16, "data": '"v=spf1 +all"'}]}
    if rtype == "CNAME" and name == "old.example.uz":
        return {"Answer": [{"type": 5, "data": "ghost-site.github.io."}]}
    if rtype == "PTR":
        return {"Answer": [{"type": 12, "data": "web.example.uz."}]}
    return {"Status": 0}


def fake_json(url, **kw):
    if "crt.sh" in url:
        return [{"name_value": "dev.example.uz\n*.example.uz"}, {"name_value": "old.example.uz\nevil.net"}]
    if "certspotter" in url:
        return [{"dns_names": ["api.example.uz"]}]
    if "jldc.me" in url:
        return None
    if "otx" in url and "passive_dns" in url:
        return {"passive_dns": [{"hostname": "dev.example.uz", "address": "93.184.216.35"}]}
    if "ipwho.is" in url:
        return {"success": True, "country": "Uzbekistan", "country_code": "UZ", "city": "Tashkent", "latitude": 41.3, "longitude": 69.2,
                "timezone": {"id": "Asia/Tashkent"}, "connection": {"asn": 8193, "org": "Uztelecom", "isp": "Uztelecom"}}
    if "rdap.org/ip" in url:
        return {"name": "UZTELECOM-NET", "startAddress": "93.184.0.0", "endAddress": "93.184.255.255", "type": "ALLOCATED PA"}
    return None


def fake_get(url, **kw):
    if "security.txt" in url:
        return b"Contact: mailto:sec@example.uz\n"
    if "robots.txt" in url:
        return b"User-agent: *\nDisallow: /admin/\nDisallow: /\n"
    if "web.archive.org" in url:
        return b"https://example.uz/.env\nhttps://example.uz/backup.sql\n"
    return None


def fake_http(url, **kw):
    if url.startswith("http://"):
        return R(200, {}, b"", url)
    return R(200, {"server": "nginx/1.18.0"}, b"<html><meta name='generator' content='WordPress 5.0'></html>", "https://example.uz/")


def fake_tls(host, port):
    return {"version": "TLSv1.3", "cipher": "x", "issuer": "LE", "subject": host, "verified": True, "error": "", "self_signed": False,
            "not_after": U._now() + dt.timedelta(days=5)}


def run_fake(target="example.uz"):
    with mock.patch.object(O, "_doh", fake_doh), mock.patch.object(O, "_get_json", fake_json), mock.patch.object(O, "_get", fake_get), \
            mock.patch.object(U, "http_request", fake_http), mock.patch.object(U, "tls_step", fake_tls), mock.patch.object(U, "asn_step", lambda ip: {"asn": "AS8193", "prefix": "93.184.0.0/16", "country": "UZ", "name": "UZTELECOM"}), \
            mock.patch.object(U, "whois_step", lambda t: {"registrar": "UZINFOCOM", "created": U._now() - dt.timedelta(days=4000)}), \
            mock.patch.object(U, "resolve_public", lambda h, p=443: ["93.184.216.34"]):
        return O.run(target)


def test_full_domain_osint_has_six_modules_and_findings():
    r = run_fake()
    assert [m["id"] for m in r["modules"]] == ["domain", "ip", "subs", "security", "graph", "leaks"]
    by = {m["id"]: m for m in r["modules"]}
    assert [m["title"] for m in r["modules"]] == ["Domain OSINT", "IP Intelligence", "Subdomain discovery", "Security analysis", "Relationship mapping", "Data leaks"]
    assert "93.184.216.34" in json.dumps(by["domain"]["rows"]) and "UZINFOCOM" in json.dumps(by["domain"]["rows"])
    assert "Uzbekistan" in json.dumps(by["ip"]["rows"]) and "AS8193" in json.dumps(by["ip"]["rows"]) and "web.example.uz" in json.dumps(by["ip"]["rows"])
    subs = {x.split()[0] for x in by["subs"]["list"]}
    assert subs == {"dev.example.uz", "old.example.uz", "api.example.uz", "example.uz"} and "evil.net" not in subs
    assert by["subs"]["rows"][0] == ["Topildi", "4 ta"] and ["Anubis", "ishlamadi"] in by["subs"]["rows"]
    texts = " | ".join(f["text"] for f in r["findings"])
    assert "Subdomain takeover xavfi: old.example.uz" in texts          # dangling CNAME -> github.io (NXDOMAIN)
    assert "SPF zaif" in texts and "HSTS yo'q" in texts and "nginx/1.18.0" in texts and "WordPress" in texts and "kundan keyin tugaydi" in texts
    assert "robots.txt" in texts and "Wayback" in texts
    assert by["security"]["status"] == "bad" and by["leaks"]["status"] == "warn"
    g = r["graph"]; ids = {n["id"] for n in g["nodes"]}
    assert {"d:example.uz", "i:93.184.216.34", "a:AS8193", "e:sec@example.uz", "n:ns1.example.uz", "m:mail.example.uz"} <= ids
    assert r["summary"]["subdomains"] == 4 and r["summary"]["findings"]["bad"] >= 2
    json.dumps(r)


def test_modules_degrade_to_na_when_sources_down():
    with mock.patch.object(O, "_doh", lambda n, t: None), mock.patch.object(O, "_get_json", lambda *a, **k: None), mock.patch.object(O, "_get", lambda *a, **k: None), \
            mock.patch.object(U, "http_request", lambda *a, **k: (_ for _ in ()).throw(OSError("down"))), mock.patch.object(U, "tls_step", lambda *a: (_ for _ in ()).throw(OSError("x"))), \
            mock.patch.object(U, "asn_step", lambda ip: None), mock.patch.object(U, "whois_step", lambda t: {}):
        r = O.run("example.uz")
    by = {m["id"]: m for m in r["modules"]}
    assert by["domain"]["status"] == "na" and by["subs"]["status"] == "na" and by["leaks"]["status"] == "na" and by["security"]["status"] == "na"
    assert r["findings"] == [] and r["ok"]


def test_ip_target_and_internal_ip_refused():
    with mock.patch.object(O, "_get_json", lambda url, **k: fake_json(url)), mock.patch.object(O, "_doh", fake_doh), \
            mock.patch.object(U, "asn_step", lambda ip: None), mock.patch.object(U, "resolve_public", lambda h, p=443: [h]):
        r = O.run("93.184.216.34")
    assert r["kind"] == "ip" and {m["id"] for m in r["modules"]} == {"domain", "ip", "subs", "security", "graph", "leaks"}
    assert "Uzbekistan" in json.dumps([m for m in r["modules"] if m["id"] == "ip"][0]["rows"])
    with pytest.raises(ChatError):
        O.run("127.0.0.1")
    with pytest.raises(ChatError):
        O.run("http://localhost/")


def test_free_hosting_domain_is_not_enumerated_as_registrable():
    seen = []
    with mock.patch.object(O, "subdomains_step", lambda d: seen.append(d) or {"subs": [], "sources": {}, "by": {}, "pdns": {}}), \
            mock.patch.object(O, "_doh", lambda n, t: None), mock.patch.object(O, "_get_json", lambda *a, **k: None), mock.patch.object(O, "_get", lambda *a, **k: None), \
            mock.patch.object(U, "http_request", lambda *a, **k: (_ for _ in ()).throw(OSError())), mock.patch.object(U, "tls_step", lambda *a: (_ for _ in ()).throw(OSError())), \
            mock.patch.object(U, "asn_step", lambda ip: None), mock.patch.object(U, "whois_step", lambda t: {}):
        O.run("someuser.github.io")
    assert seen == ["someuser.github.io"]


def test_scan_cache_and_dedupe():
    calls = []
    with mock.patch.object(O, "run", lambda raw: calls.append(raw) or {"ok": True, "target": raw}), mock.patch.object(U, "_cache", U.OrderedDict()):
        a = O.scan("example.uz"); b = O.scan("https://example.uz/page")
    assert a == b and len(calls) == 1
