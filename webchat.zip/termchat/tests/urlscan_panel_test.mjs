// Node: Scan paneli — havola yonida ochilishi, natijalarni chizishi, xavfsiz matn qo'yishi (innerHTML yo'q) va keshlashini tekshiradi.
import {createRequire} from "node:module";
import assert from "node:assert/strict";
class N {
  constructor(t) { this.tag = t; this.children = []; this.attrs = {}; this.listeners = {}; this.parentNode = null; this._cls = new Set(); this._text = ""; this.disabled = false; }
  set className(v) { this._cls = new Set(String(v).split(/\s+/).filter(Boolean)); } get className() { return [...this._cls].join(" "); }
  get classList() { const s = this._cls; return {add: c => s.add(c), remove: c => s.delete(c), contains: c => s.has(c)}; }
  set textContent(v) { this._text = String(v); this.children = []; } get textContent() { return this._text + this.children.map(c => c.textContent).join(""); }
  append(...k) { for (const c of k) { const n = typeof c === "string" ? Object.assign(new N("#t"), {_text: c}) : c; n.parentNode = this; this.children.push(n); } }
  insertBefore(n, ref) { n.parentNode = this; const i = ref ? this.children.indexOf(ref) : -1; if (i < 0) this.children.push(n); else this.children.splice(i, 0, n); }
  get nextSibling() { if (!this.parentNode) return null; const a = this.parentNode.children; return a[a.indexOf(this) + 1] || null; }
  setAttribute(k, v) { this.attrs[k] = v; } addEventListener(e, f) { (this.listeners[e] = this.listeners[e] || []).push(f); }
  get innerHTML() { throw new Error("innerHTML ishlatilmasligi kerak"); } set innerHTML(v) { throw new Error("innerHTML ishlatilmasligi kerak"); }
}
globalThis.document = {createElement: t => new N(t), createTextNode: t => Object.assign(new N("#t"), {_text: String(t)})};
const U = createRequire(import.meta.url)("../app/static/js/urlscan.js");
const all = (n, out = []) => { out.push(n); n.children.forEach(c => all(c, out)); return out; };
const click = n => n.listeners.click.forEach(f => f({stopPropagation() {}, preventDefault() {}}));
const flush = () => new Promise(r => setTimeout(r, 5));

const JPEG = "data:image/jpeg;base64,/9j/4AAQSkZJRg==";
const RESULT = {ok: true, verdict: {level: "bad", score: 70, label: "Xavfli bo'lishi mumkin — ochmang"}, note: "Bu avtomatik tekshiruv.",
  checks: ["WHOIS / RDAP", "DNS", "SSL / TLS", "Redirects", "Threat Intel", "Final URL", "Sahifa", "URL tahlili"].map((n, i) => ({name: n, status: i === 0 ? "bad" : "ok", value: i === 0 ? "3 kun yosh" : "OK", details: [["Registrator", "<img src=x onerror=alert(1)>"]]})),
  findings: [{sev: "bad", text: "<script>alert(1)</script> Domen juda yangi"}],
  advice: ["Havolani ochmang <b>x</b>"], good: ["Domen 5 yil oldin ro'yxatdan o'tgan"], coverage: {done: 8, total: 10}};
const calls = [];
let shotRes = {ok: true, image: JPEG, via: "image.thum.io"};
const deps = {api: async (path, o) => { calls.push([path, o.body.url, o.body.fresh]); return path === "/urlscan" ? RESULT : shotRes; }};

const line = new N("div"); const a = new N("a"); const btn = new N("button"); line.append(a, btn);
assert.equal(U._cache.size, 0);
U.toggle("https://evil.example/x", btn, deps);
let panel = line.children[2];
assert.ok(panel && panel.className === "scan-panel", "panel Scan tugmasidan keyin joylashadi");
assert.ok(btn.classList.contains("on") && btn.attrs["aria-expanded"] === "true");
assert.ok(panel.textContent.includes("Tekshirilmoqda"), "yuklanish holati ko'rinadi");
await flush();
assert.deepEqual(calls.map(c => c[0]).sort(), ["/urlscan", "/urlscan/shot"], "tahlil va skrinshot parallel so'raladi");
assert.ok(calls.every(c => c[1] === "https://evil.example/x" && c[2] === false));
let nodes = all(panel);
assert.ok(panel.textContent.includes("Xavfli bo'lishi mumkin"), "hukm chiqadi");
assert.equal(nodes.filter(n => n.className.startsWith("sp-cell")).length, 8, "8 ta tekshiruv katakchasi");
const img = nodes.find(n => n.tag === "img");
assert.ok(img && img.src === JPEG, "skrinshot ko'rsatiladi");
assert.ok(panel.textContent.includes("<script>alert(1)</script>"), "serverdan kelgan matn faqat matn sifatida");
assert.ok(!all(panel).some(n => n.tag === "script"), "HTML sifatida talqin qilinmaydi");
assert.ok(panel.textContent.includes("Nima qilish kerak") && panel.textContent.includes("Havolani ochmang <b>x</b>"), "tavsiyalar matn sifatida chiqadi");
assert.ok(panel.textContent.includes("Ijobiy belgilar") && panel.textContent.includes("Tekshiruv: 8/10"), "ijobiy belgilar va to'liqlik ko'rinadi");
assert.ok(!all(panel).some(n => n.tag === "b"), "tavsiya matnidagi tag talqin qilinmaydi");

// katakchani bosish — batafsil
click(all(panel).filter(n => n.className.startsWith("sp-cell"))[0]);
assert.ok(all(panel).some(n => n.className === "sp-detail"), "batafsil ochiladi");
assert.ok(panel.textContent.includes("Registrator"));
click(all(panel).filter(n => n.className.startsWith("sp-cell"))[0]);
assert.ok(all(panel).find(n => n.className.startsWith("sp-detail")).classList.contains("hidden"), "qayta bosilsa yopiladi");

// Min / qayta ochish — yangi so'rov yo'q (kesh)
click(all(panel).find(n => n.className === "sp-min" && n.textContent === "Min"));
assert.ok(panel.classList.contains("hidden") && !btn.classList.contains("on"));
U.toggle("https://evil.example/x", btn, deps);
assert.ok(!panel.classList.contains("hidden") && calls.length === 2, "qayta ochish so'rov yubormaydi");
U.toggle("https://evil.example/x", btn, deps);
assert.ok(panel.classList.contains("hidden"), "Scan tugmasi ikkinchi bosilganda yig'adi");

// ikkinchi xabarda xuddi shu havola: panel alohida, lekin so'rov takrorlanmaydi
const btn2 = new N("button"); const line2 = new N("div"); line2.append(btn2);
U.toggle("https://evil.example/x", btn2, deps); await flush();
assert.equal(calls.length, 2, "bir xil havola keshdan");
assert.ok(line2.children[1].textContent.includes("Xavfli bo'lishi mumkin"));

// xato holatlari: skrinshot yo'q, server xatosi, yaroqsiz rasm manzili
shotRes = {ok: false, message: "Skrinshot xizmati sozlanmagan"};
const b3 = new N("button"), l3 = new N("div"); l3.append(b3);
U.toggle("https://other.example/", b3, deps); await flush();
assert.ok(l3.children[1].textContent.includes("Skrinshot xizmati sozlanmagan"));
assert.ok(!all(l3.children[1]).some(n => n.tag === "img"));
shotRes = {ok: true, image: "https://evil.example/track.png"};
const b4 = new N("button"), l4 = new N("div"); l4.append(b4);
U.toggle("https://third.example/", b4, deps); await flush();
assert.ok(!all(l4.children[1]).some(n => n.tag === "img"), "faqat data:image/jpeg qabul qilinadi (tashqi rasm yuklanmaydi)");
const bad = {api: async () => { throw new Error("Bu havola ichki yoki shaxsiy tarmoq manziliga olib boradi — tekshirilmaydi"); }};
const b5 = new N("button"), l5 = new N("div"); l5.append(b5);
U.toggle("http://192.168.0.1/", b5, bad); await flush();
assert.ok(l5.children[1].textContent.includes("ichki yoki shaxsiy"), "server xatosi panelda ko'rinadi");

console.log("urlscan panel: OK");
