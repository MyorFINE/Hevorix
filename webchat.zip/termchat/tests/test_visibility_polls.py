import time
import unittest

from app.db import db  # noqa: F401
from app.errors import ChatError
from app.repositories import messages, polls, users
from app.services import channels, chat, directory


class VisibilityPollTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        now = time.time()
        suf = str(int(now * 1000))[-6:]
        cls.now = now
        cls.admin = users.create("vadm" + suf, "A", "x", "admin", now)
        cls.u1 = users.create("va" + suf, "A1", "x", "user", now)
        cls.u2 = users.create("vb" + suf, "B", "x", "user", now)
        cls.u3 = users.create("vc" + suf, "C", "x", "user", now)
        cls.suf = suf

    def g(self, i):
        return users.get(i)

    def can(self, s, t):
        try:
            chat._ensure_can_dm(self.g(s), self.g(t))
            return True
        except ChatError:
            return False

    def test_regular_user_sees_only_admins(self):
        names = {m["username"] for m in directory.members(self.g(self.u1))}
        self.assertIn("vadm" + self.suf, names)
        self.assertNotIn("vb" + self.suf, names)

    def test_dm_rules(self):
        self.assertTrue(self.can(self.u1, self.admin))
        self.assertFalse(self.can(self.u1, self.u2))
        messages.create(self.u2, "salom", self.now)
        self.assertTrue(self.can(self.u1, self.u2))
        self.assertFalse(self.can(self.u1, self.u3))
        self.assertIsNone(directory.find_by_username(self.g(self.u1), "vc"))
        self.assertIsNotNone(directory.find_by_username(self.g(self.u1), "@VC" + self.suf))
        self.assertTrue(self.can(self.u1, self.u3))

    def test_poll_and_channel_media(self):
        ch = channels.create(self.g(self.admin), "n" + self.suf, "News", False, None)
        mid = messages.create(self.admin, "e", self.now, None, None, None, None, None, None, None, None, None, e2e=True, channel_id=ch["id"])
        polls.create(mid, 3, False)
        channels.vote(self.g(self.u1), ch["id"], mid, [1])
        self.assertEqual(channels.vote(self.g(self.u2), ch["id"], mid, [1])[1]["counts"], [0, 2, 0])
        with self.assertRaises(ChatError):
            channels.vote(self.g(self.u1), ch["id"], mid, [0, 1])
        channels.close_poll(self.g(self.admin), ch["id"], mid)
        with self.assertRaises(ChatError):
            channels.vote(self.g(self.u1), ch["id"], mid, [0])
        old = self.now - 72 * 3600
        cm = messages.create(self.admin, "e", old, None, "chimg%s.jpg" % self.suf, None, 1, 1, None, None, None, 1, e2e=True, channel_id=ch["id"])
        gm = messages.create(self.u2, "e", old, None, "grimg%s.jpg" % self.suf, None, 1, 1, None, None, None, 1)
        ids = [r["id"] for r in messages.expired_media(self.now - 24 * 3600)]
        self.assertNotIn(cm, ids)
        self.assertIn(gm, ids)


if __name__ == "__main__":
    unittest.main()
