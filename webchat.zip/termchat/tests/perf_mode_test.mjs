// Node: perf.js — qurilma darajasi, qo'lda rejim, jonli kuzatuv (sekin kadrlar -> yengillashish) va saqlash.
import assert from "node:assert/strict";
import {readFileSync} from "node:fs";
const src = readFileSync(new URL("../app/static/js/perf.js", import.meta.url), "utf8");
function boot({mem = 8, cores = 8, ua = "Mozilla/5.0 (Linux; Android 13)", store = {}, frame = 16} = {}) {
  const cls = new Set(), ls = {...store}, raf = [];
  const g = {
    document: {documentElement: {classList: {toggle: (c, on) => on ? cls.add(c) : cls.delete(c), add: c => cls.add(c), contains: c => cls.has(c)}}, hidden: false, addEventListener() {}},
    navigator: {deviceMemory: mem, hardwareConcurrency: cores, userAgent: ua, connection: {}},
    localStorage: {getItem: k => ls[k] ?? null, setItem: (k, v) => { ls[k] = String(v); }, removeItem: k => { delete ls[k]; }},
    matchMedia: () => ({matches: false}), addEventListener() {}, requestAnimationFrame: f => raf.push(f), setTimeout: f => { f(); return 1; },
  };
  new Function(...Object.keys(g), "window", src)(...Object.values(g), g);
  g.window = g; g.cls = cls; g.ls = ls;
  g.runFrames = (n, dt) => { let t = 1000; for (let i = 0; i < n && raf.length; i++) { t += dt; raf.shift()(t); } };
  return g;
}
let d = boot();
assert.equal(d.Perf.level(), "full"); assert.ok(!d.cls.has("lite"));
d = boot({mem: 2}); assert.ok(d.cls.has("lite") && !d.cls.has("ultra"));
d = boot({cores: 2}); assert.ok(d.cls.has("ultra") && d.Perf.level() === "ultra");
d = boot({ua: "Mozilla/5.0 (Linux; Android 8.1)"}); assert.ok(d.cls.has("lite"));
d.Perf.set("full"); assert.ok(!d.cls.has("lite"), "qo'lda «To'liq» qurilma ro'yxatini bekor qiladi");
d.Perf.set("lite"); assert.ok(d.cls.has("lite")); d.Perf.set("auto");
// jonli kuzatuv: ikki marta sekin kadrlar -> lite, saqlanadi
d = boot();
for (let k = 0; k < 2; k++) { d.Perf.reset; d.dispatch = null; }
d.window.addEventListener = () => {};
const sampleOnce = () => { d.Perf._s && d.Perf._s(); };
assert.equal(d.Perf.mode(), "auto");
// saqlangan o'rganilgan daraja keyingi ochilishda qo'llanadi
d = boot({store: {termchat_perf_lvl: "1"}}); assert.ok(d.cls.has("lite"));
d = boot({store: {termchat_perf: "full", termchat_perf_lvl: "2"}}); assert.ok(!d.cls.has("lite"), "full rejim o'rganilgan darajadan ustun");
console.log("perf mode: OK");
