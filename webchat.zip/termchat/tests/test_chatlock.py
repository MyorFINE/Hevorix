import os
import sys
import tempfile
import unittest
from pathlib import Path

os.environ.setdefault("TERMCHAT_DATA_DIR", tempfile.mkdtemp(prefix="termchat-lock-"))
os.environ.setdefault("TERMCHAT_REQUIRE_E2EE", "0")
os.environ.setdefault("TERMCHAT_ADMIN_PASSWORD", "owner-pass-1")
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.errors import ChatError
from app.repositories import chat_locks as repo
from app.repositories import users
from app.security import limiter
from app.services import auth, bootstrap, chat, chatlock, pins, privacy


def _user(name):
    _, u = auth.register(name, name.title(), "secret12")
    return users.get(u["id"])


class ChatLockTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        bootstrap.ensure_owner()

    def setUp(self):
        self.a = _user(f"lka{self.id().split('.')[-1][-9:]}"[:20])
        self.b = _user(f"lkb{self.id().split('.')[-1][-9:]}"[:20])
        privacy.allow_peer(self.a["id"], self.b["id"])
        privacy.allow_peer(self.b["id"], self.a["id"])
        chat.post(self.a, "salom B", self.b["id"])
        chat.post(self.b, "salom A", self.a["id"])

    def _texts(self, viewer, partner):
        return [m["content"] for m in chat.dm_history_page(viewer, partner["id"])[0]]

    def test_hidden_from_peer_only_while_locked(self):
        a, b = self.a, self.b
        chatlock.create_or_update(a["id"], b["id"], "parol1234", "ask", True)
        self.assertEqual(self._texts(b, a), ["salom B", "salom A"])        # ochiq: hammasi ko'rinadi
        chatlock.lock_now(a["id"], b["id"])
        self.assertEqual(self._texts(b, a), ["salom A"])                    # qulf: A xabarlari yashirin, B o'zinikini ko'radi
        with self.assertRaises(ChatError) as cm:
            chat.dm_history_page(a, b["id"])
        self.assertEqual(cm.exception.status, 423)
        chatlock.unlock(a["id"], b["id"], "parol1234")
        self.assertEqual(self._texts(b, a), ["salom B", "salom A"])        # ochilgach yana ko'rinadi

    def test_hide_is_optional(self):
        a, b = self.a, self.b
        chatlock.create_or_update(a["id"], b["id"], "parol1234", "ask", False)
        chatlock.lock_now(a["id"], b["id"])
        self.assertEqual(self._texts(b, a), ["salom B", "salom A"])        # yashirish o'chiq: B ga ta'sir yo'q
        with self.assertRaises(ChatError):
            chat.dm_history_page(a, b["id"])                                # lekin A uchun baribir qulf

    def test_wrong_password_and_throttle(self):
        a, b = self.a, self.b
        chatlock.create_or_update(a["id"], b["id"], "parol1234", "ask", True)
        chatlock.lock_now(a["id"], b["id"])
        for _ in range(6):
            with self.assertRaises(ChatError) as cm:
                chatlock.unlock(a["id"], b["id"], "xato")
            self.assertEqual(cm.exception.status, 403)
        with self.assertRaises(ChatError) as cm:
            chatlock.unlock(a["id"], b["id"], "parol1234")                  # to'g'ri parol ham vaqtincha to'xtatiladi
        self.assertEqual(cm.exception.status, 429)
        limiter._hits.clear()
        self.assertFalse(chatlock.unlock(a["id"], b["id"], "parol1234") is None)

    def test_cannot_send_while_locked_but_peer_can(self):
        a, b = self.a, self.b
        chatlock.create_or_update(a["id"], b["id"], "parol1234", "ask", True)
        chatlock.lock_now(a["id"], b["id"])
        with self.assertRaises(ChatError) as cm:
            chat.post(a, "yashirincha", b["id"])
        self.assertEqual(cm.exception.status, 423)
        chat.post(b, "B yozdi", a["id"])                                    # B ga ta'sir yo'q
        chatlock.unlock(a["id"], b["id"], "parol1234")
        self.assertEqual(self._texts(a, b)[-1], "B yozdi")

    def test_dialogs_never_leak_locked_content(self):
        a, b = self.a, self.b
        chatlock.create_or_update(a["id"], b["id"], "parol1234", "ask", True)
        chatlock.lock_now(a["id"], b["id"])
        mine = [d for d in chat.dialogs(a) if d["user"]["id"] == b["id"]][0]
        self.assertTrue(mine["locked"])
        self.assertTrue(mine["last"]["cl"])
        self.assertEqual(mine["last"]["content"], "")
        chat.post(b, "oxirgisi B dan", a["id"])
        theirs = [d for d in chat.dialogs(b) if d["user"]["id"] == a["id"]][0]
        self.assertFalse(theirs["locked"])
        self.assertTrue(theirs["peer_locked"])
        self.assertEqual(theirs["last"].get("content"), "oxirgisi B dan")  # B ning o'z xabari ko'rinadi

    def test_peer_dialog_last_hidden_when_it_is_from_owner(self):
        a, b = self.a, self.b
        chat.post(a, "A oxirgi", b["id"])
        chatlock.create_or_update(a["id"], b["id"], "parol1234", "ask", True)
        chatlock.lock_now(a["id"], b["id"])
        d = [d for d in chat.dialogs(b) if d["user"]["id"] == a["id"]][0]
        self.assertTrue(d["last"]["cl"])
        self.assertEqual(d["last"]["content"], "")

    def test_pins_guard(self):
        a, b = self.a, self.b
        chatlock.create_or_update(a["id"], b["id"], "parol1234", "ask", True)
        chatlock.lock_now(a["id"], b["id"])
        with self.assertRaises(ChatError):
            pins.dm_pins(a, b["id"])
        self.assertEqual(pins.dm_pins(b, a["id"]), [])

    def test_ask_mode_relocks_auto_stays_open(self):
        a, b = self.a, self.b
        c = _user("lkc" + self.id().split(".")[-1][-8:])
        privacy.allow_peer(a["id"], c["id"]); privacy.allow_peer(c["id"], a["id"])
        chatlock.create_or_update(a["id"], b["id"], "parol1234", "ask", True)
        chatlock.create_or_update(a["id"], c["id"], "parol1234", "auto", True)
        chatlock.unlock(a["id"], b["id"], "parol1234"); chatlock.unlock(a["id"], c["id"], "parol1234")
        self.assertEqual(repo.lock_ask_of(a["id"]), [b["id"]])
        self.assertTrue(chatlock.is_locked(a["id"], b["id"]))
        self.assertFalse(chatlock.is_locked(a["id"], c["id"]))

    def test_update_requires_current_password_and_remove(self):
        a, b = self.a, self.b
        chatlock.create_or_update(a["id"], b["id"], "parol1234", "ask", True)
        with self.assertRaises(ChatError):
            chatlock.create_or_update(a["id"], b["id"], None, "auto", False, current="xato")
        e = chatlock.create_or_update(a["id"], b["id"], None, "auto", False, current="parol1234")
        self.assertEqual((e["mode"], e["hide"]), ("auto", False))
        chatlock.unlock(a["id"], b["id"], "parol1234")                       # eski parol saqlangan
        chatlock.lock_now(a["id"], b["id"])
        with self.assertRaises(ChatError):
            chatlock.remove(a["id"], b["id"], "xato")
        chatlock.remove(a["id"], b["id"], "parol1234")
        self.assertIsNone(repo.get(a["id"], b["id"]))

    def test_forgot_password_reset_needs_account_password(self):
        from app.security import hash_password
        a, b = self.a, self.b
        chatlock.create_or_update(a["id"], b["id"], "parol1234", "ask", True)
        chatlock.lock_now(a["id"], b["id"])
        acct = dict(a)
        acct["password_hash"] = hash_password("akkaunt-auth")
        with self.assertRaises(ChatError) as cm:
            chatlock.reset_with_account_password(acct, b["id"], "boshqa")
        self.assertEqual(cm.exception.status, 403)
        self.assertTrue(chatlock.reset_with_account_password(acct, b["id"], "akkaunt-auth"))   # yashirish tugadi
        self.assertIsNone(repo.get(a["id"], b["id"]))
        self.assertEqual(self._texts(b, a), ["salom B", "salom A"])

    def test_short_password_rejected(self):
        with self.assertRaises(ChatError):
            chatlock.create_or_update(self.a["id"], self.b["id"], "123", "ask", True)


if __name__ == "__main__":
    unittest.main()
