"""Kalitsiz xavf ro'yxatlari: yuklash, xeshlash, moslik, xatoda eski ma'lumotni saqlash, disk keshi. Tarmoq kerak emas."""
import io
import tempfile
import zipfile
from pathlib import Path

from app.services import urlscan_feeds as F

OP = b"http://evil.example/login/\nhttps://Phish.Example.NET/a/b?x=1#frag\n# izoh\n\nhttp://kompromat.org/wp/x.php\n"
DB = b"bad-domain.com\nsub.evil2.org\n# c\n*.wild.net\ngoogle.com\nx.github.io\ngithub.io\n"


def tranco_zip(n=5):
    b = io.BytesIO()
    with zipfile.ZipFile(b, "w") as z:
        z.writestr("top-1m.csv", "".join(f"{i + 1},site{i}.com\n" for i in range(n)) + "6,pineapple.com\n")
    return b.getvalue()


class Fake:
    def __init__(self, data):
        self.data, self.calls = dict(data), []

    def __call__(self, url, max_bytes, timeout):
        self.calls.append(url)
        for k, v in self.data.items():
            if k in url:
                return v() if callable(v) else v
        return None


def mk(fake, **kw):
    return F.Feeds(fake, **kw)


def protected(d):
    return d in ("google.com", "github.io") or d.endswith(".google.com") or d.count(".") < 1


def test_hashset_and_normalization():
    hs = F.HashSet([F.h64("a.com"), F.h64("b.com"), F.h64("a.com")])
    assert len(hs) == 2 and F.h64("a.com") in hs and F.h64("c.com") not in hs
    assert F.norm_url("HTTPS://Phish.Example.NET/a/b/?x=1#frag") == "phish.example.net/a/b/?x=1"
    assert F.norm_url("http://Ex.com/p/") == F.norm_url("https://ex.com/p") == "ex.com/p"
    assert F.host_of_norm("user@ex.com:8080/p") == "ex.com"


def test_urls_feed_hit_near_clean():
    fk = Fake({"openphish": OP})
    f = mk(fk)
    assert f.refresh("openphish")
    r = f.check(["https://evil.example/login"], "evil.example", protected=protected)
    assert [x for x in r if x["name"] == "OpenPhish"][0]["state"] == "hit"            # sxema/oxirgi / farq qilmaydi
    r = f.check(["https://kompromat.org/other"], "kompromat.org", protected=protected)
    assert [x for x in r if x["name"] == "OpenPhish"][0]["state"] == "near"
    r = f.check(["https://example.com/"], "example.com", protected=protected)
    assert [x for x in r if x["name"] == "OpenPhish"][0]["state"] == "clean"
    # himoyalangan domen: «near» chiqmaydi
    f2 = mk(Fake({"openphish": b"https://google.com/phish\n"}))
    f2.refresh("openphish")
    assert f2.check(["https://google.com/safe"], "google.com", protected=protected)[0]["state"] == "clean"


def test_domain_feed_parent_match_and_protection():
    f = mk(Fake({"phishing-domains": DB}))
    assert f.refresh("phishdb")
    st = lambda h: [x for x in f.check(["https://" + h], h, protected=protected) if x["name"] == "Phishing.Database"][0]["state"]
    assert st("bad-domain.com") == "hit" and st("login.bad-domain.com") == "hit"       # ota-domen ham mos
    assert st("sub.evil2.org") == "hit" and st("evil2.org") == "clean"                 # faqat ro'yxatdagi subdomen
    assert st("wild.net") == "hit"                                                     # *.wild.net -> wild.net
    assert st("mail.google.com") == "clean" and st("google.com") == "clean"            # himoyalangan (rasmiy)
    assert st("anyone.github.io") == "clean"                                           # umumiy hosting ildizi
    assert st("x.github.io") == "hit"                                                  # lekin aniq subdomen ro'yxatda


def test_not_loaded_is_na_and_disabled_is_empty():
    f = mk(Fake({}))
    assert {x["state"] for x in f.check(["https://a.com"], "a.com", protected=protected)} == {"na"}
    assert mk(Fake({}), enabled=False).check(["https://a.com"], "a.com", protected=protected) == []


def test_failure_keeps_old_data_and_backs_off():
    now = [1000.0]
    state = {"ok": True}
    fk = Fake({"openphish": lambda: OP if state["ok"] else None})
    f = mk(fk, clock=lambda: now[0])
    assert f.refresh("openphish")
    state["ok"] = False
    now[0] += 7 * 3600                                  # muddati o'tdi -> qayta urinadi, xato -> eski ma'lumot qoladi
    assert f.refresh("openphish") is True
    assert f.check(["https://evil.example/login"], "evil.example", protected=protected)[0]["state"] == "hit"
    n = len(fk.calls)
    now[0] += 60                                        # 15 daqiqa ichida qayta urinmaydi
    f.refresh("openphish")
    assert len(fk.calls) == n


def test_broken_or_empty_payload_is_rejected():
    f = mk(Fake({"openphish": b"\n# faqat izoh\n"}))
    assert f.refresh("openphish") is False and f.check(["https://a.com"], "a.com", protected=protected)[0]["state"] == "na"
    g = mk(Fake({"top-1m": b"not a zip"}))
    assert g.refresh("tranco") is False and g.popular("site0.com") is False


def test_tranco_popularity_and_cap():
    f = mk(Fake({"top-1m": tranco_zip(5)}), sources={"tranco": {**F.SOURCES["tranco"], "max_entries": 3}})
    assert f.refresh("tranco")
    assert f.popular("site0.com") and f.popular("SITE2.com") and not f.popular("site4.com") and not f.popular("pineapple.com")


def test_disk_cache_avoids_second_download():
    with tempfile.TemporaryDirectory() as d:
        fk = Fake({"openphish": OP})
        a = mk(fk, cache_dir=Path(d))
        assert a.refresh("openphish") and len(fk.calls) == 1
        fk2 = Fake({})                                  # tarmoq yo'q, lekin kesh bor
        b = mk(fk2, cache_dir=Path(d))
        assert b.refresh("openphish") and fk2.calls == []
        assert b.check(["https://evil.example/login"], "evil.example", protected=protected)[0]["state"] == "hit"


def test_entry_cap_limits_memory():
    big = ("\n".join(f"d{i}.example.com" for i in range(1000))).encode()
    f = mk(Fake({"phishing-domains": big}), sources={"phishdb": {**F.SOURCES["phishdb"], "max_entries": 100}})
    f.refresh("phishdb")
    assert f.status()["phishdb"]["n"] == 100


def test_background_thread_loads_first_source():
    fk = Fake({"openphish": OP, "phishing-domains": DB, "top-1m": tranco_zip()})
    f = mk(fk)
    f.start()
    try:
        assert f.wait_ready(5)
        assert f.check(["https://evil.example/login"], "evil.example", protected=protected)[0]["state"] == "hit"
    finally:
        f.stop()
