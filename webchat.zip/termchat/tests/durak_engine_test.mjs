// Node: durak dvigateli (pagon, hisob-kitob), bot xulqi, oxirgi bosqich yechimi va bot kuchi. Ishlatish: node tests/durak_engine_test.mjs
import fs from "node:fs"; import vm from "node:vm"; import assert from "node:assert/strict";
const load = f => { const ctx = {Math, console, performance}; ctx.self = ctx; vm.createContext(ctx); vm.runInContext(fs.readFileSync(new URL(f, import.meta.url), "utf8"), ctx); return ctx.TCDurak; };
const T = load("../app/static/js/durak.js");
// Taqqoslash uchun eski (oddiy) bot: mustaqil nusxa tests/durak_legacy_bot.js da
const loadLegacy = () => load("./durak_legacy_bot.js");
const isT = (s, c) => c[1] === s.trump;
const H = {noise: 0, budget: 0};                 // qidiruvsiz (deterministik) evristika
function setup(hands, trump = "S", deck) {
  const s = new T.State(2); s.trump = trump; s.trumpCard = "6" + trump;
  s.hands = hands.map(h => h.slice()); s.deck = deck || ["6" + trump, "7" + trump, "8" + trump, "9" + trump, "TC", "JC", "QC", "KC"]; s.att = 0; s.dfn = 1; s._startRound(); return s;
}
// 1) urishda boshqa karta bo'lsa kozerni ishlatmaydi: eng past mos oddiy karta
for (let k = 0; k < 100; k++) {
  const s = setup([["7H", "KD", "QC", "8D", "9C", "TC"], ["8H", "AS", "9S", "KH", "6D", "7C"]]);
  s.act(0, {t: "atk", c: "7H"});
  const a = T.botAct(s, 1, H);
  assert.equal(a.t, "def"); assert.equal(a.c, "8H"); assert.ok(!isT(s, a.c));
}
// 2) faqat kozer bilan ura olsa — hech qachon kerakdan yuqori kozerni ishlatmaydi
for (let k = 0; k < 100; k++) {
  const s = setup([["7H", "KD", "QC", "8D", "9C", "TC"], ["8D", "AS", "9S", "KC", "6D", "7C"]]);
  s.act(0, {t: "atk", c: "7H"});
  const a = T.botAct(s, 1, H);
  assert.ok(a.t === "take" || (a.t === "def" && a.c === "9S"), JSON.stringify(a));
}
// 3) urib bo'lmasa oladi (qidiruv bilan ham)
const s3 = setup([["AH", "KD", "QC", "8D", "9C", "TC"], ["6H", "7D", "9D", "KC", "6D", "7C"]]);
s3.act(0, {t: "atk", c: "AH"}); assert.equal(T.botAct(s3, 1, H).t, "take"); assert.equal(T.botAct(s3, 1).t, "take");
// 4) hujumda kozerni saqlaydi
const s4 = setup([["6S", "7S", "QH", "9D", "KC", "TH"], ["8H", "AS", "9S", "KH", "6D", "7C"]]);
for (let k = 0; k < 40; k++) assert.ok(!isT(s4, T.botAct(s4, 0, H).c));
const s5 = setup([["6S", "7S", "8S", "9S", "TS", "JS"], ["8H", "AH", "9H", "KH", "6D", "7C"]]);
assert.equal(T.botAct(s5, 0, H).c, "6S", "faqat kozer bo'lsa eng pastini");
// 5) qo'shib tashlashda ham kozerni tashlamaydi
const s6 = setup([["7H", "7S", "KD", "9C", "TC", "JC"], ["8H", "AH", "9H", "KH", "6D", "7C"]]);
s6.act(0, {t: "atk", c: "7H"}); s6.act(1, {t: "def", c: "8H", i: 0});
assert.ok(T.botAct(s6, 0, H).t === "pass", "7♠ kozer — tashlamasligi kerak");
// 6) olayotgan raqibga keraksiz kichik kartani qo'shib tashlaydi
const s7 = setup([["6H", "6D", "KS", "9C", "TC", "JC"], ["8H", "AH", "9H", "KH", "7D", "7C"]]);
s7.act(0, {t: "atk", c: "6H"}); s7.act(1, {t: "take"});
const a7 = T.botAct(s7, 0, H); assert.equal(JSON.stringify(a7), JSON.stringify({t: "atk", c: "6D"}));

// ---- pagon ----
assert.equal(T.pagonOf([]), 0); assert.equal(T.pagonOf(["7H"]), 0); assert.equal(T.pagonOf(["6H", "AS"]), 1);
assert.equal(T.pagonOf(["6H", "6S"]), 2); assert.equal(T.pagonOf(["6H", "6S", "6C", "6D"]), 2);
function endWith(loserHand) {
  const s = new T.State(2); s.deck = []; s.hands = [loserHand.slice(), ["7H"]]; s.att = 1; s.dfn = 0; s._startRound();
  s.act(1, {t: "atk", c: "7H"}); s.act(0, {t: "take"}); return s;
}
let e = endWith(["6H", "9S"]); assert.equal(e.over.loser, 0); assert.equal(e.over.pagon, 1);
e = endWith(["6H", "6S", "9S"]); assert.equal(e.over.pagon, 2);
e = endWith(["8H", "9S"]); assert.equal(e.over.pagon, 0);

// ---- bot hisobi: nima chiqib ketdi / nima olindi ----
{
  const g = new T.State(2, T.fullDeck());
  const tr = g.trump, o = "SHDC".replace(tr, "")[0];
  g.hands = [["6" + o, "7" + o, "8" + o, "9" + o, "T" + o, "J" + o], ["7" + tr, "8" + tr, "9" + tr, "T" + tr, "J" + tr, "Q" + tr]]; g.att = 0; g.dfn = 1; g._startRound();
  g.act(0, {t: "atk", c: "6" + o}); g.act(1, {t: "take"});            // hujumchida mos karta yo'q — raund o'zi tugaydi
  assert.ok(g.known[1].has("6" + o), "olingan karta kimning qo'lida ekani ma'lum bo'ladi");
  const g2 = new T.State(2, T.fullDeck()); const t2 = g2.trump, a = "SHDC".replace(t2, "")[0], b = "SHDC".replace(t2, "").replace(a, "")[0];
  g2.hands = [["6" + a, "8" + a, "9" + a, "T" + a, "J" + a, "Q" + a], ["7" + a, "K" + a, "A" + a, "K" + b, "Q" + b, "J" + b]]; g2.att = 0; g2.dfn = 1; g2._startRound();
  g2.act(0, {t: "atk", c: "6" + a}); g2.act(1, {t: "def", c: "7" + a, i: 0});   // mos karta yo'q — bito
  assert.ok(g2.gone.has("6" + a) && g2.gone.has("7" + a), "bito bo'lgan kartalar sanaladi");
  // klon (qidiruv) haqiqiy hisobni buzmasligi kerak
  const before = g2.gone.size, cl = g2.clone(); cl.hands[0] = ["7" + a]; cl.table = [["7" + a, null]];
  const gg = g2.gone.size; assert.equal(gg, before);
}

// ---- oxirgi bosqich yechimi (2 kishi, kolodasiz): mustaqil to'liq qidiruv bilan solishtiriladi ----
let bruteNodes = 0;
function brute(sim, me, depth = 0) {   // aniq minimax, xotirasiz; takrorlanuvchi (tsiklik) holatlar uchun chuqurlik cheklovi
  if (sim.over) return sim.over.loser == null ? 0 : sim.over.loser === me ? -1 : 1;
  if (++bruteNodes > 400000) throw new Error("cap");
  if (depth > 60) return 0;
  const seat = sim.turn, L = sim.legal(seat), mv = [];
  if (seat === sim.dfn) { for (const c of Object.keys(L.def)) for (const i of L.def[c]) mv.push({t: "def", c, i}); mv.push({t: "take"}); }
  else { L.cards.forEach(c => mv.push({t: "atk", c})); if (L.pass) mv.push({t: "pass"}); }
  let best = seat === me ? -2 : 2;
  for (const m of mv) { const nx = sim.clone(); nx.act(seat, m); const v = brute(nx, me, depth + 1); if (seat === me ? v > best : v < best) best = v; }
  return best;
}
let checked = 0, tried = 0;
while (checked < 40 && tried++ < 1500) {
  const s = new T.State(2); let k = 0;
  while (!s.over && k++ < 400) {
    if (!s.deck.length && s.hands[0].length + s.hands[1].length <= 5 && !s.out[0] && !s.out[1]) break;
    const seat = s.turn; s.act(seat, T.botAct(s, seat, {noise: 0, budget: 0}));
  }
  if (s.over || s.deck.length || s.out[0] || s.out[1]) continue;
  const seat = s.turn, r = T.solveEnd(s, seat); if (!r) continue;
  const root = s.clone(); root.hands = s.hands.map(h => h.slice());
  const L = s.legal(seat); const mv = [];
  if (seat === s.dfn) { for (const c of Object.keys(L.def)) for (const i of L.def[c]) mv.push({t: "def", c, i}); mv.push({t: "take"}); } else { L.cards.forEach(c => mv.push({t: "atk", c})); if (L.pass) mv.push({t: "pass"}); }
  let bestV = -2; bruteNodes = 0;
  try {
    for (const m of mv) { const nx = s.clone(); nx.act(seat, m); bestV = Math.max(bestV, brute(nx, seat)); }
    const nx = s.clone(); nx.act(seat, r.move); const mine = brute(nx, seat);
    assert.equal(r.value, bestV, "yechim qiymati to'liq qidiruv bilan mos kelishi kerak");
    assert.equal(mine, bestV, "tanlangan yurish optimal bo'lishi kerak");
    checked++;
  } catch (e) { if (e.message !== "cap") throw e; }
}
assert.ok(checked >= 15, "yetarli oxirgi-bosqich pozitsiyalari tekshirildi: " + checked);

// ---- bot qidiruvi: aqlli va ishonchli ----
// (a) qidiruv bilan ham qonuniy yurish qaytaradi va holatni buzmaydi
for (let n = 2; n <= 4; n++) for (let r = 0; r < 6; r++) {
  const s = new T.State(n); let k = 0;
  while (!s.over && k++ < 500) {
    const seat = s.turn, snap = JSON.stringify([s.hands, s.table, s.deck, [...s.gone].sort(), s.known.map(x => [...x].sort())]);
    const a = T.botAct(s, seat, {noise: 0.3, budget: 2, minN: 4});
    assert.equal(JSON.stringify([s.hands, s.table, s.deck, [...s.gone].sort(), s.known.map(x => [...x].sort())]), snap, "bot haqiqiy holatni o'zgartirmasligi kerak");
    s.act(seat, a);
  }
  assert.ok(s.over, "o'yin tugashi kerak");
}
// (b) bot eski (oddiy) botdan kuchliroq: 2 kishilik o'yinlarda durak bo'lish ulushi 50% dan ancha past
const O = loadLegacy();
let lost = 0, N = 70, t0 = performance.now(), calls = 0;
for (let gm = 0; gm < N; gm++) {
  const seatNew = gm % 2, s = new T.State(2); let k = 0;
  while (!s.over && k++ < 2000) {
    const seat = s.turn; let a;
    if (seat === seatNew) { calls++; a = T.botAct(s, seat, {noise: 0.3, budget: 4}); }
    else { const o = Object.create(O.State.prototype); Object.assign(o, s); a = O.botAct(o, seat); }
    s.act(seat, a);
  }
  if (s.over && s.over.loser === seatNew) lost++;
}
const ms = (performance.now() - t0) / calls;
assert.ok(lost / N < 0.42, `yangi bot ${lost}/${N} marta durak bo'ldi (50% dan ancha past bo'lishi kerak)`);
assert.ok(ms < 60, "bitta yurish uchun o'rtacha vaqt: " + ms.toFixed(1) + " ms");
console.log(`OK durak dvigateli, pagon, hisob-kitob, ${checked} ta oxirgi-bosqich pozitsiyasi, bot: ${lost}/${N} durak (${ms.toFixed(1)} ms/yurish)`);
