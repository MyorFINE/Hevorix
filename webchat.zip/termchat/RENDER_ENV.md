# Render.com — Environment Variables (Dashboard → Environment)

Blueprint (render.yaml) ishlatsangiz, qiymatli o'zgaruvchilar avtomatik qo'shiladi. Faqat "SECRET" belgilanganlarni qo'lda kiritasiz.

## SECRET (qo'lda kiriting)
| Kalit | Qiymat |
|---|---|
| TERMCHAT_MASTER_KEY | `python -c "import secrets;print(secrets.token_urlsafe(48))"` — bir marta yarating, KEYIN HECH QACHON O'ZGARTIRMANG |
| TERMCHAT_ADMIN_PASSWORD | @Asura (ega) paroli, kamida 6 belgi |
| TERMCHAT_VAPID_PRIVATE_KEY | `python -c "from cryptography.hazmat.primitives.asymmetric import ec;import base64;k=ec.generate_private_key(ec.SECP256R1());print(base64.urlsafe_b64encode(k.private_numbers().private_value.to_bytes(32,'big')).rstrip(b'=').decode())"` |
| R2_ACCOUNT_ID | Cloudflare hisob ID |
| R2_ACCESS_KEY_ID | R2 API token (Object Read & Write) |
| R2_SECRET_ACCESS_KEY | R2 API token siri |
| R2_BUCKET_NAME | bucket nomi |
| R2_ENDPOINT | `https://<ACCOUNT_ID>.r2.cloudflarestorage.com` (bo'sh qoldirsa ACCOUNT_ID dan olinadi) |

## Oddiy qiymatlar
| Kalit | Qiymat |
|---|---|
| PYTHON_VERSION | 3.12.3 |
| PYTHONUNBUFFERED | 1 |
| MALLOC_ARENA_MAX | 2 |
| TERMCHAT_TZ_OFFSET | 5 |
| TERMCHAT_VAPID_SUBJECT | mailto:sizning@pochtangiz.uz |
| R2_REGION | auto |

## Trafikni tejash
| Kalit | Qiymat | Nima uchun |
|---|---|---|
| TERMCHAT_DB_SYNC_SECONDS | 600 | Baza R2 ga kamroq yuboriladi (standart 120) |
| TERMCHAT_MAX_MEDIA_BYTES | 20971520 | Fayl chegarasi 20 MB (standart 50 MB) |
| TERMCHAT_MAX_MUSIC_BYTES | 6291456 | Musiqa chegarasi 6 MB (standart 15 MB) |

Boshqa o'zgaruvchilar (TERMCHAT_REQUIRE_TUNNEL, TERMCHAT_REQUIRE_E2EE, TERMCHAT_TRUST_PROXY ...) uchun standart qiymatlar to'g'ri — qo'shish shart emas.
