# TermChat v3.3.0 — xavfsizlik va barqarorlik hisoboti

Asos: `anonim-chat-android-ui-ux-fixed-v2.zip`. Papka tuzilishi saqlangan. Render/hosting fayllariga (`render.yaml`, `Dockerfile`, `deploy/`) tegilmagan; yangi kutubxona qo'shilmagan (faqat standart kutubxona + mavjud `cryptography`, `Pillow`).

## 0. MUHIM: nima tekshirilmagan

Bu muhitda internet yo'q, **FastAPI, uvicorn, httpx, pytest o'rnatilmagan**. Shuning uchun mavjud backend test to'plami (`tests/test_core.py`, `test_api.py`, `test_secure.py`, `test_e2ee.py`, `test_realtime.py`, `test_channels.py`, `test_reactions.py`, `test_emoji*.py`, `test_webpush.py`, `test_backup.py`) **ISHGA TUSHIRILMAGAN** — ham o'zgartirishdan oldin, ham keyin.
`app/api/ws.py`, `app/api/auth.py`, `app/transport.py`, `app/main.py` o'zgarishlari: sintaksis + stub bilan import tekshirildi, mantiq esa FastAPI'siz unit-testlar bilan sinaldi; **to'liq HTTP/WebSocket oqimi sinalmagan**. Joylashtirishdan oldin: `pip install -r requirements-dev.txt && pytest`.

## 1. O'zgartirilgan va yangi fayllar

**Yangi:** `app/datasnap.py`, `app/services/maintenance.py`, `tools/datasnap.py`, `tests/test_hardening.py`, `HISOBOT.md`
**O'zgargan:** `app/__init__.py` (3.3.0), `app/security.py`, `app/services/auth.py`, `app/api/auth.py`, `app/api/ws.py`, `app/transport.py`, `app/realtime/manager.py`, `app/services/imgclean.py`, `app/services/media.py`, `app/services/backup.py`, `app/services/moderation.py`, `app/services/avatars.py`, `app/api/e2ee.py`, `app/commands/base.py`, `app/commands/moderation.py`, `app/db.py`, `app/config.py`, `app/main.py`, `run.py`, `app/repositories/sessions.py`, `.env.example`, `README.md`
**Frontend (JS/CSS/HTML): o'zgartirilmagan** (sabab: 5-bo'limda).

## 2. Muhim o'zgarishlar (fayl · muammo · o'zgarish · sabab · test · natija)

| # | Fayl | Muammo | O'zgarish / sabab | Test → natija |
|---|------|--------|-------------------|---------------|
| 1 | `security.py`, `services/auth.py` | scrypt N=2¹⁴ (zaif); hash formati o'zgarmas | N=2¹⁵, parametrlar hash ichida (`s2$…`); eski hash tekshiriladi va kirishda avtomatik yangilanadi (moslik saqlandi). Buzuq/zararli parametrlar rad etiladi | `PasswordHashTests` (5 ta) + haqiqiy sxemada login→rehash tekshirildi → **OK** |
| 2 | `services/backup.py` | (1-o'zgarish keltirib chiqaradigan regressiya): zaxirani tiklash yangi hash shaklini «yaroqsiz» deb rad etardi | `valid_hash_shape()` eski va yangi shaklni qabul qiladi | `test_backup_restore_accepts_both_hash_formats` + export→o'chirish→restore→login → **OK** |
| 3 | `services/auth.py` | Mavjud bo'lmagan username'da scrypt hisoblanmasdi (vaqt farqi) | `burn_verify()`; ~110 ms ikkala holatda | qo'lda o'lchandi (113/104 ms) → **OK** |
| 4 | `api/auth.py` | Faqat (IP, username) cheklovi bor edi: bitta IP'dan turli username sinash cheklanmagan | qo'shimcha `login-ip` cheklovi (IP uchun 80/5 daqiqa) | kod ko'rib chiqildi; HTTP darajasida **sinalmagan** |
| 5 | `transport.py` | Server→mijoz AES-GCM nonce tasodifiy (takrorlanmasligi kafolatsiz); WS prefiksi 4 bayt tasodifiy | nonce = oqim raqami + hisoblagich; HTTP = oqim 0, har WS o'z oqimi. Mijoz kodi o'zgarmadi (u faqat hisoblagichni tekshiradi) | `TransportNonceTests` (5 ta) → **OK** |
| 6 | `transport.py`, `run.py` | WS kadr hajmi cheklanmagan (uvicorn standarti 16 MB) | `max_ws_frame()` (kadr dekodlanmasdan rad), `ws_max_size=1 MB` (`run.py`) | `test_oversized_websocket_frame…`, replay/tamper testi → **OK** |
| 7 | `transport.py` | Katta shifrlangan tanalar to'liq RAMga o'qiladi; bir vaqtda ko'pi → xotira tugashi | umumiy hajm byudjeti va ≤3 bir vaqtdagi yuklab olish; ortig'i 503 | kod ko'rib chiqildi; yuklama ostida **sinalmagan** |
| 8 | `api/ws.py`, `realtime/manager.py` | Kutilmagan xato (masalan baza) ulanishni uzardi; `cmd`/kadrlar tezligi cheklanmagan; ulanishlar soni cheksiz | xato ushlanadi («Server xatosi»); kadr 150/10 s, `cmd` 20/10 s; ≤10 ulanish (1013); oversize → 1009 | stub bilan import tekshirildi; **ishga tushirib sinalmagan** |
| 9 | 6 ta fayl (`moderation`, `avatars`, `e2ee` API, `commands/*`) | `'²'.isdigit()` True, `int('²')` xato → WS uziladi / 500 | faqat ASCII raqam | `DigitParsingTests` → **OK** |
| 10 | `services/imgclean.py` | Ko'p kadrli katta GIF (300×40 Mpx) xotirani to'ldirishi mumkin; katta JPEG to'liq dekodlanadi | kadrlar piksellari yig'indisi ≤30 M; JPEG `draft()` | `ImageLimitsTests` (GIF rad etiladi, EXIF olib tashlanadi, oddiy GIF/JPEG ishlaydi) → **OK** |
| 11 | `services/maintenance.py` (yangi), `main.py`, `media.py` | Chala `*.tmp`, biriktirilmagan `.e2e` fayllar va yetim `e2e_blobs` qatorlari yig'ilib qolardi | startup + har 30 daqiqada tozalash; xabarlarga tegilmaydi | `test_sweep_tmp…` → **OK** (lifespan ulanishi sinalmagan) |
| 12 | `app/datasnap.py`, `tools/datasnap.py` (yangi) | Faqat akkauntlar zaxirasi bor edi; xabarlar/kanallar/reaksiyalar/media zaxirasi yo'q | to'liq zaxira (baza + shifrlangan fayllar), SHA-256 manifest, tekshirish, xavfsiz tiklash (mavjud ma'lumotni jimgina o'chirmaydi, `--force` da eski nusxa saqlanadi), maxfiy kalitlar kirmaydi | `SnapshotTests` (7 ta) + CLI smoke (backup/verify/restore/rad etish/force) → **OK** |
| 13 | `maintenance.auto_backup`, `config.py` | Avtomatik zaxira yo'q | `TERMCHAT_AUTO_BACKUP_HOURS` (standart 0 = o'chiq), aylanma, yozilgach tekshiriladi | `AutoBackupTests` → **OK** |
| 14 | `repositories/sessions.py`, `services/auth.py`, `api/auth.py` | Qurilmalar sessiyalarini ko'rish/bekor qilish yo'q | `GET /api/sessions`, `DELETE /api/sessions/{id}`, `POST /api/sessions/revoke-others` (faqat o'zinikini; token ko'rsatilmaydi) | `SessionManagementTests` (4 ta: egalik, revoke-others, logout, idle tugash) → **OK** (servis darajasida) |
| 15 | `db.py` | `synchronous` va `busy_timeout` aniq emas; zaxira/butunlik API yo'q | `synchronous=NORMAL` (WAL), `busy_timeout`, `snapshot()`, `integrity_check()` | haqiqiy sxemada `integrity_check()==[]`, snapshot → **OK** |

## 3. Muvaffaqiyatli testlar (men ishga tushirganlarim)

- Python `compileall` (app, tests, tools, run.py): **OK**
- JavaScript `node --check` (barcha `static/js/*.js`, `sw.js`): **OK**
- Node testlar (avvalgi holat bilan bir xil, o'zgarishdan keyin ham): `backup_interop`, `e2e_glue_test`, `reactions_sync`, `reactions_tap`, `richtext_dom`, `richtext`, `vnote_pack`, `voice_dsp` — **hammasi OK**. (`e2e_js_interop.mjs` chiqish bermaydi, chiqish kodi 0 — o'zgarishdan oldin ham shunday edi.)
- Yangi `tests/test_hardening.py`: **27 ta test, hammasi OK** (har biri o'z vaqtinchalik papkasida).

## 4. Muvaffaqiyatsiz / o'tkazilmagan testlar

- **O'tkazilmagan** (kutubxona yo'q): mavjud pytest to'plami (yuqoridagi 0-bo'lim). Muvaffaqiyatsiz deb topilgani yo'q — shunchaki ishga tushmagan.
- Statik xavfsizlik vositalari (bandit va h.k.) mavjud emas; qo'lda ko'rib chiqildi (SQL so'rovlarida faqat parametrlar; frontendda `innerHTML`/`eval` yo'q — avvaldan shunday).
- `e2e_js_interop.mjs` Python drayveri bilan ishlaydi — ishga tushirilmadi.

## 5. Qasddan qilinmagan ishlar (sabab bilan)

- **Frontend o'zgartirilmadi.** Brauzer/qurilma yo'q, shuning uchun UI o'zgarishlarini ko'rib tekshira olmayman; tekshirilmagan UI o'zgartirishi ishlayotgan interfeysni buzishi mumkin. Audit: `innerHTML`/`eval` yo'q, qat'iy CSP, offline paneli (`connbar`), 38 ta `aria-`/`role`, klaviatura boshqaruvi — mavjud. `app.js` (4067 qator) modullarga **bo'linmadi** — sinab bo'lmaydigan katta qayta yozish xavfi.
- **Virtual scrolling qo'shilmadi** (xavfsiz sinab bo'lmasdi); tarix sahifalab yuklanadi (10 + 30).
- **Kriptografik protokol (E2EE) formati o'zgartirilmadi** — eski xabarlar ochilishi buzilmasligi uchun. Faqat server→mijoz nonce tuzilmasi o'zgardi (mijoz moslashtirishi shart emas).
- Hujjat: E2EE protokoli README'da mavjud; yangi o'zgarishlar README «v3.3.0» bo'limida.

## 6. Hali qolgan kamchiliklar

1. **Test izolyatsiyasi:** mavjud `conftest.py` butun sessiya uchun BITTA umumiy bazadan foydalanadi (sozlamalar import vaqtida o'qiladi). Har bir test uchun alohida baza qilish arxitekturani o'zgartirishni talab qiladi — qilinmadi. Yangi testlar izolyatsiyalangan.
2. **`TRUST_PROXY` standarti `True`:** Cloudflare ortida bo'lmagan serverda mijoz `CF-Connecting-IP`ni soxtalashtirib, tezlik cheklovi va IP bloklashdan qochishi mumkin. Render uchun to'g'ri bo'lgani sababli standart o'zgarmadi; `.env.example`da ogohlantirish qo'shildi.
3. **Egasining boshlang'ich paroli** birinchi ishga tushirishda logga yoziladi (`bootstrap.py`). Yangi o'rnatishda egasi kirishi uchun kerak; `TERMCHAT_ADMIN_PASSWORD` bering va logni oching.
4. **Server→mijoz tomonida nonce kafolatlangan, mijoz→server tomonida** esa mijoz tasodifiy 4 baytli prefiks ishlatadi (ikki ulanish prefiksi to'qnashuvi ehtimoli ~2⁻³², va hisoblagichlar ham mos kelishi kerak). Takroriy kadrlar serverda rad etiladi. To'liq kafolat uchun mijoz kodini o'zgartirish kerak (qilinmadi).
5. **Tunnel katta fayllarni RAMga o'qiydi** (AES-GCM yaxlit teg tufayli). Byudjet bilan cheklandi, lekin to'liq oqimli (chunked) shifrlash uchun protokolni o'zgartirish kerak.
6. **Adminlar o'z amallari logini o'chira oladi** (`/api/admin/activity/delete`; faqat ega yozuvlari himoyalangan). Yozilmas (append-only) audit qilinmadi.
7. **Sessiyalar UI:** qurilmalarni ko'rish/bekor qilish faqat API; interfeysda tugma yo'q.
8. **To'liq zaxira interfeysda yo'q** (CLI + avtomatik nusxa). Brauzerdan yuklab olish qasddan qo'shilmadi: arxivda parol hash'lari bor va u shifrlanmagan.
9. **E2EE mustaqil auditdan o'tmagan** — uni mutlaq xavfsiz deb hisoblamang. Server kim kimga, qachon, qancha yozganini ko'radi (metama'lumot), reaksiyalar ochiq.
10. Bepul tarifdagi vaqtinchalik diskda `data/` har qayta ishga tushirishda yo'qolishi mumkin — zaxirani tashqariga ko'chirib turing.

## 7. Qo'lda bajarilishi kerak bo'lgan ishlar

1. `pip install -r requirements-dev.txt && pytest` — mavjud backend testlarini ishga tushiring va natijani tekshiring.
2. `python -m unittest tests.test_hardening -v` va `node tests/*.mjs`.
3. Joylashtirishdan oldin `data/` va `master.key`ni zaxiralang (`python tools/datasnap.py backup`); `master.key`ni arxivdan **alohida** saqlang.
4. Cloudflare/Render ortida bo'lmasangiz: `TERMCHAT_TRUST_PROXY=0`.
5. Ixtiyoriy: `TERMCHAT_AUTO_BACKUP_HOURS=24`.
6. Brauzerda qo'lda sinang: login, xabar, rasm/fayl/ovoz yuborish, qayta ulanish — frontend o'zgarmagan, lekin server→mijoz nonce tuzilmasi o'zgargani uchun WebSocket va fayl yuklab olishni jonli tekshirish zarur.

---
## v3.3.1 — profil ochilishidagi qotish (FPS) tuzatildi

**Sabablar (kodda topilgan):**
1. Profil oynasi «jonli» (`live`) edi: har bir `presence`/a'zolar yangilanishida butunlay QAYTA QURILARDI — ochilish animatsiyasi paytida DOM almashib, avatar rasmi qayta yuklanib/dekodlanardi.
2. Profil rasmlari 2560 px gacha saqlanardi, ekranda esa 96 px ko'rinadi: katta JPEG'ni dekodlash asosiy oqimni to'xtatardi (ayniqsa kuchsiz telefonda).
3. Oyna animatsiyasi GPU qatlamiga ko'tarilmagan edi.

**O'zgarishlar:** `static/js/app.js` (`refreshModal` birlashtiriladi va animatsiya tugaguncha ~450 ms kutadi; avatar `decoding="async"`), `static/css/style.css` (`will-change`, kuchsiz qurilmada qisqa animatsiya), `services/imgclean.py` + `services/avatars.py` (yangi profil rasmlari ≤512 px), `services/maintenance.py` (eski katta profil rasmlari joyida 512 px ga kichraytiriladi, har 30 daqiqada ≤20 ta; fayl nomi o'zgarmaydi).
**Test:** `test_big_avatar_is_shrunk_in_place…` (28 ta unittest OK), `node --check app.js` OK, barcha Node testlar OK.
**Sinalmagan:** haqiqiy telefonda FPS o'lchanmagan (qurilma yo'q). Taxmin kodga asoslangan; yaxshilanish bo'lmasa, Chrome DevTools → Performance bilan profil ochilishini yozib yuboring.

---
## v3.4.0 — Telegram uslubidagi profil ko'rinishi

**Talab:** skrinshotdagidek profil; Call, More, QR, Add contact, Block user bo'lmasin; Message va Mute bo'lsin; username ko'rinsin; rasmlar / ovozli xabarlar / fayllar qolsin.
**Fayllar:** `static/js/app.js` (`profileView`, `openProfile`, yangi `mediaStats`, mute holati), `static/css/style.css` (`.tgp`, `.tg-*`), `static/index.html` (`i-bell-off` belgisi), yangi `tests/profile_view_test.mjs`.

- **Tuzilma:** yuqorida orqaga (←) tugmasi, katta avatar, ism, holat (onlayn/oflayn), nishon chiplari; ostida ikkita tugma — **Xabar** va **Mute**; qalin ajratgich; **@username** qatori (bosilsa nusxalanadi); bio va qo'shilgan sana (bor bo'lsa); ajratgich; **N ta rasm / ovozli xabar / fayl** qatorlari (nol bo'lgani ko'rsatilmaydi; video xabar bo'lsa alohida qator). Mobilda butun ekran (≤760 px), kompyuterda oyna. O'z profilimda faqat «Tahrirlash». Adminlar uchun moderatsiya paneli pastda saqlandi; ega/admin rangi tepada yengil fon sifatida qoldi.
- **Mute:** shu suhbatdan kelgan xabarlarda tovush va mahalliy bildirishnoma o'chadi (tugma «Ovoz yoq» ga aylanadi). Holat faqat shu qurilmada (`localStorage: ac_muted_dm`) saqlanadi.
- **Cheklovlar (halol):** (1) Mute **serverdan keladigan push-bildirishnomalarga ta'sir qilmaydi** (push E2EE tufayli yuboruvchisiz va umumiy) — buning uchun serverda alohida sozlama kerak, qilinmadi. (2) Media sanog'i faqat **qurilmaga yuklangan** xabarlardan hisoblanadi (E2EE: server shifrlangan xabarni o'qiy olmaydi); tarixning davomi bo'lsa «3+ ta rasm» ko'rinadi. (3) Qatorlar bosilganda galereya ochilmaydi (galereya yo'q). (4) «Last seen» yo'q: tizimda oxirgi ko'rilgan vaqt saqlanmaydi, shuning uchun faqat onlayn/oflayn ko'rsatiladi.
- **Test:** `node tests/profile_view_test.mjs` — Call/More/Block/QR yo'qligi, 2 ta tugma, username va nusxalash, media sanog'i (o'chirilgan xabar hisoblanmaydi, «+»), Mute yoqish/o'chirish va saqlash, o'z profilim, orqaga tugmasi: **OK**. Brauzer/telefonda ko'rinishi **ko'zdan kechirilmagan** (qurilma yo'q) — iltimos, o'zingiz tekshiring.

---
## v3.5.0 — frontend modullashtirish, CSS tozalash, virtual ro'yxat

**Qoida:** mavjud funksiyalar o'zgarmadi. Yig'ilgan `app/static/js/app.js` asl fayl bilan **bayt-ma-bayt bir xil** (`cmp` bilan tekshirilgan).

- **Manba modullarga bo'lingan:** `frontend/js/app/*.js` (27 fayl, tartib: `_order.txt`), `frontend/css/*.css` (18 fayl). Yig'ish: `python tools/build_frontend.py` (`--check` — CI uchun, `--no-prune`, `--no-minify`). **Endi `app/static/js/app.js` va `css/style.css` ni qo'lda tahrirlamang** — `frontend/` ni tahrirlab qayta yig'ing.
- **Nega haqiqiy ES modul emas:** butun ilova bitta IIFE yopilmasida va testlar `app.js` matnini qirqadi; `import/export` ga o'tish brauzer/backendsiz xavfsiz tekshirilmadi. Manba modulli, yetkazib beriladigan fayl bitta.
- **CSS:** 124 442 → ~112 800 bayt. Izohlar/probellar olib tashlandi; 36 ta ishlatilmaydigan selektor o'chirildi (`frontend/css/PRUNE_REPORT.txt`; dinamik yig'iladigan nomlar `"x-" + n` himoyalangan). Brauzer CSSOM'ida tekshirildi: qolgan 1511 qoida selektor/deklaratsiya/tartib bo'yicha aynan bir xil.
- **Virtual ro'yxat:** `app/static/js/virtual.js` + `.row.vs-off` (CSS). Ekrandan ~2,5 ekran uzoqdagi xabar qatorlari `content-visibility:hidden` bilan muzlaydi; DOMdan olinmaydi, balandligi saqlanadi (`jumpTo`, tanlash, reaksiyalar o'zgarmaydi). Ijro etilayotgan media/fokusdagi qator muzlamaydi. O'chirish: `localStorage.ac_vs="0"`. (Ilovada oldindan 80 xabarlik oyna bor edi — u saqlangan.)
- **Testlar (hammasi o'tdi):** `tests.test_frontend_build` (5), `tests.virtual_list_test` (6, Chromium), `tests.browser_smoke_test` (SRI+CSP bilan yuklanish; `ORIG_STATIC=<eski static>` bilan 322 elementning hisoblangan uslublari eski CSS bilan bir xil), `tools/verify_css.py <eski style.css>`, barcha `tests/*.mjs`. `profile_view_test.mjs` va `reactions_tap_test.mjs` asl zipda ham buzuq edi (ilova keyin o'zgargan, test kesimlari eskirgan) — faqat test yordamchilari yangilandi.
- **Sinalmagan:** backend (FastAPI yo'q) bilan to'liq oqim, telefonda haqiqiy FPS/scroll hissi, juda uzun tarix. Joylashtirishdan keyin telefonda: tepaga uzoq scroll, xabarga sakrash, belgilash rejimi, ekran burilishi.
- **Cheklov:** Safari 17 dan eski brauzerda `content-visibility` yo'q — modul o'zini o'chirib qo'yadi (hech narsa o'zgarmaydi).


---
## v11 (3.6.0) — dizayn tizimi qayta yozildi: neon yo'q, har bir element uchun alohida animatsiyali uslub

**Asos:** `anonim-chat-android-ui-ux-fixed-v3-bugfix.zip`. Papka tuzilishi saqlangan; yangi kutubxona yo'q.

### Nima o'zgardi
- **Neon butunlay olib tashlandi** (API, ma'lumotlar bazasi qiymatlari, CSS, JS, `neon` avatar ramkasi). Bazada eski ustun qoldi (`users.neon`), lekin ishlatilmaydi; ishga tushganda barcha `neon` qiymatlari va `frame='neon'` tozalanadi.
- **Admin har bir elementga alohida uslub beradi** ("Foydalanuvchilar" ro'yxatidagi **Dizayn** yoki profildagi **Dizayn berish**). Ma'lumot `users.fx` ustunida (qisqa JSON, tayyor nomlar):

| Element (`fx` kaliti) | Variantlar |
|---|---|
| Nickname (`nick`) | Yaltirash, Aurora, Shafaq, Okean, Oltin, Konfet, Glitch, Suzish, Puls, To'lqin (harflar birin-ketin) |
| Username (`user`) | Nickname bilan bir xil, To'lqindan tashqari |
| Bio (`bio`) | Yaltirash, Aurora, Shafaq, Okean, Oltin, Konfet, Nafas |
| Profil sahifasi (`page`) | Oqma fon, Yulduzlar (miltillaydi), Suzuvchi avatar. Fon (`banner`) va avatar ramkasi (`frame`) alohida tanlanadi |
| Xabarlar (`msg`) | Sakrash, Sirpanish, Ko'tarilish, Aylanish, Tushish (sakrab to'xtaydi), Aniqlashish, Oqma hoshiya |
| Reply (`reply`) | Oqma chiziq, Rangli fon, Yo'l-yo'l, Sirpanib kirish |
| Havola (`link`) | Chiziq yugurishi, Kapsula, Oqma rang, ↗ Strelka |

- **Xabar effekti** faqat yangi xabar paydo bo'lganda, bir marta ishlaydi (`appendMessage` → `fxPlay`, `.fxgo` klassi ~3,4 s). Tarix ochilganda yoki ro'yxat qayta chizilganda takrorlanmaydi. «Oqma hoshiya»da hoshiya chizig'i doim ko'rinadi, faqat oqishi yangi xabarda ishlaydi.
- **Reply va havola:** iqtibos qutisi reply **yozgan odamning** uslubida chiqadi; havola uslubi shu odam yuborgan xabar pufagidagi havolalarga qo'llanadi (profil biosidagi havolalarga emas).
- **Tahrirlash sahifasi** (`openProfileEditor`, qayta yozildi): tepada namunaviy profil + 3 ta xabar (oddiy, reply, havolali); variant bosilsa darhol ko'rinadi, **▶ Qayta ko'rsatish** xabar animatsiyasini qaytadan o'ynatadi. Faqat o'zgargan elementlar yuboriladi.
- **Saqlangan:** ishonch belgisi, galochka va emoji nishon, avatar ramkasi (neon ramkasiz), unvon, ega/admin uchun profil rangi.
- **Zaxira (backup) endi dizaynni saqlaydi:** eksportda `design` {trust, banner, frame, title, fx}; tiklashda har biri qayta tekshiriladi (noto'g'ri qiymat tushiriladi). `design` bo'lmagan eski zaxiralar ham tiklanadi (format raqami o'zgarmadi).
- **Xavfsizlik:** server faqat `app/services/fxstyle.py` dagi tayyor nomlarni qabul qiladi (noma'lum element yoki nom, `#rrggbb`, CSS matni, dict bo'lmagan qiymat → xato). Bazadagi buzuq qiymat chiqishda ham filtrlanadi. Ruxsatlar avvalgidek: admin oddiy foydalanuvchilarni va o'zini, ega adminlarni ham; egani faqat o'zi.
- **Qulaylik:** qurilmada «animatsiyani kamaytirish» yoqilgan bo'lsa, mijoz hamma effektni qo'llamaydi (`fxOf` null qaytaradi) va CSS ham animatsiyani o'chiradi. Yengil rejim (`html.lite`) ham harakatlarni o'chiradi. Xizmat ishchisi keshi `shell-v6` ga ko'tarildi.

### O'zgargan / yangi fayllar
**Yangi:** `app/services/fxstyle.py`, `frontend/css/19-fx.css`, `tests/test_fx.py`, `tests/fx_test.mjs`
**Backend:** `app/services/profiles.py`, `app/services/views.py`, `app/services/backup.py`, `app/repositories/users.py`, `app/api/admin.py`, `app/db.py`, `app/__init__.py` (3.6.0)
**Frontend (manba):** `03-avatars-design.js`, `08-chat-window.js`, `10-reactions.js`, `17-profile.js`, `22-admin-extras.js`, `17-reactions.css`, `_order.txt`; yig'ilgan `app/static/js/app.js`, `css/style.css`, `sw.js`. Test yordamchisi: `tests/profile_view_test.mjs`.

### Testlar (men ishga tushirganlarim)
- `python -m unittest tests.test_fx` — 11 ta, **o'tdi** (nomlar ro'yxati, qo'shish/birlashtirish/tozalash, rang/CSS rad etilishi, ruxsatlar, neon tozalanishi, ko'rinishlar, zaxira eksport/tiklash va eski zaxira).
- `node tests/fx_test.mjs` — **o'tdi** (ro'yxatlar, noto'g'ri nomlar e'tiborga olinmasligi, «animatsiyani kamaytirish», klasslar, «To'lqin» harflari, effekt klassi vaqtincha).
- `python -m unittest tests.test_hardening` (28), `tests.test_frontend_build` (5), `tests/profile_view_test.mjs`, `richtext*`, `reactions_*` — **o'tdi**. `tools/build_frontend.py --check` — mos.

### Sinalmagan (MUHIM)
- **Animatsiyalar brauzerda ko'rilmadi** (bu muhitda brauzer yo'q): silliqligi, ranglar kontrasti (ayniqsa Yaltirash/Oltin oq va qorong'i mavzuda), `mask-composite` bilan «Oqma hoshiya», «Yulduzlar» qatlami, «To'lqin»da uzun nickname qirqilishi. **Telefonda tekshiring.**
- FastAPI/pytest o'rnatilmagan: `POST /api/admin/user/profile` (pydantic `fx: dict[str,str]`) HTTP orqali **sinalmagan**; xizmat qatlami (`profiles.update`) sinalgan. `tests/test_backup.py`, `test_api.py` kabi pytest/FastAPI testlari ishga tushirilmadi.
- Ro'yxatlarda nickname effekti ham ishlaydi: juda ko'p odamga bir vaqtda effekt berilsa, eski telefonlar sekinlashishi mumkin. Kerak bo'lsa ro'yxatlarda `nameEl(u, {nofx: true})` bilan o'chirib, faqat xabar va profilda qoldirish mumkin (parametr tayyor, hozir hech qayerda yoqilmagan).

## v3.6.0 — UI/UX, holatlar va oflayn rejim

- `27-fx.js`: dizayn (fx) kodi `03-avatars-design.js` va `22-admin-extras.js` dan ajratildi.
- Chat oynasi: suhbat almashganda eski mazmun tozalanadi (`chatKey`, `wipeChatDom`), yopiq panel soyasi faqat ochiq paytda.
- Gradientlar: yopiq halqa, oklab, muzdek palitra, GPU yorug'lik (`19-fx.css`).
- Server: `users.last_seen` (migratsiya), WS `typing` relay (`app/api/ws.py`). **FastAPI'siz sinalmagan** (faqat py_compile).
- `28-presence.js` (yozmoqda/last seen), `29-sendstate.js` (shifrlanmoqda → yuborilmoqda → ✓), `30-offline.js` + `sw.js` v7 (shifrlangan oflayn nusxa).
- Test: `tests/presence_offline_test.mjs` (OK). Oflayn: kanallar va shifrlangan media fayllar ochilmaydi; "Chiqish" oflayn xotirani o'chiradi.
- Sinalmagan: haqiqiy telefonda vizual tekshiruv, HTTP/WS oqimi.

## v3.7.0 — Oflayn rejim tuzatildi + Oflayn Shaxmat (bot bilan)

### Asosiy xato (sabab)
Oflayn ko'rish rejimida yozish paneli CSS bilan yashirilgan edi, lekin `Composer.guard()` (har 1,5 s va ko'p hodisalarda ishlaydi) «o'lchami 0» deb panelni inline `display:flex !important` bilan **qayta ko'rsatib yuborardi**. Natija: input ko'rinadi, lekin `wsSend` oflayn rejimda rad etadi → xabar yuborilmaydi. Brauzerda (Chromium) eski kodda qayta ishlab chiqarildi: `composer: flex inline=flex`.

### Nima o'zgardi
- `Composer.guard` / `syncChatGate`: oflayn rejimda panel qaytarilmaydi; o'rniga **«Oflayn rejim» paneli** (`#offbar`: holat, nusxa yoshi, «♞ Shaxmat», «🔄 Ulanish»).
- `SC.fetch` oflayn rejimda tarmoqqa chiqmaydi — tushunarli xato qaytaradi (media, sozlamalar, api).
- Xabar menyusi oflayn rejimda faqat «Nusxalash»; chapga surib javob berish o'chirilgan; kanallar yorlig'i yashirilgan; «1 onlayn» yozuvi chiqmaydi; ulanish paneli sarlavhani yopmaydi.
- Internet yo'q + «kirib qolish» yoqilgan bo'lsa, ilova ochilganda o'zi oflayn nusxani ochadi (kirish ekrani qotib qolmaydi).
- Internet uzilganda xabar: «📴 Internet yo'q — yozganlaringiz navbatda turadi…». Navbatdagi («kutilmoqda») matn xabarni ham bekor qilish mumkin.
- **Oflayn Shaxmat** (`OffChess` in `app.js`, dvigatel `static/js/chessbot.js`): faqat bot bilan, 5 daraja, oq/qora/tasodifiy, to'liq qoidalar (rokirovka, en passant, promotsiya, mat/pat/50 yurish/takrorlanish/material), yurishlar tarixi, qaytarish, maslahat, taslim, yarim qolgan o'yin qurilmada saqlanadi, mahalliy natijalar. Bot Web Worker'da (qotmaydi), worker bo'lmasa asosiy oqimda. Kirish ekranidan, Gaming yorlig'idan va oflayn paneldan ochiladi. Serverga hech narsa yuborilmaydi.
- `sw.js` shell-v18; `index.html`: chessbot.js, `#offbar`, kirish ekranida tugma.

### Testlar (ishga tushirilgan)
- `node tests/chess_engine_test.mjs` — perft (6 ta etalon pozitsiya), make/undo+xesh, o'yin oxiri holatlari, rokirovka/en passant/promotsiya, bot mat topadi / tekin ferzni oladi, bot–bot to'liq o'yin: **o'tdi**.
- Chromium (Playwright) `tests/browser/*.cjs`: shaxmat (yurish, bot javobi, sudrab yurish, maslahat, qaytarish, sahifani yangilagach davom etish, taslim) va oflayn rejim (eski kodda xato qayta ishlandi, yangi kodda panel qaytmaydi, menyu, tablar): **o'tdi**, konsol xatolarisiz. Ishga tushirish: `python tests/browser/static_server.py &` va `CHROME=<yo'l> node tests/browser/offline_chess.cjs`.
- Avvalgi node testlar va `tests.test_hardening` (28) o'tdi. `tests/richtext_dom_test.mjs` o'zgartirishdan oldin ham yiqilardi (`richtext.js` ga tegilmagan).

### MUHIM ogohlantirishlar
- **`frontend/` papkasi eskirgan:** haqiqiy manba `app/static/js/app.js` (Gaming/shaxmat faqat shu yerda). `python tools/build_frontend.py` endi buni aniqlab to'xtaydi (`--force` bilan o'chirib yuboradi!). `tests.test_frontend_build::test_built_files_match_sources` oldin ham yiqilardi.
- Haqiqiy telefonda va FastAPI bilan to'liq oqim (login → oflayn nusxa → oflayn ochish → internet qaytishi) sinalmagan: backend kutubxonalari yo'q; oflayn nusxa test uchun brauzerda qo'lda yaratildi.
- Bot kuchi (4–5 daraja) sekin telefonlarda 1,6–3,5 s vaqt chegarasi ichida kamroq chuqurlikka yetadi.

## Pin (mahkamlash) + kontekst menyu tuzatishi
- Menyu tartibi: reaksiya → Javob berish → Nusxalash → **Pin qilish / Unpin qilish** → qolganlari o'zgarishsiz.
- Umumiy chat: faqat admin/ega pin qiladi, hamma ko'radi (ko'pi bilan 20 ta). Lichka: har bir tomon faqat o'zi uchun pin qiladi (suhbatdosh ko'rmaydi).
- Server: `chat_msg_pins` jadvali (user_id=0 — umumiy), `app/services/pins.py`, `app/repositories/pins.py`, WS `{"type":"pin","id","on"}`, `GET /api/pins/group`, `GET /api/pins/dm/{id}`; xabar o'chirilsa pin ham yo'qoladi.
- Mijoz: chat tepasida pin paneli (bosilsa xabarga o'tadi, bir nechta bo'lsa #1/3 aylanadi, ruxsati bor kishiga unpin tugmasi), pufakda kichik 📌 belgisi.
- Reaksiya paneli: «↓» bosilganda reaksiyalar tepaga o'sadi, amallar ro'yxati joyida qoladi; yig'ilganda yana asl holatiga qaytadi.
- Eslatma: `app/static/js/app.js` da frontend/ manbasida yo'q kod bor (Gaming/OffChess), shuning uchun `build_frontend.py --force` ishlatilmadi; o'zgarishlar ham manbaga, ham yig'ilgan faylga qo'lda qo'llandi.

## Maxfiylik: «Last seen» va Yashirin profil rejimi
- Sozlamalar → Maxfiylik va xavfsizlik → «Ko'rinish»: **Last seen ni ko'rsatish** (o'chirilsa, boshqalarga «yaqinda onlayn bo'lgan») va **Yashirin profil rejimi** (doim oflayn ko'rinish, «yozmoqda…» yuborilmaydi).
- Server: `chat_user_privacy` jadvali, `app/services/privacy.py`, `GET/POST /api/privacy`; `manager.online_ids(viewer)` yashirinlarni boshqalardan yashiradi; foydalanuvchi ko'rinishlarida `last_seen`=null va `seen_hidden` bayrog'i.
- Keshi bitta jarayon uchun; bir nechta worker bo'lsa Redis/umumiy holat kerak (PostgreSQL/Redis bosqichi bilan birga qilinadi).
