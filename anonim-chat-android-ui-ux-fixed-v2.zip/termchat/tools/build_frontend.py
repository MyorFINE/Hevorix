import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TARGETS = {
    "js": (ROOT / "frontend" / "js" / "app", ROOT / "app" / "static" / "js" / "app.js"),
    "css": (ROOT / "frontend" / "css", ROOT / "app" / "static" / "css" / "style.css"),
}


def assemble(src_dir: Path) -> str:
    names = [n.strip() for n in (src_dir / "_order.txt").read_text(encoding="utf-8").splitlines() if n.strip()]
    ext = ".css" if src_dir.name == "css" else ".js"
    parts = []
    for n in names:
        f = src_dir / (n if n.endswith(ext) else n + ext)
        parts.append(f.read_text(encoding="utf-8"))
    return "".join(parts)


def main() -> int:
    ap = argparse.ArgumentParser(description="frontend/ bo'laklaridan app.js va style.css yig'adi")
    ap.add_argument("--check", action="store_true", help="faqat tekshiradi: yig'ilgan natija joriy fayllar bilan bir xilmi")
    args = ap.parse_args()
    bad = 0
    for kind, (src_dir, out) in TARGETS.items():
        text = assemble(src_dir)
        if args.check:
            cur = out.read_text(encoding="utf-8") if out.exists() else None
            if cur != text:
                print(f"FARQ: {out.relative_to(ROOT)} frontend/ bilan mos emas")
                bad = 1
        else:
            out.write_text(text, encoding="utf-8", newline="")
            print(f"{out.relative_to(ROOT)}: {len(text)} bayt")
    if args.check and not bad:
        print("OK: yig'ilgan fayllar frontend/ bilan bir xil")
    return bad


if __name__ == "__main__":
    sys.exit(main())
