#!/usr/bin/env python3
"""Frontend yig'uvchi: `frontend/` dagi modullardan `app/static/` dagi yakuniy fayllarni quradi.

    python tools/build_frontend.py             # quradi (app/static/js/app.js va app/static/css/style.css)
    python tools/build_frontend.py --check     # hech narsa yozmaydi; diskdagi fayllar manbaga mos emasmi — tekshiradi (CI uchun)
    python tools/build_frontend.py --no-prune  # CSS: ishlatilmayotgan qoidalarni o'chirmaydi
    python tools/build_frontend.py --no-minify # CSS: o'qiladigan ko'rinishda (faqat birlashtiradi)

JS: `frontend/js/app/_order.txt` dagi tartibda fayllar BIR XIL baytlar bilan ulanadi (hech qanday o'zgartirish yo'q).
    Sabab: ilovaning butun mantig'i bitta IIFE yopilmasida (closure) yashaydi va mavjud testlar `app.js` matnini
    qirqib oladi. Shuning uchun manba modullarga bo'lingan, ammo yetkazib beriladigan fayl avvalgidek bitta.
CSS: `frontend/css/_order.txt` tartibida ulanadi (kaskad tartibi saqlanadi), so'ng
    1) hech qayerda ishlatilmaydigan klass/id qoidalari va yetim @keyframes olib tashlanadi (ro'yxat: frontend/css/PRUNE_REPORT.txt),
    2) izohlar va ortiqcha bo'shliqlar olib tashlanadi (qiymatlar mazmuni o'zgarmaydi).
Faqat standart kutubxona.
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
FRONT = ROOT / "frontend"
STATIC = ROOT / "app" / "static"
JS_OUT = STATIC / "js" / "app.js"
CSS_OUT = STATIC / "css" / "style.css"
REPORT = FRONT / "css" / "PRUNE_REPORT.txt"

CONTAINER_AT = {"media", "supports", "layer", "container", "document"}


# ----------------------------------------------------------------------------- JS
def _read_order(folder: Path) -> list[Path]:
    names = [n.strip() for n in (folder / "_order.txt").read_text(encoding="utf-8").splitlines() if n.strip()]
    return [folder / n for n in names]


def _read(p: Path) -> str:
    with open(p, encoding="utf-8", newline="") as f:      # newline="" — satr oxirlari o'zgarmaydi
        return f.read()


def build_js() -> str:
    return "".join(_read(p) for p in _read_order(FRONT / "js" / "app"))


# ----------------------------------------------------------------------------- CSS parser
def _skip_string(s: str, i: int) -> int:
    q = s[i]
    i += 1
    while i < len(s):
        if s[i] == "\\":
            i += 2
            continue
        if s[i] == q:
            return i + 1
        i += 1
    return i


def strip_comments(s: str) -> str:
    out, i, n = [], 0, len(s)
    while i < n:
        c = s[i]
        if c == "/" and s[i + 1:i + 2] == "*":
            j = s.find("*/", i + 2)
            i = n if j < 0 else j + 2
            out.append(" ")
        elif c in "\"'":
            j = _skip_string(s, i)
            out.append(s[i:j])
            i = j
        else:
            out.append(c)
            i += 1
    return "".join(out)


def parse(text: str) -> list[dict]:
    """CSS'ni oddiy daraxtga aylantiradi. Faqat shu loyihadagi CSS shakllarini (ichma-ich qoidalarsiz) qo'llab-quvvatlaydi."""
    s = strip_comments(text)
    pos = 0

    def block(top: bool) -> list[dict]:
        nonlocal pos
        items: list[dict] = []
        while pos < len(s):
            while pos < len(s) and s[pos].isspace():
                pos += 1
            if pos >= len(s):
                break
            if s[pos] == "}":
                if top:
                    raise ValueError("ortiqcha '}' (%d)" % pos)
                pos += 1
                return items
            start, paren = pos, 0
            while pos < len(s):
                c = s[pos]
                if c in "\"'":
                    pos = _skip_string(s, pos)
                    continue
                if c in "([":
                    paren += 1
                elif c in ")]":
                    paren -= 1
                elif paren <= 0 and c in "{;":
                    break
                pos += 1
            prelude = s[start:pos].strip()
            if pos >= len(s):
                raise ValueError("tugallanmagan qoida: " + prelude[:60])
            if s[pos] == ";":
                pos += 1
                items.append({"k": "stmt", "pre": prelude})
                continue
            pos += 1                                            # '{'
            m = re.match(r"@([-\w]+)", prelude)
            name = m.group(1).lower() if m else ""
            if name in CONTAINER_AT or name.endswith("keyframes"):
                items.append({"k": "at", "pre": prelude, "name": name, "kids": block(False)})
            else:                                               # oddiy qoida (yoki @font-face kabi): tana — deklaratsiyalar
                b0 = pos
                depth = 1
                while pos < len(s) and depth:
                    c = s[pos]
                    if c in "\"'":
                        pos = _skip_string(s, pos)
                        continue
                    if c == "{":
                        depth += 1
                    elif c == "}":
                        depth -= 1
                    pos += 1
                if depth:
                    raise ValueError("tugallanmagan blok: " + prelude[:60])
                body = s[b0:pos - 1]
                if "{" in body:
                    raise ValueError("ichma-ich qoida qo'llab-quvvatlanmaydi: " + prelude[:60])
                items.append({"k": "rule", "pre": prelude, "body": body})
        if not top:
            raise ValueError("tugallanmagan @-qoida")
        return items

    return block(True)


# ----------------------------------------------------------------------------- minify helpers
def _collapse_ws(s: str) -> str:
    """Satr ichidagi bo'shliqlardan tashqari barcha bo'shliq qatorlarini bitta probelga keltiradi."""
    out, i, n, sp = [], 0, len(s), False
    while i < n:
        c = s[i]
        if c in "\"'":
            j = _skip_string(s, i)
            if sp:
                out.append(" ")
                sp = False
            out.append(s[i:j])
            i = j
        elif c.isspace():
            sp = True
            i += 1
        else:
            if sp:
                out.append(" ")
                sp = False
            out.append(c)
            i += 1
    return "".join(out).strip()


def _tight(s: str, chars: str, *, only_outside_parens: bool = False) -> str:
    """`chars` dagi belgilar atrofidagi probellarni olib tashlaydi (qo'shtirnoq ichiga tegmaydi)."""
    out, i, n, depth = [], 0, len(s), 0
    while i < n:
        c = s[i]
        if c in "\"'":
            j = _skip_string(s, i)
            out.append(s[i:j])
            i = j
            continue
        if c in "([":
            depth += 1
        elif c in ")]":
            depth = max(0, depth - 1)
        if c == " ":
            prev = out[-1] if out else ""
            nxt = s[i + 1:i + 2]
            active = depth == 0 or not only_outside_parens
            if active and (prev and prev[-1] in chars or nxt and nxt in chars):
                i += 1
                continue
        out.append(c)
        i += 1
    return "".join(out)


def min_selector(sel: str) -> str:
    s = _collapse_ws(sel)
    s = _tight(s, ",")
    # kombinatorlar faqat qavs/[] tashqarisida (nth-child(2n + 1) va [a~=b] buzilmasin)
    s = _tight(s, ">+~", only_outside_parens=True)
    return s


def min_prelude(pre: str) -> str:
    s = _collapse_ws(pre)
    s = _tight(s, ",")
    out, i, n, depth = [], 0, len(s), 0                     # (feature: value) ichida ':' atrofi
    while i < n:
        c = s[i]
        if c in "\"'":
            j = _skip_string(s, i)
            out.append(s[i:j])
            i = j
            continue
        if c == "(":
            depth += 1
            out.append(c)
            if s[i + 1:i + 2] == " ":
                i += 1
        elif c == ")":
            depth = max(0, depth - 1)
            if out and out[-1] == " ":
                out.pop()
            out.append(c)
        elif c == ":" and depth:
            if out and out[-1] == " ":
                out.pop()
            out.append(c)
            if s[i + 1:i + 2] == " ":
                i += 1
        else:
            out.append(c)
        i += 1
    return "".join(out)


def split_decls(body: str) -> list[str]:
    parts, cur, depth, i, n = [], [], 0, 0, len(body)
    while i < n:
        c = body[i]
        if c in "\"'":
            j = _skip_string(body, i)
            cur.append(body[i:j])
            i = j
            continue
        if c in "([":
            depth += 1
        elif c in ")]":
            depth = max(0, depth - 1)
        if c == ";" and depth == 0:
            parts.append("".join(cur))
            cur = []
        else:
            cur.append(c)
        i += 1
    parts.append("".join(cur))
    return [p for p in (x.strip() for x in parts) if p]


def min_value(v: str) -> str:
    v = _collapse_ws(v)
    v = _tight(v, ",")
    v = re.sub(r"\s*!\s*important\s*$", "!important", v, flags=re.I)
    out, i, n = [], 0, len(v)                               # '(' dan keyin va ')' dan oldingi probellar
    while i < n:
        c = v[i]
        if c in "\"'":
            j = _skip_string(v, i)
            out.append(v[i:j])
            i = j
            continue
        if c == "(":
            out.append(c)
            if v[i + 1:i + 2] == " ":
                i += 1
        elif c == ")" and out and out[-1] == " ":
            out.pop()
            out.append(c)
        else:
            out.append(c)
        i += 1
    return "".join(out)


def min_body(body: str) -> str:
    out = []
    for d in split_decls(body):
        k = d.find(":")
        if k < 0:
            out.append(_collapse_ws(d))
            continue
        out.append(d[:k].strip() + ":" + min_value(d[k + 1:]))
    return ";".join(out)


# ----------------------------------------------------------------------------- unused-rule analysis
def _corpus() -> str:
    parts: list[str] = []
    for p in sorted(STATIC.rglob("*")):
        if p.is_file() and p.suffix in {".html", ".js", ".svg", ".json"} and p != JS_OUT:
            parts.append(_read(p))
    parts.append(build_js())
    for p in sorted((ROOT / "app").rglob("*.py")):
        parts.append(_read(p))
    return "\n".join(parts)


def _strip_parens(sel: str) -> str:
    out, depth, i = [], 0, 0
    while i < len(sel):
        c = sel[i]
        if c in "\"'":
            i = _skip_string(sel, i)
            continue
        if c in "([":
            depth += 1
        elif c in ")]":
            depth = max(0, depth - 1)
        elif depth == 0:
            out.append(c)
        i += 1
    return "".join(out)


class Usage:
    def __init__(self, corpus: str):
        self.corpus = corpus
        self._cache: dict[str, bool] = {}

    def name_used(self, name: str) -> bool:
        hit = self._cache.get(name)
        if hit is not None:
            return hit
        c = self.corpus
        ok = re.search(r"(?<![\w-])" + re.escape(name) + r"(?![\w-])", c) is not None
        if not ok:                                          # dinamik yig'iladigan nomlar: "ani-" + x, `ani-${x}`
            for m in re.finditer(r"[-_]", name):
                pre = name[:m.start() + 1]
                if re.search(re.escape(pre) + r"""(?:["'`]\s*\+|\$\{)""", c):
                    ok = True
                    break
        self._cache[name] = ok
        return ok

    def selector_dead(self, sel: str) -> str | None:
        """Selektor HECH QACHON mos kelmasligi aniq bo'lsa — sababini qaytaradi (aks holda None)."""
        if "\\" in sel:
            return None
        flat = _strip_parens(sel)
        for m in re.finditer(r"([.#])(-?[A-Za-z_][\w-]*)", flat):
            if m.group(1) == "#" and re.fullmatch(r"[0-9a-fA-F]{3,8}", m.group(2)):
                continue
            if not self.name_used(m.group(2)):
                return m.group(1) + m.group(2)
        return None


def _split_selectors(pre: str) -> list[str]:
    parts, cur, depth, i = [], [], 0, 0
    while i < len(pre):
        c = pre[i]
        if c in "\"'":
            j = _skip_string(pre, i)
            cur.append(pre[i:j])
            i = j
            continue
        if c in "([":
            depth += 1
        elif c in ")]":
            depth = max(0, depth - 1)
        if c == "," and depth == 0:
            parts.append("".join(cur))
            cur = []
        else:
            cur.append(c)
        i += 1
    parts.append("".join(cur))
    return [p.strip() for p in parts if p.strip()]


def prune(items: list[dict], usage: Usage, report: list[str], where: str = "") -> list[dict]:
    out = []
    for it in items:
        if it["k"] == "rule":
            keep, dropped = [], []
            for sel in _split_selectors(it["pre"]):
                why = usage.selector_dead(sel)
                (dropped if why else keep).append((sel, why))
            for sel, why in dropped:
                report.append("%s%s    [%s ishlatilmaydi]" % (where, _collapse_ws(sel), why))
            if keep:
                out.append({**it, "pre": ",".join(s for s, _ in keep)})
        elif it["k"] == "at" and not it["name"].endswith("keyframes"):
            kids = prune(it["kids"], usage, report, where + _collapse_ws(it["pre"]) + " { ")
            if kids:
                out.append({**it, "kids": kids})
            else:
                report.append("%s(bo'sh qoldi: %s)" % (where, _collapse_ws(it["pre"])))
        else:
            out.append(it)
    return out


def prune_keyframes(items: list[dict], usage: Usage, report: list[str]) -> list[dict]:
    css_text = "\n".join(_flat_values(items))
    res = []
    for it in items:
        if it["k"] == "at" and it["name"].endswith("keyframes"):
            kf = it["pre"].split(None, 1)[1].strip() if " " in it["pre"] else ""
            used = re.search(r"(?<![\w-])" + re.escape(kf) + r"(?![\w-])", css_text) or usage.name_used(kf)
            if not used:
                report.append("@keyframes %s    [hech qayerda chaqirilmaydi]" % kf)
                continue
        elif it["k"] == "at":
            it = {**it, "kids": prune_keyframes(it["kids"], usage, report)}
        res.append(it)
    return res


def _flat_values(items: list[dict]):
    for it in items:
        if it["k"] == "rule":
            yield it["body"]
        elif it["k"] == "at" and not it["name"].endswith("keyframes"):
            yield from _flat_values(it["kids"])


# ----------------------------------------------------------------------------- emit
def emit(items: list[dict], minify: bool) -> str:
    if not minify:
        return emit_pretty(items, 0)
    out = []
    for it in items:
        if it["k"] == "rule":
            out.append("%s{%s}" % (min_selector(it["pre"]), min_body(it["body"])))
        elif it["k"] == "at":
            out.append("%s{%s}" % (min_prelude(it["pre"]), emit(it["kids"], True)))
        else:
            out.append(it["pre"] + ";")
    return "".join(out)


def emit_pretty(items: list[dict], lvl: int) -> str:
    ind, out = "  " * lvl, []
    for it in items:
        if it["k"] == "rule":
            out.append("%s%s{%s}\n" % (ind, _collapse_ws(it["pre"]), it["body"].strip()))
        elif it["k"] == "at":
            out.append("%s%s{\n%s%s}\n" % (ind, _collapse_ws(it["pre"]), emit_pretty(it["kids"], lvl + 1), ind))
        else:
            out.append(ind + it["pre"] + ";\n")
    return "".join(out)


def build_css(do_prune: bool = True, minify: bool = True) -> tuple[str, list[str]]:
    src = "".join(_read(p) for p in _read_order(FRONT / "css"))
    tree = parse(src)
    report: list[str] = []
    if do_prune:
        usage = Usage(_corpus())
        tree = prune(tree, usage, report)
        tree = prune_keyframes(tree, usage, report)
    header = "/* Anonim Chat — avtomatik yig'ilgan (tools/build_frontend.py). Manba: frontend/css/*.css — shu faylni qo'lda tahrirlamang. */\n"
    return header + emit(tree, minify) + "\n", report


# ----------------------------------------------------------------------------- CLI
def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--no-prune", action="store_true")
    ap.add_argument("--no-minify", action="store_true")
    ap.add_argument("--force", action="store_true", help="eskirgan manbadan app.js ni qayta yozishga ruxsat (XAVFLI)")
    a = ap.parse_args(argv)

    # HIMOYA: app/static/js/app.js frontend/ manbasidan oldinda (Gaming, Oflayn Shaxmat faqat shu faylda). Qayta yig'ish ularni o'chirib yuboradi.
    if not a.check and not a.force and JS_OUT.exists() and "const Gaming = (() =>" in _read(JS_OUT) and "const Gaming = (() =>" not in build_js():
        print("TO'XTATILDI: app/static/js/app.js dagi Gaming/OffChess frontend/ manbasida yo'q — qayta yig'ish ularni o'chirib yuboradi.\n"
              "Avval o'zgarishlarni frontend/js/app/ ga ko'chiring yoki --force bilan davom eting.", file=sys.stderr)
        return 2

    js = build_js()
    css, report = build_css(not a.no_prune, not a.no_minify)
    rep_text = "\n".join(report) + ("\n" if report else "")
    if a.check:
        bad = []
        if not JS_OUT.exists() or _read(JS_OUT) != js:
            bad.append(str(JS_OUT.relative_to(ROOT)))
        if not CSS_OUT.exists() or _read(CSS_OUT) != css:
            bad.append(str(CSS_OUT.relative_to(ROOT)))
        if bad:
            print("MANBAGA MOS EMAS (python tools/build_frontend.py ishga tushiring):", *bad, sep="\n  ")
            return 1
        print("OK: app.js va style.css manbaga mos")
        return 0
    with open(JS_OUT, "w", encoding="utf-8", newline="") as f:
        f.write(js)
    with open(CSS_OUT, "w", encoding="utf-8", newline="") as f:
        f.write(css)
    REPORT.write_text(rep_text, encoding="utf-8")
    print("app.js  : %d bayt (%d modul)" % (len(js.encode()), len(_read_order(FRONT / "js" / "app"))))
    print("style.css: %d bayt; olib tashlangan qoidalar: %d (frontend/css/PRUNE_REPORT.txt)" % (len(css.encode()), len(report)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
