#!/usr/bin/env python3
"""CSS ekvivalentligini HAQIQIY brauzerda (Chromium, playwright) tekshiradi.

Eski (qo'lda yozilgan) style.css bilan yangi (yig'ilgan, minify qilingan) style.css brauzer CSSOM'ida solishtiriladi:
har bir qoida (kontekst @media/@supports + selektor + deklaratsiyalar) brauzer tomonidan kanonik shaklga keltiriladi.
Yangi ro'yxat eskisining TARTIBLI qism ketma-ketligi bo'lishi va yo'qolgan har bir element PRUNE_REPORT.txt dagi
ishlatilmaydigan klass/id ni o'z ichiga olishi shart. Aks holda xato (chiqish kodi 1).

    python tools/verify_css.py <eski_style.css> [<yangi_style.css>]
Talab: pip install playwright && playwright install chromium (faqat tekshirish uchun; ilovaga kerak emas).
"""
import re
import sys
from pathlib import Path

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
ADDED = {".row.vs-off"}                                 # ataylab qo'shilgan yangi qoidalar (js/virtual.js)
JS = r"""
(css) => {
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
  const out = [];
  const splitSel = s => { const r = []; let d = 0, cur = '', q = null;
    for (const c of s) { if (q) { cur += c; if (c === q) q = null; continue; }
      if (c === '"' || c === "'") { q = c; cur += c; continue; }
      if ('(['.includes(c)) d++; if (')]'.includes(c)) d--;
      if (c === ',' && d === 0) { r.push(cur.trim()); cur = ''; } else cur += c; }
    if (cur.trim()) r.push(cur.trim()); return r; };
  const walk = (rules, ctx) => { for (const r of rules) {
    if (r.type === 1) { const body = r.style.cssText; for (const s of splitSel(r.selectorText)) out.push(ctx + ' | ' + s + ' | ' + body); }
    else if (r.type === 7) out.push(ctx + ' | @keyframes ' + r.name + ' | ' + Array.from(r.cssRules).map(k => k.cssText).join(' '));
    else if (r.cssRules) walk(r.cssRules, ctx + ' > ' + (r.conditionText !== undefined ? '@' + r.constructor.name + ' ' + r.conditionText : r.cssText.split('{')[0].trim()));
    else out.push(ctx + ' | ' + r.cssText); } };
  walk(st.sheet.cssRules, '');
  return out;
}
"""


def main() -> int:
    old = Path(sys.argv[1]).read_text(encoding="utf-8")
    new = Path(sys.argv[2] if len(sys.argv) > 2 else ROOT / "app/static/css/style.css").read_text(encoding="utf-8")
    report = (ROOT / "frontend/css/PRUNE_REPORT.txt").read_text(encoding="utf-8")
    dead = set(re.findall(r"\[([.#][\w-]+) ishlatilmaydi\]", report))
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page()
        a = pg.evaluate(JS, old)
        c = pg.evaluate(JS, new)
        b.close()
    i = 0
    missing, extra = [], []
    for item in c:                                       # `a` (eski) — `c` (yangi) ning tartibli ustki ketma-ketligi bo'lishi kerak
        j = i
        while j < len(a) and a[j] != item:
            j += 1
        if j < len(a):
            missing.extend(a[i:j])
            i = j + 1
        else:
            extra.append(item)                           # eski CSS'da yo'q: faqat ruxsat etilgan YANGI qoidalar bo'lishi mumkin
    missing.extend(a[i:])
    stray = [e for e in extra if e.split(" | ")[1] not in ADDED]
    if stray:
        print("XATO: kutilmagan yangi/o'zgargan qoida:", stray[0][:200])
        return 1
    bad = [m for m in missing if not (m.startswith("@keyframes", 0) or any(re.search(re.escape(d) + r"(?![\w-])", m.split(" | ")[1]) for d in dead)
                                       or m.split(" | ")[1].startswith("@keyframes"))]
    print("eski: %d qoida, yangi: %d, olib tashlangan: %d, qo'shilgan: %d" % (len(a), len(c), len(missing), len(extra)))
    if bad:
        print("XATO: ishlatilmaydi deb belgilanmagan qoidalar yo'qolgan:")
        print(*bad[:10], sep="\n")
        return 1
    print("OK: barcha qolgan qoidalar (selektor + deklaratsiyalar + tartib) brauzerda aynan bir xil")
    return 0


if __name__ == "__main__":
    sys.exit(main())
