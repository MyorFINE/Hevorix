import os
import sys
import tempfile
import time
import unittest
from pathlib import Path

os.environ.setdefault("TERMCHAT_DATA_DIR", tempfile.mkdtemp(prefix="termchat-priv-"))
os.environ.setdefault("TERMCHAT_REQUIRE_E2EE", "0")
os.environ.setdefault("TERMCHAT_ADMIN_PASSWORD", "owner-pass-1")
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.db import db
from app.errors import ChatError
from app.repositories import messages, users
from app.services import auth, autodel, bootstrap, chat, privacy


def _user(name):
    _, u = auth.register(name, name.title(), "secret12")
    return users.get(u["id"])


class PrivacyFeatureTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        bootstrap.ensure_owner()
        cls.owner = users.get(users.get_by_username("asura")["id"])
        cls.a, cls.b, cls.c = _user("pa_user"), _user("pb_user"), _user("pc_user")

    def test_owner_is_asura_and_legacy_demoted(self):
        self.assertEqual(self.owner["username"], "Asura")
        self.assertEqual(self.owner["role"], "owner")
        old = users.create("Hevorix", "Hevorix", "x", "owner", time.time())
        bootstrap.ensure_owner()
        self.assertEqual(users.get(old)["role"], "admin")
        self.assertEqual(users.get_by_username("asura")["role"], "owner")

    def test_closed_dm_blocks_strangers_but_not_admin_or_replies(self):
        chat.post(self.a, "salom oddiy", self.b["id"])
        privacy.set_flags(self.b["id"], dm_closed=True)
        with self.assertRaises(ChatError) as cm:
            chat.post(self.c, "salom", self.b["id"])
        self.assertEqual(cm.exception.status, 403)
        chat.post(self.owner, "admin yozadi", self.b["id"])
        d = _user("pd_user")
        with self.assertRaises(ChatError):
            chat.post(d, "yo'q", self.b["id"])
        chat.post(self.b, "men yozdim", d["id"])
        chat.post(d, "javob", self.b["id"])
        privacy.set_flags(self.b["id"], dm_closed=False)
        chat.post(self.c, "endi ochiq", self.b["id"])

    def test_closed_dm_does_not_affect_group_or_own_sending(self):
        privacy.set_flags(self.c["id"], dm_closed=True)
        chat.post(self.a, "umumiy chat")
        chat.post(self.c, "o'zi yozadi", self.a["id"])
        chat.post(self.a, "a javob beradi", self.c["id"])
        privacy.set_flags(self.c["id"], dm_closed=False)

    def test_auto_delete_only_after_enable_and_window_survives_disable(self):
        e = _user("pe_user")
        before = chat.post(e, "yoqishdan oldin")["id"]
        privacy.set_flags(e["id"], auto_del=True)
        inside = chat.post(e, "yoqilgan vaqtda")["id"]
        privacy.set_flags(e["id"], auto_del=False)
        after = chat.post(e, "o'chirilgandan keyin")["id"]
        now = time.time() + 25 * 3600
        due = {r["id"] for r in privacy.due_messages(now)}
        self.assertIn(inside, due)
        self.assertNotIn(before, due)
        self.assertNotIn(after, due)
        self.assertEqual({r["id"] for r in privacy.due_messages(time.time())} & {inside}, set())

    def test_purge_marks_deleted(self):
        f = _user("pf_user")
        privacy.set_flags(f["id"], auto_del=True)
        mid = chat.post(f, "o'chadi")["id"]
        db.run("UPDATE messages SET created_at=? WHERE id=?", (time.time() - 25 * 3600, mid))
        db.run("UPDATE auto_del_windows SET start=? WHERE user_id=?", (time.time() - 30 * 3600, f["id"]))
        done = autodel.purge_due()
        self.assertIn(mid, [r["id"] for r in done])
        self.assertEqual(messages.get(mid)["deleted"], 1)

    def test_flags_persist_in_view(self):
        from app.services import views
        g = _user("pg_user")
        privacy.set_flags(g["id"], dm_closed=True, auto_del=True)
        self.assertTrue(views.user_view(g["id"])["dm_closed"])
        cur = privacy.get(g["id"])
        self.assertTrue(cur["auto_del"] and cur["dm_closed"] and not cur["ghost"])


if __name__ == "__main__":
    unittest.main()
