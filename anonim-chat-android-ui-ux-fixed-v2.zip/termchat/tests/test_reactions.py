"""Reaksiyalar: qo'yish/almashtirish/olib tashlash, ruxsatlar (lichka, shaxsiy kanal), mute, xabar ko'rinishidagi `rx`."""
import time

import pytest

from app.constants import REACTION_EMOJIS
from app.errors import ChatError
from app.repositories import messages, users as users_repo
from app.security import hash_password
from app.services import chat, views
from app.services import reactions as svc


def _user(name: str, role: str = "user"):
    uid = users_repo.create(name, name.title(), hash_password("x"), role, time.time())
    return users_repo.get(uid)


@pytest.fixture(scope="module")
def cast():
    sfx = str(int(time.time() * 1000))[-6:]
    return {"a": _user(f"rxa{sfx}"), "b": _user(f"rxb{sfx}"), "c": _user(f"rxc{sfx}")}


def _group_msg(user) -> int:
    return messages.create(user["id"], "salom", time.time())


def test_toggle_replace_remove(cast):
    mid = _group_msg(cast["a"])
    _, rx = svc.react(cast["b"], mid, "❤️")
    assert rx == {"❤️": [cast["b"]["id"]]}
    _, rx = svc.react(cast["c"], mid, "❤️")
    assert rx["❤️"] == [cast["b"]["id"], cast["c"]["id"]]
    _, rx = svc.react(cast["b"], mid, "🔥")                    # almashtirish: bitta foydalanuvchi — bitta reaksiya
    assert rx == {"❤️": [cast["c"]["id"]], "🔥": [cast["b"]["id"]]}
    _, rx = svc.react(cast["b"], mid, "🔥")                    # qayta bosish — olib tashlaydi
    assert rx == {"❤️": [cast["c"]["id"]]}
    _, rx = svc.react(cast["c"], mid, None)                    # None — olib tashlash
    assert rx == {}
    _, rx = svc.react(cast["c"], mid, None)                    # yo'q reaksiyani olib tashlash xato emas
    assert rx == {}


def test_only_allowed_emojis(cast):
    mid = _group_msg(cast["a"])
    with pytest.raises(ChatError):
        svc.react(cast["b"], mid, "<script>")
    with pytest.raises(ChatError):
        svc.react(cast["b"], mid, "x" * 500)
    assert all(svc.react(cast["b"], mid, e) for e in REACTION_EMOJIS[:2])


def test_missing_or_deleted_message(cast):
    with pytest.raises(ChatError) as e:
        svc.react(cast["a"], 99999999, "👍")
    assert e.value.status == 404
    mid = _group_msg(cast["a"])
    messages.mark_deleted(mid)
    with pytest.raises(ChatError):
        svc.react(cast["b"], mid, "👍")


def test_dm_reactions_only_for_participants(cast):
    mid = messages.create(cast["a"]["id"], "lichka", time.time(), recipient_id=cast["b"]["id"])
    svc.react(cast["b"], mid, "👍")                            # qabul qiluvchi
    svc.react(cast["a"], mid, "❤️")                            # yuboruvchi
    with pytest.raises(ChatError) as e:
        svc.react(cast["c"], mid, "👍")                        # begona
    assert e.value.status == 404


def test_muted_user_cannot_react(cast):
    mid = _group_msg(cast["a"])
    users_repo.get(cast["c"]["id"])
    from app.db import db
    db.run("UPDATE users SET muted_until=? WHERE id=?", (time.time() + 600, cast["c"]["id"]))
    try:
        with pytest.raises(ChatError):
            svc.react(users_repo.get(cast["c"]["id"]), mid, "👍")
    finally:
        db.run("UPDATE users SET muted_until=0 WHERE id=?", (cast["c"]["id"],))


def test_rx_in_message_view_and_history(cast):
    mid = _group_msg(cast["a"])
    svc.react(cast["b"], mid, "😂")
    v = views.message_view(messages.get(mid))
    assert v["rx"] == {"😂": [cast["b"]["id"]]}
    hist, _ = chat.history_page()
    assert next(x for x in hist if x["id"] == mid)["rx"] == {"😂": [cast["b"]["id"]]}
    assert views.message_view(messages.get(_group_msg(cast["a"])))["rx"] == {}


def test_hard_delete_cascades(cast):
    from app.db import db
    mid = _group_msg(cast["a"])
    svc.react(cast["b"], mid, "👍")
    db.run("DELETE FROM messages WHERE id=?", (mid,))
    assert db.one("SELECT COUNT(*) AS c FROM reactions WHERE message_id=?", (mid,))["c"] == 0
