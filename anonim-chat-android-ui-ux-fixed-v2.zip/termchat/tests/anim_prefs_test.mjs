import assert from "node:assert/strict";
import fs from "node:fs";
import vm from "node:vm";

const store = new Map();
const cls = new Set();
const imgs = [];
class FakeImage {
  set src(v) { this._s = v; setTimeout(() => this.onload && this.onload(), 0); }
  get src() { return this._s; }
  naturalWidth = 32; naturalHeight = 32;
}
const doc = {
  documentElement: { classList: { toggle: (c, on) => (on ? cls.add(c) : cls.delete(c)), add: c => cls.add(c), contains: c => cls.has(c) }, dataset: {} },
  querySelector: () => null,
  querySelectorAll: sel => imgs.filter(i => sel.includes('data-anim-kind="' + i.dataset.animKind + '"')),
  createElement: () => ({ getContext: () => ({ drawImage() {} }), toDataURL: () => "data:image/png;base64,FROZEN" }),
};
const ctx = {
  document: doc, localStorage: { getItem: k => (store.has(k) ? store.get(k) : null), setItem: (k, v) => store.set(k, v) },
  matchMedia: () => ({ matches: false }), navigator: {}, Image: FakeImage, setTimeout,
};
ctx.window = ctx;
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(new URL("../app/static/js/theme.js", import.meta.url), "utf8"), ctx);
const AP = ctx.AnimPrefs;
const mk = kind => { const i = { dataset: { animUrl: "/emoji-files/a.gif", animKind: kind }, src: "" }; imgs.push(i); return i; };
const tick = () => new Promise(r => setTimeout(r, 20));

assert.ok(AP.on("stk") && AP.on("emo") && AP.on("ui"), "standart: hammasi yoqilgan");
const s = mk("stk"), e = mk("emo");
AP.paint(s); AP.paint(e);
assert.equal(s.src, "/emoji-files/a.gif");

AP.set("stk", false); await tick();
assert.equal(s.src, "data:image/png;base64,FROZEN", "stiker oddiy rasmga aylanadi");
assert.equal(e.src, "/emoji-files/a.gif", "emoji tegilmaydi");
assert.ok(cls.has("no-stk-anim") && !cls.has("no-emo-anim"));

AP.set("emo", false); AP.set("ui", false); await tick();
assert.equal(e.src, "data:image/png;base64,FROZEN");
assert.ok(cls.has("no-emo-anim") && cls.has("no-ui-anim"));
assert.equal(store.get("termchat_anim_ui"), "off");

AP.set("stk", true); AP.set("emo", true); AP.set("ui", true); await tick();
assert.equal(s.src, "/emoji-files/a.gif"); assert.equal(e.src, "/emoji-files/a.gif");
assert.ok(!cls.has("no-stk-anim") && !cls.has("no-emo-anim") && !cls.has("no-ui-anim"));
console.log("anim_prefs_test: OK");
