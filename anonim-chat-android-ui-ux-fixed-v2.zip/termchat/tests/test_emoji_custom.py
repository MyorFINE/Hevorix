import io

import pytest
from PIL import Image, ImageDraw

from app import emojis
from app.config import settings
from app.errors import ChatError
from app.repositories import emojis as repo
from app.repositories import users as users_repo
from app.services import badges, emoji as svc, emojimaker


def _jpg_on_white():
    im = Image.new("RGB", (300, 300), (255, 255, 255))
    ImageDraw.Draw(im).ellipse((60, 60, 240, 240), fill=(30, 120, 220))
    b = io.BytesIO(); im.save(b, "JPEG"); return b.getvalue()


def _png_alpha():
    im = Image.new("RGBA", (200, 200), (0, 0, 0, 0))
    ImageDraw.Draw(im).rectangle((40, 40, 160, 160), fill=(200, 0, 0, 255))
    b = io.BytesIO(); im.save(b, "PNG"); return b.getvalue()


def _gif(frames=4):
    fs = []
    for i in range(frames):
        im = Image.new("RGB", (64, 64), (255, 255, 255)); ImageDraw.Draw(im).rectangle((i * 12, 10, i * 12 + 12, 40), fill=(220, 0, 0)); fs.append(im.convert("P"))
    b = io.BytesIO(); fs[0].save(b, "GIF", save_all=True, append_images=fs[1:], duration=80, loop=0); return b.getvalue()


@pytest.fixture(scope="module")
def people():
    now = 1.0
    admin = users_repo.get(users_repo.create("em_admin", "A", "x", "admin", now))
    bob = users_repo.get(users_repo.create("em_bob", "B", "x", "user", now))
    eve = users_repo.get(users_repo.create("em_eve", "E", "x", "user", now))
    return admin, bob, eve


def test_png_alpha_keeps_transparency_and_trims():
    m = emojimaker.make(_png_alpha(), remove_bg=True)
    assert m.source_alpha and m.transparent and not m.bg_removed and m.ext == "png"
    im = Image.open(io.BytesIO(m.data))
    assert im.mode == "RGBA" and im.getchannel("A").getpixel((0, 0)) == 255 and im.size == (121, 121)


def test_jpg_background_removed_only_when_asked():
    kept = emojimaker.make(_jpg_on_white())
    assert not kept.transparent and not kept.bg_removed
    cut = emojimaker.make(_jpg_on_white(), remove_bg=True)
    assert cut.bg_removed and cut.transparent
    a = Image.open(io.BytesIO(cut.data)).getchannel("A")
    assert a.getpixel((0, 0)) == 0 and a.getpixel((a.width // 2, a.height // 2)) == 255


def test_animated_gif_becomes_animated_webp():
    m = emojimaker.make(_gif())
    assert m.animated and m.ext == "webp" and Image.open(io.BytesIO(m.data)).n_frames == 4


@pytest.mark.parametrize("raw", [b"", b"salom", b"\x89PNG\r\n\x1a\n" + b"x" * 8, b"<svg xmlns='http://www.w3.org/2000/svg'><script>1</script></svg>"])
def test_garbage_rejected(raw):
    with pytest.raises(ChatError):
        emojimaker.make(raw)


def test_user_without_permission_cannot_create(people):
    _, bob, _ = people
    with pytest.raises(ChatError) as e:
        svc.create(bob, _png_alpha(), "mening")
    assert e.value.status == 403


def test_admin_creates_emoji_in_pack_and_catalog_lists_it(people):
    admin, bob, _ = people
    pid = svc.create_pack(admin, "Sinov to'plam", True)
    r = svc.create(admin, _jpg_on_white(), "Kulgi 1", remove_bg=True, anim="bounce", pack_id=pid, public=True)
    assert r["name"] == "kulgi_1" and r["bg_removed"]
    row = repo.get_by_name("kulgi_1")
    assert (settings.emoji_dir / row["file"]).is_file() and row["anim"] == "bounce" and row["pack_id"] == pid
    cat = svc.catalog(admin)
    e = next(x for x in cat["emojis"] if x["token"] == ":kulgi_1:")
    assert e["url"] == f"/emoji-files/{row['file']}" and e["pack"] == pid and cat["perms"]["manage"]
    assert any(p["id"] == pid for p in cat["packs"]) and "global" in cat
    assert emojis.is_token(":kulgi_1:")
    assert badges.clean(":kulgi_1:", "glow") == (":kulgi_1:", "glow")


@pytest.mark.parametrize("bad", ["kali", "kulgi_1", "A", "a" * 15, "../x", ""])
def test_names_are_validated_and_unique(people, bad):
    admin, _, _ = people
    with pytest.raises(ChatError):
        svc.create(admin, _png_alpha(), bad)


def test_unknown_animation_and_pack_rejected(people):
    admin, _, _ = people
    with pytest.raises(ChatError):
        svc.create(admin, _png_alpha(), "yomon_anim", anim="<script>")
    with pytest.raises(ChatError):
        svc.create(admin, _png_alpha(), "yomon_pack", pack_id=99999)


def test_permissions_global_and_per_user(people):
    admin, bob, eve = people
    assert svc.perms_of(bob) == {"use": False, "create": False, "manage": False}
    svc.set_global_mode(admin, "use")
    assert svc.perms_of(users_repo.get(bob["id"]))["use"] and not svc.perms_of(users_repo.get(bob["id"]))["create"]
    svc.set_global_mode(admin, "off")
    svc.set_user_perm(admin, bob["id"], 2)
    p = svc.perms_of(users_repo.get(bob["id"]))
    assert p["use"] and p["create"] and not p["manage"]
    assert not svc.perms_of(users_repo.get(eve["id"]))["use"]
    with pytest.raises(ChatError):
        svc.set_user_perm(admin, bob["id"], 5)
    with pytest.raises(ChatError):
        svc.set_user_perm(admin, admin["id"], 1)


def test_permitted_user_creates_public_unpacked_and_cannot_manage(people):
    admin, bob, eve = people
    bob = users_repo.get(bob["id"])
    pid = svc.create_pack(admin, "Yopiq to'plam", False)
    r = svc.create(bob, _png_alpha(), "bob_emoji", pack_id=pid, public=False)
    row = repo.get(r["id"])
    assert row["pack_id"] is None and row["public"] == 1 and row["created_by"] == bob["id"]
    with pytest.raises(ChatError):
        svc.edit(bob, r["id"], anim="pulse", pack_id=None, public=True)
    with pytest.raises(ChatError):
        svc.create_pack(bob, "Mening", True)
    with pytest.raises(ChatError):
        svc.delete(users_repo.get(eve["id"]), r["id"])
    assert "user_perms" not in svc.catalog(bob)
    svc.delete(bob, r["id"])
    assert repo.get(r["id"]) is None and not (settings.emoji_dir / row["file"]).exists()


def test_closing_pack_closes_its_emojis_and_delete_pack_keeps_them(people):
    admin, _, _ = people
    pid = svc.create_pack(admin, "Vaqtincha", True)
    r = svc.create(admin, _png_alpha(), "vaqtinchalik", pack_id=pid)
    svc.edit_pack(admin, pid, "Vaqtincha", False)
    assert repo.get(r["id"])["public"] == 0
    svc.delete_pack(admin, pid)
    assert repo.get(r["id"])["pack_id"] is None


def test_delete_removes_file_and_token(people):
    admin, _, _ = people
    r = svc.create(admin, _gif(), "harakat")
    row = repo.get(r["id"])
    assert row["animated"] == 1 and row["anim"] is None
    svc.delete(admin, r["id"])
    assert not (settings.emoji_dir / row["file"]).exists() and not emojis.is_token(":harakat:")
