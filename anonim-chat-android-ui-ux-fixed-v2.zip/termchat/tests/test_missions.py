import os
import sys
import tempfile
import time
import unittest
from pathlib import Path

os.environ.setdefault("TERMCHAT_DATA_DIR", tempfile.mkdtemp(prefix="termchat-mis-"))
os.environ.setdefault("TERMCHAT_REQUIRE_E2EE", "0")
os.environ.setdefault("TERMCHAT_ADMIN_PASSWORD", "owner-pass-1")
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.db import db
from app.errors import ChatError
from app.repositories import users
from app.repositories import missions as repo
from app.services import auth, bootstrap, missions, profiles

# Morphy — Gersog "Opera" o'yini: oq 17-yurishda matt qo'yadi (17 ta oq yurish)
OPERA = ("e2e4 e7e5 g1f3 d7d6 d2d4 c8g4 d4e5 g4f3 d1f3 d6e5 f1c4 g8f6 f3b3 d8e7 b1c3 c7c6 c1g5 b7b5 c3b5 c6b5 c4b5 "
         "b8d7 e1c1 a8d8 d1d7 d8d7 h1d1 e7e6 b5d7 f6d7 b3b8 d7b8 d1d8").split()
FULL_ITEMS = [{"slot": "frame", "value": "x_neon"}, {"slot": "banner", "value": "x_nebula"}, {"slot": "color", "value": "#ff3df0"},
              {"slot": "nick", "value": "x_neon"}, {"slot": "bio", "value": "x_lava"}, {"slot": "msg", "value": "x_glow"},
              {"slot": "avatar", "value": "x_pulse"}, {"slot": "badge", "value": "🏆", "anim": "glow"}]


def _user(name):
    _, u = auth.register(name, name.title(), "secret12")
    return users.get(u["id"])


def _aged_ticket(user, level=3, side="w", secs=600):
    tok = missions.start_game(user, "chess", level, side)["token"]
    db.run("UPDATE mission_games SET started_at=? WHERE token=?", (time.time() - secs, tok))
    return tok


class MissionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        bootstrap.ensure_owner()
        cls.admin = users.get(users.get_by_username("asura")["id"])
        cls.pack = missions.pack_save(cls.admin, None, "Neon to'plam", "✨", "Sinov", FULL_ITEMS)
        cls.reward = missions.reward_save(None, "chess", "5 ochko to'plang", 5, cls.pack["id"])

    def test_default_points_and_admin_override(self):
        pts = {r["rule"]: r["points"] for r in missions.rules_of("chess")}
        self.assertEqual((pts["bot_3"], pts["bot_4"], pts["bot_5"]), (5, 10, 25))
        self.assertEqual(pts["bot_1"], 0)

    def test_full_flow_grant_equip_unequip(self):
        u = _user("mis_flow")
        res = missions.submit_chess(u, _aged_ticket(u, 3), OPERA, 0, 0)
        self.assertTrue(res["counted"])
        self.assertEqual((res["gained"], res["total"]), (5, 5))
        self.assertEqual(len(res["granted"]), 1)
        inv = missions.inventory(u["id"])["items"]
        self.assertEqual(len(inv), len(FULL_ITEMS))
        self.assertFalse(any(i["on"] for i in inv))
        for it in inv:
            missions.equip(u, it["id"])
        row = users.get(u["id"])
        self.assertEqual((row["frame"], row["banner"], row["color"]), ("x_neon", "x_nebula", "#ff3df0"))
        self.assertEqual((row["badge"], row["badge_anim"]), ("🏆", "glow"))
        self.assertEqual(profiles.fxstyle.parse(row["fx"]), {"nick": "x_neon", "bio": "x_lava", "msg": "x_glow", "avatar": "x_pulse"})
        self.assertTrue(all(i["on"] for i in missions.inventory(u["id"])["items"]))
        for it in inv:
            missions.unequip(u, it["id"])
        row = users.get(u["id"])
        self.assertEqual((row["frame"], row["banner"], row["color"], row["badge"], row["fx"]), (None, None, None, None, None))
        after = missions.inventory(u["id"])["items"]
        self.assertEqual(len(after), len(FULL_ITEMS))
        self.assertFalse(any(i["on"] for i in after))
        # ikkinchi g'alaba mukofotni qayta bermaydi
        res2 = missions.submit_chess(u, _aged_ticket(u, 4), OPERA, 0, 0)
        self.assertEqual((res2["gained"], res2["total"], res2["granted"]), (10, 15, []))
        self.assertEqual(len(missions.inventory(u["id"])["items"]), len(FULL_ITEMS))

    def test_ticket_single_use_and_ownership(self):
        a, b = _user("mis_a"), _user("mis_b")
        tok = _aged_ticket(a)
        with self.assertRaises(ChatError):
            missions.submit_chess(b, tok, OPERA, 0, 0)
        self.assertTrue(missions.submit_chess(a, tok, OPERA, 0, 0)["counted"])
        with self.assertRaises(ChatError):
            missions.submit_chess(a, tok, OPERA, 0, 0)
        with self.assertRaises(ChatError):
            missions.submit_chess(a, "yo'q-token", OPERA, 0, 0)

    def test_rejects_fake_records(self):
        u = _user("mis_fake")
        with self.assertRaises(ChatError):   # qora tomon bilan oq matt qo'ygan o'yin
            missions.submit_chess(u, _aged_ticket(u, 3, "b"), OPERA, 0, 0)
        with self.assertRaises(ChatError):   # noqonuniy yurish
            missions.submit_chess(u, _aged_ticket(u), ["e2e5", "e7e5"], 0, 0)
        with self.assertRaises(ChatError):   # matt bilan tugamagan
            missions.submit_chess(u, _aged_ticket(u), OPERA[:-1], 0, 0)
        with self.assertRaises(ChatError):   # matt dan keyin yurish
            missions.submit_chess(u, _aged_ticket(u), OPERA + ["a2a3"], 0, 0)
        fool = ["f2f3", "e7e5", "g2g4", "d8h4"]
        with self.assertRaises(ChatError):   # qora g'alaba qilgan (foydalanuvchi oq)
            missions.submit_chess(u, _aged_ticket(u, 3, "w"), fool, 0, 0)
        short = missions.submit_chess(u, _aged_ticket(u, 3, "b"), fool, 0, 0)
        self.assertFalse(short["counted"])   # to'g'ri tomon, lekin juda qisqa
        self.assertEqual(missions.repo.points(u["id"], "chess"), 0)

    def test_too_fast_and_strict_mode(self):
        u = _user("mis_fast")
        fast = missions.start_game(u, "chess", 3, "w")["token"]
        self.assertFalse(missions.submit_chess(u, fast, OPERA, 0, 0)["counted"])
        self.assertFalse(missions.submit_chess(u, _aged_ticket(u), OPERA, 2, 0)["counted"])
        self.assertFalse(missions.submit_chess(u, _aged_ticket(u), OPERA, 0, 1)["counted"])
        missions.set_strict(False)
        try:
            self.assertTrue(missions.submit_chess(u, _aged_ticket(u), OPERA, 3, 1)["counted"])
        finally:
            missions.set_strict(True)

    def test_zero_point_level_and_daily_cap(self):
        u = _user("mis_cap")
        self.assertFalse(missions.submit_chess(u, _aged_ticket(u, 1), OPERA, 0, 0)["counted"])
        missions.rule_set("chess", "bot_5", 25, 2)
        try:
            ok = [missions.submit_chess(u, _aged_ticket(u, 5), OPERA, 0, 0)["counted"] for _ in range(3)]
            self.assertEqual(ok, [True, True, False])
        finally:
            missions.rule_set("chess", "bot_5", 25, 0)

    def test_premium_not_selectable_for_free(self):
        u = _user("mis_free")
        with self.assertRaises(ChatError):
            profiles.update(u, u["id"], frame="x_neon")
        with self.assertRaises(ChatError):
            profiles.update(u, u["id"], banner="x_nebula")
        with self.assertRaises(ChatError):
            profiles.update(u, u["id"], fx={"nick": "x_neon"})
        with self.assertRaises(ChatError):
            profiles.update(u, u["id"], fx={"msg": "x_glow"})
        with self.assertRaises(ChatError):
            profiles.update(u, u["id"], color="#ff3df0")

    def test_cannot_equip_foreign_item_and_badge_guard(self):
        a, b = _user("mis_o1"), _user("mis_o2")
        missions.submit_chess(a, _aged_ticket(a), OPERA, 0, 0)
        iid = missions.inventory(a["id"])["items"][0]["id"]
        with self.assertRaises(ChatError):
            missions.equip(b, iid)
        badge = next(i for i in missions.inventory(a["id"])["items"] if i["slot"] == "badge")
        users.set_badge(a["id"], "check", None)
        with self.assertRaises(ChatError):
            missions.equip(a, badge["id"])

    def test_admin_validation(self):
        bad = [
            [{"slot": "frame", "value": "gold"}],              # oddiy ramka — maxsus emas
            [{"slot": "wings", "value": "x"}],
            [{"slot": "color", "value": "red"}],
            [{"slot": "badge", "value": "not-an-emoji"}],
            [{"slot": "badge", "value": "check"}],
            [],
        ]
        for items in bad:
            with self.assertRaises(ChatError):
                missions.pack_save(self.admin, None, "x", "🎁", "", items)
        with self.assertRaises(ChatError):
            missions.reward_save(None, "chess", "x", 0, self.pack["id"])
        with self.assertRaises(ChatError):
            missions.reward_save(None, "chess", "x", 5, 99999)
        with self.assertRaises(ChatError):
            missions.rule_set("chess", "bot_9", 5, 0)

    def test_deleting_pack_keeps_granted_items(self):
        u = _user("mis_del")
        p = missions.pack_save(self.admin, None, "Vaqtincha", "🎁", "", [{"slot": "frame", "value": "x_royal"}])
        r = missions.reward_save(None, "chess", "Vaqtincha missiya", 1, p["id"])
        missions.submit_chess(u, _aged_ticket(u), OPERA, 0, 0)
        self.assertIn("x_royal", [i["value"] for i in missions.inventory(u["id"])["items"]])
        missions.pack_remove(p["id"])
        self.assertIn("x_royal", [i["value"] for i in missions.inventory(u["id"])["items"]])
        self.assertIsNone(repo.reward_get(r["id"]))


if __name__ == "__main__":
    unittest.main()
