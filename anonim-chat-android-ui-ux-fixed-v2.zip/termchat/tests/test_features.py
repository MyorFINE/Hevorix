"""Yangi imkoniyatlar testlari (FastAPI'siz): sessiya IP'si faqat egasiga, qurilmaga bog'lash, username almashtirish,
rezerv usernamelar, «Yangi» belgisi, pin va IP yorlig'i."""
import os
import secrets
import sys
import tempfile
import unittest
from pathlib import Path

os.environ.setdefault("TERMCHAT_DATA_DIR", tempfile.mkdtemp(prefix="termchat-feat-"))
os.environ.setdefault("TERMCHAT_REQUIRE_E2EE", "0")
os.environ.setdefault("TERMCHAT_MASTER_KEY", "x" * 32)
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

CHROME_WIN = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"
SAFARI_IOS = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1"


def mk(prefix="f"):
    from app.repositories import users
    from app.services import auth
    name = f"{prefix}{secrets.token_hex(3)}"
    tok, _ = auth.register(name, name.upper(), "parol123", ua=CHROME_WIN, ip="203.0.113.7")
    return users.get_by_username(name), tok


class SessionPrivacyTests(unittest.TestCase):
    def test_ip_only_in_owner_listing_and_encrypted_at_rest(self):
        from app.db import db
        from app.services import auth
        u, tok = mk()
        row = auth.list_sessions(u, tok)[0]
        self.assertEqual(row["ip"], "203.0.113.7")
        raw = db.one("SELECT ip_enc FROM sessions WHERE user_id=?", (u["id"],))["ip_enc"]
        self.assertNotIn("203.0.113.7", raw)                       # bazada ochiq yozilmaydi

    def test_online_time_and_new_device_info(self):
        from app.services import auth
        u, t1 = mk()
        self.assertIsNone(auth.new_device_info(u["id"], t1))       # birinchi qurilma: bildirish yo'q
        t2, _ = auth.login(u["username"], "parol123", ua=SAFARI_IOS, ip="198.51.100.9")
        info = auth.new_device_info(u["id"], t2)
        self.assertTrue(info and "iPhone" in info["device"] or info and info["device"])
        rows = auth.list_sessions(u, t2)
        self.assertEqual(len(rows), 2)
        self.assertTrue(all("online" in r for r in rows))

    def test_token_from_other_device_is_revoked(self):
        from app.services import auth
        u, tok = mk()
        self.assertIsNotNone(auth.authenticate(tok, ua=CHROME_WIN))
        self.assertIsNone(auth.authenticate(tok, ua=SAFARI_IOS))   # o'g'irlangan token boshqa qurilmada
        self.assertIsNone(auth.authenticate(tok, ua=CHROME_WIN))   # sessiya butunlay yo'q qilingan

    def test_browser_update_keeps_session(self):
        from app.services import auth
        u, tok = mk()
        newer = CHROME_WIN.replace("Chrome/120.0", "Chrome/131.0")
        self.assertIsNotNone(auth.authenticate(tok, ua=newer))


class IpRefTests(unittest.TestCase):
    def test_ref_is_stable_hidden_and_resolvable(self):
        from app.features.privacy import ipref
        from app.services import activity
        u, _ = mk("r")
        activity.record("login", ip="192.0.2.55", user=u)
        ipref.forget()
        r = ipref.ref("192.0.2.55")
        self.assertTrue(ipref.is_ref(r)); self.assertNotIn("192.0.2.55", r)
        self.assertEqual(ipref.ref("192.0.2.55"), r)
        self.assertEqual(ipref.resolve(r), "192.0.2.55")
        self.assertEqual(ipref.resolve("IP-0000000000"), "")
        self.assertNotIn("192.0.2.55", ipref.mask_text("blok 192.0.2.55 qilindi"))


class UsernameTests(unittest.TestCase):
    def test_change_frees_old_name_and_blocks_taken_and_reserved(self):
        from app.errors import ChatError
        from app.features.authentication import username as un
        from app.repositories import users
        a, _ = mk("ua"); b, _ = mk("ub")
        new = "n" + secrets.token_hex(4)
        res = un.change_username(a, new, "parol123", None, None, None)
        self.assertEqual(res["username"], new)
        self.assertIsNone(users.get_by_username(a["username"]))    # eski nom bo'sh
        self.assertEqual(users.get_by_username(new)["id"], a["id"])
        with self.assertRaises(ChatError):
            un.change_username(users.get(b["id"]), new, "parol123", None, None, None)      # band
        with self.assertRaises(ChatError):
            un.change_username(users.get(b["id"]), "x" + secrets.token_hex(3), "noto'g'ri", None, None, None)   # parol xato

    def test_only_admin_can_reserve_and_users_cannot_take(self):
        from app.errors import ChatError
        from app.features.authentication import username as un
        from app.services import auth
        from app.repositories import users
        admin = users.get_by_username("hevorix") or None
        a, _ = mk("ur")
        name = "brand" + secrets.token_hex(2)
        un.reserve({"id": a["id"]}, name)
        with self.assertRaises(ChatError):
            auth.register(name, "X", "parol123")
        self.assertTrue(un.is_reserved(name))
        un.release({"id": a["id"]}, name)
        self.assertFalse(un.is_reserved(name))


class NewUserFlagTests(unittest.TestCase):
    def test_admin_controls_flag_and_text(self):
        from app.features.moderation import service as svc
        from app.services import views
        a, _ = mk("nf")
        actor = {"id": a["id"], "role": "owner"}
        self.assertTrue(views.user_view(a["id"])["new"])           # yangi akkaunt
        v = svc.set_user_new(actor, a["id"], "off", "")
        self.assertFalse(v["new"])
        v = svc.set_user_new(actor, a["id"], "on", "Ehtiyot bo'ling")
        self.assertTrue(v["new"]); self.assertEqual(v["new_text"], "Ehtiyot bo'ling")
        svc.set_default_new_text(actor, "Umumiy matn")
        v = svc.set_user_new(actor, a["id"], "on", "")
        self.assertEqual(v["new_text"], "Umumiy matn")
        svc.set_default_new_text(actor, "")

    def test_style_whitelist(self):
        from app.errors import ChatError
        from app.features.moderation import service as svc
        a, _ = mk("st")
        actor = {"id": a["id"], "role": "owner"}
        v = svc.set_style(actor, a["id"], {"frame": "gold", "name_fx": "glow"})
        self.assertEqual(v["style"], {"frame": "gold", "name_fx": "glow"})
        with self.assertRaises(ChatError):
            svc.set_style(actor, a["id"], {"frame": "<script>"})


class PinTests(unittest.TestCase):
    def test_dm_pin_limit_and_group_admin_only(self):
        from app.errors import ChatError
        from app.features.messaging import pins
        from app.repositories import messages, users
        from app.services import chat
        a, _ = mk("pa"); b, _ = mk("pb")
        ids = []
        for i in range(4):
            ids.append(chat.post(users.get(a["id"]), f"salom {i}", to=b["id"])["id"])
        ua = users.get(a["id"])
        for mid in ids[:3]:
            pins.pin(ua, "dm", b["id"], mid)
        with self.assertRaises(ChatError):
            pins.pin(ua, "dm", b["id"], ids[3])                    # 3 tadan ortiq mumkin emas
        scope, cur, _ = pins.unpin(users.get(b["id"]), "dm", a["id"], ids[0])   # ikkala suhbatdosh olib tashlay oladi
        self.assertEqual(len(cur), 2)
        with self.assertRaises(ChatError):
            pins.pin(ua, "group", 0, ids[1])                       # oddiy foydalanuvchi umumiy chatda mahkamlay olmaydi


if __name__ == "__main__":
    unittest.main()
