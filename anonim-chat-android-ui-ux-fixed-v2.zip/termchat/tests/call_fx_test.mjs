// node tests/call_fx_test.mjs — jonli ovoz o'zgartirgich: 440 Hz sinus ~ratio*440 Hz bo'lib chiqishi kerak
import assert from "node:assert/strict";
import fs from "node:fs";
let Cls; globalThis.sampleRate = 48000;
globalThis.AudioWorkletProcessor = class {};
globalThis.registerProcessor = (_, c) => { Cls = c; };
new Function(fs.readFileSync(new URL("../app/static/js/callfx.js", import.meta.url), "utf8"))();   // eslint-disable-line
for (const ratio of [0.74, 0.78, 0.82]) {
  const p = new Cls({processorOptions: {ratio}}), f0 = 440, total = 48000, out = new Float32Array(total);
  for (let off = 0; off < total; off += 128) {
    const inp = new Float32Array(128).map((_, i) => 0.5 * Math.sin(2 * Math.PI * f0 * (off + i) / 48000)), o = new Float32Array(128);
    p.process([[inp]], [[o]]); out.set(o, off);
  }
  let z = 0, prev = out[12000]; const seg = out.subarray(12000, 36000);
  for (let i = 1; i < seg.length; i++) { if (prev < 0 && seg[i] >= 0) z++; prev = seg[i]; }
  const hz = z / (seg.length / 48000), peak = Math.max(...seg.map(Math.abs));
  console.log(`ratio ${ratio}: ${hz.toFixed(0)} Hz (kutilgan ~${(f0 * ratio).toFixed(0)}), amplituda ${peak.toFixed(2)}`);
  assert.ok(Math.abs(hz - f0 * ratio) < 25, "pitch noto'g'ri");
  assert.ok(peak > 0.3 && peak < 0.7, "amplituda barqaror emas");
}
console.log("ovoz o'zgartirgich OK");
