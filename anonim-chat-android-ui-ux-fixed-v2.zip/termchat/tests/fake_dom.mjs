// Soxta DOM (Node uchun): interfeys modullarini brauzersiz sinash.
import fs from "node:fs"; import vm from "node:vm";
export function setup() {
  class Node_ { constructor(t) { this.nodeType = t; this.parentNode = null; } }
  class Text_ extends Node_ { constructor(s) { super(3); this.data = s; } get textContent() { return this.data; } }
  class El extends Node_ {
    constructor(tag) { super(1); this.tag = tag; this.children = []; this.attrs = {}; this.listeners = {}; this.dataset = {}; this.style = {}; this._cls = new Set(); this.scrollLeft = 0; this.offsetLeft = 0; this.offsetWidth = 0; this.clientWidth = 0; this.disabled = false;
      const self = this; this.classList = {add: (...c) => c.forEach(x => self._cls.add(x)), remove: (...c) => c.forEach(x => self._cls.delete(x)), contains: c => self._cls.has(c),
        toggle: (c, f) => { const on = f === undefined ? !self._cls.has(c) : !!f; on ? self._cls.add(c) : self._cls.delete(c); return on; }}; }
    set className(v) { this._cls = new Set(String(v).split(/\s+/).filter(Boolean)); } get className() { return [...this._cls].join(" "); }
    setAttribute(k, v) { this.attrs[k] = v; } addEventListener(t, f) { (this.listeners[t] = this.listeners[t] || []).push(f); }
    append(...k) { for (let c of k) { if (typeof c === "string") { c = new Text_(c); } c.parentNode = this; this.children.push(c); } }
    remove() { if (this.parentNode) { this.parentNode.children = this.parentNode.children.filter(c => c !== this); this.parentNode = null; } }
    get isConnected() { let n = this; while (n.parentNode) n = n.parentNode; return n === document.body; }
    set textContent(v) { this.children.forEach(c => c.parentNode = null); this.children = []; if (v) this.append(new Text_(String(v))); }
    get textContent() { return this.children.map(c => c.textContent).join(""); }
    getBoundingClientRect() { return {left: 0, top: 0, width: 800, height: 800}; }
    setPointerCapture() {} querySelectorAll() { return []; }
  }
  const document = {body: new El("body"), createElement: t => new El(t), createTextNode: s => new Text_(s), querySelectorAll: () => []};
  document.body.parentNode = null;
  const store = {};
  Object.assign(globalThis, {document, window: globalThis, self: globalThis, requestAnimationFrame: f => setTimeout(() => f(performance.now()), 5),
    localStorage: {getItem: k => (k in store ? store[k] : null), setItem: (k, v) => { store[k] = String(v); }, removeItem: k => { delete store[k]; }}});
  const toasts = []; const began = [];
  globalThis.Missions = {begin: async (lv, side, game) => { began.push([lv, side, game]); return "tok123"; }, submit() {}, open() {}};
  Object.assign(globalThis, {
    S: {me: {id: 1}, members: [], offline: true, tab: "x", users: new Map()}, NAV_CLOSE: {}, navPush() {}, navPop() {}, haptic() {}, renderList() {}, wsTry: () => true,
    toast: (t) => toasts.push(t), confirmDlg: async () => true, isOnline: () => false, U: id => ({id, nickname: "Men", username: "men"}), avatar: () => new El("div"), nameEl: () => new El("span"), api: async () => ({}),
    Gaming: {snd: new Proxy({}, {get: () => () => {}}), sndOn: () => true},
    h(tag, props, ...kids) {
      const e = new El(tag);
      if (props) for (const [k, v] of Object.entries(props)) { if (v == null || v === false) continue; if (k === "class") e.className = v; else if (k === "text") e.textContent = v; else if (k.startsWith("on")) e.addEventListener(k.slice(2), v); else e.setAttribute(k, v === true ? "" : v); }
      for (const c of kids.flat()) { if (c == null || c === false) continue; e.append(c.nodeType ? c : String(c)); }
      return e;
    }});

  return {document, store, toasts, began};
}
export const load = (rel, name) => vm.runInThisContext(fs.readFileSync(new URL(rel, import.meta.url), "utf8") + (name ? "\nglobalThis." + name + " = " + name + ";" : ""));
