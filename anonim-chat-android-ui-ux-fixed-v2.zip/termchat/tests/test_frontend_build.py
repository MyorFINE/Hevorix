"""Frontend yig'ish: manba (frontend/) va yetkazib beriladigan fayllar (app/static/) doim mos bo'lishi shart. FastAPI kerak emas.
Ishga tushirish: python -m unittest tests.test_frontend_build -v"""
import subprocess
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "tools"))
import build_frontend as B  # noqa: E402


class FrontendBuildTests(unittest.TestCase):
    def test_built_files_match_sources(self):
        self.assertEqual(B.main(["--check"]), 0, "python tools/build_frontend.py ishga tushiring")

    def test_every_js_module_is_listed_and_parses(self):
        folder = ROOT / "frontend" / "js" / "app"
        listed = {p.name for p in B._read_order(folder)}
        self.assertEqual(listed, {p.name for p in folder.glob("*.js")}, "_order.txt va papka mos emas")
        for name in sorted(listed):
            if name in {"00-head.js", "25-tail.js", "26-marquee.js"}:
                continue
            src = "(()=>{\n" + B._read(folder / name) + "\n})();\n"
            r = subprocess.run(["node", "--check", "-"], input=src, text=True, capture_output=True)
            self.assertEqual(r.returncode, 0, name + ": " + r.stderr[:300])

    def test_every_css_part_is_listed(self):
        folder = ROOT / "frontend" / "css"
        self.assertEqual({p.name for p in B._read_order(folder)}, {p.name for p in folder.glob("*.css")})

    def test_minifier_keeps_meaning(self):
        self.assertEqual(B.min_selector("a  >  b ,  c d"), "a>b,c d")                      # tushuntiruvchi probel saqlanadi
        self.assertIn("2n + 1", B.min_selector("li:nth-child(2n + 1)"))                    # qavs ichidagi + tegilmaydi
        self.assertEqual(B.min_body(" color : red ;  margin: 0 auto ; "), "color:red;margin:0 auto")
        self.assertEqual(B.min_value("calc( 100% - 8px )"), "calc(100% - 8px)")           # calc ichidagi operator probellari kerak
        self.assertEqual(B.min_value("rgba(0, 0, 0, .3) !important"), "rgba(0,0,0,.3)!important")
        self.assertEqual(B.min_prelude("@media (max-width: 760px)  and  (pointer: coarse)"), "@media (max-width:760px) and (pointer:coarse)")
        self.assertEqual(B.min_body('content: "a;  b"'), 'content:"a;  b"')                # satr ichi tegilmaydi

    def test_parse_roundtrip_is_stable(self):
        css, _ = B.build_css(True, True)
        again = B.emit(B.parse(css), True)
        self.assertEqual(again.strip(), css.split("*/\n", 1)[1].strip(), "minify idempotent bo'lishi kerak")


if __name__ == "__main__":
    unittest.main()
