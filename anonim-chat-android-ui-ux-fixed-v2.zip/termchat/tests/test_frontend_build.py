import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def test_frontend_sources_match_built_files():
    r = subprocess.run([sys.executable, str(ROOT / "tools" / "build_frontend.py"), "--check"], capture_output=True, text=True)
    assert r.returncode == 0, r.stdout + r.stderr
