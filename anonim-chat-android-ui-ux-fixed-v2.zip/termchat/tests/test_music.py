import pytest

from app.errors import ChatError
from app.repositories import users
from app.services import music

MP3 = b"ID3\x03\x00\x00\x00\x00\x00\x00" + b"\x00" * 300


def _user(name, role="user"):
    return users.get(users.create(name, name, "x", role, 1.0))


def test_limit_default_and_admin_extend():
    u, adm = _user("mus_a"), _user("mus_adm", "admin")
    for i in range(3):
        music.upload(u, MP3, f"s{i}", "a", 10, "a.mp3")
    with pytest.raises(ChatError):
        music.upload(u, MP3, "x", "a", 10, "a.mp3")
    music.set_limit(adm, u["id"], 5)
    music.upload(u, MP3, "x", "a", 10, "a.mp3")
    assert music.listing(u["id"])["limit"] == 5
    with pytest.raises(ChatError):
        music.set_limit(u, u["id"], 99)


def test_rejects_non_audio_and_foreign_delete():
    u, o = _user("mus_b"), _user("mus_c")
    with pytest.raises(ChatError):
        music.upload(u, b"not audio at all", "x", "", 1, "x.mp3")
    t = music.upload(u, MP3, "", "", 0, "Song.mp3")
    assert t["title"] == "Song"
    with pytest.raises(ChatError):
        music.remove(o, t["id"])
    music.remove(u, t["id"])
