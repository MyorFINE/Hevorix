// Node: richtext.js DOM yasash (minimal soxta DOM bilan) — innerHTML ishlatilmasligi va matn xavfsizligini tekshiradi.
import {createRequire} from "node:module";
import assert from "node:assert/strict";
class Node_ { constructor(t) { this.tag = t; this.children = []; this.attrs = {}; this.style = {setProperty() {}}; this.dataset = {}; this.listeners = {}; this._text = ""; this.classList = {add() {}, remove() {}}; }
  set className(v) { this.cls = v; } get className() { return this.cls || ""; }
  set textContent(v) { this._text = String(v); this.children = []; } get textContent() { return this._text + this.children.map(c => c.textContent).join(""); }
  append(...k) { for (const c of k) this.children.push(typeof c === "string" ? {textContent: c, text: true} : c); }
  setAttribute(k, v) { this.attrs[k] = v; } addEventListener(e, f) { (this.listeners[e] = this.listeners[e] || []).push(f); }
  get innerHTML() { throw new Error("innerHTML ishlatilmasligi kerak"); } set innerHTML(v) { throw new Error("innerHTML ishlatilmasligi kerak"); }
  get offsetWidth() { return 1; } get children_() { return this.children; } replaceWith() {} }
Object.defineProperty(Node_.prototype, "children", {get() { return this._c || (this._c = []); }, set(v) { this._c = v; }});
globalThis.document = {createElement: t => new Node_(t), createElementNS: (n, t) => new Node_(t), createTextNode: t => ({textContent: String(t), text: true})};
const R = createRequire(import.meta.url)("../app/static/js/richtext.js");
const all = (n, out = []) => { out.push(n); (n._c || []).forEach(c => all(c, out)); return out; };

const evil = '```html\n<img src=x onerror=alert(1)><script>alert(1)</script>\n```';
const p = R.parse(evil)[0];
const dom = R.render(p, {user: "x", copy: async () => true});
assert.ok(dom.textContent.includes("<script>alert(1)</script>"), "kod matn sifatida ko'rinishi kerak");
assert.ok(all(dom).every(n => n.tag !== "script" && n.tag !== "img"), "tegli element yaratilmasligi kerak");

const t = R.render(R.parse("┌──(kali㉿kali)-[~]\n└─$ nmap -sV 10.0.0.1 | grep open > out.txt")[0], {user: "ali<b>", fx: true, copy: async () => true});
const txt = t.textContent;
assert.ok(txt.includes("nmap -sV 10.0.0.1 | grep open > out.txt"));
assert.ok(txt.includes("┌──(alib㉿kali)-[~]"), "foydalanuvchi nomi tozalanishi kerak: " + txt);
assert.ok(!txt.includes("<b>"));

console.log("richtext DOM: OK");
