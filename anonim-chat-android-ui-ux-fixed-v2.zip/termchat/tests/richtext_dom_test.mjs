// Node: richtext.js DOM yasash (minimal soxta DOM bilan) — innerHTML ishlatilmasligi va matn xavfsizligini tekshiradi.
import {createRequire} from "node:module";
import assert from "node:assert/strict";
class Node_ { constructor(t) { this.tag = t; this.children = []; this.attrs = {}; this.style = {setProperty() {}}; this.dataset = {}; this.listeners = {}; this._text = ""; this.classList = {add() {}, remove() {}}; }
  set className(v) { this.cls = v; } get className() { return this.cls || ""; }
  set textContent(v) { this._text = String(v); this.children = []; } get textContent() { return this._text + this.children.map(c => c.textContent).join(""); }
  append(...k) { for (const c of k) this.children.push(typeof c === "string" ? {textContent: c, text: true} : c); }
  setAttribute(k, v) { this.attrs[k] = v; } addEventListener(e, f) { (this.listeners[e] = this.listeners[e] || []).push(f); }
  get innerHTML() { throw new Error("innerHTML ishlatilmasligi kerak"); } set innerHTML(v) { throw new Error("innerHTML ishlatilmasligi kerak"); }
  get offsetWidth() { return 1; } get children_() { return this.children; } replaceWith() {} }
Object.defineProperty(Node_.prototype, "children", {get() { return this._c || (this._c = []); }, set(v) { this._c = v; }});
globalThis.document = {createElement: t => new Node_(t), createElementNS: (n, t) => new Node_(t), createTextNode: t => ({textContent: String(t), text: true}), createDocumentFragment: () => new Node_("#frag")};
const R = createRequire(import.meta.url)("../app/static/js/richtext.js");
const all = (n, out = []) => { out.push(n); (n._c || []).forEach(c => all(c, out)); return out; };

const evil = '```html\n<img src=x onerror=alert(1)><script>alert(1)</script>\n```';
const p = R.parse(evil)[0];
const dom = R.render(p, {user: "x", copy: async () => true});
assert.ok(dom.textContent.includes("<script>alert(1)</script>"), "kod matn sifatida ko'rinishi kerak");
assert.ok(all(dom).every(n => n.tag !== "script" && n.tag !== "img"), "tegli element yaratilmasligi kerak");

const t = R.render(R.parse("┌──(kali㉿kali)-[~]\n└─$ nmap -sV 10.0.0.1 | grep open > out.txt")[0], {user: "ali<b>", fx: true, copy: async () => true});
const txt = t.textContent;
assert.ok(txt.includes("nmap -sV 10.0.0.1 | grep open > out.txt"));
assert.ok(txt.includes("┌──(alib㉿kali)-[~]"), "foydalanuvchi nomi tozalanishi kerak: " + txt);
assert.ok(!txt.includes("<b>"));

// xabar ichidagi emojilar: faqat bizning `/emoji-files/` rasmi yaratiladi, qolgan hammasi oddiy matn bo'lib qoladi (XSS yo'q)
R.setEmojis([{token: ":kulgi_1:", url: "/emoji-files/0123456789abcdef0123.png", label: "kulgi", anim: "bounce"}], true);
const frag = R.inline('<img src=x onerror=alert(1)> :kulgi_1: va <script>alert(2)</script> :yoq_emoji:');
const nodes = all(frag);
const imgs = nodes.filter(n => n.tag === "img");
assert.equal(imgs.length, 1, "faqat bitta emoji rasmi bo'lishi kerak");
assert.equal(imgs[0].src, "/emoji-files/0123456789abcdef0123.png");
assert.ok(imgs[0].className.includes("ce") && imgs[0].className.includes("a-bounce") && !imgs[0].className.includes("big"));
assert.ok(frag.textContent.includes("<img src=x onerror=alert(1)>") && frag.textContent.includes("<script>alert(2)</script>") && frag.textContent.includes(":yoq_emoji:"));
assert.ok(nodes.every(n => n.tag !== "script"), "script elementi yaratilmasligi kerak");
assert.ok(R.inline(":kulgi_1: :kulgi_1:").children.filter(c => c.tag === "img").every(i => i.className.includes("big")), "faqat emoji bo'lsa katta chiqadi");

console.log("richtext DOM: OK");

// ---- chatlar ro'yxati: «:kod:» emoji rasmga aylanadi (kichik, animatsiyasiz), oddiy matn o'zgarmaydi
R.setEmojis([{token: ":005:", url: "/static/emoji/005.png", label: "x", anim: "bounce"}], true);
const pv = R.preview("salom :005: dunyo :yoq:");
const kids = pv._c;
assert.equal(kids.length, 3, "matn + rasm + matn (ro'yxatda yo'q :yoq: kodi matnligicha qoladi)");
assert.equal(kids[1].tag, "img");
assert.equal(kids[1].className, "ce pv", "ro'yxatda katta emas va animatsiyasiz");
assert.equal(kids[0].textContent + kids[2].textContent, "salom  dunyo :yoq:");
assert.ok(R.hasInlineEmoji("Siz :005:") && !R.hasInlineEmoji("oddiy matn"));
console.log("PREVIEW OK");
