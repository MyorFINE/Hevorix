const {chromium}=require('playwright');
(async()=>{
 const b=await chromium.launch({executablePath:process.env.CHROME,args:['--no-sandbox']});
 const ctx=await b.newContext({viewport:{width:390,height:760},hasTouch:false});
 const page=await ctx.newPage(); const errs=[];
 page.on('pageerror',e=>errs.push('PAGEERR '+e.message)); page.on('console',m=>{if(m.type()==='error'&&!/404|Failed to load resource/.test(m.text()))errs.push('CONSOLE '+m.text())});
 await page.goto('http://localhost:8765/'); await page.waitForTimeout(800); await page.evaluate(()=>{const e=document.getElementById('installSheet'); if(e) e.remove();});
 console.log('TCChess', await page.evaluate(()=>!!window.TCChess));
 await page.click('#offChessAuth'); await page.waitForSelector('#ocx .oc-menu');
 await page.screenshot({path:'lobby.png'});
 await page.click('.oc-lvb:nth-child(2)'); await page.click('.gm-sd:nth-child(1)'); await page.click('.oc-go');
 await page.waitForSelector('.oc-board');
 const sq=async(n)=>{const r=await page.evaluate((n)=>{const b=document.querySelector('.oc-board').getBoundingClientRect();const f=n.charCodeAt(0)-97,rk=+n[1]-1;return {x:b.left+(f+.5)*b.width/8,y:b.top+(7-rk+.5)*b.height/8}},n);return r};
 const click=async n=>{const p=await sq(n);await page.mouse.click(p.x,p.y)};
 await click('e2'); await click('e4'); 
 await page.waitForFunction(()=>document.querySelectorAll('.oc-board .gm-hm').length>=0);
 await page.waitForFunction(()=>document.querySelectorAll('#ocx .gm-hm').length>=2,null,{timeout:15000});
 console.log('moves in history', await page.evaluate(()=>document.querySelectorAll('#ocx .gm-hm').length));
 console.log('pieces', await page.evaluate(()=>document.querySelectorAll('#ocx .gp').length));
 await page.screenshot({path:'game.png'});
 // hint
 await page.click('.oc-hint'); await page.waitForTimeout(2500); console.log('hint squares', await page.evaluate(()=>document.querySelectorAll('.sq.hint').length));
 // undo
 await page.click('#ocx .gm-act button:nth-child(2)'); await page.waitForTimeout(500);
 console.log('after undo history', await page.evaluate(()=>document.querySelectorAll('#ocx .gm-hm').length));
 // drag move d2d4
 const a=await sq('d2'),c=await sq('d4'); await page.mouse.move(a.x,a.y); await page.mouse.down(); await page.mouse.move(c.x,c.y,{steps:6}); await page.mouse.up();
 await page.waitForFunction(()=>document.querySelectorAll('#ocx .gm-hm').length>=2,null,{timeout:15000});
 console.log('after drag history', await page.evaluate(()=>[...document.querySelectorAll('#ocx .gm-hm span')].map(e=>e.textContent).join(' ')));
 // reload resumes
 await page.reload(); await page.waitForTimeout(600); await page.evaluate(()=>{const e=document.getElementById('installSheet'); if(e) e.remove();}); await page.click('#offChessAuth'); await page.waitForSelector('.oc-board');
 console.log('resumed history', await page.evaluate(()=>document.querySelectorAll('#ocx .gm-hm').length));
 // resign
 await page.click('#ocx .gm-resign'); await page.waitForTimeout(300);
 const ok=await page.$('#dlg button.danger, #dlg .btn:not(.ghost)'); if(ok) await ok.click(); await page.waitForTimeout(600);
 console.log('over card', await page.evaluate(()=>!!document.querySelector('#ocx .go-card')&&document.querySelector('.go-t').textContent));
 await page.screenshot({path:'over.png'});
 console.log('ERRORS', JSON.stringify(errs));
 await b.close();
})().catch(e=>{console.error('FAIL',e);process.exit(1)});
