const {chromium}=require('playwright');
const fs=require('fs');
const FILE=process.env.APPJS||''+require('path').join(__dirname,'../../app/static/js/app.js')+'';
let src=fs.readFileSync(FILE,'utf8');
const mk='/* =====================================================================================\n   OFLAYN SHAXMAT';
const mk2='/* =====================================================================================\n   GAMING';
const marker=src.includes(mk)?mk:mk2; if(!src.includes(marker)) throw new Error('marker');
src=src.replace(marker,'globalThis.__T={S,Off,upsertUser,dmOf};\n'+marker);
(async()=>{
 const b=await chromium.launch({executablePath:process.env.CHROME,args:['--no-sandbox']});
 const ctx=await b.newContext({viewport:{width:1100,height:760}});
 await ctx.route('**/static/js/app.js*',r=>r.fulfill({status:200,contentType:'application/javascript',body:src}));
 const page=await ctx.newPage(); const errs=[];
 page.on('pageerror',e=>errs.push('PAGEERR '+e.message)); page.on('console',m=>{if(m.type()==='error'&&!/404|Failed to load resource/.test(m.text()))errs.push('CONSOLE '+m.text())});
 const load=async()=>{await page.goto('http://localhost:8765/'); await page.waitForTimeout(700); await page.evaluate(()=>document.getElementById('installSheet')?.remove());};
 await load();
 await page.evaluate(async()=>{
  const {S,Off,upsertUser}=__T; const me={id:1,username:'ali',nickname:'Ali'}, bob={id:2,username:'bob',nickname:'Bob'};
  S.me=me; S.token='x'; upsertUser(me); upsertUser(bob); S.members=[me,bob];
  const now=Math.floor(Date.now()/1000);
  S.group.msgs=[{id:1,user:bob,content:'Salom hammaga',ts:now-300},{id:2,user:me,content:'Va alaykum',ts:now-200},{id:3,user:bob,content:'Qalay?',ts:now-100}];
  const d=__T.dmOf(2); d.msgs=[{id:10,user:bob,to:1,content:'lichka xabar',ts:now-50}]; d.loaded=true;
  await Off.arm({user:'ali',password:'x',stay:true}); await Off.save();
 });
 await load();
 console.log('offBtn visible', await page.evaluate(()=>!document.getElementById('offBtn').classList.contains('hidden')));
 await page.click('#offBtn'); await page.waitForTimeout(800);
 const st=()=>page.evaluate(()=>{const c=document.getElementById('composer'),o=document.getElementById('offbar');return {chatCls:document.getElementById('chat').className,composer:getComputedStyle(c).display+' inline='+c.style.display,offbar:getComputedStyle(o).display,body:document.body.className}});
 console.log('t0', JSON.stringify(await st()));
 await page.waitForTimeout(3500);
 console.log('t+3.5s', JSON.stringify(await st()));
 console.log('msgs rendered', await page.evaluate(()=>document.querySelectorAll('#msgs .row').length));
 await page.screenshot({path:'offline.png'});
 // ctx menu
 const bub=await page.$('#msgs .row .bubble'); if(bub){await bub.click({button:'right'}); await page.waitForTimeout(300); console.log('ctx items', await page.evaluate(()=>[...document.querySelectorAll('#ctx .dd-i')].map(e=>e.textContent.trim()))); await page.keyboard.press('Escape'); await page.mouse.click(5,5);}
 // games tab
 await page.click('#gamesTab'); await page.waitForTimeout(300);
 console.log('games tab', await page.evaluate(()=>[...document.querySelectorAll('#list .gcard b, #list .oc-none')].map(e=>e.textContent)));
 await page.click('#chnTab',{timeout:1500}).catch(()=>console.log('channels tab hidden: ok'));
 await page.click('#obChess').catch(e=>console.log('obChess click', e.message.split('\n')[0]));
 await page.waitForTimeout(400);
 console.log('chess opened from offbar', await page.evaluate(()=>!!document.getElementById('ocx')));
 console.log('ERRORS', JSON.stringify(errs));
 await b.close();
})().catch(e=>{console.error('FAIL',e.message.split('\n').slice(0,3).join(' | '));process.exit(1)});
