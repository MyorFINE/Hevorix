import http.server, socketserver, os, sys
import pathlib; ROOT=str(pathlib.Path(__file__).resolve().parents[2]/'app'/'static')
class H(http.server.SimpleHTTPRequestHandler):
    def translate_path(self, path):
        path=path.split('?')[0]
        if path=='/': return ROOT+'/index.html'
        if path.startswith('/static/'): return ROOT+path[7:]
        return '/nonexistent'
    def log_message(self,*a): pass
socketserver.TCPServer.allow_reuse_address=True
socketserver.TCPServer(('127.0.0.1',8765),H).serve_forever()
