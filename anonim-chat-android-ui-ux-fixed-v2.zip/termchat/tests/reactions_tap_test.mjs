// Xabar ustiga bosish mantig'i: 1 marta = menyu, 2 marta = reaksiya (yoqilgan bo'lsa), o'chirilgan bo'lsa darrov menyu.
// Ishga tushirish: node tests/reactions_tap_test.mjs
import fs from "node:fs";
import vm from "node:vm";
import assert from "node:assert/strict";

const src = fs.readFileSync(new URL("../app/static/js/app.js", import.meta.url), "utf8");
const a = src.indexOf("const TAP_SKIP"), b = src.indexOf("\n}\n", src.indexOf("function attachTap")) + 3;   // faqat attachTap oxirigacha
assert.ok(a > 0 && b > a, "attachTap topilmadi");
const sleep = ms => new Promise(r => setTimeout(r, ms));

function setup(prefs) {
  const log = [];
  const ctx = {
    rxPrefs: prefs, S: {sel: null}, canReact: () => true, rxMine: () => null, haptic: () => {},
    reactTo: (m, e) => log.push(["react", e]), rxBurst: () => log.push(["burst"]), openCtx: (x, y) => log.push(["menu", x, y]),
    getSelection: () => ({removeAllRanges() {}, toString: () => ""}), setTimeout, clearTimeout, Date,
    document: {addEventListener() {}, removeEventListener() {}, querySelector: () => null},
    $: () => ({addEventListener() {}, classList: {add() {}, remove() {}, toggle() {}}}),   // kesim ichiga tushgan `$("msgs").addEventListener(...)` uchun
  };
  vm.createContext(ctx);
  vm.runInContext(src.slice(a, b), ctx);
  let handler; const bubble = {addEventListener: (t, f) => { handler = f; }};
  ctx.attachTap(bubble, {id: 1});
  const click = (over = {}) => handler(Object.assign({defaultPrevented: false, target: {closest: () => null}, clientX: 5, clientY: 7}, over));
  return {log, click};
}

// 1) ikki marta bosish yoqilgan: bitta bosish ~280ms dan keyin menyu ochadi
let t = setup({dbl: true, emoji: "❤️"});
t.click(); assert.deepEqual(t.log, []); await sleep(340); assert.deepEqual(t.log, [["menu", 5, 7]]);

// 2) ketma-ket ikki bosish: menyu YO'Q, reaksiya bor
t = setup({dbl: true, emoji: "🔥"});
t.click(); await sleep(120); t.click(); await sleep(400);
assert.deepEqual(t.log, [["burst"], ["react", "🔥"]]);

// 3) sekin ikki bosish (>320ms) — ikkita menyu, reaksiya yo'q
t = setup({dbl: true, emoji: "❤️"});
t.click(); await sleep(360); t.click(); await sleep(360);
assert.equal(t.log.filter(x => x[0] === "react").length, 0);

// 4) ikki marta bosish o'chirilgan: darrov menyu, ikkinchi bosishda reaksiya yo'q
t = setup({dbl: false, emoji: "❤️"});
t.click(); assert.deepEqual(t.log, [["menu", 5, 7]]); t.click(); assert.equal(t.log.filter(x => x[0] === "react").length, 0);

// 5) tugma/rasm/fayl (o'z amali bor) bosilsa — hech narsa bo'lmaydi
t = setup({dbl: true, emoji: "❤️"});
t.click({target: {closest: () => ({})}}); await sleep(340); assert.deepEqual(t.log, []);

// 6) belgilash rejimi yoki uzoq bosishdan keyingi (defaultPrevented) bosish — e'tiborsiz
t = setup({dbl: false, emoji: "❤️"});
t.click({defaultPrevented: true}); assert.deepEqual(t.log, []);
console.log("reactions_tap_test: OK");
