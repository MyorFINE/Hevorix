import asyncio
import json
import os
import random
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

os.environ.setdefault("TERMCHAT_DATA_DIR", tempfile.mkdtemp(prefix="termchat-dk-"))
os.environ.setdefault("TERMCHAT_REQUIRE_E2EE", "0")
os.environ.setdefault("TERMCHAT_ADMIN_PASSWORD", "owner-pass-1")
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app.errors import ChatError
from app.games import durak_engine as de
from app.repositories import users
from app.services import auth


def pick(s, rnd):
    L = s.legal(s.turn)
    if s.turn == s.dfn:
        opts = [{"t": "def", "c": c, "i": i} for c, ix in L["def"].items() for i in ix] + [{"t": "take"}]
    else:
        opts = [{"t": "atk", "c": c} for c in L["cards"]] + ([{"t": "pass"}] if L["pass"] else [])
    return rnd.choice(opts)


class EngineTests(unittest.TestCase):
    def test_deal_trump_and_first_attacker(self):
        for n in (2, 3, 4):
            s = de.State(n, rng=random.Random(n))
            self.assertEqual([len(h) for h in s.hands], [6] * n)
            self.assertEqual(len(s.deck), 36 - 6 * n)
            self.assertEqual(s.trump, s.trump_card[1])
            self.assertEqual(s.dfn, (s.att + 1) % n)
            trumps = [(de.rank(c), i) for i, h in enumerate(s.hands) for c in h if c[1] == s.trump]
            if trumps:
                self.assertEqual(s.att, min(trumps)[1])

    def test_size_limits(self):
        for n in (1, 5):
            with self.assertRaises(ValueError):
                de.State(n)

    def test_beating_rules(self):
        s = de.State(2, rng=random.Random(1))
        t = s.trump
        other = next(x for x in "SHDC" if x != t)
        self.assertTrue(s.beats("6" + other, "7" + other))
        self.assertFalse(s.beats("7" + other, "6" + other))
        self.assertFalse(s.beats("6" + other, "A" + next(x for x in "SHDC" if x not in (t, other))))
        self.assertTrue(s.beats("A" + other, "6" + t))
        self.assertTrue(s.beats("6" + t, "7" + t))
        self.assertFalse(s.beats("7" + t, "A" + other))

    def test_take_and_bito_flow(self):
        s = de.State(2, deck=de.full_deck())
        t = s.trump
        o, x = [q for q in "SHDC" if q != t][:2]
        s.hands = [["6" + o, "7" + o, "8" + o, "9" + o, "6" + x, "JD" if t != "D" else "JC"], ["7" + t, "8" + t, "9" + t, "T" + t, "J" + t, "Q" + t]]
        s.att, s.dfn = 0, 1
        s._start_round()
        s.act(0, {"t": "atk", "c": "6" + o})
        self.assertEqual(s.turn, 1)
        with self.assertRaises(ValueError):
            s.act(0, {"t": "atk", "c": "7" + o})                        # navbat himoyachida
        s.act(1, {"t": "def", "c": "7" + t, "i": 0})                    # boshqa urish imkoni yo'q — kozer bilan
        self.assertEqual(s.turn, 0)                                      # podkidka navbati
        s.act(0, {"t": "atk", "c": "7" + o})
        s.act(1, {"t": "take"})
        self.assertEqual(s.phase, "take")
        self.assertEqual(s.turn, 0)                                      # 6-x hali qo'shib tashlanishi mumkin (6 stolda bor)
        s.act(0, {"t": "atk", "c": "6" + x})
        self.assertEqual(s.turn, 0 if s.throwable(0) else s.turn)
        if s.over is None and s.table:
            s.act(0, {"t": "pass"})
        self.assertEqual(s.table, [])
        self.assertEqual(s.phase, "attack")
        self.assertEqual(s.att, 0)                                       # olgan himoyachi navbatni o'tkazadi
        self.assertEqual(s.dfn, 1)
        self.assertGreaterEqual(len(s.hands[1]), 6)

    def test_random_games_finish_and_conserve_cards(self):
        for n in (2, 3, 4):
            for seed in range(40):
                rnd = random.Random(seed)
                s = de.State(n, rng=rnd)
                steps = 0
                while not s.over:
                    total = len(s.deck) + s.discard + sum(len(h) for h in s.hands) + sum(1 for p in s.table for c in p if c)
                    self.assertEqual(total, 36)
                    s.act(s.turn, pick(s, rnd))
                    steps += 1
                    self.assertLess(steps, 2000)

    @unittest.skipUnless(shutil.which("node"), "node kerak")
    def test_js_engine_replays_python_games_identically(self):
        rows = []
        for n in (2, 3, 4):
            for seed in range(15):
                rnd = random.Random(seed * 5 + n)
                deck = de.full_deck()
                rnd.shuffle(deck)
                s = de.State(n, deck=deck)
                acts, snaps = [], []
                while not s.over:
                    seat, a = s.turn, pick(s, rnd)
                    s.act(seat, a)
                    acts.append([seat, a])
                    snaps.append([s.turn, s.att, s.dfn, s.phase, [sorted(h) for h in s.hands], len(s.deck), s.discard, [list(p) for p in s.table], list(s.out)])
                rows.append({"n": n, "deck": deck, "acts": acts, "snaps": snaps, "loser": s.over["loser"]})
        js = ("const T=require(%s);const rows=JSON.parse(require('fs').readFileSync(0,'utf8'));let bad=0;"
              "for(const r of rows){const s=new T.State(r.n,r.deck);r.acts.forEach(([seat,a],k)=>{s.act(seat,a);const sn=r.snaps[k];"
              "const m=[s.turn,s.att,s.dfn,s.phase,s.hands.map(h=>h.slice().sort()),s.deck.length,s.discard,s.table,s.out];"
              "if(JSON.stringify(m)!==JSON.stringify(sn))bad++;});if((s.over&&s.over.loser)!==r.loser)bad++;}console.log(bad);"
              % json.dumps(str(ROOT / "app/static/js/durak.js")))
        out = subprocess.run(["node", "-e", js], input=json.dumps(rows), capture_output=True, text=True, timeout=120)
        self.assertEqual(out.stdout.strip(), "0", out.stderr)


def _user(name):
    _, u = auth.register(name, name.title(), "secret12")
    return users.get(u["id"])


class ServiceTests(unittest.TestCase):
    def test_table_flow(self):
        from app.services import durak as svc
        a, b, c, d, e = (_user(f"dk_{x}") for x in "abcde")

        async def scenario():
            with self.assertRaises(ChatError):
                await svc.invite(a, b["id"])                          # stol yo'q
            await svc.create(a)
            t = svc._tables[svc._user_table[a["id"]]]
            with self.assertRaises(ChatError):
                await svc.start(a)                                    # 1 kishi
            with self.assertRaises(ChatError):
                await svc.create(a)
            await svc.invite(a, b["id"])
            with self.assertRaises(ChatError):
                await svc.invite(a, b["id"])                          # takroriy taklif
            with self.assertRaises(ChatError):
                await svc.invite(b, c["id"])                          # faqat egasi
            await svc.reply(b, svc._in[b["id"]], True)
            await svc.invite(a, c["id"])
            await svc.reply(c, svc._in[c["id"]], True)
            await svc.invite(a, d["id"])
            await svc.reply(d, svc._in[d["id"]], True)
            with self.assertRaises(ChatError):
                await svc.invite(a, e["id"])                          # 4 tadan ortiq emas
            await svc.start(a)
            self.assertEqual(t.status, "playing")
            self.assertEqual(len(t.st.hands), 4)
            v = svc._view(t, b["id"])
            self.assertEqual(len(v["game"]["hand"]), 6)
            self.assertNotIn("hands", v["game"])
            self.assertEqual(v["me"], t.seats.index(b["id"]))
            # begona yoki noto'g'ri navbatdagi harakat rad etiladi
            who = {u["id"]: u for u in (a, b, c, d)}
            turn_uid = t.seats[t.st.turn]
            other = next(u for u in (a, b, c, d) if u["id"] != turn_uid)
            with self.assertRaises(ChatError):
                await svc.act(other, {"t": "take"})
            att = who[turn_uid]
            card = t.st.hands[t.st.turn][0]
            await svc.act(att, {"t": "atk", "c": card})
            self.assertEqual(len(t.st.table), 1)
            with self.assertRaises(ChatError):
                await svc.act(who[t.seats[t.st.dfn]], {"t": "def", "c": "ZZ", "i": 0})
            # o'yin tugamaguncha chiqib ketgan — durak
            quitter = who[t.seats[t.st.dfn]]
            await svc.leave(quitter)
            self.assertEqual(t.status, "over")
            self.assertEqual(t.result["loser"], quitter["id"])
            self.assertEqual(t.result["reason"], "left")
            self.assertFalse(svc.busy(quitter["id"]))
            # egasi qayta boshlaydi (3 kishi bilan)
            if t.host == quitter["id"]:
                self.fail("egasi chiqmadi")
            await svc.start(who[t.host])
            self.assertEqual(len(t.st.hands), 3)
            self.assertNotIn(quitter["id"], t.seats)
            # egasi chiqsa va o'yin tugasa stol boshqaga o'tadi
            host = t.host
            await svc.leave(who[host])
            self.assertEqual(t.status, "over")
            self.assertNotEqual(t.host, host)
            for u in (a, b, c, d):
                if svc.busy(u["id"]):
                    await svc.leave(u)
            self.assertEqual(svc._tables, {})

        asyncio.run(scenario())

    def test_timeout_makes_player_durak_and_lobby_close(self):
        from app.services import durak as svc
        a, b = _user("dk_f"), _user("dk_g")

        async def scenario():
            await svc.create(a)
            t = svc._tables[svc._user_table[a["id"]]]
            await svc.invite(a, b["id"])
            await svc.reply(b, svc._in[b["id"]], False)               # rad etdi
            self.assertEqual(t.pending(), [])
            await svc.invite(a, b["id"])
            await svc.reply(b, svc._in[b["id"]], True)
            await svc.start(a)
            seat = t.st.turn
            await svc._finish(t, "timeout", t.seats[seat])
            self.assertEqual((t.result["loser"], t.result["reason"], t.result["order"], t.result["rated"]), (t.seats[seat], "timeout", [], False))
            await svc.leave(b)
            await svc.leave(a)
            self.assertEqual(svc._tables, {})
            # lobbida egasi chiqsa stol yopiladi
            await svc.create(a)
            await svc.leave(a)
            self.assertEqual(svc._tables, {})

        asyncio.run(scenario())


class PointsTests(unittest.TestCase):
    def _table(self, svc, names):
        us = [_user(n) for n in names]

        async def mk():
            await svc.create(us[0])
            t = svc._tables[svc._user_table[us[0]["id"]]]
            for u in us[1:]:
                await svc.invite(us[0], u["id"])
                await svc.reply(u, svc._in[u["id"]], True)
            await svc.start(us[0])
            return t
        return us, mk

    def test_two_players_points_and_limits(self):
        from app.repositories import games as repo
        from app.services import durak as svc
        async def scenario():
            us, mk = self._table(svc, ["dk_p1", "dk_p2"])
            t = await mk()
            t.actions = 3                                           # juda qisqa — ochko yo'q
            await svc._finish(t, "left", us[0]["id"])
            self.assertFalse(t.result["rated"])
            self.assertEqual(t.result["pts"][str(us[1]["id"])], 0)
            await svc.start(us[0]) if False else None
            await svc.leave(us[1]); await svc.leave(us[0])
            # uzun o'yin: durak −10 (0 dan pastga tushmaydi), yutgan +10
            us2, mk2 = self._table(svc, ["dk_p3", "dk_p4"])
            t = await mk2()
            t.actions = 30
            await svc._finish(t, "timeout", us2[0]["id"])
            self.assertTrue(t.result["rated"])
            self.assertEqual(t.result["pts"][str(us2[1]["id"])], 10)
            self.assertEqual(t.result["total"][str(us2[1]["id"])], 10)
            self.assertEqual(repo.stats(us2[0]["id"], "durak")["losses"], 1)
            self.assertEqual(repo.stats(us2[1]["id"], "durak")["wins"], 1)
            sb = svc.scoreboard(us2[1])
            self.assertEqual(sb["game"], "durak")
            self.assertEqual(sb["top"][0]["uid"], us2[1]["id"])
            self.assertEqual(sb["me"]["rank"], 1)
            await svc.leave(us2[1]); await svc.leave(us2[0])
        asyncio.run(scenario())

    def test_three_players_by_finish_order_and_draw(self):
        from app.services import durak as svc
        async def scenario():
            us, mk = self._table(svc, ["dk_q1", "dk_q2", "dk_q3"])
            t = await mk()
            t.actions = 40
            ids = [u["id"] for u in us]
            order = [ids[1], ids[2]]                                # 1-o'rin: ids[1], 2-o'rin: ids[2]; durak: ids[0]
            d = svc._deltas(t, ids[0], order)
            self.assertEqual((d[ids[0]], d[ids[1]], d[ids[2]]), (-10, 10, 5))
            d = svc._deltas(t, ids[0], [])                          # hech kim chiqmagan holda taymaut
            self.assertEqual((d[ids[0]], d[ids[1]], d[ids[2]]), (-10, 5, 5))
            d = svc._deltas(t, None, [])
            self.assertEqual(set(d.values()), {0})
            await svc._finish(t, "normal", None)                    # durang
            self.assertEqual(t.result["loser"], None)
            self.assertFalse(t.result["rated"])
            for u in us:
                await svc.leave(u)
        asyncio.run(scenario())


if __name__ == "__main__":
    unittest.main()
