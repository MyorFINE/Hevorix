import asyncio
import json
import os
import random
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

os.environ.setdefault("TERMCHAT_DATA_DIR", tempfile.mkdtemp(prefix="termchat-ck-"))
os.environ.setdefault("TERMCHAT_REQUIRE_E2EE", "0")
os.environ.setdefault("TERMCHAT_ADMIN_PASSWORD", "owner-pass-1")
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app.errors import ChatError
from app.games import checkers_engine as ce
from app.repositories import games as repo
from app.repositories import users
from app.services import auth


def mk(w="", b="", turn="w"):
    q = ce.Position()
    q.b = ["."] * 64
    q.turn = turn
    for s in w.split():
        q.b[ce.idx(s.lstrip("K"))] = "W" if s.startswith("K") else "w"
    for s in b.split():
        q.b[ce.idx(s.lstrip("K"))] = "B" if s.startswith("K") else "b"
    return q


def lm(q):
    return {k: sorted("-".join(x) for x in v) for k, v in q.legal_map().items()}


class EngineTests(unittest.TestCase):
    def test_start_has_seven_moves(self):
        p = ce.Position()
        self.assertEqual(len(p.legal()), 7)
        self.assertEqual(sum(1 for c in p.b if c == "w"), 12)
        self.assertEqual(sum(1 for c in p.b if c == "b"), 12)

    def test_man_captures_backward_and_capture_is_mandatory(self):
        q = mk("c3 h2", "d4 b2")
        self.assertEqual(set(lm(q)), {"c3"})           # h2 ning oddiy yurishi yo'q — urish majburiy
        self.assertEqual(lm(q)["c3"], ["a1", "e5"])

    def test_king_flies_and_must_pick_continuing_square(self):
        self.assertEqual(lm(mk("Ka1", "c3 f6 e7"))["a1"], ["d4-g7", "d4-h8", "e5-g7", "e5-h8"])

    def test_promotion_in_the_middle_of_capture_continues_as_king(self):
        q = mk("c6", "d7 g6")
        self.assertEqual(lm(q), {"c6": ["e8-h5"]})
        info = q.push(["c6", "e8", "h5"])
        self.assertTrue(info["promo"])
        self.assertEqual(q.b[ce.idx("h5")], "W")
        self.assertEqual(q.b[ce.idx("d7")], ".")

    def test_turkish_strike(self):
        self.assertEqual(lm(mk("Ka1", "c3 c5 e5"))["a1"], ["d4-a7", "d4-b6", "d4-f6", "d4-g7", "d4-h8"])

    def test_illegal_and_garbage_paths_rejected(self):
        p = ce.Position()
        for bad in (["a3", "a4"], ["a3"], ["z9", "a1"], None, [1, 2], ["c3", "d4", "e5"]):
            with self.assertRaises(ValueError):
                p.copy().push(bad)

    def test_half_counter_counts_only_king_moves(self):
        q = mk("Ka3 h2", "Kh6 a7")
        q.push(["a3", "b4"])
        self.assertEqual(q.half, 1)
        q.push(["h6", "g7"])
        self.assertEqual(q.half, 2)
        q.push(["h2", "g3"])                                       # oddiy shashka yurishi hisobni nollaydi
        self.assertEqual(q.half, 0)

    @unittest.skipUnless(shutil.which("node"), "node kerak")
    def test_js_engine_agrees_with_python(self):
        rnd = random.Random(11)
        rows = []
        for _ in range(40):
            p, n = ce.Position(), 0
            while p.legal() and n < 200 and p.half < ce.KING_ONLY_PLIES:
                rows.append({"b": "".join(p.b), "t": p.turn, "map": p.legal_map()})
                m = rnd.choice(p.legal())
                p.push([ce.name(i) for i in m["path"]])
                n += 1
        js = ("const T=require(%s);const rows=JSON.parse(require('fs').readFileSync(0,'utf8'));"
              "const norm=m=>Object.keys(m).sort().map(k=>k+':'+m[k].map(x=>x.join('-')).sort().join('|')).join(';');"
              "let bad=0;for(const r of rows){if(norm(T.fromBoard(r.b,r.t).legalMap())!==norm(r.map))bad++;}console.log(bad);"
              % json.dumps(str(ROOT / "app/static/js/checkers.js")))
        out = subprocess.run(["node", "-e", js], input=json.dumps(rows), capture_output=True, text=True, timeout=120)
        self.assertEqual(out.stdout.strip(), "0", out.stderr)


def _user(name):
    _, u = auth.register(name, name.title(), "secret12")
    return users.get(u["id"])


class ServiceTests(unittest.TestCase):
    def test_invite_play_and_points(self):
        from app.services import checkers as svc
        from app.services import games as chess
        a, b, c = _user("ck_a"), _user("ck_b"), _user("ck_c")

        async def scenario():
            await svc.invite(a, b["id"])
            with self.assertRaises(ChatError):
                await svc.invite(a, c["id"])                       # avvalgi taklif kutilmoqda
            with self.assertRaises(ChatError):
                await chess.invite(c, b["id"])                     # b ga shashka taklifi kelgan — shaxmat taklifi o'tmaydi
            inv = svc._invites[svc._out[a["id"]]]
            with self.assertRaises(ChatError):
                await svc.reply(c, inv["id"], True)                # taklif boshqaga
            await svc.reply(b, inv["id"], True)
            g = svc._games[svc._user_game[a["id"]]]
            self.assertEqual(svc._user_game[a["id"]], svc._user_game[b["id"]])
            with self.assertRaises(ChatError):
                await chess.start_bot(a, "w")                      # shashka o'yinida shaxmat boshlanmaydi
            white = users.get(g.white)
            black = users.get(g.black)
            with self.assertRaises(ChatError):
                await svc.move(black, g.gid, ["b6", "a5"])          # navbat oqda
            with self.assertRaises(ChatError):
                await svc.move(white, g.gid, ["a3", "a4"])          # noqonuniy yurish
            await svc.move(white, g.gid, ["c3", "d4"])
            self.assertEqual(g.plies, 1)
            self.assertEqual(g.hist, ["c3d4"])
            self.assertEqual(g.last["path"], ["c3", "d4"])
            await svc.move(black, g.gid, ["b6", "a5"])
            g.plies = 12                                            # yetarlicha uzun o'yin (reytingli)
            await svc.resign(black, g.gid)
            self.assertIsNotNone(g.over)
            self.assertEqual(g.over["result"], "w")
            self.assertTrue(g.over["rated"])
            self.assertEqual(g.over["pts"]["w"], svc.WIN)
            self.assertEqual(repo.stats(white["id"], "checkers")["points"], svc.WIN)
            self.assertEqual(repo.stats(black["id"], "checkers")["wins"], 0)
            self.assertFalse(svc.busy(a["id"]) or svc.busy(b["id"]))
            with self.assertRaises(ChatError):
                await svc.move(white, g.gid, ["d4", "e5"])          # o'yin tugagan

        asyncio.run(scenario())

    def test_last_capture_wins_and_short_game_is_unrated(self):
        from app.services import checkers as svc
        a, b = _user("ck_d"), _user("ck_e")

        async def scenario():
            g = svc.Game(a["id"], b["id"])
            svc._games[g.gid] = g
            svc._user_game[a["id"]] = svc._user_game[b["id"]] = g.gid
            g.pos = mk("c3", "d4")
            g.legal = g.pos.legal_map()
            await svc.move(a, g.gid, ["c3", "e5"])
            self.assertEqual(g.over["result"], "w")
            self.assertEqual(g.over["reason"], "no_moves")
            self.assertFalse(g.over["rated"])                       # 1 yarim yurish — ochko yo'q
            self.assertEqual(g.over["pts"], {"w": 0, "b": 0})

        asyncio.run(scenario())

    def test_repetition_and_scoreboard(self):
        from app.services import checkers as svc
        a, b = _user("ck_f"), _user("ck_g")

        async def scenario():
            g = svc.Game(a["id"], b["id"])
            svc._games[g.gid] = g
            svc._user_game[a["id"]] = svc._user_game[b["id"]] = g.gid
            g.pos = mk("Ka3", "Kh6")
            g.reps = {g.pos.key(): 1}
            g.legal = g.pos.legal_map()
            seq = [(a, ["a3", "b4"]), (b, ["h6", "g7"]), (a, ["b4", "a3"]), (b, ["g7", "h6"])] * 3
            for who, path in seq:
                if g.over:
                    break
                await svc.move(who, g.gid, path)
            self.assertEqual(g.over["result"], "d")
            self.assertEqual(g.over["reason"], "repetition")
            sb = svc.scoreboard(a)
            self.assertEqual(sb["game"], "checkers")
            self.assertEqual(sb["me"]["draws"], 1)

        asyncio.run(scenario())


def _won_game(side, seed=1):
    """Tasodifiy o'yin: `side` yurish qolmaganda g'alaba qozongan yozuvni qaytaradi."""
    rnd = random.Random(seed)
    while True:
        p, moves = ce.Position(), []
        while True:
            L = p.legal()
            if not L:
                winner = "b" if p.turn == "w" else "w"
                break
            m = rnd.choice(L)
            path = [ce.name(i) for i in m["path"]]
            p.push(path)
            moves.append("".join(path))
            if len(moves) > 400 or p.half >= ce.KING_ONLY_PLIES:
                winner = None
                break
        if winner == side and len(moves) >= 20:
            return moves


class MissionTests(unittest.TestCase):
    def setUp(self):
        from app.services import missions
        self.m = missions

    def _ticket(self, user, level=4, side="w", secs=900):
        import time
        from app.db import db
        tok = self.m.start_game(user, "checkers", level, side)["token"]
        db.run("UPDATE mission_games SET started_at=? WHERE token=?", (time.time() - secs, tok))
        return tok

    def test_default_rules_and_bot_win_awards_points(self):
        from app.repositories import missions as mrepo
        pts = {r["rule"]: r["points"] for r in self.m.rules_of("checkers")}
        self.assertEqual((pts["bot_3"], pts["bot_4"], pts["bot_5"], pts["pvp_win"]), (5, 10, 25, 10))
        u = _user("ck_m1")
        moves = _won_game("w")
        res = self.m.submit_chess(u, self._ticket(u, 4, "w"), moves, 0, 0, "checkers")
        self.assertTrue(res["counted"], res)
        self.assertEqual(res["gained"], 10)
        self.assertEqual(mrepo.points(u["id"], "checkers"), 10)
        self.assertEqual(mrepo.points(u["id"], "chess"), 0)

    def test_black_side_win_and_rejections(self):
        u = _user("ck_m2")
        res = self.m.submit_chess(u, self._ticket(u, 5, "b"), _won_game("b", 3), 0, 0, "checkers")
        self.assertTrue(res["counted"], res)
        self.assertEqual(res["gained"], 25)
        # boshqa tomon g'olib bo'lgan o'yin, qayta yuborish, soxta yozuv, boshqa o'yin chiptasi
        with self.assertRaises(ChatError):
            self.m.submit_chess(u, self._ticket(u, 5, "b"), _won_game("w", 5), 0, 0, "checkers")
        tok = self._ticket(u, 5, "w")
        mv = _won_game("w", 7)
        self.m.submit_chess(u, tok, mv, 0, 0, "checkers")
        with self.assertRaises(ChatError):
            self.m.submit_chess(u, tok, mv, 0, 0, "checkers")
        with self.assertRaises(ChatError):
            self.m.submit_chess(u, self._ticket(u, 5, "w"), mv[:-1], 0, 0, "checkers")      # tugamagan
        with self.assertRaises(ChatError):
            self.m.submit_chess(u, self._ticket(u, 5, "w"), ["a3a4"] + mv[1:], 0, 0, "checkers")  # noqonuniy yurish
        chess_tok = self.m.start_game(u, "chess", 3, "w")["token"]
        with self.assertRaises(ChatError):
            self.m.submit_chess(u, chess_tok, mv, 0, 0, "checkers")                            # boshqa o'yin chiptasi

    def test_hints_and_undo_block_points_in_strict_mode(self):
        u = _user("ck_m3")
        res = self.m.submit_chess(u, self._ticket(u, 4, "w"), _won_game("w", 9), 1, 0, "checkers")
        self.assertFalse(res["counted"])

    def test_pvp_win_gives_mission_points_and_admin_can_change_rule(self):
        import asyncio
        from app.repositories import missions as mrepo
        from app.services import checkers as svc
        a, b = _user("ck_m4"), _user("ck_m5")
        self.m.rule_set("checkers", "pvp_win", 7, 0)

        async def scenario():
            g = svc.Game(a["id"], b["id"])
            g.plies = 12
            await svc._finish(g, "w", "resign")

        asyncio.run(scenario())
        self.assertEqual(mrepo.points(a["id"], "checkers"), 7)
        self.assertEqual(mrepo.points(b["id"], "checkers"), 0)
        self.assertIn("checkers", [x["game"] for x in self.m.admin_overview()["games"]])


if __name__ == "__main__":
    unittest.main()
