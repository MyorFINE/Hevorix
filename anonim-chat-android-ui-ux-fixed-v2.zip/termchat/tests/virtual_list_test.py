import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
STATIC = ROOT / "app" / "static"
try:
    from playwright.sync_api import sync_playwright
    HAVE = True
except Exception:
    HAVE = False

PAGE = """<!doctype html><html><head><meta charset=utf-8></head><body>
<div id="chat" style="height:600px"><div id="msgs" class="msgs" style="height:600px;overflow-y:auto;display:block;position:relative"></div></div>
</body></html>"""

FILL = """(n) => { const box = document.getElementById('msgs');
  for (let i = 1; i <= n; i++) { const r = document.createElement('div'); r.className = 'row' + (i % 3 ? '' : ' mine'); r.dataset.id = i;
    const b = document.createElement('div'); b.className = 'bubble'; b.textContent = ('Xabar ' + i + ' ').repeat(1 + (i * 7) % 23); r.append(b); box.append(r); } }"""


@unittest.skipUnless(HAVE, "playwright yo'q")
class VirtualListTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pw = sync_playwright().start()
        cls.br = cls.pw.chromium.launch()

    @classmethod
    def tearDownClass(cls):
        cls.br.close()
        cls.pw.stop()

    def page(self, rows=400, *, inject=True, pre=None):
        pg = self.br.new_page(viewport={"width": 420, "height": 700})
        self.addCleanup(pg.close)
        pg.route("http://app.test/**", lambda route: route.fulfill(body=PAGE, content_type="text/html"))
        pg.goto("http://app.test/")
        pg.add_style_tag(path=str(STATIC / "css" / "style.css"))
        if pre:
            pg.evaluate(pre)
        pg.evaluate(FILL, rows)
        pg.wait_for_timeout(50)
        self.base = pg.evaluate("document.getElementById('msgs').scrollHeight")
        if inject:
            pg.add_script_tag(path=str(STATIC / "js" / "virtual.js"))
            pg.wait_for_timeout(250)
        return pg

    def test_far_rows_are_frozen_and_height_is_preserved(self):
        pg = self.page()
        n = pg.evaluate("__vlist.count()")
        self.assertGreater(n, 100, "uzoq qatorlar muzlamadi")
        after = pg.evaluate("document.getElementById('msgs').scrollHeight")
        self.assertLessEqual(abs(after - self.base), 2, f"scroll balandligi o'zgardi: {self.base} -> {after}")
        self.assertEqual(pg.evaluate("document.querySelectorAll('#msgs .row').length"), 400, "qatorlar DOM'dan o'chmasligi kerak")

    def test_scrolling_thaws_visible_rows_and_keeps_height(self):
        pg = self.page()
        for top in (0, 3000, 9000, 10 ** 7, 0):
            pg.evaluate("t => { document.getElementById('msgs').scrollTop = t }", top)
            pg.wait_for_timeout(200)
            h = pg.evaluate("document.getElementById('msgs').scrollHeight")
            self.assertLessEqual(abs(h - self.base), 3, f"top={top}: balandlik {self.base} -> {h}")
            vis = pg.evaluate("""() => { const b = document.getElementById('msgs').getBoundingClientRect();
              return [...document.querySelectorAll('#msgs .row')].filter(r => { const q = r.getBoundingClientRect(); return q.bottom > b.top && q.top < b.bottom; })
                .every(r => !r.classList.contains('vs-off')); }""")
            self.assertTrue(vis, f"top={top}: ko'rinib turgan qator muzlab qolgan")

    def test_jump_to_far_row_works(self):
        pg = self.page()
        pg.evaluate("document.querySelector('#msgs .row[data-id=\"120\"]').scrollIntoView({block:'center'})")
        pg.wait_for_timeout(250)
        ok = pg.evaluate("""() => { const r = document.querySelector('#msgs .row[data-id="120"]'), b = document.getElementById('msgs').getBoundingClientRect(), q = r.getBoundingClientRect();
          return !r.classList.contains('vs-off') && q.top >= b.top - 2 && q.bottom <= b.bottom + 2; }""")
        self.assertTrue(ok, "jumpTo ekvivalenti: qator markazda ko'rinishi va muzlamagan bo'lishi kerak")

    def test_new_rows_are_observed_and_playing_media_is_not_frozen(self):
        pg = self.page(300)
        pg.evaluate("document.getElementById('msgs').scrollTop = 1e7")
        pg.wait_for_timeout(250)
        pg.evaluate("""() => { const box = document.getElementById('msgs'), r = document.createElement('div'); r.className = 'row'; r.dataset.id = 'x';
          const a = document.createElement('audio'); Object.defineProperty(a, 'paused', {get: () => false}); r.append(a); box.insertBefore(r, box.firstChild); }""")
        pg.wait_for_timeout(250)
        self.assertFalse(pg.evaluate("document.querySelector('#msgs .row[data-id=\"x\"]').classList.contains('vs-off')"), "ijro etilayotgan media qatori muzlamasligi kerak")
        before = pg.evaluate("__vlist.count()")
        pg.evaluate("""() => { const box = document.getElementById('msgs'); for (let i = 0; i < 5; i++) { const r = document.createElement('div'); r.className = 'row'; r.textContent = 'yangi ' + i; box.insertBefore(r, box.children[1]); } }""")
        pg.wait_for_timeout(250)
        self.assertGreaterEqual(pg.evaluate("__vlist.count()"), before + 5, "yangi qo'shilgan uzoq qatorlar kuzatilmadi")

    def test_rerender_like_app_textcontent_clear(self):
        pg = self.page(200)
        pg.evaluate("document.getElementById('msgs').textContent = ''")
        pg.evaluate(FILL, 200)
        pg.wait_for_timeout(250)
        self.assertGreater(pg.evaluate("__vlist.count()"), 20)
        self.assertEqual(pg.evaluate("document.querySelectorAll('#msgs .row').length"), 200)

    def test_kill_switch(self):
        pg = self.page(inject=False, pre="localStorage.setItem('ac_vs','0')")
        pg.add_script_tag(path=str(STATIC / "js" / "virtual.js"))
        pg.wait_for_timeout(200)
        self.assertEqual(pg.evaluate("typeof window.__vlist"), "undefined")
        self.assertEqual(pg.evaluate("document.querySelectorAll('.vs-off').length"), 0)


if __name__ == "__main__":
    unittest.main()
