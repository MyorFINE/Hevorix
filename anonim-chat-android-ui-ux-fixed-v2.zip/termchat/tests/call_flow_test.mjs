// node tests/call_flow_test.mjs — qo'ng'iroq mijoz oqimi (soxta WebRTC/DOM bilan): parol, kalit tasdig'i, noto'g'ri parol, media faqat tasdiqdan keyin
import assert from "node:assert/strict";
import fs from "node:fs";
import { webcrypto } from "node:crypto";
globalThis.crypto ??= webcrypto;
await import("../app/static/js/callcrypto.js");
const CallCrypto = globalThis.CallCrypto;
const SRC = fs.readFileSync(new URL("../app/static/js/call.js", import.meta.url), "utf8");
const tick = (ms = 20) => new Promise(r => setTimeout(r, ms));
async function until(fn, what, ms = 8000) { const t0 = Date.now(); while (!fn()) { if (Date.now() - t0 > ms) throw new Error("kutish tugadi: " + what); await tick(15); } }

class El {
  constructor(tag) { this.tag = tag; this.children = []; this.cls = new Set(); this.textContent = ""; this.value = ""; this.attrs = {}; this.ls = {}; this.srcObject = null; this.style = {}; }
  get classList() { const s = this.cls; return {add: c => s.add(c), remove: c => s.delete(c), contains: c => s.has(c), toggle: (c, f) => { (f === undefined ? !s.has(c) : f) ? s.add(c) : s.delete(c); }}; }
  set className(v) { this.cls = new Set(String(v).split(/\s+/).filter(Boolean)); }
  append(...k) { for (const c of k) this.children.push(typeof c === "string" ? Object.assign(new El("#t"), {textContent: c}) : c); }
  setAttribute(k, v) { this.attrs[k] = v; }
  addEventListener(t, f) { (this.ls[t] ||= []).push(f); }
  click() { if (this.onclick) this.onclick(); (this.ls.click || []).forEach(f => f()); }
  focus() {} play() { return Promise.resolve(); }
  all() { return this.children.flatMap(c => [c, ...c.all()]); }
  q(sel) { return this.all().find(e => sel.startsWith(".") ? sel.slice(1).split(".").every(c => e.cls.has(c)) : e.tag === sel) || null; }
  querySelector(sel) { return this.q(sel); }
}
const h = (tag, props, ...kids) => { const e = new El(tag); for (const [k, v] of Object.entries(props || {})) { if (v == null || v === false) continue; if (k === "class") e.className = v; else if (k === "text") e.textContent = v; else if (k.startsWith("on")) e.addEventListener(k.slice(2), v); else e.setAttribute(k, v); } e.append(...kids.flat().filter(x => x != null && x !== false)); return e; };
const icon = (name) => { const s = new El("svg"); const u = new El("use"); u.setAttribute("href", "#i-" + name); s.append(u); return s; };

const server = { parties: {}, calls: {}, n: 0,
  deliver(uid, m) { setTimeout(() => this.parties[uid].root.Call.onSignal({type: "call", ...m}), 0); },
  handle(from, m) {
    if (m.op === "start") { const id = "c" + ++this.n; this.calls[id] = {a: from, b: m.to}; this.deliver(from, {op: "started", id, to: m.to, online: true}); this.deliver(m.to, {op: "incoming", id, from}); return; }
    const c = this.calls[m.id]; if (!c) return;
    const other = from === c.a ? c.b : c.a;
    if (m.op === "accept") this.deliver(c.a, {op: "accepted", id: m.id});
    else if (m.op === "end") { delete this.calls[m.id]; this.deliver(c.a, {op: "ended", id: m.id, reason: "hangup"}); this.deliver(c.b, {op: "ended", id: m.id, reason: "hangup"}); }
    else if (["kex", "confirm", "offer", "answer", "ice"].includes(m.op)) this.deliver(other, m);
  } };

function party(uid) {
  const P = {uid, log: [], pcs: [], workers: [], toasts: []};
  const doc = {body: new El("body")};
  const track = {enabled: true, stop() {}, kind: "audio", tag: "PROCESSED"}, rawTrack = {stop() {}, tag: "RAW"};
  const AudioNode = class { connect() {} };
  const root = {
    document: doc, isSecureContext: true, CallCrypto, crypto: webcrypto, addEventListener() {},
    navigator: {mediaDevices: {getUserMedia: async () => ({getTracks: () => [rawTrack]}), enumerateDevices: async () => []}},
    AudioContext: class { constructor() { this.audioWorklet = {addModule: async () => {}}; } async resume() {} close() {} createMediaStreamSource() { return new AudioNode(); } createBiquadFilter() { const n = new AudioNode(); n.frequency = {}; return n; }
      createMediaStreamDestination() { const n = new AudioNode(); n.stream = {getAudioTracks: () => [track]}; return n; } createOscillator() { throw new Error("yo'q"); } },
    AudioWorkletNode: class extends AudioNode { constructor(ac, name, o) { super(); P.shifter = {name, ratio: o.processorOptions.ratio}; } },
    RTCRtpScriptTransform: class { constructor(w, o) { this.o = o; } },
    MediaStream: class { constructor(t) { this.t = t; } },
    Worker: class { constructor(url) { this.url = url; this.msgs = []; P.workers.push(this); } postMessage(m) { this.msgs.push(m); } terminate() { this.dead = true; } },
    RTCPeerConnection: class {
      constructor(cfg) { this.cfg = cfg; this.tracks = []; this.senders = []; P.pcs.push(this); this.connectionState = "new"; }
      addTransceiver(t) { this.tracks.push(t); const tr = {sender: {transform: null}, receiver: {transform: null}}; this.senders.push(tr.sender); return tr; }
      getSenders() { return this.senders; }
      createDataChannel() { return {readyState: "connecting", close() {}, bufferedAmount: 0}; }
      async createOffer() { return {type: "offer", sdp: "v=0\r\nm=audio 9 UDP/TLS/RTP/SAVPF 111\r\na=extmap:1 urn:ietf:params:rtp-hdrext:ssrc-audio-level\r\na=rtpmap:111 opus/48000/2\r\na=fmtp:111 usedtx=1\r\n"}; }
      async createAnswer() { return this.createOffer(); }
      async setLocalDescription(d) { this.local = d; this.maybe(); }
      async setRemoteDescription(d) { this.remoteDescription = d; this.maybe(); }
      maybe() { if (this.local && this.remoteDescription && !this.did) { this.did = true; setTimeout(() => { this.connectionState = "connected"; this.onconnectionstatechange && this.onconnectionstatechange(); }, 5); } }
      async addIceCandidate() {} close() { this.closed = true; }
    },
  };
  Object.assign(P, {root, doc, track, rawTrack});
  P.ui = () => doc.body.children.find(c => c.cls.has("callui"));
  P.find = s => P.ui().q(s);
  const fn = new Function("globalThis", "window", "CallCrypto", "RTCPeerConnection", "Worker", "MediaStream", "RTCRtpScriptTransform", SRC);
  fn(root, root, CallCrypto, root.RTCPeerConnection, root.Worker, root.MediaStream, root.RTCRtpScriptTransform);
  root.Call.init({api: async () => ({iceServers: [{urls: ["turn:x"]}], turn: true}), wsSend: m => { server.handle(uid, m); return true; }, toast: (t) => P.toasts.push(t), h, icon,
    avatar: () => new El("div"), user: id => ({id, nickname: "User" + id})});
  server.parties[uid] = P;
  return P;
}
const status = p => p.find(".cu-status").textContent;

// ---- 1) to'g'ri parol: ulanish va media faqat tasdiqdan keyin
{
  const A = party(1), B = party(2);
  A.root.Call.start(2);
  A.find(".cu-in").value = "123";  A.find(".cu-go").click();
  assert.match(A.find(".cu-err").textContent, /kamida 6/);
  A.find(".cu-in").value = "kelishuv-parol"; A.find(".cu-go").click();
  await until(() => B.ui() && status(B).startsWith("Kiruvchi"), "B kiruvchi");
  assert.equal(A.pcs.length, 0, "PC tasdiqdan oldin yaratilmaydi");
  B.find(".cu-b.acc").click();
  assert.ok(!B.find(".cu-pw").cls.has("hidden"), "callee parol so'raydi");
  B.find(".cu-in").value = "kelishuv-parol"; B.find(".cu-go").click();
  await until(() => A.pcs.length === 1 && B.pcs.length === 1, "ikkala PC");
  await until(() => /^\d\d:\d\d$/.test(status(A)) && /^\d\d:\d\d$/.test(status(B)), "ulandi");
  for (const P of [A, B]) {
    assert.equal(P.pcs[0].tracks[0].tag, "PROCESSED", "PC ga faqat o'zgartirilgan trek beriladi, xom mikrofon emas");
    assert.ok(P.shifter.ratio >= 0.74 && P.shifter.ratio <= 0.82);
    assert.equal(P.pcs[0].cfg.iceTransportPolicy, "relay");
    assert.equal(P.workers.length, 1); assert.equal(P.workers[0].msgs[0].type, "keys");
    assert.ok(P.pcs[0].senders[0].transform && P.pcs[0].senders[0].transform.o.operation === "encrypt");
  }
  assert.ok(!/ssrc-audio-level/.test(A.pcs[0].local.sdp) && /usedtx=0/.test(A.pcs[0].local.sdp), "SDP mustahkamlangan");
  assert.equal(A.find(".cu-sub").textContent.match(/kod (\d{4})/)[1], B.find(".cu-sub").textContent.match(/kod (\d{4})/)[1], "SAS bir xil");
  // mikrofon o'chirish
  A.find(".cu-b.mute").click(); assert.equal(A.track.enabled, false); A.find(".cu-b.mute").click(); assert.equal(A.track.enabled, true);
  A.find(".cu-b.spk").click(); assert.ok(A.find(".cu-b.spk").cls.has("on"));
  // qo'yish: ikkala tomon tozalanadi, kalitlar o'chiriladi
  A.find(".cu-b.end").click();
  await until(() => A.pcs[0].closed && B.pcs[0].closed, "yopildi");
  assert.ok(A.workers[0].dead && A.workers[0].msgs.some(m => m.type === "wipe"));
  assert.equal(A.root.Call.busy(), false); assert.equal(B.root.Call.busy(), false);
  console.log("1) to'g'ri parol: OK");
}

// ---- 2) noto'g'ri parol: media boshlanmaydi, qayta urinish
{
  const A = party(1), B = party(2);
  A.root.Call.start(2); A.find(".cu-in").value = "togri-parol"; A.find(".cu-go").click();
  await until(() => B.ui() && status(B).startsWith("Kiruvchi"), "B kiruvchi");
  B.find(".cu-b.acc").click(); B.find(".cu-in").value = "xato-parol"; B.find(".cu-go").click();
  await until(() => /1\/3/.test(B.find(".cu-err").textContent), "B xato");
  await until(() => /mos kelmadi/.test(status(A)), "A xabardor");
  assert.equal(A.pcs.length + B.pcs.length, 0, "parol xato bo'lsa hech qanday PC/media yo'q");
  B.find(".cu-in").value = "togri-parol"; B.find(".cu-go").click();
  await until(() => A.pcs.length === 1 && B.pcs.length === 1, "qayta urinish o'tdi");
  await until(() => /^\d\d:\d\d$/.test(status(A)), "ulandi");
  A.find(".cu-b.end").click(); await until(() => !A.root.Call.busy() && !B.root.Call.busy(), "tugadi");
  console.log("2) qayta urinish: OK");
}

// ---- 3) uch marta noto'g'ri: qo'ng'iroq to'xtaydi
{
  const A = party(1), B = party(2);
  A.root.Call.start(2); A.find(".cu-in").value = "togri-parol"; A.find(".cu-go").click();
  await until(() => B.ui() && status(B).startsWith("Kiruvchi"), "B kiruvchi");
  B.find(".cu-b.acc").click(); B.find(".cu-in").value = "xato-parol1"; B.find(".cu-go").click();
  for (const [i, pw] of [[1, "xato-parol2"], [2, "xato-parol3"]]) {
    await until(() => new RegExp(i + "/3").test(B.find(".cu-err").textContent), "urinish " + i);
    B.find(".cu-in").value = pw; B.find(".cu-go").click();
  }
  await until(() => !A.root.Call.busy() && !B.root.Call.busy(), "3 xatodan keyin to'xtadi");
  assert.equal(A.pcs.length + B.pcs.length, 0);
  console.log("3) 3 ta xato parol: OK");
}

// ---- 4) rad etish va javobsiz bekor qilish
{
  const A = party(1), B = party(2);
  A.root.Call.start(2); A.find(".cu-in").value = "togri-parol"; A.find(".cu-go").click();
  await until(() => B.ui() && status(B).startsWith("Kiruvchi"), "B kiruvchi");
  B.find(".cu-b.end").click();
  await until(() => !A.root.Call.busy() && !B.root.Call.busy(), "rad etildi");
  console.log("4) rad etish: OK");
}
console.log("qo'ng'iroq mijoz oqimi: hammasi o'tdi");
process.exit(0);
