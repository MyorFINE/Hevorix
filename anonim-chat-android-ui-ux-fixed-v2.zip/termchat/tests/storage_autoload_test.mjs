import assert from "node:assert/strict";
import fs from "node:fs";
import vm from "node:vm";

const files = new Map();
const dir = {
  kind: "directory", name: "Yuklamalar",
  queryPermission: async () => "granted",
  getFileHandle: async (n, o) => {
    if (!files.has(n)) { if (!(o && o.create)) { const e = new Error("x"); e.name = "NotFoundError"; throw e; } files.set(n, null); }
    return { createWritable: async () => ({ write: async b => files.set(n, b), close: async () => {}, abort: async () => {} }) };
  },
};
let fetches = 0;
const ctx = {
  console, setTimeout, Blob, URL: {createObjectURL: () => "blob:x", revokeObjectURL() {}},
  document: {body: {append() {}}, querySelectorAll: () => [], querySelector: () => null},
  window: {}, localStorage: {_m: new Map(), getItem(k) { return this._m.has(k) ? this._m.get(k) : null; }, setItem(k, v) { this._m.set(k, v); }},
  indexedDB: {}, h: () => ({click() {}, remove() {}}), S: {offline: false, token: "t", group: {msgs: []}, dms: new Map()},
  SC: {fetch: async () => { fetches++; return {ok: true, bytes: new Uint8Array(8)}; }},
  e2eFetchBlob: async () => { fetches++; return new Uint8Array(16); },
  paintVoices() {}, paintVNs() {}, drawCover() {}, VNote: {unpack: () => ({video: new Uint8Array(1)})},
};
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(new URL("../frontend/js/app/68-storage-autoload.js", import.meta.url), "utf8") +
  "\nthis.api={MC,Store,autoDlOn,autoDlSet,fileBytes,autoWarm,saveToChosen,mcWarm};", ctx);
const A = ctx.api;
const tick = () => new Promise(r => setTimeout(r, 10));

assert.equal(A.autoDlOn(), true, "standart: yoqilgan");
A.autoDlSet(false); assert.equal(A.autoDlOn(), false); A.autoDlSet(true);

const m = {id: 5, file: {size: 100, e2e: true, url: "/f"}};
A.autoWarm(m); await tick();
assert.ok(A.mcWarm(5), "avtozagruzka yoqilganda xotiraga olinadi");
await A.fileBytes(m); assert.equal(fetches, 1, "ikkinchi marta tarmoqqa chiqmaydi");

A.autoDlSet(false);
A.autoWarm({id: 6, file: {size: 100, e2e: true}}); await tick();
assert.ok(!A.mcWarm(6), "o'chirilganda oldindan yuklanmaydi");
A.autoDlSet(true);
A.autoWarm({id: 7, file: {size: 50 * 1048576, e2e: true}}); await tick();
assert.ok(!A.mcWarm(7), "katta fayl o'zi yuklanmaydi");

A.Store.dir = dir; A.Store.name = dir.name;
assert.equal(await A.saveToChosen(new Uint8Array([1]), "a.txt"), "Yuklamalar");
assert.equal(await A.saveToChosen(new Uint8Array([2]), "a.txt"), "Yuklamalar");
assert.deepEqual([...files.keys()], ["a.txt", "a (1).txt"], "bir xil nom ustiga yozilmaydi");
console.log("storage_autoload_test: OK");
