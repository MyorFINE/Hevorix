import os
import sys
import tempfile
import unittest
from pathlib import Path

os.environ.setdefault("TERMCHAT_DATA_DIR", tempfile.mkdtemp(prefix="termchat-fx-"))
os.environ.setdefault("TERMCHAT_REQUIRE_E2EE", "0")
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.db import db
from app.errors import ChatError
from app.repositories import users
from app.security import hash_password
from app.services import backup, fxstyle, profiles, views

_n = [0]


def mk(role="user"):
    _n[0] += 1
    name = f"fx_{role}_{_n[0]}"
    return users.get(users.create(name, name.title(), hash_password("x" * 64), role, 1_700_000_000.0))


class FxStyleTests(unittest.TestCase):
    def test_parse_drops_unknown_and_garbage(self):
        self.assertEqual(fxstyle.parse('{"nick":"aurora","user":"wave","zzz":"x","msg":"bounce"}'), {"nick": "aurora", "msg": "bounce"})
        self.assertEqual(fxstyle.parse("garbage"), {})
        self.assertEqual(fxstyle.parse('["nick"]'), {})
        self.assertEqual(fxstyle.parse({"nick": 5}), {})
        self.assertIsNone(fxstyle.dump({}))

    def test_variant_lists_match_spec(self):
        self.assertEqual(set(fxstyle.FX), {"nick", "user", "bio", "page", "msg", "reply", "link"})
        self.assertEqual(len(fxstyle.FX["nick"]), 10)
        self.assertIn("wave", fxstyle.FX["nick"])
        self.assertNotIn("wave", fxstyle.FX["user"])
        self.assertEqual(set(fxstyle.FX["user"]), set(fxstyle.FX["nick"]) - {"wave"})
        self.assertEqual(fxstyle.FX["bio"][-1], "breathe")
        self.assertEqual(len(fxstyle.FX["msg"]), 7)
        self.assertEqual(len(fxstyle.FX["reply"]), 4)
        self.assertEqual(len(fxstyle.FX["link"]), 4)


class ProfileFxTests(unittest.TestCase):
    def test_set_merge_and_clear(self):
        admin, u = mk("admin"), mk()
        t, ch = profiles.update(admin, u["id"], fx={"nick": "aurora", "msg": "bounce"})
        self.assertEqual(ch, ["fx"])
        self.assertEqual(fxstyle.parse(t["fx"]), {"nick": "aurora", "msg": "bounce"})
        t, _ = profiles.update(admin, u["id"], fx={"link": "pill"})
        self.assertEqual(fxstyle.parse(t["fx"]), {"nick": "aurora", "msg": "bounce", "link": "pill"})
        t, _ = profiles.update(admin, u["id"], fx={"nick": ""})
        self.assertEqual(fxstyle.parse(t["fx"]), {"msg": "bounce", "link": "pill"})
        t, _ = profiles.update(admin, u["id"], fx={"msg": "none", "link": ""})
        self.assertIsNone(t["fx"])

    def test_rejects_colors_css_and_unknown_names(self):
        admin, u = mk("admin"), mk()
        for bad in ({"nick": "#ff0000"}, {"nick": "red;background:url(x)"}, {"nick": "wave", "user": "wave"}, {"bio": "glitch"},
                    {"msg": "<script>"}, {"unknown": "aurora"}, {"page": "bounce"}, {"reply": "pill"}):
            with self.assertRaises(ChatError, msg=str(bad)):
                profiles.update(admin, u["id"], fx=bad)
        self.assertIsNone(users.get(u["id"])["fx"])
        with self.assertRaises(ChatError):
            profiles.update(admin, u["id"], fx="aurora")

    def test_all_declared_names_accepted(self):
        admin, u = mk("admin"), mk()
        for area, names in fxstyle.FX.items():
            for name in names:
                t, _ = profiles.update(admin, u["id"], fx={area: name})
                self.assertEqual(fxstyle.parse(t["fx"])[area], name)

    def test_permissions_unchanged(self):
        owner, admin, admin2, u = mk("owner"), mk("admin"), mk("admin"), mk()
        with self.assertRaises(ChatError):
            profiles.update(u, admin["id"], fx={"nick": "gold"})
        profiles.update(admin, u["id"], fx={"nick": "gold"})
        profiles.update(admin, admin["id"], fx={"nick": "gold"})
        with self.assertRaises(ChatError):
            profiles.update(admin, admin2["id"], fx={"nick": "gold"})
        profiles.update(owner, admin2["id"], fx={"nick": "gold"})
        with self.assertRaises(ChatError):
            profiles.update(admin, owner["id"], fx={"nick": "gold"})

    def test_neon_and_neon_frame_gone(self):
        self.assertNotIn("neon", profiles.FRAMES)
        admin, u = mk("admin"), mk()
        with self.assertRaises(TypeError):
            profiles.update(admin, u["id"], neon="#00f0ff")
        db.run("UPDATE users SET neon='#00f0ff', frame='neon' WHERE id=?", (u["id"],))
        db._migrate()
        r = users.get(u["id"])
        self.assertIsNone(r["neon"])
        self.assertIsNone(r["frame"])
        with self.assertRaises(ChatError):
            profiles.update(admin, u["id"], frame="neon")


class ViewTests(unittest.TestCase):
    def test_user_and_member_views_carry_fx_only_valid(self):
        admin, u = mk("admin"), mk()
        profiles.update(admin, u["id"], fx={"nick": "wave", "page": "stars", "reply": "stripes"})
        v = views.user_view(u["id"])
        self.assertEqual(v["fx"], {"nick": "wave", "page": "stars", "reply": "stripes"})
        self.assertNotIn("neon", v)
        db.run("UPDATE users SET fx=? WHERE id=?", ('{"nick":"evil<b>","msg":"bounce"}', u["id"]))
        self.assertEqual(views.user_view(u["id"])["fx"], {"msg": "bounce"})
        m = next(x for x in users.list_members() if x["id"] == u["id"])
        self.assertEqual(views.member_view(m, admin_view=False)["fx"], {"msg": "bounce"})

    def test_deleted_account_has_no_fx(self):
        admin, u = mk("admin"), mk()
        profiles.update(admin, u["id"], fx={"nick": "aurora"})
        users.mark_deleted(u["id"], 1_800_000_000.0)
        self.assertEqual(views.user_view(u["id"])["fx"], {})
        self.assertIsNone(users.get(u["id"])["fx"])


class BackupDesignTests(unittest.TestCase):
    def test_export_and_restore_keep_design(self):
        owner, admin, u = mk("owner"), mk("admin"), mk()
        profiles.update(admin, u["id"], fx={"nick": "candy", "link": "arrow"}, banner="ocean", frame="gold", title="VIP", trust="trusted")
        data = backup.export_users(owner)
        rec = next(x for x in data["users"] if x["username"] == u["username"])
        self.assertEqual(rec["design"]["fx"], {"nick": "candy", "link": "arrow"})
        self.assertEqual((rec["design"]["banner"], rec["design"]["frame"], rec["design"]["title"], rec["design"]["trust"]), ("ocean", "gold", "VIP", 0))
        db.run("DELETE FROM users WHERE id=?", (u["id"],))
        res = backup.restore_users(owner, data)
        self.assertGreaterEqual(res["created"], 1)
        back = users.get_by_username(u["username"])
        self.assertEqual(fxstyle.parse(back["fx"]), {"nick": "candy", "link": "arrow"})
        self.assertEqual((back["banner"], back["frame"], back["title"], back["trust"]), ("ocean", "gold", "VIP", 0))

    def test_restore_rejects_bad_design_and_accepts_old_backups(self):
        owner, u = mk("owner"), mk()
        data = backup.export_users(owner)
        rec = next(x for x in data["users"] if x["username"] == u["username"])
        db.run("DELETE FROM users WHERE id=?", (u["id"],))
        rec["design"] = {"fx": {"nick": "#ff0000", "msg": "bounce", "zzz": "x"}, "banner": "<x>", "frame": "neon", "title": "A" * 99, "trust": True}
        backup.restore_users(owner, {"v": data["v"], "app": "anonim-chat", "users": [rec]})
        back = users.get_by_username(u["username"])
        self.assertEqual(fxstyle.parse(back["fx"]), {"msg": "bounce"})
        self.assertIsNone(back["banner"]); self.assertIsNone(back["frame"]); self.assertIsNone(back["title"]); self.assertIsNone(back["trust"])
        db.run("DELETE FROM users WHERE username=?", (u["username"],))
        rec.pop("design")
        res = backup.restore_users(owner, {"v": data["v"], "app": "anonim-chat", "users": [rec]})
        self.assertEqual(res["created"], 1)


if __name__ == "__main__":
    unittest.main()
