import os
import sys
import tempfile
import unittest
from pathlib import Path

os.environ.setdefault("TERMCHAT_DATA_DIR", tempfile.mkdtemp(prefix="termchat-fx-"))
os.environ.setdefault("TERMCHAT_REQUIRE_E2EE", "0")
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.db import db
from app.errors import ChatError
from app.repositories import users
from app.security import hash_password
from app.services import backup, fxstyle, profiles, views

_n = [0]


def mk(role="user"):
    _n[0] += 1
    name = f"fx_{role}_{_n[0]}"
    return users.get(users.create(name, name.title(), hash_password("x" * 64), role, 1_700_000_000.0))


class FxStyleTests(unittest.TestCase):
    def test_parse_drops_unknown_and_garbage(self):
        self.assertEqual(fxstyle.parse('{"nick":"aurora","user":"wave","zzz":"x","msg":"bounce"}'), {"nick": "aurora"})
        self.assertEqual(fxstyle.parse("garbage"), {})
        self.assertEqual(fxstyle.parse('["nick"]'), {})
        self.assertEqual(fxstyle.parse({"nick": 5}), {})
        self.assertIsNone(fxstyle.dump({}))

    def test_variant_lists_match_spec(self):
        self.assertEqual(set(fxstyle.FX), {"nick", "user", "bio", "page", "reply", "link"})
        self.assertNotIn("msg", fxstyle.FX)
        self.assertEqual(len(fxstyle.FX["nick"]), 10)
        self.assertIn("wave", fxstyle.FX["nick"])
        self.assertNotIn("wave", fxstyle.FX["user"])
        self.assertEqual(set(fxstyle.FX["user"]), set(fxstyle.FX["nick"]) - {"wave"})
        self.assertEqual(fxstyle.FX["bio"][-1], "breathe")
        self.assertEqual(len(fxstyle.FX["reply"]), 4)
        self.assertEqual(len(fxstyle.FX["link"]), 4)


class ProfileFxTests(unittest.TestCase):
    def test_set_merge_and_clear(self):
        admin, u = mk("admin"), mk()
        t, ch = profiles.update(u, u["id"], fx={"nick": "aurora", "reply": "tint"})
        self.assertEqual(ch, ["fx"])
        self.assertEqual(fxstyle.parse(t["fx"]), {"nick": "aurora", "reply": "tint"})
        t, _ = profiles.update(u, u["id"], fx={"link": "pill"})
        self.assertEqual(fxstyle.parse(t["fx"]), {"nick": "aurora", "reply": "tint", "link": "pill"})
        t, _ = profiles.update(u, u["id"], fx={"nick": ""})
        self.assertEqual(fxstyle.parse(t["fx"]), {"reply": "tint", "link": "pill"})
        t, _ = profiles.update(u, u["id"], fx={"reply": "none", "link": ""})
        self.assertIsNone(t["fx"])

    def test_rejects_colors_css_and_unknown_names(self):
        admin, u = mk("admin"), mk()
        for bad in ({"nick": "#ff0000"}, {"nick": "red;background:url(x)"}, {"nick": "wave", "user": "wave"}, {"bio": "glitch"},
                    {"msg": "bounce"}, {"msg": "<script>"}, {"unknown": "aurora"}, {"page": "bounce"}, {"reply": "pill"}):
            with self.assertRaises(ChatError, msg=str(bad)):
                profiles.update(u, u["id"], fx=bad)
        self.assertIsNone(users.get(u["id"])["fx"])
        with self.assertRaises(ChatError):
            profiles.update(u, u["id"], fx="aurora")

    def test_all_declared_names_accepted(self):
        admin, u = mk("admin"), mk()
        for area, names in fxstyle.FX.items():
            for name in names:
                t, _ = profiles.update(u, u["id"], fx={area: name})
                self.assertEqual(fxstyle.parse(t["fx"])[area], name)

    def test_admin_cannot_give_design_to_others(self):
        owner, admin, admin2, u = mk("owner"), mk("admin"), mk("admin"), mk()
        for kw in ({"fx": {"nick": "gold"}}, {"banner": "ocean"}, {"frame": "gold"}, {"color": "#ff0000"}):
            for actor, target in ((admin, u), (owner, u), (owner, admin2), (admin, admin2)):
                with self.assertRaises(ChatError, msg=str(kw)):
                    profiles.update(actor, target["id"], **kw)
        self.assertIsNone(users.get(u["id"])["fx"])
        # o'z dizayni (admin ham)
        profiles.update(admin, admin["id"], fx={"nick": "gold"}, banner="ocean")

    def test_title_and_trust_role_rules(self):
        owner, admin, admin2, u = mk("owner"), mk("admin"), mk("admin"), mk()
        with self.assertRaises(ChatError):
            profiles.update(u, admin["id"], title="X")
        profiles.update(admin, u["id"], title="VIP", trust="trusted")
        with self.assertRaises(ChatError):
            profiles.update(admin, admin2["id"], title="X")
        profiles.update(owner, admin2["id"], title="Yordamchi")
        with self.assertRaises(ChatError):
            profiles.update(admin, owner["id"], title="X")

    def test_neon_and_neon_frame_gone(self):
        self.assertNotIn("neon", profiles.FRAMES)
        admin, u = mk("admin"), mk()
        with self.assertRaises(TypeError):
            profiles.update(u, u["id"], neon="#00f0ff")
        db.run("UPDATE users SET neon='#00f0ff', frame='neon' WHERE id=?", (u["id"],))
        db._migrate()
        r = users.get(u["id"])
        self.assertIsNone(r["neon"])
        self.assertIsNone(r["frame"])
        with self.assertRaises(ChatError):
            profiles.update(u, u["id"], frame="neon")


class SelfDesignTests(unittest.TestCase):
    """Foydalanuvchi o'z dizaynini o'zi sozlaydi; nishon/galochka/ishonch/rang faqat adminda."""

    def test_user_sets_own_design(self):
        u = mk()
        t, ch = profiles.update(u, u["id"], fx={"nick": "aurora", "link": "pill"}, banner="ocean", frame="gold")
        self.assertEqual(ch, ["banner", "frame", "fx"])
        self.assertEqual(fxstyle.parse(t["fx"]), {"nick": "aurora", "link": "pill"})
        self.assertEqual((t["banner"], t["frame"]), ("ocean", "gold"))
        t, _ = profiles.update(u, u["id"], fx={"nick": ""}, banner="")
        self.assertEqual(fxstyle.parse(t["fx"]), {"link": "pill"})
        self.assertIsNone(t["banner"])

    def test_user_cannot_touch_others(self):
        u, other, admin = mk(), mk(), mk("admin")
        for target in (other, admin):
            with self.assertRaises(ChatError) as cm:
                profiles.update(u, target["id"], fx={"nick": "gold"})
            self.assertEqual(cm.exception.status, 403)
        self.assertIsNone(users.get(other["id"])["fx"])

    def test_user_cannot_set_trust_title_or_color(self):
        u = mk()
        with self.assertRaises(ChatError):
            profiles.update(u, u["id"], title="VIP")
        with self.assertRaises(ChatError):
            profiles.update(u, u["id"], trust="trusted")
        with self.assertRaises(ChatError):
            profiles.update(u, u["id"], color="#ff0000")
        self.assertIsNone(users.get(u["id"])["trust"])

    def test_user_cannot_give_self_badge(self):
        from app.services import badges
        u = mk()
        for b in ("check", "\U0001f525", "none"):
            with self.assertRaises(ChatError):
                badges.set_for(u, u["id"], b, "")
        admin = mk("admin")
        badges.set_for(admin, u["id"], "\U0001f525", "pulse")
        self.assertEqual(users.get(u["id"])["badge"], "\U0001f525")


class ViewTests(unittest.TestCase):
    def test_user_and_member_views_carry_fx_only_valid(self):
        admin, u = mk("admin"), mk()
        profiles.update(u, u["id"], fx={"nick": "wave", "page": "stars", "reply": "stripes"})
        v = views.user_view(u["id"])
        self.assertEqual(v["fx"], {"nick": "wave", "page": "stars", "reply": "stripes"})
        self.assertNotIn("neon", v)
        db.run("UPDATE users SET fx=? WHERE id=?", ('{"nick":"evil<b>","msg":"bounce","link":"pill"}', u["id"]))
        self.assertEqual(views.user_view(u["id"])["fx"], {"link": "pill"})
        m = next(x for x in users.list_members() if x["id"] == u["id"])
        self.assertEqual(views.member_view(m, admin_view=False)["fx"], {"link": "pill"})

    def test_deleted_account_has_no_fx(self):
        admin, u = mk("admin"), mk()
        profiles.update(u, u["id"], fx={"nick": "aurora"})
        users.mark_deleted(u["id"], 1_800_000_000.0)
        self.assertEqual(views.user_view(u["id"])["fx"], {})
        self.assertIsNone(users.get(u["id"])["fx"])


class BackupDesignTests(unittest.TestCase):
    def test_export_and_restore_keep_design(self):
        owner, admin, u = mk("owner"), mk("admin"), mk()
        profiles.update(u, u["id"], fx={"nick": "candy", "link": "arrow"}, banner="ocean", frame="gold")
        profiles.update(admin, u["id"], title="VIP", trust="trusted")
        data = backup.export_users(owner)
        rec = next(x for x in data["users"] if x["username"] == u["username"])
        self.assertEqual(rec["design"]["fx"], {"nick": "candy", "link": "arrow"})
        self.assertEqual((rec["design"]["banner"], rec["design"]["frame"], rec["design"]["title"], rec["design"]["trust"]), ("ocean", "gold", "VIP", 0))
        db.run("DELETE FROM users WHERE id=?", (u["id"],))
        res = backup.restore_users(owner, data)
        self.assertGreaterEqual(res["created"], 1)
        back = users.get_by_username(u["username"])
        self.assertEqual(fxstyle.parse(back["fx"]), {"nick": "candy", "link": "arrow"})
        self.assertEqual((back["banner"], back["frame"], back["title"], back["trust"]), ("ocean", "gold", "VIP", 0))

    def test_restore_rejects_bad_design_and_accepts_old_backups(self):
        owner, u = mk("owner"), mk()
        data = backup.export_users(owner)
        rec = next(x for x in data["users"] if x["username"] == u["username"])
        db.run("DELETE FROM users WHERE id=?", (u["id"],))
        rec["design"] = {"fx": {"nick": "#ff0000", "msg": "bounce", "reply": "tint", "zzz": "x"}, "banner": "<x>", "frame": "neon", "title": "A" * 99, "trust": True}
        backup.restore_users(owner, {"v": data["v"], "app": "anonim-chat", "users": [rec]})
        back = users.get_by_username(u["username"])
        self.assertEqual(fxstyle.parse(back["fx"]), {"reply": "tint"})
        self.assertIsNone(back["banner"]); self.assertIsNone(back["frame"]); self.assertIsNone(back["title"]); self.assertIsNone(back["trust"])
        db.run("DELETE FROM users WHERE username=?", (u["username"],))
        rec.pop("design")
        res = backup.restore_users(owner, {"v": data["v"], "app": "anonim-chat", "users": [rec]})
        self.assertEqual(res["created"], 1)


if __name__ == "__main__":
    unittest.main()
