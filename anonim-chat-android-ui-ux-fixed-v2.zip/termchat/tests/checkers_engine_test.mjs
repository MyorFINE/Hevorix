// Node: rus shashkasi dvigateli (app/static/js/checkers.js) — qoidalar, perft va bot.
// Ishlatish: node tests/checkers_engine_test.mjs
import fs from "node:fs"; import vm from "node:vm"; import assert from "node:assert/strict";
const src = fs.readFileSync(new URL("../app/static/js/checkers.js", import.meta.url), "utf8");
const ctx = {Math, console, Date}; ctx.self = ctx; vm.createContext(ctx); vm.runInContext(src, ctx);
const eq = (a, b, msg) => assert.equal(JSON.stringify(a), JSON.stringify(b), msg);   // vm kontekst massivlari uchun
const T = ctx.TCDraughts; assert.ok(T, "TCDraughts topilmadi");

function mk(w, b, turn = "w") {
  const bd = Array(64).fill(".");
  for (const s of w.split(" ").filter(Boolean)) bd[T.sqIdx(s.replace("K", ""))] = s[0] === "K" ? "W" : "w";
  for (const s of b.split(" ").filter(Boolean)) bd[T.sqIdx(s.replace("K", ""))] = s[0] === "K" ? "B" : "b";
  return T.fromBoard(bd.join(""), turn);
}
const perft = (p, d) => { if (!d) return 1; const L = p.legal(); if (d === 1) return L.length; let n = 0; for (const m of L) { const c = p.clone(); c.make(m); n += perft(c, d - 1); } return n; };

// 1) perft (boshlang'ich holat)
[7, 49, 302, 1469, 7482, 37986].forEach((n, i) => assert.equal(perft(new T.Pos(), i + 1), n, "perft " + (i + 1)));
console.log("OK perft");

// 2) oddiy shashka orqaga ham uradi, majburiy urish
let p = mk("c3", "d4 b2");
eq(Object.keys(p.legalMap()), ["c3"]);
eq(p.legalMap().c3.map(x => x.join("-")).sort(), ["a1", "e5"]);
console.log("OK orqaga urish");

// 3) damka uzoqdan uradi va davom ettirish shart bo'lgan katakni tanlaydi
p = mk("Ka1", "c3 f6 e7");
eq(p.legalMap().a1.map(x => x.join("-")).sort(), ["d4-g7", "d4-h8", "e5-g7", "e5-h8"]);
console.log("OK damka urishi");

// 4) urish paytida damka bo'lib davom etish
p = mk("c6", "d7 g6");
eq(p.legalMap().c6, [["e8", "h5"]]);
const m = p.find(["c6", "e8", "h5"]); p.make(m);
assert.equal(p.b[T.sqIdx("h5")], 2); assert.equal(p.b[T.sqIdx("d7")], 0);
console.log("OK urishda damka");

// 5) turk zarbasi: urilgan tosh ikki marta urilmaydi
p = mk("Ka1", "c3 c5 e5");
eq(p.legalMap().a1.map(x => x.join("-")).sort(), ["d4-a7", "d4-b6", "d4-f6", "d4-g7", "d4-h8"]);
console.log("OK turk zarbasi");

// 6) oddiy yurishda damka bo'lish; bo'sh joyga noqonuniy yurish topilmaydi
p = mk("a7", "");
p.make(p.find(["a7", "b8"])); assert.equal(p.b[T.sqIdx("b8")], 2);
assert.equal(new T.Pos().find(["a3", "a4"]), null);
console.log("OK promotsiya");

// 7) bot: har bir daraja qonuniy yurish qaytaradi; usta daraja zaiflarni yutadi
const start = new T.Pos();
for (let lv = 1; lv <= 4; lv++) { const mv = T.chooseMove(start, lv); assert.ok(start.find(mv.p.map(T.sqName)), "daraja " + lv); }
const play = (lw, lb) => {
  const pos = new T.Pos(), seen = new Map(); let plies = 0;
  while (plies < 160) {
    const L = pos.legal(); if (!L.length) return pos.turn === 1 ? "b" : "w";
    const mv = T.chooseMove(pos, pos.turn === 1 ? lw : lb); pos.make(mv); plies++;
    const k = pos.key(); seen.set(k, (seen.get(k) || 0) + 1);
    if (seen.get(k) >= 3 || pos.half >= T.KING_ONLY_PLIES) return "d";
  }
  return "d";
};
let score = 0; for (let g = 0; g < 4; g++) { const r = g % 2 ? play(1, 4) : play(4, 1); const w4 = g % 2 ? r === "b" : r === "w"; if (w4) score++; else if (r === "d") score += 0.5; }
assert.ok(score >= 3, "4-daraja 1-darajani yengishi kerak, ball: " + score);
console.log("OK bot (4-daraja 1-darajaga qarshi: " + score + "/4)");
