// Node: "yozmoqda" holatlari, last seen, yuborish bosqichlari (Pend) va OFLAYN rejim (shifrlangan IndexedDB nusxasi) mantig'i.
// Ishlatish: node tests/presence_offline_test.mjs
import fs from "node:fs"; import vm from "node:vm"; import assert from "node:assert/strict"; import {webcrypto} from "node:crypto";
const root = new URL("../app/static/js/", import.meta.url).pathname;
let src = fs.readFileSync(root + "app.js", "utf8");
const mark = "\n})();\n\n\n/* ---------------- Uzun nickname";
assert.ok(src.includes(mark), "marker topilmadi");
src = src.replace(mark, "\nglobalThis.__T={Off,Pend,Typing,TY,S,lastSeenText,statusText,typingLabel,onTyping,typingClearFrom,typingNow,resetState,dmOf,chatKey,upsertUser,hhmm};\n})();\n\n\n/* x");

const stub = () => { const f = function () {}; return new Proxy(f, {get: (t, k) => k === Symbol.toPrimitive ? () => "" : k === "value" || k === "textContent" ? "" : k === "length" ? 0 : k === "then" ? undefined : stub(), apply: () => stub(), construct: () => stub(), set: () => true}); };
const els = new Map();
const el = id => {                                    // doimiy soxta element: yozilgan xossalar saqlanadi
  if (!els.has(id)) {
    const st = {textContent: "", value: "", classes: new Set()};
    els.set(id, new Proxy(st, {
      get(t, k) { if (k in t) return t[k]; if (k === "classList") return {add: (...c) => c.forEach(x => t.classes.add(x)), remove: (...c) => c.forEach(x => t.classes.delete(x)), toggle: (c, f) => { (f === undefined ? !t.classes.has(c) : f) ? t.classes.add(c) : t.classes.delete(c); }, contains: c => t.classes.has(c)}; return stub(); },
      set(t, k, v) { t[k] = v; return true; }}));
  }
  return els.get(id);
};
const bodyClasses = new Set();
const document = new Proxy({getElementById: el, hidden: false, body: {classList: {add: c => bodyClasses.add(c), remove: c => bodyClasses.delete(c), contains: c => bodyClasses.has(c)}}, querySelectorAll: () => []}, {get: (t, k) => k in t ? t[k] : stub()});

function fakeIDB() {                                  // eng sodda xotiradagi IndexedDB
  const store = new Map();
  return {store, open() {
    const rq = {};
    setTimeout(() => {
      rq.result = {createObjectStore() {}, close() {}, transaction() {
        const tx = {}; const done = f => { const r = {result: f()}; setTimeout(() => tx.oncomplete && tx.oncomplete(), 0); return r; };
        const os = {get: k => done(() => store.get(k)), put: (v, k) => done(() => { store.set(k, v); }), delete: k => done(() => { store.delete(k); })};
        tx.objectStore = () => os; return tx; }};
      rq.onupgradeneeded && rq.onupgradeneeded(); rq.onsuccess && rq.onsuccess();
    }, 0);
    return rq; }};
}
const idb = fakeIDB();
const ctx = {setInterval, clearInterval, setTimeout, clearTimeout, crypto: webcrypto, TextEncoder, TextDecoder, btoa, atob, console, URL, Uint8Array, Promise, Blob,
  localStorage: {_d: {}, getItem(k) { return this._d[k] ?? null; }, setItem(k, v) { this._d[k] = String(v); }, removeItem(k) { delete this._d[k]; }},
  matchMedia: q => ({matches: /max-width/.test(String(q)), addEventListener() {}}), performance: {now: () => Date.now()}, requestAnimationFrame: () => 0, cancelAnimationFrame() {},
  document, navigator: {}, addEventListener() {}, location: {origin: "http://x", host: "x", protocol: "https:"}, Image: class {}, FormData: class {},
  MutationObserver: class { observe() {} }, HTMLElement: class {}, indexedDB: idb};
ctx.window = ctx; ctx.globalThis = ctx; vm.createContext(ctx);
vm.runInContext(fs.readFileSync(root + "e2ee.js", "utf8"), ctx);
vm.runInContext(fs.readFileSync(root + "richtext.js", "utf8"), ctx);
vm.runInContext(fs.readFileSync(root + "channels.js", "utf8"), ctx);
ctx.SC = {supported: () => true, setToken() {}, fetch: async () => ({ok: false, status: 404, async json() { return {}; }})};
vm.runInContext(src, ctx, {filename: "app.js"});
const T = ctx.__T, {S, Off, Pend, Typing, TY} = T;
const sleep = ms => new Promise(r => setTimeout(r, ms));
await sleep(20);

// ---- 1) last seen matni
const now = Math.floor(Date.now() / 1000);
assert.equal(T.lastSeenText({}), "oflayn");
assert.equal(T.lastSeenText({last_seen: now - 20}), "last seen hozirgina");
const mid = new Date(); mid.setHours(0, 0, 5, 0);                         // bugun, yarim tundan keyin
if (Date.now() / 1000 - mid / 1000 > 120) assert.equal(T.lastSeenText({last_seen: mid / 1000}), "last seen bugun " + T.hhmm(mid / 1000));
const yest = new Date(); yest.setDate(yest.getDate() - 1); yest.setHours(21, 5, 0, 0);
assert.equal(T.lastSeenText({last_seen: yest / 1000}), "last seen kecha 21:05");
const old = new Date(2025, 2, 7, 9, 4, 0); assert.equal(T.lastSeenText({last_seen: old / 1000}), "last seen 07.03.25 09:04");
S.me = {id: 1, username: "alice", nickname: "Alice"}; S.online = new Set([2]);
assert.equal(T.statusText({id: 2}), "onlayn");
assert.equal(T.statusText({id: 3, last_seen: old / 1000}), "last seen 07.03.25 09:04");

// ---- 2) "yozmoqda" yuborish: throttle, ustuvorlik, stop
const sent = []; S.ws = {readyState: 1, send: m => sent.push(JSON.parse(m))}; S.active = {kind: "dm", uid: 5};
Typing.send("text"); Typing.send("text");
assert.equal(sent.length, 1); assert.deepEqual(sent[0], {type: "typing", kind: "text", to: 5});
Typing.send("emoji"); assert.equal(sent.length, 1, "emoji matnni bosib ketmasligi kerak");
Typing.send("voice"); assert.equal(sent.length, 2); assert.equal(sent[1].kind, "voice");
Typing.stop(); assert.deepEqual(sent[2], {type: "typing", kind: "stop", to: 5}); Typing.stop(); assert.equal(sent.length, 3, "ikkinchi stop yuborilmaydi");
const rel = Typing.hold("vnote"); assert.equal(sent.at(-1).kind, "vnote"); rel(); assert.equal(sent.at(-1).kind, "stop"); rel();
S.active = {kind: "group"}; sent.length = 0; Typing.send("text"); assert.equal(sent[0].to, undefined, "umumiy chatda 'to' yo'q"); Typing.stop();
S.active = {kind: "channel", id: 1}; sent.length = 0; Typing.send("text"); assert.equal(sent.length, 0, "kanalda signal yo'q");
S.ws.readyState = 3; S.active = {kind: "dm", uid: 5}; Typing.send("text"); assert.equal(sent.length, 0, "ulanish yo'q bo'lsa jimgina o'tkazadi (toast yo'q)");
S.ws.readyState = 1;

// ---- 3) qabul qilish: matn, tugash muddati, xabar kelganda yo'qolish
S.users.set(5, {id: 5, nickname: "Vali"}); S.users.set(6, {id: 6, nickname: "Ali"});
T.onTyping({uid: 5, kind: "voice", group: false}); assert.equal(T.typingLabel("d5"), "ovozli xabar yozmoqda");
T.onTyping({uid: 5, kind: "vnote", group: false}); assert.equal(T.typingLabel("d5"), "dumaloq video yozmoqda");
T.onTyping({uid: 5, kind: "file", group: false}); assert.equal(T.typingLabel("d5"), "fayl yubormoqda");
T.onTyping({uid: 5, kind: "emoji", group: false}); assert.equal(T.typingLabel("d5"), "emoji tanlamoqda");
T.onTyping({uid: 5, kind: "text", group: false}); assert.equal(T.typingLabel("d5"), "yozmoqda");
T.typingClearFrom(5); assert.equal(T.typingLabel("d5"), "");
T.onTyping({uid: 5, kind: "text", group: true}); assert.equal(T.typingLabel("g"), "Vali yozmoqda");
T.onTyping({uid: 6, kind: "text", group: true}); assert.equal(T.typingLabel("g"), "Vali va Ali yozmoqda");
S.users.set(7, {id: 7, nickname: "Sher"}); T.onTyping({uid: 7, kind: "text", group: true}); assert.equal(T.typingLabel("g"), "3 kishi yozmoqda");
T.onTyping({uid: 5, kind: "stop", group: true}); T.onTyping({uid: 7, kind: "stop", group: true}); assert.equal(T.typingLabel("g"), "Ali yozmoqda");
TY.seen.get("g").get(6).until = Date.now() - 1; assert.equal(T.typingLabel("g"), "", "muddat tugasa yo'qoladi");
T.onTyping({uid: 1, kind: "text", group: true}); assert.equal(T.typingLabel("g"), "", "o'z signalimiz e'tiborga olinmaydi");

// ---- 4) yuborish bosqichlari
S.active = {kind: "group"};
const p = Pend.add(S.active, {kind: "text", text: "salom"}); assert.equal(p.stage, "enc"); assert.equal(Pend.label(p), "shifrlanmoqda…");
Pend.stage(p, "up"); assert.equal(Pend.label(p), "yuborilmoqda…");
Pend.sent(p); assert.equal(p.stage, "sent"); assert.equal(Pend.list.length, 1);
Pend.settle({user: {id: 1}, to: null}); assert.equal(Pend.list.length, 0, "server qaytargach vaqtincha pufak olib tashlanadi");
const q = Pend.add({kind: "dm", uid: 5}, {kind: "voice"}); Pend.settle({user: {id: 1}, to: null}); assert.equal(Pend.list.length, 1, "boshqa suhbat xabari tegmaydi");
Pend.settle({user: {id: 1}, to: 5}); assert.equal(Pend.list.length, 1, "oddiy matn ovozli pufakni olib tashlamaydi");
Pend.settle({user: {id: 1}, to: 5, file: {voice: 1}}); assert.equal(Pend.list.length, 0);
const pt = Pend.add({kind: "dm", uid: 5}, {kind: "text", text: "a"}), pf = Pend.add({kind: "dm", uid: 5}, {kind: "file", name: "r.png", isImg: true, text: "izoh"});
Pend.settle({user: {id: 1}, to: 5, image: "x"}); assert.ok(Pend.list.length === 1 && Pend.list[0] === pt, "rasm xabari rasm pufagini almashtiradi");
Pend.settle({user: {id: 1}, to: 5}); assert.equal(Pend.list.length, 0);
const f = Pend.add(S.active, {kind: "text", text: "x"}); Pend.fail(f); assert.equal(Pend.label(f), "yuborilmadi"); Pend.stage(f, "up"); assert.equal(f.stage, "fail", "xatodan keyin holat o'zgarmaydi");
Pend.clear(); assert.equal(Pend.list.length, 0);

// ---- 5) OFLAYN: shifrlangan nusxa saqlanadi va faqat to'g'ri parol bilan ochiladi
const seed = () => {
  S.token = "t"; S.me = {id: 1, username: "alice", nickname: "Alice"}; S.offline = false;
  S.users = new Map([[1, S.me], [2, {id: 2, username: "bob", nickname: "Bob", last_seen: old / 1000, bio: "salom"}]]);
  S.members = [S.users.get(2)];
  S.group.msgs = [{id: 1, ts: now - 100, user: S.users.get(2), to: null, content: "umumiy salom"}, {id: 2, ts: now - 50, user: S.me, to: null, content: "javob"}];
  const d = T.dmOf(2); d.msgs = [{id: 3, ts: now - 40, user: S.users.get(2), to: 1, content: "maxfiy lichka", e2e: true, verified: true}]; d.loaded = true;
};
seed();
await Off.arm({user: "Alice", password: "parol-123", stay: false});
await Off.save();
const rec = idb.store.get("snap"); assert.ok(rec && rec.data, "nusxa saqlanmadi");
assert.ok(!Buffer.from(rec.data).includes(Buffer.from("maxfiy lichka")), "nusxa ochiq matn bo'lib qolmasligi kerak");
assert.equal(rec.mode, "pw");
// noto'g'ri parol
T.resetState(); el("f_user").value = "alice"; el("f_pass").value = "boshqa";
await Off.open(); assert.ok(!S.offline && /noto'g'ri/.test(el("autherr").textContent), "noto'g'ri parol rad etilishi kerak: " + el("autherr").textContent);
// boshqa akkaunt
el("f_user").value = "mallory"; el("f_pass").value = "parol-123"; await Off.open(); assert.ok(!S.offline && /boshqa akkaunt/.test(el("autherr").textContent));
// parolsiz
el("f_user").value = "alice"; el("f_pass").value = ""; await Off.open(); assert.ok(!S.offline && /parol/i.test(el("autherr").textContent));
// to'g'ri parol
el("f_pass").value = "parol-123"; await Off.open();
assert.ok(S.offline, "to'g'ri parol bilan ochilishi kerak: " + el("autherr").textContent);
assert.ok(bodyClasses.has("offline-mode"));
assert.equal(S.me.username, "alice"); assert.equal(S.group.msgs.length, 2); assert.equal(S.group.msgs[0].content, "umumiy salom");
assert.equal(S.group.msgs[0].user.nickname, "Bob", "xabar egasi foydalanuvchi obyektiga qaytadi");
assert.equal(T.dmOf(2).msgs[0].content, "maxfiy lichka"); assert.ok(T.dmOf(2).loaded);
assert.equal(T.statusText(S.users.get(2)), "last seen 07.03.25 09:04", "profil va last seen oflayn ham ko'rinadi");
assert.equal(S.users.get(2).bio, "salom");
sent.length = 0; assert.equal(ctx.wsSend ? 0 : 0, 0);
// internet qaytganda chiqish
Off.leave(); assert.ok(!S.offline && !bodyClasses.has("offline-mode"));

// ---- 6) "bu qurilmada kirib qolish": parolsiz ochiladi, kalit qurilmadan chiqarilmaydi
T.resetState(); seed(); await Off.arm({user: "alice", password: "", stay: true}); await Off.save();
assert.equal(idb.store.get("snap").mode, "stay"); assert.ok(idb.store.get("stayKey"), "kalit saqlanmadi"); assert.ok(!idb.store.get("meta"), "stay rejimida parol tuzi kerak emas");
T.resetState(); el("f_user").value = ""; el("f_pass").value = ""; await Off.open(); assert.ok(S.offline, "stay rejimi parolsiz ochilishi kerak: " + el("autherr").textContent);
assert.equal(T.dmOf(2).msgs[0].content, "maxfiy lichka");
// stay o'chirilsa — stay bilan shifrlangan nusxa o'chadi
Off.leave(); T.resetState(); await Off.disarmStay(); assert.ok(!idb.store.get("snap") && !idb.store.get("stayKey"));
// wipe
seed(); await Off.arm({user: "alice", password: "p2", stay: false}); await Off.save(); assert.ok(idb.store.get("snap")); await Off.wipe(); assert.ok(!idb.store.get("snap") && !idb.store.get("meta"));

console.log("PRESENCE+OFFLINE OK");
process.exit(0);
