import os
import sys
import tempfile
from pathlib import Path

os.environ["TERMCHAT_DATA_DIR"] = tempfile.mkdtemp(prefix="termchat-test-")
os.environ["TERMCHAT_MSG_RATE_COUNT"] = "50"
os.environ["TERMCHAT_ADMIN_PASSWORD"] = "owner-pass-1"
os.environ["TERMCHAT_REQUIRE_E2EE"] = "0"
os.environ["TERMCHAT_REQUIRE_TUNNEL"] = "0"
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
