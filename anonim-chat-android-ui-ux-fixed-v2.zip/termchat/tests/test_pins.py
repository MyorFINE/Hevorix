"""Pin: umumiy chatda faqat adminlar (hamma uchun), lichkada ikkala tomon o'zi uchun."""
import time

import pytest

from app.errors import ChatError
from app.repositories import messages, users as users_repo
from app.security import hash_password
from app.services import chat
from app.services import pins as svc


def _user(name: str, role: str = "user"):
    uid = users_repo.create(name, name.title(), hash_password("x"), role, time.time())
    return users_repo.get(uid)


@pytest.fixture(scope="module")
def cast():
    sfx = str(int(time.time() * 1000))[-6:]
    return {"adm": _user(f"pna{sfx}", "admin"), "u1": _user(f"pnb{sfx}"), "u2": _user(f"pnc{sfx}"), "u3": _user(f"pnd{sfx}")}


def test_group_pin_admin_only(cast):
    mid = messages.create(cast["u1"]["id"], "muhim", time.time())
    with pytest.raises(ChatError):
        svc.set_pin(cast["u1"], mid, True)                       # oddiy foydalanuvchi o'z xabarini ham pin qila olmaydi
    _, shared = svc.set_pin(cast["adm"], mid, True)
    assert shared and [p["id"] for p in svc.group_pins()][-1] == mid
    svc.set_pin(cast["adm"], mid, True)                          # takror — xato emas, ikkilanmaydi
    assert [p["id"] for p in svc.group_pins()].count(mid) == 1
    with pytest.raises(ChatError):
        svc.set_pin(cast["u1"], mid, False)                      # unpin ham faqat admin
    svc.set_pin(cast["adm"], mid, False)
    assert mid not in [p["id"] for p in svc.group_pins()]


def test_deleted_message_not_listed(cast):
    mid = messages.create(cast["u1"]["id"], "o'chadi", time.time())
    svc.set_pin(cast["adm"], mid, True)
    chat.delete(cast["u1"], mid)
    assert mid not in [p["id"] for p in svc.group_pins()]


def test_dm_pin_is_personal(cast):
    a, b, c = cast["u1"], cast["u2"], cast["u3"]
    mid = messages.create(a["id"], "lichka", time.time(), recipient_id=b["id"])
    _, shared = svc.set_pin(a, mid, True)
    assert not shared
    assert [p["id"] for p in svc.dm_pins(a, b["id"])] == [mid]   # pin qo'ygan tomon ko'radi
    assert svc.dm_pins(b, a["id"]) == []                         # suhbatdosh ko'rmaydi
    svc.set_pin(b, mid, True)                                    # u ham o'zi uchun pin qila oladi
    svc.set_pin(a, mid, False)
    assert svc.dm_pins(a, b["id"]) == [] and [p["id"] for p in svc.dm_pins(b, a["id"])] == [mid]
    with pytest.raises(ChatError):
        svc.set_pin(c, mid, True)                                # begona kirita olmaydi
    assert svc.group_pins() == [] or mid not in [p["id"] for p in svc.group_pins()]


def test_dm_pin_for_both(cast):
    """«Suhbatdosh uchun ham» belgilansa pin ikkala tomonda ko'rinadi; olib tashlash ham ikkalasidan."""
    a, b = cast["u1"], cast["u2"]
    mid = messages.create(a["id"], "lichka", time.time(), recipient_id=b["id"])
    svc.set_pin(a, mid, True, both=True)
    assert [p["id"] for p in svc.dm_pins(a, b["id"])] == [mid]
    assert [p["id"] for p in svc.dm_pins(b, a["id"])] == [mid]
    svc.set_pin(a, mid, False, both=True)
    assert svc.dm_pins(a, b["id"]) == [] and svc.dm_pins(b, a["id"]) == []
