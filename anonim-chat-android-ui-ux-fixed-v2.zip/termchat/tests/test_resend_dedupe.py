"""Yomon internet: mijoz xabarni qayta yuborsa (bir xil cid), server uni IKKI MARTA saqlamaydi; yuboruvchiga avvalgisini qaytaradi."""
import asyncio

import pytest

from app.api import ws as W
from app.errors import ChatError


@pytest.fixture(autouse=True)
def clean():
    W._SEEN.clear()
    yield
    W._SEEN.clear()


def run(coro):
    return asyncio.new_event_loop().run_until_complete(coro)


def setup(monkeypatch, fail=None):
    saved, delivered, direct = [], [], []

    def post_e2e(user, env, to, blob):
        if fail:
            raise fail
        saved.append(env)
        return {"type": "message", "id": len(saved), "to": to, "user": {"id": user["id"]}}

    async def deliver(row, msg):
        delivered.append(msg["id"])

    async def send_to(uid, payload):
        direct.append((uid, payload))

    monkeypatch.setattr(W.chat, "post_e2e", post_e2e)
    monkeypatch.setattr(W, "deliver", deliver)
    monkeypatch.setattr(W.webpush, "fire", lambda *a, **k: None)
    monkeypatch.setattr(W.activity, "record", lambda *a, **k: None)
    monkeypatch.setattr(W.manager, "send_to", send_to)
    return saved, delivered, direct


def test_duplicate_is_not_saved_twice(monkeypatch):
    saved, delivered, direct = setup(monkeypatch)
    u = {"id": 7}
    pkt = {"type": "send", "e2e": "ENV", "cid": "abcdef0123456789"}
    run(W._handle(u, dict(pkt), "t", "1.1.1.1"))
    run(W._handle(u, dict(pkt), "t", "1.1.1.1"))
    assert saved == ["ENV"] and delivered == [1]
    assert direct == [(7, {"type": "message", "id": 1, "to": None, "user": {"id": 7}, "cid": "abcdef0123456789"})]


def test_without_cid_still_works(monkeypatch):
    saved, _, _ = setup(monkeypatch)
    run(W._handle({"id": 7}, {"type": "send", "e2e": "A"}, "t", "ip"))
    run(W._handle({"id": 7}, {"type": "send", "e2e": "A"}, "t", "ip"))
    assert saved == ["A", "A"]


def test_other_user_same_cid_is_independent(monkeypatch):
    saved, _, _ = setup(monkeypatch)
    pkt = {"type": "send", "e2e": "X", "cid": "abcdef0123456789"}
    run(W._handle({"id": 1}, dict(pkt), "t", "ip"))
    run(W._handle({"id": 2}, dict(pkt), "t", "ip"))
    assert len(saved) == 2


def test_rule_rejection_sends_final_nack(monkeypatch):
    _, _, direct = setup(monkeypatch, fail=ChatError("muted"))
    run(W._handle({"id": 7}, {"type": "send", "e2e": "A", "cid": "abcdef0123456789"}, "t", "ip"))
    assert direct[0] == (7, {"type": "nack", "cid": "abcdef0123456789", "final": True})


def test_server_error_nack_is_retryable_and_not_marked_seen(monkeypatch):
    _, _, direct = setup(monkeypatch, fail=RuntimeError("db"))
    run(W._handle({"id": 7}, {"type": "send", "e2e": "A", "cid": "abcdef0123456789"}, "t", "ip"))
    assert direct[0][1] == {"type": "nack", "cid": "abcdef0123456789", "final": False}
    assert (7, "abcdef0123456789") not in W._SEEN
