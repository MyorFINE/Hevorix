"""python tests/call_server_test.py — qo'ng'iroq signalizatsiyasi (fastapi'siz): faqat ikki ishtirokchi, band, qurilmaga bog'lash, hajm tekshiruvi."""
import asyncio, json, os, sys, tempfile
os.environ.update(TERMCHAT_DATA_DIR=tempfile.mkdtemp(prefix="call-"), TERMCHAT_MASTER_KEY="z" * 32)
sys.path.insert(0, ".")
from app.db import db
from app.realtime import callhub
from app.realtime.manager import manager
from app.services.calls import book, CallError


class WS:
    def __init__(self, name): self.name, self.got = name, []
    async def send_text(self, t): self.got.append(json.loads(t))
    async def close(self, code=1000): pass
    def last(self, op=None):
        xs = [m for m in self.got if m.get("type") == "call" and (op is None or m["op"] == op)]
        return xs[-1] if xs else None


def user(i): return {"id": i, "nickname": f"U{i}", "username": f"u{i}"}


async def main():
    for i in range(1, 6):
        db.run("INSERT INTO users(id,username,nickname,password_hash,created_at) VALUES(?,?,?,?,1)", (i, f"u{i}", f"U{i}", "x"))
    a, b1, b2, c, d = WS("a"), WS("b1"), WS("b2"), WS("c"), WS("d")
    for uid, ws in ((1, a), (2, b1), (2, b2), (3, c), (4, d)):
        manager.connect(uid, ws)
    H = callhub.handle

    # 1) boshlash
    await H(user(1), {"op": "start", "to": 2}, a)
    cid = a.last("started")["id"]
    assert b1.last("incoming")["id"] == b2.last("incoming")["id"] == cid and b1.last("incoming")["from"] == 1
    # o'ziga / yo'q foydalanuvchiga / band
    await H(user(1), {"op": "start", "to": 1}, a); assert a.last("error")["code"] in ("self", "busy_self")
    await H(user(4), {"op": "start", "to": 2}, d); assert d.last("error")["code"] == "busy", d.got
    await H(user(4), {"op": "start", "to": 99}, d); assert d.last("error")["code"] == "gone"
    # 2) uchinchi shaxs aralasha olmaydi
    for op in ("accept", "end", "kex", "offer", "ice", "rebind"):
        c.got.clear(); await H(user(3), {"op": op, "id": cid, "pub": "x", "sdp": "x"}, c)
        assert c.last("error")["code"] == "gone", (op, c.got)
    assert book.get(cid, 1) is not None
    # 3) qabul qilishdan oldin signal yo'q; chaqiruvchi qabul qila olmaydi
    await H(user(1), {"op": "kex", "id": cid, "pub": "AAAA"}, a); assert a.last("error")["code"] == "state"
    await H(user(1), {"op": "accept", "id": cid}, a); assert a.last("error")["code"] == "role"
    # 4) callee b1 qabul qiladi: b2 da jiringlash to'xtaydi, a "accepted" oladi
    await H(user(2), {"op": "accept", "id": cid}, b1)
    assert a.last("accepted")["id"] == cid and b2.last("ended")["reason"] == "other" and b1.last("ended") is None
    # 5) uzatish: faqat bog'langan ws'lardan
    await H(user(1), {"op": "kex", "id": cid, "pub": "QUJD"}, a); assert b1.last("kex")["pub"] == "QUJD" and b2.last("kex") is None
    await H(user(2), {"op": "confirm", "id": cid, "mac": "m"}, b1); assert a.last("confirm")["mac"] == "m"
    n = len(a.got); await H(user(2), {"op": "confirm", "id": cid, "mac": "x"}, b2); assert len(a.got) == n, "bog'lanmagan qurilma uzata olmaydi"
    await H(user(2), {"op": "offer", "id": cid, "sdp": "v=0"}, b1); assert a.last("offer")["sdp"] == "v=0"
    await H(user(1), {"op": "ice", "id": cid, "c": "candidate:1 1 udp", "mid": "0", "idx": 0}, a); assert b1.last("ice")["c"].startswith("candidate")
    await H(user(1), {"op": "ice", "id": cid, "c": None}, a); assert b1.last("ice")["c"] is None
    # 6) noto'g'ri/katta signallar; qo'shimcha maydonlar uzatilmaydi
    await H(user(1), {"op": "offer", "id": cid, "sdp": "x" * 20000}, a); assert a.last("error")["code"] == "bad"
    await H(user(1), {"op": "ice", "id": cid, "c": "x", "idx": 99}, a); assert a.last("error")["code"] == "bad"
    await H(user(1), {"op": "kex", "id": cid, "pub": "QQ", "evil": "<script>", "to": 3}, a)
    assert "evil" not in b1.last("kex") and b1.last("kex")["id"] == cid
    await H(user(1), {"op": "zzz", "id": cid}, a); assert a.last("error")["code"] == "bad"
    # 7) qayta ulanish (rebind): yangi ws bog'lanadi
    a2 = WS("a2"); manager.connect(1, a2)
    await H(user(1), {"op": "rebind", "id": cid}, a2); assert a2.last("rebound")["state"] == "active"
    await H(user(2), {"op": "kex", "id": cid, "pub": "ZZ"}, b1); assert a2.last("kex")["pub"] == "ZZ"
    # 8) tugatish: ikkala tomonga, keyin id yaroqsiz
    await H(user(2), {"op": "end", "id": cid}, b1)
    assert a2.last("ended")["reason"] == "hangup" and b1.last("ended")["reason"] == "hangup" and book.count() == 0
    await H(user(1), {"op": "kex", "id": cid, "pub": "QQ"}, a2); assert a2.last("error")["code"] == "gone"
    # 9) rad etish (ringing paytida callee end)
    await H(user(3), {"op": "start", "to": 4}, c); c2 = c.last("started")["id"]
    await H(user(4), {"op": "end", "id": c2}, d); assert c.last("ended")["reason"] == "declined"
    # 10) javobsiz tugash va ringing paytida chaqiruvchi uzilishi
    await H(user(3), {"op": "start", "to": 4}, c); c3 = c.last("started")["id"]
    await callhub._ring_timeout(c3); assert c.last("ended")["reason"] == "noanswer" and book.count() == 0
    await H(user(3), {"op": "start", "to": 4}, c); await callhub.on_disconnect(3, c)
    assert d.last("ended")["reason"] == "drop" and book.count() == 0
    # 11) push orqali ochilganda jiringlayotgan qo'ng'iroq yetkaziladi
    await H(user(5), {"op": "start", "to": 4}, WS("e")); d.got.clear()
    await callhub.on_connect(4, d); assert d.last("incoming")["from"] == 5
    print("qo'ng'iroq serveri: hammasi o'tdi")

asyncio.run(main())
