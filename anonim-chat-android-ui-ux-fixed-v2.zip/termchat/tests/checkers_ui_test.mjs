// Node: shashka interfeysi (frontend/js/app/97b-checkers.js) — soxta DOM bilan: bot o'yini, yurish tanlash, orqaga, taslim, saqlash.
// Ishlatish: node tests/checkers_ui_test.mjs
import fs from "node:fs"; import vm from "node:vm"; import assert from "node:assert/strict";

class Node_ { constructor(t) { this.nodeType = t; this.parentNode = null; } }
class Text_ extends Node_ { constructor(s) { super(3); this.data = s; } get textContent() { return this.data; } }
class El extends Node_ {
  constructor(tag) { super(1); this.tag = tag; this.children = []; this.attrs = {}; this.listeners = {}; this.dataset = {}; this.style = {}; this._cls = new Set(); this.scrollLeft = 0; this.offsetLeft = 0; this.offsetWidth = 0; this.clientWidth = 0; this.disabled = false;
    const self = this; this.classList = {add: (...c) => c.forEach(x => self._cls.add(x)), remove: (...c) => c.forEach(x => self._cls.delete(x)), contains: c => self._cls.has(c),
      toggle: (c, f) => { const on = f === undefined ? !self._cls.has(c) : !!f; on ? self._cls.add(c) : self._cls.delete(c); return on; }}; }
  set className(v) { this._cls = new Set(String(v).split(/\s+/).filter(Boolean)); } get className() { return [...this._cls].join(" "); }
  setAttribute(k, v) { this.attrs[k] = v; } addEventListener(t, f) { (this.listeners[t] = this.listeners[t] || []).push(f); }
  append(...k) { for (let c of k) { if (typeof c === "string") { c = new Text_(c); } c.parentNode = this; this.children.push(c); } }
  remove() { if (this.parentNode) { this.parentNode.children = this.parentNode.children.filter(c => c !== this); this.parentNode = null; } }
  get isConnected() { let n = this; while (n.parentNode) n = n.parentNode; return n === document.body; }
  set textContent(v) { this.children.forEach(c => c.parentNode = null); this.children = []; if (v) this.append(new Text_(String(v))); }
  get textContent() { return this.children.map(c => c.textContent).join(""); }
  getBoundingClientRect() { return {left: 0, top: 0, width: 800, height: 800}; }
  setPointerCapture() {} querySelectorAll() { return []; }
}
const document = {body: new El("body"), createElement: t => new El(t), createTextNode: s => new Text_(s), querySelectorAll: () => []};
document.body.parentNode = null;
const store = {};
Object.assign(globalThis, {document, window: globalThis, self: globalThis, requestAnimationFrame: f => setTimeout(() => f(performance.now()), 5),
  localStorage: {getItem: k => (k in store ? store[k] : null), setItem: (k, v) => { store[k] = String(v); }, removeItem: k => { delete store[k]; }}});
const toasts = [];
Object.assign(globalThis, {
  S: {me: {id: 1}, members: [], offline: true, tab: "x", users: new Map()}, NAV_CLOSE: {}, navPush() {}, navPop() {}, haptic() {}, renderList() {}, wsTry: () => true,
  toast: (t) => toasts.push(t), confirmDlg: async () => true, isOnline: () => false, U: id => ({id, nickname: "Men", username: "men"}), avatar: () => new El("div"), nameEl: () => new El("span"), api: async () => ({}),
  Gaming: {snd: new Proxy({}, {get: () => () => {}}), sndOn: () => true},
  h(tag, props, ...kids) {
    const e = new El(tag);
    if (props) for (const [k, v] of Object.entries(props)) { if (v == null || v === false) continue; if (k === "class") e.className = v; else if (k === "text") e.textContent = v; else if (k.startsWith("on")) e.addEventListener(k.slice(2), v); else e.setAttribute(k, v === true ? "" : v); }
    for (const c of kids.flat()) { if (c == null || c === false) continue; e.append(c.nodeType ? c : String(c)); }
    return e;
  }});
vm.runInThisContext(fs.readFileSync(new URL("../app/static/js/checkers.js", import.meta.url), "utf8"));
assert.ok(globalThis.TCDraughts);
vm.runInThisContext(fs.readFileSync(new URL("../frontend/js/app/97b-checkers.js", import.meta.url), "utf8") + "\nglobalThis.Checkers = Checkers;");

const find = (el, pred, out = []) => { if (el.nodeType === 1) { if (pred(el)) out.push(el); el.children.forEach(c => find(c, pred, out)); } return out; };
const byText = (root, t) => find(root, e => e.tag === "button" && e.textContent.includes(t))[0];
const click = el => { assert.ok(el, "tugma topilmadi"); el.listeners.click.forEach(f => f({currentTarget: el, target: el})); };
const ptr = (board, type, sq, extra = {}) => {
  const f = sq.charCodeAt(0) - 97, r = +sq[1] - 1, x = f, y = 7 - r;   // oq tomondan
  (board.listeners[type] || []).forEach(fn => fn({clientX: (x + .5) * 100, clientY: (y + .5) * 100, button: 0, pointerId: 1, preventDefault() {}, ...extra}));
};
const sleep = ms => new Promise(r => setTimeout(r, ms));
const movesSaved = () => JSON.parse(store.tc_offck || "{\"moves\":[]}").moves;

store.tc_offck_cfg = JSON.stringify({level: 1, side: "w"});
Checkers.openFromPush();
const root = () => document.body.children.find(c => c.attrs && c.className.includes("ck"));
assert.ok(root(), "ekran ochilmadi");
click(byText(root(), "Bot bilan o'ynash"));
click(byText(root(), "O'yinni boshlash"));
let board = find(root(), e => e.className.includes("gm-board"))[0];
assert.ok(board, "taxta chizilmadi");
assert.equal(find(root(), e => e.className.includes("gp")).length, 24, "24 ta tosh bo'lishi kerak");

// c3 -> d4: tanlash va yurish; bot javob beradi
ptr(board, "pointerdown", "c3"); ptr(board, "pointerup", "c3");
assert.ok(find(root(), e => e.className.includes("sq") && e.className.includes("tg")).length === 2, "c3 uchun 2 ta nishon (b4, d4)");
ptr(board, "pointerdown", "d4");
assert.deepEqual(movesSaved(), ["c3d4"]);
await sleep(1600);
assert.equal(movesSaved().length, 2, "bot javob yurishi kerak");

// noqonuniy bosish yurish bermaydi
ptr(board, "pointerdown", "a1"); ptr(board, "pointerdown", "h8");
assert.equal(movesSaved().length, 2);

// orqaga: ikkala yurish ham qaytariladi
click(byText(root(), "Orqaga"));
assert.equal(movesSaved().length, 0, "orqaga bosilganda boshlang'ich holat");
board = find(root(), e => e.className.includes("gm-board"))[0];
assert.equal(find(root(), e => e.className.includes("gp")).length, 24);

// majburiy urish: majburiy bo'lmasa oddiy yurish; yopib qayta ochganda o'yin saqlanadi
ptr(board, "pointerdown", "e3"); ptr(board, "pointerdown", "f4");
await sleep(1600);
const n = movesSaved().length; assert.equal(n, 2);
click(find(root(), e => e.attrs["aria-label"] === "Yopish")[0]);
assert.ok(!root(), "ekran yopilishi kerak");
Checkers.openFromPush();
assert.equal(find(root(), e => e.className.includes("gp")).length, 24, "saqlangan o'yin tiklanishi kerak");
assert.equal(movesSaved().length, 2);

// taslim: natija kartasi chiqadi, saqlangan o'yin o'chadi
click(byText(root(), "Taslim"));
await sleep(50);
assert.ok(find(root(), e => e.className.includes("go-card")).length === 1, "natija kartasi");
assert.ok(!store.tc_offck, "tugagan o'yin saqlanmasligi kerak");
assert.deepEqual(JSON.parse(store.tc_offck_stat), {w: 0, l: 1, d: 0});
console.log("OK shashka interfeysi (bot, tanlash, orqaga, saqlash, taslim)");

// ---- online rejim: server holati -> yurish xabari ----
const sent = []; globalThis.wsTry = o => { sent.push(o); return true; };
click(byText(root(), "Yopish")); 
const E = globalThis.TCDraughts, pos = new E.Pos();
const mkState = (hist, plies, last) => ({type: "ck_state", gid: "g1", white: 1, black: 2, board: pos.boardString(), turn: pos.turn === 1 ? "w" : "b", plies, last,
  legal: pos.legalMap(), clock: {w: 600000, b: 600000, turn: pos.turn === 1 ? "w" : "b", running: true}, base: {w: 0, b: 0}, hist, over: null});
Checkers.onWs(mkState([], 0, null));
assert.ok(root(), "online o'yin ekrani ochilishi kerak");
board = find(root(), e => e.className.includes("gm-board"))[0];
ptr(board, "pointerdown", "c3"); ptr(board, "pointerdown", "b4");
const mv = sent.find(o => o.type === "ck_move");
assert.deepEqual(JSON.parse(JSON.stringify(mv)), {type: "ck_move", gid: "g1", path: ["c3", "b4"]});
// raqib yurishi keladi: b4 -> qora a5? avval server holatini yangilaymiz
pos.make(pos.find(["c3", "b4"])); const bm = pos.find(["b6", "a5"]); pos.make(bm);
Checkers.onWs(mkState(["c3b4", "b6a5"], 2, {path: ["b6", "a5"], caps: [], promo: false}));
await sleep(50);
assert.equal(find(root(), e => e.className.includes("gp")).length, 24);
Checkers.onWs({type: "ck_over", gid: "g1"});
const over = mkState(["c3b4", "b6a5"], 2, null); over.over = {result: "w", reason: "resign", rated: true, pts: {w: 10, b: 0}, total: {w: 10, b: 0}}; over.legal = {};
Checkers.onWs(over);
await sleep(1100);
assert.equal(find(root(), e => e.className.includes("go-card")).length, 1, "online natija kartasi");
console.log("OK online rejim (holat, yurish xabari, natija)");

process.exit(0);
