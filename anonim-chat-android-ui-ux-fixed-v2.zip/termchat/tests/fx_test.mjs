// Node: v11 element uslublari — app.js dan yordamchi funksiyalar ajratib olinib, minimal soxta DOM bilan sinaladi.
import fs from "node:fs";
import assert from "node:assert/strict";

class N { constructor(t) { this.tag = t; this._c = []; this.attrs = {}; this.set = new Set(); this.style = {props: {}, setProperty(k, v) { this.props[k] = v; }}; this._t = "";
    const self = this; this.classList = {add: (...c) => c.forEach(x => self.set.add(x)), remove: (...c) => c.forEach(x => self.set.delete(x)), contains: c => self.set.has(c)}; }
  set className(v) { this.set = new Set(String(v).split(/\s+/).filter(Boolean)); } get className() { return [...this.set].join(" "); }
  set textContent(v) { this._t = String(v); this._c = []; } get textContent() { return this._t + this._c.map(c => c.textContent).join(""); }
  append(...k) { for (const c of k) this._c.push(c); } setAttribute(k, v) { this.attrs[k] = v; } get offsetWidth() { return 1; } }
globalThis.document = {createElement: t => new N(t), createElementNS: (n, t) => new N(t), createTextNode: t => ({nodeType: 3, textContent: String(t)})};
let reduced = false;
globalThis.matchMedia = () => ({get matches() { return reduced; }});
const timers = []; globalThis.setTimeout = (f, ms) => { timers.push([f, ms]); return timers.length; }; globalThis.clearTimeout = () => {};

const src = fs.readFileSync(new URL("../app/static/js/app.js", import.meta.url), "utf8");
const cut = (from, to) => { const a = src.indexOf(from), b = src.indexOf(to, a); assert.ok(a >= 0 && b > a, "topilmadi: " + from); return src.slice(a, b); };
const code = cut("function h(tag, props", "const icon =") + "\n" + cut("const BANNERS = ", "const bannerCls") + "\nreturn {FX, FX_AREAS, fxOf, fxMap, fxText, fxWave, fxBubble, fxPlay, pageCls, h};";
const M = new Function(code)();
const {FX, FX_AREAS, fxOf, fxMap, fxText, fxWave, fxBubble, fxPlay, pageCls, h} = M;

// 1) ro'yxatlar spetsifikatsiyaga mos
assert.deepEqual(FX_AREAS, ["nick", "user", "bio", "page", "reply", "link"]);
assert.equal(FX.nick.items.length, 10); assert.ok(FX.nick.items.some(x => x[0] === "wave"));
assert.ok(!FX.user.items.some(x => x[0] === "wave")); assert.equal(FX.user.items.length, 9);
assert.equal(FX.bio.items.length, 7); assert.equal(FX.bio.items.at(-1)[0], "breathe");
assert.equal(FX.msg, undefined); assert.equal(FX.reply.items.length, 4); assert.equal(FX.link.items.length, 4);
assert.equal(FX.page.items.length, 3);

// 2) fxOf: faqat tayyor nomlar; o'chirilgan akkaunt, noto'g'ri qiymat, boshqa element nomi — e'tiborga olinmaydi
assert.equal(fxOf({fx: {nick: "aurora"}}, "nick"), "aurora");
assert.equal(fxOf({fx: {nick: "aurora"}}, "bio"), null);
assert.equal(fxOf({fx: {user: "wave"}}, "user"), null);
assert.equal(fxOf({fx: {nick: "#ff0000"}}, "nick"), null);
assert.equal(fxOf({fx: {nick: "red;x:y"}}, "nick"), null);
assert.equal(fxOf({deleted: true, fx: {nick: "aurora"}}, "nick"), null);
assert.equal(fxOf({}, "nick"), null); assert.equal(fxOf(null, "nick"), null); assert.equal(fxOf({fx: "aurora"}, "nick"), null);
assert.equal(fxMap({fx: {reply: "tint"}}).reply, "tint"); assert.equal(fxMap({fx: {reply: "tint"}}).nick, "");
// Eski «msg» qiymati (drop) endi ham yaroqsiz; faqat missiya sovg'asi (x_ bilan boshlanadigan) qabul qilinadi
assert.equal(fxMap({fx: {msg: "drop"}}).msg, ""); assert.equal(fxOf({fx: {msg: "drop"}}, "msg"), null);
assert.equal(fxOf({fx: {msg: "x_glow"}}, "msg"), "x_glow"); assert.equal(fxOf({fx: {avatar: "x_spin"}}, "avatar"), "x_spin");
assert.equal(fxOf({fx: {nick: "x_neon"}}, "nick"), "x_neon"); assert.equal(fxOf({fx: {msg: "x_spin"}}, "msg"), null);
assert.equal(fxMap({fx: {msg: "x_flow", avatar: "x_pulse"}}).msg, "x_flow");

// 3) «animatsiyani kamaytirish»: hamma effekt o'chadi
reduced = true;
assert.equal(fxOf({fx: {nick: "aurora"}}, "nick"), null); assert.equal(pageCls({fx: {page: "stars"}}), "");
reduced = false;
assert.equal(pageCls({fx: {page: "stars"}}), " fxp-stars"); assert.equal(pageCls({}), "");

// 4) klasslar
let el = fxText(h("span", {class: "nt"}), "gold"); assert.ok(el.set.has("fxt") && el.set.has("fxg-gold"));
el = fxText(h("span", {class: "nt"}), "glitch"); assert.ok(el.set.has("fxa-glitch") && !el.set.has("fxt"));
el = fxText(h("span", {class: "nt"}), "breathe"); assert.ok(el.set.has("fxa-breathe"));
el = fxText(h("span", {class: "nt"}), null); assert.equal(el.set.size, 1);
const b = fxBubble(h("div", {class: "bubble"}), {fx: {msg: "spin", link: "pill"}});
assert.ok(b.set.has("fxl-pill") && ![...b.set].some(c => c.startsWith("fxm-")));
assert.equal(fxBubble(h("div", {class: "bubble"}), {fx: {}}).set.size, 1);

// 5) «To'lqin»: har bir harf alohida element, matn o'zgarmaydi
const nt = fxWave(h("span", {class: "nt"}), "Ali Vali");
assert.equal(nt._c.length, 8); assert.equal(nt.textContent, "Ali Vali"); assert.equal(nt.attrs["aria-label"], "Ali Vali");
assert.equal(nt._c[3].textContent, " "); assert.equal(nt._c[2].style.props["--i"], "2");

// 6) xabar effekti faqat vaqtincha: fxgo qo'yiladi, keyin olinadi
const row = h("div", {class: "row"});
fxPlay(row); assert.ok(row.set.has("fxgo"));
const [fn, ms] = timers.at(-1); assert.ok(ms >= 1500); fn(); assert.ok(!row.set.has("fxgo"));
console.log("fx_test: OK");
