// node tests/call_crypto_test.mjs — qo'ng'iroq kriptografiyasi: kalit kelishuvi, parol, kadr shifri, replay, to'ldirish, SDP
import assert from "node:assert/strict";
import { webcrypto } from "node:crypto";
globalThis.crypto ??= webcrypto;
await import("../app/static/js/callcrypto.js");
const C = globalThis.CallCrypto;
const id = "testcall123";

const a = await C.newKex(), b = await C.newKex();
const A = await C.deriveSession({priv: a.priv, myPubRaw: a.pubRaw, peerPub: b.pub, password: "kelishilgan-parol", callId: id, role: "caller"});
const B = await C.deriveSession({priv: b.priv, myPubRaw: b.pubRaw, peerPub: a.pub, password: " kelishilgan-parol ", callId: id, role: "callee"});   // chetdagi bo'sh joy e'tiborsiz
assert.equal(A.sas, B.sas, "SAS bir xil");
assert.ok(await C.checkConfirm(A, await C.makeConfirm(B)), "callee tasdig'i caller'da to'g'ri");
assert.ok(await C.checkConfirm(B, await C.makeConfirm(A)), "caller tasdig'i callee'da to'g'ri");
assert.ok(!(await C.checkConfirm(A, await C.makeConfirm(A))), "o'z tasdig'ini qaytarib yuborish (reflection) o'tmaydi");

// noto'g'ri parol -> tasdiq mos kelmaydi
const W = await C.deriveSession({priv: b.priv, myPubRaw: b.pubRaw, peerPub: a.pub, password: "boshqa-parol", callId: id, role: "callee"});
assert.ok(!(await C.checkConfirm(A, await C.makeConfirm(W))), "noto'g'ri parol rad etiladi");
assert.ok(!(await C.checkConfirm(W, await C.makeConfirm(A))));
assert.notEqual(A.sas, W.sas);

// MITM (boshqa ECDH kaliti, parol yo'q) -> tasdiq mos kelmaydi
const m = await C.newKex();
const M = await C.deriveSession({priv: m.priv, myPubRaw: m.pubRaw, peerPub: a.pub, password: "taxmin", callId: id, role: "callee"});
assert.ok(!(await C.checkConfirm(A, await C.makeConfirm(M))));

// kadr shifri: caller -> callee
const tx = C.makeCipher(A.send), rx = C.makeCipher(B.recv);
const sizes = new Set();
for (const n of [0, 1, 5, 60, 90, 150, 158, 159, 300]) {
  const data = new Uint8Array(n).map((_, i) => (i * 7 + n) & 255);
  const f = await tx.seal(data); sizes.add(f.length);
  assert.deepEqual([...(await rx.open(f))], [...data]);
}
assert.ok([...sizes].every(s => [8 + 160 + 16, 8 + 320 + 16].includes(s)), "o'lchamlar faqat bucket: " + [...sizes]);
// sukunat va nutq bir xil hajm
const s1 = await tx.seal(new Uint8Array(3)), s2 = await tx.seal(new Uint8Array(100));
assert.equal(s1.length, s2.length);
// replay va buzish
const f = await tx.seal(new Uint8Array([1, 2, 3]));
assert.ok(await rx.open(f)); assert.equal(await rx.open(f), null, "replay tashlanadi");
const g = await tx.seal(new Uint8Array([9, 9])); g[20] ^= 1; assert.equal(await rx.open(g), null, "buzilgan kadr tashlanadi");
// teskari yo'nalish kaliti bilan ochilmaydi (reflection)
const h = await tx.seal(new Uint8Array([4])); assert.equal(await C.makeCipher(A.recv).open(h), null);
// noto'g'ri parol bilan ochib bo'lmaydi
assert.equal(await C.makeCipher(W.recv).open(await tx.seal(new Uint8Array([1]))), null);
// callee -> caller
const tx2 = C.makeCipher(B.send), rx2 = C.makeCipher(A.recv);
assert.deepEqual([...(await rx2.open(await tx2.seal(new Uint8Array([5, 6]))))], [5, 6]);
// ikki tomonning IV'lari to'qnashmaydi (prefikslar farqli)
assert.notDeepEqual([...A.send.ivPrefix], [...B.send.ivPrefix]);
// cover shifri
const cv = C.makeCipher(A.cover); const cf = await cv.seal(new Uint8Array(200), 300); assert.equal(cf.length, 8 + 300 + 16);
// bir xil hisoblagichli takroriy kadr takrorlanmasin (counter oshadi)
const c1 = await tx.seal(new Uint8Array(1)), c2 = await tx.seal(new Uint8Array(1));
assert.notDeepEqual([...c1.subarray(0, 8)], [...c2.subarray(0, 8)]);

// SDP
const sdp = ["v=0", "m=audio 9 UDP/TLS/RTP/SAVPF 111 63", "a=extmap:1 urn:ietf:params:rtp-hdrext:ssrc-audio-level", "a=extmap:2 urn:ietf:params:rtp-hdrext:sdes:mid",
  "a=rtpmap:111 opus/48000/2", "a=fmtp:111 minptime=10;useinbandfec=1;usedtx=1", ""].join("\r\n");
const out = C.hardenSdp(sdp);
assert.ok(!out.includes("ssrc-audio-level") && out.includes("sdes:mid"));
assert.match(out, /a=fmtp:111 .*usedtx=0/); assert.match(out, /cbr=1/); assert.ok(!/usedtx=1/.test(out)); assert.match(out, /minptime=10/);
const bare = C.hardenSdp("m=audio 9 RTP/AVP 111\r\na=rtpmap:111 opus/48000/2\r\n");
assert.match(bare, /a=fmtp:111 usedtx=0/);

const plan = C.coverPlan(Math.random); assert.ok(plan.delayMs >= 30 && plan.size >= 48);
console.log("call crypto: hammasi o'tdi (SAS", A.sas + ")");
