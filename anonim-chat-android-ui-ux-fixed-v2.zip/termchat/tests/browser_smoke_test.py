import json
import mimetypes
import os
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
try:
    from playwright.sync_api import sync_playwright
    HAVE = True
except Exception:
    HAVE = False

CSP = ("default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self' data: blob:; media-src 'self' blob:; font-src 'self'; "
       "connect-src 'self' ws: wss:; manifest-src 'self'; object-src 'none'; frame-src 'none'; worker-src 'self'; "
       "frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
DUMP = """() => { const out = {}; let k = 0;
  for (const el of document.querySelectorAll('*')) { const cs = getComputedStyle(el), o = [];
    if (el.tagName === 'SCRIPT' || el.id === 'instProg') continue;   // instProg: stroke-dashoffset'ni install.js taymer bilan yozadi (vaqtga bog'liq)
    if (false) continue;                       // yangi js/virtual.js tegi — ataylab qo'shilgan
    for (const p of cs) o.push(p + ':' + cs.getPropertyValue(p)); out[k++ + ':' + el.tagName + '#' + el.id + '.' + el.className] = o.sort().join(';'); }
  return out; }"""


def open_page(br, static: Path, render):
    pg = br.new_page(viewport={"width": 420, "height": 800})
    errors = []
    pg.on("pageerror", lambda e: errors.append("pageerror: %s" % e))
    pg.on("console", lambda m: errors.append("console.%s: %s" % (m.type, m.text)) if m.type in ("error", "warning") and "404" not in m.text else None)

    def handle(route):
        path = route.request.url.split("app.test", 1)[1].split("?")[0]
        if path == "/":
            return route.fulfill(body=render(static), content_type="text/html; charset=utf-8", headers={"Content-Security-Policy": CSP})
        if path.startswith("/static/"):
            f = static / path[len("/static/"):]
            if f.is_file():
                return route.fulfill(body=f.read_bytes(), content_type=mimetypes.guess_type(str(f))[0] or "application/octet-stream")
        return route.fulfill(status=404, body=json.dumps({"detail": "yo'q"}), content_type="application/json")
    pg.route("http://app.test/**", handle)
    pg.goto("http://app.test/")
    pg.wait_for_timeout(800)
    return pg, errors


@unittest.skipUnless(HAVE, "playwright yo'q")
class BrowserSmoke(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from app.sri import render_index
        cls.render = staticmethod(lambda static: render_index(static).encode("utf-8"))
        cls.pw = sync_playwright().start()
        cls.br = cls.pw.chromium.launch()

    @classmethod
    def tearDownClass(cls):
        cls.br.close()
        cls.pw.stop()

    def test_boots_without_errors_under_sri_and_csp(self):
        pg, errors = open_page(self.br, ROOT / "app" / "static", self.render)
        self.addCleanup(pg.close)
        bad = [e for e in errors if "Failed to load resource" not in e]
        self.assertEqual(bad, [], "brauzer xatolari: %s" % bad)
        self.assertEqual(pg.evaluate("typeof window.__vlist"), "object", "virtual.js yuklanmadi")
        self.assertTrue(pg.evaluate("!!document.querySelector('form, #loginForm, .auth-card')"), "kirish ekrani chizilmadi")

    @unittest.skipUnless(os.environ.get("ORIG_STATIC"), "ORIG_STATIC berilmagan")
    def test_computed_styles_identical_to_original(self):
        new, _ = open_page(self.br, ROOT / "app" / "static", self.render)
        old, _ = open_page(self.br, Path(os.environ["ORIG_STATIC"]), self.render)
        self.addCleanup(new.close)
        self.addCleanup(old.close)
        for pg in (old, new):
            pg.evaluate("() => { const st = new CSSStyleSheet(); st.replaceSync('*,*::before,*::after{animation:none!important;transition:none!important}'); document.adoptedStyleSheets = [...document.adoptedStyleSheets, st]; }")
        a, b = old.evaluate(DUMP), new.evaluate(DUMP)
        self.assertEqual(list(a), list(b), "DOM tuzilishi farq qiladi")
        diff = [k for k in a if a[k] != b[k]]
        self.assertEqual(diff, [], "hisoblangan uslublar farq qiladi: %s" % diff[:5])
        print("  taqqoslandi: %d element, farq yo'q" % len(a))


if __name__ == "__main__":
    unittest.main()
