// Node: durak dvigateli va bot xulqi (kozerni saqlash). Ishlatish: node tests/durak_engine_test.mjs
import fs from "node:fs"; import vm from "node:vm"; import assert from "node:assert/strict";
const ctx = {Math, console}; ctx.self = ctx; vm.createContext(ctx);
vm.runInContext(fs.readFileSync(new URL("../app/static/js/durak.js", import.meta.url), "utf8"), ctx);
const T = ctx.TCDurak;
const isT = (s, c) => c[1] === s.trump;
function setup(hands, trump = "S") {
  // trump = "S": ostki karta ♠
  const s = new T.State(2); s.trump = trump; s.trumpCard = "6" + trump;
  s.hands = hands.map(h => h.slice()); s.deck = ["6" + trump, "7" + trump, "8" + trump, "9" + trump, "TC", "JC", "QC", "KC"]; s.att = 0; s.dfn = 1; s._startRound(); return s;
}
// 1) bot urishda boshqa karta bo'lsa kozerni ishlatmaydi
for (let k = 0; k < 200; k++) {
  const s = setup([["7H", "KD", "QC", "8D", "9C", "TC"], ["8H", "AS", "9S", "KH", "6D", "7C"]]);
  s.act(0, {t: "atk", c: "7H"});
  const a = T.botAct(s, 1);
  assert.equal(a.t, "def"); assert.equal(a.c, "8H", "eng past mos kartani ishlatishi kerak (kozerni emas)"); assert.ok(!isT(s, a.c));
}
// 2) faqat kozer bilan ura olsa — eng past kozerni ishlatadi (yoki ba'zan oladi), hech qachon yuqorisini emas
let usedTrump = 0, took = 0;
for (let k = 0; k < 300; k++) {
  const s = setup([["7H", "KD", "QC", "8D", "9C", "TC"], ["8D", "AS", "9S", "KC", "6D", "7C"]]);
  s.act(0, {t: "atk", c: "7H"});
  const a = T.botAct(s, 1);
  if (a.t === "def") { usedTrump++; assert.equal(a.c, "9S", "eng past kozerni ishlatishi kerak"); } else { assert.equal(a.t, "take"); took++; }
}
assert.ok(usedTrump > 0, "kozerni ishlatishi kerak");
// 3) urib bo'lmasa oladi
const s3 = setup([["AH", "KD", "QC", "8D", "9C", "TC"], ["6H", "7D", "9D", "KC", "6D", "7C"]]);
s3.act(0, {t: "atk", c: "AH"}); assert.equal(T.botAct(s3, 1).t, "take");
// 4) hujumda kozerni saqlaydi: avval kozer bo'lmagan eng past karta
const s4 = setup([["6S", "7S", "QH", "9D", "KC", "TH"], ["8H", "AS", "9S", "KH", "6D", "7C"]]);
for (let k = 0; k < 50; k++) assert.equal(T.botAct(s4, 0).c, "9D");
const s5 = setup([["6S", "7S", "8S", "9S", "TS", "JS"], ["8H", "AH", "9H", "KH", "6D", "7C"]]);
assert.equal(T.botAct(s5, 0).c, "6S", "faqat kozer bo'lsa eng pastini");
// 5) qo'shib tashlashda ham kozerni tashlamaydi
const s6 = setup([["7H", "7S", "KD", "9C", "TC", "JC"], ["8H", "AH", "9H", "KH", "6D", "7C"]]);
s6.act(0, {t: "atk", c: "7H"}); s6.act(1, {t: "def", c: "8H", i: 0});
const a6 = T.botAct(s6, 0); assert.ok(a6.t === "pass", "7♠ kozer — tashlamasligi kerak: " + JSON.stringify(a6));
console.log("OK durak dvigateli va bot (kozerni saqlaydi, " + usedTrump + " marta ishlatdi, " + took + " marta oldi)");
