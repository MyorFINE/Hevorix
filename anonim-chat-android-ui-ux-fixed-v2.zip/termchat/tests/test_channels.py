import base64
import json
import os
import time

import pytest

from app.errors import ChatError
from app.repositories import channels as repo
from app.repositories import users as users_repo
from app.security import hash_password
from app.repositories import e2ee as e2ee_repo
from app.services import channels as svc
from app.services import chat


def _user(name: str, role: str = "user"):
    uid = users_repo.create(name, name.title(), hash_password("x"), role, time.time())
    return users_repo.get(uid)


@pytest.fixture(scope="module")
def cast():
    sfx = str(int(time.time() * 1000))[-6:]
    return {"admin": _user(f"cadm{sfx}", "admin"), "a": _user(f"ca{sfx}"), "b": _user(f"cb{sfx}"), "sfx": sfx}


def test_only_admin_creates(cast):
    with pytest.raises(ChatError):
        svc.create(cast["a"], f"x_{cast['sfx']}", "Nom", False, None)


def test_public_channel_visible_to_all(cast):
    ch = svc.create(cast["admin"], f"pub_{cast['sfx']}", "Yangiliklar", False, None)
    assert ch["private"] is False and ch["can_manage"] is True
    assert ch["id"] in [c["id"] for c in svc.list_channels(cast["a"])]
    svc.get_visible(ch["id"], cast["b"])
    with pytest.raises(ChatError):
        svc.create(cast["admin"], f"pub_{cast['sfx']}", "Dublikat", False, None)


def test_private_hidden_until_password_join(cast):
    sfx = cast["sfx"]
    with pytest.raises(ChatError):
        svc.create(cast["admin"], f"prv_{sfx}", "Yopiq", True, "")
    ch = svc.create(cast["admin"], f"prv_{sfx}", "Yopiq", True, "sir1234")
    assert ch["private"] is True
    assert ch["id"] in [c["id"] for c in svc.list_channels(cast["admin"])]
    assert ch["id"] not in [c["id"] for c in svc.list_channels(cast["a"])]
    with pytest.raises(ChatError) as e:
        svc.get_visible(ch["id"], cast["a"])
    assert e.value.status == 404
    with pytest.raises(ChatError):
        svc.join(cast["a"], f"prv_{sfx}", "noto'g'ri")
    with pytest.raises(ChatError) as e2:
        svc.join(cast["a"], "mavjud_emas_kanal", "sir1234")
    assert e2.value.message == "Kanal topilmadi yoki parol noto'g'ri"
    j = svc.join(cast["a"], f"@PRV_{sfx}", "sir1234")
    assert j["joined"] is True and j["id"] == ch["id"]
    assert ch["id"] in [c["id"] for c in svc.list_channels(cast["a"])]
    assert ch["id"] not in [c["id"] for c in svc.list_channels(cast["b"])]
    aud = svc.audience(repo.get(ch["id"]))
    assert cast["a"]["id"] in aud and cast["admin"]["id"] in aud and cast["b"]["id"] not in aud
    svc.update(cast["admin"], ch["id"], password="yangi5678")
    assert ch["id"] not in [c["id"] for c in svc.list_channels(cast["a"])]
    svc.update(cast["admin"], ch["id"], private=False)
    assert ch["id"] in [c["id"] for c in svc.list_channels(cast["b"])]
    with pytest.raises(ChatError):
        svc.update(cast["a"], ch["id"], nickname="Hack")


def _b64u(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).decode().rstrip("=")


def _env(kind: str = "c", ep: int = 1) -> str:
    o = {"v": 1, "k": kind, "ep": ep, "n": _b64u(os.urandom(12)), "c": _b64u(os.urandom(40)), "s": _b64u(os.urandom(64))}
    return "e2e1:" + _b64u(json.dumps(o).encode())


@pytest.fixture(scope="module")
def epoch(cast):
    from app.db import db
    for k in ("admin", "a", "b"):
        db.run("UPDATE users SET ecdh_pub='AAAA', sign_pub='BBBB' WHERE id=?", (cast[k]["id"],))
        cast[k] = users_repo.get(cast[k]["id"])
    cur = e2ee_repo.current_epoch()
    if cur < 1:
        assert e2ee_repo.create_epoch(1, cast["admin"]["id"], _b64u(os.urandom(40)), [(cast["admin"]["id"], "w")], "init")
        cur = 1
    return cur


def test_posts_are_e2ee_messages(cast, epoch):
    ch = svc.create(cast["admin"], f"pc_{cast['sfx']}", "Post kanal", False, None)
    cid, row = ch["id"], repo.get(ch["id"])
    with pytest.raises(ChatError) as e:
        chat.post_channel_e2e(cast["a"], row, _env(ep=epoch))
    assert e.value.status == 403
    for bad in (_env("g", epoch), _env("d", 0), _env("c", epoch + 5), "ochiq matn"):
        with pytest.raises(ChatError):
            chat.post_channel_e2e(cast["admin"], row, bad)
    with pytest.raises(ChatError):
        chat.post_e2e(cast["admin"], _env("c", epoch), None)
    p = chat.post_channel_e2e(cast["admin"], row, _env(ep=epoch))
    assert p["ch"] == cid and p["to"] is None and p["views"] == 0 and p["comments"] == 0 and p["e2e"].startswith("e2e1:")
    assert all(not m.get("ch") for m in chat.history_page()[0])
    posts, more = svc.posts(cast["a"], cid)
    assert [x["id"] for x in posts] == [p["id"]] and more is False
    ch2 = svc.list_channels(cast["a"])[0]
    assert ch2["posts"] == 1 and ch2["last"]["id"] == p["id"]


def test_post_file_blob(cast, epoch):
    ch = svc.create(cast["admin"], f"pf_{cast['sfx']}", "Fayl kanal", False, None)
    row = repo.get(ch["id"])
    name = f"blob{time.time_ns()}.e2e"
    e2ee_repo.add_blob(name, cast["admin"]["id"], 321)
    p = chat.post_channel_e2e(cast["admin"], row, _env(ep=epoch), name)
    assert p["blob"]["url"].endswith(name) and p["blob"]["size"] == 321
    with pytest.raises(ChatError):
        chat.post_channel_e2e(cast["admin"], row, _env(ep=epoch), name)


def test_views_comments_edit_delete(cast, epoch):
    ch = svc.create(cast["admin"], f"vc_{cast['sfx']}", "Izoh kanal", False, None)
    cid, row = ch["id"], repo.get(ch["id"])
    p = chat.post_channel_e2e(cast["admin"], row, _env(ep=epoch))
    assert svc.mark_viewed(cast["a"], cid, [p["id"]])[1] == {p["id"]: 1}
    assert svc.mark_viewed(cast["a"], cid, [p["id"]])[1] == {}
    assert svc.mark_viewed(cast["b"], cid, [p["id"], 999999])[1] == {p["id"]: 2}
    assert svc.mark_viewed(cast["admin"], cid, [p["id"]])[1] == {}
    with pytest.raises(ChatError):
        svc.add_comment(cast["a"], cid, p["id"], "ochiq matn")
    with pytest.raises(ChatError):
        svc.add_comment(cast["a"], cid, p["id"], _env("g", epoch))
    _, c1, n1 = svc.add_comment(cast["a"], cid, p["id"], _env(ep=epoch))
    _, c2, n2 = svc.add_comment(cast["b"], cid, p["id"], _env(ep=epoch))
    assert (n1, n2) == (1, 2) and c1["user"]["id"] == cast["a"]["id"] and c1["e2e"].startswith("e2e1:") and "content" not in c1
    items, more = svc.comments(cast["b"], cid, p["id"])
    assert [c["id"] for c in items] == [c1["id"], c2["id"]] and more is False
    got = svc.posts(cast["a"], cid)[0][-1]
    assert got["views"] == 2 and got["comments"] == 2
    with pytest.raises(ChatError):
        svc.delete_comment(cast["b"], cid, p["id"], c1["id"])
    assert svc.delete_comment(cast["admin"], cid, p["id"], c1["id"])[1] == 1
    assert svc.delete_comment(cast["b"], cid, p["id"], c2["id"])[1] == 0
    chat.edit_e2e(cast["admin"], p["id"], _env(ep=epoch))
    with pytest.raises(ChatError):
        chat.edit_e2e(cast["a"], p["id"], _env(ep=epoch))
    with pytest.raises(ChatError):
        chat.edit_e2e(cast["admin"], p["id"], _env("g", epoch))
    svc.add_comment(cast["a"], cid, p["id"], _env(ep=epoch))
    with pytest.raises(ChatError):
        chat.delete(cast["a"], p["id"])
    assert chat.delete(cast["admin"], p["id"])["channel_id"] == cid
    assert repo.comment_count(p["id"]) == 0 and svc.posts(cast["a"], cid)[0] == []
    svc.delete(cast["admin"], cid)
    with pytest.raises(ChatError):
        svc.get_visible(cid, cast["a"])


def test_private_posts_not_leaking(cast, epoch):
    ch = svc.create(cast["admin"], f"pl_{cast['sfx']}", "Yopiq2", True, "abcd")
    p = chat.post_channel_e2e(cast["admin"], repo.get(ch["id"]), _env(ep=epoch))
    for fn in (lambda: svc.posts(cast["b"], ch["id"]), lambda: svc.comments(cast["b"], ch["id"], p["id"]),
               lambda: svc.add_comment(cast["b"], ch["id"], p["id"], _env(ep=epoch)), lambda: svc.mark_viewed(cast["b"], ch["id"], [p["id"]])):
        with pytest.raises(ChatError):
            fn()


def test_legacy_posts_migrated(cast):
    from app import crypto
    from app.db import db
    ch = svc.create(cast["admin"], f"old_{cast['sfx']}", "Eski", False, None)
    old = db.run("INSERT INTO channel_posts(channel_id,user_id,content,created_at) VALUES(?,?,?,?)",
                 (ch["id"], cast["admin"]["id"], crypto.seal("Eski post", "chpost"), time.time()))
    db.run("INSERT INTO channel_comments(post_id,user_id,content,created_at) VALUES(?,?,?,?)", (old, cast["a"]["id"], crypto.seal("eski izoh", "chcom"), time.time()))
    assert repo.migrate_legacy_posts() >= 1 and repo.migrate_legacy_posts() == 0
    p = svc.posts(cast["b"], ch["id"])[0][0]
    assert p["legacy"] is True and p["content"] == "Eski post" and p["comments"] == 1
    c = svc.comments(cast["b"], ch["id"], p["id"])[0][0]
    assert c["content"] == "eski izoh" and c["legacy"] is True
