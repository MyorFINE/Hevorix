"""Kanallar: ruxsatlar (ommaviy/shaxsiy), parol bilan qo'shilish, postlar, ko'rishlar soni va kommentlar (fastapi kerak emas)."""
import time

import pytest

from app.errors import ChatError
from app.repositories import channels as repo
from app.repositories import users as users_repo
from app.security import hash_password
from app.services import channels as svc


def _user(name: str, role: str = "user"):
    uid = users_repo.create(name, name.title(), hash_password("x"), role, time.time())
    return users_repo.get(uid)


@pytest.fixture(scope="module")
def cast():
    sfx = str(int(time.time() * 1000))[-6:]
    return {"admin": _user(f"cadm{sfx}", "admin"), "a": _user(f"ca{sfx}"), "b": _user(f"cb{sfx}"), "sfx": sfx}


def test_only_admin_creates(cast):
    with pytest.raises(ChatError):
        svc.create(cast["a"], f"x_{cast['sfx']}", "Nom", False, None)


def test_public_channel_visible_to_all(cast):
    ch = svc.create(cast["admin"], f"pub_{cast['sfx']}", "Yangiliklar", False, None)
    assert ch["private"] is False and ch["can_manage"] is True
    assert ch["id"] in [c["id"] for c in svc.list_channels(cast["a"])]
    svc.get_visible(ch["id"], cast["b"])                                    # xato bermaydi
    with pytest.raises(ChatError):
        svc.create(cast["admin"], f"pub_{cast['sfx']}", "Dublikat", False, None)      # username band


def test_private_hidden_until_password_join(cast):
    sfx = cast["sfx"]
    with pytest.raises(ChatError):
        svc.create(cast["admin"], f"prv_{sfx}", "Yopiq", True, "")                      # parolsiz shaxsiy kanal mumkin emas
    ch = svc.create(cast["admin"], f"prv_{sfx}", "Yopiq", True, "sir1234")
    assert ch["private"] is True
    assert ch["id"] in [c["id"] for c in svc.list_channels(cast["admin"])]              # adminga ko'rinadi
    assert ch["id"] not in [c["id"] for c in svc.list_channels(cast["a"])]              # oddiyga ko'rinmaydi
    with pytest.raises(ChatError) as e:
        svc.get_visible(ch["id"], cast["a"])
    assert e.value.status == 404
    with pytest.raises(ChatError):
        svc.join(cast["a"], f"prv_{sfx}", "noto'g'ri")
    with pytest.raises(ChatError) as e2:
        svc.join(cast["a"], "mavjud_emas_kanal", "sir1234")
    assert e2.value.message == "Kanal topilmadi yoki parol noto'g'ri"                   # kanal borligi oshkor bo'lmaydi
    j = svc.join(cast["a"], f"@PRV_{sfx}", "sir1234")                                   # @ va katta harf e'tiborsiz
    assert j["joined"] is True and j["id"] == ch["id"]
    assert ch["id"] in [c["id"] for c in svc.list_channels(cast["a"])]
    assert ch["id"] not in [c["id"] for c in svc.list_channels(cast["b"])]
    aud = svc.audience(repo.get(ch["id"]))
    assert cast["a"]["id"] in aud and cast["admin"]["id"] in aud and cast["b"]["id"] not in aud
    # parol almashsa eski a'zolar chiqariladi, public qilinsa hamma ko'radi
    svc.update(cast["admin"], ch["id"], password="yangi5678")
    assert ch["id"] not in [c["id"] for c in svc.list_channels(cast["a"])]
    svc.update(cast["admin"], ch["id"], private=False)
    assert ch["id"] in [c["id"] for c in svc.list_channels(cast["b"])]
    with pytest.raises(ChatError):
        svc.update(cast["a"], ch["id"], nickname="Hack")                                # oddiy foydalanuvchi o'zgartira olmaydi


def test_posts_views_comments(cast):
    ch = svc.create(cast["admin"], f"pc_{cast['sfx']}", "Post kanal", False, None)
    cid = ch["id"]
    with pytest.raises(ChatError):
        svc.add_post(cast["a"], cid, "oddiy foydalanuvchi post yoza olmaydi")
    _, p = svc.add_post(cast["admin"], cid, "  Salom kanal!  ")
    assert p["text"] == "Salom kanal!" and p["views"] == 0 and p["comments"] == 0
    # ko'rishlar: har bir foydalanuvchi bir marta, muallif sanalmaydi
    assert svc.mark_viewed(cast["a"], cid, [p["id"]])[1] == {p["id"]: 1}
    assert svc.mark_viewed(cast["a"], cid, [p["id"]])[1] == {}                          # takror sanalmaydi
    assert svc.mark_viewed(cast["b"], cid, [p["id"], 999999])[1] == {p["id"]: 2}
    assert svc.mark_viewed(cast["admin"], cid, [p["id"]])[1] == {}
    # kommentlar post ostida
    _, c1, n1 = svc.add_comment(cast["a"], cid, p["id"], "Zo'r!")
    _, c2, n2 = svc.add_comment(cast["b"], cid, p["id"], "Rahmat")
    assert (n1, n2) == (1, 2) and c1["user"]["id"] == cast["a"]["id"] and c1["text"] == "Zo'r!"
    items, more = svc.comments(cast["b"], cid, p["id"])
    assert [c["text"] for c in items] == ["Zo'r!", "Rahmat"] and more is False
    posts, _ = svc.posts(cast["a"], cid)
    assert posts[-1]["views"] == 2 and posts[-1]["comments"] == 2
    with pytest.raises(ChatError):
        svc.delete_comment(cast["b"], cid, p["id"], c1["id"])                           # begona kommentni o'chira olmaydi
    assert svc.delete_comment(cast["admin"], cid, p["id"], c1["id"])[1] == 1            # admin o'chira oladi
    assert svc.delete_comment(cast["b"], cid, p["id"], c2["id"])[1] == 0                # o'zinikini
    with pytest.raises(ChatError):
        svc.add_comment(cast["a"], cid, p["id"], "   ")
    # tahrirlash va o'chirish
    assert svc.edit_post(cast["admin"], cid, p["id"], "Yangilandi")[1]["edited"] is True
    svc.delete_post(cast["admin"], cid, p["id"])
    assert svc.posts(cast["a"], cid)[0] == []
    svc.delete(cast["admin"], cid)
    with pytest.raises(ChatError):
        svc.get_visible(cid, cast["a"])


def test_private_comments_not_leaking(cast):
    ch = svc.create(cast["admin"], f"pl_{cast['sfx']}", "Yopiq2", True, "abcd")
    _, p = svc.add_post(cast["admin"], ch["id"], "yashirin post")
    for fn in (lambda: svc.posts(cast["b"], ch["id"]), lambda: svc.comments(cast["b"], ch["id"], p["id"]),
               lambda: svc.add_comment(cast["b"], ch["id"], p["id"], "kiraman"), lambda: svc.mark_viewed(cast["b"], ch["id"], [p["id"]])):
        with pytest.raises(ChatError):
            fn()


def test_stored_encrypted(cast):
    from app.db import db
    ch = svc.create(cast["admin"], f"enc_{cast['sfx']}", "Shifr", False, None)
    _, p = svc.add_post(cast["admin"], ch["id"], "maxfiy matn 123")
    raw = db.one("SELECT content FROM channel_posts WHERE id=?", (p["id"],))["content"]
    assert raw.startswith("enc1:") and "maxfiy" not in raw
