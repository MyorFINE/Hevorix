// Node: durak interfeysi (frontend/js/app/97c-durak.js) — botlar bilan to'liq o'yin va online holatlar, soxta DOM bilan.
// Ishlatish: node tests/durak_ui_test.mjs
import assert from "node:assert/strict";
import {setup, load} from "./fake_dom.mjs";
const realSetTimeout = globalThis.setTimeout;
globalThis.setTimeout = (f, ms, ...a) => realSetTimeout(f, Math.min(ms || 0, 3), ...a);   // bot kutishlarini tezlashtiramiz
const {document} = setup();
const sent = []; globalThis.wsTry = o => { sent.push(JSON.parse(JSON.stringify(o))); return true; };
globalThis.U = id => ({id, nickname: "User" + id, username: "u" + id});
load("../app/static/js/durak.js");
load("../frontend/js/app/97c-durak.js", "Durak");

const find = (el, pred, out = []) => { if (el.nodeType === 1) { if (pred(el)) out.push(el); el.children.forEach(c => find(c, pred, out)); } return out; };
const has = (el, c) => el.className.split(" ").includes(c);
const root = () => document.body.children.find(c => c.attrs && has(c, "dk"));
const byText = (r, t) => find(r, e => e.tag === "button" && e.textContent.includes(t))[0];
const click = el => { assert.ok(el, "element topilmadi"); (el.listeners.click || []).forEach(f => f({currentTarget: el, target: el})); };
const sleep = ms => new Promise(r => realSetTimeout(r, ms));
const overCard = () => root() && find(root(), e => has(e, "go-card"))[0];

// ---- 1) botlar bilan: to'liq o'yin oxirigacha ----
Durak.openFromPush();
assert.ok(root(), "ekran ochilmadi");
click(byText(root(), "Botlar bilan"));
click(find(root(), e => e.tag === "button" && e.textContent.includes("2 bot"))[0]);
click(byText(root(), "O'yinni boshlash"));
assert.equal(find(root(), e => has(e, "dk-hand")).length, 1, "qo'l chizilmadi");
assert.equal(find(root(), e => has(e, "dk-opp")).length, 2, "2 ta raqib bo'lishi kerak");
let bad = find(root(), e => has(e, "dkc") && has(e, "no") && e.parentNode && has(e.parentNode, "dk-hand"))[0];
let steps = 0;
while (!overCard() && steps++ < 4000) {
  const r = root();
  const ok = find(r, e => has(e, "dkc") && has(e, "ok") && e.parentNode && has(e.parentNode, "dk-hand"));
  const toss = find(r, e => has(e, "dk-pair") && has(e, "tg"));
  if (toss.length) { click(toss[0]); continue; }
  if (ok.length) {
    // eng past (chapdagi) emas — birinchi o'ynaladigan kartani bosamiz; bir nechta nishon bo'lsa keyingi iteratsiyada juft tanlanadi
    click(ok[0]); continue;
  }
  const b = byText(r, "Bito") || byText(r, "Pas") || byText(r, "Olaman");
  if (b) { click(b); continue; }
  await sleep(4);
}
assert.ok(overCard(), "o'yin tugamadi (" + steps + " qadam)");
assert.ok(/durak|Durang/i.test(overCard().textContent), "natija matni");
click(byText(root(), "Yopish"));
console.log("OK durak: botlar bilan to'liq o'yin (" + steps + " qadam)");

// ---- 2) online: server holati -> harakat xabari ----
const T = globalThis.TCDurak, st = new T.State(2);
const mkMsg = (extra = {}) => ({type: "dk_state", tid: "t1", host: 1, status: "playing", seats: [1, 2], gone: [], me: 0, pending: [], left: 60000, turnS: 60, result: null, max: 4, min: 2,
  game: {n: 2, trump: st.trump, trumpCard: st.deck.length ? st.trumpCard : null, deck: st.deck.length, counts: st.hands.map(h => h.length), hand: st.hands[0].slice(), table: st.table.map(p => p.slice()),
    att: st.att, dfn: st.dfn, turn: st.turn, phase: st.phase, cap: st.cap, discard: st.discard, out: st.out.slice(), finish: st.finish.slice(), legal: st.legal(0), over: st.over}, ...extra});
// 0-o'rin hujumchi bo'lishini ta'minlaymiz (kozer eng past bo'lgan boshlaydi, bo'lmasa 0)
const attSeat = st.att;
Durak.onWs(mkMsg({me: attSeat, game: undefined, status: "lobby", seats: [1], pending: [], }));   // lobby
assert.ok(byText(root(), "Kamida 2 kishi kerak"), "lobbida 1 kishi bilan boshlab bo'lmaydi");
assert.ok(byText(root(), "taklif qilish"), "egasi taklif qila olishi kerak");
const v = (me) => { const g = mkMsg().game; g.hand = st.hands[me].slice(); g.legal = st.legal(me); return g; };
Durak.onWs({...mkMsg(), me: attSeat, game: v(attSeat)});
const ok = find(root(), e => has(e, "dkc") && has(e, "ok") && e.parentNode && has(e.parentNode, "dk-hand"));
assert.ok(ok.length > 0, "hujumchida o'ynaladigan karta bo'lishi kerak");
const card = ok[0].attrs["data-c"];
click(ok[0]);
const act = sent.find(o => o.type === "dk_act");
assert.deepEqual(act, {type: "dk_act", a: {t: "atk", c: card}});
// navbat bo'lmaganda bosish xabar yubormaydi
sent.length = 0;
const other = {...mkMsg(), me: 1 - st.att, game: v(1 - st.att)};
Durak.onWs(other);
find(root(), e => has(e, "dkc") && e.parentNode && has(e.parentNode, "dk-hand")).forEach(click);
assert.equal(sent.filter(o => o.type === "dk_act").length, 0, "navbat sizda emas — harakat yuborilmasligi kerak");
// o'yin tugashi: natija kartasi
const fin = mkMsg({status: "over", result: {loser: 2, reason: "timeout", order: [1], rated: true, pts: {"1": 10, "2": -10}, total: {"1": 30, "2": 0}}}); fin.game.over = {loser: 1}; fin.game.legal = null;
Durak.onWs(fin);
await sleep(30);
assert.ok(overCard(), "online natija kartasi");
assert.ok(overCard().textContent.includes("Yana o'ynash"), "egasida «Yana o'ynash» bo'lishi kerak");
assert.ok(overCard().textContent.includes("+10 ochko") && overCard().textContent.includes("Jami: 30"), "ochko ko'rsatilishi kerak: " + overCard().textContent);
Durak.onWs({type: "dk_closed", tid: "t1", reason: "left"});
assert.ok(byText(root(), "Botlar bilan"), "yopilgach menyu qaytishi kerak");
console.log("OK durak online: lobby, harakat xabari, natija");
process.exit(0);
