// Node: oflayn shaxmat dvigateli (app/static/js/chessbot.js) — qoidalar to'g'riligi (perft), o'yin oxiri holatlari va bot.
// Ishlatish: node tests/chess_engine_test.mjs
import fs from "node:fs"; import vm from "node:vm"; import assert from "node:assert/strict";
const src = fs.readFileSync(new URL("../app/static/js/chessbot.js", import.meta.url), "utf8");
const ctx = {performance, Math, console}; ctx.self = ctx; vm.createContext(ctx); vm.runInContext(src, ctx);
const C = ctx.TCChess; assert.ok(C, "TCChess topilmadi");
const P = C.Pos;

// 1) perft: shaxmat qoidalarining to'g'riligi (taniqli etalon sonlar)
const PERFT = [
  ["boshlang'ich", C.START_FEN, [20, 400, 8902, 197281]],
  ["kiwipete (rokirovka/en passant/pin)", "r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1", [48, 2039, 97862]],
  ["3-pozitsiya (en passant, endshpil)", "8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1", [14, 191, 2812, 43238]],
  ["4-pozitsiya (promotsiya, shoh)", "r3k2r/Pppp1ppp/1b3nbN/nP6/BBP1P3/q4N2/Pp1P2PP/R2Q1RK1 w kq - 0 1", [6, 264, 9467]],
  ["5-pozitsiya", "rnbq1k1r/pp1Pbppp/2p5/8/2B5/8/PPP1NnPP/RNBQK2R w KQ - 1 8", [44, 1486, 62379]],
  ["6-pozitsiya", "r4rk1/1pp1qppp/p1np1n2/2b1p1B1/2B1P1b1/P1NP1N2/1PP1QPPP/R4RK1 w - - 0 10", [46, 2079, 89890]],
];
for (const [name, fen, exp] of PERFT) {
  exp.forEach((n, i) => { const got = C.perft(new P(fen), i + 1); assert.equal(got, n, `${name}: perft(${i + 1}) = ${got}, kutilgan ${n}`); });
  console.log("OK perft", name);
}

// 2) make/undo butunlay qaytaradi (FEN va xesh)
{ const p = new P("r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1"), f0 = p.fen(), h0 = [p.h1, p.h2];
  const walk = d => { if (!d) return; for (const m of p.legal()) { p.make(m); walk(d - 1); p.undo(); } };
  walk(3); assert.equal(p.fen(), f0); assert.deepEqual([p.h1, p.h2], h0);
  const q = new P(f0); const m = q.legal()[5]; q.make(m); const h = [q.h1, q.h2]; q.hash(); assert.deepEqual([q.h1, q.h2], h, "o'sib boruvchi xesh to'liq xeshga teng emas");
  console.log("OK make/undo + xesh"); }

// 3) o'yin oxiri holatlari
const st = fen => JSON.parse(JSON.stringify(new P(fen).status()));
assert.deepEqual(st("rnb1kbnr/pppp1ppp/8/4p3/6Pq/5P2/PPPPP2P/RNBQKBNR w KQkq - 1 3"), {over: true, result: "b", reason: "checkmate"});     // ahmoq mati
assert.deepEqual(st("7k/5Q2/6K1/8/8/8/8/8 b - - 0 1"), {over: true, result: "d", reason: "stalemate"});
assert.equal(st("8/8/8/4k3/8/8/8/4K3 w - - 0 1").reason, "insufficient");
assert.equal(st("8/8/8/4k3/8/8/8/3NK3 w - - 0 1").reason, "insufficient");
assert.equal(st("8/8/8/4k3/8/8/8/3QK3 w - - 0 1").over, false);
assert.equal(st("8/8/8/4k3/8/8/4P3/4K3 w - - 100 80").reason, "fifty");
{ const p = new P(); const seq = ["g1f3", "g8f6", "f3g1", "f6g8", "g1f3", "g8f6", "f3g1", "f6g8"];
  seq.forEach((u, i) => { assert.equal(p.status().over, false, "erta tugadi: " + i); p.make(p.findUci(u)); });
  assert.equal(p.status().reason, "repetition"); }
console.log("OK o'yin oxiri");

// 4) rokirovka va en passant, promotsiya
{ const p = new P("r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1"); const ml = p.legal().map(m => p.toUci(m)); assert.ok(ml.includes("e1g1") && ml.includes("e1c1"));
  p.make(p.findUci("e1g1")); assert.equal(p.fen().split(" ")[0], "r3k2r/8/8/8/8/8/8/R4RK1");
  const q = new P("4k3/8/8/8/8/8/8/4K2R w K - 0 1"); q.make(q.findUci("h1h8")); assert.equal(q.cast, 0);
  const e = new P("4k3/8/8/3pP3/8/8/8/4K3 w - d6 0 2"); assert.ok(e.legal().map(m => e.toUci(m)).includes("e5d6"));
  const pr = new P("8/P7/8/8/8/8/8/k6K w - - 0 1"); assert.equal(pr.legal().map(m => pr.toUci(m)).filter(u => u.startsWith("a7")).sort().join(), "a7a8b,a7a8n,a7a8q,a7a8r");
  const ill = new P("4k3/8/8/8/8/8/4r3/R3K2R w KQ - 0 1"); assert.ok(!ill.legal().map(m => ill.toUci(m)).some(u => u === "e1g1" || u === "e1c1"), "shoh ostida rokirovka"); 
  console.log("OK maxsus yurishlar"); }

// 5) bot: mat topadi, taxtadagi tekin ferzni oladi, qonuniy yuradi
{ const t0 = Date.now();
  const mate = C.chooseMove("6k1/5ppp/8/8/8/8/5PPP/R5K1 w - - 0 1", [], 4);       // Ra8#
  assert.equal(mate.uci, "a1a8", "1 yurishda mat topilmadi: " + mate.uci);
  const hang = C.chooseMove("4k3/8/8/3q4/8/8/8/3RK3 w - - 0 1", [], 3);
  assert.equal(hang.uci, "d1d5", "tekin ferz olinmadi: " + hang.uci);
  for (let lvl = 1; lvl <= 5; lvl++) {
    const p = new P(); const moves = [];
    for (let i = 0; i < 6; i++) { const r = C.chooseMove(C.START_FEN, moves, lvl); assert.ok(r && r.uci, "daraja " + lvl); const m = p.findUci(r.uci); assert.ok(m, "noqonuniy yurish: " + r.uci); p.make(m); moves.push(r.uci); }
  }
  console.log("OK bot (" + (Date.now() - t0) + " ms)"); }

// 6) bot o'ziga qarshi: to'liq o'yin noqonuniy yurishsiz tugaydi yoki chegaraga yetadi
{ const p = new P(), moves = []; let n = 0;
  while (!p.status().over && n < 160) { const lvl = n % 2 ? 2 : 3; const r = C.chooseMove(C.START_FEN, moves, lvl); assert.ok(r, "yurish yo'q"); const m = p.findUci(r.uci); assert.ok(m, "noqonuniy: " + r.uci); p.make(m); moves.push(r.uci); n++; }
  console.log("OK bot-bot o'yin:", n, "yarim yurish,", JSON.stringify(p.status())); }
console.log("HAMMASI OK");
