import base64
import io

import pytest

from app.errors import ChatError
from app.repositories import users
from app.services import backup, badges
from app.security import hash_password

try:
    from PIL import Image
except ImportError:
    Image = None


def _owner():
    return users.get_by_username("asura")


def _png() -> bytes:
    b = io.BytesIO()
    Image.new("RGB", (8, 8), (200, 30, 30)).save(b, "PNG")
    return b.getvalue()


def _mk(name, role="user", nick=None):
    return users.get(users.create(name, nick or name.title(), hash_password("x" * 64), role, 1_700_000_000.0))


def test_export_owner_only_and_roundtrip():
    owner = _owner()
    a = _mk("bk_ali", nick="Ali")
    admin = _mk("bk_boss", "admin")
    with pytest.raises(ChatError):
        backup.export_users(admin)
    data = backup.export_users(owner)
    by = {u["username"]: u for u in data["users"]}
    assert by["bk_ali"]["nickname"] == "Ali" and by["bk_ali"]["role"] == "user" and by["bk_ali"]["joined"] == 1_700_000_000.0
    assert by["bk_boss"]["role"] == "admin"
    assert by["bk_ali"]["cred"]["password_hash"] == a["password_hash"]
    from app.db import db
    db.run("DELETE FROM users WHERE username IN ('bk_ali','bk_boss')")
    res = backup.restore_users(owner, data)
    assert res["created"] >= 2 and res["invalid"] == 0
    again = users.get_by_username("bk_ali")
    assert again["nickname"] == "Ali" and again["created_at"] == 1_700_000_000.0 and again["password_hash"] == a["password_hash"]
    assert users.get_by_username("bk_boss")["role"] == "admin"
    res2 = backup.restore_users(owner, data)
    assert res2["created"] == 0 and res2["skipped"] >= 2


@pytest.mark.skipif(Image is None, reason="Pillow kerak")
def test_avatar_roundtrip_and_validation():
    from app.config import settings
    from app.db import db
    owner = _owner()
    u = _mk("bk_pic")
    name = "bk_pic.png"
    (settings.avatars_dir / name).write_bytes(_png())
    from app.repositories import avatars as av
    users.set_active_avatar(u["id"], av.add(u["id"], name, 1.0))
    data = backup.export_users(owner)
    rec = next(x for x in data["users"] if x["username"] == "bk_pic")
    assert rec["avatar"] and base64.b64decode(rec["avatar"]["data"])[:4] == b"\x89PNG"
    db.run("DELETE FROM users WHERE username='bk_pic'")
    assert backup.restore_users(owner, data)["avatars"] >= 1
    assert users.get_view(users.get_by_username("bk_pic")["id"])["avatar"]


def test_restore_rejects_bad_records():
    owner = _owner()
    _mk("bk_seed")
    good = next(u for u in backup.export_users(owner)["users"] if u["username"] == "bk_seed")
    base = {"v": 1, "app": "anonim-chat"}
    evil = [
        {**good, "username": "Bad Name!"},
        {**good, "username": "bk_x1", "role": "owner"},
        {**good, "username": "bk_x2", "role": "root"},
        {**good, "username": "bk_x3", "cred": {**good["cred"], "password_hash": "plain"}},
        {**good, "username": "admin"},
        {**good, "username": "bk_x4", "cred": {"password_hash": good["cred"]["password_hash"], "auth_v": 1}},
        "satr",
    ]
    res = backup.restore_users(owner, {**base, "users": evil})
    assert res["created"] == 0 and res["invalid"] == len(evil) - 1 and res["skipped"] == 1
    for bad in ({}, {"app": "boshqa", "v": 1, "users": []}, {**base, "v": 2, "users": []}, {**base, "users": "x"}):
        with pytest.raises(ChatError):
            backup.restore_users(owner, bad)
    with pytest.raises(ChatError):
        backup.restore_users(_mk("bk_adm2", "admin"), {**base, "users": []})


def test_owner_is_never_exported_nor_overwritten():
    owner = _owner()
    data = backup.export_users(owner)
    assert all(u["role"] != "owner" and u["username"] != "asura" for u in data["users"])
    forged = {**data, "users": data["users"] + [{**data["users"][0], "username": "asura", "role": "owner"}]}
    backup.restore_users(owner, forged)
    assert users.get_by_username("asura")["role"] == "owner"
    assert users.get_by_username("asura")["password_hash"] == owner["password_hash"]


def test_verified_check_without_admin():
    owner = _owner()
    u = _mk("bk_vrf")
    t = badges.set_for(owner, u["id"], "check", "")
    assert users.get(u["id"])["badge"] == "check" and users.get(u["id"])["role"] == "user"
    badges.set_for(owner, u["id"], "", "")
    assert users.get(u["id"])["badge"] is None
    with pytest.raises(ChatError):
        badges.set_for(u, u["id"], "check", "")
    adm = _mk("bk_adm3", "admin")
    badges.set_for(owner, adm["id"], "check", "")
    assert users.get(adm["id"])["badge"] is None
