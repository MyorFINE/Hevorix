import os, sys, tempfile, time, io
from datetime import datetime, timezone, timedelta
d = tempfile.mkdtemp(prefix="smoke-")
os.environ.update(TERMCHAT_DATA_DIR=d, TERMCHAT_MASTER_KEY="x"*32, R2_BUCKET_NAME="b", R2_ACCESS_KEY_ID="k",
                  R2_SECRET_ACCESS_KEY="s", R2_ENDPOINT="https://acc.r2.cloudflarestorage.com/b", R2_REGION="weur")
sys.path.insert(0, ".")

class ClientError(Exception):
    def __init__(s, code): s.response = {"Error": {"Code": code}}
class Fake:
    def __init__(s): s.o = {}
    def put_object(s, Bucket, Key, Body, ContentType=None): s.o[Key] = [bytes(Body), datetime.now(timezone.utc)]
    def get_object(s, Bucket, Key):
        if Key not in s.o: raise ClientError("NoSuchKey")
        return {"Body": io.BytesIO(s.o[Key][0])}
    def delete_object(s, Bucket, Key): s.o.pop(Key, None)
    def delete_objects(s, Bucket, Delete, **k):
        for x in Delete["Objects"]: s.o.pop(x["Key"], None)
    def copy_object(s, Bucket, Key, CopySource):
        if CopySource["Key"] not in s.o: raise ClientError("NoSuchKey")
        s.o[Key] = list(s.o[CopySource["Key"]])
    def list_objects_v2(s, Bucket, Prefix, ContinuationToken=None):
        return {"Contents": [{"Key": k, "LastModified": v[1], "Size": len(v[0])} for k, v in sorted(s.o.items()) if k.startswith(Prefix)], "IsTruncated": False}

from app.services import r2
fake = Fake(); r2._client = fake
assert r2.enabled() and r2._endpoint() == "https://acc.r2.cloudflarestorage.com"

# 1) restore: R2 bo'sh -> yangi baza
from app.services import dbsync
assert dbsync.restore_if_needed() is False
from app.db import db
from app.config import settings
db.run("INSERT INTO users(username,nickname,password_hash,created_at) VALUES('ali','Ali','x',1)")
db.run("INSERT INTO messages(user_id,content,created_at,e2e) VALUES(1,'ENVELOPE-1',?,1)", (time.time(),))

# 2) E2EE fayl R2 ga tushadi
from app.services import media
raw = os.urandom(5000)
name = media.store_opaque(raw)
assert fake.o["media/" + name][0] == raw and not list(settings.media_dir.glob("*.e2e")), "disk emas, R2 bo'lishi kerak"
assert media.read(name) == raw
print("e2e blob R2 da:", name)

# 3) 24 soat: eski xabar fayli o'chadi, yangisi qoladi
from app.repositories import messages, e2ee as e2ee_repo
old_id = db.run("INSERT INTO messages(user_id,content,created_at,e2e,file,file_size) VALUES(1,'E',?,1,?,5000)", (time.time()-25*3600, name))
e2ee_repo.add_blob(name, 1, 5000)
new_name = media.store_opaque(os.urandom(100))
new_id = db.run("INSERT INTO messages(user_id,content,created_at,e2e,file,file_size) VALUES(1,'E',?,1,?,100)", (time.time()-3600, new_name))
from app.services import maintenance
assert maintenance.sweep_expired() == 1
assert "media/" + name not in fake.o and "media/" + new_name in fake.o
assert media.read(name) is None
row = db.one("SELECT * FROM messages WHERE id=?", (old_id,)); assert row["media_expired"] == 1 and row["file"] is None
assert db.one("SELECT file FROM messages WHERE id=?", (new_id,))["file"] == new_name
assert maintenance.sweep_expired() == 0
print("24 soat: OK")

# 4) R2 da yetim eski obyekt (bazada yo'q) ham o'chadi; emoji tegilmaydi
fake.o["media/orphan.e2e"] = [b"x", datetime.now(timezone.utc) - timedelta(hours=30)]
fake.o["emoji/keep.png"] = [b"png", datetime.now(timezone.utc) - timedelta(days=400)]
assert maintenance.sweep_r2_media() == 1 and "media/orphan.e2e" not in fake.o and "emoji/keep.png" in fake.o
print("yetim + emoji doimiy: OK")

# 5) emoji: restore + upload_missing
(settings.emoji_dir / "a.png").write_bytes(b"A")
assert r2.upload_missing("emoji", settings.emoji_dir) == 1 and fake.o["emoji/a.png"][0] == b"A"
(settings.emoji_dir / "a.png").unlink()
assert r2.restore_dir("emoji", settings.emoji_dir) == 2 and (settings.emoji_dir / "keep.png").read_bytes() == b"png"
print("emoji sinxron: OK")

# 6) baza snapshot -> R2 -> boshqa joyga tiklash
assert dbsync.push(force=True) and "db/chat.db.enc" in fake.o
assert b"ENVELOPE-1" not in fake.o["db/chat.db.enc"][0], "baza R2 da shifrlangan bo'lishi kerak"
db.run("INSERT INTO messages(user_id,content,created_at,e2e) VALUES(1,'ENVELOPE-2',?,1)", (time.time(),))
assert dbsync.push() and "db/chat.db.prev.enc" in fake.o
assert dbsync.push() is False                          # o'zgarish yo'q
path = settings.db_path
db._conn.close(); [p.unlink() for p in path.parent.glob("chat.db*")]
assert dbsync.restore_if_needed() is True
import sqlite3
c = sqlite3.connect(path); got = [r[0] for r in c.execute("SELECT content FROM messages ORDER BY id")]
assert "ENVELOPE-1" in got and "ENVELOPE-2" in got, got
print("baza tiklash: OK", got)
