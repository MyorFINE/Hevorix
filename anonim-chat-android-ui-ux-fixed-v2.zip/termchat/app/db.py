"""SQLite ulanishi va sxema."""
from __future__ import annotations

import sqlite3
import threading
from pathlib import Path

from app.config import settings

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE COLLATE NOCASE,
  nickname TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'user',            -- user | admin | owner
  banned INTEGER NOT NULL DEFAULT 0,
  ban_reason TEXT,
  muted_until REAL NOT NULL DEFAULT 0,
  mute_reason TEXT,
  active_avatar_id INTEGER,
  bio TEXT NOT NULL DEFAULT '',
  color TEXT,                                   -- admin/ega tanlagan profil rangi (#rrggbb)
  created_at REAL NOT NULL,
  deleted INTEGER NOT NULL DEFAULT 0,           -- 1 = akkaunt o'chirilgan ("Deleted account"), xabarlari qoladi
  deleted_at REAL
);
CREATE TABLE IF NOT EXISTS avatars(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  filename TEXT NOT NULL,
  created_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions(
  token_hash TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
CREATE TABLE IF NOT EXISTS messages(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  created_at REAL NOT NULL,
  edited_at REAL,
  deleted INTEGER NOT NULL DEFAULT 0,
  recipient_id INTEGER REFERENCES users(id) ON DELETE CASCADE,   -- NULL = umumiy chat, aks holda shaxsiy xabar
  read INTEGER NOT NULL DEFAULT 0,                               -- faqat shaxsiy xabarlar uchun
  image TEXT,                                                    -- yuklangan rasm fayl nomi
  reply_to INTEGER,                                              -- javob berilgan xabar id
  img_w INTEGER,                                                 -- rasm eni (piksel)
  img_h INTEGER                                                  -- rasm bo'yi (piksel)
);
CREATE TABLE IF NOT EXISTS logs(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  type TEXT NOT NULL,          -- edit | delete | mute | unmute | ban | unban | role
  message_id INTEGER,
  user_id INTEGER,             -- xabar egasi / nishon
  actor_id INTEGER,            -- amalni bajargan
  old_content TEXT,
  new_content TEXT,
  created_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS activity(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created_at REAL NOT NULL,
  ip TEXT,
  user_id INTEGER,
  username TEXT,               -- harakat vaqtidagi username (noma'lum foydalanuvchi urinishlari uchun ham)
  action TEXT NOT NULL,
  detail TEXT
);
CREATE INDEX IF NOT EXISTS idx_activity_ip ON activity(ip, id);
CREATE INDEX IF NOT EXISTS idx_activity_user ON activity(user_id, id);
CREATE INDEX IF NOT EXISTS idx_activity_time ON activity(created_at);
CREATE TABLE IF NOT EXISTS ip_blocks(
  ip TEXT PRIMARY KEY,
  reason TEXT,
  blocked_by INTEGER,
  created_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS chat_settings(          -- moderatsiya sozlamalari (sekin rejim, qulf, taqiqlangan so'zlar)
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS reports(                -- foydalanuvchi shikoyatlari (umumiy chat xabarlari)
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  message_id INTEGER NOT NULL,
  reporter_id INTEGER NOT NULL,
  target_id INTEGER NOT NULL,
  reason TEXT,                 -- shifrlangan
  snapshot TEXT,               -- shikoyat vaqtidagi xabar matni (shifrlangan)
  created_at REAL NOT NULL,
  status TEXT NOT NULL DEFAULT 'open',            -- open | closed
  handled_by INTEGER,
  handled_at REAL,
  action TEXT,
  UNIQUE(message_id, reporter_id)
);
CREATE INDEX IF NOT EXISTS idx_reports_status ON reports(status, id);
CREATE TABLE IF NOT EXISTS room_epochs(            -- umumiy chat guruh kalitining avlodlari (E2EE); kalitning o'zi serverda YO'Q
  epoch INTEGER PRIMARY KEY,
  created_by INTEGER,
  created_at REAL NOT NULL,
  check_blob TEXT NOT NULL,    -- kalit to'g'riligini tekshirish uchun (kalit bilan shifrlangan); server uni ocha olmaydi
  reason TEXT
);
CREATE TABLE IF NOT EXISTS room_keys(              -- har bir a'zo uchun, uning OMMAVIY kaliti bilan o'ralgan guruh kaliti
  epoch INTEGER NOT NULL,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  wrapped TEXT NOT NULL,
  wrapper_id INTEGER,
  created_at REAL NOT NULL,
  PRIMARY KEY(epoch, user_id)
);
CREATE TABLE IF NOT EXISTS emoji_packs(            -- emoji to'plamlari (admin yaratadi)
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE COLLATE NOCASE,
  public INTEGER NOT NULL DEFAULT 1,           -- 1 = hamma ishlata oladi, 0 = faqat adminlar
  created_by INTEGER,
  created_at REAL NOT NULL,
  kind TEXT NOT NULL DEFAULT 'emoji',          -- 'emoji' = matn ichida kichik; 'sticker' = faqat yakka yuboriladi, katta
  scale INTEGER NOT NULL DEFAULT 100           -- ko'rinish hajmi, % (50–200)
);
CREATE TABLE IF NOT EXISTS custom_emojis(          -- maxsus emojilar: `:nom:` ko'rinishida yoziladi
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  file TEXT NOT NULL,                          -- data/emoji/<file>
  anim TEXT,                                   -- CSS animatsiya (pulse, bounce, ...) yoki NULL
  animated INTEGER NOT NULL DEFAULT 0,         -- 1 = fayl o'zi animatsiyali (GIF/WEBP dan)
  pack_id INTEGER REFERENCES emoji_packs(id) ON DELETE SET NULL,
  public INTEGER NOT NULL DEFAULT 1,           -- 1 = hamma ishlata oladi, 0 = faqat adminlar
  created_by INTEGER,
  created_at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_custom_emojis_pack ON custom_emojis(pack_id);
CREATE TABLE IF NOT EXISTS user_sticker_packs(     -- foydalanuvchi o'zi qo'shgan stiker to'plamlari (sukut bo'yicha hech kimda yo'q)
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  pack_id INTEGER NOT NULL REFERENCES emoji_packs(id) ON DELETE CASCADE,
  added_at REAL NOT NULL,
  PRIMARY KEY(user_id, pack_id)
);
CREATE TABLE IF NOT EXISTS game_stats(             -- Gaming: foydalanuvchining o'yin bo'yicha ochkolari (Score board)
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  game TEXT NOT NULL,
  points INTEGER NOT NULL DEFAULT 0,
  wins INTEGER NOT NULL DEFAULT 0,
  losses INTEGER NOT NULL DEFAULT 0,
  draws INTEGER NOT NULL DEFAULT 0,
  updated_at REAL NOT NULL,
  PRIMARY KEY(user_id, game)
);
CREATE INDEX IF NOT EXISTS idx_game_stats_top ON game_stats(game, points DESC);
CREATE TABLE IF NOT EXISTS game_log(               -- tugagan o'yinlar (ochko hisobi va takroriy "ochko almashish"dan himoya)
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  game TEXT NOT NULL,
  white_id INTEGER NOT NULL,
  black_id INTEGER NOT NULL,
  result TEXT NOT NULL,                        -- 'w' | 'b' | 'd'
  reason TEXT NOT NULL,
  pts_w INTEGER NOT NULL DEFAULT 0,
  pts_b INTEGER NOT NULL DEFAULT 0,
  plies INTEGER NOT NULL DEFAULT 0,
  rated INTEGER NOT NULL DEFAULT 1,
  started_at REAL NOT NULL,
  ended_at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_game_log_pair ON game_log(game, white_id, black_id, ended_at);
CREATE TABLE IF NOT EXISTS push_subs(              -- Web Push obunalari: brauzer butunlay yopiq bo'lsa ham bildirishnoma yetib boradi
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  endpoint TEXT NOT NULL UNIQUE,
  p256dh TEXT NOT NULL,
  auth TEXT NOT NULL,
  created_at REAL NOT NULL,
  last_ok REAL
);
CREATE INDEX IF NOT EXISTS idx_push_user ON push_subs(user_id);
CREATE TABLE IF NOT EXISTS channels(               -- kanallar: admin yaratadi; ommaviy (hamma ko'radi) yoki shaxsiy (adminlar + parol bilan qo'shilganlar)
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  nickname TEXT NOT NULL,
  avatar TEXT,
  is_private INTEGER NOT NULL DEFAULT 0,
  pw_hash TEXT,
  owner_id INTEGER NOT NULL,
  created_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS channel_members(       -- shaxsiy kanalga parol bilan qo'shilganlar
  channel_id INTEGER NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  joined_at REAL NOT NULL,
  PRIMARY KEY(channel_id, user_id)
);
CREATE TABLE IF NOT EXISTS channel_posts(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  channel_id INTEGER NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL,
  content TEXT NOT NULL,                           -- bazada shifrlangan (at-rest)
  created_at REAL NOT NULL,
  edited_at REAL
);
CREATE INDEX IF NOT EXISTS idx_chpost ON channel_posts(channel_id, id);
CREATE TABLE IF NOT EXISTS channel_post_views(    -- har bir foydalanuvchi postni bir marta sanaladi
  post_id INTEGER NOT NULL REFERENCES channel_posts(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL,
  PRIMARY KEY(post_id, user_id)
);
CREATE TABLE IF NOT EXISTS channel_comments(      -- faqat shu post ostida ko'rinadi, umumiy chatga tushmaydi
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  post_id INTEGER NOT NULL REFERENCES channel_posts(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  created_at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_chcom ON channel_comments(post_id, id);
CREATE TABLE IF NOT EXISTS post_comments(         -- kanal posti ostidagi izohlar (post = messages.id, channel_id bor qator); E2EE konvert yoki eski ochiq matn
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  post_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  e2e INTEGER NOT NULL DEFAULT 0,                  -- 1 = content E2EE konvert (server ocha olmaydi)
  created_at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_pcom ON post_comments(post_id, id);
CREATE TABLE IF NOT EXISTS post_views(             -- har bir foydalanuvchi postni bir marta sanaladi
  post_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  PRIMARY KEY(post_id, user_id)
);
CREATE TABLE IF NOT EXISTS reactions(              -- xabar/post reaksiyalari: bitta foydalanuvchi — bitta xabarga bitta reaksiya (Telegramdagidek)
  message_id INTEGER NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  emoji TEXT NOT NULL,
  created_at REAL NOT NULL,
  PRIMARY KEY(message_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_reactions_msg ON reactions(message_id, created_at);
CREATE TABLE IF NOT EXISTS pins(                   -- mahkamlangan xabarlar: user_id=0 — umumiy chat (hamma ko'radi, faqat adminlar), aks holda lichkada shu foydalanuvchining shaxsiy pini
  message_id INTEGER NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL,
  created_at REAL NOT NULL,
  PRIMARY KEY(message_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_pins_user ON pins(user_id, created_at);
CREATE TABLE IF NOT EXISTS e2e_blobs(              -- E2EE fayllar: server faqat shifrlangan baytlarni saqlaydi
  name TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL,
  size INTEGER NOT NULL,
  created_at REAL NOT NULL
);
"""


class Database:
    """Yupqa o'ramchi: bitta ulanish, lock bilan himoyalangan."""

    def __init__(self, path: Path):
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(str(path), check_same_thread=False, timeout=10)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")        # WAL bilan xavfsiz: elektr uzilsa ham baza buzilmaydi
        self._conn.execute("PRAGMA busy_timeout=10000")
        self._conn.execute("PRAGMA foreign_keys=ON")
        self._conn.execute("PRAGMA cache_size=-4096")           # 4 MB sahifa keshi (standart ~2 MB; ortiqcha o'sishi yo'q)
        self._conn.execute("PRAGMA mmap_size=0")                # fayl xotiraga xaritalanmaydi (RSS ga qo'shilmaydi)
        self._conn.execute("PRAGMA journal_size_limit=4194304") # WAL fayli 4 MB dan oshib qolmasin
        with self._lock:
            self._conn.executescript(SCHEMA)
            self._migrate()
            self._conn.commit()

    def _migrate(self) -> None:
        """Eski bazalarni yangi sxemaga o'tkazadi (ustun qo'shish) va indekslarni yaratadi."""
        def columns(table: str) -> set[str]:
            return {r[1] for r in self._conn.execute(f"PRAGMA table_info({table})")}

        pcols = columns("emoji_packs")
        if "kind" not in pcols:
            self._conn.execute("ALTER TABLE emoji_packs ADD COLUMN kind TEXT NOT NULL DEFAULT 'emoji'")
        if "scale" not in pcols:
            self._conn.execute("ALTER TABLE emoji_packs ADD COLUMN scale INTEGER NOT NULL DEFAULT 100")
        ucols = columns("users")
        if "bio" not in ucols:
            self._conn.execute("ALTER TABLE users ADD COLUMN bio TEXT NOT NULL DEFAULT ''")
        if "color" not in ucols:
            self._conn.execute("ALTER TABLE users ADD COLUMN color TEXT")
        if "deleted" not in ucols:
            self._conn.execute("ALTER TABLE users ADD COLUMN deleted INTEGER NOT NULL DEFAULT 0")
        if "deleted_at" not in ucols:
            self._conn.execute("ALTER TABLE users ADD COLUMN deleted_at REAL")
        if "badge" not in ucols:
            self._conn.execute("ALTER TABLE users ADD COLUMN badge TEXT")          # emoji nishon (galochka o'rniga)
        if "badge_anim" not in ucols:
            self._conn.execute("ALTER TABLE users ADD COLUMN badge_anim TEXT")     # nishon animatsiyasi
        for col, ddl in (("ecdh_pub", "TEXT"), ("sign_pub", "TEXT"), ("key_blob", "TEXT"), ("kdf_iter", "INTEGER"),
                         ("auth_v", "INTEGER NOT NULL DEFAULT 0")):       # E2EE: ommaviy kalitlar, parol bilan o'ralgan maxfiy kalitlar
            if col not in ucols:
                self._conn.execute(f"ALTER TABLE users ADD COLUMN {col} {ddl}")
        if "last_seen" not in ucols:        # oxirgi marta onlayn bo'lgan vaqt (oflayn bo'lganda yoziladi)
            self._conn.execute("ALTER TABLE users ADD COLUMN last_seen REAL")
        if "warns" not in ucols:
            self._conn.execute("ALTER TABLE users ADD COLUMN warns INTEGER NOT NULL DEFAULT 0")
        if "emoji_perm" not in ucols:        # 0 = umumiy sozlamaga amal qiladi, 1 = emoji ishlata oladi, 2 = ishlatadi va yarata oladi
            self._conn.execute("ALTER TABLE users ADD COLUMN emoji_perm INTEGER NOT NULL DEFAULT 0")
        for col, ddl in (("trust", "INTEGER"),      # admin qarori: NULL = avtomatik (akkaunt yoshi), 0 = "yangi" belgisi yashirin, 1 = doim ko'rsatiladi
                         ("neon", "TEXT"),         # ESKI (v11 da neon olib tashlandi): ustun saqlanadi, lekin ishlatilmaydi
                         ("fx", "TEXT"),           # v11: element bo'yicha animatsiyali uslublar (tayyor nomlar JSON'i, app/services/fxstyle.py)
                         ("banner", "TEXT"),       # profil fon dizayni (tayyor gradient nomi)
                         ("frame", "TEXT"),        # avatar ramkasi (tayyor uslub nomi)
                         ("title", "TEXT")):       # ism ostidagi qisqa unvon (masalan, "Moderator")
            if col not in ucols:
                self._conn.execute(f"ALTER TABLE users ADD COLUMN {col} {ddl}")
        self._conn.execute("UPDATE users SET neon=NULL WHERE neon IS NOT NULL")                 # v11: neon olib tashlandi
        self._conn.execute("UPDATE users SET frame=NULL WHERE frame='neon'")
        mcols = columns("messages")
        if "recipient_id" not in mcols:
            self._conn.execute("ALTER TABLE messages ADD COLUMN recipient_id INTEGER REFERENCES users(id) ON DELETE CASCADE")
        if "read" not in mcols:
            self._conn.execute("ALTER TABLE messages ADD COLUMN read INTEGER NOT NULL DEFAULT 0")
        if "image" not in mcols:
            self._conn.execute("ALTER TABLE messages ADD COLUMN image TEXT")
        if "reply_to" not in mcols:
            self._conn.execute("ALTER TABLE messages ADD COLUMN reply_to INTEGER")
        if "img_w" not in mcols:
            self._conn.execute("ALTER TABLE messages ADD COLUMN img_w INTEGER")
        if "img_h" not in mcols:
            self._conn.execute("ALTER TABLE messages ADD COLUMN img_h INTEGER")
        if "file" not in mcols:
            self._conn.execute("ALTER TABLE messages ADD COLUMN file TEXT")        # rasm bo'lmagan fayl (shifrlangan nusxa nomi)
        if "file_name" not in mcols:
            self._conn.execute("ALTER TABLE messages ADD COLUMN file_name TEXT")   # asl fayl nomi (shifrlangan)
        if "file_mime" not in mcols:
            self._conn.execute("ALTER TABLE messages ADD COLUMN file_mime TEXT")
        if "file_size" not in mcols:
            self._conn.execute("ALTER TABLE messages ADD COLUMN file_size INTEGER")  # rasm va fayllar uchun (bayt)
        if "e2e" not in mcols:
            self._conn.execute("ALTER TABLE messages ADD COLUMN e2e INTEGER NOT NULL DEFAULT 0")   # 1 = content E2EE konvert (server ocha olmaydi)
        if "media_expired" not in mcols:
            self._conn.execute("ALTER TABLE messages ADD COLUMN media_expired INTEGER NOT NULL DEFAULT 0")   # 1 = fayl muddati o'tib o'chirilgan
        if "channel_id" not in mcols:
            self._conn.execute("ALTER TABLE messages ADD COLUMN channel_id INTEGER")               # kanal posti (umumiy chat va lichkada NULL)
        self._conn.execute("CREATE INDEX IF NOT EXISTS idx_msg_channel ON messages(channel_id, id)")
        scols = columns("sessions")
        if "last_active" not in scols:
            self._conn.execute("ALTER TABLE sessions ADD COLUMN last_active REAL")             # oxirgi FAOL vaqt (faolsizlikdan keyin sessiya tugaydi)
        if "device" not in scols:
            self._conn.execute("ALTER TABLE sessions ADD COLUMN device TEXT")   # qurilma nomi (brauzer • tizim)
        if "persistent" not in scols:
            self._conn.execute("ALTER TABLE sessions ADD COLUMN persistent INTEGER NOT NULL DEFAULT 0")   # 1 = \"kirib qolish\": har kirishda login so'ralmaydi
        rcols = columns("reports")
        if "envelope" not in rcols:
            self._conn.execute("ALTER TABLE reports ADD COLUMN envelope TEXT")                    # shikoyat vaqtidagi shifrlangan xabar
        self._conn.execute("CREATE INDEX IF NOT EXISTS idx_msg_group ON messages(recipient_id, id)")
        self._conn.execute("CREATE INDEX IF NOT EXISTS idx_msg_dm ON messages(user_id, recipient_id, id)")

    def snapshot(self, dest: Path) -> None:
        """Ishlab turgan bazaning izchil nusxasini `dest` ga yozadi (SQLite backup API; yozuvlar to'xtatilmaydi)."""
        with self._lock:
            out = sqlite3.connect(str(dest))
            try:
                self._conn.backup(out)
            finally:
                out.close()

    def integrity_check(self) -> list[str]:
        """Bo'sh ro'yxat — baza butun; aks holda topilgan muammolar."""
        with self._lock:
            rows = [r[0] for r in self._conn.execute("PRAGMA integrity_check")]
            fk = [f"foreign key: {tuple(r)}" for r in self._conn.execute("PRAGMA foreign_key_check")]
        return ([] if rows == ["ok"] else rows) + fk

    def all(self, sql: str, args=()) -> list[sqlite3.Row]:
        with self._lock:
            return self._conn.execute(sql, args).fetchall()

    def one(self, sql: str, args=()) -> sqlite3.Row | None:
        with self._lock:
            return self._conn.execute(sql, args).fetchone()

    def run(self, sql: str, args=()) -> int:
        with self._lock:
            cur = self._conn.execute(sql, args)
            self._conn.commit()
            return cur.lastrowid


from app.services import dbsync  # noqa: E402  (baza ochilishidan oldin R2 dan tiklash kerak)

dbsync.restore_if_needed()
db = Database(settings.db_path)
