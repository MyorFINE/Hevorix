# Arxitektura xaritasi

Mavjud kod ishlashi o'zgarmasligi uchun ko'chirilmadi; yangi funksiyalar `features/` ichida. Quyida har bir qatlam qaysi fayllarga to'g'ri kelishi:

- `features/authentication` → app.services.auth, app.api.auth, app.features.authentication.username, app.security
- `features/messaging` → app.services.chat, app.api.chat, app.commands, app.features.messaging.pins, app.repositories.messages
- `features/reactions` → app.services.reactions, app.repositories.reactions
- `features/typing` → app.realtime.manager
- `features/message-search` → app.repositories.messages
- `features/attachments` → app.services.media, app.api.media, app.services.imgclean
- `features/voice-messages` → app.services.media
- `features/video-messages` → app.services.media
- `features/encryption` → app.crypto, app.services.e2ee, app.api.e2ee, app.transport
- `features/privacy` → app.features.privacy.ipref, app.netutil
- `features/device-management` → app.services.auth, app.repositories.sessions
- `features/notifications` → app.services.webpush, app.api.push
- `features/channels` → app.services.channels, app.api.channels, app.repositories.channels
- `features/contacts` → app.services.avatars, app.api.social, app.repositories.users
- `features/moderation` → app.services.modsettings, app.api.admin, app.services.ipblock, app.features.moderation.service
- `features/backups` → app.services.dbsync, app.datasnap
- `bootstrap` → app.main, app.config, app.db
- `core` → app.errors, app.constants, app.roles, app.security
- `shared` → app.netutil, app.sri
- `entities` → app.repositories.users, app.repositories.messages, app.repositories.channels
- `pages` → app/static/index.html, app/static/js/app.js
- `infrastructure` → app.db, app.transport, app.realtime.manager, app.crypto
- `workers` → app.services.serverstatus, app.datasnap
- `styles` → app/static/css/style.css
- `tests` → tests/ (loyiha ildizida)
