"""Umumiy konstantalar."""

# WebSocket yopilish kodlari (4000+ - ilova kodlari)
WS_UNAUTHORIZED = 4401
WS_FORBIDDEN = 4403
WS_IP_BLOCKED = 4410
WS_IDLE = 4408             # yurak urishi to'xtadi (ulanish o'lik): mijoz qayta ulanadi, foydalanuvchi oflayn bo'ladi
WS_REKEY = 4428            # shifrlash sessiyasi topilmadi: mijoz qayta qo'l siqishi (handshake) kerak

# Doimiy band username (platforma egasi). Katta-kichik harfga e'tibor berilmaydi.
OWNER_USERNAME = "Hevorix"
