"""Shaxmat dvigateli (faqat server tomonida): qonuniy yurishlar, shoh/mat/pat, rokirovka, en passant, o'tkazish,
durang qoidalari (pat, yetarsiz material, 50 yurish, uch marta takror).

Taxta: 64 belgidan iborat ro'yxat. Indeks = (qator-1)*8 + ustun; a1 = 0, h1 = 7, a8 = 56, h8 = 63.
Belgilar: katta harf — oq (PNBRQK), kichik — qora (pnbrqk), '.' — bo'sh.
"""
from __future__ import annotations

FILES = "abcdefgh"
START = "RNBQKBNRPPPPPPPP" + "." * 32 + "pppppppprnbqkbnr"
VALUE = {"p": 1, "n": 3, "b": 3, "r": 5, "q": 9, "k": 0}

_KNIGHT = ((1, 2), (2, 1), (-1, 2), (-2, 1), (1, -2), (2, -1), (-1, -2), (-2, -1))
_KING = ((1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1), (-1, 1), (-1, -1))
_BISHOP = ((1, 1), (1, -1), (-1, 1), (-1, -1))
_ROOK = ((1, 0), (-1, 0), (0, 1), (0, -1))


def name(i: int) -> str:
    return FILES[i % 8] + str(i // 8 + 1)


def idx(s: str) -> int:
    if not isinstance(s, str) or len(s) != 2 or s[0] not in FILES or s[1] not in "12345678":
        raise ValueError("noto'g'ri katak")
    return (int(s[1]) - 1) * 8 + FILES.index(s[0])


def color(p: str) -> str:
    return "w" if p.isupper() else "b"


class Position:
    __slots__ = ("b", "turn", "castle", "ep", "half", "full")

    def __init__(self) -> None:
        self.b: list[str] = list(START)
        self.turn = "w"
        self.castle = {"K", "Q", "k", "q"}
        self.ep = -1                      # en passant nishon katagi (yoki -1)
        self.half = 0                     # pyon yurishi/olishdan beri yarim yurishlar (50 yurish qoidasi)
        self.full = 1

    def copy(self) -> "Position":
        p = Position.__new__(Position)
        p.b = self.b[:]
        p.turn = self.turn
        p.castle = set(self.castle)
        p.ep = self.ep
        p.half = self.half
        p.full = self.full
        return p

    # ------------------------------------------------------------ hujum tekshiruvi
    def attacked(self, sq: int, by: str) -> bool:
        b = self.b
        f, r = sq % 8, sq // 8
        pawn, knight, king, bishop, rook, queen = ("P", "N", "K", "B", "R", "Q") if by == "w" else ("p", "n", "k", "b", "r", "q")
        pr = r - 1 if by == "w" else r + 1            # hujum qiluvchi pyon shu qatorda turadi
        if 0 <= pr < 8:
            for df in (-1, 1):
                if 0 <= f + df < 8 and b[pr * 8 + f + df] == pawn:
                    return True
        for df, dr in _KNIGHT:
            x, y = f + df, r + dr
            if 0 <= x < 8 and 0 <= y < 8 and b[y * 8 + x] == knight:
                return True
        for df, dr in _KING:
            x, y = f + df, r + dr
            if 0 <= x < 8 and 0 <= y < 8 and b[y * 8 + x] == king:
                return True
        for dirs, pieces in ((_BISHOP, (bishop, queen)), (_ROOK, (rook, queen))):
            for df, dr in dirs:
                x, y = f + df, r + dr
                while 0 <= x < 8 and 0 <= y < 8:
                    p = b[y * 8 + x]
                    if p != ".":
                        if p in pieces:
                            return True
                        break
                    x += df
                    y += dr
        return False

    def king_sq(self, side: str) -> int:
        return self.b.index("K" if side == "w" else "k")

    def in_check(self, side: str | None = None) -> bool:
        side = side or self.turn
        return self.attacked(self.king_sq(side), "b" if side == "w" else "w")

    # ------------------------------------------------------------ yurishlarni hosil qilish
    def _pseudo(self):
        b, me = self.b, self.turn
        enemy = "b" if me == "w" else "w"
        for i in range(64):
            p = b[i]
            if p == "." or color(p) != me:
                continue
            f, r = i % 8, i // 8
            t = p.lower()
            if t == "p":
                d = 1 if me == "w" else -1
                start, last = (1, 7) if me == "w" else (6, 0)
                nr = r + d
                if 0 <= nr < 8:
                    if b[nr * 8 + f] == ".":
                        if nr == last:
                            for pr in "qrbn":
                                yield i, nr * 8 + f, pr
                        else:
                            yield i, nr * 8 + f, ""
                            if r == start and b[(r + 2 * d) * 8 + f] == ".":
                                yield i, (r + 2 * d) * 8 + f, ""
                    for df in (-1, 1):
                        x = f + df
                        if not 0 <= x < 8:
                            continue
                        to = nr * 8 + x
                        q = b[to]
                        if (q != "." and color(q) == enemy) or to == self.ep:
                            if nr == last:
                                for pr in "qrbn":
                                    yield i, to, pr
                            else:
                                yield i, to, ""
            elif t == "n" or t == "k":
                for df, dr in (_KNIGHT if t == "n" else _KING):
                    x, y = f + df, r + dr
                    if 0 <= x < 8 and 0 <= y < 8:
                        q = b[y * 8 + x]
                        if q == "." or color(q) == enemy:
                            yield i, y * 8 + x, ""
                if t == "k":
                    yield from self._castles(i)
            else:
                dirs = _BISHOP if t == "b" else _ROOK if t == "r" else _BISHOP + _ROOK
                for df, dr in dirs:
                    x, y = f + df, r + dr
                    while 0 <= x < 8 and 0 <= y < 8:
                        q = b[y * 8 + x]
                        if q == ".":
                            yield i, y * 8 + x, ""
                        else:
                            if color(q) == enemy:
                                yield i, y * 8 + x, ""
                            break
                        x += df
                        y += dr

    def _castles(self, ksq: int):
        me = self.turn
        enemy = "b" if me == "w" else "w"
        home = 4 if me == "w" else 60
        if ksq != home or self.in_check(me):
            return
        b = self.b
        base = 0 if me == "w" else 56
        rook = "R" if me == "w" else "r"
        k_right, q_right = ("K", "Q") if me == "w" else ("k", "q")
        if k_right in self.castle and b[base + 7] == rook and b[base + 5] == "." and b[base + 6] == "." \
                and not self.attacked(base + 5, enemy) and not self.attacked(base + 6, enemy):
            yield ksq, base + 6, ""
        if q_right in self.castle and b[base] == rook and b[base + 1] == "." and b[base + 2] == "." and b[base + 3] == "." \
                and not self.attacked(base + 3, enemy) and not self.attacked(base + 2, enemy):
            yield ksq, base + 2, ""

    def legal(self) -> list[tuple[int, int, str]]:
        out = []
        me = self.turn
        for m in self._pseudo():
            q = self.copy()
            q._apply(*m)
            if not q.attacked(q.king_sq(me), "b" if me == "w" else "w"):
                out.append(m)
        return out

    def legal_map(self) -> dict[str, list[str]]:
        res: dict[str, list[str]] = {}
        for f, t, _ in self.legal():
            lst = res.setdefault(name(f), [])
            n = name(t)
            if n not in lst:
                lst.append(n)
        return res

    # ------------------------------------------------------------ yurishni bajarish
    def _apply(self, frm: int, to: int, promo: str) -> dict:
        b = self.b
        p = b[frm]
        cap = b[to]
        t = p.lower()
        info = {"cap": cap if cap != "." else "", "ep": False, "castle": "", "promo": ""}
        if t == "p" and to == self.ep and cap == ".":        # en passant: olingan pyon boshqa katakda
            csq = to - 8 if p == "P" else to + 8
            info["cap"] = b[csq]
            info["ep"] = True
            b[csq] = "."
        b[to] = p
        b[frm] = "."
        if t == "p" and (to // 8 in (0, 7)):
            np = (promo if promo in ("q", "r", "b", "n") else "q")
            b[to] = np.upper() if p == "P" else np
            info["promo"] = np
        if t == "k" and abs(to - frm) == 2:                   # rokirovka: ladya ham yuradi
            if to > frm:
                b[to - 1], b[to + 1] = b[to + 1], "."
                info["castle"] = "k"
            else:
                b[to + 1], b[to - 2] = b[to - 2], "."
                info["castle"] = "q"
        # rokirovka huquqlari
        if t == "k":
            self.castle -= {"K", "Q"} if p == "K" else {"k", "q"}
        for sq, right in ((0, "Q"), (7, "K"), (56, "q"), (63, "k")):
            if frm == sq or to == sq:
                self.castle.discard(right)
        # en passant katagi (faqat haqiqatan olish mumkin bo'lsa — takrorni to'g'ri sanash uchun)
        self.ep = -1
        if t == "p" and abs(to - frm) == 16:
            mid = (frm + to) // 2
            enemy_pawn = "p" if p == "P" else "P"
            for df in (-1, 1):
                x = to % 8 + df
                if 0 <= x < 8 and b[(to // 8) * 8 + x] == enemy_pawn:
                    self.ep = mid
        self.half = 0 if (t == "p" or cap != "." or info["ep"]) else self.half + 1
        if self.turn == "b":
            self.full += 1
        self.turn = "b" if self.turn == "w" else "w"
        return info

    def push(self, frm: int, to: int, promo: str = "") -> dict:
        """Qonuniy yurishni bajaradi; noqonuniy bo'lsa ValueError."""
        if not any(m[0] == frm and m[1] == to and (m[2] == (promo or "q") or not m[2]) for m in self.legal()):
            raise ValueError("noqonuniy yurish")
        return self._apply(frm, to, promo)

    # ------------------------------------------------------------ holat
    def key(self) -> str:
        return "".join(self.b) + self.turn + "".join(sorted(self.castle)) + str(self.ep)

    def material(self, side: str) -> int:
        return sum(VALUE[p.lower()] for p in self.b if p != "." and color(p) == side)

    def insufficient(self) -> bool:
        pcs = [p for p in self.b if p not in (".", "K", "k")]
        if not pcs:
            return True
        if all(p.lower() in ("b", "n") for p in pcs):
            if len(pcs) == 1:
                return True
            if all(p.lower() == "b" for p in pcs):           # faqat fillar: hammasi bir xil rangli katakda bo'lsa
                shades = {((i % 8) + (i // 8)) % 2 for i, p in enumerate(self.b) if p.lower() == "b"}
                return len(shades) == 1
        return False

    def can_mate(self, side: str) -> bool:
        """`side` qo'ldagi material bilan mat qila oladimi (vaqt tugaganda durang/yutuqni aniqlash uchun)."""
        mine = [p.lower() for p in self.b if p not in (".", "K", "k") and color(p) == side]
        if any(p in ("p", "r", "q") for p in mine):
            return True
        return len(mine) >= 2
