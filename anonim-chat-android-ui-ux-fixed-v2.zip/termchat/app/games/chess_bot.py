from __future__ import annotations

import random

from app.games.chess_engine import VALUE, Position, color

MATE = 100_000
NOISE = 30
_PV = {"p": 100, "n": 320, "b": 330, "r": 500, "q": 900, "k": 0}


def _pst(p: str, sq: int) -> int:
    t = p.lower()
    rank, file = sq >> 3, sq & 7
    if color(p) == "b":
        rank = 7 - rank
    cd = abs(3.5 - file) + abs(3.5 - rank)
    if t == "p":
        return rank * 6 + (8 if file in (3, 4) and rank in (3, 4, 5) else 0)
    if t in ("n", "b"):
        return int(28 - cd * 7)
    if t == "q":
        return int(8 - cd * 2)
    if t == "r":
        return 10 if rank == 6 else 0
    return 0


def evaluate(pos: Position) -> int:
    s = 0
    for i, p in enumerate(pos.b):
        if p == ".":
            continue
        v = _PV[p.lower()] + _pst(p, i)
        s += v if color(p) == "w" else -v
    return s if pos.turn == "w" else -s


def _order(pos: Position, moves):
    def key(m):
        cap = pos.b[m[1]]
        return -(VALUE[cap.lower()] * 10 - VALUE[pos.b[m[0]].lower()]) if cap != "." else 0
    return sorted(moves, key=key)


def _reply_score(q: Position, floor: int) -> int:
    replies = q.legal()
    if not replies:
        return -MATE if q.in_check() else 0
    best = MATE
    for m in _order(q, replies):
        c = q.copy()
        c._apply(*m)
        sc = evaluate(c)
        if sc < best:
            best = sc
            if best <= floor:
                break
    return best


def choose(pos: Position):
    moves = pos.legal()
    if not moves:
        return None
    scored = []
    best_real = -MATE * 2
    for m in _order(pos, moves):
        q = pos.copy()
        q._apply(*m)
        if not q.legal():
            if q.in_check():
                return m
            sc = 0
            if evaluate(pos) > 150:
                sc = -400
        else:
            sc = _reply_score(q, best_real - NOISE * 2)
        best_real = max(best_real, sc)
        scored.append((sc + random.uniform(-NOISE, NOISE), m))
    scored.sort(key=lambda x: -x[0])
    top = scored[0][0]
    pool = [m for s, m in scored[:3] if s >= top - 40]
    return random.choice(pool) if random.random() < 0.15 else scored[0][1]
