"""Durak (podkidnoy durak): 36 ta karta, 2–4 o'yinchi.

Karta — ikki belgi: daraja ("6789TJQKA") + mast ("SHDC" = ♠ ♥ ♦ ♣), masalan "TH" = ♥10.
Qoidalar:
  * har kimga 6 tadan; ostki karta kozer (u eng oxirgi olinadi). Kozer eng past bo'lgan o'yinchi birinchi yuradi (bo'lmasa 0-o'rin);
  * hujumchi bitta karta tashlaydi; himoyachi har bir tashlangan kartani shu mastning kattasi yoki kozer bilan uradi (kozerni faqat kattaroq kozer uradi);
  * navbat bilan qolgan o'yinchilar (soat strelkasi bo'yicha) stoldagi darajalardan biriga teng kartalarni qo'shishi (podkidka) yoki «bito/pas» deyishi mumkin;
  * stoldagi hujum kartalari soni 6 dan va round boshidagi himoyachi qo'lidagi kartalar sonidan oshmaydi;
  * himoyachi «olaman» desa, hujumchilar yana qo'shib tashlashi mumkin, so'ng hamma karta himoyachiga o'tadi va u navbatni o'tkazadi;
  * hamma uringan bo'lsa va hech kim qo'shmasa — «bito»: kartalar chiqib ketadi, himoyachi navbatdagi hujumchi bo'ladi;
  * round oxirida hujumchidan boshlab (himoyachi oxirida) hamma 6 tagacha karta oladi;
  * kolodada karta qolmagach, qo'li bo'sh o'yinchi o'yindan chiqadi; oxirgi qolgani — durak; hamma birdan chiqsa — durang.
Harakatlar: {"t":"atk","c":karta}, {"t":"def","c":karta,"i":stoldagi_juft_indeksi}, {"t":"take"}, {"t":"pass"}.
"""
from __future__ import annotations

import random

RANKS = "6789TJQKA"
SUITS = "SHDC"
HAND = 6


def rank(c: str) -> int:
    return RANKS.index(c[0])


def full_deck() -> list[str]:
    return [r + s for s in SUITS for r in RANKS]


class State:
    def __init__(self, n: int, deck: list[str] | None = None, rng: random.Random | None = None) -> None:
        if not 2 <= n <= 4:
            raise ValueError("O'yinchilar soni 2 dan 4 gacha")
        if deck is None:
            deck = full_deck()
            (rng or random).shuffle(deck)
        self.n = n
        self.deck = list(deck)               # oxiridan olinadi; deck[0] — kozer kartasi
        self.hands: list[list[str]] = [[] for _ in range(n)]
        for _ in range(HAND):
            for i in range(n):
                self.hands[i].append(self.deck.pop())
        self.trump_card = self.deck[0]
        self.trump = self.trump_card[1]
        self.out = [False] * n
        self.finish: list[int] = []
        self.discard = 0
        self.over: dict | None = None
        best, first = 99, 0
        for i, h in enumerate(self.hands):
            for c in h:
                if c[1] == self.trump and rank(c) < best:
                    best, first = rank(c), i
        self.att = first
        self.dfn = self._next(first)
        self._start_round()

    # ---- yordamchi ----
    def _next(self, seat: int) -> int:
        s = (seat + 1) % self.n
        while self.out[s] and s != seat:
            s = (s + 1) % self.n
        return s

    def _start_round(self) -> None:
        self.table: list[list[str | None]] = []
        self.phase = "attack"
        self.passed: set[int] = set()
        self.cap = min(HAND, len(self.hands[self.dfn]))
        self.turn = self.att

    def beats(self, att: str, c: str) -> bool:
        if c[1] == att[1]:
            return rank(c) > rank(att)
        return c[1] == self.trump and att[1] != self.trump

    def _unbeaten(self) -> list[int]:
        return [i for i, p in enumerate(self.table) if p[1] is None]

    def _attackers(self) -> list[int]:
        out, s = [], self.att
        for _ in range(self.n):
            if s != self.dfn and not self.out[s]:
                out.append(s)
            s = (s + 1) % self.n
        return out

    def throwable(self, seat: int) -> list[str]:
        if self.over or self.out[seat] or seat == self.dfn:
            return []
        h = self.hands[seat]
        if not self.table:
            return list(h) if seat == self.att else []
        if len(self.table) >= self.cap:
            return []
        if self.phase == "attack" and len(self.hands[self.dfn]) <= len(self._unbeaten()):
            return []
        ranks = {c[0] for p in self.table for c in p if c}
        return [c for c in h if c[0] in ranks]

    def _set_turn(self) -> None:
        if self.phase == "attack" and self._unbeaten():
            self.turn = self.dfn
            return
        if not self.table:
            self.turn = self.att
            return
        for s in self._attackers():
            if s not in self.passed and self.throwable(s):
                self.turn = s
                return
        self._end_round()

    def _end_round(self) -> None:
        took = self.phase == "take"
        cards = [c for p in self.table for c in p if c]
        if took:
            self.hands[self.dfn].extend(cards)
        else:
            self.discard += len(cards)
        self.table = []
        order = self._attackers() + [self.dfn]
        for s in order:
            if self.out[s]:
                continue
            while len(self.hands[s]) < HAND and self.deck:
                self.hands[s].append(self.deck.pop())
        for s in range(self.n):
            if not self.out[s] and not self.hands[s] and not self.deck:
                self.out[s] = True
                self.finish.append(s)
        alive = [s for s in range(self.n) if not self.out[s]]
        if len(alive) <= 1:
            self.over = {"loser": alive[0] if alive else None}
            self.turn = -1
            return
        dfn = self.dfn
        na = self._next(dfn) if took else (dfn if not self.out[dfn] else self._next(dfn))
        self.att = na
        self.dfn = self._next(na)
        self._start_round()

    # ---- ochiq interfeys ----
    def legal(self, seat: int) -> dict:
        res = {"cards": [], "take": False, "pass": False, "def": {}}
        if self.over or seat != self.turn:
            return res
        if seat == self.dfn:
            res["take"] = True
            for c in self.hands[seat]:
                idx = [i for i in self._unbeaten() if self.beats(self.table[i][0], c)]
                if idx:
                    res["def"][c] = idx
            res["cards"] = list(res["def"])
            return res
        res["cards"] = self.throwable(seat)
        res["pass"] = bool(self.table)
        return res

    def act(self, seat: int, a: dict) -> dict:
        if self.over:
            raise ValueError("o'yin tugagan")
        if seat != self.turn:
            raise ValueError("navbat sizda emas")
        t = a.get("t") if isinstance(a, dict) else None
        if t == "atk":
            c = a.get("c")
            if c not in self.throwable(seat):
                raise ValueError("bu kartani tashlab bo'lmaydi")
            self.hands[seat].remove(c)
            self.table.append([c, None])
            self.passed.clear()
            info = {"t": "atk", "seat": seat, "c": c}
        elif t == "def":
            if seat != self.dfn or self.phase != "attack":
                raise ValueError("siz himoyachi emassiz")
            c, i = a.get("c"), a.get("i")
            if not isinstance(i, int) or isinstance(i, bool) or i not in self._unbeaten() or c not in self.hands[seat] or not self.beats(self.table[i][0], c):
                raise ValueError("bu karta urmaydi")
            self.hands[seat].remove(c)
            self.table[i][1] = c
            info = {"t": "def", "seat": seat, "c": c, "i": i}
        elif t == "take":
            if seat != self.dfn or self.phase != "attack" or not self._unbeaten():
                raise ValueError("hozir olib bo'lmaydi")
            self.phase = "take"
            self.passed.clear()
            info = {"t": "take", "seat": seat}
        elif t == "pass":
            if seat == self.dfn or not self.table:
                raise ValueError("hozir pas qilib bo'lmaydi")
            self.passed.add(seat)
            info = {"t": "pass", "seat": seat}
        else:
            raise ValueError("noma'lum harakat")
        self._set_turn()
        return info

    def view(self, seat: int | None) -> dict:
        """`seat` o'yinchiga ko'rinadigan holat (boshqalarning kartalari yashirin)."""
        return {
            "n": self.n, "trump": self.trump, "trumpCard": self.trump_card if self.deck else None, "deck": len(self.deck),
            "counts": [len(h) for h in self.hands], "hand": list(self.hands[seat]) if seat is not None else [],
            "table": [list(p) for p in self.table], "att": self.att, "dfn": self.dfn, "turn": self.turn, "phase": self.phase,
            "cap": self.cap, "discard": self.discard, "out": list(self.out), "finish": list(self.finish),
            "legal": self.legal(seat) if seat is not None else None, "over": self.over,
        }
