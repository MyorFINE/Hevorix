"""Rus shashkasi (russkiye shashki) qoidalari.

Taxta: 64 katak, indeks = qator*8 + ustun, a1 = 0 (qorong'i katak). Toshlar: 'w' / 'b' — oddiy shashka, 'W' / 'B' — damka.
Qoidalar:
  * oq birinchi yuradi; oddiy shashka faqat oldinga bir katak yuradi, lekin oldinga ham, orqaga ham uradi;
  * damka istalgan masofaga yuradi va uzoqdan uradi (urilgan tosh ortidagi istalgan bo'sh katakka tushadi);
  * urish majburiy (eng ko'p urishni tanlash shart emas, lekin boshlangan urishni oxirigacha davom ettirish shart);
  * oddiy shashka urish paytida oxirgi qatorga yetsa — darhol damka bo'lib, o'sha yurishda urishni damka sifatida davom ettiradi;
  * "turk zarbasi": urilgan toshlar yurish tugaguncha taxtada turadi, bir toshni ikki marta urib bo'lmaydi va u yo'lni to'sadi;
  * damka urib, keyin yana urish mumkin bo'lgan katakni tanlashi shart;
  * yurish yo'q (toshlar tugagan yoki qamalgan) — yutqazadi;
  * durang: bir xil holat uch marta takrorlansa yoki 15 yurish davomida faqat damkalar bilan (urishsiz, oddiy shashkasiz) yurilsa.
Yurish — katakchalar yo'li: [boshlang'ich, ..., oxirgi]. Yo'l urilgan toshlarni bir ma'noda belgilaydi.
"""
from __future__ import annotations

DIRS = ((1, 1), (1, -1), (-1, 1), (-1, -1))
KING_ONLY_PLIES = 30  # 15 yurish (har ikki tomondan)


def idx(sq: str) -> int:
    if not isinstance(sq, str) or len(sq) != 2 or sq[0] not in "abcdefgh" or sq[1] not in "12345678":
        raise ValueError("katak noto'g'ri")
    return (ord(sq[1]) - 49) * 8 + ord(sq[0]) - 97


def name(i: int) -> str:
    return "abcdefgh"[i & 7] + str((i >> 3) + 1)


def start_board() -> list[str]:
    b = ["."] * 64
    for r in range(8):
        for f in range(8):
            if (f + r) % 2 == 0:
                if r < 3:
                    b[r * 8 + f] = "w"
                elif r > 4:
                    b[r * 8 + f] = "b"
    return b


def _on(f: int, r: int) -> bool:
    return 0 <= f < 8 and 0 <= r < 8


def _jumps(b: list[str], pos: int, king: bool, enemy: str, caps: list[int]) -> list[tuple[int, list[int]]]:
    """pos dan bir zarbada urish mumkin bo'lgan (urilgan tosh, tushish kataklari) ro'yxati."""
    out = []
    f0, r0 = pos & 7, pos >> 3
    for df, dr in DIRS:
        f, r = f0 + df, r0 + dr
        if king:
            while _on(f, r) and b[r * 8 + f] == ".":
                f += df
                r += dr
        if not _on(f, r):
            continue
        mid = r * 8 + f
        if b[mid] not in enemy or mid in caps:
            continue
        lands = []
        lf, lr = f + df, r + dr
        while _on(lf, lr) and b[lr * 8 + lf] == ".":
            lands.append(lr * 8 + lf)
            if not king:
                break
            lf += df
            lr += dr
        if lands:
            out.append((mid, lands))
    return out


def _capture_seqs(b: list[str], start: int, side: str) -> list[dict]:
    enemy = "bB" if side == "w" else "wW"
    promo_rank = 7 if side == "w" else 0
    piece = b[start]
    was_king = piece.isupper()
    res: list[dict] = []
    b[start] = "."

    def dfs(pos: int, king: bool, path: list[int], caps: list[int]) -> None:
        jumps = _jumps(b, pos, king, enemy, caps)
        if not jumps:
            if caps:
                res.append({"path": path, "caps": caps, "promo": king and not was_king})
            return
        for mid, lands in jumps:
            ncaps = caps + [mid]
            if king:
                cont = [l for l in lands if _jumps(b, l, True, enemy, ncaps)]
                for l in (cont or lands):
                    dfs(l, True, path + [l], ncaps)
            else:
                l = lands[0]
                dfs(l, (l >> 3) == promo_rank, path + [l], ncaps)

    try:
        dfs(start, was_king, [start], [])
    finally:
        b[start] = piece
    return res


def _simple_moves(b: list[str], start: int, side: str) -> list[dict]:
    piece = b[start]
    king = piece.isupper()
    promo_rank = 7 if side == "w" else 0
    f0, r0 = start & 7, start >> 3
    res = []
    for df, dr in DIRS:
        if not king and dr != (1 if side == "w" else -1):
            continue
        f, r = f0 + df, r0 + dr
        while _on(f, r) and b[r * 8 + f] == ".":
            to = r * 8 + f
            res.append({"path": [start, to], "caps": [], "promo": (not king) and r == promo_rank})
            if not king:
                break
            f += df
            r += dr
    return res


class Position:
    def __init__(self) -> None:
        self.b = start_board()
        self.turn = "w"
        self.half = 0  # urishsiz, oddiy shashkasiz yarim-yurishlar soni

    def copy(self) -> "Position":
        p = Position.__new__(Position)
        p.b, p.turn, p.half = self.b[:], self.turn, self.half
        return p

    def key(self) -> str:
        return "".join(self.b) + self.turn

    def legal(self) -> list[dict]:
        side = self.turn
        mine = "wW" if side == "w" else "bB"
        caps: list[dict] = []
        for i in range(64):
            if self.b[i] in mine:
                caps.extend(_capture_seqs(self.b, i, side))
        if caps:
            return caps
        moves: list[dict] = []
        for i in range(64):
            if self.b[i] in mine:
                moves.extend(_simple_moves(self.b, i, side))
        return moves

    def legal_map(self) -> dict[str, list[list[str]]]:
        out: dict[str, list[list[str]]] = {}
        for m in self.legal():
            p = m["path"]
            out.setdefault(name(p[0]), []).append([name(i) for i in p[1:]])
        return out

    def push(self, path) -> dict:
        try:
            want = [idx(s) for s in path]
        except (TypeError, ValueError):
            raise ValueError("yurish noto'g'ri")
        mv = next((m for m in self.legal() if m["path"] == want), None)
        if mv is None:
            raise ValueError("noqonuniy yurish")
        b = self.b
        piece = b[want[0]]
        was_man = piece.islower()
        for c in mv["caps"]:
            b[c] = "."
        b[want[0]] = "."
        b[want[-1]] = piece.upper() if (mv["promo"] or piece.isupper()) else piece
        if mv["caps"] or was_man:
            self.half = 0
        else:
            self.half += 1
        self.turn = "b" if self.turn == "w" else "w"
        return {"path": [name(i) for i in want], "caps": [name(c) for c in mv["caps"]], "promo": mv["promo"], "king": piece.isupper()}

    def counts(self) -> dict[str, int]:
        c = {"w": 0, "W": 0, "b": 0, "B": 0}
        for ch in self.b:
            if ch in c:
                c[ch] += 1
        return c
