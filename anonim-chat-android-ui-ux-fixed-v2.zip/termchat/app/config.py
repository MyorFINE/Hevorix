from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def _load_dotenv(path: Path) -> None:
    if not path.is_file():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


def _env(name: str, default):
    raw = os.getenv(f"TERMCHAT_{name}")
    if raw is None or raw == "":
        return default
    if isinstance(default, bool):
        return raw.strip().lower() in ("1", "true", "yes", "on")
    return type(default)(raw)


@dataclass(frozen=True)
class Settings:
    host: str
    port: int
    data_dir: Path
    tz_offset: int
    max_message_length: int
    history_limit: int
    initial_history: int
    idle_logout: int
    ws_idle_timeout: int
    away_grace: int
    new_user_days: int
    max_avatars: int
    max_avatar_bytes: int
    max_media_bytes: int
    max_music_bytes: int
    music_limit: int
    msg_rate_count: int
    msg_rate_window: int
    login_attempts: int
    login_window: int
    register_attempts: int
    register_window: int
    default_mute_minutes: int
    admin_password: str
    trust_proxy: bool
    activity_days: int
    master_key: str
    require_tunnel: bool
    require_e2ee: bool
    e2e_max_envelope: int
    vapid_private: str
    vapid_subject: str
    push_hosts: str
    push_max_devices: int
    auto_backup_hours: int
    auto_backup_keep: int
    r2_account_id: str
    r2_access_key_id: str
    r2_secret_access_key: str
    r2_bucket: str
    r2_endpoint: str
    r2_region: str
    media_ttl_hours: int
    db_sync_seconds: int

    @property
    def master_key_path(self) -> Path:
        return self.data_dir / "master.key"

    @property
    def vapid_key_path(self) -> Path:
        return self.data_dir / "vapid.key"

    @property
    def db_path(self) -> Path:
        return self.data_dir / "chat.db"

    @property
    def avatars_dir(self) -> Path:
        return self.data_dir / "avatars"

    @property
    def emoji_dir(self) -> Path:
        return self.data_dir / "emoji"

    @property
    def music_dir(self) -> Path:
        return self.data_dir / "music"

    @property
    def uploads_dir(self) -> Path:
        return self.data_dir / "uploads"

    @property
    def media_dir(self) -> Path:
        return self.data_dir / "media"

    @property
    def backups_dir(self) -> Path:
        return self.data_dir / "backups"

    @classmethod
    def load(cls) -> "Settings":
        _load_dotenv(ROOT / ".env")
        data_dir = Path(_env("DATA_DIR", str(ROOT / "data"))).resolve()
        port = int(os.getenv("TERMCHAT_PORT") or os.getenv("PORT") or 8000)
        s = cls(
            host=_env("HOST", "0.0.0.0"),
            port=port,
            data_dir=data_dir,
            tz_offset=_env("TZ_OFFSET", 5),
            max_message_length=_env("MAX_MESSAGE_LENGTH", 3000),
            history_limit=_env("HISTORY_LIMIT", 30),
            initial_history=_env("INITIAL_HISTORY", 10),
            idle_logout=_env("IDLE_LOGOUT", 300),
            ws_idle_timeout=_env("WS_IDLE_TIMEOUT", 45),
            away_grace=_env("AWAY_GRACE", 6),
            new_user_days=_env("NEW_USER_DAYS", 7),
            max_avatars=_env("MAX_AVATARS", 3),
            max_avatar_bytes=_env("MAX_AVATAR_BYTES", 2 * 1024 * 1024),
            max_media_bytes=_env("MAX_MEDIA_BYTES", 50 * 1024 * 1024),
            max_music_bytes=_env("MAX_MUSIC_BYTES", 15 * 1024 * 1024),
            music_limit=_env("MUSIC_LIMIT", 3),
            msg_rate_count=_env("MSG_RATE_COUNT", 5),
            msg_rate_window=_env("MSG_RATE_WINDOW", 5),
            login_attempts=_env("LOGIN_ATTEMPTS", 8),
            login_window=_env("LOGIN_WINDOW", 300),
            register_attempts=_env("REGISTER_ATTEMPTS", 10),
            register_window=_env("REGISTER_WINDOW", 3600),
            default_mute_minutes=_env("DEFAULT_MUTE_MINUTES", 10),
            admin_password=_env("ADMIN_PASSWORD", ""),
            trust_proxy=_env("TRUST_PROXY", True),
            activity_days=_env("ACTIVITY_DAYS", 90),
            master_key=_env("MASTER_KEY", ""),
            require_tunnel=_env("REQUIRE_TUNNEL", True),
            require_e2ee=_env("REQUIRE_E2EE", True),
            e2e_max_envelope=_env("E2E_MAX_ENVELOPE", 32768),
            vapid_private=_env("VAPID_PRIVATE_KEY", ""),
            vapid_subject=_env("VAPID_SUBJECT", "mailto:admin@anonim-chat.invalid"),
            push_hosts=_env("PUSH_HOSTS", ""),
            push_max_devices=_env("PUSH_MAX_DEVICES", 5),
            auto_backup_hours=_env("AUTO_BACKUP_HOURS", 0),
            auto_backup_keep=_env("AUTO_BACKUP_KEEP", 3),
            r2_account_id=os.getenv("R2_ACCOUNT_ID", "").strip(),
            r2_access_key_id=os.getenv("R2_ACCESS_KEY_ID", "").strip(),
            r2_secret_access_key=os.getenv("R2_SECRET_ACCESS_KEY", "").strip(),
            r2_bucket=os.getenv("R2_BUCKET_NAME", "").strip(),
            r2_endpoint=os.getenv("R2_ENDPOINT", "").strip(),
            r2_region=os.getenv("R2_REGION", "auto").strip().lower() or "auto",
            media_ttl_hours=_env("MEDIA_TTL_HOURS", 24),
            db_sync_seconds=_env("DB_SYNC_SECONDS", 120),
        )
        s.avatars_dir.mkdir(parents=True, exist_ok=True)
        s.emoji_dir.mkdir(parents=True, exist_ok=True)
        s.music_dir.mkdir(parents=True, exist_ok=True)
        s.uploads_dir.mkdir(parents=True, exist_ok=True)
        s.media_dir.mkdir(parents=True, exist_ok=True)
        return s


settings = Settings.load()
