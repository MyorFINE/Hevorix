from __future__ import annotations

import re
import time

from app.config import ROOT

EMOJI_DIR = ROOT / "app" / "static" / "emoji"
NAME = re.compile(r"^[a-z0-9_]{2,32}$")
TOKEN = re.compile(r"^:([a-z0-9_]{2,32}):$")
EXTS = (".svg", ".png", ".webp")
MAX_FILE_BYTES = 256 * 1024
_TTL = 10.0

LABELS = {
    "kali": "Kali Linux",
    "linux": "Linux (Tux)",
    "anon": "Anonymous niqobi",
    "ghost": "Ghost (Simon Riley)",
}
_cache: tuple[float, dict[str, str]] = (0.0, {})


def _custom() -> dict[str, str]:
    try:
        from app.repositories import emojis as repo
        return {r["name"]: r["file"] for r in repo.all_emojis()}
    except Exception:
        return {}


def _scan() -> dict[str, str]:
    found: dict[str, str] = {}
    if EMOJI_DIR.is_dir():
        for p in sorted(EMOJI_DIR.iterdir()):
            if p.suffix.lower() in EXTS and p.is_file() and NAME.match(p.stem) and p.stat().st_size <= MAX_FILE_BYTES:
                found.setdefault(p.stem, p.name)
    return found


def builtin() -> dict[str, str]:
    global _cache
    now = time.monotonic()
    if now - _cache[0] > _TTL:
        _cache = (now, _scan())
    return _cache[1]


def available() -> dict[str, str]:
    return {**_custom(), **builtin()}


def listing() -> list[dict]:
    return [{"name": n, "token": f":{n}:", "file": f, "url": f"/static/emoji/{f}", "label": LABELS.get(n, n.replace("_", " ").title()),
             "builtin": True} for n, f in builtin().items()]


def is_token(value: str) -> bool:
    m = TOKEN.match(value or "")
    return bool(m) and m.group(1) in available()


def reset_cache() -> None:
    global _cache
    _cache = (0.0, {})
