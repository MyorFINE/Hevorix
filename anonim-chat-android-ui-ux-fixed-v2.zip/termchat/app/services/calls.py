"""Ovozli qo'ng'iroq holati (faqat xotirada; fastapi'ga bog'liq emas — alohida testlanadi).

Qoidalar:
  * qo'ng'iroq FAQAT ikki kishi o'rtasida: chaqiruvchi va chaqirilgan. Signallar faqat shu ikki foydalanuvchidan qabul qilinadi
    va faqat ikkinchisiga uzatiladi (uchinchi kishi qo'ng'iroq identifikatorini bilsa ham hech narsa qila olmaydi: "gone");
  * bitta foydalanuvchida bir vaqtda bitta qo'ng'iroq (band bo'lsa — "busy");
  * har tomon o'z WebSocket ulanishiga bog'lanadi: boshqa qurilma/tabdan aralashib bo'lmaydi.
Server SDP va kalit almashuvini ko'radi, lekin ovozni ochish uchun kerakli kalitni (parol + qurilmadagi ECDH) bilmaydi.
"""
from __future__ import annotations

import secrets
import time
from dataclasses import dataclass, field
from typing import Any


class CallError(Exception):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code, self.message = code, message


@dataclass
class Call:
    id: str
    caller: int
    callee: int
    created: float
    state: str = "ringing"              # ringing -> active -> (o'chiriladi)
    answered_at: float = 0.0
    ws: dict = field(default_factory=dict)         # uid -> bog'langan WebSocket
    timer: Any = None

    def other(self, uid: int) -> int:
        return self.callee if uid == self.caller else self.caller

    def has(self, uid: int) -> bool:
        return uid == self.caller or uid == self.callee


class CallBook:
    def __init__(self) -> None:
        self._calls: dict[str, Call] = {}
        self._by_user: dict[int, str] = {}

    def start(self, caller: int, callee: int, ws: Any, now: float | None = None) -> Call:
        if caller == callee:
            raise CallError("self", "O'zingizga qo'ng'iroq qilib bo'lmaydi")
        if caller in self._by_user:
            raise CallError("busy_self", "Siz allaqachon qo'ng'iroqdasiz")
        if callee in self._by_user:
            raise CallError("busy", "Foydalanuvchi band (boshqa qo'ng'iroqda)")
        c = Call(secrets.token_urlsafe(16), caller, callee, now if now is not None else time.time())
        c.ws[caller] = ws
        self._calls[c.id] = c
        self._by_user[caller] = self._by_user[callee] = c.id
        return c

    def get(self, call_id: Any, uid: int) -> Call:
        """Qo'ng'iroq yo'q yoki siz uning ishtirokchisi emassiz — bir xil javob (mavjudligi oshkor bo'lmasin)."""
        c = self._calls.get(call_id) if isinstance(call_id, str) else None
        if c is None or not c.has(uid):
            raise CallError("gone", "Qo'ng'iroq topilmadi yoki tugagan")
        return c

    def accept(self, call_id: Any, uid: int, ws: Any) -> Call:
        c = self.get(call_id, uid)
        if uid != c.callee:
            raise CallError("role", "Qo'ng'iroqni faqat chaqirilgan tomon qabul qiladi")
        if c.state != "ringing":
            raise CallError("gone", "Qo'ng'iroq allaqachon qabul qilingan")
        c.state, c.answered_at = "active", time.time()
        c.ws[uid] = ws
        return c

    def bound(self, c: Call, uid: int, ws: Any) -> bool:
        return c.ws.get(uid) is ws

    def rebind(self, call_id: Any, uid: int, ws: Any) -> Call:
        c = self.get(call_id, uid)
        if c.state != "active" and uid != c.caller:
            raise CallError("gone", "Qo'ng'iroq topilmadi yoki tugagan")
        c.ws[uid] = ws
        return c

    def end(self, call_id: str) -> Call | None:
        c = self._calls.pop(call_id, None)
        if c is None:
            return None
        for u in (c.caller, c.callee):
            if self._by_user.get(u) == call_id:
                self._by_user.pop(u, None)
        if c.timer is not None:
            try:
                c.timer.cancel()
            except Exception:
                pass
            c.timer = None
        return c

    def of_user(self, uid: int) -> Call | None:
        cid = self._by_user.get(uid)
        return self._calls.get(cid) if cid else None

    def ringing_for(self, uid: int) -> Call | None:
        c = self.of_user(uid)
        return c if c and c.state == "ringing" and c.callee == uid else None

    def count(self) -> int:
        return len(self._calls)


book = CallBook()
