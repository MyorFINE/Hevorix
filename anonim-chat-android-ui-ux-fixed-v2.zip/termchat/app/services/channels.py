"""Kanallar: admin yaratadi; ommaviy (hamma a'zo ko'radi) yoki shaxsiy (ro'yxatda ko'rinmaydi: faqat adminlar va username + parol
bilan qo'shilganlar). Postlar ostida ko'rishlar soni va kommentlar bor; kommentlar umumiy chatda ko'rinmaydi.

Eslatma: kanal postlari/kommentlari serverda o'qiladi (umumiy chat kabi E2EE emas), lekin bazada AES-GCM bilan shifrlangan holda yotadi."""
from __future__ import annotations

import re
import secrets
import time

from app import crypto
from app.config import settings
from app.errors import ChatError
from app.repositories import channels as repo
from app.repositories import users
from app.roles import is_admin
from app.security import hash_password, limiter, verify_password
from app.services import avatars as avatar_svc
from app.services import views

USERNAME = re.compile(r"^[a-z0-9_]{3,20}$")
_CTRL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")
POST_MAX = 4000
COMMENT_MAX = 1000
PAGE = 20
COMMENT_PAGE = 30


def _clean(text, limit: int) -> str:
    t = _CTRL.sub("", text if isinstance(text, str) else "").strip()
    if not t:
        raise ChatError("Matn bo'sh bo'lishi mumkin emas")
    if len(t) > limit:
        raise ChatError(f"Matn {limit} belgidan oshmasligi kerak")
    return t


def _ensure_can_write(user) -> None:
    left = views.mute_left(user)
    if left > 0:
        raise ChatError(f"Siz mute holatidasiz (~{int(left // 60) + 1} daqiqa qoldi)")


def _admin(user) -> None:
    if not is_admin(user):
        raise ChatError("Bu amal faqat adminlar uchun", 403)


def _nick(raw) -> str:
    n = _CTRL.sub("", raw if isinstance(raw, str) else "").strip()
    if not 1 <= len(n) <= 40:
        raise ChatError("Kanal nomi 1–40 belgi bo'lishi kerak")
    return n


def _uname(raw) -> str:
    u = (raw if isinstance(raw, str) else "").strip().lstrip("@").lower()
    if not USERNAME.match(u):
        raise ChatError("Kanal username'i 3–20 belgi: a-z, 0-9, _")
    return u


def _pw(raw) -> str:
    p = raw if isinstance(raw, str) else ""
    if not 4 <= len(p) <= 64:
        raise ChatError("Shaxsiy kanal paroli 4–64 belgi bo'lishi kerak")
    return p


# ---------------------------------------------------------------- ko'rinishlar
def channel_view(r, user) -> dict:
    staff = is_admin(user)
    return {"id": r["id"], "username": r["username"], "nickname": r["nickname"],
            "avatar": f"/avatars/{r['avatar']}" if r["avatar"] else None,
            "private": bool(r["is_private"]), "posts": r["posts"] or 0, "last_post": r["last_post"] or 0,
            "joined": bool(r["joined"]), "can_manage": staff, "members": (r["members"] or 0) if staff else None,
            "created": r["created_at"]}


def post_view(p) -> dict:
    return {"id": p["id"], "ch": p["channel_id"], "by": p["user_id"], "text": crypto.open_(p["content"], "chpost"), "ts": p["created_at"],
            "edited": bool(p["edited_at"]), "views": p["views"], "comments": p["comments"]}


def comment_view(c) -> dict:
    return {"id": c["id"], "post": c["post_id"], "user": views.user_view(c["user_id"]),
            "text": crypto.open_(c["content"], "chcom"), "ts": c["created_at"]}


# ---------------------------------------------------------------- ruxsat
def can_see(ch, user) -> bool:
    if not ch["is_private"] or is_admin(user):
        return True
    return repo.is_member(ch["id"], user["id"])


def get_visible(cid: int, user):
    ch = repo.get(cid, user["id"])
    if not ch or not can_see(ch, user):
        raise ChatError("Kanal topilmadi", 404)       # shaxsiy kanalning borligi ham oshkor qilinmaydi
    return ch


def audience(ch) -> list[int] | None:
    """None — hamma (ommaviy kanal); aks holda adminlar va a'zolar."""
    if not ch["is_private"]:
        return None
    return list(dict.fromkeys(users.staff_ids() + repo.member_ids(ch["id"])))


# ---------------------------------------------------------------- kanal
def list_channels(user) -> list[dict]:
    return [channel_view(r, user) for r in repo.list_for(user["id"], is_admin(user))]


def create(user, username, nickname, private: bool, password) -> dict:
    _admin(user)
    uname, nick = _uname(username), _nick(nickname)
    if repo.get_by_username(uname):
        raise ChatError("Bu kanal username'i band")
    pw_hash = hash_password(_pw(password)) if private else None
    cid = repo.create(uname, nick, private, pw_hash, user["id"], time.time())
    return channel_view(repo.get(cid, user["id"]), user)


def update(user, cid: int, *, username=None, nickname=None, private=None, password=None) -> dict:
    _admin(user)
    ch = repo.get(cid, user["id"])
    if not ch:
        raise ChatError("Kanal topilmadi", 404)
    fields: dict = {}
    if username is not None:
        u = _uname(username)
        other = repo.get_by_username(u)
        if other and other["id"] != cid:
            raise ChatError("Bu kanal username'i band")
        fields["username"] = u
    if nickname is not None:
        fields["nickname"] = _nick(nickname)
    new_private = bool(ch["is_private"]) if private is None else bool(private)
    if new_private:
        if password:                                    # yangi parol berilsa almashadi
            fields["pw_hash"] = hash_password(_pw(password))
        elif not ch["pw_hash"]:
            raise ChatError("Shaxsiy kanal uchun parol qo'ying")
        fields["is_private"] = 1
    else:
        fields["is_private"] = 0
        fields["pw_hash"] = None
        repo.clear_members(cid)                         # ommaviy bo'lsa a'zolik kerak emas
    repo.update(cid, **fields)
    if new_private and password and ch["is_private"]:   # parol almashdi: eski a'zolar yangi parolni bilmaydi — chiqariladi
        repo.clear_members(cid)
    return channel_view(repo.get(cid, user["id"]), user)


def set_avatar(user, cid: int, raw: bytes) -> dict:
    _admin(user)
    ch = repo.get(cid, user["id"])
    if not ch:
        raise ChatError("Kanal topilmadi", 404)
    if len(raw) > settings.max_avatar_bytes:
        raise ChatError(f"Rasm {settings.max_avatar_bytes // (1024 * 1024)} MB dan oshmasligi kerak")
    if not avatar_svc.sniff_image(raw):
        raise ChatError("Faqat PNG, JPG, WEBP yoki GIF rasmlar mumkin")
    from app.services import imgclean
    img = imgclean.clean(raw)
    name = f"ch_{secrets.token_hex(12)}.{img.ext}"
    (settings.avatars_dir / name).write_bytes(img.data)
    _drop_file(ch["avatar"])
    repo.update(cid, avatar=name)
    return channel_view(repo.get(cid, user["id"]), user)


def clear_avatar(user, cid: int) -> dict:
    _admin(user)
    ch = repo.get(cid, user["id"])
    if not ch:
        raise ChatError("Kanal topilmadi", 404)
    _drop_file(ch["avatar"])
    repo.update(cid, avatar=None)
    return channel_view(repo.get(cid, user["id"]), user)


def _drop_file(name) -> None:
    if name:
        try:
            (settings.avatars_dir / name).unlink()
        except OSError:
            pass


def delete(user, cid: int) -> None:
    _admin(user)
    ch = repo.get(cid, user["id"])
    if not ch:
        raise ChatError("Kanal topilmadi", 404)
    _drop_file(ch["avatar"])
    repo.delete(cid)


def join(user, username, password) -> dict:
    """Shaxsiy kanalga username + parol bilan qo'shilish. Xato xabari bir xil: kanal borligi oshkor bo'lmaydi."""
    limiter.check(f"chjoin:{user['id']}", 8, 300, "Juda ko'p urinish. Bir necha daqiqadan so'ng qayta urining")
    uname = (username if isinstance(username, str) else "").strip().lstrip("@").lower()
    ch = repo.get_by_username(uname) if USERNAME.match(uname) else None
    bad = ChatError("Kanal topilmadi yoki parol noto'g'ri", 404)
    if not ch or not ch["is_private"] or not ch["pw_hash"]:
        verify_password("x", "00$00")                    # vaqt farqi bilan aniqlashni qiyinlashtiradi
        raise bad
    if not verify_password(password if isinstance(password, str) else "", ch["pw_hash"]):
        raise bad
    repo.add_member(ch["id"], user["id"], time.time())
    return channel_view(repo.get(ch["id"], user["id"]), user)


def leave(user, cid: int) -> None:
    ch = repo.get(cid, user["id"])
    if not ch or not ch["is_private"]:
        raise ChatError("Kanal topilmadi", 404)
    repo.remove_member(cid, user["id"])


# ---------------------------------------------------------------- postlar
def posts(user, cid: int, before: int = 0, limit: int = 0) -> tuple[list[dict], bool]:
    get_visible(cid, user)
    n = max(1, min(limit or PAGE, 50))
    rows = repo.posts_page(cid, max(0, before), n + 1)
    more = len(rows) > n
    return [post_view(p) for p in reversed(rows[:n])], more


def add_post(user, cid: int, text) -> tuple[dict, dict]:
    _admin(user)
    ch = get_visible(cid, user)
    body = _clean(text, POST_MAX)
    pid = repo.add_post(cid, user["id"], crypto.seal(body, "chpost"), time.time())
    return ch, post_view(repo.post(pid))


def _post(user, cid: int, pid: int):
    ch = get_visible(cid, user)
    p = repo.post(pid)
    if not p or p["channel_id"] != cid:
        raise ChatError("Post topilmadi", 404)
    return ch, p


def edit_post(user, cid: int, pid: int, text) -> tuple[dict, dict]:
    _admin(user)
    ch, p = _post(user, cid, pid)
    repo.edit_post(pid, crypto.seal(_clean(text, POST_MAX), "chpost"), time.time())
    return ch, post_view(repo.post(pid))


def delete_post(user, cid: int, pid: int):
    _admin(user)
    ch, _ = _post(user, cid, pid)
    repo.delete_post(pid)
    return ch


def mark_viewed(user, cid: int, ids) -> tuple[dict, dict[int, int]]:
    ch = get_visible(cid, user)
    clean = [i for i in (ids if isinstance(ids, list) else [])[:50] if isinstance(i, int) and not isinstance(i, bool)]
    return ch, repo.view_posts(cid, user["id"], clean)


# ---------------------------------------------------------------- kommentlar
def comments(user, cid: int, pid: int, before: int = 0, limit: int = 0) -> tuple[list[dict], bool]:
    _post(user, cid, pid)
    n = max(1, min(limit or COMMENT_PAGE, 60))
    rows = repo.comments_page(pid, max(0, before), n + 1)
    more = len(rows) > n
    return [comment_view(c) for c in reversed(rows[:n])], more


def add_comment(user, cid: int, pid: int, text) -> tuple[dict, dict, int]:
    ch, _ = _post(user, cid, pid)
    _ensure_can_write(user)
    body = _clean(text, COMMENT_MAX)
    limiter.check(f"chcom:{user['id']}", 6, 30, "Sekinroq yozing (spam himoyasi)")
    kid = repo.add_comment(pid, user["id"], crypto.seal(body, "chcom"), time.time())
    return ch, comment_view(repo.comment(kid)), repo.comment_count(pid)


def delete_comment(user, cid: int, pid: int, kid: int) -> tuple[dict, int]:
    ch, _ = _post(user, cid, pid)
    c = repo.comment(kid)
    if not c or c["post_id"] != pid:
        raise ChatError("Komment topilmadi", 404)
    if c["user_id"] != user["id"] and not is_admin(user):
        raise ChatError("Faqat o'z kommentingizni o'chira olasiz", 403)
    repo.delete_comment(kid)
    return ch, repo.comment_count(pid)
