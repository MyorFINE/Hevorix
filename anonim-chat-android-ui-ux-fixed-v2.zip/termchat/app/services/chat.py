import re
import time
from math import ceil

from app import e2ee as envelope_fmt
from app.config import settings
from app.errors import ChatError
from app.repositories import channels as channels_repo
from app.repositories import e2ee as e2ee_repo
from app.repositories import logs, messages, users
from app.roles import Role, role_of
from app.security import limiter
from app.services import media, modsettings, privacy, views

_CTRL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


def _sanitize(text: str) -> str:
    return _CTRL.sub("", text).strip()[: settings.max_message_length]


def _ensure_can_write(user) -> None:
    left = views.mute_left(user)
    if left > 0:
        raise ChatError(f"Siz mute holatidasiz (~{ceil(left / 60)} daqiqa qoldi)")


def audience(msg) -> list[int] | None:
    if msg["recipient_id"] is None:
        return None
    return [msg["user_id"], msg["recipient_id"]]


def _partner(user, partner_id: int, *, allow_deleted: bool = False):
    p = users.get(partner_id) if isinstance(partner_id, int) else None
    if not p or p["banned"]:
        raise ChatError("Foydalanuvchi topilmadi", 404)
    if p["id"] == user["id"]:
        raise ChatError("O'zingizga yoza olmaysiz")
    if p["deleted"] and not allow_deleted:
        raise ChatError("Bu akkaunt o'chirilgan. Unga xabar yuborib bo'lmaydi", 403)
    return p


def _ensure_can_dm(user, partner) -> None:
    """Yopiq lichkali foydalanuvchiga faqat admin/ega yoki u o'zi ilgari yozgan odam yoza oladi."""
    if role_of(user) >= Role.ADMIN or not privacy.dm_closed(partner["id"]):
        return
    if privacy.has_written_to(user["id"], partner["id"]):
        return
    raise ChatError("Bu foydalanuvchi shaxsiy xabarlarni yopgan: unga faqat admin yoza oladi", 403)


def _note_dm(user, partner) -> None:
    privacy.allow_peer(user["id"], partner["id"])


def _page(rows: list, limit: int) -> tuple[list[dict], bool]:
    more = len(rows) > limit
    rows = rows[-limit:] if more else rows
    return [views.message_view(m) for m in rows], more


def _limit(n: int | None, default: int) -> int:
    return max(1, min(int(n or default), settings.history_limit))


def history_page(before: int = 0, limit: int | None = None) -> tuple[list[dict], bool]:
    n = _limit(limit, settings.initial_history)
    return _page(messages.recent(n, max(0, before)), n)


def history() -> list[dict]:
    return history_page()[0]


def dm_history_page(user, partner_id: int, before: int = 0, limit: int | None = None) -> tuple[list[dict], bool]:
    _partner(user, partner_id, allow_deleted=True)
    n = _limit(limit, settings.initial_history)
    return _page(messages.dm_history(user["id"], partner_id, n, max(0, before)), n)


def dm_history(user, partner_id: int) -> list[dict]:
    return dm_history_page(user, partner_id)[0]


def dialogs(user) -> list[dict]:
    out = []
    for r in messages.dialogs(user["id"]):
        partner = users.get(r["partner"])
        if not partner or partner["banned"]:
            continue
        out.append({
            "user": views.user_view(partner["id"]),
            "last": views.message_view(messages.get(r["last_id"])),
            "unread": r["unread"] or 0,
        })
    return out


def _reply_target(user, to: int | None, reply_to: int | None) -> int | None:
    if reply_to is None:
        return None
    m = messages.get_active(reply_to)
    if not m:
        raise ChatError("Javob beriladigan xabar topilmadi")
    if to is None:
        if m["recipient_id"] is not None or m["channel_id"]:
            raise ChatError("Bu xabar boshqa suhbatga tegishli")
    elif m["recipient_id"] is None or {m["user_id"], m["recipient_id"]} != {user["id"], to}:
        raise ChatError("Bu xabar boshqa suhbatga tegishli")
    return m["id"]


def _rate_limit(user) -> None:
    try:
        limiter.check(f"msg:{user['id']}", settings.msg_rate_count, settings.msg_rate_window,
                      "Sekinroq yozing (spam himoyasi)")
    except ChatError:
        auto = modsettings.spam_strike(user)
        if auto:
            raise ChatError(auto, 429)
        raise


def _plain_allowed() -> None:
    if settings.require_e2ee:
        raise ChatError("Xabar shifrlanmagan: server ochiq matnni qabul qilmaydi (E2EE majburiy). Sahifani yangilang", 400)


def _check_envelope(user, envelope, to: int | None, chan: bool = False) -> dict:
    if not user["ecdh_pub"]:
        raise ChatError("Avval E2EE kalitlaringiz yaratilishi kerak", 409)
    try:
        h = envelope_fmt.parse_envelope(envelope, settings.e2e_max_envelope)
    except ValueError:
        raise ChatError("Xabar shifrlanmagan yoki konvert noto'g'ri", 400)
    if chan:
        cur = e2ee_repo.current_epoch()
        if h["k"] != "c":
            raise ChatError("Konvert turi mos emas", 400)
        if cur < 1:
            raise ChatError("Guruh kaliti hali yaratilmagan, biroz kuting", 409)
        if h["ep"] != cur:
            raise ChatError("Guruh kaliti yangilangan, qayta urinib ko'ring", 409)
        return h
    if h["k"] == "c":
        raise ChatError("Konvert turi mos emas", 400)
    if to is None:
        cur = e2ee_repo.current_epoch()
        if h["k"] != "g":
            raise ChatError("Konvert turi mos emas", 400)
        if cur < 1:
            raise ChatError("Guruh kaliti hali yaratilmagan, biroz kuting", 409)
        if h["ep"] != cur:
            raise ChatError("Guruh kaliti yangilangan, qayta urinib ko'ring", 409)
    elif h["k"] != "d":
        raise ChatError("Konvert turi mos emas", 400)
    return h


def post_e2e(user, envelope, to: int | None = None, blob: str | None = None) -> dict:
    _ensure_can_write(user)
    p = None
    if to is not None:
        p = _partner(user, to)
        _ensure_can_dm(user, p)
        if not p["ecdh_pub"]:
            raise ChatError("Bu foydalanuvchi hali E2EE kalitlarini yaratmagan (u bir marta kirishi kerak)", 409)
    _check_envelope(user, envelope, to)
    size = None
    if blob is not None:
        b = e2ee_repo.get_blob(blob) if isinstance(blob, str) else None
        if not b or b["user_id"] != user["id"] or e2ee_repo.blob_attached(blob):
            raise ChatError("Fayl topilmadi, qayta yuklang")
        size = b["size"]
    if to is None:
        modsettings.check_group(user)
    _rate_limit(user)
    mid = messages.create(user["id"], envelope, time.time(), to, None, None, None, None, blob, None, None, size, e2e=True)
    if to is None:
        modsettings.note_post(user)
    else:
        _note_dm(user, p)
    return views.message_view(messages.get(mid))


def post_channel_e2e(user, ch, envelope, blob: str | None = None) -> dict:
    if role_of(user) < Role.ADMIN:
        raise ChatError("Kanalga faqat adminlar post yoza oladi", 403)
    _ensure_can_write(user)
    _check_envelope(user, envelope, None, chan=True)
    size = None
    if blob is not None:
        b = e2ee_repo.get_blob(blob) if isinstance(blob, str) else None
        if not b or b["user_id"] != user["id"] or e2ee_repo.blob_attached(blob):
            raise ChatError("Fayl topilmadi, qayta yuklang")
        size = b["size"]
    _rate_limit(user)
    mid = messages.create(user["id"], envelope, time.time(), None, None, None, None, None, blob, None, None, size, e2e=True,
                          channel_id=ch["id"])
    return views.message_view(messages.get(mid))


def edit_e2e(user, mid: int, envelope):
    _ensure_can_write(user)
    msg = messages.get_active(mid)
    if not msg or msg["user_id"] != user["id"]:
        raise ChatError("Faqat o'z xabaringizni tahrirlay olasiz")
    if not msg["e2e"]:
        raise ChatError("Bu eski (E2EE emas) xabar, uni tahrirlab bo'lmaydi")
    if msg["channel_id"] and role_of(user) < Role.ADMIN:
        raise ChatError("Kanal postini faqat adminlar tahrirlay oladi", 403)
    _check_envelope(user, envelope, msg["recipient_id"], chan=bool(msg["channel_id"]))
    messages.update_content(mid, envelope, time.time(), e2e=True)
    if msg["recipient_id"] is None and not msg["channel_id"]:
        logs.add("edit", message_id=mid, user_id=user["id"], actor_id=user["id"], old=msg["content"], new=envelope)
    return msg, envelope


def purge_legacy(actor) -> int:
    if role_of(actor) != Role.OWNER:
        raise ChatError("Buni faqat ega bajara oladi", 403)
    rows = messages.purge_legacy()
    for r in rows:
        media.remove_row(r)
    logs.add("clear", user_id=actor["id"], actor_id=actor["id"], new=f"eski xabarlar: {len(rows)} ta")
    return len(rows)


def post(user, text: str, to: int | None = None, reply_to: int | None = None) -> dict:
    _plain_allowed()
    _ensure_can_write(user)
    p = None
    if to is not None:
        p = _partner(user, to)
        _ensure_can_dm(user, p)
    text = _sanitize(text)
    if not text:
        raise ChatError("Bo'sh xabar")
    if to is None:
        modsettings.check_group(user)
    reply = _reply_target(user, to, reply_to)
    _rate_limit(user)
    mid = messages.create(user["id"], text, time.time(), to, None, reply)
    if to is None:
        modsettings.note_post(user)
    else:
        _note_dm(user, p)
    return views.message_view(messages.get(mid))


def post_media(user, raw: bytes, filename: str = "", mime: str = "", caption: str = "",
               to: int | None = None, reply_to: int | None = None) -> dict:
    _plain_allowed()
    _ensure_can_write(user)
    p = None
    if to is not None:
        p = _partner(user, to)
        _ensure_can_dm(user, p)
    caption = _sanitize(caption or "")
    media.validate(raw)
    if to is None:
        modsettings.check_group(user)
    reply = _reply_target(user, to, reply_to)
    _rate_limit(user)
    st = media.store(raw, filename, mime)
    try:
        mid = messages.create(user["id"], caption, time.time(), to, st.image, reply, st.width, st.height,
                              st.file, st.file_name, st.file_mime, st.size)
    except Exception:
        media.remove(st.image or st.file)
        raise
    if to is None:
        modsettings.note_post(user)
    else:
        _note_dm(user, p)
    return views.message_view(messages.get(mid))


def mark_read(user, partner_id: int) -> int:
    if not isinstance(partner_id, int):
        return 0
    return messages.mark_read(user["id"], partner_id)


def edit(user, mid: int, new_text: str):
    _plain_allowed()
    _ensure_can_write(user)
    msg = messages.get_active(mid)
    if not msg or msg["user_id"] != user["id"]:
        raise ChatError("Faqat o'z xabaringizni tahrirlay olasiz")
    new_text = _sanitize(new_text)
    if not new_text and not (msg["image"] or msg["file"]):
        raise ChatError("Matn bo'sh bo'lishi mumkin emas")
    if new_text == msg["content"]:
        raise ChatError("Matn o'zgarmagan")
    messages.update_content(mid, new_text, time.time())
    if msg["recipient_id"] is None:
        logs.add("edit", message_id=mid, user_id=user["id"], actor_id=user["id"], old=msg["content"], new=new_text)
    return msg, new_text


def delete(actor, mid: int):
    msg = messages.get_active(mid)
    if not msg:
        raise ChatError("Xabar topilmadi")
    is_dm = msg["recipient_id"] is not None
    if msg["user_id"] != actor["id"]:
        if is_dm:
            raise ChatError("Shaxsiy xabarni faqat yuboruvchi o'chira oladi")
        if role_of(actor) < Role.ADMIN:
            raise ChatError("Faqat o'z xabaringizni o'chira olasiz")
        owner_of_msg = users.get(msg["user_id"])
        if not msg["channel_id"] and role_of(owner_of_msg) >= Role.ADMIN and role_of(actor) != Role.OWNER:
            raise ChatError("Admin xabarini faqat ega o'chira oladi")
    elif msg["channel_id"] and role_of(actor) < Role.ADMIN:
        raise ChatError("Kanal postini faqat adminlar o'chira oladi", 403)
    messages.mark_deleted(mid)
    media.remove_row(msg)
    if msg["channel_id"]:
        channels_repo.drop_post_data(mid)
    elif not is_dm:
        logs.add("delete", message_id=mid, user_id=msg["user_id"], actor_id=actor["id"], old=msg["content"])
    return msg


MAX_BULK_DELETE = 200


def delete_many(actor, ids: list[int]):
    done, skipped = [], 0
    for mid in list(dict.fromkeys(ids))[:MAX_BULK_DELETE]:
        try:
            done.append(delete(actor, mid))
        except ChatError:
            skipped += 1
    return done, skipped


def clear_group(actor) -> int:
    if role_of(actor) < Role.ADMIN:
        raise ChatError("Chatni faqat adminlar tozalay oladi")
    rows = messages.clear_group()
    for r in rows:
        media.remove_row(r)
    logs.add("clear", user_id=actor["id"], actor_id=actor["id"], new=f"{len(rows)} ta xabar")
    return len(rows)


def delete_dm(user, partner_id: int) -> int:
    p = users.get(partner_id) if isinstance(partner_id, int) else None
    if not p or p["id"] == user["id"]:
        raise ChatError("Suhbat topilmadi", 404)
    rows = messages.clear_dm(user["id"], p["id"])
    for r in rows:
        media.remove_row(r)
    return len(rows)
