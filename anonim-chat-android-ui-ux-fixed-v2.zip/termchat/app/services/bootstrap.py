import logging
import secrets
import time

from app.config import settings
from app.constants import LEGACY_OWNER_USERNAME, OWNER_USERNAME
from app.repositories import users
from app.roles import Role
from app.security import hash_password, verify_password

log = logging.getLogger("termchat.bootstrap")


def ensure_owner() -> None:
    env_pw = settings.admin_password
    if env_pw and len(env_pw) < 6:
        log.error("TERMCHAT_ADMIN_PASSWORD kamida 6 belgi bo'lishi kerak — e'tiborga olinmadi")
        env_pw = ""

    user = users.get_by_username(OWNER_USERNAME)
    if user is None:
        generated = not env_pw
        password = env_pw or secrets.token_urlsafe(9)
        users.create(OWNER_USERNAME, OWNER_USERNAME, hash_password(password), Role.OWNER.db_name, time.time())
        if generated:
            log.warning("=" * 60)
            log.warning("Ega yaratildi: username=%s  parol=%s", OWNER_USERNAME, password)
            log.warning("Kirgach parolni profil sozlamalarida almashtiring (yoki TERMCHAT_ADMIN_PASSWORD bering).")
            log.warning("=" * 60)
        else:
            log.info("Ega yaratildi: %s", OWNER_USERNAME)
        _retire_legacy_owner()
        return

    _retire_legacy_owner()
    if user["role"] != Role.OWNER.db_name:
        users.set_role(user["id"], Role.OWNER.db_name)
        log.info("%s egalik huquqiga qaytarildi", OWNER_USERNAME)
    if env_pw and int(user["auth_v"] or 0) == 1:
        pass
    elif env_pw and not verify_password(env_pw, user["password_hash"]):
        users.set_password(user["id"], hash_password(env_pw))
        log.info("%s paroli TERMCHAT_ADMIN_PASSWORD bo'yicha yangilandi", OWNER_USERNAME)


def _retire_legacy_owner() -> None:
    """Eski ega (@Hevorix) endi egalik huquqiga ega emas: ega faqat @Asura.
    Akkaunt o'chirilmaydi (xabarlari va kalitlari saqlanadi) — oddiy admin bo'lib qoladi.
    Username qayta nomlanmaydi: parol va E2EE kalitlari username'dan olinadi, nomni o'zgartirish kirishni buzadi."""
    old = users.get_by_username(LEGACY_OWNER_USERNAME)
    if old is not None and old["role"] == Role.OWNER.db_name:
        users.set_role(old["id"], Role.ADMIN.db_name)
        log.warning("%s endi ega emas (admin qilindi). Ega: %s", LEGACY_OWNER_USERNAME, OWNER_USERNAME)
