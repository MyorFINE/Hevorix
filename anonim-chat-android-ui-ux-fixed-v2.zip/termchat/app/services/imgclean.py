from dataclasses import dataclass
from io import BytesIO

from app.errors import ChatError

try:
    from PIL import Image, ImageOps, ImageSequence
except ImportError:
    Image = None

MAX_PIXELS = 24_000_000
MAX_SIDE = 2560
MAX_FRAMES = 300
MAX_ANIM_PIXELS = 30_000_000
THUMB_SIDE = 28
_EXT = {"JPEG": "jpg", "PNG": "png", "WEBP": "webp", "GIF": "gif"}
BAD = "Rasm buzilgan yoki qo'llab-quvvatlanmaydi"

if Image is not None:
    Image.MAX_IMAGE_PIXELS = MAX_PIXELS


@dataclass
class Clean:
    data: bytes
    ext: str
    width: int
    height: int
    thumb: bytes


def _flat(im, bg=(34, 44, 56)):
    im = im.convert("RGBA")
    base = Image.new("RGB", im.size, bg)
    base.paste(im, mask=im.getchannel("A"))
    return base


def _thumb(im) -> bytes:
    t = _flat(im) if im.mode in ("RGBA", "LA", "P") else im.convert("RGB")
    t.thumbnail((THUMB_SIDE, THUMB_SIDE))
    out = BytesIO()
    t.save(out, "JPEG", quality=55)
    return out.getvalue()


def _fit(im, side: int = MAX_SIDE):
    if max(im.size) > side:
        im = im.copy()
        im.thumbnail((side, side), Image.LANCZOS)
    return im


def clean(raw: bytes, max_side: int = MAX_SIDE) -> Clean:
    if Image is None:
        raise ChatError("Serverda rasmlarni qayta ishlash moduli (Pillow) o'rnatilmagan", 500)
    try:
        im = Image.open(BytesIO(raw))
        fmt = im.format
        if fmt not in _EXT:
            raise ChatError("Faqat PNG, JPG, WEBP yoki GIF rasmlar mumkin")
        ext = _EXT[fmt]
        if im.width < 1 or im.height < 1 or im.width * im.height > MAX_PIXELS:
            raise ChatError("Rasm o'lchami juda katta")
        out = BytesIO()
        if getattr(im, "is_animated", False) and ext in ("gif", "webp"):
            n_frames = getattr(im, "n_frames", 1)
            if n_frames > MAX_FRAMES:
                raise ChatError("Animatsiya juda uzun")
            eff_w, eff_h = im.size
            scale = min(1.0, max_side / max(eff_w, eff_h))
            if int(eff_w * scale) * int(eff_h * scale) * n_frames > MAX_ANIM_PIXELS:
                raise ChatError("Animatsiya juda katta (kadrlar soni yoki o'lchami kamaytirilsin)")
            duration, loop = im.info.get("duration", 80), im.info.get("loop", 0)
            frames = [_fit(f.convert("RGBA"), max_side) for f in ImageSequence.Iterator(im)]
            first = frames[0]
            first.save(out, ext.upper(), save_all=True, append_images=frames[1:], duration=duration,
                       loop=loop, disposal=2) if ext == "gif" else \
                first.save(out, "WEBP", save_all=True, append_images=frames[1:], duration=duration,
                           loop=loop, quality=85)
            w, h = first.size
            thumb = _thumb(first)
        else:
            if fmt == "JPEG":
                im.draft("RGB", (max_side, max_side))
            im.load()
            im = ImageOps.exif_transpose(im) or im
            im = _fit(im, max_side)
            if ext == "jpg":
                im = im.convert("RGB") if im.mode != "RGB" else im
            elif im.mode not in ("RGB", "RGBA", "L", "LA"):
                im = im.convert("RGBA")
            im.info = {}
            if ext == "jpg":
                im.save(out, "JPEG", quality=88, optimize=True, progressive=True)
            elif ext == "png":
                im.save(out, "PNG", optimize=True)
            elif ext == "webp":
                im.save(out, "WEBP", quality=88)
            else:
                im.convert("RGBA").save(out, "GIF")
            w, h = im.size
            thumb = _thumb(im)
        return Clean(out.getvalue(), ext, w, h, thumb)
    except ChatError:
        raise
    except Exception:
        raise ChatError(BAD)
