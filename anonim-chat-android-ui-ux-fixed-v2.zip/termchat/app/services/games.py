"""Gaming: onlayn shaxmat. Server — yagona haqiqat manbai: yurishlar, soat, ochkolar shu yerda tekshiriladi.

Mijoz -> server (WebSocket):
  game_invite {to}                 taklif yuborish (oflaynga ham: push), INVITE_TTL soniya kutiladi
  game_reply  {id, accept}         taklifga javob
  game_cancel {id}                 yuborilgan taklifni bekor qilish
  game_move   {gid, from, to, promo?}
  game_resign {gid}
  game_react  {gid, emoji}
  game_sync   {}                   ulanganda: davom etayotgan o'yin / kutilayotgan taklifni qaytaradi
Server -> mijoz: game_invite, game_invite_sent, game_invite_end, game_state, game_over, game_react.

Faol o'yinlar xotirada (server qayta ishga tushsa tugaydi); natijalar (ochko) bazada.
"""
from __future__ import annotations

import asyncio
import logging
import random
import time

from app.errors import ChatError
from app.games import chess_engine as ce
from app.realtime.manager import manager
from app.repositories import games as repo
from app.repositories import users as users_repo
from app.security import limiter
from app.services import webpush

log = logging.getLogger("termchat.games")

GAME = "chess"
INVITE_TTL = 10                 # soniya: taklif shuncha vaqt kutiladi (oflayn foydalanuvchiga ham xuddi shu)
CLOCK_MS = 10 * 60 * 1000       # har bir o'yinchiga 10 daqiqa
FIRST_MOVE_S = 60               # birinchi yurish shuncha vaqtda qilinmasa o'yin bekor qilinadi (ochkosiz)
ABANDON_S = 90                  # o'yinchi shuncha vaqt aloqasiz qolsa — texnik mag'lubiyat
MIN_RATED_PLIES = 8             # undan qisqa o'yinlarda ochko berilmaydi (taslim bo'lib "ochko almashish"dan himoya)
PAIR_LIMIT = 5                  # bir juftlik 24 soatda ko'pi bilan shuncha o'yindan ochko oladi
WIN_BASE = 10
LOSS = 10
BONUS_CAP = 15
REACTIONS = ("😂", "😡", "😮", "👏", "😭", "🔥", "🤝", "😎", "👍", "❤️")

_invites: dict[str, dict] = {}
_out: dict[int, str] = {}       # yuboruvchi -> taklif id
_in: dict[int, str] = {}        # qabul qiluvchi -> taklif id
_games: dict[str, "Game"] = {}
_user_game: dict[int, str] = {}
_tasks: set[asyncio.Task] = set()


def _spawn(coro) -> asyncio.Task:
    t = asyncio.create_task(coro)
    _tasks.add(t)
    t.add_done_callback(_tasks.discard)
    return t


def _rid() -> str:
    import secrets
    return secrets.token_urlsafe(9)


class Game:
    def __init__(self, white: int, black: int) -> None:
        self.gid = _rid()
        self.white, self.black = white, black
        self.pos = ce.Position()
        self.clock = {"w": CLOCK_MS, "b": CLOCK_MS}
        self.t0 = time.monotonic()
        self.turn_t = self.t0
        self.started = time.time()
        self.plies = 0
        self.last: dict | None = None
        self.captured = {"w": [], "b": []}       # kim qaysi toshlarni olgan (olingan tosh belgisi)
        self.promos = {"w": 0, "b": 0}
        self.reps = {self.pos.key(): 1}
        self.legal = self.pos.legal_map()
        self.over: dict | None = None
        self.off: dict[int, float] = {}
        self.base = {"w": 0, "b": 0}              # o'yin boshidagi jami ochkolar
        self.watch: asyncio.Task | None = None

    def side_of(self, uid: int) -> str | None:
        return "w" if uid == self.white else "b" if uid == self.black else None

    def uid_of(self, side: str) -> int:
        return self.white if side == "w" else self.black


# ------------------------------------------------------------------------------------------ ochko hisobi
def _cap_value(g: Game, side: str) -> int:
    return sum(ce.VALUE[p.lower()] for p in g.captured[side])


def _bonus(g: Game, winner: str, mate: bool) -> dict:
    used = max(0, CLOCK_MS - g.clock[winner])
    speed = round(8 * max(0.0, 1 - used / (0.6 * CLOCK_MS)))                                   # tez yutish — ko'proq
    mat = min(6, max(0, _cap_value(g, winner) - _cap_value(g, "b" if winner == "w" else "w")) // 2)  # olingan toshlar ustunligi
    tactic = (3 if mate else 0) + min(2, g.promos[winner])                                     # mat va pyonni ferzga chiqarish
    total = min(BONUS_CAP, speed + mat + tactic)
    return {"speed": speed, "material": mat, "tactic": tactic, "total": total}


def win_preview(g: Game, side: str) -> int:
    """O'yinchi hozir yutsa taxminan necha ochko olishi (jonli ko'rsatkich)."""
    return WIN_BASE + _bonus(g, side, False)["total"]


def _is_rated(g: Game) -> bool:
    if g.plies < MIN_RATED_PLIES:
        return False
    return repo.pair_rated_since(GAME, g.white, g.black, time.time() - 86400) < PAIR_LIMIT


# ------------------------------------------------------------------------------------------ holat
def _remaining(g: Game, side: str) -> int:
    if g.over is None and side == g.pos.turn:
        return int(g.clock[side] - (time.monotonic() - g.turn_t) * 1000)
    return int(g.clock[side])


def _state(g: Game) -> dict:
    pos = g.pos
    check = ce.name(pos.king_sq(pos.turn)) if pos.in_check() else None
    return {
        "type": "game_state", "gid": g.gid, "game": GAME, "white": g.white, "black": g.black,
        "board": "".join(pos.b), "turn": pos.turn, "plies": g.plies, "last": g.last, "check": check,
        "legal": g.legal if g.over is None else {},
        "captured": g.captured,
        "clock": {"w": _remaining(g, "w"), "b": _remaining(g, "b"), "turn": pos.turn, "running": g.over is None},
        "preview": {"w": win_preview(g, "w"), "b": win_preview(g, "b")}, "base": g.base,
        "over": g.over,
    }


async def _push_state(g: Game) -> None:
    await manager.send_many([g.white, g.black], _state(g))


def _outcome_side(result: str, side: str) -> str:
    return "d" if result == "d" else ("w" if result == side else "l")


async def _finish(g: Game, result: str, reason: str) -> None:
    if g.over is not None:
        return
    mate = reason == "checkmate"
    rated = result != "d" and _is_rated(g)
    delta = {"w": 0, "b": 0}
    bonus = None
    if result in ("w", "b") and rated:
        loser = "b" if result == "w" else "w"
        bonus = _bonus(g, result, mate)
        delta[result] = WIN_BASE + bonus["total"]
        delta[loser] = -LOSS
    g.clock["w"], g.clock["b"] = max(0, _remaining(g, "w")), max(0, _remaining(g, "b"))
    now = time.time()
    totals, gained = {}, {}
    for side in ("w", "b"):
        uid = g.uid_of(side)
        before = (repo.stats(uid, GAME) or {"points": 0})["points"]
        totals[side] = repo.add_result(uid, GAME, delta[side], _outcome_side(result, side), now)
        gained[side] = totals[side] - before
    try:
        repo.log(GAME, g.white, g.black, result, reason, gained["w"], gained["b"], g.plies, rated, g.started, now)
    except Exception:
        log.exception("O'yin jurnaliga yozilmadi")
    g.over = {"result": result, "reason": reason, "rated": rated, "pts": gained, "total": totals, "bonus": bonus}
    if g.watch and g.watch is not asyncio.current_task():
        g.watch.cancel()
    for uid in (g.white, g.black):
        if _user_game.get(uid) == g.gid:
            _user_game.pop(uid, None)
    _games.pop(g.gid, None)
    await _push_state(g)
    await manager.send_many([g.white, g.black], {"type": "game_over", "gid": g.gid, **g.over})


# ------------------------------------------------------------------------------------------ nazorat (soat, uzilish)
async def _watch(g: Game) -> None:
    try:
        while g.over is None:
            await asyncio.sleep(0.5)
            if g.over is not None:
                return
            now = time.monotonic()
            side = g.pos.turn
            if g.clock[side] - (now - g.turn_t) * 1000 <= 0:
                other = "b" if side == "w" else "w"
                await _finish(g, other if g.pos.can_mate(other) else "d", "timeout" if g.pos.can_mate(other) else "timeout_draw")
                return
            if g.plies < 2 and now - g.t0 > FIRST_MOVE_S:
                await _finish(g, "d", "abort")
                return
            for uid in (g.white, g.black):
                if manager.connection_count(uid) > 0:
                    g.off.pop(uid, None)
                else:
                    since = g.off.setdefault(uid, now)
                    if now - since > ABANDON_S:
                        await _finish(g, "b" if uid == g.white else "w", "abandon")
                        return
    except asyncio.CancelledError:
        pass
    except Exception:
        log.exception("O'yin nazoratida xato (gid=%s)", g.gid)


# ------------------------------------------------------------------------------------------ takliflar
async def _end_invite(inv: dict, status: str) -> None:
    if _invites.pop(inv["id"], None) is None:
        return
    _out.pop(inv["frm"], None)
    _in.pop(inv["to"], None)
    t = inv.get("task")
    if t and t is not asyncio.current_task():
        t.cancel()
    await manager.send_many([inv["frm"], inv["to"]], {"type": "game_invite_end", "id": inv["id"], "status": status, "frm": inv["frm"], "to": inv["to"]})


async def _expire(iid: str) -> None:
    try:
        await asyncio.sleep(INVITE_TTL)
        inv = _invites.get(iid)
        if inv:
            await _end_invite(inv, "expired")
    except asyncio.CancelledError:
        pass


def _ttl_left(inv: dict) -> float:
    return max(0.0, INVITE_TTL - (time.time() - inv["created"]))


async def invite(user, to) -> None:
    uid = user["id"]
    if not isinstance(to, int) or isinstance(to, bool):
        raise ChatError("Foydalanuvchi noto'g'ri")
    if not limiter.allow(f"ginv:{uid}", 6, 30):
        raise ChatError("Takliflar juda tez yuborilmoqda")
    if to == uid:
        raise ChatError("O'zingizni taklif qila olmaysiz")
    target = users_repo.get(to)
    if not target or target["deleted"] or target["banned"]:
        raise ChatError("Foydalanuvchi topilmadi", 404)
    if uid in _user_game:
        raise ChatError("Siz hozir o'yindasiz")
    if to in _user_game:
        raise ChatError("Bu foydalanuvchi hozir o'yinda")
    if uid in _out:
        raise ChatError("Avvalgi taklifga javob kutilmoqda")
    if to in _in:
        raise ChatError("Bu foydalanuvchiga boshqa taklif kelgan, biroz kuting")
    inv = {"id": _rid(), "frm": uid, "to": to, "game": GAME, "created": time.time(), "task": None}
    inv["task"] = _spawn(_expire(inv["id"]))
    _invites[inv["id"]] = inv
    _out[uid] = inv["id"]
    _in[to] = inv["id"]
    await manager.send_to(to, {"type": "game_invite", "id": inv["id"], "frm": uid, "game": GAME, "ttl": INVITE_TTL})
    await manager.send_to(uid, {"type": "game_invite_sent", "id": inv["id"], "to": to, "ttl": INVITE_TTL})
    if not manager.is_online(to):
        webpush.fire_game_invite(to, user)                   # oflayn: bildirishnoma (ilovani ochsa, taklif muddati tugamagan bo'lsa ko'radi)


async def reply(user, iid, accept) -> None:
    inv = _invites.get(iid) if isinstance(iid, str) else None
    if not inv or inv["to"] != user["id"]:
        raise ChatError("Taklif muddati tugagan")
    if not accept:
        await _end_invite(inv, "declined")
        return
    a, b = inv["frm"], inv["to"]
    if a in _user_game or b in _user_game:
        await _end_invite(inv, "busy")
        return
    await _end_invite(inv, "accepted")
    white, black = (a, b) if random.random() < 0.5 else (b, a)          # oq/qora tasodifiy
    g = Game(white, black)
    g.base = {"w": (repo.stats(white, GAME) or {"points": 0})["points"], "b": (repo.stats(black, GAME) or {"points": 0})["points"]}
    _games[g.gid] = g
    _user_game[white] = _user_game[black] = g.gid
    g.watch = _spawn(_watch(g))
    await _push_state(g)


async def cancel(user, iid) -> None:
    inv = _invites.get(iid) if isinstance(iid, str) else None
    if inv and inv["frm"] == user["id"]:
        await _end_invite(inv, "cancelled")


# ------------------------------------------------------------------------------------------ o'yin amallari
def _game_of(user, gid) -> tuple[Game, str]:
    g = _games.get(gid) if isinstance(gid, str) else None
    if not g or g.over is not None:
        raise ChatError("O'yin tugagan")
    side = g.side_of(user["id"])
    if not side:
        raise ChatError("Bu o'yinda ishtirok etmaysiz", 403)
    return g, side


async def move(user, gid, frm, to, promo) -> None:
    g, side = _game_of(user, gid)
    if side != g.pos.turn:
        raise ChatError("Navbat sizda emas")
    if not limiter.allow(f"gmove:{user['id']}", 20, 10):
        raise ChatError("Juda tez yurilmoqda")
    now = time.monotonic()
    spent = (now - g.turn_t) * 1000
    if g.clock[side] - spent <= 0:
        other = "b" if side == "w" else "w"
        await _finish(g, other if g.pos.can_mate(other) else "d", "timeout" if g.pos.can_mate(other) else "timeout_draw")
        return
    try:
        f, t = ce.idx(frm), ce.idx(to)
        info = g.pos.push(f, t, promo if isinstance(promo, str) else "")
    except ValueError:
        await manager.send_to(user["id"], _state(g))               # mijoz holati eskirgan bo'lishi mumkin: qayta sinxronlaymiz
        raise ChatError("Noqonuniy yurish")
    g.clock[side] -= spent
    g.turn_t = now
    g.plies += 1
    if info["cap"]:
        g.captured[side].append(info["cap"])
    if info["promo"]:
        g.promos[side] += 1
    g.last = {"from": frm, "to": to, "promo": info["promo"], "cap": info["cap"], "ep": info["ep"], "castle": info["castle"]}
    key = g.pos.key()
    g.reps[key] = g.reps.get(key, 0) + 1
    g.legal = g.pos.legal_map()
    if not g.legal:
        if g.pos.in_check():
            await _finish(g, side, "checkmate")
        else:
            await _finish(g, "d", "stalemate")
    elif g.pos.insufficient():
        await _finish(g, "d", "insufficient")
    elif g.pos.half >= 100:
        await _finish(g, "d", "fifty")
    elif g.reps[key] >= 3:
        await _finish(g, "d", "repetition")
    else:
        await _push_state(g)


async def resign(user, gid) -> None:
    g, side = _game_of(user, gid)
    await _finish(g, "b" if side == "w" else "w", "resign")


async def react(user, gid, emoji) -> None:
    g, _ = _game_of(user, gid)
    if emoji not in REACTIONS:
        raise ChatError("Bunday reaksiya yo'q")
    if not limiter.allow(f"greact:{user['id']}", 8, 10):
        return
    await manager.send_many([g.white, g.black], {"type": "game_react", "gid": g.gid, "uid": user["id"], "emoji": emoji, "n": random.randint(1, 10 ** 9)})


async def sync(user) -> None:
    uid = user["id"]
    gid = _user_game.get(uid)
    g = _games.get(gid) if gid else None
    if g:
        await manager.send_to(uid, _state(g))
    iid = _in.get(uid)
    inv = _invites.get(iid) if iid else None
    if inv and _ttl_left(inv) > 0.3:
        await manager.send_to(uid, {"type": "game_invite", "id": inv["id"], "frm": inv["frm"], "game": GAME, "ttl": round(_ttl_left(inv), 1)})
    oid = _out.get(uid)
    out = _invites.get(oid) if oid else None
    if out and _ttl_left(out) > 0.3:
        await manager.send_to(uid, {"type": "game_invite_sent", "id": out["id"], "to": out["to"], "ttl": round(_ttl_left(out), 1)})


async def handle(user, data: dict) -> None:
    kind = data.get("type")
    if kind == "game_invite":
        await invite(user, data.get("to"))
    elif kind == "game_reply":
        await reply(user, data.get("id"), bool(data.get("accept")))
    elif kind == "game_cancel":
        await cancel(user, data.get("id"))
    elif kind == "game_move":
        await move(user, data.get("gid"), data.get("from"), data.get("to"), data.get("promo"))
    elif kind == "game_resign":
        await resign(user, data.get("gid"))
    elif kind == "game_react":
        await react(user, data.get("gid"), data.get("emoji"))
    elif kind == "game_sync":
        await sync(user)


def scoreboard(user) -> dict:
    top = [{"uid": r["user_id"], "points": r["points"], "wins": r["wins"], "losses": r["losses"], "draws": r["draws"]} for r in repo.top(GAME, 30)]
    me = repo.stats(user["id"], GAME)
    mine = {"points": me["points"], "wins": me["wins"], "losses": me["losses"], "draws": me["draws"]} if me else {"points": 0, "wins": 0, "losses": 0, "draws": 0}
    mine["rank"] = repo.rank_of(GAME, mine["points"]) if (me and (me["wins"] + me["losses"] + me["draws"])) else None
    return {"game": GAME, "top": top, "me": mine}
