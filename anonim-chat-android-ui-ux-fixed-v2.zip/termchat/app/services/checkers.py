"""Online rus shashkasi: taklif, yurishlar (server qoidalarni tekshiradi), soat, ochkolar.

Shaxmat xizmatidan (services/games.py) mustaqil: o'z taklif navbati va o'z o'yinlari bor, xabar turlari "ck_" bilan boshlanadi.
Ikkala o'yin bir vaqtda ochilmasligi uchun `busy()` o'zaro tekshiriladi. Ochkolar `game_stats` jadvalida game="checkers" bilan saqlanadi.
"""
from __future__ import annotations

import asyncio
import logging
import random
import secrets
import time

from app.errors import ChatError
from app.games import checkers_engine as ce
from app.realtime.manager import manager
from app.repositories import games as repo
from app.repositories import users as users_repo
from app.security import limiter
from app.services import webpush

log = logging.getLogger("termchat.checkers")

GAME = "checkers"
INVITE_TTL = 60
CLOCK_MS = 10 * 60 * 1000
FIRST_MOVE_S = 60
ABANDON_S = 90
MIN_RATED_PLIES = 8
PAIR_LIMIT = 5
WIN = 10
LOSS = 10
MAX_PATH = 40

_invites: dict[str, dict] = {}
_out: dict[int, str] = {}
_in: dict[int, str] = {}
_games: dict[str, "Game"] = {}
_user_game: dict[int, str] = {}
_tasks: set[asyncio.Task] = set()


def _spawn(coro) -> asyncio.Task:
    t = asyncio.create_task(coro)
    _tasks.add(t)
    t.add_done_callback(_tasks.discard)
    return t


def _rid() -> str:
    return secrets.token_urlsafe(9)


def busy(uid: int) -> bool:
    """Foydalanuvchi shashka o'yinida yoki taklif jarayonida (shaxmat xizmati shuni tekshiradi)."""
    return uid in _user_game or uid in _out or uid in _in


def _chess_busy(uid: int) -> bool:
    from app.services import games as chess
    return uid in chess._user_game or uid in chess._out or uid in chess._in


class Game:
    def __init__(self, white: int, black: int) -> None:
        self.gid = _rid()
        self.white, self.black = white, black
        self.pos = ce.Position()
        self.clock = {"w": CLOCK_MS, "b": CLOCK_MS}
        self.t0 = time.monotonic()
        self.turn_t = self.t0
        self.started = time.time()
        self.plies = 0
        self.last: dict | None = None
        self.reps = {self.pos.key(): 1}
        self.legal = self.pos.legal_map()
        self.over: dict | None = None
        self.off: dict[int, float] = {}
        self.base = {"w": 0, "b": 0}
        self.watch: asyncio.Task | None = None
        self.hist: list[str] = []

    def side_of(self, uid: int) -> str | None:
        return "w" if uid == self.white else "b" if uid == self.black else None

    def uid_of(self, side: str) -> int:
        return self.white if side == "w" else self.black


def _remaining(g: Game, side: str) -> int:
    if g.over is None and side == g.pos.turn:
        return int(g.clock[side] - (time.monotonic() - g.turn_t) * 1000)
    return int(g.clock[side])


def _state(g: Game) -> dict:
    return {
        "type": "ck_state", "gid": g.gid, "game": GAME, "white": g.white, "black": g.black,
        "board": "".join(g.pos.b), "turn": g.pos.turn, "plies": g.plies, "last": g.last,
        "legal": g.legal if g.over is None else {},
        "clock": {"w": _remaining(g, "w"), "b": _remaining(g, "b"), "turn": g.pos.turn, "running": g.over is None},
        "base": g.base, "hist": list(g.hist), "over": g.over,
    }


async def _push_state(g: Game) -> None:
    await manager.send_many([g.white, g.black], _state(g))


def _is_rated(g: Game) -> bool:
    if g.plies < MIN_RATED_PLIES:
        return False
    return repo.pair_rated_since(GAME, g.white, g.black, time.time() - 86400) < PAIR_LIMIT


async def _finish(g: Game, result: str, reason: str) -> None:
    if g.over is not None:
        return
    rated = result != "d" and _is_rated(g)
    delta = {"w": 0, "b": 0}
    if result in ("w", "b") and rated:
        delta[result] = WIN
        delta["b" if result == "w" else "w"] = -LOSS
    g.clock["w"], g.clock["b"] = max(0, _remaining(g, "w")), max(0, _remaining(g, "b"))
    now = time.time()
    totals, gained = {}, {}
    for side in ("w", "b"):
        uid = g.uid_of(side)
        before = (repo.stats(uid, GAME) or {"points": 0})["points"]
        outcome = "d" if result == "d" else ("w" if result == side else "l")
        totals[side] = repo.add_result(uid, GAME, delta[side], outcome, now)
        gained[side] = totals[side] - before
    try:
        repo.log(GAME, g.white, g.black, result, reason, gained["w"], gained["b"], g.plies, rated, g.started, now)
    except Exception:
        log.exception("Shashka o'yin jurnaliga yozilmadi")
    g.over = {"result": result, "reason": reason, "rated": rated, "pts": gained, "total": totals}
    if g.watch and g.watch is not asyncio.current_task():
        g.watch.cancel()
    for uid in (g.white, g.black):
        if _user_game.get(uid) == g.gid:
            _user_game.pop(uid, None)
    _games.pop(g.gid, None)
    await _push_state(g)
    await manager.send_many([g.white, g.black], {"type": "ck_over", "gid": g.gid, **g.over})
    if rated and result in ("w", "b"):
        await _mission_win(g.uid_of(result), g.plies)


async def _mission_win(uid: int, plies: int) -> None:
    """Haqiqiy o'yinchini yutish missiya ochkosi beradi (reytingli o'yin qoidalari bilan)."""
    try:
        from app.services import missions
        res = missions.award(uid, GAME, "pvp_win", plies)
        if res.get("counted"):
            await manager.send_many([uid], {"type": "mission_award", "game": GAME, **res})
    except Exception:
        log.exception("Shashka missiya ochkosi berilmadi")


async def _watch(g: Game) -> None:
    try:
        while g.over is None:
            await asyncio.sleep(0.5)
            if g.over is not None:
                return
            now = time.monotonic()
            side = g.pos.turn
            if g.clock[side] - (now - g.turn_t) * 1000 <= 0:
                await _finish(g, "b" if side == "w" else "w", "timeout")
                return
            if g.plies < 2 and now - g.t0 > FIRST_MOVE_S:
                await _finish(g, "d", "abort")
                return
            for uid in (g.white, g.black):
                if manager.connection_count(uid) > 0:
                    g.off.pop(uid, None)
                else:
                    since = g.off.setdefault(uid, now)
                    if now - since > ABANDON_S:
                        await _finish(g, "b" if uid == g.white else "w", "abandon")
                        return
    except asyncio.CancelledError:
        pass
    except Exception:
        log.exception("Shashka nazoratida xato (gid=%s)", g.gid)


# ---------- takliflar ----------
async def _end_invite(inv: dict, status: str) -> None:
    if _invites.pop(inv["id"], None) is None:
        return
    _out.pop(inv["frm"], None)
    _in.pop(inv["to"], None)
    t = inv.get("task")
    if t and t is not asyncio.current_task():
        t.cancel()
    await manager.send_many([inv["frm"], inv["to"]], {"type": "ck_invite_end", "id": inv["id"], "status": status, "frm": inv["frm"], "to": inv["to"]})


async def _expire(iid: str) -> None:
    try:
        await asyncio.sleep(INVITE_TTL)
        inv = _invites.get(iid)
        if inv:
            await _end_invite(inv, "expired")
    except asyncio.CancelledError:
        pass


def _ttl_left(inv: dict) -> float:
    return max(0.0, INVITE_TTL - (time.time() - inv["created"]))


async def invite(user, to) -> None:
    uid = user["id"]
    if not isinstance(to, int) or isinstance(to, bool):
        raise ChatError("Foydalanuvchi noto'g'ri")
    if not limiter.allow(f"ckinv:{uid}", 6, 30):
        raise ChatError("Takliflar juda tez yuborilmoqda")
    if to == uid:
        raise ChatError("O'zingizni taklif qila olmaysiz")
    target = users_repo.get(to)
    if not target or target["deleted"] or target["banned"]:
        raise ChatError("Foydalanuvchi topilmadi", 404)
    if uid in _user_game or _chess_busy(uid):
        raise ChatError("Siz hozir o'yindasiz")
    if to in _user_game or _chess_busy(to):
        raise ChatError("Bu foydalanuvchi hozir o'yinda")
    if uid in _out:
        raise ChatError("Avvalgi taklifga javob kutilmoqda")
    if to in _in:
        raise ChatError("Bu foydalanuvchiga boshqa taklif kelgan, biroz kuting")
    inv = {"id": _rid(), "frm": uid, "to": to, "created": time.time(), "task": None}
    inv["task"] = _spawn(_expire(inv["id"]))
    _invites[inv["id"]] = inv
    _out[uid] = inv["id"]
    _in[to] = inv["id"]
    await manager.send_to(to, {"type": "ck_invite", "id": inv["id"], "frm": uid, "ttl": INVITE_TTL})
    await manager.send_to(uid, {"type": "ck_invite_sent", "id": inv["id"], "to": to, "ttl": INVITE_TTL})
    if not manager.is_online(to):
        webpush.fire_game_invite(to, user, "ck")


async def reply(user, iid, accept) -> None:
    inv = _invites.get(iid) if isinstance(iid, str) else None
    if not inv or inv["to"] != user["id"]:
        raise ChatError("Taklif muddati tugagan")
    if not accept:
        await _end_invite(inv, "declined")
        return
    a, b = inv["frm"], inv["to"]
    if a in _user_game or b in _user_game or _chess_busy(a) or _chess_busy(b):
        await _end_invite(inv, "busy")
        return
    await _end_invite(inv, "accepted")
    white, black = (a, b) if random.random() < 0.5 else (b, a)
    g = Game(white, black)
    g.base = {"w": (repo.stats(white, GAME) or {"points": 0})["points"], "b": (repo.stats(black, GAME) or {"points": 0})["points"]}
    _games[g.gid] = g
    _user_game[white] = _user_game[black] = g.gid
    g.watch = _spawn(_watch(g))
    await _push_state(g)


async def cancel(user, iid) -> None:
    inv = _invites.get(iid) if isinstance(iid, str) else None
    if inv and inv["frm"] == user["id"]:
        await _end_invite(inv, "cancelled")


# ---------- o'yin ----------
def _game_of(user, gid) -> tuple[Game, str]:
    g = _games.get(gid) if isinstance(gid, str) else None
    if not g or g.over is not None:
        raise ChatError("O'yin tugagan")
    side = g.side_of(user["id"])
    if not side:
        raise ChatError("Bu o'yinda ishtirok etmaysiz", 403)
    return g, side


async def move(user, gid, path) -> None:
    g, side = _game_of(user, gid)
    if side != g.pos.turn:
        raise ChatError("Navbat sizda emas")
    if not limiter.allow(f"ckmove:{user['id']}", 20, 10):
        raise ChatError("Juda tez yurilmoqda")
    if not isinstance(path, list) or not (2 <= len(path) <= MAX_PATH):
        raise ChatError("Noqonuniy yurish")
    now = time.monotonic()
    spent = (now - g.turn_t) * 1000
    if g.clock[side] - spent <= 0:
        await _finish(g, "b" if side == "w" else "w", "timeout")
        return
    try:
        info = g.pos.push(path)
    except ValueError:
        await manager.send_to(user["id"], _state(g))
        raise ChatError("Noqonuniy yurish")
    g.clock[side] -= spent
    g.turn_t = now
    g.plies += 1
    g.last = {"path": info["path"], "caps": info["caps"], "promo": info["promo"]}
    g.hist.append("".join(info["path"]))
    key = g.pos.key()
    g.reps[key] = g.reps.get(key, 0) + 1
    g.legal = g.pos.legal_map()
    if not g.legal:
        await _finish(g, side, "no_moves")
    elif g.reps[key] >= 3:
        await _finish(g, "d", "repetition")
    elif g.pos.half >= ce.KING_ONLY_PLIES:
        await _finish(g, "d", "kings15")
    else:
        await _push_state(g)


async def resign(user, gid) -> None:
    g, side = _game_of(user, gid)
    await _finish(g, "b" if side == "w" else "w", "resign")


async def sync(user) -> None:
    uid = user["id"]
    gid = _user_game.get(uid)
    g = _games.get(gid) if gid else None
    if g:
        await manager.send_to(uid, _state(g))
    iid = _in.get(uid)
    inv = _invites.get(iid) if iid else None
    if inv and _ttl_left(inv) > 0.3:
        await manager.send_to(uid, {"type": "ck_invite", "id": inv["id"], "frm": inv["frm"], "ttl": round(_ttl_left(inv), 1)})
    oid = _out.get(uid)
    out = _invites.get(oid) if oid else None
    if out and _ttl_left(out) > 0.3:
        await manager.send_to(uid, {"type": "ck_invite_sent", "id": out["id"], "to": out["to"], "ttl": round(_ttl_left(out), 1)})


async def handle(user, data: dict) -> None:
    kind = data.get("type")
    if kind == "ck_invite":
        await invite(user, data.get("to"))
    elif kind == "ck_reply":
        await reply(user, data.get("id"), bool(data.get("accept")))
    elif kind == "ck_cancel":
        await cancel(user, data.get("id"))
    elif kind == "ck_move":
        await move(user, data.get("gid"), data.get("path"))
    elif kind == "ck_resign":
        await resign(user, data.get("gid"))
    elif kind == "ck_sync":
        await sync(user)


def scoreboard(user) -> dict:
    top = [{"uid": r["user_id"], "points": r["points"], "wins": r["wins"], "losses": r["losses"], "draws": r["draws"]} for r in repo.top(GAME, 30)]
    me = repo.stats(user["id"], GAME)
    mine = {"points": me["points"], "wins": me["wins"], "losses": me["losses"], "draws": me["draws"]} if me else {"points": 0, "wins": 0, "losses": 0, "draws": 0}
    mine["rank"] = repo.rank_of(GAME, mine["points"]) if (me and (me["wins"] + me["losses"] + me["draws"])) else None
    return {"game": GAME, "top": top, "me": mine}
