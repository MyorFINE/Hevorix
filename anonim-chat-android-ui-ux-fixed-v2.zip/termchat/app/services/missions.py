"""Missiyalar, dizayn paketlari va inventar.

Oqim: admin paket yaratadi -> admin "X ochko to'plasang shu paket" missiyasini belgilaydi -> foydalanuvchi o'yin o'ynaydi ->
SERVER o'yinni tekshiradi (chipta + yurishlarni qayta o'ynash + matt) -> missiya ochkosi qo'shiladi -> yetarli bo'lsa paket
foydalanuvchi inventariga ochiladi (har bir element alohida) -> foydalanuvchi har bir elementni alohida kiyadi / olib qo'yadi.
"""
from __future__ import annotations

import json
import secrets
import time

from app.errors import ChatError
from app.games import checkers_engine as ck
from app.games import chess_engine as ce
from app.repositories import chat_settings, users
from app.repositories import missions as repo
from app.security import limiter
from app.services import badges, fxstyle
from app.services.auth import COLOR_RE

GAMES: dict[str, dict] = {
    "chess": {
        "title": "Shaxmat", "emoji": "♞",
        "note": "Botni internet orqali boshlangan o'yinda matt qilib yuting yoki haqiqiy o'yinchini yuting (kamida 8 yurishlik, bir juftlik bilan kuniga 5 tagacha o'yin hisoblanadi). Natijani server tekshiradi.",
        "rules": [("bot_1", "1-daraja botni yutish", 0, 0), ("bot_2", "2-daraja botni yutish", 0, 0),
                  ("bot_3", "3-daraja botni yutish", 5, 0), ("bot_4", "4-daraja botni yutish", 10, 0),
                  ("bot_5", "5-daraja botni yutish", 25, 0),
                  ("pvp_win", "Haqiqiy o'yinchini yutish", 10, 0)],
    },
    "checkers": {
        "title": "Shashka", "emoji": "⛀",
        "note": "Botni internet orqali boshlangan o'yinda yuting (yurish qolmagan holatda) yoki haqiqiy o'yinchini yuting (kamida 8 yarim yurishlik, bir juftlik bilan kuniga 5 tagacha o'yin hisoblanadi). Natijani server tekshiradi.",
        "rules": [("bot_1", "1-daraja botni yutish", 0, 0), ("bot_2", "2-daraja botni yutish", 0, 0),
                  ("bot_3", "3-daraja botni yutish", 5, 0), ("bot_4", "4-daraja botni yutish", 10, 0),
                  ("bot_5", "5-daraja botni yutish", 25, 0),
                  ("pvp_win", "Haqiqiy o'yinchini yutish", 10, 0)],
    },
}

SLOTS: dict[str, str] = {
    "frame": "Avatar ramkasi", "banner": "Profil foni", "color": "Profil rangi", "nick": "Nickname animatsiyasi",
    "bio": "Bio animatsiyasi", "msg": "Xabar animatsiyasi", "avatar": "Profil rasmi animatsiyasi", "badge": "Nishon",
}
FX_SLOTS = ("nick", "bio", "msg", "avatar")
_TXT = {"x_neon": "Neon", "x_lava": "Lava", "x_royal": "Qirollik oltini", "x_rainbow": "Kamalak", "x_frost": "Qirov", "x_glow": "Nur"}
LABELS: dict[str, dict[str, str]] = {
    "frame": {"x_neon": "Neon", "x_galaxy": "Galaktika", "x_royal": "Qirollik", "x_toxic": "Zaharli", "x_plasma": "Plazma", "x_glacier": "Muzlik"},
    "banner": {"x_nebula": "Tumanlik", "x_lava": "Lava", "x_matrix": "Matritsa", "x_sakura": "Sakura", "x_abyss": "Tubsizlik", "x_royal": "Qirollik"},
    "nick": _TXT, "bio": _TXT,
    "msg": {"x_glow": "Nurli hoshiya", "x_flow": "Oqma hoshiya", "x_sparkle": "Yaltirash", "x_pulse": "Puls", "x_neon": "Neon", "x_royal": "Qirollik"},
    "avatar": {"x_pulse": "Puls", "x_float": "Suzish", "x_swing": "Tebranish", "x_heartbeat": "Yurak urishi", "x_glitch": "Glitch", "x_spin": "Aylanish"},
}

MAX_ITEMS = 12
MIN_USER_MOVES = 8          # bundan qisqa o'yin (masalan 4 yurishlik "matt") hisoblanmaydi
MIN_SEC_PER_MOVE = 1.0      # foydalanuvchining har bir yurishiga kamida shuncha soniya
TICKET_MAX_AGE = 24 * 3600
MAX_MOVES = 600


# ---------- sozlamalar ----------
def strict() -> bool:
    return bool(chat_settings.get("missions_strict", True))


def set_strict(on: bool) -> None:
    chat_settings.put("missions_strict", bool(on))


def rules_of(game: str) -> list[dict]:
    spec = GAMES[game]["rules"]
    saved = {r["rule"]: r for r in repo.rules(game)}
    out = []
    for key, title, dpts, dcap in spec:
        r = saved.get(key)
        out.append({"rule": key, "title": title, "points": r["points"] if r else dpts, "daily_cap": r["daily_cap"] if r else dcap})
    return out


def _rule(game: str, key: str) -> dict | None:
    return next((r for r in rules_of(game) if r["rule"] == key), None)


def catalog() -> dict:
    slots = []
    for slot, label in SLOTS.items():
        entry = {"slot": slot, "label": label}
        if slot in LABELS:
            entry["values"] = [{"value": v, "label": LABELS[slot].get(v, v)} for v in _values(slot)]
        slots.append(entry)
    return {"slots": slots, "anims": [a for a in badges.ANIMS if a != "none"], "max_items": MAX_ITEMS}


def _values(slot: str) -> tuple[str, ...]:
    if slot == "frame":
        return fxstyle.PREMIUM_FRAMES
    if slot == "banner":
        return fxstyle.PREMIUM_BANNERS
    return fxstyle.PREMIUM_FX.get(slot, ())


# ---------- paket elementlarini tekshirish ----------
def _clean_item(raw) -> dict:
    if not isinstance(raw, dict):
        raise ChatError("Paket elementi noto'g'ri")
    slot = raw.get("slot")
    value = raw.get("value")
    if slot not in SLOTS or not isinstance(value, str):
        raise ChatError("Paket elementi noto'g'ri")
    value = value.strip()
    anim = ""
    if slot == "color":
        if not COLOR_RE.match(value):
            raise ChatError("Rang #rrggbb ko'rinishida bo'lishi kerak")
        value = value.lower()
        label = "Rang " + value
    elif slot == "badge":
        b, a = badges.clean(value, raw.get("anim") if isinstance(raw.get("anim"), str) else "")
        if not b or b in (badges.HIDDEN, badges.VERIFIED):
            raise ChatError("Nishon uchun emoji kiriting")
        value, anim = b, a or ""
        label = "Nishon " + value
    else:
        if value not in _values(slot):
            raise ChatError(f"«{SLOTS[slot]}» uchun bunday dizayn yo'q")
        label = LABELS[slot].get(value, value)
    return {"slot": slot, "value": value, "anim": anim, "label": label}


def _clean_items(raw) -> list[dict]:
    if not isinstance(raw, list) or not raw:
        raise ChatError("Paketda kamida bitta element bo'lishi kerak")
    if len(raw) > MAX_ITEMS:
        raise ChatError(f"Paketda {MAX_ITEMS} tadan ko'p element bo'lmasin")
    seen, out = set(), []
    for r in raw:
        it = _clean_item(r)
        k = (it["slot"], it["value"], it["anim"])
        if k not in seen:
            seen.add(k)
            out.append(it)
    return out


def _clean_text(raw, what: str, mx: int, required: bool = True) -> str:
    t = " ".join(str(raw or "").split())
    if required and not t:
        raise ChatError(f"{what} bo'sh bo'lmasin")
    if len(t) > mx:
        raise ChatError(f"{what} {mx} belgidan oshmasin")
    return t


def _clean_emoji(raw) -> str:
    e = str(raw or "").strip() or "🎁"
    b, _ = badges.clean(e, "")
    if not b or b in (badges.HIDDEN, badges.VERIFIED) or b.startswith(":"):
        raise ChatError("Paket belgisi oddiy emoji bo'lishi kerak")
    return b


# ---------- admin: paketlar ----------
def pack_view(r) -> dict:
    try:
        items = json.loads(r["items"])
    except ValueError:
        items = []
    return {"id": r["id"], "name": r["name"], "emoji": r["emoji"], "descr": r["descr"], "items": items, "created_at": r["created_at"]}


def pack_save(admin, pid, name, emoji, descr, items) -> dict:
    name = _clean_text(name, "Paket nomi", 32)
    descr = _clean_text(descr, "Tavsif", 120, required=False)
    emoji = _clean_emoji(emoji)
    items = _clean_items(items)
    if pid is None:
        if len(repo.pack_all()) >= 200:
            raise ChatError("Paketlar soni cheklovga yetdi")
        pid = repo.pack_add(name, emoji, descr, items, admin["id"], time.time())
    else:
        if not repo.pack_get(pid):
            raise ChatError("Paket topilmadi", 404)
        repo.pack_update(pid, name, emoji, descr, items)
    return pack_view(repo.pack_get(pid))


def pack_remove(pid) -> None:
    if not isinstance(pid, int) or not repo.pack_get(pid):
        raise ChatError("Paket topilmadi", 404)
    repo.pack_delete(pid)  # bu paketga bog'langan missiyalar ham o'chadi; foydalanuvchilarga berilgan elementlar saqlanadi


# ---------- admin: ochko qoidalari va missiyalar ----------
def rule_set(game, rule, points, cap) -> list[dict]:
    if game not in GAMES or not _rule(game, rule):
        raise ChatError("Bunday qoida yo'q")
    if not isinstance(points, int) or isinstance(points, bool) or not 0 <= points <= 10000:
        raise ChatError("Ochko 0 dan 10000 gacha bo'lsin")
    if not isinstance(cap, int) or isinstance(cap, bool) or not 0 <= cap <= 1000:
        raise ChatError("Kunlik limit 0 dan 1000 gacha bo'lsin (0 = cheklovsiz)")
    repo.rule_put(game, rule, points, cap)
    return rules_of(game)


def _reward_view(r) -> dict:
    p = repo.pack_get(r["pack_id"])
    return {"id": r["id"], "game": r["game"], "title": r["title"], "need": r["need"], "active": bool(r["active"]),
            "pack": pack_view(p) if p else None, "claimed": repo.claim_count(r["id"])}


def reward_save(rid, game, title, need, pack_id, active=True) -> dict:
    if game not in GAMES:
        raise ChatError("Bunday o'yin yo'q")
    title = _clean_text(title, "Missiya nomi", 48)
    if not isinstance(need, int) or isinstance(need, bool) or not 1 <= need <= 1_000_000:
        raise ChatError("Kerakli ochko 1 dan 1 000 000 gacha bo'lsin")
    if not isinstance(pack_id, int) or not repo.pack_get(pack_id):
        raise ChatError("Paket topilmadi", 404)
    now = time.time()
    if rid is None:
        if len(repo.reward_all()) >= 300:
            raise ChatError("Missiyalar soni cheklovga yetdi")
        rid = repo.reward_add(game, title, need, pack_id, now)
        if not active:
            repo.reward_update(rid, title, need, pack_id, 0)
    else:
        if not repo.reward_get(rid):
            raise ChatError("Missiya topilmadi", 404)
        repo.reward_update(rid, title, need, pack_id, 1 if active else 0)
    return _reward_view(repo.reward_get(rid))


def reward_remove(rid) -> None:
    if not isinstance(rid, int) or not repo.reward_get(rid):
        raise ChatError("Missiya topilmadi", 404)
    repo.reward_delete(rid)


def admin_overview() -> dict:
    return {
        "strict": strict(), "catalog": catalog(),
        "games": [{"game": g, "title": spec["title"], "emoji": spec["emoji"], "rules": rules_of(g)} for g, spec in GAMES.items()],
        "packs": [pack_view(r) for r in repo.pack_all()],
        "rewards": [_reward_view(r) for r in repo.reward_all()],
    }


# ---------- foydalanuvchi: missiyalar sahifasi ----------
def grant_due(uid: int) -> list[dict]:
    """Yetarli ochko to'plagan, lekin hali olmagan missiyalar mukofotini inventarga ochadi."""
    out = []
    claimed = repo.claimed_ids(uid)
    now = time.time()
    for r in repo.reward_all(only_active=True):
        if r["id"] in claimed or repo.points(uid, r["game"]) < r["need"]:
            continue
        p = repo.pack_get(r["pack_id"])
        if not p:
            continue
        if not repo.claim(uid, r["id"], now):
            continue
        pv = pack_view(p)
        added = 0
        for it in pv["items"]:
            if repo.inv_add(uid, p["id"], p["name"], it["slot"], it["value"], it.get("anim", ""), it.get("label", ""), now):
                added += 1
        out.append({"reward_id": r["id"], "title": r["title"], "pack": {"name": pv["name"], "emoji": pv["emoji"]},
                    "items": [{"slot": i["slot"], "value": i["value"], "anim": i.get("anim", ""), "label": i.get("label", "")} for i in pv["items"]],
                    "added": added})
    return out


def overview(uid: int) -> dict:
    grants = grant_due(uid)
    claimed = repo.claimed_ids(uid)
    games = []
    for g, spec in GAMES.items():
        pts = repo.points(uid, g)
        missions = []
        for r in repo.reward_all(g, only_active=True):
            p = repo.pack_get(r["pack_id"])
            if not p:
                continue
            pv = pack_view(p)
            missions.append({"id": r["id"], "title": r["title"], "need": r["need"], "done": r["id"] in claimed,
                             "pack": {"name": pv["name"], "emoji": pv["emoji"], "descr": pv["descr"], "items": pv["items"]}})
        games.append({"game": g, "title": spec["title"], "emoji": spec["emoji"], "note": spec.get("note", ""), "points": pts,
                      "rules": [{"title": x["title"], "points": x["points"], "daily_cap": x["daily_cap"]} for x in rules_of(g) if x["points"] > 0],
                      "missions": missions})
    return {"games": games, "granted": grants, "strict": strict(), "inventory": repo.inv_count(uid)}


# ---------- o'yin chiptasi va g'alabani tekshirish ----------
def start_game(user, game, level, side) -> dict:
    if game not in ("chess", "checkers"):
        raise ChatError("Bunday o'yin yo'q")
    if not isinstance(level, int) or isinstance(level, bool) or not 1 <= level <= 5:
        raise ChatError("Daraja noto'g'ri")
    if side not in ("w", "b"):
        raise ChatError("Tomon noto'g'ri")
    limiter.check(f"mstart:{user['id']}", 40, 3600, "Juda tez-tez yangi o'yin boshlanmoqda")
    now = time.time()
    repo.tickets_prune(now - 3 * 86400)
    token = secrets.token_urlsafe(18)
    repo.ticket_add(token, user["id"], game, level, side, now)
    return {"token": token}


def _replay(moves: list, side: str) -> tuple[int, str]:
    """Yurishlarni noldan qayta o'ynaydi. (foydalanuvchi yurishlari soni, oxirgi yurgan tomon) qaytaradi; matt bo'lmasa xato."""
    pos = ce.Position()
    mine = 0
    last = ""
    for u in moves:
        if not isinstance(u, str) or len(u) not in (4, 5):
            raise ChatError("O'yin yozuvi noto'g'ri")
        if not pos.legal():
            raise ChatError("O'yin yozuvi noto'g'ri")
        try:
            pos.push(ce.idx(u[0:2]), ce.idx(u[2:4]), u[4:5])
        except ValueError:
            raise ChatError("O'yin yozuvi noto'g'ri")
        last = "b" if pos.turn == "w" else "w"
        if last == side:
            mine += 1
    if pos.legal() or not pos.in_check():
        raise ChatError("Bu o'yin matt bilan tugamagan")
    return mine, last


def _replay_checkers(moves: list, side: str) -> tuple[int, str]:
    """Shashka yurishlarini noldan qayta o'ynaydi; yurish qolmagan holatda tugamagan bo'lsa xato."""
    pos = ck.Position()
    mine = 0
    last = ""
    for u in moves:
        if not isinstance(u, str) or len(u) < 4 or len(u) % 2 or len(u) > 80:
            raise ChatError("O'yin yozuvi noto'g'ri")
        mover = pos.turn
        try:
            pos.push([u[i:i + 2] for i in range(0, len(u), 2)])
        except ValueError:
            raise ChatError("O'yin yozuvi noto'g'ri")
        last = mover
        if mover == side:
            mine += 1
    if pos.legal():
        raise ChatError("Bu o'yin g'alaba bilan tugamagan")
    return mine, last


def submit_checkers(user, token, moves, hints, undos) -> dict:
    return submit_chess(user, token, moves, hints, undos, "checkers")


def submit_chess(user, token, moves, hints, undos, game: str = "chess") -> dict:
    uid = user["id"]
    if not isinstance(token, str) or not isinstance(moves, list) or len(moves) > MAX_MOVES:
        raise ChatError("O'yin yozuvi noto'g'ri")
    limiter.check(f"msubmit:{uid}", 20, 600, "Juda tez-tez yuborilmoqda")
    t = repo.ticket_get(token)
    if not t or t["user_id"] != uid or t["game"] != game:
        raise ChatError("Bu o'yin missiyaga hisoblanmaydi (internet bilan boshlanmagan)")
    now = time.time()
    if not repo.ticket_use(token):
        raise ChatError("Bu o'yin allaqachon hisoblangan")
    if now - t["started_at"] > TICKET_MAX_AGE:
        raise ChatError("O'yin juda eski — hisoblanmaydi")
    mine, winner = (_replay_checkers if game == "checkers" else _replay)(moves, t["side"])
    if winner != t["side"]:
        raise ChatError("Bu o'yinda siz g'alaba qozonmagansiz")
    if mine < MIN_USER_MOVES:
        return _no_points("O'yin juda qisqa (kamida %d ta yurish kerak)" % MIN_USER_MOVES, uid, game)
    if now - t["started_at"] < mine * MIN_SEC_PER_MOVE:
        return _no_points("O'yin g'ayritabiiy tez tugagan — hisoblanmadi", uid, game)
    hints = hints if isinstance(hints, int) and not isinstance(hints, bool) else 0
    undos = undos if isinstance(undos, int) and not isinstance(undos, bool) else 0
    if strict() and (hints > 0 or undos > 0):
        return _no_points("Maslahat yoki «orqaga» ishlatilgan o'yin missiyaga hisoblanmaydi", uid, game)
    return award(uid, game, f"bot_{t['level']}", len(moves), now)


def award(uid: int, game: str, rule_key: str, plies: int = 0, now: float | None = None) -> dict:
    """Har qanday o'yin uchun umumiy ochko berish nuqtasi: qoida (admin belgilagan ochko + kunlik limit) bo'yicha
    missiya ochkosi qo'shadi va yetarli bo'lsa paketlarni inventarga ochadi. Yangi o'yin qo'shilganda faqat GAMES ga
    yozib, g'alaba tekshirilgach shu funksiyani chaqirish kifoya."""
    now = now or time.time()
    rule = _rule(game, rule_key)
    if not rule or rule["points"] <= 0:
        return _no_points("Bu natija uchun missiya ochkosi berilmaydi", uid, game)
    if rule["daily_cap"] and repo.wins_since(uid, game, rule["rule"], now - 86400) >= rule["daily_cap"]:
        return _no_points("Bu natija uchun kunlik limit tugadi", uid, game)
    total = repo.add_points(uid, game, rule["points"], now)
    repo.win_log(uid, game, rule["rule"], rule["points"], plies, now)
    return {"counted": True, "gained": rule["points"], "total": total, "granted": grant_due(uid)}


def _no_points(reason: str, uid: int, game: str = "chess") -> dict:
    return {"counted": False, "reason": reason, "gained": 0, "total": repo.points(uid, game), "granted": []}


# ---------- inventar: kiyish / olib qo'yish ----------
def _fx_of(row) -> dict:
    return fxstyle.parse(row["fx"])


def _is_on(row, it) -> bool:
    s, v = it["slot"], it["value"]
    if s == "frame":
        return row["frame"] == v
    if s == "banner":
        return row["banner"] == v
    if s == "color":
        return (row["color"] or "").lower() == v
    if s == "badge":
        return row["badge"] == v and (row["badge_anim"] or "") == (it["anim"] or "")
    return _fx_of(row).get(s) == v


def inventory(uid: int) -> dict:
    row = users.get(uid)
    items = []
    for it in repo.inv_all(uid):
        items.append({"id": it["id"], "slot": it["slot"], "value": it["value"], "anim": it["anim"] or "", "label": it["label"],
                      "pack": it["pack_name"], "on": _is_on(row, it), "got_at": it["got_at"]})
    return {"items": items, "slots": SLOTS}


def equip(user, item_id) -> None:
    uid = user["id"]
    it = repo.inv_get(uid, item_id) if isinstance(item_id, int) else None
    if not it:
        raise ChatError("Bu narsa inventaringizda yo'q", 404)
    limiter.check(f"minv:{uid}", 60, 60, "Juda tez-tez almashtiryapsiz")
    row = users.get(uid)
    s, v = it["slot"], it["value"]
    if s in ("frame", "banner", "color"):
        users.set_style(uid, {s: v})
    elif s in FX_SLOTS:
        fx = _fx_of(row)
        fx[s] = v
        users.set_style(uid, {"fx": fxstyle.dump(fx)})
    elif s == "badge":
        if row["badge"] in (badges.VERIFIED, badges.HIDDEN):
            raise ChatError("Sizda admin bergan maxsus belgi bor — nishonni kiyib bo'lmaydi")
        users.set_badge(uid, v, it["anim"] or None)


def unequip(user, item_id) -> None:
    uid = user["id"]
    it = repo.inv_get(uid, item_id) if isinstance(item_id, int) else None
    if not it:
        raise ChatError("Bu narsa inventaringizda yo'q", 404)
    row = users.get(uid)
    if not _is_on(row, it):
        return
    s = it["slot"]
    if s in ("frame", "banner", "color"):
        users.set_style(uid, {s: None})
    elif s in FX_SLOTS:
        fx = _fx_of(row)
        fx.pop(s, None)
        users.set_style(uid, {"fx": fxstyle.dump(fx)})
    elif s == "badge":
        users.set_badge(uid, None, None)
