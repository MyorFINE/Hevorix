from __future__ import annotations

import logging
import queue
import re
import secrets
import threading
from dataclasses import dataclass
from pathlib import Path

from app import crypto
from app.config import settings
from app.errors import ChatError
from app.services import imgclean, r2
from app.services.avatars import sniff_image

log = logging.getLogger("termchat.media")

CTX = "media"
NAME_RE = re.compile(r"^[0-9a-f]{32}(?:_t)?\.(?:png|jpg|webp|gif|bin|e2e)$")
MIME_BY_EXT = {"png": "image/png", "jpg": "image/jpeg", "webp": "image/webp", "gif": "image/gif", "bin": "application/octet-stream"}
_MIME_RE = re.compile(r"^[a-z0-9][a-z0-9.+-]*/[a-z0-9][a-z0-9.+-]*$")


@dataclass
class Stored:
    image: str | None = None
    width: int | None = None
    height: int | None = None
    file: str | None = None
    file_name: str | None = None
    file_mime: str | None = None
    size: int = 0


def limit_mb() -> int:
    return settings.max_media_bytes // (1024 * 1024)


def validate(raw: bytes) -> None:
    if not raw:
        raise ChatError("Fayl tanlanmagan")
    if len(raw) > settings.max_media_bytes:
        raise ChatError(f"Fayl {limit_mb()} MB dan oshmasligi kerak")


def sanitize_name(name: str | None) -> str:
    name = (name or "").replace("\\", "/").rsplit("/", 1)[-1]
    name = re.sub(r"[\x00-\x1f\x7f<>:\"|?*\u202a-\u202e\u2066-\u2069]", "", name).strip(" .")
    if len(name) > 100:
        stem, dot, ext = name.rpartition(".")
        name = (stem[: 100 - len(ext) - 1] + "." + ext[:10]) if dot and len(ext) <= 10 and stem else name[:100]
    return name or "fayl"


def clean_mime(mime: str | None) -> str:
    m = (mime or "").split(";")[0].strip().lower()
    return m if len(m) <= 100 and _MIME_RE.match(m) else "application/octet-stream"


def thumb_name(name: str) -> str:
    return name.rsplit(".", 1)[0] + "_t.jpg"


def _path(name: str) -> Path:
    if name.endswith(".e2e"):
        return settings.media_dir / name
    return settings.media_dir / (name + ".enc")


def _obj(name: str) -> str:
    return "media/" + (name if name.endswith(".e2e") else name + ".enc")


def _put(name: str, payload: bytes) -> None:
    if r2.enabled():
        try:
            r2.put(_obj(name), payload)
        except Exception:
            log.exception("R2 ga fayl yozib bo'lmadi")
            raise ChatError("Faylni saqlab bo'lmadi, birozdan keyin qayta urinib ko'ring", 502)
        return
    path = _path(name)
    tmp = path.with_suffix(".tmp")
    tmp.write_bytes(payload)
    tmp.replace(path)


def _get(name: str) -> bytes | None:
    if r2.enabled():
        try:
            data = r2.get(_obj(name))
        except Exception:
            log.exception("R2 dan fayl o'qib bo'lmadi")
            raise ChatError("Fayl xizmati vaqtincha ishlamayapti", 503)
        if data is not None:
            return data
    p = _path(name)
    return p.read_bytes() if p.is_file() else None


def _write(name: str, data: bytes) -> None:
    _put(name, crypto.seal_bytes(data, CTX))


def store(raw: bytes, filename: str | None = None, mime: str | None = None) -> Stored:
    validate(raw)
    stem = secrets.token_hex(16)
    if sniff_image(raw):
        try:
            img = imgclean.clean(raw)
        except ChatError:
            img = None
        if img is not None:
            name = f"{stem}.{img.ext}"
            _write(name, img.data)
            _write(thumb_name(name), img.thumb)
            return Stored(image=name, width=img.width, height=img.height, size=len(img.data))
    name = f"{stem}.bin"
    _write(name, raw)
    return Stored(file=name, file_name=sanitize_name(filename), file_mime=clean_mime(mime), size=len(raw))


def store_opaque(raw: bytes) -> str:
    if not raw or len(raw) < 12 + 16:
        raise ChatError("Fayl bo'sh")
    if len(raw) > settings.max_media_bytes + 64:
        raise ChatError(f"Fayl {limit_mb()} MB dan oshmasligi kerak")
    name = secrets.token_hex(16) + ".e2e"
    _put(name, raw)
    return name


def content_type(name: str) -> str:
    return MIME_BY_EXT.get(name.rsplit(".", 1)[-1], "application/octet-stream")


def read(name: str) -> bytes | None:
    if not NAME_RE.match(name):
        return None
    if name.endswith(".e2e"):
        return _get(name)
    blob = _get(name)
    if blob is not None:
        return crypto.open_bytes(blob, CTX)
    legacy = settings.uploads_dir / name
    if legacy.is_file():
        return legacy.read_bytes()
    return None


_r2_del_q: "queue.Queue[str]" = queue.Queue()
_r2_del_lock = threading.Lock()
_r2_del_thread: threading.Thread | None = None


def _r2_delete_worker() -> None:
    while True:
        batch = [_r2_del_q.get()]
        try:
            while len(batch) < 500:
                batch.append(_r2_del_q.get_nowait())
        except queue.Empty:
            pass
        try:
            if len(batch) == 1:
                r2.delete(batch[0])
            else:
                r2.delete_many(batch)
        except Exception:
            log.warning("R2 dan %d ta fayl o'chirib bo'lmadi (keyingi tozalashda qayta uriniladi)", len(batch))
        finally:
            for _ in batch:
                _r2_del_q.task_done()


def _r2_delete_async(key: str) -> None:
    global _r2_del_thread
    with _r2_del_lock:
        if _r2_del_thread is None or not _r2_del_thread.is_alive():
            _r2_del_thread = threading.Thread(target=_r2_delete_worker, name="r2-delete", daemon=True)
            _r2_del_thread.start()
    _r2_del_q.put(key)


def _unlink(name: str) -> None:
    if r2.enabled():
        _r2_delete_async(_obj(name))
    for p in (_path(name), settings.uploads_dir / name):
        try:
            p.unlink()
        except OSError:
            pass


def remove(name: str | None) -> None:
    if not name or not NAME_RE.match(name):
        return
    _unlink(name)
    if not name.endswith(".bin"):
        _unlink(thumb_name(name))
    if name.endswith(".e2e"):
        from app.repositories import e2ee as e2ee_repo
        e2ee_repo.drop_blob(name)


def remove_row(row) -> None:
    keys = row.keys() if hasattr(row, "keys") else row
    for k in ("image", "file"):
        if k in keys:
            remove(row[k])


def migrate_legacy() -> int:
    n = 0
    for p in settings.uploads_dir.iterdir():
        if p.is_file() and NAME_RE.match(p.name):
            try:
                _write(p.name, p.read_bytes())
                p.unlink()
                n += 1
            except OSError:
                log.exception("Eski faylni shifrlab bo'lmadi: %s", p.name)
    if n:
        log.info("Eski %d ta fayl shifrlandi", n)
    return n
