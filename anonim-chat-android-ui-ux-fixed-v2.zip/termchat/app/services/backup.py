from __future__ import annotations

import base64
import re
import secrets
import sqlite3
import time

from app.config import settings
from app.constants import OWNER_USERNAME
from app.errors import ChatError
from app.repositories import avatars as avatars_repo
from app.repositories import users
from app.roles import Role, role_of
from app.security import valid_hash_shape
from app.services import avatars, badges, e2ee as e2ee_svc, fxstyle
from app.services.auth import RESERVED, USERNAME_RE, clean_nickname

FORMAT = 1
MAX_USERS = 5000
MAX_AVATAR_EXPORT = 600 * 1024
MAX_TOTAL_AVATARS = 24 * 1024 * 1024
_COLOR_RE = re.compile(r"^#[0-9a-fA-F]{6}$")


def _owner_only(actor) -> None:
    if role_of(actor) != Role.OWNER:
        raise ChatError("Zaxirani faqat platforma egasi yuklab oladi va tiklaydi (unda kirish ma'lumotlari bor)", 403)


def export_users(actor) -> dict:
    _owner_only(actor)
    out, total, skipped = [], 0, 0
    for r in users.list_for_backup():
        if r["role"] == "owner":
            continue
        av = None
        if r["avatar"]:
            f = settings.avatars_dir / r["avatar"]
            try:
                raw = f.read_bytes()
            except OSError:
                raw = b""
            if raw and len(raw) <= MAX_AVATAR_EXPORT and total + len(raw) <= MAX_TOTAL_AVATARS:
                av = {"ext": r["avatar"].rsplit(".", 1)[-1][:4], "data": base64.b64encode(raw).decode()}
                total += len(raw)
            elif raw:
                skipped += 1
        out.append({
            "username": r["username"], "nickname": r["nickname"], "role": r["role"], "bio": r["bio"] or "",
            "color": r["color"], "joined": r["created_at"], "banned": bool(r["banned"]),
            "badge": r["badge"], "badge_anim": r["badge_anim"], "avatar": av,
            "design": {"trust": r["trust"], "banner": r["banner"], "frame": r["frame"], "title": r["title"],
                       "fx": fxstyle.parse(r["fx"])},
            "cred": {"password_hash": r["password_hash"], "auth_v": int(r["auth_v"] or 0), "kdf_iter": r["kdf_iter"],
                     "ecdh_pub": r["ecdh_pub"], "sign_pub": r["sign_pub"], "key_blob": r["key_blob"]},
        })
    return {"v": FORMAT, "app": "anonim-chat", "exported_at": time.time(), "by": actor["username"],
            "users": out, "avatars_skipped": skipped}


def _clean_design(d, role: str) -> dict:
    from app.services import profiles
    d = d if isinstance(d, dict) else {}
    out = {"trust": None, "banner": None, "frame": None, "title": None, "fx": None}
    if d.get("trust") in (0, 1) and not isinstance(d.get("trust"), bool) and role == "user":
        out["trust"] = d["trust"]
    if d.get("banner") in profiles.BANNERS:
        out["banner"] = d["banner"]
    if d.get("frame") in profiles.FRAMES:
        out["frame"] = d["frame"]
    if isinstance(d.get("title"), str):
        try:
            out["title"] = profiles._title(d["title"])
        except ChatError:
            pass
    out["fx"] = fxstyle.dump(fxstyle.parse(d.get("fx")))
    return out


def _clean(rec) -> dict:
    if not isinstance(rec, dict):
        raise ValueError("yozuv")
    username = rec.get("username")
    if not isinstance(username, str) or not USERNAME_RE.match(username.lower()):
        raise ValueError("username")
    username = username.lower()
    if username in RESERVED or username.startswith("deleted_"):
        raise ValueError("band username")
    nick = clean_nickname(rec.get("nickname") if isinstance(rec.get("nickname"), str) else "")
    role = rec.get("role")
    if role not in ("user", "admin"):
        raise ValueError("rol")
    bio = rec.get("bio") if isinstance(rec.get("bio"), str) else ""
    bio = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]", "", bio).strip()[:200]
    color = rec.get("color")
    if color is not None and not (isinstance(color, str) and _COLOR_RE.match(color)):
        color = None
    joined = rec.get("joined")
    if isinstance(joined, bool) or not isinstance(joined, (int, float)) or not 0 < joined <= time.time() + 86400:
        joined = time.time()
    try:
        badge, anim = badges.clean(rec.get("badge") or "", rec.get("badge_anim") or "")
    except ChatError:
        badge = anim = None
    design = _clean_design(rec.get("design"), role)
    cred = rec.get("cred")
    if not isinstance(cred, dict):
        raise ValueError("kirish ma'lumoti")
    ph = cred.get("password_hash")
    if not valid_hash_shape(ph):
        raise ValueError("parol hash'i")
    auth_v = cred.get("auth_v")
    if auth_v not in (0, 1):
        raise ValueError("auth_v")
    keys = {"ecdh_pub": None, "sign_pub": None, "key_blob": None, "kdf_iter": None}
    if auth_v == 1:
        keys = e2ee_svc.validate_account_keys({k: cred.get(k) for k in keys})
    return {"username": username, "nickname": nick, "role": role, "bio": bio, "color": color, "created_at": float(joined),
            "banned": bool(rec.get("banned")), "badge": badge, "badge_anim": anim, "password_hash": ph,
            "auth_v": auth_v, **design, **keys}


def _restore_avatar(uid: int, av) -> bool:
    if not isinstance(av, dict) or not isinstance(av.get("data"), str) or len(av["data"]) > MAX_AVATAR_EXPORT * 2:
        return False
    try:
        raw = base64.b64decode(av["data"], validate=True)
    except ValueError:
        return False
    if not raw or len(raw) > settings.max_avatar_bytes or not avatars.sniff_image(raw):
        return False
    from app.services import imgclean
    try:
        img = imgclean.clean(raw)
    except ChatError:
        return False
    name = f"{secrets.token_hex(12)}.{img.ext}"
    (settings.avatars_dir / name).write_bytes(img.data)
    users.set_active_avatar(uid, avatars_repo.add(uid, name, time.time()))
    return True


def restore_users(actor, data) -> dict:
    _owner_only(actor)
    if not isinstance(data, dict) or data.get("app") != "anonim-chat" or data.get("v") != FORMAT or not isinstance(data.get("users"), list):
        raise ChatError("Bu Anonim Chat zaxirasi emas yoki versiyasi mos kelmaydi")
    recs = data["users"]
    if len(recs) > MAX_USERS:
        raise ChatError("Zaxirada akkauntlar juda ko'p")
    made = skipped = bad = pics = 0
    for raw in recs:
        if isinstance(raw, dict) and raw.get("role") == "owner":
            skipped += 1
            continue
        try:
            rec = _clean(raw)
        except (ValueError, ChatError):
            bad += 1
            continue
        if rec["username"] == OWNER_USERNAME.lower() or users.get_by_username(rec["username"]):
            skipped += 1
            continue
        try:
            uid = users.create_restored(rec)
        except sqlite3.IntegrityError:
            skipped += 1
            continue
        made += 1
        if isinstance(raw, dict) and raw.get("avatar") and _restore_avatar(uid, raw["avatar"]):
            pics += 1
    return {"created": made, "skipped": skipped, "invalid": bad, "avatars": pics}
