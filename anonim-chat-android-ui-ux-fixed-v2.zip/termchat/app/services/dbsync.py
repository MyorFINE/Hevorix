"""Bazani (xabarlar, hisoblar, sozlamalar) R2 ga zaxiralash va qayta ishga tushganda tiklash.

Render free'da disk vaqtinchalik: server uxlab qolsa yoki qayta ishga tushsa lokal baza yo'qoladi. Shu sababli:
  * ishga tushganda lokal baza yo'q bo'lsa — R2 dagi so'nggi nusxa tiklanadi;
  * ishlab turganda baza o'zgargan bo'lsa har DB_SYNC_SECONDS soniyada, to'xtatilganda (SIGTERM) darhol yangi nusxa yuklanadi.
Nusxa master kalit bilan shifrlanadi (AES-256-GCM). Xabar matnlari bazada allaqachon E2EE konvert ko'rinishida.
Oldingi nusxa `db/chat.db.prev.enc` sifatida saqlanadi (bitta yomon yozuv hammasini yo'q qilmasin).
"""
from __future__ import annotations

import asyncio
import logging
import tempfile
from pathlib import Path

from app import crypto
from app.config import settings
from app.services import r2

log = logging.getLogger("termchat.dbsync")

KEY, PREV = "db/chat.db.enc", "db/chat.db.prev.enc"
CTX = "dbsnap"
_last_changes = -1


def restore_if_needed() -> bool:
    """Baza ochilishidan OLDIN chaqiriladi. Lokal baza bor bo'lsa tegmaydi."""
    path: Path = settings.db_path
    if not r2.enabled() or (path.is_file() and path.stat().st_size > 0):
        return False
    for key in (KEY, PREV):
        try:
            blob = r2.get(key)
        except Exception:
            log.exception("R2 dan bazani o'qib bo'lmadi (%s)", key)
            continue
        if blob is None:
            continue
        data = crypto.open_bytes(blob, CTX)
        if data is None:
            log.error("R2 dagi baza nusxasini ochib bo'lmadi (%s): TERMCHAT_MASTER_KEY o'zgargan bo'lishi mumkin", key)
            continue
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        log.warning("Baza R2 dan tiklandi: %s (%d bayt)", key, len(data))
        return True
    log.warning("R2 da baza nusxasi topilmadi: yangi baza yaratiladi")
    return False


def push(force: bool = False) -> bool:
    """Baza o'zgargan bo'lsa (yoki force) shifrlangan nusxani R2 ga yuklaydi."""
    global _last_changes
    if not r2.enabled():
        return False
    from app.db import db
    changes = db._conn.total_changes
    if not force and changes == _last_changes:
        return False
    with tempfile.TemporaryDirectory(prefix="dbsync-") as tmp:
        snap = Path(tmp) / "chat.db"
        db.snapshot(snap)
        sealed = crypto.seal_bytes(snap.read_bytes(), CTX)
    try:
        r2.copy(KEY, PREV)
    except Exception:
        log.warning("Oldingi nusxani PREV ga ko'chirib bo'lmadi")
    r2.put(KEY, sealed)
    _last_changes = changes
    return True


async def loop() -> None:
    every = settings.db_sync_seconds
    if every <= 0 or not r2.enabled():
        return
    while True:
        await asyncio.sleep(every)
        try:
            await asyncio.to_thread(push)
        except Exception:
            log.exception("Bazani R2 ga yuklab bo'lmadi")


async def final_push() -> None:
    if settings.db_sync_seconds > 0 and r2.enabled():
        try:
            await asyncio.to_thread(push, True)
            log.info("Baza R2 ga yakuniy yuklandi")
        except Exception:
            log.exception("Yakuniy yuklash xatosi")
