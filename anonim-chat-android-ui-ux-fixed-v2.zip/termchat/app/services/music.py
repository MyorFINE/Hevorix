"""Profil musiqalari: har bir foydalanuvchi o'z profiliga cheklangan miqdorda musiqa qo'yadi.

Limit: umumiy sukut (sukut 3) + admin tomonidan alohida foydalanuvchi uchun kengaytirish.
Fayllar data/music/ da, R2 yoqilgan bo'lsa music/ prefiksida ham saqlanadi (avtomatik o'chmaydi).
"""
from __future__ import annotations

import re
import secrets
import time

from app.config import settings
from app.errors import ChatError
from app.repositories import chat_settings, music, users
from app.roles import is_admin
from app.services import r2

MAX_LIMIT = 100
_CTRL = re.compile(r"[\x00-\x1f\x7f\u202a-\u202e\u2066-\u2069]")


def sniff_audio(raw: bytes) -> tuple[str, str] | None:
    """(kengaytma, mime) yoki None. Faqat haqiqiy audio konteynerlar."""
    h = raw[:16]
    if h.startswith(b"ID3") or (len(h) > 1 and h[0] == 0xFF and (h[1] & 0xE0) == 0xE0 and (h[1] & 0x06) != 0):
        return "mp3", "audio/mpeg"
    if h[4:8] == b"ftyp":
        return "m4a", "audio/mp4"
    if h.startswith(b"OggS"):
        return "ogg", "audio/ogg"
    if h.startswith(b"RIFF") and h[8:12] == b"WAVE":
        return "wav", "audio/wav"
    if h.startswith(b"fLaC"):
        return "flac", "audio/flac"
    if h.startswith(b"\x1a\x45\xdf\xa3"):
        return "webm", "audio/webm"
    return None


def _clean(text, limit: int, fallback: str) -> str:
    t = _CTRL.sub("", str(text or "")).strip()
    t = " ".join(t.split())[:limit].strip()
    return t or fallback


def default_limit() -> int:
    v = chat_settings.get("music_limit", settings.music_limit)
    return v if isinstance(v, int) and not isinstance(v, bool) and 0 <= v <= MAX_LIMIT else settings.music_limit


def limit_for(uid: int) -> int:
    v = chat_settings.get(f"music_limit:{uid}")
    if isinstance(v, int) and not isinstance(v, bool) and 0 <= v <= MAX_LIMIT:
        return v
    return default_limit()


def view(t) -> dict:
    return {"id": t["id"], "uid": t["user_id"], "title": t["title"], "artist": t["artist"],
            "dur": t["duration"], "size": t["size"], "mime": t["mime"]}


def listing(uid: int) -> dict:
    items = music.list_for_user(uid)
    return {"tracks": [view(t) for t in items], "limit": limit_for(uid), "used": len(items), "max_bytes": settings.max_music_bytes}


def upload(user, raw: bytes, title: str, artist: str, duration, filename: str = "") -> dict:
    uid = user["id"]
    if music.count(uid) >= limit_for(uid):
        raise ChatError(f"Profilga eng ko'pi bilan {limit_for(uid)} ta musiqa qo'yish mumkin. Avval birini o'chiring", 403)
    if not raw:
        raise ChatError("Fayl bo'sh")
    if len(raw) > settings.max_music_bytes:
        raise ChatError(f"Musiqa {settings.max_music_bytes // (1024 * 1024)} MB dan oshmasligi kerak", 413)
    kind = sniff_audio(raw)
    if not kind:
        raise ChatError("Faqat audio fayl: MP3, M4A, OGG, WAV, FLAC yoki WEBM")
    ext, mime = kind
    base = re.sub(r"\.[A-Za-z0-9]{1,5}$", "", filename or "")
    dur = int(duration) if isinstance(duration, (int, float)) and not isinstance(duration, bool) and 0 < duration < 36000 else 0
    name = f"{secrets.token_hex(16)}.{ext}"
    (settings.music_dir / name).write_bytes(raw)
    r2.put_file("music", name, raw)
    tid = music.add(uid, name, _clean(title, 80, _clean(base, 80, "Nomsiz musiqa")), _clean(artist, 60, ""), dur, len(raw), mime, time.time())
    return view(music.get(tid))


def _find(track_id: int):
    t = music.get(track_id)
    if not t:
        raise ChatError("Musiqa topilmadi", 404)
    return t


def edit(user, track_id: int, title: str, artist: str) -> dict:
    t = _find(track_id)
    if t["user_id"] != user["id"] and not is_admin(user):
        raise ChatError("Bu musiqani o'zgartira olmaysiz", 403)
    music.rename(t["id"], _clean(title, 80, t["title"]), _clean(artist, 60, ""))
    return view(music.get(t["id"]))


def _unlink(t) -> None:
    try:
        (settings.music_dir / t["filename"]).unlink()
    except OSError:
        pass
    r2.delete_file("music", t["filename"])


def remove(user, track_id: int) -> int:
    t = _find(track_id)
    if t["user_id"] != user["id"] and not is_admin(user):
        raise ChatError("Bu musiqani o'chira olmaysiz", 403)
    music.delete(t["id"])
    _unlink(t)
    return t["user_id"]


def wipe_user(uid: int) -> None:
    for t in music.list_for_user(uid):
        music.delete(t["id"])
        _unlink(t)


def read(track_id: int) -> tuple[bytes, dict]:
    t = _find(track_id)
    p = settings.music_dir / t["filename"]
    data = None
    try:
        data = p.read_bytes()
    except OSError:
        if r2.enabled():
            try:
                data = r2.get(f"music/{t['filename']}")
            except Exception:
                data = None
            if data is not None:
                try:
                    p.write_bytes(data)
                except OSError:
                    pass
    if data is None:
        raise ChatError("Musiqa fayli topilmadi", 404)
    return data, t


def set_limit(actor, user_id: int | None, limit: int | None) -> dict:
    if not is_admin(actor):
        raise ChatError("Faqat adminlar limitni o'zgartira oladi", 403)
    if user_id is None:
        if limit is None or isinstance(limit, bool) or not 0 <= limit <= MAX_LIMIT:
            raise ChatError(f"Limit 0 dan {MAX_LIMIT} gacha bo'lishi kerak")
        chat_settings.put("music_limit", limit)
        return {"default": limit}
    t = users.get(user_id)
    if not t or t["deleted"]:
        raise ChatError("Foydalanuvchi topilmadi", 404)
    if limit is None:
        chat_settings.put(f"music_limit:{user_id}", None)
    else:
        if isinstance(limit, bool) or not 0 <= limit <= MAX_LIMIT:
            raise ChatError(f"Limit 0 dan {MAX_LIMIT} gacha bo'lishi kerak")
        chat_settings.put(f"music_limit:{user_id}", limit)
    return {"user_id": user_id, "limit": limit_for(user_id)}
