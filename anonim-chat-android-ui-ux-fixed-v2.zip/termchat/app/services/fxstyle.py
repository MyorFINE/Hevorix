from __future__ import annotations

import json

_TEXT = ("shimmer", "aurora", "sunrise", "ocean", "gold", "candy", "glitch", "float", "pulse")

FX: dict[str, tuple[str, ...]] = {
    "nick": _TEXT + ("wave",),
    "user": _TEXT,
    "bio": ("shimmer", "aurora", "sunrise", "ocean", "gold", "candy", "breathe"),
    "page": ("flow", "stars", "float"),
    "reply": ("line", "tint", "stripes", "slidein"),
    "link": ("run", "pill", "flow", "arrow"),
}


# Missiya sovg'alari: faqat inventardan kiyiladi (profiles.update bularni qabul qilmaydi), shuning uchun
# oddiy "Profil dizayni" ro'yxatida yo'q. Nomlari `x_` bilan boshlanadi.
_PTEXT = ("x_neon", "x_lava", "x_royal", "x_rainbow", "x_frost", "x_glow")
PREMIUM_FX: dict[str, tuple[str, ...]] = {
    "nick": _PTEXT,
    "bio": _PTEXT,
    "msg": ("x_glow", "x_flow", "x_sparkle", "x_pulse", "x_neon", "x_royal"),
    "avatar": ("x_pulse", "x_float", "x_swing", "x_heartbeat", "x_glitch", "x_spin"),
}
PREMIUM_FRAMES = ("x_neon", "x_galaxy", "x_royal", "x_toxic", "x_plasma", "x_glacier")
PREMIUM_BANNERS = ("x_nebula", "x_lava", "x_matrix", "x_sakura", "x_abyss", "x_royal")
FX_ALL: dict[str, tuple[str, ...]] = {k: FX.get(k, ()) + PREMIUM_FX.get(k, ()) for k in set(FX) | set(PREMIUM_FX)}


def is_premium_fx(area: str, value: str) -> bool:
    return value in PREMIUM_FX.get(area, ())


def parse(raw) -> dict[str, str]:
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except ValueError:
            return {}
    if not isinstance(raw, dict):
        return {}
    return {k: v for k, v in raw.items() if k in FX_ALL and isinstance(v, str) and v in FX_ALL[k]}


def dump(fx: dict[str, str]) -> str | None:
    return json.dumps(fx, sort_keys=True, separators=(",", ":")) if fx else None
