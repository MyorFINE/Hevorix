from __future__ import annotations

import json

_TEXT = ("shimmer", "aurora", "sunrise", "ocean", "gold", "candy", "glitch", "float", "pulse")

FX: dict[str, tuple[str, ...]] = {
    "nick": _TEXT + ("wave",),
    "user": _TEXT,
    "bio": ("shimmer", "aurora", "sunrise", "ocean", "gold", "candy", "breathe"),
    "page": ("flow", "stars", "float"),
    "msg": ("bounce", "slide", "rise", "spin", "drop", "focus", "border"),
    "reply": ("line", "tint", "stripes", "slidein"),
    "link": ("run", "pill", "flow", "arrow"),
}


def parse(raw) -> dict[str, str]:
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except ValueError:
            return {}
    if not isinstance(raw, dict):
        return {}
    return {k: v for k, v in raw.items() if k in FX and isinstance(v, str) and v in FX[k]}


def dump(fx: dict[str, str]) -> str | None:
    return json.dumps(fx, sort_keys=True, separators=(",", ":")) if fx else None
