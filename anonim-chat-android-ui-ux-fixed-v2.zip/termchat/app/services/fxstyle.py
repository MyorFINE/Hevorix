"""Element bo'yicha animatsiyali uslublar (v11): faqat TAYYOR ro'yxatdagi nomlar. Rang yoki CSS kodi qabul qilinmaydi.

Har bir foydalanuvchida `users.fx` ustuni bor: {"nick": "aurora", "msg": "bounce", ...} ko'rinishidagi qisqa JSON.
Mijoz bu nomlarni faqat o'z CSS klasslariga ulaydi, shuning uchun nom ro'yxatdan tashqarida bo'lsa e'tiborga olinmaydi.
"""
from __future__ import annotations

import json

_TEXT = ("shimmer", "aurora", "sunrise", "ocean", "gold", "candy", "glitch", "float", "pulse")

FX: dict[str, tuple[str, ...]] = {
    "nick": _TEXT + ("wave",),                                                    # nickname
    "user": _TEXT,                                                                # @username (to'lqin yo'q)
    "bio": ("shimmer", "aurora", "sunrise", "ocean", "gold", "candy", "breathe"),
    "page": ("flow", "stars", "float"),                                           # profil sahifasi: oqma fon, yulduzlar, suzuvchi avatar
    "msg": ("bounce", "slide", "rise", "spin", "drop", "focus", "border"),        # xabar pufagi paydo bo'lishi
    "reply": ("line", "tint", "stripes", "slidein"),                              # reply iqtibos qutisi
    "link": ("run", "pill", "flow", "arrow"),                                     # havola
}


def parse(raw) -> dict[str, str]:
    """Bazadagi JSON matnni (yoki dict'ni) tekshirib, faqat ruxsat etilgan juftliklarni qaytaradi. Buzuq qiymat = bo'sh."""
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except ValueError:
            return {}
    if not isinstance(raw, dict):
        return {}
    return {k: v for k, v in raw.items() if k in FX and isinstance(v, str) and v in FX[k]}


def dump(fx: dict[str, str]) -> str | None:
    return json.dumps(fx, sort_keys=True, separators=(",", ":")) if fx else None
