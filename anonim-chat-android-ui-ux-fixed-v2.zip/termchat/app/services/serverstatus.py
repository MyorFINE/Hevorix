from __future__ import annotations

import os
import shutil
import threading
import time
from collections import deque
from pathlib import Path

from app import __version__
from app.config import settings
from app.db import db
from app.realtime.manager import manager

STARTED = time.time()
_lock = threading.Lock()
_cpu_prev: tuple[float, float] | None = None
_req_total = 0
_req_err = 0
_req_times: deque[float] = deque(maxlen=5000)
_peak_ws = 0


def count_request(status: int) -> None:
    global _req_total, _req_err
    _req_total += 1
    if status >= 500:
        _req_err += 1
    _req_times.append(time.monotonic())


def _read(path: str) -> str | None:
    try:
        return Path(path).read_text()
    except Exception:
        return None


def _meminfo() -> dict | None:
    txt = _read("/proc/meminfo")
    if not txt:
        return None
    kv = {}
    for line in txt.splitlines():
        k, _, v = line.partition(":")
        parts = v.split()
        if parts:
            kv[k] = int(parts[0]) * 1024
    total = kv.get("MemTotal")
    avail = kv.get("MemAvailable", kv.get("MemFree"))
    if not total or avail is None:
        return None
    return {"total": total, "used": total - avail}


def _cgroup_mem() -> dict | None:
    for cur, lim in (("/sys/fs/cgroup/memory.current", "/sys/fs/cgroup/memory.max"),
                     ("/sys/fs/cgroup/memory/memory.usage_in_bytes", "/sys/fs/cgroup/memory/memory.limit_in_bytes")):
        c, m = _read(cur), _read(lim)
        if c and m and m.strip().isdigit() and int(m) < (1 << 50):
            return {"total": int(m), "used": int(c)}
    return None


def _rss() -> int | None:
    txt = _read("/proc/self/status")
    if txt:
        for line in txt.splitlines():
            if line.startswith("VmRSS:"):
                return int(line.split()[1]) * 1024
    try:
        import resource
        r = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        return int(r) * (1 if os.uname().sysname == "Darwin" else 1024)
    except Exception:
        return None


def _cpu_percent() -> float | None:
    global _cpu_prev
    now, cpu = time.monotonic(), time.process_time()
    with _lock:
        prev, _cpu_prev = _cpu_prev, (now, cpu)
    if not prev or now - prev[0] < 0.2:
        return None
    return max(0.0, (cpu - prev[1]) / (now - prev[0]) * 100)


def _dir_size(p: Path) -> int:
    total = 0
    try:
        for root, _d, files in os.walk(p):
            for f in files:
                try:
                    total += os.path.getsize(os.path.join(root, f))
                except OSError:
                    pass
    except Exception:
        pass
    return total


_sizes: tuple[float, dict] = (0.0, {})


def _data_sizes() -> dict:
    global _sizes
    if time.monotonic() - _sizes[0] < 30 and _sizes[1]:
        return _sizes[1]
    d = settings.data_dir
    out = {"db": sum(os.path.getsize(f) for f in (str(settings.db_path), str(settings.db_path) + "-wal") if os.path.exists(f)),
           "media": _dir_size(settings.media_dir), "uploads": _dir_size(settings.uploads_dir),
           "avatars": _dir_size(settings.avatars_dir), "emoji": _dir_size(settings.emoji_dir),
           "backups": _dir_size(settings.backups_dir), "total": _dir_size(d)}
    _sizes = (time.monotonic(), out)
    return out


def snapshot() -> dict:
    global _peak_ws
    t0 = time.perf_counter()
    try:
        db.one("SELECT 1")
        db_ok = True
    except Exception:
        db_ok = False
    db_ms = (time.perf_counter() - t0) * 1000
    users = db.one("SELECT COUNT(*) c FROM users WHERE deleted=0")["c"]
    msgs = db.one("SELECT COUNT(*) c FROM messages WHERE deleted=0")["c"]
    sessions = db.one("SELECT COUNT(*) c FROM sessions")["c"]

    conns = sum(len(s) for s in manager._conns.values())
    _peak_ws = max(_peak_ws, conns)
    now = time.monotonic()
    rps = sum(1 for t in _req_times if now - t <= 10) / 10

    try:
        load = os.getloadavg()
    except Exception:
        load = None
    try:
        du = shutil.disk_usage(settings.data_dir)
        disk = {"total": du.total, "used": du.used, "free": du.free}
    except Exception:
        disk = None
    mem = _cgroup_mem() or _meminfo()
    return {
        "ok": db_ok, "version": __version__, "time": time.time(), "started": STARTED, "uptime": time.time() - STARTED,
        "cpu": {"process_pct": _cpu_percent(), "load": list(load) if load else None, "cores": os.cpu_count() or 1},
        "mem": {**(mem or {}), "process": _rss()} if (mem or _rss()) else None,
        "disk": disk, "data": _data_sizes(),
        "ws": {"connections": conns, "online": manager.count(), "away": len(manager._away), "peak": _peak_ws},
        "http": {"total": _req_total, "errors": _req_err, "rps": rps},
        "db": {"ok": db_ok, "ping_ms": db_ms, "users": users, "messages": msgs, "sessions": sessions},
        "threads": threading.active_count(),
        "pid": os.getpid(),
    }
