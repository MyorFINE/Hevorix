"""Reaksiyalar: umumiy chat, shaxsiy yozishma va kanal postlari. Reaksiya matn emas (faqat emoji), shuning uchun E2EE konvertga kirmaydi."""
import time

from app.constants import REACTION_EMOJIS
from app.errors import ChatError
from app.repositories import messages, reactions
from app.security import limiter
from app.services import channels as channels_svc
from app.services import views


def _visible_message(user, mid: int):
    """Xabarni foydalanuvchi ko'ra olsa qaytaradi (shaxsiy yozishma — faqat ikki ishtirokchi, shaxsiy kanal — ruxsat bor kishi)."""
    m = messages.get_active(mid) if isinstance(mid, int) and not isinstance(mid, bool) else None
    if not m:
        raise ChatError("Xabar topilmadi", 404)
    if m["channel_id"]:
        channels_svc.get_visible(m["channel_id"], user)                # ruxsat yo'q bo'lsa 404
    elif m["recipient_id"] is not None and user["id"] not in (m["user_id"], m["recipient_id"]):
        raise ChatError("Xabar topilmadi", 404)
    return m


def react(user, mid: int, emoji) -> tuple[dict, dict]:
    """Reaksiyani qo'yadi: bir xil emoji qayta bosilsa — olib tashlaydi, boshqasi bosilsa — almashtiradi.
    (xabar qatori, yangi {emoji: [user_id]} ro'yxati) qaytadi."""
    if emoji is not None and emoji not in REACTION_EMOJIS:
        raise ChatError("Bunday reaksiya yo'q")
    left = views.mute_left(user)
    if left > 0:
        raise ChatError(f"Siz mute holatidasiz (~{int(left // 60) + 1} daqiqa qoldi)")
    limiter.check(f"rx:{user['id']}", 40, 10, "Sekinroq (reaksiyalar juda tez)")
    m = _visible_message(user, mid)
    cur = reactions.get_user(m["id"], user["id"])
    if emoji is None or emoji == cur:
        if cur is not None:
            reactions.remove(m["id"], user["id"])
    else:
        reactions.put(m["id"], user["id"], emoji, time.time())
    return m, reactions.grouped(m["id"])
