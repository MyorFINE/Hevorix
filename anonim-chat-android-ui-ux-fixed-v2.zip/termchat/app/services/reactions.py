import time

from app import emojis as emoji_files
from app.constants import REACTION_EMOJIS
from app.errors import ChatError
from app.repositories import emojis as emoji_repo
from app.repositories import messages, reactions
from app.security import limiter
from app.services import channels as channels_svc
from app.services import emoji as emoji_svc
from app.services import views


def _visible_message(user, mid: int):
    m = messages.get_active(mid) if isinstance(mid, int) and not isinstance(mid, bool) else None
    if not m:
        raise ChatError("Xabar topilmadi", 404)
    if m["channel_id"]:
        channels_svc.get_visible(m["channel_id"], user)
    elif m["recipient_id"] is not None and user["id"] not in (m["user_id"], m["recipient_id"]):
        raise ChatError("Xabar topilmadi", 404)
    return m


def _allowed(user, emoji: str) -> bool:
    if emoji in REACTION_EMOJIS:
        return True
    if not emoji_files.is_token(emoji):
        return False
    perms = emoji_svc.perms_of(user)
    if not perms["use"]:
        return False
    row = emoji_repo.get_by_name(emoji[1:-1])
    if row is None:
        return True
    if perms["manage"]:
        return True
    pack = emoji_repo.get_pack(row["pack_id"]) if row["pack_id"] is not None else None
    return bool(row["public"]) and (pack is None or bool(pack["public"]))


def react(user, mid: int, emoji) -> tuple[dict, dict]:
    if emoji is not None and (not isinstance(emoji, str) or len(emoji) > 20):
        raise ChatError("Bunday reaksiya yo'q")
    left = views.mute_left(user)
    if left > 0:
        raise ChatError(f"Siz mute holatidasiz (~{int(left // 60) + 1} daqiqa qoldi)")
    limiter.check(f"rx:{user['id']}", 40, 10, "Sekinroq (reaksiyalar juda tez)")
    m = _visible_message(user, mid)
    cur = reactions.get_user(m["id"], user["id"])
    if emoji is not None and emoji != cur and not _allowed(user, emoji):
        raise ChatError("Bu reaksiyani ishlatishga ruxsatingiz yo'q" if emoji_files.is_token(emoji) else "Bunday reaksiya yo'q")
    if emoji is None or emoji == cur:
        if cur is not None:
            reactions.remove(m["id"], user["id"])
    else:
        reactions.put(m["id"], user["id"], emoji, time.time())
    return m, reactions.grouped(m["id"])
