"""Maxsus emojilar: yaratish, to'plamlar (pack), ruxsatlar.

Ruxsatlar (oddiy foydalanuvchi uchun):
  * umumiy sozlama `emoji_users`: "off" (standart) | "use" — hamma emoji tanlagichini ko'radi va ochiq emojilarni ishlatadi;
  * foydalanuvchiga alohida `emoji_perm`: 0 = umumiy sozlamaga amal qiladi, 1 = ishlata oladi, 2 = ishlatadi VA yarata oladi.
Adminlar va ega har doim hammasini qila oladi.

DIQQAT: xabarlar E2EE — server `:nom:` yozilganini ko'rmaydi. Shuning uchun "faqat adminlar uchun" emojilar
mijoz tanlagichida yashiriladi, lekin kimdir qo'lda `:nom:` yozsa, uni server to'sa olmaydi (hamma ko'radi).
"""
from __future__ import annotations

import base64
import json
import re
import secrets
import time
import zipfile
from io import BytesIO

from app import emojis
from app.config import settings
from app.errors import ChatError
from app.repositories import chat_settings
from app.repositories import emojis as repo
from app.repositories import users as users_repo
from app.roles import is_admin
from app.services import emojimaker, r2

NAME_MAX = 32                 # emoji nomi uzunligi (oldin 14 edi)
NAME_OK = re.compile(r"^[a-z0-9_]{2,%d}$" % NAME_MAX)
MAX_EMOJIS = 0                # 0 = emojilar soniga CHEGARA YO'Q
MAX_PACKS = 0                 # 0 = to'plamlar soniga chegara yo'q
MAX_ZIP = 50 * 1024 * 1024    # ZIP fayl hajmi (faqat server xotirasini himoya qiladi)
ZIP_FILES = 0                 # 0 = ZIP ichidagi emojilar soniga chegara yo'q
ZIP_TOTAL = 300 * 1024 * 1024 # ochilgandagi umumiy hajm (zip-bomba himoyasi)
ZIP_EXT = ("png", "gif")
USER_LIMIT = 0                # 0 = ruxsat berilgan foydalanuvchi uchun ham chegara yo'q


# ------------------------------------------------------------------------------------------ ruxsatlar
def global_mode() -> str:
    return "use" if chat_settings.get("emoji_users", "off") == "use" else "off"


def set_global_mode(actor, mode: str) -> str:
    if mode not in ("off", "use"):
        raise ChatError("Noto'g'ri qiymat")
    chat_settings.put("emoji_users", mode)
    return mode


def perms_of(user) -> dict:
    """{use, create, manage} — shu foydalanuvchi nima qila oladi."""
    if is_admin(user):
        return {"use": True, "create": True, "manage": True}
    p = int(user["emoji_perm"] or 0) if "emoji_perm" in user.keys() else 0
    use = p >= 1 or (p == 0 and global_mode() == "use")
    return {"use": use, "create": p >= 2, "manage": False}


def set_user_perm(actor, uid: int, perm: int) -> dict:
    if isinstance(perm, bool) or perm not in (0, 1, 2):
        raise ChatError("Noto'g'ri ruxsat darajasi")
    t = users_repo.get(uid)
    if not t or t["deleted"]:
        raise ChatError("Foydalanuvchi topilmadi", 404)
    if is_admin(t):
        raise ChatError("Adminlarda bu ruxsat doim bor")
    users_repo.set_emoji_perm(uid, perm)
    return t


# ------------------------------------------------------------------------------------------ nomlar
def clean_name(raw: str) -> str:
    n = re.sub(r"[^a-z0-9_]+", "_", (raw or "").strip().strip(":").lower()).strip("_")
    if not NAME_OK.match(n):
        raise ChatError("Emoji nomi 2–32 belgi: kichik lotin harflari, raqam yoki _ (masalan: kulgi_1)")
    return n


def _free(name: str) -> None:
    if name in emojis.available():
        raise ChatError(f"«{name}» nomli emoji allaqachon bor")


def clean_anim(raw: str | None) -> str | None:
    a = (raw or "").strip().lower()
    if not a or a == "none":
        return None
    if a not in emojimaker.ANIMS:
        raise ChatError("Bunday animatsiya yo'q")
    return a


def _pack_id(raw) -> int | None:
    if raw in (None, "", 0, "0"):
        return None
    try:
        pid = int(raw)
    except (TypeError, ValueError):
        raise ChatError("To'plam noto'g'ri")
    if not repo.get_pack(pid):
        raise ChatError("Bunday to'plam yo'q", 404)
    return pid


# ------------------------------------------------------------------------------------------ katalog
def catalog(user) -> dict:
    """Mijozga: HAMMA emoji (xabarlarda ko'rinishi uchun) + to'plamlar + shu foydalanuvchining ruxsatlari."""
    perms = perms_of(user)
    items = [{**e, "pack": None, "public": True, "anim": None, "animated": False} for e in emojis.listing()]
    for r in repo.all_emojis():
        items.append({"id": r["id"], "name": r["name"], "token": f":{r['name']}:", "file": r["file"], "url": f"/emoji-files/{r['file']}",
                      "label": r["name"].replace("_", " "), "builtin": False, "anim": r["anim"], "animated": bool(r["animated"]),
                      "pack": r["pack_id"], "public": bool(r["public"]), "by": r["created_by"], "author": r["author"] or ""})
    packs = [{"id": p["id"], "name": p["name"], "public": bool(p["public"]), "kind": p["kind"] or "emoji", "scale": p["scale"] or 100} for p in repo.all_packs()]
    out = {"emojis": items, "packs": packs, "perms": perms}
    if perms["manage"]:
        out["global"] = global_mode()
        out["limit"] = 0
        out["user_perms"] = {str(k): v for k, v in users_repo.emoji_perms().items()}
    else:
        out["limit"] = 0
    return out


# ------------------------------------------------------------------------------------------ emoji yaratish
def preview(user, raw: bytes, remove_bg: bool, tolerance: int) -> emojimaker.Made:
    if not perms_of(user)["create"]:
        raise ChatError("Emoji yaratishga ruxsatingiz yo'q", 403)
    return emojimaker.make(raw, remove_bg, tolerance)


def create(user, raw: bytes, name: str, *, anim=None, remove_bg=False, tolerance=emojimaker.TOL_DEFAULT, pack_id=None, public=True) -> dict:
    perms = perms_of(user)
    if not perms["create"]:
        raise ChatError("Emoji yaratishga ruxsatingiz yo'q", 403)
    name = clean_name(name)
    _free(name)
    if MAX_EMOJIS and len(repo.all_emojis()) >= MAX_EMOJIS:
        raise ChatError(f"Emojilar soni chegarasi ({MAX_EMOJIS} ta) to'ldi")
    if not perms["manage"]:
        if USER_LIMIT and repo.count_by(user["id"]) >= USER_LIMIT:
            raise ChatError(f"Siz eng ko'pi bilan {USER_LIMIT} ta emoji yarata olasiz")
        pack_id, public = None, True                   # oddiy foydalanuvchi: to'plamsiz va hamma uchun ochiq
    pid = _pack_id(pack_id)
    anim = clean_anim(anim)
    made = emojimaker.make(raw, remove_bg, tolerance)
    if made.animated:
        anim = None                                    # fayl o'zi animatsiyali — CSS animatsiya ustiga qo'shilmaydi
    file = f"{secrets.token_hex(10)}.{made.ext}"
    (settings.emoji_dir / file).write_bytes(made.data)
    r2.put_file("emoji", file, made.data)
    try:
        eid = repo.add(name, file, anim, made.animated, pid, public, user["id"], time.time())
    except Exception:
        (settings.emoji_dir / file).unlink(missing_ok=True)
        r2.delete_file("emoji", file)
        raise ChatError(f"«{name}» nomli emoji allaqachon bor")
    emojis.reset_cache()
    return {"id": eid, "name": name, "bg_removed": made.bg_removed, "animated": made.animated}


def edit(user, eid: int, *, anim, pack_id, public) -> None:
    e = repo.get(eid)
    if not e:
        raise ChatError("Emoji topilmadi", 404)
    if not perms_of(user)["manage"]:
        raise ChatError("Faqat adminlar emojini tahrirlay oladi", 403)
    a = None if e["animated"] else clean_anim(anim)
    repo.update(eid, anim=a, pack_id=_pack_id(pack_id), public=bool(public))


def delete(user, eid: int) -> dict:
    e = repo.get(eid)
    if not e:
        raise ChatError("Emoji topilmadi", 404)
    if not perms_of(user)["manage"] and e["created_by"] != user["id"]:
        raise ChatError("Bu emojini o'chira olmaysiz", 403)
    repo.remove(eid)
    (settings.emoji_dir / e["file"]).unlink(missing_ok=True)
    r2.delete_file("emoji", e["file"])                 # emoji faqat qo'lda o'chiriladi — R2 dan ham ketadi
    emojis.reset_cache()
    return e


# ------------------------------------------------------------------------------------------ to'plamlar
def _need_manage(user) -> None:
    if not perms_of(user)["manage"]:
        raise ChatError("Faqat adminlar to'plam yarata oladi", 403)


def _pack_name(raw: str) -> str:
    n = " ".join("".join(c for c in (raw or "") if c.isprintable() or c.isspace()).split())      # apostrof (o', g'), emoji va h.k. mumkin; boshqaruv belgilari yo'q
    if not 2 <= len(n) <= 24:
        raise ChatError("To'plam nomi 2–24 belgi bo'lishi kerak")
    return n


def _kind(raw) -> str:
    k = (raw or "emoji")
    if k not in ("emoji", "sticker"):
        raise ChatError("To'plam turi noto'g'ri")
    return k


def _scale(raw) -> int:
    try:
        v = int(raw)
    except (TypeError, ValueError):
        raise ChatError("Hajm noto'g'ri")
    return max(50, min(200, v))


def create_pack(user, name: str, public: bool, kind: str = "emoji") -> int:
    _need_manage(user)
    n = _pack_name(name)
    if MAX_PACKS and len(repo.all_packs()) >= MAX_PACKS:
        raise ChatError(f"To'plamlar soni chegarasi ({MAX_PACKS} ta) to'ldi")
    if repo.pack_by_name(n):
        raise ChatError("Bunday nomli to'plam bor")
    return repo.add_pack(n, public, user["id"], time.time(), _kind(kind), 100)


def edit_pack(user, pid: int, name: str, public: bool, kind: str | None = None, scale: int | None = None) -> None:
    _need_manage(user)
    cur = repo.get_pack(pid)
    if not cur:
        raise ChatError("To'plam topilmadi", 404)
    n = _pack_name(name)
    other = repo.pack_by_name(n)
    if other and other["id"] != pid:
        raise ChatError("Bunday nomli to'plam bor")
    repo.update_pack(pid, n, public, _kind(kind if kind is not None else cur["kind"]), _scale(scale if scale is not None else cur["scale"]))
    repo.set_pack_public(pid, public)             # to'plam yopilsa/ochilsa, ichidagi emojilar ham shunga mos bo'ladi


def delete_pack(user, pid: int) -> None:
    _need_manage(user)
    if not repo.get_pack(pid):
        raise ChatError("To'plam topilmadi", 404)
    repo.remove_pack(pid)                         # ichidagi emojilar o'chmaydi, "to'plamsiz" bo'lib qoladi


# ------------------------------------------------------------------------------------------ ZIP to'plam (faqat adminlar)
def _zip_open(raw: bytes) -> zipfile.ZipFile:
    if not raw:
        raise ChatError("ZIP fayl bo'sh")
    if len(raw) > MAX_ZIP:
        raise ChatError(f"ZIP fayl {MAX_ZIP // (1024 * 1024)} MB dan oshmasligi kerak")
    try:
        return zipfile.ZipFile(BytesIO(raw))
    except zipfile.BadZipFile:
        raise ChatError("ZIP fayl buzilgan yoki ZIP emas")


def _zip_entries(zf: zipfile.ZipFile) -> tuple[list[tuple[zipfile.ZipInfo, str]], list[dict]]:
    """(yaroqli yozuvlar [(info, fayl nomi)], o'tkazib yuborilganlar). Hech narsa diskka yozilmaydi — yo'l (path) ishlatilmaydi."""
    ok, skipped, total = [], [], 0
    for i in zf.infolist():
        if i.is_dir():
            continue
        path = i.filename.replace("\\", "/")
        base = path.split("/")[-1]
        if not base or base.startswith(".") or path.startswith("__MACOSX/"):
            continue
        ext = base.rsplit(".", 1)[-1].lower() if "." in base else ""
        if ext not in ZIP_EXT:
            skipped.append({"file": base, "error": "Faqat PNG va GIF qabul qilinadi"})
        elif i.flag_bits & 0x1:
            skipped.append({"file": base, "error": "Parol bilan himoyalangan"})
        elif i.file_size > emojimaker.MAX_RAW:
            skipped.append({"file": base, "error": f"{emojimaker.MAX_RAW // (1024 * 1024)} MB dan katta"})
        else:
            total += i.file_size
            if total > ZIP_TOTAL:
                raise ChatError("ZIP ichidagi fayllar juda katta")
            if ZIP_FILES and len(ok) >= ZIP_FILES:
                raise ChatError(f"ZIP da {ZIP_FILES} tadan ko'p emoji bo'lmasin")
            ok.append((i, base))
    return ok, skipped


def _zip_read(zf: zipfile.ZipFile, info: zipfile.ZipInfo) -> bytes:
    with zf.open(info) as f:
        data = f.read(emojimaker.MAX_RAW + 1)                # e'lon qilingan hajmga ishonilmaydi
    if len(data) > emojimaker.MAX_RAW:
        raise ChatError("Fayl juda katta")
    return data


def _suggest(base: str, taken: set[str]) -> str:
    stem = re.sub(r"[^a-z0-9_]+", "_", base.rsplit(".", 1)[0].lower()).strip("_")
    stem = stem[:NAME_MAX].strip("_")
    if len(stem) < 2:
        stem = "emoji"
    name, n = stem, 2
    while name in taken or name in emojis.available():
        suf = f"_{n}"
        name = stem[: NAME_MAX - len(suf)] + suf
        n += 1
    taken.add(name)
    return name


def zip_preview(user, raw: bytes) -> dict:
    """ZIP ichidagi PNG/GIF fayllar: tavsiya etilgan nom, ko'rinish va (agar yaroqsiz bo'lsa) sabab. Hech narsa saqlanmaydi."""
    if not perms_of(user)["manage"]:
        raise ChatError("ZIP to'plam faqat adminlar uchun", 403)
    zf = _zip_open(raw)
    ok, skipped = _zip_entries(zf)
    taken: set[str] = set()
    items = []
    for info, base in ok:
        try:
            made = emojimaker.make(_zip_read(zf, info), False, emojimaker.TOL_DEFAULT)
        except ChatError as e:
            skipped.append({"file": base, "error": e.message})
            continue
        mime = "image/webp" if made.ext == "webp" else "image/png"
        items.append({"file": info.filename, "base": base, "name": _suggest(base, taken), "animated": made.animated,
                      "image": f"data:{mime};base64," + base64.b64encode(made.data).decode()})
    if not items:
        raise ChatError("ZIP ichida yaroqli PNG yoki GIF topilmadi")
    return {"items": items, "skipped": skipped, "left": None}


def zip_create(user, raw: bytes, pack_name: str, public: bool, items_json: str, kind: str = "emoji") -> dict:
    """Tanlangan fayllardan to'plam va emojilar yaratadi. Nomlar oldindan tekshiriladi: xato bo'lsa hech narsa yaratilmaydi."""
    if not perms_of(user)["manage"]:
        raise ChatError("ZIP to'plam faqat adminlar uchun", 403)
    try:
        items = json.loads(items_json or "[]")
        assert isinstance(items, list) and all(isinstance(x, dict) for x in items)
    except Exception:
        raise ChatError("Emoji ro'yxati noto'g'ri")
    if not items:
        raise ChatError("Kamida bitta emoji tanlang")
    zf = _zip_open(raw)
    ok, _ = _zip_entries(zf)
    by_path = {i.filename: i for i, _b in ok}
    if MAX_EMOJIS and len(repo.all_emojis()) + len(items) > MAX_EMOJIS:
        raise ChatError(f"Emojilar soni chegarasi ({MAX_EMOJIS} ta) to'lib ketadi")
    pname = _pack_name(pack_name)
    if repo.pack_by_name(pname):
        raise ChatError("Bunday nomli to'plam bor")
    if MAX_PACKS and len(repo.all_packs()) >= MAX_PACKS:
        raise ChatError(f"To'plamlar soni chegarasi ({MAX_PACKS} ta) to'ldi")
    plan, seen = [], set()
    for it in items:
        info = by_path.get(str(it.get("file", "")))
        if not info:
            raise ChatError("ZIP ichida bunday fayl yo'q")
        nm = clean_name(str(it.get("name", "")))
        if nm in seen:
            raise ChatError(f"«{nm}» nomi takrorlandi — har emojiga boshqa nom bering")
        _free(nm)
        seen.add(nm)
        plan.append((info, nm))
    pid = repo.add_pack(pname, bool(public), user["id"], time.time(), _kind(kind), 100)
    created, failed = [], []
    for info, nm in plan:
        file = ""
        try:
            made = emojimaker.make(_zip_read(zf, info), False, emojimaker.TOL_DEFAULT)
            file = f"{secrets.token_hex(10)}.{made.ext}"
            (settings.emoji_dir / file).write_bytes(made.data)
            r2.put_file("emoji", file, made.data)
            repo.add(nm, file, None, made.animated, pid, bool(public), user["id"], time.time())
            created.append(nm)
        except Exception as e:
            if file:
                (settings.emoji_dir / file).unlink(missing_ok=True)
                r2.delete_file("emoji", file)
            failed.append({"name": nm, "error": e.message if isinstance(e, ChatError) else "Yaratib bo'lmadi"})
    if not created:
        repo.remove_pack(pid)
        raise ChatError("Hech bir emoji yaratilmadi: " + (failed[0]["error"] if failed else ""))
    emojis.reset_cache()
    return {"pack_id": pid, "pack": pname, "created": created, "failed": failed}
