"""Maxsus emojilar: yaratish, to'plamlar (pack), ruxsatlar.

Ruxsatlar (oddiy foydalanuvchi uchun):
  * umumiy sozlama `emoji_users`: "off" (standart) | "use" — hamma emoji tanlagichini ko'radi va ochiq emojilarni ishlatadi;
  * foydalanuvchiga alohida `emoji_perm`: 0 = umumiy sozlamaga amal qiladi, 1 = ishlata oladi, 2 = ishlatadi VA yarata oladi.
Adminlar va ega har doim hammasini qila oladi.

DIQQAT: xabarlar E2EE — server `:nom:` yozilganini ko'rmaydi. Shuning uchun "faqat adminlar uchun" emojilar
mijoz tanlagichida yashiriladi, lekin kimdir qo'lda `:nom:` yozsa, uni server to'sa olmaydi (hamma ko'radi).
"""
from __future__ import annotations

import re
import secrets
import time

from app import emojis
from app.config import settings
from app.errors import ChatError
from app.repositories import chat_settings
from app.repositories import emojis as repo
from app.repositories import users as users_repo
from app.roles import is_admin
from app.services import emojimaker

NAME_OK = re.compile(r"^[a-z0-9_]{2,14}$")
MAX_EMOJIS = 300
MAX_PACKS = 30
USER_LIMIT = 30              # ruxsat berilgan oddiy foydalanuvchi eng ko'pi bilan nechta emoji yarata oladi


# ------------------------------------------------------------------------------------------ ruxsatlar
def global_mode() -> str:
    return "use" if chat_settings.get("emoji_users", "off") == "use" else "off"


def set_global_mode(actor, mode: str) -> str:
    if mode not in ("off", "use"):
        raise ChatError("Noto'g'ri qiymat")
    chat_settings.put("emoji_users", mode)
    return mode


def perms_of(user) -> dict:
    """{use, create, manage} — shu foydalanuvchi nima qila oladi."""
    if is_admin(user):
        return {"use": True, "create": True, "manage": True}
    p = int(user["emoji_perm"] or 0) if "emoji_perm" in user.keys() else 0
    use = p >= 1 or (p == 0 and global_mode() == "use")
    return {"use": use, "create": p >= 2, "manage": False}


def set_user_perm(actor, uid: int, perm: int) -> dict:
    if isinstance(perm, bool) or perm not in (0, 1, 2):
        raise ChatError("Noto'g'ri ruxsat darajasi")
    t = users_repo.get(uid)
    if not t or t["deleted"]:
        raise ChatError("Foydalanuvchi topilmadi", 404)
    if is_admin(t):
        raise ChatError("Adminlarda bu ruxsat doim bor")
    users_repo.set_emoji_perm(uid, perm)
    return t


# ------------------------------------------------------------------------------------------ nomlar
def clean_name(raw: str) -> str:
    n = re.sub(r"[^a-z0-9_]+", "_", (raw or "").strip().strip(":").lower()).strip("_")
    if not NAME_OK.match(n):
        raise ChatError("Emoji nomi 2–14 belgi: kichik lotin harflari, raqam yoki _ (masalan: kulgi_1)")
    return n


def _free(name: str) -> None:
    if name in emojis.available():
        raise ChatError(f"«{name}» nomli emoji allaqachon bor")


def clean_anim(raw: str | None) -> str | None:
    a = (raw or "").strip().lower()
    if not a or a == "none":
        return None
    if a not in emojimaker.ANIMS:
        raise ChatError("Bunday animatsiya yo'q")
    return a


def _pack_id(raw) -> int | None:
    if raw in (None, "", 0, "0"):
        return None
    try:
        pid = int(raw)
    except (TypeError, ValueError):
        raise ChatError("To'plam noto'g'ri")
    if not repo.get_pack(pid):
        raise ChatError("Bunday to'plam yo'q", 404)
    return pid


# ------------------------------------------------------------------------------------------ katalog
def catalog(user) -> dict:
    """Mijozga: HAMMA emoji (xabarlarda ko'rinishi uchun) + to'plamlar + shu foydalanuvchining ruxsatlari."""
    perms = perms_of(user)
    items = [{**e, "pack": None, "public": True, "anim": None, "animated": False} for e in emojis.listing()]
    for r in repo.all_emojis():
        items.append({"id": r["id"], "name": r["name"], "token": f":{r['name']}:", "file": r["file"], "url": f"/emoji-files/{r['file']}",
                      "label": r["name"].replace("_", " "), "builtin": False, "anim": r["anim"], "animated": bool(r["animated"]),
                      "pack": r["pack_id"], "public": bool(r["public"]), "by": r["created_by"], "author": r["author"] or ""})
    packs = [{"id": p["id"], "name": p["name"], "public": bool(p["public"])} for p in repo.all_packs()]
    out = {"emojis": items, "packs": packs, "perms": perms}
    if perms["manage"]:
        out["global"] = global_mode()
        out["limit"] = MAX_EMOJIS
        out["user_perms"] = {str(k): v for k, v in users_repo.emoji_perms().items()}
    else:
        out["limit"] = USER_LIMIT
    return out


# ------------------------------------------------------------------------------------------ emoji yaratish
def preview(user, raw: bytes, remove_bg: bool, tolerance: int) -> emojimaker.Made:
    if not perms_of(user)["create"]:
        raise ChatError("Emoji yaratishga ruxsatingiz yo'q", 403)
    return emojimaker.make(raw, remove_bg, tolerance)


def create(user, raw: bytes, name: str, *, anim=None, remove_bg=False, tolerance=emojimaker.TOL_DEFAULT, pack_id=None, public=True) -> dict:
    perms = perms_of(user)
    if not perms["create"]:
        raise ChatError("Emoji yaratishga ruxsatingiz yo'q", 403)
    name = clean_name(name)
    _free(name)
    if len(repo.all_emojis()) >= MAX_EMOJIS:
        raise ChatError(f"Emojilar soni chegarasi ({MAX_EMOJIS} ta) to'ldi")
    if not perms["manage"]:
        if repo.count_by(user["id"]) >= USER_LIMIT:
            raise ChatError(f"Siz eng ko'pi bilan {USER_LIMIT} ta emoji yarata olasiz")
        pack_id, public = None, True                   # oddiy foydalanuvchi: to'plamsiz va hamma uchun ochiq
    pid = _pack_id(pack_id)
    anim = clean_anim(anim)
    made = emojimaker.make(raw, remove_bg, tolerance)
    if made.animated:
        anim = None                                    # fayl o'zi animatsiyali — CSS animatsiya ustiga qo'shilmaydi
    file = f"{secrets.token_hex(10)}.{made.ext}"
    (settings.emoji_dir / file).write_bytes(made.data)
    try:
        eid = repo.add(name, file, anim, made.animated, pid, public, user["id"], time.time())
    except Exception:
        (settings.emoji_dir / file).unlink(missing_ok=True)
        raise ChatError(f"«{name}» nomli emoji allaqachon bor")
    emojis.reset_cache()
    return {"id": eid, "name": name, "bg_removed": made.bg_removed, "animated": made.animated}


def edit(user, eid: int, *, anim, pack_id, public) -> None:
    e = repo.get(eid)
    if not e:
        raise ChatError("Emoji topilmadi", 404)
    if not perms_of(user)["manage"]:
        raise ChatError("Faqat adminlar emojini tahrirlay oladi", 403)
    a = None if e["animated"] else clean_anim(anim)
    repo.update(eid, anim=a, pack_id=_pack_id(pack_id), public=bool(public))


def delete(user, eid: int) -> dict:
    e = repo.get(eid)
    if not e:
        raise ChatError("Emoji topilmadi", 404)
    if not perms_of(user)["manage"] and e["created_by"] != user["id"]:
        raise ChatError("Bu emojini o'chira olmaysiz", 403)
    repo.remove(eid)
    (settings.emoji_dir / e["file"]).unlink(missing_ok=True)
    emojis.reset_cache()
    return e


# ------------------------------------------------------------------------------------------ to'plamlar
def _need_manage(user) -> None:
    if not perms_of(user)["manage"]:
        raise ChatError("Faqat adminlar to'plam yarata oladi", 403)


def _pack_name(raw: str) -> str:
    n = " ".join("".join(c for c in (raw or "") if c.isprintable() or c.isspace()).split())      # apostrof (o', g'), emoji va h.k. mumkin; boshqaruv belgilari yo'q
    if not 2 <= len(n) <= 24:
        raise ChatError("To'plam nomi 2–24 belgi bo'lishi kerak")
    return n


def create_pack(user, name: str, public: bool) -> int:
    _need_manage(user)
    n = _pack_name(name)
    if len(repo.all_packs()) >= MAX_PACKS:
        raise ChatError(f"To'plamlar soni chegarasi ({MAX_PACKS} ta) to'ldi")
    if repo.pack_by_name(n):
        raise ChatError("Bunday nomli to'plam bor")
    return repo.add_pack(n, public, user["id"], time.time())


def edit_pack(user, pid: int, name: str, public: bool) -> None:
    _need_manage(user)
    if not repo.get_pack(pid):
        raise ChatError("To'plam topilmadi", 404)
    n = _pack_name(name)
    other = repo.pack_by_name(n)
    if other and other["id"] != pid:
        raise ChatError("Bunday nomli to'plam bor")
    repo.update_pack(pid, n, public)
    repo.set_pack_public(pid, public)             # to'plam yopilsa/ochilsa, ichidagi emojilar ham shunga mos bo'ladi


def delete_pack(user, pid: int) -> None:
    _need_manage(user)
    if not repo.get_pack(pid):
        raise ChatError("To'plam topilmadi", 404)
    repo.remove_pack(pid)                         # ichidagi emojilar o'chmaydi, "to'plamsiz" bo'lib qoladi
