"""Umumiy chat moderatsiyasi: sekin rejim, qulflash va avtomatik antispam.

Sozlamalar bazada saqlanadi. Qoidalar faqat UMUMIY chatga tegishli va adminlarga/egaga qo'llanmaydi;
shaxsiy yozishmalar (lichka) hech qachon filtrlanmaydi va tekshirilmaydi.
"""
from __future__ import annotations

import time
from math import ceil

from app.errors import ChatError
from app.repositories import chat_settings, logs, users
from app.roles import is_admin
from app.security import limiter

MAX_SLOWMODE = 3600
SPAM_MUTE_SECONDS = 300
_last_post: dict[int, float] = {}


def get() -> dict:
    return {
        "slowmode": int(chat_settings.get("slowmode", 0) or 0),
        "locked": bool(chat_settings.get("locked", False)),
        "newuser_text": str(chat_settings.get("newuser_text", "") or ""),
    }


def public() -> dict:
    """Hamma foydalanuvchiga ko'rinadigan qism (guruh rasmi va bio'si ham shu yerda)."""
    s = get()
    av = chat_settings.get("group_avatar", None)
    return {"slowmode": s["slowmode"], "locked": s["locked"], "bio": chat_settings.get("group_bio", "") or "",
            "avatar": f"/avatars/{av}" if av else None}


def set_slowmode(actor, seconds) -> int:
    if isinstance(seconds, bool) or not isinstance(seconds, int) or not 0 <= seconds <= MAX_SLOWMODE:
        raise ChatError(f"Sekin rejim 0 dan {MAX_SLOWMODE} soniyagacha bo'lishi kerak")
    chat_settings.put("slowmode", seconds)
    logs.add("slowmode", user_id=actor["id"], actor_id=actor["id"], new=f"{seconds} soniya" if seconds else "o'chirildi")
    return seconds


def set_locked(actor, locked: bool) -> bool:
    chat_settings.put("locked", bool(locked))
    logs.add("lock" if locked else "unlock", user_id=actor["id"], actor_id=actor["id"])
    return bool(locked)


def check_group(user) -> None:
    """Umumiy chatga yozishdan oldin: qulf va sekin rejim (adminlar uchun qo'llanmaydi)."""
    if is_admin(user):
        return
    s = get()
    if s["locked"]:
        raise ChatError("Umumiy chat hozir faqat adminlar uchun ochiq (qulflangan)", 403)
    if s["slowmode"]:
        left = s["slowmode"] - (time.monotonic() - _last_post.get(user["id"], -1e9))
        if left > 0:
            raise ChatError(f"Sekin rejim: yana {ceil(left)} soniya kuting", 429)


def note_post(user) -> None:
    _last_post[user["id"]] = time.monotonic()


def spam_strike(user) -> str | None:
    """Tezlik limitiga qayta-qayta urilgan oddiy foydalanuvchini avtomatik mute qiladi (1 daqiqada 3 martadan keyin)."""
    if is_admin(user) or limiter.allow(f"spam:{user['id']}", 3, 60):
        return None
    users.set_mute(user["id"], time.time() + SPAM_MUTE_SECONDS, "spam (avtomatik)")
    logs.add("mute", user_id=user["id"], actor_id=None, new=f"{SPAM_MUTE_SECONDS // 60} daqiqa: spam (avtomatik)")
    return f"Spam uchun {SPAM_MUTE_SECONDS // 60} daqiqaga avtomatik mute qilindingiz"
