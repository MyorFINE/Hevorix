import time

from app.db import db

_cache: dict[int, dict] | None = None
_FIELDS = ("hide_seen", "ghost", "auto_del", "dm_closed")
_DAY = 24 * 3600


def _load() -> dict[int, dict]:
    global _cache
    if _cache is None:
        _cache = {r["user_id"]: {k: bool(r[k]) for k in _FIELDS}
                  for r in db.all("SELECT user_id, hide_seen, ghost, auto_del, dm_closed FROM chat_user_privacy")}
    return _cache


def get(uid: int) -> dict:
    cur = _load().get(uid)
    return {k: (cur[k] if cur else False) for k in _FIELDS}


def is_ghost(uid: int) -> bool:
    return get(uid)["ghost"]


def seen_hidden(uid: int) -> bool:
    cur = get(uid)
    return cur["hide_seen"] or cur["ghost"]


def dm_closed(uid: int) -> bool:
    return get(uid)["dm_closed"]


def set_flags(uid: int, hide_seen=None, ghost=None, auto_del=None, dm_closed=None) -> dict:
    cur = get(uid)
    was_auto = cur["auto_del"]
    for key, val in (("hide_seen", hide_seen), ("ghost", ghost), ("auto_del", auto_del), ("dm_closed", dm_closed)):
        if isinstance(val, bool):
            cur[key] = val
    db.run("INSERT INTO chat_user_privacy(user_id,hide_seen,ghost,auto_del,dm_closed) VALUES(?,?,?,?,?) "
           "ON CONFLICT(user_id) DO UPDATE SET hide_seen=excluded.hide_seen, ghost=excluded.ghost, "
           "auto_del=excluded.auto_del, dm_closed=excluded.dm_closed",
           (uid, int(cur["hide_seen"]), int(cur["ghost"]), int(cur["auto_del"]), int(cur["dm_closed"])))
    now = time.time()
    if cur["auto_del"] and not was_auto:
        db.run("INSERT INTO auto_del_windows(user_id, start, end) VALUES(?,?,NULL)", (uid, now))
    elif was_auto and not cur["auto_del"]:
        db.run("UPDATE auto_del_windows SET end=? WHERE user_id=? AND end IS NULL", (now, uid))
    _load()[uid] = dict(cur)
    return cur


def allow_peer(owner_id: int, peer_id: int) -> None:
    """owner_id peer_id'ga yozdi — endi peer_id ham owner_id'ga yoza oladi (yopiq lichkada ham)."""
    db.run("INSERT OR IGNORE INTO dm_allow(user_id, peer_id) VALUES(?,?)", (owner_id, peer_id))


def has_written_to(sender_id: int, target_id: int) -> bool:
    """target_id ilgari sender_id'ga yozganmi (yozgan bo'lsa sender unga javob yoza oladi)."""
    return db.one("SELECT 1 FROM dm_allow WHERE user_id=? AND peer_id=?", (target_id, sender_id)) is not None


def due_messages(now: float | None = None, limit: int = 500) -> list:
    """24 soat o'tgan va avto-o'chirish oynasiga tushgan xabarlar (oyna yopilgan bo'lsa ham)."""
    now = time.time() if now is None else now
    return db.all(
        "SELECT m.* FROM messages m WHERE m.deleted=0 AND m.channel_id IS NULL AND m.created_at<=? AND EXISTS ("
        "SELECT 1 FROM auto_del_windows w WHERE w.user_id=m.user_id AND m.created_at>=w.start "
        "AND (w.end IS NULL OR m.created_at<w.end)) ORDER BY m.id LIMIT ?", (now - _DAY, limit))


def prune_windows(now: float | None = None) -> None:
    now = time.time() if now is None else now
    db.run("DELETE FROM auto_del_windows WHERE end IS NOT NULL AND end<?", (now - 7 * _DAY,))
