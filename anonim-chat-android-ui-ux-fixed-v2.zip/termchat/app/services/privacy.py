"""Maxfiylik: «last seen» ni yashirish va «Yashirin profil rejimi» (ghost).
hide_seen — boshqalar oxirgi onlayn vaqtingizni ko'rmaydi («yaqinda» deb ko'rinadi); onlayn holat saqlanadi.
ghost     — doim oflayn ko'rinasiz: onlayn/last seen/«yozmoqda…» boshqalarga ketmaydi (o'zingiz hammasini odatdagidek ko'rasiz).
Holat jadvalda saqlanadi; kichik kesh bitta jarayon uchun (bir nechta worker bo'lsa Redis/DB'dan o'qish kerak)."""
from app.db import db

_cache: dict[int, tuple[bool, bool]] | None = None


def _load() -> dict[int, tuple[bool, bool]]:
    global _cache
    if _cache is None:
        _cache = {r["user_id"]: (bool(r["hide_seen"]), bool(r["ghost"])) for r in db.all("SELECT user_id, hide_seen, ghost FROM chat_user_privacy")}
    return _cache


def get(uid: int) -> dict:
    hs, gh = _load().get(uid, (False, False))
    return {"hide_seen": hs, "ghost": gh}


def is_ghost(uid: int) -> bool:
    return _load().get(uid, (False, False))[1]


def seen_hidden(uid: int) -> bool:
    hs, gh = _load().get(uid, (False, False))
    return hs or gh


def set_flags(uid: int, hide_seen=None, ghost=None) -> dict:
    cur = get(uid)
    if isinstance(hide_seen, bool):
        cur["hide_seen"] = hide_seen
    if isinstance(ghost, bool):
        cur["ghost"] = ghost
    db.run("INSERT INTO chat_user_privacy(user_id,hide_seen,ghost) VALUES(?,?,?) "
           "ON CONFLICT(user_id) DO UPDATE SET hide_seen=excluded.hide_seen, ghost=excluded.ghost",
           (uid, int(cur["hide_seen"]), int(cur["ghost"])))
    _load()[uid] = (cur["hide_seen"], cur["ghost"])
    return cur
