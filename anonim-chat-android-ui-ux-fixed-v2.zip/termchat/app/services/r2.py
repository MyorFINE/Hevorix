"""Cloudflare R2 (S3-mos object storage) bilan ishlash.

Muhit o'zgaruvchilari (Render'da): R2_ACCESS_KEY_ID, R2_SECRET_ACCESS_KEY, R2_BUCKET_NAME, R2_ENDPOINT (yoki R2_ACCOUNT_ID), R2_REGION.
Ular bo'lmasa `enabled()` False bo'ladi va ilova avvalgidek lokal diskda ishlaydi.

Kalit tuzilmasi (bucket ichida):
  media/<nom>.e2e     — mijoz qurilmasida shifrlangan fayllar (server mazmunini ko'ra olmaydi), 24 soatdan keyin o'chadi
  emoji/<fayl>        — emoji va stikerlar (doimiy, faqat qo'lda o'chiriladi)
  avatars/<fayl>      — profil rasmlari
  db/chat.db.enc      — bazaning shifrlangan nusxasi (xabarlar E2EE konvert holida, hisoblar), qayta ishga tushganda tiklanadi
"""
from __future__ import annotations

import logging
import threading
from urllib.parse import urlsplit

from app.config import settings

log = logging.getLogger("termchat.r2")

_client = None
_lock = threading.Lock()


def _endpoint() -> str:
    ep = (settings.r2_endpoint or "").strip()
    if not ep and settings.r2_account_id:
        ep = f"https://{settings.r2_account_id}.r2.cloudflarestorage.com"
    if ep and "://" not in ep:
        ep = "https://" + ep
    p = urlsplit(ep)
    return f"{p.scheme}://{p.netloc}" if p.netloc else ""      # oxiriga bucket nomi qo'shib yuborilgan bo'lsa ham tushadi


def enabled() -> bool:
    return bool(settings.r2_bucket and settings.r2_access_key_id and settings.r2_secret_access_key and _endpoint())


def client():
    global _client
    if _client is None:
        with _lock:
            if _client is None:
                import boto3                                             # kech import: R2 o'chiq bo'lsa kutubxona kerak emas
                from botocore.config import Config
                region = settings.r2_region if settings.r2_region in ("auto", "us-east-1") else "auto"
                opts = dict(signature_version="s3v4", retries={"max_attempts": 4, "mode": "standard"},
                            connect_timeout=10, read_timeout=60, s3={"addressing_style": "path"})
                try:                                                      # yangi boto3 R2 bilan CRC32 sarlavhalarida muammo beradi
                    cfg = Config(request_checksum_calculation="when_required", response_checksum_validation="when_required", **opts)
                except TypeError:                                         # eski botocore bu parametrni bilmaydi
                    cfg = Config(**opts)
                _client = boto3.client("s3", endpoint_url=_endpoint(), aws_access_key_id=settings.r2_access_key_id,
                                       aws_secret_access_key=settings.r2_secret_access_key, region_name=region, config=cfg)
    return _client


def _missing(exc: Exception) -> bool:
    code = str(getattr(exc, "response", {}).get("Error", {}).get("Code", ""))
    return code in ("NoSuchKey", "404", "NotFound")


def put(key: str, data: bytes, content_type: str = "application/octet-stream") -> None:
    client().put_object(Bucket=settings.r2_bucket, Key=key, Body=data, ContentType=content_type)


def get(key: str) -> bytes | None:
    try:
        return client().get_object(Bucket=settings.r2_bucket, Key=key)["Body"].read()
    except Exception as e:
        if _missing(e):
            return None
        raise


def delete(key: str) -> None:
    client().delete_object(Bucket=settings.r2_bucket, Key=key)


def delete_many(keys: list[str]) -> int:
    n = 0
    for i in range(0, len(keys), 1000):
        chunk = keys[i:i + 1000]
        client().delete_objects(Bucket=settings.r2_bucket, Delete={"Objects": [{"Key": k} for k in chunk], "Quiet": True})
        n += len(chunk)
    return n


def copy(src: str, dst: str) -> bool:
    try:
        client().copy_object(Bucket=settings.r2_bucket, Key=dst, CopySource={"Bucket": settings.r2_bucket, "Key": src})
        return True
    except Exception as e:
        if _missing(e):
            return False
        raise


def list_objects(prefix: str) -> list[dict]:
    """[{Key, LastModified, Size}] — prefiks bo'yicha hammasi (sahifalab)."""
    out, token = [], None
    while True:
        kw = {"Bucket": settings.r2_bucket, "Prefix": prefix}
        if token:
            kw["ContinuationToken"] = token
        r = client().list_objects_v2(**kw)
        out.extend(r.get("Contents") or [])
        if not r.get("IsTruncated"):
            return out
        token = r.get("NextContinuationToken")


# ---------------------------------------------------------------------------------- lokal papka <-> R2 (emoji, profil rasmlari)
def put_file(prefix: str, name: str, data: bytes) -> None:
    """Emoji/avatar yozilganda: R2 ga darhol nusxa. Xatoda ilova to'xtamaydi (keyingi tozalash tsikli qayta urinadi)."""
    if not enabled():
        return
    try:
        put(f"{prefix}/{name}", data)
    except Exception:
        log.exception("R2 ga yozib bo'lmadi: %s/%s", prefix, name)


def delete_file(prefix: str, name: str) -> None:
    if not enabled():
        return
    try:
        delete(f"{prefix}/{name}")
    except Exception:
        log.exception("R2 dan o'chirib bo'lmadi: %s/%s", prefix, name)


def restore_dir(prefix: str, directory) -> int:
    """Ishga tushganda: lokal papkada yo'q fayllarni R2 dan tiklaydi (Render free diski har safar tozalanadi)."""
    n = 0
    for o in list_objects(prefix + "/"):
        name = o["Key"][len(prefix) + 1:]
        if not name or "/" in name or name.startswith("."):
            continue
        p = directory / name
        if p.exists():
            continue
        data = get(o["Key"])
        if data is not None:
            p.write_bytes(data)
            n += 1
    return n


def upload_missing(prefix: str, directory) -> int:
    """Lokal papkada bor, R2 da yo'q fayllarni yuklaydi (eski fayllarni ko'chirish va yozuv xatolaridan keyin tuzatish)."""
    have = {o["Key"] for o in list_objects(prefix + "/")}
    n = 0
    for p in directory.iterdir():
        if p.is_file() and not p.name.startswith(".") and not p.name.endswith(".tmp") and f"{prefix}/{p.name}" not in have:
            put(f"{prefix}/{p.name}", p.read_bytes())
            n += 1
    return n
