from __future__ import annotations

import asyncio
import logging
import time

from datetime import datetime, timedelta, timezone

from app.config import settings
from app.services import r2

log = logging.getLogger("termchat.maintenance")

INTERVAL = 10 * 60
TMP_MAX_AGE = 3600
BLOB_MAX_AGE = 3600


def sweep_tmp(max_age: float = TMP_MAX_AGE) -> int:
    n, now = 0, time.time()
    for d in (settings.media_dir, settings.avatars_dir, settings.emoji_dir, settings.music_dir):
        try:
            entries = list(d.glob("*.tmp"))
        except OSError:
            continue
        for p in entries:
            try:
                if p.is_file() and now - p.stat().st_mtime > max_age:
                    p.unlink()
                    n += 1
            except OSError:
                pass
    return n


def sweep_blobs(max_age: float = BLOB_MAX_AGE) -> int:
    from app.repositories import e2ee as e2ee_repo
    from app.services import media
    n = 0
    for r in e2ee_repo.stale_blobs(time.time() - max_age):
        media.remove(r["name"])
        e2ee_repo.drop_blob(r["name"])
        n += 1
    return n


def sweep_expired(ttl_hours: float | None = None) -> int:
    from app.repositories import messages
    from app.services import media
    hours = settings.media_ttl_hours if ttl_hours is None else ttl_hours
    if hours <= 0:
        return 0
    cutoff, n = time.time() - hours * 3600, 0
    while True:
        rows = messages.expired_media(cutoff, 200)
        if not rows:
            return n
        for row in rows:
            media.remove_row(row)
            messages.expire_media(row["id"])
            n += 1


def sweep_r2_media(ttl_hours: float | None = None) -> int:
    from app.repositories import e2ee as e2ee_repo
    hours = settings.media_ttl_hours if ttl_hours is None else ttl_hours
    if hours <= 0 or not r2.enabled():
        return 0
    cutoff = datetime.now(timezone.utc) - timedelta(hours=hours)
    old = [o["Key"] for o in r2.list_objects("media/") if o["LastModified"] < cutoff]
    if not old:
        return 0
    r2.delete_many(old)
    for key in old:
        if key.endswith(".e2e"):
            e2ee_repo.drop_blob(key[len("media/"):])
    return len(old)


def sync_r2_dirs() -> int:
    if not r2.enabled():
        return 0
    return r2.upload_missing("emoji", settings.emoji_dir) + r2.upload_missing("avatars", settings.avatars_dir) + r2.upload_missing("music", settings.music_dir)


def auto_backup(hours: int | None = None, keep: int | None = None, directory=None) -> str | None:
    import tempfile
    from pathlib import Path
    from app import datasnap
    from app.db import db
    hours = settings.auto_backup_hours if hours is None else hours
    keep = max(1, settings.auto_backup_keep if keep is None else keep)
    if hours <= 0:
        return None
    d = Path(directory) if directory else settings.backups_dir
    d.mkdir(parents=True, exist_ok=True)
    existing = sorted(d.glob("auto-*.tar.gz"))
    if existing and time.time() - existing[-1].stat().st_mtime < hours * 3600:
        return None
    name = d / time.strftime("auto-%Y%m%d-%H%M%S.tar.gz")
    with tempfile.TemporaryDirectory(prefix="live-", dir=str(d)) as tmp:
        live = Path(tmp) / "chat.db"
        db.snapshot(live)
        datasnap.create(settings.data_dir, name, include_files=False, db_file=live)
    datasnap.verify(name)
    for old in sorted(d.glob("auto-*.tar.gz"))[:-keep]:
        old.unlink(missing_ok=True)
    log.info("Avtomatik zaxira: %s", name.name)
    return name.name


def shrink_avatars(limit: int = 20) -> int:
    from app.services import imgclean
    from app.services.avatars import AVATAR_SIDE
    n = 0
    for p in settings.avatars_dir.iterdir():
        if n >= limit:
            break
        if not p.is_file() or p.suffix.lower() not in (".jpg", ".png", ".webp", ".gif"):
            continue
        try:
            raw = p.read_bytes()
            from PIL import Image
            from io import BytesIO
            with Image.open(BytesIO(raw)) as im:
                if max(im.size) <= AVATAR_SIDE:
                    continue
            img = imgclean.clean(raw, AVATAR_SIDE)
            if img.ext != p.suffix.lower().lstrip("."):
                continue
            tmp = p.with_name(p.name + ".tmp")
            tmp.write_bytes(img.data)
            tmp.replace(p)
            n += 1
        except Exception:
            log.warning("Avatar kichraytirilmadi: %s", p.name)
    return n


def run_once() -> dict:
    from app.services import auth
    out = {"tmp": sweep_tmp(), "blobs": sweep_blobs(), "sessions": auth.purge_idle_sessions(), "avatars": shrink_avatars()}
    for name, fn in (("expired", sweep_expired), ("r2_media", sweep_r2_media), ("r2_sync", sync_r2_dirs)):
        try:
            out[name] = fn()
        except Exception:
            log.exception("Tozalash bosqichi muvaffaqiyatsiz: %s", name)
    try:
        out["backup"] = auto_backup()
    except Exception:
        log.exception("Avtomatik zaxira xatosi")
    if any(out.values()):
        log.info("Tozalash: %s", out)
    return out


async def loop() -> None:
    while True:
        try:
            await asyncio.to_thread(run_once)
        except Exception:
            log.exception("Davriy tozalash xatosi")
        await asyncio.sleep(INTERVAL)
