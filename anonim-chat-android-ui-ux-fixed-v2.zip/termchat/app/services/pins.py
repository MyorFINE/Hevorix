"""Xabarni mahkamlash (pin). Umumiy chatda — faqat admin/ega, hamma uchun; lichkada — ikkala tomon o'zi uchun (shaxsiy)."""
import time

from app.errors import ChatError
from app.repositories import messages, pins
from app.roles import Role, role_of
from app.security import limiter
from app.services import views


def _int(v):
    return v if isinstance(v, int) and not isinstance(v, bool) else None


def set_pin(user, mid, on: bool, both: bool = False) -> tuple[dict, bool]:
    """Pinni yoqadi/o'chiradi. (xabar qatori, umumiy_pinmi) qaytadi.
    Lichkada `both=True` bo'lsa — pin suhbatdosh uchun ham qo'yiladi (yoki olib tashlanadi)."""
    limiter.check(f"pin:{user['id']}", 30, 10, "Sekinroq (pinlar juda tez)")
    mid = _int(mid)
    m = messages.get_active(mid) if mid else None
    if not m or m["channel_id"]:
        raise ChatError("Xabar topilmadi", 404)
    if m["recipient_id"] is None:                                   # umumiy chat
        if role_of(user) < Role.ADMIN:
            raise ChatError("Xabarni faqat adminlar mahkamlay oladi", 403)
        owner = pins.GROUP
    else:                                                           # lichka: faqat ikki ishtirokchi, har kim o'zi uchun
        if user["id"] not in (m["user_id"], m["recipient_id"]):
            raise ChatError("Xabar topilmadi", 404)
        owner = user["id"]
    owners = [owner]
    if both and owner != pins.GROUP:                               # lichka: suhbatdosh uchun ham
        owners.append(m["recipient_id"] if m["user_id"] == user["id"] else m["user_id"])
    if on:
        if not pins.has(mid, owner) and (len(pins.group_rows()) if owner == pins.GROUP else 0) >= MAX_GROUP_PINS:
            raise ChatError(f"Umumiy chatda {MAX_GROUP_PINS} tadan ko'p xabar mahkamlab bo'lmaydi")
        for o in owners:
            pins.put(mid, o, time.time())
    else:
        for o in owners:
            pins.remove(mid, o)
    return m, owner == pins.GROUP


MAX_GROUP_PINS = 20


def group_pins() -> list[dict]:
    return [views.message_view(r) for r in pins.group_rows()]


def dm_pins(user, partner_id: int) -> list[dict]:
    return [views.message_view(r) for r in pins.dm_rows(user["id"], partner_id)]
