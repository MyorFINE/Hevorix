"""Online durak: stol ochish, taklif qilish, 2–4 o'yinchi, har bir harakat serverda tekshiriladi.

Xabarlar "dk_" bilan boshlanadi. Har bir o'yinchiga faqat o'z kartalari yuboriladi (boshqalarniki — faqat soni).
Navbat soati: TURN_S soniya ichida yurmagan o'yinchi durak bo'ladi; stoldan chiqib ketgan yoki uzoq vaqt aloqasi uzilgan ham.
Hozircha ochko/reyting yo'q.
"""
from __future__ import annotations

import asyncio
import logging
import random
import secrets
import time

from app.errors import ChatError
from app.games import durak_engine as de
from app.realtime.manager import manager
from app.repositories import games as repo
from app.repositories import users as users_repo
from app.security import limiter
from app.services import webpush

log = logging.getLogger("termchat.durak")

MAX_SEATS = 4
MIN_SEATS = 2
INVITE_TTL = 60
TURN_S = 60
ABANDON_S = 90
LOBBY_IDLE_S = 900
GAME = "durak"
LOSS = 10                                   # durak bo'lgan yo'qotadi
WIN_BY_PLACE = {2: [10], 3: [10, 5], 4: [10, 6, 3]}   # birinchi bo'lib chiqqanlarga (o'rin bo'yicha)
WIN_FORFEIT = {2: 10, 3: 5, 4: 4}           # kimdir vaqtida yurmasa/chiqib ketsa, qolganlarning har biriga
MIN_ACTIONS = 12                            # shundan qisqa o'yin ochko bermaydi
PAIR_LIMIT = 5                              # bir juftlik bilan 24 soatda ko'pi bilan shuncha reytingli o'yin

_tables: dict[str, "Table"] = {}
_user_table: dict[int, str] = {}
_invites: dict[str, dict] = {}
_in: dict[int, str] = {}
_tasks: set[asyncio.Task] = set()


def _spawn(coro) -> asyncio.Task:
    t = asyncio.create_task(coro)
    _tasks.add(t)
    t.add_done_callback(_tasks.discard)
    return t


def _rid() -> str:
    return secrets.token_urlsafe(9)


def busy(uid: int) -> bool:
    return uid in _user_table or uid in _in


class Table:
    def __init__(self, host: int) -> None:
        self.tid = _rid()
        self.host = host
        self.seats: list[int] = [host]
        self.status = "lobby"          # lobby | playing | over
        self.st: de.State | None = None
        self.deadline = 0.0
        self.created = time.monotonic()
        self.off: dict[int, float] = {}
        self.watch: asyncio.Task | None = None
        self.result: dict | None = None
        self.invites: dict[int, str] = {}   # taklif qilingan uid -> taklif id
        self.actions = 0
        self.started = time.time()
        self.base: dict[int, int] = {}
        self.gone: set[int] = set()          # o'yin tugagach (yoki davomida) stoldan chiqqanlar; o'rinlar ro'yxati o'yin tugaguncha o'zgarmaydi

    def pending(self) -> list[int]:
        return list(self.invites)

    def active(self) -> list[int]:
        return [u for u in self.seats if u not in self.gone]


def _view(t: Table, uid: int) -> dict:
    seat = t.seats.index(uid) if uid in t.seats else -1
    if t.st and seat >= t.st.n:
        seat = -1
    game = t.st.view(seat if seat >= 0 else None) if t.st else None
    left = max(0, int((t.deadline - time.monotonic()) * 1000)) if t.status == "playing" else None
    return {"type": "dk_state", "tid": t.tid, "host": t.host, "status": t.status, "seats": list(t.seats), "gone": sorted(t.gone), "me": seat,
            "pending": t.pending(), "base": {str(u): v for u, v in t.base.items()}, "game": game, "left": left, "turnS": TURN_S, "result": t.result, "max": MAX_SEATS, "min": MIN_SEATS}


async def _push(t: Table) -> None:
    for uid in t.active():
        await manager.send_to(uid, _view(t, uid))


def _table_of(user) -> Table:
    tid = _user_table.get(user["id"])
    t = _tables.get(tid) if tid else None
    if not t:
        raise ChatError("Siz hech qanday stolda emassiz")
    return t


async def _close(t: Table, reason: str) -> None:
    if _tables.pop(t.tid, None) is None:
        return
    for iid in list(t.invites.values()):
        inv = _invites.get(iid)
        if inv:
            await _end_invite(inv, "cancelled")
    for uid in t.active():
        if _user_table.get(uid) == t.tid:
            _user_table.pop(uid, None)
        await manager.send_to(uid, {"type": "dk_closed", "tid": t.tid, "reason": reason})
    if t.watch and t.watch is not asyncio.current_task():
        t.watch.cancel()


async def create(user) -> None:
    uid = user["id"]
    if not limiter.allow(f"dkmk:{uid}", 6, 60):
        raise ChatError("Juda tez-tez stol ochilmoqda")
    if uid in _user_table:
        raise ChatError("Siz allaqachon stoldasiz")
    if uid in _in:
        raise ChatError("Avval taklifga javob bering")
    t = Table(uid)
    _tables[t.tid] = t
    _user_table[uid] = t.tid
    t.watch = _spawn(_watch(t))
    await _push(t)


# ---------- takliflar ----------
async def _end_invite(inv: dict, status: str) -> None:
    if _invites.pop(inv["id"], None) is None:
        return
    _in.pop(inv["to"], None)
    t = _tables.get(inv["tid"])
    if t:
        t.invites.pop(inv["to"], None)
    task = inv.get("task")
    if task and task is not asyncio.current_task():
        task.cancel()
    await manager.send_many([inv["frm"], inv["to"]], {"type": "dk_invite_end", "id": inv["id"], "status": status, "frm": inv["frm"], "to": inv["to"], "tid": inv["tid"]})
    if t and t.status != "playing" and t.tid in _tables:
        await _push(t)


async def _expire(iid: str) -> None:
    try:
        await asyncio.sleep(INVITE_TTL)
        inv = _invites.get(iid)
        if inv:
            await _end_invite(inv, "expired")
    except asyncio.CancelledError:
        pass


async def invite(user, to) -> None:
    uid = user["id"]
    t = _table_of(user)
    if t.host != uid:
        raise ChatError("Faqat stol egasi taklif qila oladi")
    if t.status == "playing":
        raise ChatError("O'yin davom etmoqda")
    if not isinstance(to, int) or isinstance(to, bool):
        raise ChatError("Foydalanuvchi noto'g'ri")
    if not limiter.allow(f"dkinv:{uid}", 12, 30):
        raise ChatError("Takliflar juda tez yuborilmoqda")
    if to == uid or to in t.seats:
        raise ChatError("Bu foydalanuvchi allaqachon stolda")
    target = users_repo.get(to)
    if not target or target["deleted"] or target["banned"]:
        raise ChatError("Foydalanuvchi topilmadi", 404)
    if to in t.invites:
        raise ChatError("Bu foydalanuvchiga taklif yuborilgan")
    if to in _user_table:
        raise ChatError("Bu foydalanuvchi hozir o'yinda")
    if to in _in:
        raise ChatError("Bu foydalanuvchiga boshqa taklif kelgan, biroz kuting")
    if len(t.active()) + len(t.invites) >= MAX_SEATS:
        raise ChatError(f"Stolda ko'pi bilan {MAX_SEATS} kishi bo'ladi")
    inv = {"id": _rid(), "frm": uid, "to": to, "tid": t.tid, "created": time.time(), "task": None}
    inv["task"] = _spawn(_expire(inv["id"]))
    _invites[inv["id"]] = inv
    _in[to] = inv["id"]
    t.invites[to] = inv["id"]
    await manager.send_to(to, {"type": "dk_invite", "id": inv["id"], "frm": uid, "tid": t.tid, "ttl": INVITE_TTL})
    await _push(t)
    if not manager.is_online(to):
        webpush.fire_game_invite(to, user, "dk")


async def reply(user, iid, accept) -> None:
    inv = _invites.get(iid) if isinstance(iid, str) else None
    if not inv or inv["to"] != user["id"]:
        raise ChatError("Taklif muddati tugagan")
    t = _tables.get(inv["tid"])
    if not accept:
        await _end_invite(inv, "declined")
        return
    if not t or t.status == "playing" or len(t.active()) >= MAX_SEATS or user["id"] in _user_table:
        await _end_invite(inv, "busy")
        return
    await _end_invite(inv, "accepted")
    t.seats.append(user["id"])
    _user_table[user["id"]] = t.tid
    t.created = time.monotonic()
    await _push(t)


async def cancel_invite(user, to) -> None:
    t = _table_of(user)
    iid = t.invites.get(to) if isinstance(to, int) else None
    inv = _invites.get(iid) if iid else None
    if inv and t.host == user["id"]:
        await _end_invite(inv, "cancelled")


# ---------- o'yin ----------
def _deadline(t: Table) -> None:
    t.deadline = time.monotonic() + TURN_S


async def start(user) -> None:
    t = _table_of(user)
    if t.host != user["id"]:
        raise ChatError("Faqat stol egasi boshlay oladi")
    if t.status == "playing":
        raise ChatError("O'yin allaqachon boshlangan")
    if len(t.active()) < MIN_SEATS:
        raise ChatError("Kamida 2 o'yinchi kerak")
    if not limiter.allow(f"dkgo:{user['id']}", 10, 60):
        raise ChatError("Juda tez-tez boshlanmoqda")
    for iid in list(t.invites.values()):
        inv = _invites.get(iid)
        if inv:
            await _end_invite(inv, "cancelled")
    t.seats = t.active()
    t.gone = set()
    t.actions = 0
    t.started = time.time()
    t.base = {u: (repo.stats(u, GAME) or {"points": 0})["points"] for u in t.seats}
    random.shuffle(t.seats)
    t.st = de.State(len(t.seats))
    t.status = "playing"
    t.result = None
    t.off = {}
    _deadline(t)
    await _push(t)


async def act(user, a) -> None:
    t = _table_of(user)
    if t.status != "playing" or not t.st:
        raise ChatError("O'yin boshlanmagan")
    if not isinstance(a, dict) or not isinstance(a.get("t"), str):
        raise ChatError("Harakat noto'g'ri")
    if not limiter.allow(f"dkact:{user['id']}", 30, 10):
        raise ChatError("Juda tez yurilmoqda")
    seat = t.seats.index(user["id"])
    clean = {"t": a["t"]}
    if isinstance(a.get("c"), str):
        clean["c"] = a["c"][:2]
    if isinstance(a.get("i"), int) and not isinstance(a.get("i"), bool):
        clean["i"] = a["i"]
    try:
        t.st.act(seat, clean)
        t.actions += 1
    except ValueError:
        await manager.send_to(user["id"], _view(t, user["id"]))
        raise ChatError("Noqonuniy harakat")
    if t.st.over:
        await _finish(t, "normal")
    else:
        _deadline(t)
        await _push(t)


def _is_rated(t: Table) -> bool:
    if t.actions < MIN_ACTIONS:
        return False
    since = time.time() - 86400
    seats = t.seats
    for i in range(len(seats)):
        for j in range(i + 1, len(seats)):
            if repo.pair_rated_since(GAME, seats[i], seats[j], since) >= PAIR_LIMIT:
                return False
    return True


def _deltas(t: Table, loser: int | None, order: list[int]) -> dict[int, int]:
    """Durak −10; birinchi bo'lib chiqqanlar o'rniga qarab; o'yin oxirigacha o'ynalmasa (taymaut/chiqish) qolganlarga teng."""
    n = len(t.seats)
    d = {u: 0 for u in t.seats}
    if loser is None:
        return d
    d[loser] = -LOSS
    places = WIN_BY_PLACE[n]
    fin = [u for u in order if u != loser]
    for place, u in enumerate(fin):
        d[u] = places[min(place, len(places) - 1)]
    for u in t.seats:
        if u != loser and u not in fin:
            d[u] = WIN_FORFEIT[n]
    return d


async def _finish(t: Table, reason: str, loser_uid: int | None = None) -> None:
    if t.status != "playing":
        return
    st = t.st
    if loser_uid is None and st and st.over and st.over.get("loser") is not None:
        loser_uid = t.seats[st.over["loser"]]
    order = [t.seats[s] for s in st.finish] if st else []
    rated = loser_uid is not None and _is_rated(t)
    delta = _deltas(t, loser_uid, order) if rated else {u: 0 for u in t.seats}
    now = time.time()
    gained, total = {}, {}
    for u in t.seats:
        before = (repo.stats(u, GAME) or {"points": 0})["points"]
        outcome = "d" if loser_uid is None else ("l" if u == loser_uid else "w")
        total[u] = repo.add_result(u, GAME, delta[u], outcome, now)
        gained[u] = total[u] - before
    try:
        if loser_uid is not None:
            winners = [u for u in t.seats if u != loser_uid]
            for w in winners:
                repo.log(GAME, w, loser_uid, "w", reason, gained[w], gained[loser_uid] // max(1, len(winners)), t.actions, rated, t.started, now)
    except Exception:
        log.exception("Durak o'yin jurnaliga yozilmadi")
    t.status = "over"
    t.result = {"loser": loser_uid, "reason": reason, "order": order, "rated": rated,
                "pts": {str(u): v for u, v in gained.items()}, "total": {str(u): v for u, v in total.items()}}
    if st and not st.over:
        st.over = {"loser": t.seats.index(loser_uid) if loser_uid in t.seats else None}
        st.turn = -1
    await _push(t)


async def leave(user) -> None:
    t = _table_of(user)
    uid = user["id"]
    if t.status == "playing":
        await _finish(t, "left", uid)
    if t.status == "lobby":
        if t.host == uid:
            await _close(t, "host_left")
            return
        t.seats = [x for x in t.seats if x != uid]
    else:
        t.gone.add(uid)
    _user_table.pop(uid, None)
    await manager.send_to(uid, {"type": "dk_closed", "tid": t.tid, "reason": "left"})
    rest = t.active()
    if not rest:
        await _close(t, "empty")
        return
    if t.host == uid or t.host in t.gone:
        t.host = rest[0]
    await _push(t)


async def _watch(t: Table) -> None:
    try:
        while t.tid in _tables:
            await asyncio.sleep(0.5)
            now = time.monotonic()
            if t.status == "playing" and t.st:
                if now > t.deadline:
                    seat = t.st.turn
                    if 0 <= seat < len(t.seats):
                        await _finish(t, "timeout", t.seats[seat])
                    continue
                for uid in t.active():
                    if manager.connection_count(uid) > 0:
                        t.off.pop(uid, None)
                    else:
                        since = t.off.setdefault(uid, now)
                        if now - since > ABANDON_S:
                            await _finish(t, "abandon", uid)
                            break
            elif now - t.created > LOBBY_IDLE_S:
                await _close(t, "idle")
                return
    except asyncio.CancelledError:
        pass
    except Exception:
        log.exception("Durak nazoratida xato (tid=%s)", t.tid)


async def sync(user) -> None:
    uid = user["id"]
    tid = _user_table.get(uid)
    t = _tables.get(tid) if tid else None
    if t:
        await manager.send_to(uid, _view(t, uid))
    iid = _in.get(uid)
    inv = _invites.get(iid) if iid else None
    if inv:
        left = max(0.0, INVITE_TTL - (time.time() - inv["created"]))
        if left > 0.3:
            await manager.send_to(uid, {"type": "dk_invite", "id": inv["id"], "frm": inv["frm"], "tid": inv["tid"], "ttl": round(left, 1)})


async def handle(user, data: dict) -> None:
    kind = data.get("type")
    if kind == "dk_create":
        await create(user)
    elif kind == "dk_invite":
        await invite(user, data.get("to"))
    elif kind == "dk_uninvite":
        await cancel_invite(user, data.get("to"))
    elif kind == "dk_reply":
        await reply(user, data.get("id"), bool(data.get("accept")))
    elif kind == "dk_start":
        await start(user)
    elif kind == "dk_act":
        await act(user, data.get("a"))
    elif kind == "dk_leave":
        await leave(user)
    elif kind == "dk_sync":
        await sync(user)


def scoreboard(user) -> dict:
    top = [{"uid": r["user_id"], "points": r["points"], "wins": r["wins"], "losses": r["losses"], "draws": r["draws"]} for r in repo.top(GAME, 30)]
    me = repo.stats(user["id"], GAME)
    mine = {"points": me["points"], "wins": me["wins"], "losses": me["losses"], "draws": me["draws"]} if me else {"points": 0, "wins": 0, "losses": 0, "draws": 0}
    mine["rank"] = repo.rank_of(GAME, mine["points"]) if (me and (me["wins"] + me["losses"] + me["draws"])) else None
    return {"game": GAME, "top": top, "me": mine}
