"""Web Push (RFC 8030 + RFC 8291 aes128gcm + VAPID RFC 8292) — tashqi kutubxonasiz, faqat `cryptography`.

Nega kerak: brauzer/ilova butunlay yopilgan bo'lsa ham telefon/kompyuterga bildirishnoma yetib borishi uchun.
Xabar E2EE bo'lgani uchun push ichida xabar MATNI YO'Q — faqat «kim yozdi» va «qayerga» (umumiy chat / lichka).
Bu ma'lumot ham push xizmatiga (Google/Apple/Mozilla) ochiq ketmaydi: yuk RFC 8291 bo'yicha qurilma kaliti bilan shifrlanadi.
"""
from __future__ import annotations

import asyncio
import base64
import json
import logging
import os
import time
import urllib.error
import urllib.request
from urllib.parse import urlsplit

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.utils import decode_dss_signature
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

from app.config import settings
from app.errors import ChatError
from app.realtime.manager import manager
from app.repositories import push as push_repo

log = logging.getLogger("termchat.push")

TTL = 3 * 24 * 3600                 # qurilma oflayn bo'lsa, push xizmati shuncha vaqt saqlaydi
SEND_TIMEOUT = 10
_sem: asyncio.Semaphore | None = None

# SSRF'dan himoya: server faqat tanilgan push xizmatlariga so'rov yuboradi (foydalanuvchi bergan endpoint tekshiriladi).
ALLOWED_SUFFIXES = (
    ".googleapis.com", ".push.services.mozilla.com", ".notify.windows.com", ".push.apple.com", ".push.samsung.com",
)


def _b64e(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def _b64d(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


# ---------------------------------------------------------------- VAPID kalit
_key: ec.EllipticCurvePrivateKey | None = None


def _load_key() -> ec.EllipticCurvePrivateKey:
    global _key
    if _key is not None:
        return _key
    raw = settings.vapid_private.strip()
    if raw:
        _key = ec.derive_private_key(int.from_bytes(_b64d(raw), "big"), ec.SECP256R1())
    else:
        path = settings.vapid_key_path
        if path.is_file():
            _key = ec.derive_private_key(int.from_bytes(_b64d(path.read_text().strip()), "big"), ec.SECP256R1())
        else:
            _key = ec.generate_private_key(ec.SECP256R1())
            num = _key.private_numbers().private_value.to_bytes(32, "big")
            fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "w") as f:
                f.write(_b64e(num))
            log.warning("Yangi VAPID kalit yaratildi: %s (zaxiralang yoki TERMCHAT_VAPID_PRIVATE_KEY bering — "
                        "yo'qolsa barcha qurilmalar qayta obuna bo'lishi kerak)", path)
    return _key


def public_key() -> str:
    """Brauzer `applicationServerKey` sifatida ishlatadigan ochiq kalit (base64url, 65 bayt)."""
    pub = _load_key().public_key().public_bytes(serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint)
    return _b64e(pub)


def _vapid_header(endpoint: str) -> str:
    u = urlsplit(endpoint)
    head = _b64e(json.dumps({"typ": "JWT", "alg": "ES256"}, separators=(",", ":")).encode())
    claims = _b64e(json.dumps({"aud": f"{u.scheme}://{u.netloc}", "exp": int(time.time()) + 12 * 3600,
                               "sub": settings.vapid_subject}, separators=(",", ":")).encode())
    signing = f"{head}.{claims}".encode()
    r, s = decode_dss_signature(_load_key().sign(signing, ec.ECDSA(hashes.SHA256())))
    sig = r.to_bytes(32, "big") + s.to_bytes(32, "big")                  # JWS ES256: xom r||s
    return f"vapid t={head}.{claims}.{_b64e(sig)}, k={public_key()}"


# ---------------------------------------------------------------- RFC 8291 shifrlash
def encrypt(payload: bytes, p256dh: str, auth: str) -> bytes:
    """aes128gcm tanasi (header + shifrlangan yuk). `p256dh` — qurilmaning ochiq kaliti, `auth` — 16 baytlik sir."""
    ua_pub_raw = _b64d(p256dh)
    auth_secret = _b64d(auth)
    if len(ua_pub_raw) != 65 or ua_pub_raw[0] != 4 or len(auth_secret) != 16:
        raise ValueError("noto'g'ri obuna kalitlari")
    ua_pub = ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(), ua_pub_raw)
    as_priv = ec.generate_private_key(ec.SECP256R1())
    as_pub_raw = as_priv.public_key().public_bytes(serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint)
    shared = as_priv.exchange(ec.ECDH(), ua_pub)
    ikm = HKDF(hashes.SHA256(), 32, auth_secret, b"WebPush: info\x00" + ua_pub_raw + as_pub_raw).derive(shared)
    salt = os.urandom(16)
    cek = HKDF(hashes.SHA256(), 16, salt, b"Content-Encoding: aes128gcm\x00").derive(ikm)
    nonce = HKDF(hashes.SHA256(), 12, salt, b"Content-Encoding: nonce\x00").derive(ikm)
    body = AESGCM(cek).encrypt(nonce, payload + b"\x02", None)          # 0x02 — oxirgi yozuv belgisi
    return salt + (4096).to_bytes(4, "big") + bytes([len(as_pub_raw)]) + as_pub_raw + body


# ---------------------------------------------------------------- endpoint tekshiruvi
def _extra_hosts() -> tuple[str, ...]:
    return tuple("." + h.strip().lstrip(".").lower() for h in settings.push_hosts.split(",") if h.strip())


def validate_endpoint(endpoint: str) -> str:
    if not isinstance(endpoint, str) or len(endpoint) > 1024:
        raise ChatError("Obuna noto'g'ri")
    u = urlsplit(endpoint)
    host = (u.hostname or "").lower()
    if u.scheme != "https" or not host or u.username or u.password or (u.port not in (None, 443)):
        raise ChatError("Obuna manzili noto'g'ri")
    if not any(("." + host).endswith(sfx) or host == sfx.lstrip(".") for sfx in ALLOWED_SUFFIXES + _extra_hosts()):
        raise ChatError("Bu brauzerning bildirishnoma xizmati qo'llab-quvvatlanmaydi")
    return endpoint


def validate_keys(p256dh: str, auth: str) -> None:
    try:
        ok = isinstance(p256dh, str) and isinstance(auth, str) and len(_b64d(p256dh)) == 65 and len(_b64d(auth)) == 16
        if ok:
            ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(), _b64d(p256dh))
    except Exception:
        ok = False
    if not ok:
        raise ChatError("Obuna kalitlari noto'g'ri")


# ---------------------------------------------------------------- yuborish
class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **kw):
        return None


_opener = urllib.request.build_opener(_NoRedirect)


def _post(sub, payload: bytes, topic: str | None, urgency: str) -> int:
    """Bloklovchi so'rov (thread'da ishlaydi). HTTP kodini qaytaradi; tarmoq xatosida 0."""
    try:
        body = encrypt(payload, sub["p256dh"], sub["auth"])
    except Exception:
        return 410                                           # kalitlari yaroqsiz obuna: o'chiriladi
    headers = {"Content-Encoding": "aes128gcm", "Content-Type": "application/octet-stream", "TTL": str(TTL),
               "Urgency": urgency, "Authorization": _vapid_header(sub["endpoint"])}
    if topic:
        headers["Topic"] = topic                             # bir xil mavzudagi kutayotgan push'lar bittaga birlashadi
    req = urllib.request.Request(sub["endpoint"], data=body, headers=headers, method="POST")
    try:
        with _opener.open(req, timeout=SEND_TIMEOUT) as r:
            return r.status
    except urllib.error.HTTPError as e:
        return e.code
    except Exception:
        return 0


async def _send_one(sub, payload: bytes, topic: str | None, urgency: str) -> None:
    global _sem
    if _sem is None:
        _sem = asyncio.Semaphore(16)
    async with _sem:
        code = await asyncio.to_thread(_post, sub, payload, topic, urgency)
    if code in (404, 410):                                   # obuna o'lgan (ilova o'chirilgan / ruxsat qaytarib olingan)
        push_repo.remove(sub["endpoint"])
    elif code in (400, 401, 403):                            # odatda VAPID kaliti almashgan: eski obuna foydasiz
        log.warning("Push rad etildi (%s): %s", code, urlsplit(sub["endpoint"]).netloc)
        push_repo.remove(sub["endpoint"])
    elif 200 <= code < 300:
        push_repo.mark_ok(sub["id"])


def _topic(s: str) -> str:
    return _b64e(s.encode())[:32]


async def notify_message(message: dict, sender_id: int) -> None:
    """Yangi xabar: hozir ONLAYN BO'LMAGAN qabul qiluvchilarga push yuboradi (onlayn bo'lsa xabar WebSocket orqali real vaqtda keladi)."""
    try:
        to = message.get("to")
        sender = message.get("user") or {}
        name = (sender.get("nickname") or sender.get("username") or "Anonim")[:40]
        if to is None:
            subs = push_repo.for_everyone_except(sender_id)
            data = {"k": "g", "n": name, "u": sender_id, "i": message.get("id")}
            topic = _topic("g")
        else:
            subs = push_repo.for_users([to])
            data = {"k": "d", "n": name, "u": sender_id, "i": message.get("id")}
            topic = _topic(f"d{sender_id}")
        subs = [s for s in subs if not manager.is_online(s["user_id"])]
        if not subs:
            return
        data["t"] = int(time.time())
        payload = json.dumps(data, ensure_ascii=False, separators=(",", ":")).encode()
        await asyncio.gather(*[_send_one(s, payload, topic, "high") for s in subs], return_exceptions=True)
    except Exception:
        log.exception("Push yuborishda xato")


def fire(message: dict, sender_id: int) -> None:
    """Xabarni yuborish yo'lini kutdirmaydi: push fon vazifasida ketadi."""
    t = asyncio.create_task(notify_message(message, sender_id))
    _tasks.add(t)
    t.add_done_callback(_tasks.discard)


_tasks: set[asyncio.Task] = set()
