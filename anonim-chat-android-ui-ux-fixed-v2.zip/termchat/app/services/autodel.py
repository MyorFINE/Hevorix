import asyncio
import logging

from app.repositories import messages
from app.services import media, privacy

log = logging.getLogger("termchat.autodel")
INTERVAL = 60


def purge_due() -> list:
    """Muddati o'tgan xabarlarni o'chiradi (oddiy o'chirish bilan bir xil: mark_deleted + fayllar)."""
    done = []
    for row in privacy.due_messages():
        messages.mark_deleted(row["id"])
        media.remove_row(row)
        done.append(row)
    return done


async def run_once() -> int:
    from app.realtime.events import publish_deleted
    rows = await asyncio.to_thread(purge_due)
    for r in rows:
        try:
            await publish_deleted(r)
        except Exception:
            log.exception("O'chirish haqidagi xabar yuborilmadi: #%s", r["id"])
    if rows:
        log.info("Avto-o'chirish: %d ta xabar", len(rows))
    return len(rows)


async def loop() -> None:
    n = 0
    while True:
        try:
            await run_once()
            n += 1
            if n % 360 == 1:
                await asyncio.to_thread(privacy.prune_windows)
        except Exception:
            log.exception("Avto-o'chirish xatosi")
        await asyncio.sleep(INTERVAL)
