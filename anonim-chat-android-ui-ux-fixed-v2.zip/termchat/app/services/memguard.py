"""Xotira (RAM) nazorati — Render free (512 MB) uchun.

Muammo: Python/glibc katta (fayl hajmidagi) bytes obyektlarini bo'shatgach ham xotirani OSga qaytarmaydi, ko'p oqimli
ilovada esa har bir oqim o'z «arena»sini ochib, RSS ni oshiradi. Natijada 20–50 MB fayl bir marta o'tgandan keyin ham ilova
~350 MB turib qoladi. Bu modul:
  * `configure()` — glibc arenalari sonini 2 ga tushiradi (oqimlar ko'p xotira yig'masin);
  * `trim()` — bo'sh xotirani OSga qaytaradi (malloc_trim) va garbage collector'ni ishga tushiradi;
  * `loop()` — har ~40 soniyada xotira bandligi yuqori bo'lsa o'zi tozalaydi;
  * `after_big()` — katta fayl yuklangandan/yuborilgandan keyin darhol chaqiriladi.
Linux/glibc bo'lmasa (Windows/macOS/musl) hech narsa qilmaydi va xato bermaydi.
"""
from __future__ import annotations

import asyncio
import ctypes
import gc
import logging
import threading
import time

log = logging.getLogger("termchat.mem")

_libc = None
_libc_tried = False
_lock = threading.Lock()
_last_trim = 0.0
SOFT_LIMIT = 190 * 1024 * 1024          # shundan oshsa davriy tozalash har safar ishlaydi
MIN_GAP = 3.0                           # ketma-ket tozalash orasidagi eng kichik vaqt (soniya)


def _lib():
    global _libc, _libc_tried
    if not _libc_tried:
        _libc_tried = True
        try:
            _libc = ctypes.CDLL("libc.so.6")
        except Exception:
            _libc = None
    return _libc


def configure() -> None:
    """Jarayon boshida (oqimlar ochilishidan oldin) chaqiriladi."""
    lib = _lib()
    if lib is None:
        return
    try:
        lib.mallopt(-8, 2)               # M_ARENA_MAX = 2
        lib.mallopt(-3, 128 * 1024)      # M_MMAP_THRESHOLD: 128 KB dan kattasi mmap bilan olinadi va bo'shatilganda OSga qaytadi
        lib.mallopt(-1, 256 * 1024)      # M_TRIM_THRESHOLD
    except Exception:
        pass


def rss() -> int | None:
    try:
        with open("/proc/self/status") as f:
            for line in f:
                if line.startswith("VmRSS:"):
                    return int(line.split()[1]) * 1024
    except Exception:
        pass
    return None


def trim(force: bool = False) -> None:
    global _last_trim
    now = time.monotonic()
    if not force and now - _last_trim < MIN_GAP:
        return
    with _lock:
        _last_trim = now
        gc.collect()
        lib = _lib()
        if lib is not None:
            try:
                lib.malloc_trim(0)
            except Exception:
                pass


def after_big(nbytes: int) -> None:
    """Katta (≥1 MB) so'rov/javobdan keyin chaqiriladi."""
    if nbytes >= 1024 * 1024:
        trim()


async def loop() -> None:
    while True:
        await asyncio.sleep(40)
        try:
            r = rss()
            if r is None or r > SOFT_LIMIT:
                await asyncio.to_thread(trim, True)
                if r is not None:
                    log.info("Xotira tozalandi: %d → %d MB", r // 1048576, (rss() or r) // 1048576)
        except Exception:
            log.exception("Xotira tozalashda xato")
