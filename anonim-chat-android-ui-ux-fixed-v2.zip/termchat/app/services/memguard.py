from __future__ import annotations

import asyncio
import ctypes
import gc
import logging
import threading
import time

log = logging.getLogger("termchat.mem")

_libc = None
_libc_tried = False
_lock = threading.Lock()
_last_trim = 0.0
SOFT_LIMIT = 190 * 1024 * 1024
MIN_GAP = 3.0


def _lib():
    global _libc, _libc_tried
    if not _libc_tried:
        _libc_tried = True
        try:
            _libc = ctypes.CDLL("libc.so.6")
        except Exception:
            _libc = None
    return _libc


def configure() -> None:
    lib = _lib()
    if lib is None:
        return
    try:
        lib.mallopt(-8, 2)
        lib.mallopt(-3, 128 * 1024)
        lib.mallopt(-1, 256 * 1024)
    except Exception:
        pass


def rss() -> int | None:
    try:
        with open("/proc/self/status") as f:
            for line in f:
                if line.startswith("VmRSS:"):
                    return int(line.split()[1]) * 1024
    except Exception:
        pass
    return None


def trim(force: bool = False) -> None:
    global _last_trim
    now = time.monotonic()
    if not force and now - _last_trim < MIN_GAP:
        return
    with _lock:
        _last_trim = now
        gc.collect()
        lib = _lib()
        if lib is not None:
            try:
                lib.malloc_trim(0)
            except Exception:
                pass


def after_big(nbytes: int) -> None:
    if nbytes >= 1024 * 1024:
        trim()


async def loop() -> None:
    while True:
        await asyncio.sleep(40)
        try:
            r = rss()
            if r is None or r > SOFT_LIMIT:
                await asyncio.to_thread(trim, True)
                if r is not None:
                    log.info("Xotira tozalandi: %d → %d MB", r // 1048576, (rss() or r) // 1048576)
        except Exception:
            log.exception("Xotira tozalashda xato")
