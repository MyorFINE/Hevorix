"""Admin tomonidan profilga DIZAYN berish (neon, fon, ramka, unvon, "yangi" belgisi, rang).

Admin foydalanuvchining nickname, username, rasm va bio'sini O'ZGARTIRMAYDI: bular faqat egasiniki. Admin faqat ko'rinish (dizayn) beradi.
Admin oddiy foydalanuvchilarga, ega esa adminlarga ham dizayn bera oladi; o'z dizaynini hamma admin o'zgartira oladi.
Platforma egasining dizaynini faqat o'zi o'zgartiradi.
"""
from __future__ import annotations

import re

from app.errors import ChatError
from app.repositories import users
from app.roles import Role, is_admin, role_of
from app.services import auth

BANNERS = ("aurora", "sunset", "ocean", "forest", "midnight", "rose", "gold", "fire", "ice", "violet")
FRAMES = ("gold", "neon", "rainbow", "fire", "ice", "emerald", "rose")
TRUST = {"auto": None, "trusted": 0, "new": 1}          # admin qarori: "yangi foydalanuvchi" belgisi
_NEON_RE = re.compile(r"^#[0-9a-fA-F]{6}$")
_CTRL = re.compile(r"[\x00-\x1f\x7f\u200b-\u200f\u202a-\u202e\u2066-\u2069]")      # boshqaruv va yo'nalish o'zgartiruvchi belgilar


def target_for(actor, target_id):
    """Tahrirlanadigan foydalanuvchi (ruxsat tekshirilgan)."""
    if not is_admin(actor):
        raise ChatError("Profilni faqat adminlar tahrirlay oladi", 403)
    t = users.get(target_id) if isinstance(target_id, int) else None
    if not t or t["deleted"]:
        raise ChatError("Foydalanuvchi topilmadi", 404)
    if t["id"] != actor["id"]:
        if role_of(t) == Role.OWNER or (role_of(t) == Role.ADMIN and role_of(actor) != Role.OWNER):
            raise ChatError("Bu foydalanuvchi profilini o'zgartira olmaysiz", 403)
    return t


def _title(raw: str) -> str | None:
    t = re.sub(r"\s+", " ", _CTRL.sub("", raw or "")).strip()
    if len(t) > 24:
        raise ChatError("Unvon 24 belgidan oshmasligi kerak")
    return t or None


def _choice(raw: str, allowed: tuple, what: str) -> str | None:
    raw = (raw or "").strip().lower()
    if not raw or raw == "none":
        return None
    if raw not in allowed:
        raise ChatError(f"Noto'g'ri {what}")
    return raw


def update(actor, target_id, *, color=None, neon=None, banner=None, frame=None, title=None, trust=None):
    """None = o'zgartirilmaydi; bo'sh qator = tozalash. Qaytaradi: (yangilangan qator, o'zgargan maydonlar)."""
    t = target_for(actor, target_id)
    f: dict = {}
    if color is not None:
        f["color"] = auth.clean_color(actor, color)
    if neon is not None:
        neon = neon.strip()
        if neon and not _NEON_RE.match(neon):
            raise ChatError("Neon rangi #rrggbb ko'rinishida bo'lishi kerak")
        f["neon"] = neon.lower() or None
    if banner is not None:
        f["banner"] = _choice(banner, BANNERS, "fon dizayni")
    if frame is not None:
        f["frame"] = _choice(frame, FRAMES, "ramka")
    if title is not None:
        f["title"] = _title(title)
    if trust is not None:
        if trust not in TRUST:
            raise ChatError("Noto'g'ri holat")
        f["trust"] = TRUST[trust] if not is_admin(t) else None      # "yangi" belgisi faqat oddiy foydalanuvchilarda
    users.set_style(t["id"], f)
    return users.get(t["id"]), sorted(f)
