from __future__ import annotations

import re

from app.errors import ChatError
from app.repositories import users
from app.roles import Role, is_admin, role_of
from app.services import auth, fxstyle

BANNERS = ("aurora", "sunset", "ocean", "forest", "midnight", "rose", "gold", "fire", "ice", "violet")
FRAMES = ("gold", "rainbow", "fire", "ice", "emerald", "rose")
TRUST = {"auto": None, "trusted": 0, "new": 1}
_CTRL = re.compile(r"[\x00-\x1f\x7f\u200b-\u200f\u202a-\u202e\u2066-\u2069]")


def target_for(actor, target_id):
    # Dizaynni faqat egasi o'zgartiradi; boshqalarga admin faqat unvon/ishonch beradi (update() tekshiradi).
    own = isinstance(target_id, int) and target_id == actor["id"]
    if not own and not is_admin(actor):
        raise ChatError("Boshqa foydalanuvchi profilini faqat adminlar o'zgartira oladi", 403)
    t = users.get(target_id) if isinstance(target_id, int) else None
    if not t or t["deleted"]:
        raise ChatError("Foydalanuvchi topilmadi", 404)
    if t["id"] != actor["id"]:
        if role_of(t) == Role.OWNER or (role_of(t) == Role.ADMIN and role_of(actor) != Role.OWNER):
            raise ChatError("Bu foydalanuvchi profilini o'zgartira olmaysiz", 403)
    return t


def _title(raw: str) -> str | None:
    t = re.sub(r"\s+", " ", _CTRL.sub("", raw or "")).strip()
    if len(t) > 24:
        raise ChatError("Unvon 24 belgidan oshmasligi kerak")
    return t or None


def _choice(raw: str, allowed: tuple, what: str) -> str | None:
    raw = (raw or "").strip().lower()
    if not raw or raw == "none":
        return None
    if raw not in allowed:
        raise ChatError(f"Noto'g'ri {what}")
    return raw


def _merge_fx(current_raw, patch) -> str | None:
    if not isinstance(patch, dict) or len(patch) > len(fxstyle.FX):
        raise ChatError("Noto'g'ri uslub ma'lumoti")
    cur = fxstyle.parse(current_raw)
    for k, v in patch.items():
        if k not in fxstyle.FX:
            raise ChatError("Noto'g'ri element")
        v = v.strip().lower() if isinstance(v, str) else None
        if v is None:
            raise ChatError("Noto'g'ri uslub")
        if not v or v == "none":
            cur.pop(k, None)
        elif v in fxstyle.FX[k]:
            cur[k] = v
        else:
            raise ChatError("Noto'g'ri uslub nomi")
    return fxstyle.dump(cur)


def update(actor, target_id, *, color=None, fx=None, banner=None, frame=None, title=None, trust=None):
    t = target_for(actor, target_id)
    own = t["id"] == actor["id"]
    if not own and any(v is not None for v in (color, fx, banner, frame)):
        raise ChatError("Dizaynni har kim o'zi sozlaydi — admin boshqaga dizayn bera olmaydi", 403)
    if title is not None and not is_admin(actor):
        raise ChatError("Unvonni faqat adminlar beradi", 403)
    f: dict = {}
    if color is not None:
        f["color"] = auth.clean_color(actor, color)
    if fx is not None:
        f["fx"] = _merge_fx(t["fx"], fx)
    if banner is not None:
        f["banner"] = _choice(banner, BANNERS, "fon dizayni")
    if frame is not None:
        f["frame"] = _choice(frame, FRAMES, "ramka")
    if title is not None:
        f["title"] = _title(title)
    if trust is not None:
        if not is_admin(actor):
            raise ChatError("Ishonch belgisini faqat adminlar o'zgartira oladi", 403)
        if trust not in TRUST:
            raise ChatError("Noto'g'ri holat")
        f["trust"] = TRUST[trust] if not is_admin(t) else None
    users.set_style(t["id"], f)
    return users.get(t["id"]), sorted(f)
