"""Ovozli qo'ng'iroq signalizatsiyasi (WebSocket orqali). Media serverdan O'TMAYDI: u qurilmalar orasida to'g'ridan-to'g'ri (WebRTC).

Mijoz -> server: {"type": "call", "op": ..., "id": <qo'ng'iroq>, ...}
  start {to}                 qo'ng'iroq boshlash
  accept {id}                qabul qilish (faqat chaqirilgan tomon)
  end {id}                   qo'yish / rad etish / bekor qilish
  rebind {id}                WebSocket qayta ulangandan keyin shu ulanishni qo'ng'iroqqa bog'lash
  kex {id, pub}              ECDH ochiq kaliti (qurilmada yaratilgan)
  confirm {id, mac}          kalit tasdig'i (parol mos kelishini tekshiradi)
  offer/answer {id, sdp}, ice {id, c, mid, idx}   WebRTC signali
Server -> mijoz: {"type": "call", "op": incoming|started|accepted|ended|kex|confirm|offer|answer|ice|error|rebound, ...}

Server faqat ikki ishtirokchi o'rtasida uzatadi, hajm/turini tekshiradi va hech narsani saqlamaydi (qo'ng'iroq tarkibi logga yozilmaydi).
"""
from __future__ import annotations

import asyncio
import logging

from app.config import settings
from app.errors import ChatError
from app.realtime.manager import manager
from app.repositories import users as users_repo
from app.security import limiter
from app.services import activity, webpush
from app.services.calls import Call, CallError, book

log = logging.getLogger("termchat.call")
GRACE = 25                      # soniya: faol qo'ng'iroqda WebSocket uzilsa, qayta ulanishga shuncha vaqt beriladi
RELAY = {"kex", "confirm", "offer", "answer", "ice"}


def _str(v, n: int):
    return v if isinstance(v, str) and 0 < len(v) <= n else None


def clean(op: str, d: dict) -> dict:
    """Uzatiladigan maydonlar: faqat kutilganlari, hajmi cheklangan."""
    if op in ("offer", "answer"):
        sdp = _str(d.get("sdp"), 16000)
        if not sdp:
            raise CallError("bad", "Noto'g'ri signal")
        return {"sdp": sdp}
    if op == "ice":
        c = d.get("c")
        if c is not None and not _str(c, 1000):
            raise CallError("bad", "Noto'g'ri signal")
        mid, idx = d.get("mid"), d.get("idx")
        if mid is not None and not _str(mid, 64):
            raise CallError("bad", "Noto'g'ri signal")
        if idx is not None and (not isinstance(idx, int) or isinstance(idx, bool) or not 0 <= idx < 16):
            raise CallError("bad", "Noto'g'ri signal")
        return {"c": c, "mid": mid, "idx": idx}
    if op == "kex":
        pub = _str(d.get("pub"), 200)
        if not pub:
            raise CallError("bad", "Noto'g'ri signal")
        return {"pub": pub}
    if op == "confirm":
        mac = _str(d.get("mac"), 128)
        if not mac:
            raise CallError("bad", "Noto'g'ri signal")
        return {"mac": mac}
    raise CallError("bad", "Noma'lum amal")


async def _err(ws, err: CallError, call_id=None) -> None:
    await manager.send_ws(ws, {"type": "call", "op": "error", "id": call_id, "code": err.code, "message": err.message})


async def finish(call: Call, reason: str) -> None:
    if book.end(call.id) is None:
        return
    await manager.send_many([call.caller, call.callee], {"type": "call", "op": "ended", "id": call.id, "reason": reason})


async def _ring_timeout(call_id: str) -> None:
    c = book._calls.get(call_id)
    if c is not None and c.state == "ringing":
        await finish(c, "noanswer")


def _schedule_ring(call: Call) -> None:
    loop = asyncio.get_running_loop()
    call.timer = loop.call_later(settings.call_ring_seconds, lambda: loop.create_task(_ring_timeout(call.id)))


async def handle(user: dict, data: dict, ws) -> None:
    uid, op = user["id"], data.get("op")
    cid = data.get("id")
    try:
        if op == "start":
            limiter.check(f"callstart:{uid}", 6, 60, "Juda ko'p qo'ng'iroq urinishi, biroz kuting")
            to = data.get("to")
            if not isinstance(to, int) or isinstance(to, bool):
                raise CallError("bad", "Qabul qiluvchi noto'g'ri ko'rsatilgan")
            target = users_repo.get(to)
            if not target or target["banned"]:
                raise CallError("gone", "Foydalanuvchi topilmadi")
            call = book.start(uid, to, ws)
            _schedule_ring(call)
            online = manager.is_online(to)
            await manager.send_ws(ws, {"type": "call", "op": "started", "id": call.id, "to": to, "online": online,
                                       "ring": settings.call_ring_seconds})
            await manager.send_to(to, {"type": "call", "op": "incoming", "id": call.id, "from": uid, "ring": settings.call_ring_seconds})
            if not online:
                webpush.fire_call(to, {"id": uid, "nickname": user.get("nickname"), "username": user.get("username")})
            activity.record("call", user=user)                        # kimga ekani yozilmaydi
        elif op == "accept":
            call = book.accept(cid, uid, ws)
            if call.timer is not None:
                call.timer.cancel()
                call.timer = None
            await manager.send_except(uid, ws, {"type": "call", "op": "ended", "id": call.id, "reason": "other"})   # boshqa qurilmalarda jiringlash to'xtaydi
            await manager.send_ws(call.ws[call.caller], {"type": "call", "op": "accepted", "id": call.id})
        elif op == "end":
            call = book.get(cid, uid)
            await finish(call, "declined" if call.state == "ringing" and uid == call.callee else "hangup")
        elif op == "rebind":
            call = book.rebind(cid, uid, ws)
            await manager.send_ws(ws, {"type": "call", "op": "rebound", "id": call.id, "state": call.state})
        elif op in RELAY:
            call = book.get(cid, uid)
            if call.state != "active":
                raise CallError("state", "Qo'ng'iroq hali qabul qilinmagan")
            if not book.bound(call, uid, ws):
                return                                                  # boshqa tab/qurilma: e'tiborsiz
            if op == "ice":
                limiter.check(f"callsig-ice:{uid}", 200, 30, "Signal juda tez")
            out = clean(op, data)
            peer_ws = call.ws.get(call.other(uid))
            if peer_ws is None:
                raise CallError("state", "Suhbatdosh hali ulanmagan")
            out.update({"type": "call", "op": op, "id": call.id})
            await manager.send_ws(peer_ws, out)
        else:
            raise CallError("bad", "Noma'lum amal")
    except CallError as e:
        await _err(ws, e, cid if isinstance(cid, str) else None)
    except ChatError as e:
        await _err(ws, CallError("limit", e.message), cid if isinstance(cid, str) else None)


async def on_connect(uid: int, ws) -> None:
    """Push orqali ilova ochilganda hali jiringlayotgan qo'ng'iroq bo'lsa, ko'rsatiladi."""
    c = book.ringing_for(uid)
    if c is not None:
        await manager.send_ws(ws, {"type": "call", "op": "incoming", "id": c.id, "from": c.caller, "ring": settings.call_ring_seconds})


async def on_disconnect(uid: int, ws) -> None:
    c = book.of_user(uid)
    if c is None or c.ws.get(uid) is not ws:
        return
    if c.state == "ringing":
        await finish(c, "drop")
        return
    loop = asyncio.get_running_loop()

    async def _check():
        await asyncio.sleep(GRACE)
        cur = book._calls.get(c.id)
        if cur is not None and not manager.has_conn(uid, cur.ws.get(uid)):
            await finish(cur, "drop")
    loop.create_task(_check())
