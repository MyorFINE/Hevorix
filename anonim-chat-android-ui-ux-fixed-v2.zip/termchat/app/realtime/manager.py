from __future__ import annotations

import logging
from typing import Any

log = logging.getLogger("termchat.realtime")


SEND_TIMEOUT = 8


class ConnectionManager:
    def __init__(self) -> None:
        self._conns: dict[int, set[Any]] = {}
        self._ips: dict[Any, str] = {}
        self._hidden: set[int] = set()
        self._away: set[Any] = set()

    def connect(self, uid: int, ws: Any, ip: str = "") -> bool:
        first = not self.is_online(uid)
        if ip:
            self._ips[ws] = ip
        self._conns.setdefault(uid, set()).add(ws)
        return first

    def connection_count(self, uid: int) -> int:
        return len(self._conns.get(uid, ()))

    def disconnect(self, uid: int, ws: Any) -> bool:
        was = self.is_online(uid)
        self._ips.pop(ws, None)
        self._away.discard(ws)
        sockets = self._conns.get(uid)
        if sockets:
            sockets.discard(ws)
            if not sockets:
                self._conns.pop(uid, None)
        return was and not self.is_online(uid)

    def set_away(self, uid: int, ws: Any, away: bool) -> bool:
        if ws not in self._conns.get(uid, ()):
            return False
        before = self.is_online(uid)
        if away:
            self._away.add(ws)
        else:
            self._away.discard(ws)
        return before != self.is_online(uid)


    def is_online(self, uid: int) -> bool:
        return any(w not in self._away for w in self._conns.get(uid, ()))

    def set_hidden(self, uid: int, hidden: bool) -> None:
        (self._hidden.add if hidden else self._hidden.discard)(uid)

    def is_hidden(self, uid: int) -> bool:
        return uid in self._hidden

    def online_ids(self, viewer: int | None = None) -> list[int]:
        return [uid for uid in self._conns if self.is_online(uid) and (uid not in self._hidden or uid == viewer)]

    def count(self) -> int:
        return sum(1 for uid in self._conns if self.is_online(uid))

    @staticmethod
    async def _send(ws: Any, payload: dict) -> None:
        import asyncio
        import json
        try:
            await asyncio.wait_for(ws.send_text(json.dumps(payload)), SEND_TIMEOUT)
        except asyncio.TimeoutError:
            try:
                await ws.close(1011)
            except Exception:
                pass
        except Exception:
            pass

    @staticmethod
    async def _gather(coros: list) -> None:
        import asyncio
        if coros:
            await asyncio.gather(*coros, return_exceptions=True)

    async def send_to(self, uid: int, payload: dict) -> None:
        await self._gather([self._send(ws, payload) for ws in list(self._conns.get(uid, ()))])

    async def send_many(self, uids, payload: dict) -> None:
        await self._gather([self._send(ws, payload) for uid in dict.fromkeys(uids) for ws in list(self._conns.get(uid, ()))])

    async def broadcast(self, payload: dict, exclude_uid: int | None = None) -> None:
        await self._gather([self._send(ws, payload) for uid, sockets in list(self._conns.items())
                            if uid != exclude_uid for ws in list(sockets)])

    @staticmethod
    def _sys(lines, level: str) -> dict:
        return {"type": "system", "level": level, "lines": [lines] if isinstance(lines, str) else lines}

    async def system(self, uid: int, lines, level: str = "info") -> None:
        await self.send_to(uid, self._sys(lines, level))

    async def broadcast_system(self, lines, level: str = "info", exclude_uid: int | None = None) -> None:
        await self.broadcast(self._sys(lines, level), exclude_uid=exclude_uid)

    async def kick_ip(self, ip: str, code: int) -> int:
        n = 0
        for ws, wip in list(self._ips.items()):
            if wip == ip:
                n += 1
                try:
                    await ws.close(code)
                except Exception:
                    pass
        return n

    async def kick(self, uid: int, code: int) -> None:
        for ws in list(self._conns.get(uid, ())):
            try:
                await ws.close(code)
            except Exception:
                pass


manager = ConnectionManager()
