from app.realtime.manager import manager
from app.services import chat


def _channel_of(row):
    try:
        return row["channel_id"]
    except (KeyError, IndexError):
        return None


async def deliver(msg_row, payload: dict) -> None:
    cid = _channel_of(msg_row)
    if cid:
        from app.repositories import channels as channels_repo
        ch = channels_repo.get(cid)
        if ch is not None:
            await publish_channel(ch, payload)
        return
    aud = chat.audience(msg_row)
    if aud is None:
        await manager.broadcast(payload)
    else:
        await manager.send_many(aud, payload)


async def publish_edited(msg_row, new_text: str, e2e: bool = False) -> None:
    await deliver(msg_row, {"type": "message_edited", "id": msg_row["id"], "to": msg_row["recipient_id"],
                            "from": msg_row["user_id"], "ch": _channel_of(msg_row), ("e2e" if e2e else "content"): new_text})


async def publish_reaction(msg_row, rx: dict) -> None:
    await deliver(msg_row, {"type": "message_reaction", "id": msg_row["id"], "to": msg_row["recipient_id"],
                            "from": msg_row["user_id"], "ch": _channel_of(msg_row), "rx": rx})


async def publish_rotate_hint(reason: str) -> None:
    from app.repositories import users
    await manager.send_many(users.staff_ids(), {"type": "e2ee_rotate_hint", "reason": reason})


async def publish_deleted(msg_row) -> None:
    await deliver(msg_row, {"type": "message_deleted", "id": msg_row["id"], "to": msg_row["recipient_id"],
                            "from": msg_row["user_id"], "ch": _channel_of(msg_row)})


async def publish_user_removed(uid: int) -> None:
    from app.constants import WS_UNAUTHORIZED
    from app.services import views
    await manager.send_to(uid, {"type": "account_removed"})
    await manager.kick(uid, WS_UNAUTHORIZED)
    await manager.broadcast({"type": "user_removed", "user": views.user_view(uid)})
    await manager.broadcast({"type": "members_changed"})


async def publish_channel(ch, payload: dict) -> None:
    from app.services import channels
    aud = channels.audience(ch)
    if aud is None:
        await manager.broadcast(payload)
    else:
        await manager.send_many(aud, payload)
