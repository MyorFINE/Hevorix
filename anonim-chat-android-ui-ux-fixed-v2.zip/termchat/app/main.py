"""Ilova fabrikasi: Anonim Chat by Hevorix."""
import asyncio
import logging
import time
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles

from app import __version__
from app.api import admin as admin_api
from app.api import auth as auth_api
from app.api import e2ee as e2ee_api
from app.api import channels as channels_api
from app.api import media as media_api
from app.api import push as push_api
from app.api import avatars as avatars_api
from app.api import emoji as emoji_api
from app.api import social as social_api
from app.api import ws as ws_api
from app import crypto, sri
from app.config import ROOT, settings
from app.db import db
from app.errors import ChatError
from app.netutil import real_ip
from app.services import activity, bootstrap, dbsync, ipblock, maintenance, media, r2, serverstatus
from app.services import memguard
from app.transport import TunnelMiddleware

memguard.configure()                                       # glibc arenalari: jarayon boshida, oqimlar ochilishidan oldin
STATIC_DIR = ROOT / "app" / "static"
_blocked_logged: dict[str, float] = {}

CSP = ("default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self' data: blob:; media-src 'self' blob:; font-src 'self'; "
       "connect-src 'self' ws: wss:; manifest-src 'self'; object-src 'none'; frame-src 'none'; worker-src 'self'; "
       "frame-ancestors 'none'; base-uri 'none'; form-action 'self'")


@asynccontextmanager
async def lifespan(_: FastAPI):
    try:                                                   # bir vaqtda ko'p oqim = ko'p xotira arenasi: 40 ta emas, 12 ta
        import anyio.to_thread
        anyio.to_thread.current_default_thread_limiter().total_tokens = 12
    except Exception:
        pass
    mem_task = asyncio.create_task(memguard.loop())        # xotirani OSga qaytarish (Render 512 MB)
    task = asyncio.create_task(maintenance.loop())         # davriy tozalash (qoldiq fayllar, eski sessiyalar, 24 soatlik fayllar)
    sync_task = asyncio.create_task(dbsync.loop())         # bazani R2 ga zaxiralash
    try:
        yield
    finally:
        task.cancel()
        sync_task.cancel()
        mem_task.cancel()
        await dbsync.final_push()                          # SIGTERM: oxirgi xabarlar ham R2 ga tushadi


def create_app() -> FastAPI:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    app = FastAPI(title="Anonim Chat by Hevorix", version=__version__, docs_url=None, redoc_url=None, lifespan=lifespan)
    if r2.enabled():                              # Render free diski tozalanadi: emoji va profil rasmlari R2 dan tiklanadi
        for _prefix, _dir in (("emoji", settings.emoji_dir), ("avatars", settings.avatars_dir)):
            try:
                _n = r2.restore_dir(_prefix, _dir)
                if _n:
                    logging.getLogger("termchat").info("R2 dan tiklandi (%s): %s ta", _prefix, _n)
            except Exception:
                logging.getLogger("termchat").exception("R2 dan %s tiklab bo'lmadi", _prefix)
    crypto.migrate_legacy(db)                     # eski ochiq matnlar bir marta shifrlanadi
    media.migrate_legacy()                        # eski ochiq fayllar bir marta shifrlanadi
    bootstrap.ensure_owner()                      # @Hevorix doim mavjud
    from app.repositories import channels as _channels_repo
    _moved = _channels_repo.migrate_legacy_posts()     # eski kanal postlari umumiy xabar tizimiga ko'chiriladi (bir marta)
    if _moved:
        logging.getLogger("termchat").info("Eski kanal postlari ko'chirildi: %s ta", _moved)

    @app.middleware("http")
    async def security_headers(request: Request, call_next):
        path = request.url.path
        if path == "/healthz" and request.method in ("GET", "HEAD"):   # UptimeRobot/Render: hech narsaga bog'liq emas, har doim 200 (HEAD'da tanasi uzatilmaydi)
            return JSONResponse({"status": "ok", "version": __version__}, headers={"Cache-Control": "no-store"})
        if path != "/healthz":
            ip = real_ip(request.headers, request.client)
            if ipblock.is_blocked(ip):            # bloklangan IP: hech narsa ko'rsatilmaydi
                now = time.monotonic()
                if now - _blocked_logged.get(ip, 0) > 60:      # bir IP'dan daqiqada ko'pi bilan 1 ta yozuv
                    _blocked_logged[ip] = now
                    activity.record("blocked", ip=ip, detail=f"{request.method} {path}"[:120])
                if path.startswith("/api/"):
                    return JSONResponse({"detail": "IP manzilingiz bloklangan"}, status_code=403)
                return PlainTextResponse("403 — IP manzilingiz bloklangan", status_code=403)
        response = await call_next(request)
        if path.startswith("/api/"):
            serverstatus.count_request(response.status_code)
        if path.startswith(("/avatars/", "/emoji-files/")):
            response.headers.setdefault("Cache-Control", "public, max-age=31536000, immutable")
        response.headers.setdefault("Content-Security-Policy", CSP)
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "DENY")
        response.headers.setdefault("Referrer-Policy", "no-referrer")
        response.headers.setdefault("Permissions-Policy", "camera=(self), microphone=(self), geolocation=(), payment=(), usb=()")
        response.headers.setdefault("Cross-Origin-Opener-Policy", "same-origin")
        response.headers.setdefault("Cross-Origin-Resource-Policy", "same-origin")
        if path.startswith("/api/") or path == "/":
            response.headers.setdefault("Cache-Control", "no-store")
        elif path == "/sw.js":
            response.headers.setdefault("Cache-Control", "no-cache")
        elif path.startswith("/static/"):
            response.headers.setdefault("Cache-Control", "no-cache")
        if request.url.scheme == "https" or request.headers.get("x-forwarded-proto") == "https":
            response.headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
        return response

    @app.exception_handler(ChatError)
    async def chat_error(_: Request, exc: ChatError):
        return JSONResponse({"detail": exc.message}, status_code=exc.status)

    @app.exception_handler(RequestValidationError)
    async def validation_error(_: Request, __: RequestValidationError):
        return JSONResponse({"detail": "Ma'lumotlar noto'g'ri to'ldirilgan"}, status_code=422)

    app.add_middleware(TunnelMiddleware)          # eng tashqi qatlam: shifrlangan so'rovlarni ochadi

    app.include_router(auth_api.router)
    app.include_router(avatars_api.router)
    app.include_router(emoji_api.router)
    app.include_router(e2ee_api.router)
    app.include_router(social_api.router)
    app.include_router(media_api.router)
    app.include_router(push_api.router)
    app.include_router(channels_api.router)
    app.include_router(admin_api.router)
    app.include_router(ws_api.router)

    app.mount("/avatars", StaticFiles(directory=settings.avatars_dir), name="avatars")
    app.mount("/emoji-files", StaticFiles(directory=settings.emoji_dir), name="emoji_files")   # fayl nomlari tasodifiy; o'chirilsa nomi qayta ishlatilmaydi
    app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

    @app.api_route("/", methods=["GET", "HEAD"], include_in_schema=False)   # HEAD: UptimeRobot kabi monitoring
    async def index():
        return HTMLResponse(sri.render_index(STATIC_DIR))

    @app.get("/sw.js", include_in_schema=False)       # service worker ildizdan xizmat qilishi shart (scope "/")
    async def service_worker():
        return FileResponse(STATIC_DIR / "sw.js", media_type="application/javascript", headers={"Service-Worker-Allowed": "/"})

    @app.api_route("/healthz", methods=["GET", "HEAD"], include_in_schema=False)   # UptimeRobot (HEAD yoki GET) va Render health check
    async def healthz():
        return {"status": "ok", "version": __version__}

    return app


app = create_app()
