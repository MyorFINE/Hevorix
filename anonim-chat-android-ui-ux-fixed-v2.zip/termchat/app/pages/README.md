# pages

Bu qatlam uchun hozirgi kod: app/static/index.html, app/static/js/app.js
