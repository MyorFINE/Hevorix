from typing import Optional

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel

from app.api.deps import admin_user, client_ip, current_user
from app.services import activity
from app.services import emoji as emoji_svc
from app.services import checkers as ck_svc
from app.services import games as svc

router = APIRouter(prefix="/api/games", tags=["games"])


@router.get("/chess/scoreboard")
def chess_scoreboard(user=Depends(current_user)):
    return svc.scoreboard(user)


@router.get("/checkers/scoreboard")
def checkers_scoreboard(user=Depends(current_user)):
    return ck_svc.scoreboard(user)


@router.get("/chess/reactions")
def chess_reactions(user=Depends(current_user)):
    return {"items": svc.reaction_set(), "default": list(svc.REACTIONS), "max": svc.MAX_REACTS, "min": svc.MIN_REACTS,
            "manage": bool(emoji_svc.perms_of(user)["manage"])}


class ReactionsIn(BaseModel):
    items: Optional[list[str]] = None


@router.put("/chess/reactions")
def set_chess_reactions(data: ReactionsIn, request: Request, admin=Depends(admin_user)):
    items = svc.set_reactions(admin, data.items)
    activity.record("emoji", ip=client_ip(request), user=admin, detail="shaxmat reaksiyalari: " + " ".join(items)[:200])
    return {"ok": True, "items": items}
