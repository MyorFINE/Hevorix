"""Gaming: Score board."""
from fastapi import APIRouter, Depends

from app.api.deps import current_user
from app.services import games as svc

router = APIRouter(prefix="/api/games", tags=["games"])


@router.get("/chess/scoreboard")
def chess_scoreboard(user=Depends(current_user)):
    return svc.scoreboard(user)
