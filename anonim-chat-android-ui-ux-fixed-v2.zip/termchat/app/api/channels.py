from fastapi import APIRouter, Depends, File, UploadFile
from fastapi.concurrency import run_in_threadpool
from pydantic import BaseModel, Field

from app.api.deps import current_user
from app.config import settings
from app.realtime.events import publish_channel
from app.realtime.manager import manager
from app.services import channels as svc

router = APIRouter(prefix="/api/channels", tags=["channels"])


class ChannelIn(BaseModel):
    username: str = Field(max_length=40)
    nickname: str = Field(max_length=80)
    private: bool = False
    password: str | None = Field(None, max_length=128)


class ChannelPatch(BaseModel):
    username: str | None = Field(None, max_length=40)
    nickname: str | None = Field(None, max_length=80)
    private: bool | None = None
    password: str | None = Field(None, max_length=128)


class JoinIn(BaseModel):
    username: str = Field(max_length=40)
    password: str = Field(max_length=128)


class EnvelopeIn(BaseModel):
    e2e: str = Field(max_length=40000)


class ViewsIn(BaseModel):
    ids: list[int] = Field(max_length=50)


async def _changed() -> None:
    await manager.broadcast({"type": "channels_changed"})


@router.get("")
def list_channels(user=Depends(current_user)):
    return {"channels": svc.list_channels(user)}


@router.post("")
async def create(data: ChannelIn, user=Depends(current_user)):
    ch = await run_in_threadpool(svc.create, user, data.username, data.nickname, data.private, data.password)
    await _changed()
    return {"channel": ch}


@router.patch("/{cid}")
async def update(cid: int, data: ChannelPatch, user=Depends(current_user)):
    ch = await run_in_threadpool(svc.update, user, cid, username=data.username, nickname=data.nickname,
                                 private=data.private, password=data.password)
    await _changed()
    return {"channel": ch}


@router.post("/{cid}/avatar")
async def set_avatar(cid: int, file: UploadFile = File(...), user=Depends(current_user)):
    raw = await file.read(settings.max_avatar_bytes + 1)
    ch = await run_in_threadpool(svc.set_avatar, user, cid, raw)
    await _changed()
    return {"channel": ch}


@router.delete("/{cid}/avatar")
async def clear_avatar(cid: int, user=Depends(current_user)):
    ch = svc.clear_avatar(user, cid)
    await _changed()
    return {"channel": ch}


@router.delete("/{cid}")
async def delete(cid: int, user=Depends(current_user)):
    svc.delete(user, cid)
    await _changed()
    return {"ok": True}


@router.post("/join")
async def join(data: JoinIn, user=Depends(current_user)):
    ch = await run_in_threadpool(svc.join, user, data.username, data.password)
    await manager.send_to(user["id"], {"type": "channels_changed"})
    return {"channel": ch}


@router.post("/{cid}/leave")
async def leave(cid: int, user=Depends(current_user)):
    svc.leave(user, cid)
    await manager.send_to(user["id"], {"type": "channels_changed"})
    return {"ok": True}


@router.get("/{cid}/posts")
def posts(cid: int, before: int = 0, limit: int = 0, user=Depends(current_user)):
    items, more = svc.posts(user, cid, before, limit)
    return {"posts": items, "more": more}


@router.post("/{cid}/views")
async def views(cid: int, data: ViewsIn, user=Depends(current_user)):
    ch, changed = svc.mark_viewed(user, cid, data.ids)
    if changed:
        await publish_channel(ch, {"type": "channel_views", "ch": cid, "views": {str(k): v for k, v in changed.items()}})
    return {"ok": True}


@router.get("/{cid}/posts/{pid}/comments")
def comments(cid: int, pid: int, before: int = 0, limit: int = 0, user=Depends(current_user)):
    items, more = svc.comments(user, cid, pid, before, limit)
    return {"comments": items, "more": more}


@router.post("/{cid}/posts/{pid}/comments")
async def add_comment(cid: int, pid: int, data: EnvelopeIn, user=Depends(current_user)):
    ch, comment, count = svc.add_comment(user, cid, pid, data.e2e)
    await publish_channel(ch, {"type": "channel_comment", "ch": cid, "post": pid, "comment": comment, "count": count})
    return {"comment": comment, "count": count}


@router.delete("/{cid}/posts/{pid}/comments/{kid}")
async def delete_comment(cid: int, pid: int, kid: int, user=Depends(current_user)):
    ch, count = svc.delete_comment(user, cid, pid, kid)
    await publish_channel(ch, {"type": "channel_comment_deleted", "ch": cid, "post": pid, "id": kid, "count": count})
    return {"ok": True, "count": count}
