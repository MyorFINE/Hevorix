"""Ovozli qo'ng'iroq uchun ICE serverlar (STUN/TURN). Shifrlangan kanal ichida, faqat kirgan foydalanuvchiga."""
import json
import logging
import urllib.request

from fastapi import APIRouter, Depends
from fastapi.concurrency import run_in_threadpool

from app.api.deps import current_user
from app.config import settings
from app.security import limiter

router = APIRouter(prefix="/api/call", tags=["call"])
log = logging.getLogger("termchat.call")
TTL = 4 * 3600


def _csv(s: str) -> list[str]:
    return [x.strip() for x in s.split(",") if x.strip()]


def _cloudflare() -> list[dict]:
    req = urllib.request.Request(
        f"https://rtc.live.cloudflare.com/v1/turn/keys/{settings.call_turn_key_id}/credentials/generate-ice-servers",
        data=json.dumps({"ttl": TTL}).encode(), method="POST",
        headers={"Authorization": f"Bearer {settings.call_turn_key_token}", "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=6) as r:
        servers = json.loads(r.read().decode()).get("iceServers") or []
    out = []
    for s in servers if isinstance(servers, list) else [servers]:
        urls = [u for u in (s.get("urls") or []) if ":53" not in u]          # brauzerlar 53-portni bloklaydi: kutishni oldini olamiz
        if urls:
            out.append({**s, "urls": urls})
    return out


@router.get("/ice")
async def ice(user=Depends(current_user)):
    limiter.check(f"callice:{user['id']}", 20, 60, "Juda ko'p so'rov")
    servers: list[dict] = []
    stun = _csv(settings.call_stun_urls)
    if stun:
        servers.append({"urls": stun})
    turn = False
    if settings.call_turn_key_id and settings.call_turn_key_token:
        try:
            got = await run_in_threadpool(_cloudflare)
            servers.extend(got)
            turn = any(any(u.startswith(("turn:", "turns:")) for u in s.get("urls", [])) for s in got)
        except Exception:
            log.exception("Cloudflare TURN ma'lumotlarini olib bo'lmadi")
    if not turn and settings.call_turn_urls:
        entry = {"urls": _csv(settings.call_turn_urls)}
        if settings.call_turn_username:
            entry.update(username=settings.call_turn_username, credential=settings.call_turn_credential)
        servers.append(entry)
        turn = True
    return {"iceServers": servers, "turn": turn}
