"""Ovozli qo'ng'iroq uchun ICE serverlar (STUN/TURN). Shifrlangan kanal ichida, faqat kirgan foydalanuvchiga."""
import json
import logging
import re
import urllib.error
import urllib.request

from fastapi import APIRouter, Depends
from fastapi.concurrency import run_in_threadpool

from app.api.deps import current_user
from app.config import settings
from app.security import limiter

router = APIRouter(prefix="/api/call", tags=["call"])
log = logging.getLogger("termchat.call")
TTL = 4 * 3600
CF_BASE = "https://rtc.live.cloudflare.com"
_PORT53 = re.compile(r":53(\?|$)")             # faqat aynan 53-port (":5349" ga tegmaydi)


def _csv(s: str) -> list[str]:
    return [x.strip() for x in s.split(",") if x.strip()]


def _cloudflare() -> list[dict]:
    req = urllib.request.Request(
        f"{CF_BASE}/v1/turn/keys/{settings.call_turn_key_id}/credentials/generate-ice-servers",
        data=json.dumps({"ttl": TTL}).encode(), method="POST",
        headers={"Authorization": f"Bearer {settings.call_turn_key_token}", "Content-Type": "application/json", "Accept": "application/json",
                 "User-Agent": "Mozilla/5.0 (compatible; AnonimChat/1.0)"})        # "Python-urllib" nomi Cloudflare tomonidan ba'zan 403 bilan rad etiladi
    with urllib.request.urlopen(req, timeout=6) as r:
        servers = json.loads(r.read().decode()).get("iceServers") or []
    out = []
    for s in servers if isinstance(servers, list) else [servers]:
        urls = [u for u in (s.get("urls") or []) if not _PORT53.search(u)]          # brauzerlar 53-portni bloklaydi: kutishni oldini olamiz
        if urls:
            out.append({**s, "urls": urls})
    return out


@router.get("/ice")
async def ice(user=Depends(current_user)):
    limiter.check(f"callice-http:{user['id']}", 20, 60, "Juda ko'p so'rov")
    servers: list[dict] = []
    stun = _csv(settings.call_stun_urls)
    if stun:
        servers.append({"urls": stun})
    turn = False
    why = None                                                   # TURN nega yo'qligi (maxfiy emas): mijoz ekranida ko'rsatiladi
    if settings.call_turn_key_id and settings.call_turn_key_token:
        try:
            got = await run_in_threadpool(_cloudflare)
            servers.extend(got)
            turn = any(any(u.startswith(("turn:", "turns:")) for u in s.get("urls", [])) for s in got)
            if not turn:
                why = "Cloudflare javobida TURN manzillari yo'q"
        except urllib.error.HTTPError as e:
            why = f"Cloudflare HTTP {e.code}" + (" (KEY_ID yoki TOKEN noto'g'ri)" if e.code in (400, 401, 403, 404) else "")
            log.error("Cloudflare TURN javobi: HTTP %s (KEY_ID yoki TOKEN noto'g'ri bo'lishi mumkin)", e.code)
        except Exception as e:
            why = "Cloudflare'ga ulanib bo'lmadi: " + type(e).__name__
            log.exception("Cloudflare TURN ma'lumotlarini olib bo'lmadi")
    else:
        why = "serverda CALL_TURN_KEY_ID / CALL_TURN_KEY_TOKEN bo'sh"
        log.warning("CALL_TURN_KEY_ID / CALL_TURN_KEY_TOKEN bo'sh: TURN o'chiq")
    if not turn and settings.call_turn_urls:
        entry = {"urls": _csv(settings.call_turn_urls)}
        if settings.call_turn_username:
            entry.update(username=settings.call_turn_username, credential=settings.call_turn_credential)
        servers.append(entry)
        turn = True
        why = None
    return {"iceServers": servers, "turn": turn, "why": why}
