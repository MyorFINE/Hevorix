from typing import Any, Optional

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel

from app.api.deps import admin_user, client_ip, current_user
from app.realtime.manager import manager
from app.services import activity, missions as svc, views

router = APIRouter(prefix="/api/missions", tags=["missions"])


class StartIn(BaseModel):
    game: str = "chess"
    level: int
    side: str


class SubmitIn(BaseModel):
    game: str = "chess"
    token: str
    moves: list[str]
    hints: int = 0
    undos: int = 0


class ItemIn(BaseModel):
    item_id: int


@router.get("")
def my_missions(user=Depends(current_user)):
    return svc.overview(user["id"])


@router.post("/start")
def start(data: StartIn, user=Depends(current_user)):
    return svc.start_game(user, data.game, data.level, data.side)


@router.post("/submit")
async def submit(data: SubmitIn, request: Request, user=Depends(current_user)):
    if data.game not in ("chess", "checkers"):
        return {"counted": False, "reason": "Bunday o'yin yo'q", "gained": 0, "total": 0, "granted": []}
    res = svc.submit_chess(user, data.token, data.moves, data.hints, data.undos, data.game)
    if res.get("counted"):
        activity.record("mission", ip=client_ip(request), user=user,
                        detail=f"{'shashka' if data.game == 'checkers' else 'shaxmat'} missiya: +{res['gained']} ochko (jami {res['total']})")
    for g in res.get("granted", []):
        activity.record("mission", ip=client_ip(request), user=user, detail="sovg'a ochildi: " + g["pack"]["name"])
    return res


@router.get("/inventory")
def my_inventory(user=Depends(current_user)):
    return svc.inventory(user["id"])


async def _changed(user):
    view = views.user_view(user["id"])
    await manager.broadcast({"type": "user_update", "user": view})
    return {"ok": True, "user": view, **svc.inventory(user["id"])}


@router.post("/inventory/equip")
async def equip(data: ItemIn, request: Request, user=Depends(current_user)):
    svc.equip(user, data.item_id)
    activity.record("profile", ip=client_ip(request), user=user, detail="inventardan kiydi")
    return await _changed(user)


@router.post("/inventory/unequip")
async def unequip(data: ItemIn, request: Request, user=Depends(current_user)):
    svc.unequip(user, data.item_id)
    activity.record("profile", ip=client_ip(request), user=user, detail="inventarga qaytardi")
    return await _changed(user)


# ---------------- admin: missiya paneli ----------------
class PackIn(BaseModel):
    id: Optional[int] = None
    name: str
    emoji: str = "🎁"
    descr: str = ""
    items: list[dict[str, Any]]


class RuleIn(BaseModel):
    game: str
    rule: str
    points: int
    daily_cap: int = 0


class RewardIn(BaseModel):
    id: Optional[int] = None
    game: str
    title: str
    need: int
    pack_id: int
    active: bool = True


class IdIn(BaseModel):
    id: int


class StrictIn(BaseModel):
    on: bool


@router.get("/admin")
def admin_get(admin=Depends(admin_user)):
    return svc.admin_overview()


@router.post("/admin/pack")
def admin_pack(data: PackIn, request: Request, admin=Depends(admin_user)):
    p = svc.pack_save(admin, data.id, data.name, data.emoji, data.descr, data.items)
    activity.record("mission", ip=client_ip(request), user=admin, detail=("paket saqlandi: " + p["name"])[:200])
    return {"ok": True, "pack": p}


@router.post("/admin/pack/delete")
def admin_pack_delete(data: IdIn, request: Request, admin=Depends(admin_user)):
    svc.pack_remove(data.id)
    activity.record("mission", ip=client_ip(request), user=admin, detail=f"paket o'chirildi #{data.id}")
    return {"ok": True}


@router.post("/admin/rule")
def admin_rule(data: RuleIn, request: Request, admin=Depends(admin_user)):
    rules = svc.rule_set(data.game, data.rule, data.points, data.daily_cap)
    activity.record("mission", ip=client_ip(request), user=admin, detail=f"ochko: {data.game}/{data.rule} = {data.points}")
    return {"ok": True, "rules": rules}


@router.post("/admin/reward")
def admin_reward(data: RewardIn, request: Request, admin=Depends(admin_user)):
    r = svc.reward_save(data.id, data.game, data.title, data.need, data.pack_id, data.active)
    activity.record("mission", ip=client_ip(request), user=admin, detail=f"missiya saqlandi: {r['title']} ({r['need']} ochko)"[:200])
    return {"ok": True, "reward": r}


@router.post("/admin/reward/delete")
def admin_reward_delete(data: IdIn, request: Request, admin=Depends(admin_user)):
    svc.reward_remove(data.id)
    activity.record("mission", ip=client_ip(request), user=admin, detail=f"missiya o'chirildi #{data.id}")
    return {"ok": True}


@router.post("/admin/strict")
def admin_strict(data: StrictIn, request: Request, admin=Depends(admin_user)):
    svc.set_strict(data.on)
    activity.record("mission", ip=client_ip(request), user=admin,
                    detail="maslahat/orqaga ochkoni bekor qiladi: " + ("ha" if data.on else "yo'q"))
    return {"ok": True, "strict": svc.strict()}
