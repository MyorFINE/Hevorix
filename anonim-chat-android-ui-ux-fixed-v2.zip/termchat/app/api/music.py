from fastapi import APIRouter, Depends, File, Form, Request, UploadFile
from fastapi.concurrency import run_in_threadpool
from fastapi.responses import Response
from pydantic import BaseModel, Field

from app.api.deps import admin_user, client_ip, current_user
from app.config import settings
from app.errors import ChatError
from app.realtime.manager import manager
from app.repositories import users as users_repo
from app.security import limiter
from app.services import activity, music

router = APIRouter(prefix="/api", tags=["music"])


async def _changed(uid: int) -> None:
    await manager.broadcast({"type": "music_update", "uid": uid})


class EditIn(BaseModel):
    title: str = Field("", max_length=120)
    artist: str = Field("", max_length=80)


class LimitIn(BaseModel):
    user_id: int | None = None
    limit: int | None = Field(None, ge=0, le=music.MAX_LIMIT)


@router.get("/music/user/{uid}")
def user_music(uid: int, user=Depends(current_user)):
    t = users_repo.get(uid)
    if not t or t["deleted"]:
        return {"tracks": [], "limit": 0, "used": 0, "max_bytes": settings.max_music_bytes}
    return music.listing(uid)


@router.post("/music")
async def upload_music(request: Request, file: UploadFile = File(...), title: str = Form(""), artist: str = Form(""),
                       duration: float = Form(0), user=Depends(current_user)):
    limiter.check(f"music:{user['id']}", 8, 60, "Juda tez-tez yuklayapsiz, biroz kuting")
    raw = await file.read(settings.max_music_bytes + 1)
    track = await run_in_threadpool(music.upload, user, raw, title, artist, duration, file.filename or "")
    await _changed(user["id"])
    activity.record("music", ip=client_ip(request), user=user, detail=f"qo'shdi: {track['title'][:60]}")
    return {"ok": True, "track": track, **music.listing(user["id"])}


@router.get("/music/{track_id}/file")
async def music_file(track_id: int, user=Depends(current_user)):
    data, t = await run_in_threadpool(music.read, track_id)
    return Response(content=data, media_type=t["mime"],
                    headers={"Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff"})


@router.patch("/music/{track_id}")
async def edit_music(track_id: int, data: EditIn, user=Depends(current_user)):
    track = music.edit(user, track_id, data.title, data.artist)
    await _changed(track["uid"])
    return {"ok": True, "track": track}


@router.delete("/music/{track_id}")
async def delete_music(track_id: int, request: Request, user=Depends(current_user)):
    uid = await run_in_threadpool(music.remove, user, track_id)
    await _changed(uid)
    activity.record("music", ip=client_ip(request), user=user, detail=f"o'chirdi #{track_id}")
    return {"ok": True, **music.listing(uid)}


@router.get("/admin/music-limit")
def get_limit(admin=Depends(admin_user)):
    return {"default": music.default_limit(), "max": music.MAX_LIMIT}


@router.get("/admin/music-limit/{uid}")
def get_user_limit(uid: int, admin=Depends(admin_user)):
    return {"user_id": uid, "limit": music.limit_for(uid), "default": music.default_limit(), "used": len(music.music.list_for_user(uid))}


@router.post("/admin/music-limit")
async def set_limit(data: LimitIn, request: Request, admin=Depends(admin_user)):
    if data.user_id is None and data.limit is None:
        raise ChatError("Limitni kiriting")
    res = music.set_limit(admin, data.user_id, data.limit)
    who = "hamma uchun sukut" if data.user_id is None else f"user #{data.user_id}"
    activity.record("music", ip=client_ip(request), user=admin, detail=f"limit ({who}): {data.limit if data.limit is not None else 'sukutga qaytdi'}")
    return res
