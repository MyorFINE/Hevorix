import asyncio
import json
import logging
import time
from urllib.parse import urlsplit

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from app.commands import Ctx, dispatch
from app.config import settings
from app.constants import WS_FORBIDDEN, WS_IDLE, WS_IP_BLOCKED, WS_REKEY, WS_UNAUTHORIZED
from app.errors import ChatError
from app.netutil import real_ip
from app.realtime.events import deliver, publish_deleted, publish_edited, publish_reaction
from app.realtime.manager import manager
from app.repositories import users as users_repo
from app.security import hash_token, limiter
from app.services import activity, auth, chat, ipblock, modsettings, views, webpush
from app.services import pins as pins_svc
from app.services import privacy
from app.services import reactions as reactions_svc
from app.services import channels as channels_svc
from app.services import games as games_svc
from app.transport import FrameTooBig, SecureWS, store

router = APIRouter()
log = logging.getLogger("termchat.ws")
ACTIVE_KINDS = {"send", "edit", "delete", "pin", "delete_many", "delete_dm", "clear_chat", "cmd", "game_move", "game_invite", "game_reply", "game_resign", "game_bot", "game_undo"}
MAX_CONN_PER_USER = 10
FRAME_RATE = (150, 10)
CMD_RATE = (20, 10)
TYPING_RATE = (14, 10)
TYPING_KINDS = {"text", "file", "emoji", "voice", "vnote", "stop"}
WS_TRY_LATER = 1013

SEEN_TTL = 900
SEEN_MAX = 20000
_SEEN: dict[tuple[int, str], tuple[float, dict | None]] = {}


def _seen_purge(now: float) -> None:
    if len(_SEEN) < SEEN_MAX // 2 and len(_SEEN) % 64:
        return
    for k in [k for k, (ts, _) in _SEEN.items() if now - ts > SEEN_TTL]:
        _SEEN.pop(k, None)
    while len(_SEEN) > SEEN_MAX:
        _SEEN.pop(next(iter(_SEEN)), None)


def _cid(data: dict):
    cid = data.get("cid")
    return cid if isinstance(cid, str) and 8 <= len(cid) <= 64 and cid.isascii() and cid.isprintable() else None
WS_TOO_BIG = 1009


def _parse(raw: str) -> dict:
    try:
        data = json.loads(raw)
    except ValueError:
        return {}
    return data if isinstance(data, dict) else {}


def _int(v):
    return v if isinstance(v, int) and not isinstance(v, bool) else None


def _stamp(uid: int) -> float:
    ts = time.time()
    try:
        users_repo.touch_seen(uid, ts)
    except Exception:
        log.exception("last_seen yozilmadi (uid=%s)", uid)
    return ts


def _snippet(text: str, n: int = 100) -> str:
    return " ".join(text.split())[:n]


async def _handle(user, data: dict, token_hash: str, ip: str) -> None:
    kind = data.get("type") or "send"
    text = data.get("text")
    text = text.strip() if isinstance(text, str) else ""
    cid = _cid(data) if kind == "send" else None
    ckey = None
    try:
        if cid:
            ckey = (user["id"], cid)
            now = time.time()
            hit = _SEEN.get(ckey)
            if hit is not None:
                if hit[1] is not None:
                    await manager.send_to(user["id"], {**hit[1], "cid": cid})
                return
            _SEEN[ckey] = (now, None)
            _seen_purge(now)
        if kind == "send":
            to = _int(data.get("to"))
            if data.get("to") is not None and to is None:
                raise ChatError("Qabul qiluvchi noto'g'ri ko'rsatilgan")
            env = data.get("e2e")
            ch_id = _int(data.get("ch"))
            if data.get("ch") is not None:
                if ch_id is None or to is not None or not isinstance(env, str):
                    raise ChatError("Kanalga post shifrlangan bo'lishi kerak")
                ch = channels_svc.get_visible(ch_id, user)
                blob = data.get("blob")
                message = chat.post_channel_e2e(user, ch, env, blob if isinstance(blob, str) else None)
                if ckey:
                    _SEEN[ckey] = (time.time(), message)
                await deliver({"recipient_id": None, "user_id": user["id"], "channel_id": ch_id}, message)
                webpush.fire_channel(ch, message, user["id"])
                activity.record("chpost", ip=ip, user=user)
                return
            if isinstance(env, str):
                blob = data.get("blob")
                message = chat.post_e2e(user, env, to, blob if isinstance(blob, str) else None)
                if ckey:
                    _SEEN[ckey] = (time.time(), message)
                await deliver({"recipient_id": message["to"], "user_id": user["id"]}, message)
                webpush.fire(message, user["id"])
                activity.record("msg" if to is None else "dm", ip=ip, user=user)
                return
            if not text:
                return
            message = chat.post(user, text, to, _int(data.get("reply_to")))
            row = {"recipient_id": message["to"], "user_id": user["id"]}
            await deliver(row, message)
            webpush.fire(message, user["id"])
            if to is None:
                activity.record("msg", ip=ip, user=user, detail=_snippet(text))
            else:
                activity.record("dm", ip=ip, user=user)
        elif kind == "edit":
            env = data.get("e2e")
            if isinstance(env, str):
                msg, new_env = chat.edit_e2e(user, _int(data.get("id")) or 0, env)
                await publish_edited(msg, new_env, e2e=True)
                activity.record("edit", ip=ip, user=user, detail=f"#{msg['id']}" if msg["recipient_id"] is None else "lichkada")
                return
            msg, new_text = chat.edit(user, _int(data.get("id")) or 0, text)
            await publish_edited(msg, new_text)
            if msg["recipient_id"] is None:
                activity.record("edit", ip=ip, user=user,
                                detail=f"#{msg['id']}: {_snippet(msg['content'], 60)} → {_snippet(new_text, 60)}")
            else:
                activity.record("edit", ip=ip, user=user, detail="lichkada")
        elif kind == "react":
            emoji = data.get("emoji")
            if emoji is not None and not isinstance(emoji, str):
                raise ChatError("Bunday reaksiya yo'q")
            msg, rx = reactions_svc.react(user, _int(data.get("id")) or 0, emoji)
            await publish_reaction(msg, rx)
        elif kind == "pin":
            on = data.get("on") is not False
            both = data.get("both") is True
            msg, shared = pins_svc.set_pin(user, data.get("id"), on, both)
            if shared:
                await manager.broadcast({"type": "pins_changed", "scope": "g", "id": msg["id"], "on": on})
                activity.record("pin" if on else "unpin", ip=ip, user=user, detail=f"#{msg['id']}")
            else:
                partner = msg["recipient_id"] if msg["user_id"] == user["id"] else msg["user_id"]
                await manager.send_to(user["id"], {"type": "pins_changed", "scope": "d", "with": partner, "id": msg["id"], "on": on})
                if both and partner != user["id"]:
                    await manager.send_to(partner, {"type": "pins_changed", "scope": "d", "with": user["id"], "id": msg["id"], "on": on})
        elif kind == "delete":
            msg = chat.delete(user, _int(data.get("id")) or 0)
            await publish_deleted(msg)
            if msg["recipient_id"] is None:
                own = msg["user_id"] == user["id"]
                activity.record("delete", ip=ip, user=user,
                                detail=f"#{msg['id']}" + ("" if own else f" (egasi id={msg['user_id']})")
                                + ("" if msg["e2e"] else f": {_snippet(msg['content'], 80)}"))
            else:
                activity.record("delete", ip=ip, user=user, detail="lichkada")
        elif kind == "delete_many":
            raw_ids = data.get("ids")
            if not isinstance(raw_ids, list):
                return
            ids = [i for i in (_int(x) for x in raw_ids[: chat.MAX_BULK_DELETE]) if i]
            done, skipped = chat.delete_many(user, ids)
            for msg in done:
                await publish_deleted(msg)
            if done:
                activity.record("delete", ip=ip, user=user, detail=f"{len(done)} ta xabar birdaniga o'chirildi")
            if skipped:
                await manager.system(user["id"], f"{skipped} ta xabar o'chirilmadi (ruxsat yo'q)", "warn")
        elif kind == "delete_dm":
            partner = _int(data.get("with"))
            if partner is None:
                raise ChatError("Suhbat topilmadi")
            n = chat.delete_dm(user, partner)
            await manager.send_many([user["id"], partner], {"type": "dm_cleared", "a": user["id"], "b": partner})
            activity.record("dm_clear", ip=ip, user=user, detail=f"{n} ta xabar")
        elif kind == "clear_chat":
            n = chat.clear_group(user)
            await manager.broadcast({"type": "chat_cleared", "by": user["id"], "count": n})
            activity.record("clear", ip=ip, user=user, detail=f"umumiy chat tozalandi ({n} ta xabar)")
        elif kind == "read":
            partner = _int(data.get("with"))
            if partner is not None and chat.mark_read(user, partner):
                await manager.send_to(partner, {"type": "read", "by": user["id"]})
        elif isinstance(kind, str) and kind.startswith("game_"):
            await games_svc.handle(user, data)
        elif kind == "cmd":
            limiter.check(f"cmd:{user['id']}", CMD_RATE[0], CMD_RATE[1], "Buyruqlar juda tez yuborilmoqda")
            if text.startswith("/"):
                await dispatch(Ctx.parse(user, text[:2000], token_hash, ip))
    except ChatError as e:
        if cid:
            await manager.send_to(user["id"], {"type": "nack", "cid": cid, "final": True})
        await manager.system(user["id"], e.message, "error")
    except Exception:
        log.exception("WebSocket amali xatosi (uid=%s, type=%s)", user["id"], kind)
        if cid:
            _SEEN.pop(ckey, None)
            await manager.send_to(user["id"], {"type": "nack", "cid": cid, "final": False})
        else:
            await manager.system(user["id"], "Server xatosi, qayta urinib ko'ring", "error")


def _origin_ok(raw: WebSocket) -> bool:
    origin = raw.headers.get("origin")
    if not origin:
        return True
    host = (raw.headers.get("host") or "").split(":")[0].lower()
    return (urlsplit(origin).hostname or "").lower() == host


@router.websocket("/ws")
async def chat_socket(raw: WebSocket):
    await raw.accept()
    if not _origin_ok(raw):
        return await raw.close(WS_FORBIDDEN)
    ip = real_ip(raw.headers, raw.client)
    if ipblock.is_blocked(ip):
        return await raw.close(WS_IP_BLOCKED)
    sess = store.get(raw.query_params.get("k", ""))
    if sess is None:
        return await raw.close(WS_REKEY)
    ws = SecureWS(raw, sess)
    try:
        token = str(_parse(await asyncio.wait_for(ws.receive_text(), 10)).get("a") or "")
    except WebSocketDisconnect:
        return
    except Exception:
        return await raw.close(WS_UNAUTHORIZED)
    user = auth.authenticate(token)
    if not user:
        return await raw.close(WS_UNAUTHORIZED)
    if user["banned"]:
        return await raw.close(WS_FORBIDDEN)

    uid, token_hash = user["id"], hash_token(token)
    if manager.connection_count(uid) >= MAX_CONN_PER_USER:
        return await raw.close(WS_TRY_LATER)
    manager.set_hidden(uid, privacy.is_ghost(uid))
    first = manager.connect(uid, ws, ip)
    if first:
        activity.record("session", ip=ip, user=user)
    away_task: asyncio.Task | None = None

    async def _set_away(away: bool) -> None:
        if manager.set_away(uid, ws, away):
            ts = _stamp(uid) if away else None
            if manager.is_hidden(uid):
                return
            await manager.broadcast({"type": "presence", "uid": uid, "online": not away, "ts": ts}, exclude_uid=uid)

    async def _typing(data: dict) -> None:
        k = data.get("kind")
        if k not in TYPING_KINDS or not limiter.allow(f"typing:{uid}", TYPING_RATE[0], TYPING_RATE[1]):
            return
        to = _int(data.get("to"))
        if data.get("to") is not None and to is None:
            return
        if manager.is_hidden(uid):
            return
        frame = {"type": "typing", "uid": uid, "kind": k, "group": to is None}
        if to is None:
            await manager.broadcast(frame, exclude_uid=uid)
        else:
            await manager.send_to(to, frame)

    async def _away_later() -> None:
        await asyncio.sleep(settings.away_grace)
        await _set_away(True)

    try:
        history, more = chat.history_page()
        await ws.send_text(json.dumps({"type": "init", "me": views.user_view(uid), "history": history, "more": more,
                                       "online_ids": manager.online_ids(uid), "chat": modsettings.public()}))
        if first and not manager.is_hidden(uid):
            await manager.broadcast({"type": "presence", "uid": uid, "online": True}, exclude_uid=uid)
        while True:
            try:
                raw_frame = await asyncio.wait_for(ws.receive_text(), settings.ws_idle_timeout)
            except asyncio.TimeoutError:
                await ws.close(WS_IDLE)
                break
            data = _parse(raw_frame)
            if not data:
                continue
            if not limiter.allow(f"wsframe:{uid}", FRAME_RATE[0], FRAME_RATE[1]):
                continue
            if ipblock.is_blocked(ip):
                await ws.close(WS_IP_BLOCKED)
                break
            kind = data.get("type")
            idle = data.get("i")
            active = kind in ACTIVE_KINDS or (kind == "ping" and isinstance(idle, (int, float)) and 0 <= idle < 60)
            user = auth.authenticate(token, active=active)
            if not user:
                await ws.close(WS_UNAUTHORIZED)
                break
            if user["banned"]:
                await ws.close(WS_FORBIDDEN)
                break
            if kind == "ping":
                await ws.send_text('{"type":"pong"}')
            elif kind == "typing":
                await _typing(data)
            elif kind == "away":
                if user["role"] == "owner":
                    continue
                if away_task is None or away_task.done():
                    away_task = asyncio.create_task(_away_later())
            elif kind == "back":
                if away_task is not None:
                    away_task.cancel()
                    away_task = None
                await _set_away(False)
            else:
                await _handle(user, data, token_hash, ip)
    except WebSocketDisconnect:
        pass
    except FrameTooBig:
        try:
            await raw.close(WS_TOO_BIG)
        except Exception:
            pass
    except (ValueError, KeyError):
        try:
            await raw.close(WS_UNAUTHORIZED)
        except Exception:
            pass
    except Exception:
        log.exception("WebSocket xatosi (uid=%s)", uid)
    finally:
        if away_task is not None:
            away_task.cancel()
        if manager.disconnect(uid, ws):
            ts_off = _stamp(uid)
            if not manager.is_hidden(uid):
                await manager.broadcast({"type": "presence", "uid": uid, "online": False, "ts": ts_off})
