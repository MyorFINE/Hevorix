"""Chat WebSocket: /ws?k=<kid>. Barcha kadrlar shifrlangan (app.transport.SecureWS).

Birinchi kadr (mijoz -> server): {"a": "<token>"}; keyin quyidagi xabarlar:

Mijoz -> server (JSON):
  {"type": "send",   "text": "...", "to": <user_id>?, "reply_to": <message_id>?}   to yo'q bo'lsa umumiy chatga
  {"type": "send",   "e2e": "<konvert>", "blob": "<fayl>"?, "ch": <kanal_id>}      kanalga E2EE post (faqat adminlar)
  {"type": "edit",   "id": 12, "text": "..."}
  {"type": "delete", "id": 12}
  {"type": "react",  "id": 12, "emoji": "❤️"}           reaksiya (bir xil emoji qayta — olib tashlaydi); "emoji": null — olib tashlash
  {"type": "delete_many", "ids": [1, 2, 3]}          belgilangan xabarlarni birdaniga o'chirish
  {"type": "delete_dm", "with": <user_id>}           shaxsiy suhbatni ikki tomon uchun o'chirish
  {"type": "clear_chat"}                              umumiy chatni tozalash (faqat admin/ega)
  {"type": "read",   "with": <user_id>}                  shaxsiy suhbatni o'qilgan deb belgilash
  {"type": "cmd",    "text": "/mute user 10"}            moderatsiya (admin tugmalari ishlatadi)
  {"type": "ping",   "i": <soniya>}                      yurak urishi (har ~15 s): `i` — foydalanuvchi oxirgi marta tegganiga necha soniya bo'ldi
  {"type": "away"} / {"type": "back"}                    sahifa yashirildi (boshqa sahifa, ilova, ekran o'chdi) / qaytdi -> oflayn/onlayn

Server -> mijoz: `pong` (ping javobi). Ping'dan ham, boshqa kadrdan ham `ws_idle_timeout` soniya hech narsa kelmasa, ulanish o'lgan
hisoblanadi (qurilma o'chdi, tarmoq uzildi) va foydalanuvchi darhol OFLAYN bo'ladi.
"""
import asyncio
import json
import logging
from urllib.parse import urlsplit

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from app.commands import Ctx, dispatch
from app.config import settings
from app.constants import WS_FORBIDDEN, WS_IDLE, WS_IP_BLOCKED, WS_REKEY, WS_UNAUTHORIZED
from app.errors import ChatError
from app.netutil import real_ip
from app.realtime.events import deliver, publish_deleted, publish_edited, publish_reaction
from app.realtime.manager import manager
from app.security import hash_token, limiter
from app.services import activity, auth, chat, ipblock, modsettings, views, webpush
from app.services import reactions as reactions_svc
from app.services import channels as channels_svc
from app.transport import FrameTooBig, SecureWS, store

router = APIRouter()
log = logging.getLogger("termchat.ws")
ACTIVE_KINDS = {"send", "edit", "delete", "delete_many", "delete_dm", "clear_chat", "cmd"}
MAX_CONN_PER_USER = 10          # bitta akkauntdan bir vaqtda ochiq WebSocket'lar soni (ortig'i 1013 bilan rad etiladi)
FRAME_RATE = (150, 10)          # (kadr soni, soniya): ping/away/back ham kiradi; oddiy foydalanishdan ancha yuqori
CMD_RATE = (20, 10)             # moderatsiya buyruqlari
WS_TRY_LATER = 1013
WS_TOO_BIG = 1009


def _parse(raw: str) -> dict:
    try:
        data = json.loads(raw)
    except ValueError:
        return {}
    return data if isinstance(data, dict) else {}


def _int(v):
    return v if isinstance(v, int) and not isinstance(v, bool) else None


def _snippet(text: str, n: int = 100) -> str:
    return " ".join(text.split())[:n]


async def _handle(user, data: dict, token_hash: str, ip: str) -> None:
    kind = data.get("type") or "send"
    text = data.get("text")
    text = text.strip() if isinstance(text, str) else ""
    try:
        if kind == "send":
            to = _int(data.get("to"))
            if data.get("to") is not None and to is None:
                raise ChatError("Qabul qiluvchi noto'g'ri ko'rsatilgan")
            env = data.get("e2e")
            ch_id = _int(data.get("ch"))
            if data.get("ch") is not None:           # kanalga post: faqat adminlar, faqat E2EE (matn, rasm, fayl, ovoz, dumaloq video)
                if ch_id is None or to is not None or not isinstance(env, str):
                    raise ChatError("Kanalga post shifrlangan bo'lishi kerak")
                ch = channels_svc.get_visible(ch_id, user)
                blob = data.get("blob")
                message = chat.post_channel_e2e(user, ch, env, blob if isinstance(blob, str) else None)
                await deliver({"recipient_id": None, "user_id": user["id"], "channel_id": ch_id}, message)
                webpush.fire_channel(ch, message, user["id"])
                activity.record("chpost", ip=ip, user=user)                      # post mazmuni logga YOZILMAYDI
                return
            if isinstance(env, str):                  # E2EE: server faqat shifrlangan konvertni ko'radi
                blob = data.get("blob")
                message = chat.post_e2e(user, env, to, blob if isinstance(blob, str) else None)
                await deliver({"recipient_id": message["to"], "user_id": user["id"]}, message)
                webpush.fire(message, user["id"])         # oflayn (brauzer yopiq) qabul qiluvchilarga push
                activity.record("msg" if to is None else "dm", ip=ip, user=user)     # matn/mazmun logga YOZILMAYDI
                return
            if not text:
                return
            message = chat.post(user, text, to, _int(data.get("reply_to")))        # E2EE majburiy bo'lsa, bu yerda xato beradi
            row = {"recipient_id": message["to"], "user_id": user["id"]}
            await deliver(row, message)
            webpush.fire(message, user["id"])
            if to is None:
                activity.record("msg", ip=ip, user=user, detail=_snippet(text))
            else:                                   # shaxsiy xabar matni va qabul qiluvchisi yozilmaydi
                activity.record("dm", ip=ip, user=user)
        elif kind == "edit":
            env = data.get("e2e")
            if isinstance(env, str):
                msg, new_env = chat.edit_e2e(user, _int(data.get("id")) or 0, env)
                await publish_edited(msg, new_env, e2e=True)
                activity.record("edit", ip=ip, user=user, detail=f"#{msg['id']}" if msg["recipient_id"] is None else "lichkada")
                return
            msg, new_text = chat.edit(user, _int(data.get("id")) or 0, text)
            await publish_edited(msg, new_text)
            if msg["recipient_id"] is None:
                activity.record("edit", ip=ip, user=user,
                                detail=f"#{msg['id']}: {_snippet(msg['content'], 60)} → {_snippet(new_text, 60)}")
            else:
                activity.record("edit", ip=ip, user=user, detail="lichkada")
        elif kind == "react":
            emoji = data.get("emoji")
            if emoji is not None and not isinstance(emoji, str):
                raise ChatError("Bunday reaksiya yo'q")
            msg, rx = reactions_svc.react(user, _int(data.get("id")) or 0, emoji)
            await publish_reaction(msg, rx)
        elif kind == "delete":
            msg = chat.delete(user, _int(data.get("id")) or 0)
            await publish_deleted(msg)
            if msg["recipient_id"] is None:
                own = msg["user_id"] == user["id"]
                activity.record("delete", ip=ip, user=user,
                                detail=f"#{msg['id']}" + ("" if own else f" (egasi id={msg['user_id']})")
                                + ("" if msg["e2e"] else f": {_snippet(msg['content'], 80)}"))
            else:
                activity.record("delete", ip=ip, user=user, detail="lichkada")
        elif kind == "delete_many":
            raw_ids = data.get("ids")
            if not isinstance(raw_ids, list):
                return
            ids = [i for i in (_int(x) for x in raw_ids[: chat.MAX_BULK_DELETE]) if i]
            done, skipped = chat.delete_many(user, ids)
            for msg in done:
                await publish_deleted(msg)
            if done:
                activity.record("delete", ip=ip, user=user, detail=f"{len(done)} ta xabar birdaniga o'chirildi")
            if skipped:
                await manager.system(user["id"], f"{skipped} ta xabar o'chirilmadi (ruxsat yo'q)", "warn")
        elif kind == "delete_dm":
            partner = _int(data.get("with"))
            if partner is None:
                raise ChatError("Suhbat topilmadi")
            n = chat.delete_dm(user, partner)
            await manager.send_many([user["id"], partner], {"type": "dm_cleared", "a": user["id"], "b": partner})
            activity.record("dm_clear", ip=ip, user=user, detail=f"{n} ta xabar")
        elif kind == "clear_chat":
            n = chat.clear_group(user)
            await manager.broadcast({"type": "chat_cleared", "by": user["id"], "count": n})
            activity.record("clear", ip=ip, user=user, detail=f"umumiy chat tozalandi ({n} ta xabar)")
        elif kind == "read":
            partner = _int(data.get("with"))
            if partner is not None and chat.mark_read(user, partner):
                await manager.send_to(partner, {"type": "read", "by": user["id"]})
        elif kind == "cmd":
            limiter.check(f"cmd:{user['id']}", CMD_RATE[0], CMD_RATE[1], "Buyruqlar juda tez yuborilmoqda")
            if text.startswith("/"):
                await dispatch(Ctx.parse(user, text[:2000], token_hash, ip))
    except ChatError as e:
        await manager.system(user["id"], e.message, "error")
    except Exception:                                    # kutilmagan xato (masalan, baza): ulanish uzilmaydi, foydalanuvchi xabar oladi
        log.exception("WebSocket amali xatosi (uid=%s, type=%s)", user["id"], kind)
        await manager.system(user["id"], "Server xatosi, qayta urinib ko'ring", "error")


def _origin_ok(raw: WebSocket) -> bool:
    """Boshqa saytdan WebSocket ochishga urinishni (CSWSH) rad etadi."""
    origin = raw.headers.get("origin")
    if not origin:
        return True                                   # brauzer bo'lmagan mijoz
    host = (raw.headers.get("host") or "").split(":")[0].lower()
    return (urlsplit(origin).hostname or "").lower() == host


@router.websocket("/ws")
async def chat_socket(raw: WebSocket):
    await raw.accept()
    if not _origin_ok(raw):
        return await raw.close(WS_FORBIDDEN)
    ip = real_ip(raw.headers, raw.client)
    if ipblock.is_blocked(ip):
        return await raw.close(WS_IP_BLOCKED)
    sess = store.get(raw.query_params.get("k", ""))
    if sess is None:
        return await raw.close(WS_REKEY)
    ws = SecureWS(raw, sess)
    try:                                              # birinchi shifrlangan kadr: token
        token = str(_parse(await asyncio.wait_for(ws.receive_text(), 10)).get("a") or "")
    except WebSocketDisconnect:
        return
    except Exception:
        return await raw.close(WS_UNAUTHORIZED)
    ua = raw.headers.get("user-agent", "")
    user = auth.authenticate(token, ua=ua)
    if not user:
        return await raw.close(WS_UNAUTHORIZED)
    if user["banned"]:
        return await raw.close(WS_FORBIDDEN)

    uid, token_hash = user["id"], hash_token(token)
    if manager.connection_count(uid) >= MAX_CONN_PER_USER:
        return await raw.close(WS_TRY_LATER)
    first = manager.connect(uid, ws, ip)
    if first:
        activity.record("session", ip=ip, user=user)
    away_task: asyncio.Task | None = None

    async def _set_away(away: bool) -> None:
        if manager.set_away(uid, ws, away):
            await manager.broadcast({"type": "presence", "uid": uid, "online": not away}, exclude_uid=uid)

    async def _away_later() -> None:               # qisqa almashtirishda (1-2 s) onlayn/oflayn miltillamasligi uchun biroz kutamiz
        await asyncio.sleep(settings.away_grace)
        await _set_away(True)

    try:
        history, more = chat.history_page()
        await ws.send_text(json.dumps({"type": "init", "me": views.user_view(uid), "history": history, "more": more,
                                       "online_ids": manager.online_ids(), "chat": modsettings.public()}))
        if first:
            await manager.broadcast({"type": "presence", "uid": uid, "online": True}, exclude_uid=uid)
        while True:
            try:
                raw_frame = await asyncio.wait_for(ws.receive_text(), settings.ws_idle_timeout)
            except asyncio.TimeoutError:             # yurak urishi to'xtadi: ulanish o'lik (qurilma o'chgan / tarmoq yo'q)
                await ws.close(WS_IDLE)
                break
            data = _parse(raw_frame)
            if not data:
                continue
            if not limiter.allow(f"wsframe:{uid}", FRAME_RATE[0], FRAME_RATE[1]):      # kadrlar toshqini: ortiqchasi e'tiborsiz
                continue
            if ipblock.is_blocked(ip):                   # ulanish ochiq paytda bloklangan bo'lishi mumkin
                await ws.close(WS_IP_BLOCKED)
                break
            kind = data.get("type")
            idle = data.get("i")
            # Faol deb faqat haqiqiy harakatlar va "foydalanuvchi yaqinda tekkan" pinglar sanaladi: sessiya faolsizlikdan tugaydi.
            active = kind in ACTIVE_KINDS or (kind == "ping" and isinstance(idle, (int, float)) and 0 <= idle < 60)
            user = auth.authenticate(token, active=active, ua=ua)   # har safar yangi holat: ban/rol/sessiya/faolsizlik
            if not user:
                await ws.close(WS_UNAUTHORIZED)
                break
            if user["banned"]:
                await ws.close(WS_FORBIDDEN)
                break
            if kind == "ping":
                await ws.send_text('{"type":"pong"}')
            elif kind == "away":
                if user["role"] == "owner":           # Hevorix doim onlayn: ulanishi bor ekan, sahifa yashirilsa ham "away" bo'lmaydi (kalit tarqatuvchi)
                    continue
                if away_task is None or away_task.done():
                    away_task = asyncio.create_task(_away_later())
            elif kind == "back":
                if away_task is not None:
                    away_task.cancel()
                    away_task = None
                await _set_away(False)
            else:
                await _handle(user, data, token_hash, ip)
    except WebSocketDisconnect:
        pass
    except FrameTooBig:                                  # ruxsat etilganidan katta kadr: ulanish uziladi (mijoz qayta ulanadi)
        try:
            await raw.close(WS_TOO_BIG)
        except Exception:
            pass
    except (ValueError, KeyError):                      # shifr/replay xatosi: ulanishni jimgina uzamiz
        try:
            await raw.close(WS_UNAUTHORIZED)
        except Exception:
            pass
    except Exception:
        log.exception("WebSocket xatosi (uid=%s)", uid)
    finally:
        if away_task is not None:
            away_task.cancel()
        if manager.disconnect(uid, ws):
            await manager.broadcast({"type": "presence", "uid": uid, "online": False})
