from __future__ import annotations

import hashlib
import hmac
import secrets
import threading
import time
from collections import defaultdict, deque

from app.errors import ChatError

_LEGACY = (2 ** 14, 8, 1)
_CUR_LOG_N, _CUR_R, _CUR_P = 15, 8, 1
_MAXMEM = 128 * 1024 * 1024
_SCHEME = "s2"


_SCRYPT_SLOTS = threading.BoundedSemaphore(3)


def _scrypt(password: str, salt: bytes, n: int, r: int, p: int) -> bytes:
    with _SCRYPT_SLOTS:
        return hashlib.scrypt(password.encode(), salt=salt, n=n, r=r, p=p, maxmem=_MAXMEM)


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = _scrypt(password, salt, 2 ** _CUR_LOG_N, _CUR_R, _CUR_P)
    return f"{_SCHEME}${_CUR_LOG_N}${_CUR_R}${_CUR_P}${salt.hex()}${digest.hex()}"


def _parse(stored: str) -> tuple[int, int, int, bytes, str]:
    parts = stored.split("$")
    if len(parts) == 2:
        return (*_LEGACY, bytes.fromhex(parts[0]), parts[1])
    scheme, log_n, r, p, salt_hex, digest_hex = parts
    if scheme != _SCHEME:
        raise ValueError("hash formati")
    log_n, r, p = int(log_n), int(r), int(p)
    if not (10 <= log_n <= 20 and 1 <= r <= 16 and 1 <= p <= 4):
        raise ValueError("hash parametrlari")
    return 2 ** log_n, r, p, bytes.fromhex(salt_hex), digest_hex


def verify_password(password: str, stored: str) -> bool:
    try:
        n, r, p, salt, digest_hex = _parse(stored)
        digest = _scrypt(password, salt, n, r, p)
        return hmac.compare_digest(digest.hex(), digest_hex)
    except Exception:
        return False


def valid_hash_shape(stored) -> bool:
    if not isinstance(stored, str) or len(stored) > 200:
        return False
    try:
        _, _, _, salt, digest_hex = _parse(stored)
        return len(salt) == 16 and len(digest_hex) == 128 and bytes.fromhex(digest_hex) is not None
    except Exception:
        return False


def needs_rehash(stored: str) -> bool:
    try:
        n, r, p, _, _ = _parse(stored)
    except Exception:
        return False
    return (n, r, p) != (2 ** _CUR_LOG_N, _CUR_R, _CUR_P)


_DUMMY_HASH = hash_password("dummy-password-for-timing")


def burn_verify(password: str) -> None:
    verify_password(password, _DUMMY_HASH)


def new_token() -> str:
    return secrets.token_urlsafe(32)


def hash_token(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


class RateLimiter:

    def __init__(self) -> None:
        self._hits: dict[str, deque[float]] = defaultdict(deque)

    def allow(self, key: str, limit: int, window: float) -> bool:
        now = time.monotonic()
        q = self._hits[key]
        while q and now - q[0] >= window:
            q.popleft()
        if len(q) >= limit:
            return False
        q.append(now)
        if len(self._hits) > 20000:
            for k in [k for k, v in self._hits.items() if not v or now - v[-1] >= 3600]:
                self._hits.pop(k, None)
        return True

    def check(self, key: str, limit: int, window: float, message: str) -> None:
        if not self.allow(key, limit, window):
            raise ChatError(message, 429)


limiter = RateLimiter()
