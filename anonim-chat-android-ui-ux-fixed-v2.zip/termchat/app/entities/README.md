# entities

Bu qatlam uchun hozirgi kod: app.repositories.users, app.repositories.messages, app.repositories.channels
