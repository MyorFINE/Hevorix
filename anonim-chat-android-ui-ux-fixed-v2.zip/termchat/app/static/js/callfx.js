/* Anonim Chat — jonli ovoz o'zgartirgich (AudioWorklet). Ovozli xabardagidek ovoz balandligi va tembri PASAYADI (qalinlashadi).
   Qo'sh-nuqtali kechikish chizig'i (granular pitch shift): ikki o'quvchi bir-birining yarim davriga siljigan, Hann oynasi bilan aralashadi.
   ratio < 1 => pastroq ovoz. Har qo'ng'iroqda ratio tasodifiy (0.74..0.82) — call.js beradi. Xom mikrofon ovozi tarmoqqa chiqmaydi. */
class VoiceShifter extends AudioWorkletProcessor {
  constructor(o) {
    super();
    const r = o && o.processorOptions && o.processorOptions.ratio;
    this.step = 1 - (typeof r === "number" && r > 0.5 && r < 1.5 ? r : 0.78);
    this.N = 8192; this.mask = this.N - 1; this.buf = new Float32Array(this.N); this.w = 0;
    this.D = Math.round(sampleRate * 0.06);                     // 60 ms oyna
    this.d1 = 0; this.d2 = this.D / 2;
  }
  tap(d) {
    const p = this.w - d, i = Math.floor(p), f = p - i, b = this.buf, m = this.mask;
    const x = b[i & m], y = b[(i + 1) & m];
    return x + (y - x) * f;
  }
  process(inputs, outputs) {
    const out = outputs[0][0];
    if (!out) return true;
    const inp = inputs[0] && inputs[0][0], D = this.D, TWO_PI = 2 * Math.PI;
    for (let i = 0; i < out.length; i++) {
      this.buf[this.w] = inp ? inp[i] : 0;
      const w1 = 0.5 - 0.5 * Math.cos(TWO_PI * this.d1 / D), w2 = 0.5 - 0.5 * Math.cos(TWO_PI * this.d2 / D);
      out[i] = this.tap(this.d1) * w1 + this.tap(this.d2) * w2;
      this.d1 += this.step; this.d2 += this.step;
      if (this.d1 >= D) this.d1 -= D; else if (this.d1 < 0) this.d1 += D;
      if (this.d2 >= D) this.d2 -= D; else if (this.d2 < 0) this.d2 += D;
      this.w = (this.w + 1) & this.mask;
    }
    return true;
  }
}
registerProcessor("voice-shifter", VoiceShifter);
