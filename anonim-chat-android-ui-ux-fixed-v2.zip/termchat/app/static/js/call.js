/* Anonim Chat by Hevorix — ovozli qo'ng'iroq (1:1, lichkada). Media qurilmalar orasida to'g'ridan-to'g'ri (WebRTC), server faqat signal uzatadi.

   Xavfsizlik (batafsil: js/callcrypto.js):
     - ikki tomon oldindan kelishgan PAROL + qurilmada yaratilgan ECDH kalit: ovoz kadrlari AES-256-GCM bilan shifrlanadi (Insertable Streams).
       Parol mos kelmasa qo'ng'iroq ULANMAYDI va ovoz oqimi boshlanmaydi. Server va tarmoq vositachilari ovozni eshita olmaydi.
     - ovozning o'zi ham o'zgartiriladi (ovozli xabardagidek pastroq/qalinroq): xom mikrofon ovozi tarmoqqa HECH QACHON chiqmaydi;
     - kadrlar qat'iy hajmgacha to'ldiriladi, DTX/“audio level” o'chiriladi, qo'shimcha soxta (decoy) shifrlangan paketlar yuboriladi;
     - TURN mavjud bo'lsa faqat relay orqali ulanadi: suhbatdoshlar bir-birining IP manzilini ko'rmaydi (anonimlik);
     - qo'ng'iroqqa faqat ikki ishtirokchi ulanadi (server tekshiradi), shifr kaliti esa faqat ularda. */
"use strict";
(root => {
const doc = root.document, nav = root.navigator;
const MIN_PW = 6, MAX_TRIES = 3, SECURE_TIMEOUT = 90000;
let B = null, K = null, ui = null, hideTimer = 0;

const rnd = () => { const b = new Uint32Array(1); root.crypto.getRandomValues(b); return b[0] / 4294967296; };
const fmt = s => String(Math.floor(s / 60)).padStart(2, "0") + ":" + String(Math.floor(s % 60)).padStart(2, "0");
const wait = ms => new Promise(r => setTimeout(r, ms));

/* ---------------- ovoz signallari ---------------- */
const Tone = {
  ctx: null, timer: 0, vib: 0,
  start(kind) {
    this.stop();
    const AC = root.AudioContext || root.webkitAudioContext;
    if (!AC) return;
    try { this.ctx = new AC(); this.ctx.resume && this.ctx.resume(); } catch (_) { return; }
    const beep = (f, d) => { try { const c = this.ctx, o = c.createOscillator(), g = c.createGain(); g.gain.value = 0.05; o.frequency.value = f; o.connect(g); g.connect(c.destination); o.start(); o.stop(c.currentTime + d); } catch (_) {} };
    const play = () => { if (kind === "in") { beep(523, 0.25); setTimeout(() => beep(659, 0.25), 300); if (nav.vibrate) nav.vibrate([350, 150, 350]); } else beep(425, 0.9); };
    play(); this.timer = setInterval(play, kind === "in" ? 1800 : 3200);
  },
  stop() {
    clearInterval(this.timer); this.timer = 0;
    if (nav.vibrate) try { nav.vibrate(0); } catch (_) {}
    if (this.ctx) { try { this.ctx.close(); } catch (_) {} this.ctx = null; }
  },
};

/* ---------------- qo'llab-quvvatlash ---------------- */
function unsupported() {
  if (!root.isSecureContext) return "Qo'ng'iroq faqat HTTPS (xavfsiz ulanish) orqali ishlaydi";
  if (!root.RTCPeerConnection || !nav.mediaDevices || !nav.mediaDevices.getUserMedia) return "Brauzeringiz ovozli qo'ng'iroqni qo'llamaydi";
  if (!(root.AudioContext || root.webkitAudioContext) || !root.AudioWorkletNode) return "Brauzeringiz jonli ovoz qayta ishlashni qo'llamaydi";
  const legacy = root.RTCRtpSender && root.RTCRtpSender.prototype.createEncodedStreams;
  if (!root.RTCRtpScriptTransform && !legacy) return "Brauzeringiz qo'ng'iroqni shifrlash (Insertable Streams) imkoniyatiga ega emas — brauzerni yangilang";
  if (!root.CallCrypto) return "Qo'ng'iroq moduli yuklanmadi";
  return null;
}

/* ---------------- interfeys ---------------- */
function icon(name) { return B.icon(name, "ic"); }
function build() {
  const h = B.h;
  const btn = (cls, ic, label, fn) => h("button", {class: "cu-b " + cls, type: "button", "aria-label": label, title: label, onclick: fn}, icon(ic), h("span", {class: "cu-bl", text: label}));
  ui = {};
  ui.av = h("div", {class: "cu-av"});
  ui.name = h("div", {class: "cu-name"});
  ui.status = h("div", {class: "cu-status", role: "status", "aria-live": "polite"});
  ui.sub = h("div", {class: "cu-sub"});
  ui.dbg = h("div", {class: "cu-sub"});
  ui.pwInput = h("input", {class: "cu-in", type: "password", autocomplete: "off", autocapitalize: "off", spellcheck: "false", maxlength: "64", placeholder: "Qo'ng'iroq paroli"});
  ui.pwErr = h("div", {class: "cu-err"});
  ui.pwHint = h("div", {class: "cu-hint"});
  ui.pwGo = h("button", {class: "cu-go", type: "button"});
  ui.pw = h("div", {class: "cu-pw hidden"}, ui.pwHint, ui.pwInput, ui.pwErr, ui.pwGo);
  ui.mute = btn("mute", "mic", "Mikrofon", () => toggleMute());
  ui.spk = btn("spk", "phone", "Quloq", () => toggleSpeaker());
  ui.end = btn("end", "hangup", "Qo'yish", () => hangup());
  ui.acc = btn("acc", "phone", "Javob berish", () => onAcceptClick());
  ui.btns = h("div", {class: "cu-btns"}, ui.mute, ui.end, ui.spk, ui.acc);
  ui.audio = h("audio", {autoplay: true, playsinline: true});
  ui.root = h("div", {class: "callui hidden", role: "dialog", "aria-modal": "true", "aria-label": "Ovozli qo'ng'iroq"},
    h("div", {class: "cu-top"}, ui.av, ui.name, ui.status, ui.sub, ui.dbg), ui.pw, ui.btns, ui.audio);
  ui.pwInput.addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); ui.pwGo.click(); } });
  ui.root.addEventListener("click", () => { if (ui.audio.srcObject && ui.audio.paused) ui.audio.play().catch(() => {}); });   // brauzer avtomatik ijroni bloklasa: ekranga bosish yoqadi
  doc.body.append(ui.root);
}

function paint() {
  if (!ui || !K) return;
  const st = K.st, peer = B.user(K.peer);
  ui.av.textContent = ""; ui.av.append(B.avatar(peer, "l"));
  ui.name.textContent = peer.nickname || "Noma'lum";
  const pwMode = st === "setup" || st === "pw_in";
  ui.pw.classList.toggle("hidden", !pwMode);
  const inCall = st === "securing" || st === "connecting" || st === "connected";
  ui.mute.classList.toggle("hidden", !inCall);
  ui.spk.classList.toggle("hidden", !inCall);
  ui.acc.classList.toggle("hidden", st !== "ringing_in");
  ui.end.classList.toggle("hidden", st === "ended");
  const endLabel = st === "ringing_in" ? "Rad etish" : st === "setup" || st === "pw_in" ? "Bekor qilish" : "Qo'yish";
  ui.end.querySelector(".cu-bl").textContent = endLabel; ui.end.setAttribute("aria-label", endLabel);
  ui.mute.classList.toggle("on", !!K.muted);
  ui.mute.querySelector("use").setAttribute("href", K.muted ? "#i-mic-off" : "#i-mic");
  ui.mute.querySelector(".cu-bl").textContent = K.muted ? "Ovoz o'chiq" : "Mikrofon";
  ui.spk.classList.toggle("on", !!K.speaker);
  ui.spk.querySelector("use").setAttribute("href", K.speaker ? "#i-volume" : "#i-phone");
  ui.spk.querySelector(".cu-bl").textContent = K.speaker ? "Gromkaga" : "Quloqqa";
  if (pwMode) {
    ui.pwGo.textContent = st === "setup" ? "Qo'ng'iroq qilish" : "Ulanish";
    ui.pwHint.textContent = st === "setup"
      ? "Suhbatdoshingiz bilan oldindan kelishilgan parolni kiriting (kamida " + MIN_PW + " belgi). Parol serverga yuborilmaydi — ovoz shu parol bilan shifrlanadi."
      : "Suhbatdoshingiz bilan kelishilgan qo'ng'iroq parolini kiriting. Parol mos kelmasa qo'ng'iroq ulanmaydi.";
  }
  ui.status.textContent = K.statusText || "";
  ui.sub.textContent = K.subText || "";
  ui.root.classList.toggle("connected", st === "connected");
}
const setStatus = (t, sub) => { if (!K) return; K.statusText = t; if (sub !== undefined) K.subText = sub; paint(); };
function show() { if (!ui) build(); clearTimeout(hideTimer); ui.btns.classList.remove("hidden"); ui.root.classList.remove("hidden"); doc.body.classList.add("in-call"); paint(); }
function hide() { if (ui) ui.root.classList.add("hidden"); doc.body.classList.remove("in-call"); }

/* ---------------- mikrofon + ovoz o'zgartirgich ---------------- */
async function openMic() {
  let stream;
  try { stream = await nav.mediaDevices.getUserMedia({audio: {echoCancellation: true, noiseSuppression: true, autoGainControl: true, channelCount: 1}}); }
  catch (e) {
    const n = e && e.name;
    throw new Error(n === "NotAllowedError" || n === "SecurityError" ? "Mikrofonga ruxsat berilmagan. Brauzer sozlamalaridan ruxsat bering"
      : n === "NotFoundError" || n === "OverconstrainedError" ? "Mikrofon topilmadi" : "Mikrofonni ochib bo'lmadi");
  }
  const AC = root.AudioContext || root.webkitAudioContext;
  const ac = new AC({latencyHint: "interactive"});
  try {
    await ac.resume();
    await ac.audioWorklet.addModule("/static/js/callfx.js");
  } catch (e) { stream.getTracks().forEach(t => t.stop()); try { ac.close(); } catch (_) {} throw new Error("Ovoz o'zgartirgichni yuklab bo'lmadi"); }
  const ratio = 0.74 + rnd() * 0.08;                           // ovozli xabardagi kabi: har qo'ng'iroqda tasodifiy (0.74..0.82)
  const src = ac.createMediaStreamSource(stream);
  const hp = ac.createBiquadFilter(); hp.type = "highpass"; hp.frequency.value = 80;
  const fx = new root.AudioWorkletNode(ac, "voice-shifter", {numberOfInputs: 1, numberOfOutputs: 1, outputChannelCount: [1], processorOptions: {ratio}});
  const dest = ac.createMediaStreamDestination();
  let an = null; try { an = ac.createAnalyser(); an.fftSize = 1024; } catch (_) {}      // faqat diagnostika uchun
  src.connect(hp); hp.connect(fx); fx.connect(dest); if (an) fx.connect(an);
  K.mic = {stream, ac, an, track: dest.stream.getAudioTracks()[0]};          // PC ga faqat shu (o'zgartirilgan) trek beriladi
  K.mic.track.enabled = !K.muted;
}

function toggleMute() { if (!K) return; K.muted = !K.muted; if (K.mic) K.mic.track.enabled = !K.muted; paint(); }

async function applySpeaker() {
  if (!K || !ui) return;
  const a = ui.audio, want = !!K.speaker;
  let routed = false;
  if (a.setSinkId && nav.mediaDevices.enumerateDevices) {
    try {
      const outs = (await nav.mediaDevices.enumerateDevices()).filter(d => d.kind === "audiooutput");
      const earp = outs.find(d => /earpiece|receiver|handset|quloq/i.test(d.label)), spk = outs.find(d => /speaker|dinamik|loud/i.test(d.label));
      const pick = want ? (spk || outs.find(d => d.deviceId === "default")) : earp;
      if (pick) { await a.setSinkId(pick.deviceId); routed = want ? !!spk : true; }
    } catch (_) {}
  }
  a.volume = want || routed ? 1 : 0.4;                           // brauzer quloq dinamigiga o'tkaza olmasa: ovoz pasaytiriladi
  if (!want && !routed && !K.routeWarned) { K.routeWarned = true; B.toast("Brauzer telefon quloq dinamigiga o'tkaza olmaydi: ovoz pasaytirildi. Gromkaga o'tkazish uchun tugmani bosing", "warn"); }
}
function toggleSpeaker() { if (!K) return; K.speaker = !K.speaker; paint(); applySpeaker(); }

/* ---------------- qo'ng'iroq oqimi ---------------- */
const send = (op, extra) => B.wsSend(Object.assign({type: "call", op, id: K && K.id}, extra || {}));

function start(uid) {
  if (K) { show(); return; }
  const why = unsupported();
  if (why) return B.toast(why, "error");
  const peer = B.user(uid);
  if (!peer || peer.deleted) return B.toast("Bu foydalanuvchiga qo'ng'iroq qilib bo'lmaydi", "error");
  K = {role: "caller", peer: uid, st: "setup", speaker: false, muted: false};
  show(); ui.pwInput.value = ""; ui.pwErr.textContent = ""; setTimeout(() => ui.pwInput.focus(), 50);
  ui.pwGo.onclick = submitCaller;
}

async function submitCaller() {
  const pw = ui.pwInput.value.trim();
  if (pw.length < MIN_PW) { ui.pwErr.textContent = "Parol kamida " + MIN_PW + " belgidan iborat bo'lsin"; return; }
  ui.pwErr.textContent = ""; K.pw = pw; ui.pwInput.value = "";
  K.st = "starting"; setStatus("Mikrofon ochilmoqda…");
  try { await openMic(); } catch (e) { return finish(e.message, true); }
  if (!K) return;
  if (!B.wsSend({type: "call", op: "start", to: K.peer})) return finish("Ulanish yo'q", true);
  K.st = "ringing_out"; setStatus("Qo'ng'iroq qilinmoqda…", ""); Tone.start("out");
}

function onIncoming(m) {
  if (K) { B.wsSend({type: "call", op: "end", id: m.id}); return; }       // allaqachon band
  const why = unsupported();
  if (why) { B.wsSend({type: "call", op: "end", id: m.id}); return B.toast("Kiruvchi qo'ng'iroq rad etildi: " + why, "warn"); }
  K = {role: "callee", id: m.id, peer: m.from, st: "ringing_in", speaker: false, muted: false};
  show(); setStatus("Kiruvchi ovozli qo'ng'iroq…", "🔒 Uchdan-uchga shifrlangan"); Tone.start("in");
}

function onAcceptClick() {
  if (!K || K.st !== "ringing_in") return;
  Tone.stop(); K.st = "pw_in"; K.tries = 0; setStatus("");
  ui.pwInput.value = ""; ui.pwErr.textContent = ""; paint(); setTimeout(() => ui.pwInput.focus(), 50);
  ui.pwGo.onclick = submitCallee;
}

async function submitCallee() {
  const pw = ui.pwInput.value.trim();
  if (pw.length < MIN_PW) { ui.pwErr.textContent = "Parol kamida " + MIN_PW + " belgidan iborat"; return; }
  ui.pwErr.textContent = ""; ui.pwInput.value = "";
  if (K.mic) {                                                    // parol xato bo'lgandan keyingi qayta urinish
    K.pw = pw; K.st = "securing"; setStatus("Parol tekshirilmoqda…"); return rederive();
  }
  K.pw = pw; K.st = "securing"; setStatus("Mikrofon ochilmoqda…");
  try { await openMic(); } catch (e) { return finish(e.message, true); }
  if (!K) return;
  if (!send("accept")) return finish("Ulanish yo'q", true);
  setStatus("Xavfsiz kanal o'rnatilmoqda…");
  beginSecure();
}

function beginSecure() {
  K.icePromise = B.api("/call/ice").catch(() => { if (K) K.iceFail = true; return {iceServers: [{urls: ["stun:stun.cloudflare.com:3478"]}], turn: false}; });
  K.secureTimer = setTimeout(() => { if (K && K.st !== "connected") { send("end"); finish("Xavfsiz ulanish o'rnatilmadi (vaqt tugadi)"); } }, SECURE_TIMEOUT);
  CallCrypto.newKex().then(kex => { if (!K) return; K.kex = kex; send("kex", {pub: kex.pub}); return derive(); }).catch(e => finish("Kalit yaratib bo'lmadi: " + e.message, true));
}

async function derive() {
  if (!K || !K.kex || !K.peerPub || !K.pw || K.deriving) return;
  K.deriving = true;
  try {
    K.sess = await CallCrypto.deriveSession({priv: K.kex.priv, myPubRaw: K.kex.pubRaw, peerPub: K.peerPub, password: K.pw, callId: K.id, role: K.role});
    K.pw = null;
    if (!K) return;
    send("confirm", {mac: await CallCrypto.makeConfirm(K.sess)});
  } catch (e) { K.deriving = false; return finish("Kalit kelishuvi xatosi", true); }
  K.deriving = false;
  await verifyPeer();
}
async function rederive() {                                       // callee: yangi parol bilan qayta
  K.sess = null; K.deriving = false; await derive();
}

async function verifyPeer() {
  if (!K || !K.sess || !K.peerMac || K.mediaStarted) return;
  if (K.checked && K.checked.sess === K.sess && K.checked.mac === K.peerMac) return;     // bir xil tasdiq ikki marta tekshirilmasin (urinishlar ikki hissa sanalmasin)
  K.checked = {sess: K.sess, mac: K.peerMac};
  const ok = await CallCrypto.checkConfirm(K.sess, K.peerMac);
  if (!K) return;
  if (ok) { clearTimeout(K.secureTimer); return startMedia(); }
  if (K.role === "callee") {                                      // parol mos kelmadi: 3 martagacha qayta urinish
    K.tries = (K.tries || 0) + 1;
    if (K.tries >= MAX_TRIES) { send("end"); return finish("Parol mos kelmadi. Qo'ng'iroq to'xtatildi"); }
    K.st = "pw_in"; setStatus(""); ui.pwErr.textContent = "Parol mos kelmadi. Qayta kiriting (" + K.tries + "/" + MAX_TRIES + ")";
    ui.pwInput.value = ""; ui.pwGo.onclick = submitCallee; paint(); setTimeout(() => ui.pwInput.focus(), 50);
  } else {
    K.badConf = (K.badConf || 0) + 1;                              // suhbatdosh parolni taxmin qilib ko'rayotgan bo'lishi mumkin: cheklov
    if (K.badConf > MAX_TRIES + 2) { send("end"); return finish("Parol bir necha marta mos kelmadi. Qo'ng'iroq to'xtatildi"); }
    setStatus("Parol mos kelmadi. Suhbatdosh qayta urinmoqda…");
  }
}

/* ---------------- WebRTC ---------------- */
async function startMedia() {
  if (!K || K.mediaStarted) return;
  K.mediaStarted = true; K.st = "connecting"; setStatus("Ulanmoqda…", "🔒 Uchdan-uchga shifrlangan · kod " + K.sess.sas);
  const ice = await K.icePromise;
  if (!K) return;
  const cfg = {iceServers: ice.iceServers, bundlePolicy: "max-bundle", rtcpMuxPolicy: "require", iceTransportPolicy: ice.turn ? "relay" : "all"};
  if (!root.RTCRtpScriptTransform) cfg.encodedInsertableStreams = true;
  const pc = new RTCPeerConnection(cfg);
  K.pc = pc;
  if (!ice.turn) K.subText += K.iceFail ? " · ⚠ /api/call/ice xatosi (server loglarini tekshiring)" : " · ⚠ relay yo'q: IP manzillar ko'rinishi mumkin";
  const sendCipher = CallCrypto.makeCipher(K.sess.send), recvCipher = CallCrypto.makeCipher(K.sess.recv);
  const tr = pc.addTransceiver(K.mic.track, {direction: "sendrecv"});
  if (root.RTCRtpScriptTransform) {
    K.worker = new Worker("/static/js/callworker.js");
    K.worker.postMessage({type: "keys", send: K.sess.send, recv: K.sess.recv});
    tr.sender.transform = new RTCRtpScriptTransform(K.worker, {operation: "encrypt"});
    tr.receiver.transform = new RTCRtpScriptTransform(K.worker, {operation: "decrypt"});
  } else {
    const s = tr.sender.createEncodedStreams(), r = tr.receiver.createEncodedStreams();
    s.readable.pipeThrough(CallCrypto.makeTransform(() => sendCipher, "encrypt")).pipeTo(s.writable).catch(() => {});
    r.readable.pipeThrough(CallCrypto.makeTransform(() => recvCipher, "decrypt")).pipeTo(r.writable).catch(() => {});
  }
  K.coverCipher = CallCrypto.makeCipher(K.sess.cover);
  K.sess = null;                                                   // asosiy kalit materiali endi shifrlovchilarda; boshqa nusxa saqlanmaydi

  K.icedbg = {relay: 0, other: 0, errs: []};
  pc.onicecandidateerror = e => { if (K && K.pc === pc && K.icedbg.errs.length < 3) K.icedbg.errs.push(e.errorCode + (e.url ? " " + String(e.url).split("?")[0] : "")); };
  K.iceTimer = setTimeout(() => { if (K && K.pc === pc && pc.connectionState !== "connected") {
    const d = K.icedbg, why = ice.turn && !d.relay ? "TURN relay nomzodi olinmadi (Cloudflare TURN kaliti/tokeni yoki tarmoq)" : "ICE: " + pc.iceConnectionState;
    send("end"); finish("Aloqa o'rnatilmadi — " + why + (d.errs.length ? " [" + d.errs.join(", ") + "]" : ""), true); } }, 30000);
  pc.onicecandidate = e => { if (K && K.pc === pc && e.candidate) { if (/ typ relay/.test(e.candidate.candidate)) K.icedbg.relay++; else K.icedbg.other++; } if (K && K.pc === pc) send("ice", e.candidate ? {c: e.candidate.candidate, mid: e.candidate.sdpMid, idx: e.candidate.sdpMLineIndex} : {c: null}); };
  pc.ontrack = e => {
    if (e.track.kind !== "audio") return;                          // faqat shifrlangan audio qabul qilinadi
    ui.audio.srcObject = new MediaStream([e.track]); ui.audio.play().catch(() => {}); applySpeaker();
  };
  pc.ondatachannel = e => coverTraffic(e.channel);
  pc.onconnectionstatechange = () => {
    if (!K || K.pc !== pc) return;
    const s = pc.connectionState;
    if (s === "connected") { clearTimeout(K.dropTimer); onConnected(); }
    else if (s === "disconnected") { setStatus("Aloqa beqaror…"); K.dropTimer = setTimeout(() => { if (K && K.pc === pc && pc.connectionState !== "connected") { send("end"); finish("Aloqa uzildi"); } }, 10000); }
    else if (s === "failed") { send("end"); finish(ice.turn ? "Aloqa o'rnatilmadi" : "Aloqa o'rnatilmadi (TURN server sozlanmagan bo'lishi mumkin)"); }
  };

  if (K.role === "caller") {
    coverTraffic(pc.createDataChannel("c", {ordered: false, maxRetransmits: 0}));
    const offer = await pc.createOffer();
    offer.sdp = CallCrypto.hardenSdp(offer.sdp);
    await pc.setLocalDescription(offer);
    send("offer", {sdp: offer.sdp});
  } else if (K.pendingOffer) { const o = K.pendingOffer; K.pendingOffer = null; await onOffer(o); }
  for (const c of K.iceQueue || []) addIce(c);
  if (K) K.iceQueue = [];
}

async function onOffer(m) {
  if (!K) return;
  if (!K.pc) { K.pendingOffer = m; return; }
  if (/^m=(video|text)/mi.test(m.sdp)) { send("end"); return finish("Noto'g'ri qo'ng'iroq so'rovi rad etildi", true); }   // faqat shifrlangan audio
  const pc = K.pc;
  await pc.setRemoteDescription({type: "offer", sdp: m.sdp});
  const ans = await pc.createAnswer();
  ans.sdp = CallCrypto.hardenSdp(ans.sdp);
  await pc.setLocalDescription(ans);
  send("answer", {sdp: ans.sdp});
  for (const c of K.iceQueue || []) addIce(c);
  K.iceQueue = [];
}
async function onAnswer(m) {
  if (!K || !K.pc) return;
  if (/^m=(video|text)/mi.test(m.sdp)) { send("end"); return finish("Noto'g'ri javob rad etildi", true); }
  await K.pc.setRemoteDescription({type: "answer", sdp: m.sdp});
  for (const c of K.iceQueue || []) addIce(c);
  K.iceQueue = [];
}
function addIce(m) {
  if (!K || !K.pc || !K.pc.remoteDescription) { if (K) (K.iceQueue = K.iceQueue || []).push(m); return; }
  if (!m.c) return;
  K.pc.addIceCandidate({candidate: m.c, sdpMid: m.mid, sdpMLineIndex: m.idx}).catch(() => {});
}

/* Soxta paketlar: tasodifiy vaqt va hajmda shifrlangan tasodifiy ma'lumot (ikki tomonga). Haqiqiy ovoz hajmi ham qat'iy. */
function coverTraffic(dc) {
  K.cover = dc; dc.binaryType = "arraybuffer";
  const tick = async () => {
    if (!K || K.cover !== dc || dc.readyState === "closed") return;
    try {
      if (dc.readyState === "open" && dc.bufferedAmount < 32768) {
        const burst = rnd() < 0.12 ? 2 + Math.floor(rnd() * 4) : 1;
        for (let i = 0; i < burst; i++) {
          const plan = CallCrypto.coverPlan(rnd), data = root.crypto.getRandomValues(new Uint8Array(plan.size));
          dc.send(await K.coverCipher.seal(data, plan.size + 2));
        }
      }
    } catch (_) {}
    K.coverTimer = setTimeout(tick, CallCrypto.coverPlan(rnd).delayMs);
  };
  dc.onopen = () => { clearTimeout(K && K.coverTimer); tick(); };
  dc.onmessage = () => {};                                         // kelgan soxta paketlar e'tiborsiz
}

function micLevel() {
  const an = K && K.mic && K.mic.an; if (!an) return 0;
  const a = new Float32Array(an.fftSize); an.getFloatTimeDomainData(a);
  let m = 0; for (let i = 0; i < a.length; i++) m = Math.max(m, Math.abs(a[i]));
  return m;
}
function statsTick() {
  const k = K; if (!k || !k.pc || !ui) return;
  if (ui.audio.srcObject && ui.audio.paused) ui.audio.play().catch(() => {});
  k.pc.getStats().then(rep => {
    if (K !== k) return;
    let sent = 0, got = 0, energy = 0, dec = 0;
    rep.forEach(r => {
      if (r.type === "outbound-rtp" && r.kind === "audio") sent = r.bytesSent || 0;
      if (r.type === "inbound-rtp" && r.kind === "audio") { got = r.bytesReceived || 0; energy = r.totalAudioEnergy || 0; dec = r.totalSamplesReceived || 0; }
    });
    const ml = micLevel(), kb = n => Math.round(n / 1024);
    ui.dbg.textContent = "mik " + (ml > 0.02 ? "▮▮▮" : ml > 0.002 ? "▮▮" : ml > 0 ? "▮" : "—") + " · ↑" + kb(sent) + "KB · ↓" + kb(got) + "KB · dekod " + (dec > 0 ? "bor" : "yo'q") + " · tovush " + (energy > 0.0001 ? "bor" : "yo'q") + (ui.audio.paused ? " · PLEYER TO'XTAGAN (ekranga bosing)" : " · vol " + ui.audio.volume);
  }).catch(() => {});
}
async function onConnected() {
  if (!K || K.st === "connected") return;
  K.st = "connected"; K.t0 = Date.now();
  K.timer = setInterval(() => { if (K) setStatus(fmt((Date.now() - K.t0) / 1000)); }, 1000);
  setStatus("00:00"); applySpeaker();
  K.statsTimer = setInterval(statsTick, 1000);
  try { if (nav.wakeLock) K.wake = await nav.wakeLock.request("screen"); } catch (_) {}
}

/* ---------------- yakunlash ---------------- */
function hangup() {
  if (!K) return;
  if (K.id) send("end"); else K.cancel = true;
  finish(K.st === "ringing_in" ? "Rad etildi" : "Qo'ng'iroq tugadi");
}

function finish(text, isError) {
  const k = K;
  if (!k) return;
  K = null;
  Tone.stop();
  [k.timer, k.secureTimer, k.dropTimer, k.coverTimer, k.iceTimer, k.statsTimer].forEach(t => { clearInterval(t); clearTimeout(t); });
  try { if (k.cover) k.cover.close(); } catch (_) {}
  try { if (k.pc) { k.pc.getSenders().forEach(s => { s.transform = null; }); k.pc.close(); } } catch (_) {}
  try { if (k.worker) { k.worker.postMessage({type: "wipe"}); k.worker.terminate(); } } catch (_) {}
  try { if (k.mic) { k.mic.stream.getTracks().forEach(t => t.stop()); k.mic.track.stop(); k.mic.ac.close(); } } catch (_) {}
  try { if (k.wake) k.wake.release(); } catch (_) {}
  if (ui) { ui.dbg.textContent = ""; ui.audio.srcObject = null; ui.pw.classList.add("hidden"); ui.pwInput.value = ""; }
  if (text && ui && !ui.root.classList.contains("hidden")) {
    ui.status.textContent = text; ui.sub.textContent = ""; ui.btns.classList.add("hidden"); ui.root.classList.remove("connected");
    hideTimer = setTimeout(() => { if (!K) { hide(); ui.btns.classList.remove("hidden"); } }, isError ? 2600 : 1400);
  } else { hide(); }
}

const REASONS = {hangup: "Suhbatdosh qo'ng'iroqni tugatdi", declined: "Qo'ng'iroq rad etildi", noanswer: "Javob bermadi", drop: "Aloqa uzildi", other: ""};
function onSignal(m) {
  if (!m || m.type !== "call") return;
  switch (m.op) {
    case "incoming": return onIncoming(m);
    case "started":
      if (K && K.role === "caller" && !K.id) { K.id = m.id; if (K.cancel) { send("end"); return finish("Bekor qilindi"); } if (!m.online) setStatus("Qo'ng'iroq qilinmoqda…", "Foydalanuvchi hozir oflayn: bildirishnoma yuborildi"); }
      return;
    case "accepted":
      if (K && K.id === m.id && K.role === "caller") { Tone.stop(); K.st = "securing"; setStatus("Xavfsiz kanal o'rnatilmoqda…"); beginSecure(); }
      return;
    case "kex": if (K && K.id === m.id && typeof m.pub === "string") { K.peerPub = m.pub; derive(); } return;
    case "confirm": if (K && K.id === m.id && typeof m.mac === "string") { K.peerMac = m.mac; verifyPeer(); } return;
    case "offer": if (K && K.id === m.id && K.role === "callee" && typeof m.sdp === "string") onOffer(m).catch(() => finish("Ulanish xatosi", true)); return;
    case "answer": if (K && K.id === m.id && K.role === "caller" && typeof m.sdp === "string") onAnswer(m).catch(() => finish("Ulanish xatosi", true)); return;
    case "ice": if (K && K.id === m.id) addIce(m); return;
    case "ended":
      if (K && K.id === m.id) finish(REASONS[m.reason] != null ? REASONS[m.reason] : "Qo'ng'iroq tugadi");
      return;
    case "error":
      if (K && (!m.id || m.id === K.id || !K.id)) finish(m.message || "Qo'ng'iroq xatosi", true);
      else if (m.message) B.toast(m.message, "error");
      return;
  }
}

function onWsOpen() { if (K && K.id && K.st !== "setup" && K.st !== "pw_in") B.wsSend({type: "call", op: "rebind", id: K.id}); }
function reset() { if (K) { if (K.id) { try { send("end"); } catch (_) {} } finish("", false); } }
root.addEventListener("pagehide", () => { if (K && K.id) { try { send("end"); } catch (_) {} } });

root.Call = {init(bridge) { B = bridge; }, start, onSignal, onWsOpen, reset, busy: () => !!K, unsupported};
})(typeof globalThis !== "undefined" ? globalThis : window);
