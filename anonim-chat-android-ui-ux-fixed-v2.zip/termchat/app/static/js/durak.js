/* Durak (podkidnoy): qoidalar + bot. window.TCDurak. Qoidalar server (app/games/durak_engine.py) bilan bir xil.
   Karta: daraja ("6789TJQKA") + mast ("SHDC"), masalan "TH" = ♥10. Harakat: {t:"atk",c} {t:"def",c,i} {t:"take"} {t:"pass"}. */
(function (root) {
  "use strict";
  const RANKS = "6789TJQKA", SUITS = "SHDC", HAND = 6;
  const rank = c => RANKS.indexOf(c[0]);
  const fullDeck = () => { const d = []; for (const s of SUITS) for (const r of RANKS) d.push(r + s); return d; };
  const shuffle = a => { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };

  class State {
    constructor(n, deck) {
      if (!(n >= 2 && n <= 4)) throw new Error("O'yinchilar soni 2 dan 4 gacha");
      this.n = n; this.deck = deck ? deck.slice() : shuffle(fullDeck());
      this.hands = Array.from({length: n}, () => []);
      for (let k = 0; k < HAND; k++) for (let i = 0; i < n; i++) this.hands[i].push(this.deck.pop());
      this.trumpCard = this.deck[0]; this.trump = this.trumpCard[1];
      this.out = new Array(n).fill(false); this.finish = []; this.discard = 0; this.over = null;
      let best = 99, first = 0;
      this.hands.forEach((h, i) => h.forEach(c => { if (c[1] === this.trump && rank(c) < best) { best = rank(c); first = i; } }));
      this.att = first; this.dfn = this._next(first);
      this._startRound();
    }
    _next(seat) { let s = (seat + 1) % this.n; while (this.out[s] && s !== seat) s = (s + 1) % this.n; return s; }
    _startRound() { this.table = []; this.phase = "attack"; this.passed = new Set(); this.cap = Math.min(HAND, this.hands[this.dfn].length); this.turn = this.att; }
    beats(att, c) { return c[1] === att[1] ? rank(c) > rank(att) : (c[1] === this.trump && att[1] !== this.trump); }
    _unbeaten() { const o = []; this.table.forEach((p, i) => { if (p[1] == null) o.push(i); }); return o; }
    _attackers() { const o = []; let s = this.att; for (let k = 0; k < this.n; k++) { if (s !== this.dfn && !this.out[s]) o.push(s); s = (s + 1) % this.n; } return o; }
    throwable(seat) {
      if (this.over || this.out[seat] || seat === this.dfn) return [];
      const h = this.hands[seat];
      if (!this.table.length) return seat === this.att ? h.slice() : [];
      if (this.table.length >= this.cap) return [];
      if (this.phase === "attack" && this.hands[this.dfn].length <= this._unbeaten().length) return [];
      const ranks = new Set(); this.table.forEach(p => p.forEach(c => { if (c) ranks.add(c[0]); }));
      return h.filter(c => ranks.has(c[0]));
    }
    _setTurn() {
      if (this.phase === "attack" && this._unbeaten().length) { this.turn = this.dfn; return; }
      if (!this.table.length) { this.turn = this.att; return; }
      for (const s of this._attackers()) if (!this.passed.has(s) && this.throwable(s).length) { this.turn = s; return; }
      this._endRound();
    }
    _endRound() {
      const took = this.phase === "take", cards = [];
      this.table.forEach(p => p.forEach(c => { if (c) cards.push(c); }));
      if (took) this.hands[this.dfn].push(...cards); else this.discard += cards.length;
      this.table = [];
      for (const s of this._attackers().concat([this.dfn])) {
        if (this.out[s]) continue;
        while (this.hands[s].length < HAND && this.deck.length) this.hands[s].push(this.deck.pop());
      }
      for (let s = 0; s < this.n; s++) if (!this.out[s] && !this.hands[s].length && !this.deck.length) { this.out[s] = true; this.finish.push(s); }
      const alive = []; for (let s = 0; s < this.n; s++) if (!this.out[s]) alive.push(s);
      if (alive.length <= 1) { this.over = {loser: alive.length ? alive[0] : null}; this.turn = -1; return; }
      const d = this.dfn;
      this.att = took ? this._next(d) : (!this.out[d] ? d : this._next(d));
      this.dfn = this._next(this.att);
      this._startRound();
    }
    legal(seat) {
      const res = {cards: [], take: false, pass: false, def: {}};
      if (this.over || seat !== this.turn) return res;
      if (seat === this.dfn) {
        res.take = true;
        for (const c of this.hands[seat]) { const idx = this._unbeaten().filter(i => this.beats(this.table[i][0], c)); if (idx.length) res.def[c] = idx; }
        res.cards = Object.keys(res.def); return res;
      }
      res.cards = this.throwable(seat); res.pass = this.table.length > 0; return res;
    }
    act(seat, a) {
      if (this.over) throw new Error("o'yin tugagan");
      if (seat !== this.turn) throw new Error("navbat sizda emas");
      const t = a && a.t; let info;
      if (t === "atk") {
        if (!this.throwable(seat).includes(a.c)) throw new Error("bu kartani tashlab bo'lmaydi");
        this.hands[seat].splice(this.hands[seat].indexOf(a.c), 1); this.table.push([a.c, null]); this.passed.clear(); info = {t, seat, c: a.c};
      } else if (t === "def") {
        if (seat !== this.dfn || this.phase !== "attack") throw new Error("siz himoyachi emassiz");
        if (!Number.isInteger(a.i) || !this._unbeaten().includes(a.i) || !this.hands[seat].includes(a.c) || !this.beats(this.table[a.i][0], a.c)) throw new Error("bu karta urmaydi");
        this.hands[seat].splice(this.hands[seat].indexOf(a.c), 1); this.table[a.i][1] = a.c; info = {t, seat, c: a.c, i: a.i};
      } else if (t === "take") {
        if (seat !== this.dfn || this.phase !== "attack" || !this._unbeaten().length) throw new Error("hozir olib bo'lmaydi");
        this.phase = "take"; this.passed.clear(); info = {t, seat};
      } else if (t === "pass") {
        if (seat === this.dfn || !this.table.length) throw new Error("hozir pas qilib bo'lmaydi");
        this.passed.add(seat); info = {t, seat};
      } else throw new Error("noma'lum harakat");
      this._setTurn();
      return info;
    }
  }

  // ---- bot: kozerni saqlaydi, faqat boshqa urib bo'lmasa (yoki oxirgi bosqichda) ishlatadi ----
  const isT = (s, c) => c[1] === s.trump;
  const byRank = (a, b) => rank(a) - rank(b);
  function planDefense(s, seat) {
    const hand = s.hands[seat].slice(), plan = [];
    const idx = s._unbeaten().sort((a, b) => (isT(s, s.table[b][0]) - isT(s, s.table[a][0])) || (rank(s.table[b][0]) - rank(s.table[a][0])));
    for (const i of idx) {
      const opts = hand.filter(c => s.beats(s.table[i][0], c)).sort((a, b) => (isT(s, a) - isT(s, b)) || byRank(a, b));
      if (!opts.length) return null;
      plan.push({i, c: opts[0]}); hand.splice(hand.indexOf(opts[0]), 1);
    }
    return plan;
  }
  function botAct(s, seat) {
    const L = s.legal(seat);
    if (seat === s.dfn) {
      const plan = planDefense(s, seat);
      if (!plan) return {t: "take"};
      const bigTrump = plan.some(p => isT(s, p.c) && rank(p.c) >= 6 && !isT(s, s.table[p.i][0]));
      if (bigTrump && s.deck.length >= 6 && Math.random() < 0.6) return {t: "take"};
      return {t: "def", c: plan[0].c, i: plan[0].i};
    }
    const cards = L.cards, plain = cards.filter(c => !isT(s, c)).sort(byRank);
    if (!s.table.length) {
      if (!plain.length) return {t: "atk", c: cards.slice().sort(byRank)[0]};
      const cnt = {}; plain.forEach(c => { cnt[c[0]] = (cnt[c[0]] || 0) + 1; });
      const pair = plain.find(c => cnt[c[0]] > 1);
      return {t: "atk", c: pair || plain[0]};
    }
    let pool = plain;
    if (!pool.length && !s.deck.length) pool = cards.slice().sort(byRank);
    if (!pool.length) return {t: "pass"};
    const c = pool[0];
    if (s.phase !== "take" && rank(c) >= 7 && s.deck.length > 0 && s.hands[s.dfn].length > 2 && Math.random() < 0.5) return {t: "pass"};
    return {t: "atk", c};
  }
  const api = {State, rank, fullDeck, botAct, RANKS, SUITS};
  root.TCDurak = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof self !== "undefined" ? self : this);
