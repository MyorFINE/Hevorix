/* Rus shashkasi: qoidalar + bot. Brauzerda (window.TCDraughts) ham, Web Worker ichida ham ishlaydi.
   Qoidalar server (app/games/checkers_engine.py) bilan bir xil: majburiy urish, damka uzoqdan uradi, urish paytida damka bo'lib davom etish,
   "turk zarbasi", 15 yurishlik damka qoidasi va 3 marta takrorlanish. Taxta: indeks = qator*8 + ustun, a1 = 0.
   Toshlar: 1 oq shashka, 2 oq damka, -1 qora shashka, -2 qora damka. */
(function (root) {
  "use strict";
  const DIRS = [[1, 1], [1, -1], [-1, 1], [-1, -1]];
  const KING_ONLY_PLIES = 30;
  const CH = {"0": ".", "1": "w", "2": "W", "-1": "b", "-2": "B"};
  const FROM = {".": 0, w: 1, W: 2, b: -1, B: -2};
  const sqName = i => "abcdefgh"[i & 7] + ((i >> 3) + 1);
  const sqIdx = s => (s.charCodeAt(1) - 49) * 8 + s.charCodeAt(0) - 97;
  const on = (f, r) => f >= 0 && f < 8 && r >= 0 && r < 8;

  function jumps(b, pos, king, sgn, caps) {
    const out = [], f0 = pos & 7, r0 = pos >> 3;
    for (const [df, dr] of DIRS) {
      let f = f0 + df, r = r0 + dr;
      if (king) while (on(f, r) && b[r * 8 + f] === 0) { f += df; r += dr; }
      if (!on(f, r)) continue;
      const mid = r * 8 + f;
      if (b[mid] * sgn >= 0 || caps.indexOf(mid) >= 0) continue;
      const lands = [];
      let lf = f + df, lr = r + dr;
      while (on(lf, lr) && b[lr * 8 + lf] === 0) { lands.push(lr * 8 + lf); if (!king) break; lf += df; lr += dr; }
      if (lands.length) out.push([mid, lands]);
    }
    return out;
  }
  function captureSeqs(b, start, sgn) {
    const piece = b[start], wasKing = Math.abs(piece) === 2, promoRank = sgn === 1 ? 7 : 0, res = [];
    b[start] = 0;
    const dfs = (pos, king, path, caps) => {
      const js = jumps(b, pos, king, sgn, caps);
      if (!js.length) { if (caps.length) res.push({p: path, c: caps, k: king && !wasKing}); return; }
      for (const [mid, lands] of js) {
        const nc = caps.concat(mid);
        if (king) {
          const cont = lands.filter(l => jumps(b, l, true, sgn, nc).length);
          for (const l of (cont.length ? cont : lands)) dfs(l, true, path.concat(l), nc);
        } else { const l = lands[0]; dfs(l, (l >> 3) === promoRank, path.concat(l), nc); }
      }
    };
    dfs(start, wasKing, [start], []);
    b[start] = piece;
    return res;
  }
  function simpleMoves(b, start, sgn) {
    const king = Math.abs(b[start]) === 2, promoRank = sgn === 1 ? 7 : 0, res = [], f0 = start & 7, r0 = start >> 3;
    for (const [df, dr] of DIRS) {
      if (!king && dr !== sgn) continue;
      let f = f0 + df, r = r0 + dr;
      while (on(f, r) && b[r * 8 + f] === 0) {
        res.push({p: [start, r * 8 + f], c: [], k: !king && r === promoRank});
        if (!king) break;
        f += df; r += dr;
      }
    }
    return res;
  }

  class Pos {
    constructor() {
      this.b = new Int8Array(64); this.turn = 1; this.half = 0;
      for (let r = 0; r < 8; r++) for (let f = 0; f < 8; f++) if ((f + r) % 2 === 0) { if (r < 3) this.b[r * 8 + f] = 1; else if (r > 4) this.b[r * 8 + f] = -1; }
    }
    clone() { const p = new Pos(); p.b.set(this.b); p.turn = this.turn; p.half = this.half; return p; }
    boardString() { let s = ""; for (let i = 0; i < 64; i++) s += CH[this.b[i]]; return s; }
    key() { return this.boardString() + this.turn; }
    legal() {
      const sgn = this.turn, b = this.b, caps = [];
      for (let i = 0; i < 64; i++) if (b[i] * sgn > 0) { const s = captureSeqs(b, i, sgn); for (const m of s) caps.push(m); }
      if (caps.length) return caps;
      const res = [];
      for (let i = 0; i < 64; i++) if (b[i] * sgn > 0) { const s = simpleMoves(b, i, sgn); for (const m of s) res.push(m); }
      return res;
    }
    find(path, list) {
      const want = path.map(sqIdx), L = list || this.legal();
      return L.find(m => m.p.length === want.length && m.p.every((v, i) => v === want[i])) || null;
    }
    make(m) {
      const b = this.b, piece = b[m.p[0]], man = Math.abs(piece) === 1;
      for (const c of m.c) b[c] = 0;
      b[m.p[0]] = 0;
      b[m.p[m.p.length - 1]] = (m.k || !man) ? 2 * Math.sign(piece) : piece;
      this.half = (m.c.length || man) ? 0 : this.half + 1;
      this.turn = -this.turn;
    }
    legalMap(list) {
      const out = {};
      for (const m of (list || this.legal())) (out[sqName(m.p[0])] = out[sqName(m.p[0])] || []).push(m.p.slice(1).map(sqName));
      return out;
    }
  }
  const fromBoard = (str, turn) => { const p = new Pos(); for (let i = 0; i < 64; i++) p.b[i] = FROM[str[i]]; p.turn = turn === "b" ? -1 : 1; return p; };
  const pathOf = s => { const o = []; for (let i = 0; i + 1 < s.length; i += 2) o.push(s.slice(i, i + 2)); return o; };
  const pathStr = m => m.p.map(sqName).join("");

  // ---- baholash va qidiruv ----
  const INF = 1e6, WIN = 100000;
  function evaluate(pos) {
    const b = pos.b; let s = 0, men = 0;
    for (let i = 0; i < 64; i++) {
      const v = b[i]; if (!v) continue;
      const a = Math.abs(v), sg = Math.sign(v), f = i & 7, r = i >> 3, rr = sg === 1 ? r : 7 - r;
      const cen = (f >= 2 && f <= 5 && r >= 2 && r <= 5) ? 3 : 0;
      if (a === 1) { men++; s += sg * (100 + rr * 4 + cen + (rr === 0 ? 5 : 0) + (f === 0 || f === 7 ? -2 : 0)); }
      else s += sg * (320 + (f === r ? 8 : 0) + ((7 - f) === r ? 3 : 0) + cen);
    }
    return pos.turn * s;
  }
  function order(moves) {
    return moves.map(m => ({m, s: m.c.length * 10 + (m.k ? 8 : 0) + (m.c.length ? 0 : (m.p[1] >> 3))})).sort((a, b) => b.s - a.s).map(x => x.m);
  }
  function search(pos, depth, alpha, beta, ply, st) {
    if ((++st.nodes & 1023) === 0 && Date.now() > st.deadline) st.stop = true;
    if (st.stop) return 0;
    if (pos.half >= KING_ONLY_PLIES) return 0;
    const moves = pos.legal();
    if (!moves.length) return -WIN + ply;
    if ((depth <= 0 && !moves[0].c.length) || depth < -8) return evaluate(pos);
    let best = -INF;
    for (const m of order(moves)) {
      const ch = pos.clone(); ch.make(m);
      const v = -search(ch, depth - 1, -beta, -alpha, ply + 1, st);
      if (st.stop) return 0;
      if (v > best) best = v;
      if (best > alpha) alpha = best;
      if (alpha >= beta) break;
    }
    return best;
  }
  const LEVELS = {
    1: {name: "Yangi boshlovchi", depth: 1, noise: 140, ms: 400},
    2: {name: "Havaskor", depth: 2, noise: 55, ms: 600},
    3: {name: "O'rta", depth: 4, noise: 18, ms: 900},
    4: {name: "Kuchli", depth: 6, noise: 5, ms: 1500},
    5: {name: "Usta", depth: 14, noise: 0, ms: 2200},
  };
  function chooseMove(pos, level, opts) {
    const moves = pos.legal();
    if (!moves.length) return null;
    if (moves.length === 1) return moves[0];
    const lv = (opts && opts.hint) ? LEVELS[5] : (LEVELS[level] || LEVELS[3]);
    const st = {nodes: 0, stop: false, deadline: Date.now() + lv.ms};
    const ord = order(moves);
    if (lv.noise) {
      let best = null, bs = -INF;
      for (const m of ord) {
        const ch = pos.clone(); ch.make(m);
        const v = -search(ch, lv.depth - 1, -INF, INF, 1, st);
        if (st.stop) break;
        const s = v + (Math.random() * 2 - 1) * lv.noise;
        if (s > bs) { bs = s; best = m; }
      }
      return best || ord[Math.floor(Math.random() * ord.length)];
    }
    let best = ord[0], list = ord;
    for (let d = 1; d <= lv.depth; d++) {
      let ib = null, is = -INF, alpha = -INF;
      const scored = [];
      for (const m of list) {
        const ch = pos.clone(); ch.make(m);
        const v = -search(ch, d - 1, -INF, -alpha, 1, st);
        if (st.stop) break;
        scored.push([m, v]);
        if (v > is) { is = v; ib = m; }
        if (v > alpha) alpha = v;
      }
      if (st.stop) break;
      best = ib; list = scored.sort((a, b) => b[1] - a[1]).map(x => x[0]);
      if (is > WIN - 100 || is < -WIN + 100) break;
    }
    return best;
  }
  function replay(moves) {
    const pos = new Pos();
    for (const s of moves) { const m = pos.find(pathOf(s)); if (!m) return null; pos.make(m); }
    return pos;
  }
  const api = {Pos, LEVELS, KING_ONLY_PLIES, sqName, sqIdx, fromBoard, pathOf, pathStr, chooseMove, evaluate, replay};
  root.TCDraughts = api;
  if (typeof WorkerGlobalScope !== "undefined" && typeof self !== "undefined" && self instanceof WorkerGlobalScope) {
    self.onmessage = e => {
      const d = e.data || {};
      try {
        const pos = replay(d.moves || []);
        if (!pos) throw new Error("yurishlar tarixi noto'g'ri");
        const m = chooseMove(pos, d.level || 3, {hint: !!d.hint});
        self.postMessage({id: d.id, ok: true, path: m ? m.p.map(sqName) : null});
      } catch (err) { self.postMessage({id: d.id, ok: false, error: String(err && err.message || err)}); }
    };
  }
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof self !== "undefined" ? self : this);
