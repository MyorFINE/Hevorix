/* Kanallar: admin yaratadi (ommaviy yoki shaxsiy), postlar ostida ko'rishlar soni va kommentlar.
   Kommentlar faqat o'sha post ostida ko'rinadi — umumiy chatga tushmaydi.
   Matn DOM'ga faqat textContent orqali chiqariladi (XSS yo'q, CSP qat'iy). */
(() => {
  "use strict";
  let B = null;                                   // app.js bergan ko'prik (api, h, icon, toast, ...)
  const st = {list: [], cur: null, posts: [], more: false, cards: new Map(), unread: new Map(), cm: null, sent: new Set(), pend: new Set(), timer: 0, io: null};
  let ov, listView, chView, listEl, postsEl, headEl, composer, cmEl, cmBody, cmList, cmInput;
  const admin = () => !!B.amAdmin();

  /* ---------------- yordamchilar ---------------- */
  function chAvatar(c, cls) {
    const e = B.h("div", {class: "ch-av " + (cls || "")});
    if (c.avatar) e.append(B.h("img", {src: c.avatar, alt: "", draggable: "false"}));
    else e.append(B.h("span", {text: (Array.from((c.nickname || "?").trim())[0] || "?").toUpperCase()}));
    return e;
  }
  const lockIc = () => B.icon("lock", "ic ch-lock");
  function scrollBottom(el) { el.scrollTop = el.scrollHeight; }
  const nearBottom = el => el.scrollHeight - el.scrollTop - el.clientHeight < 120;
  const fail = err => B.toast(err && err.message ? err.message : "Xato, qayta urinib ko'ring", "error");

  /* ---------------- qobiq (bir marta quriladi) ---------------- */
  function build() {
    const h = B.h;
    // 1-daraja: kanallar ro'yxati
    listEl = h("div", {class: "ch-list"});
    const addBtn = h("button", {class: "icon-btn", type: "button", "aria-label": "Kanal yaratish", title: "Kanal yaratish", onclick: () => formModal(null)}, B.icon("plus"));
    const joinBtn = h("button", {class: "icon-btn", type: "button", "aria-label": "Shaxsiy kanalga qo'shilish", title: "Shaxsiy kanalga qo'shilish (username + parol)", onclick: joinModal}, B.icon("lock"));
    addBtn.classList.add("ch-admin-only"); 
    listView = h("div", {class: "ch-view"},
      h("div", {class: "ch-head"},
        h("button", {class: "icon-btn", type: "button", "aria-label": "Yopish", onclick: () => closeOverlay(false)}, B.icon("back")),
        h("div", {class: "ch-title"}, h("b", {text: "Kanallar"})),
        joinBtn, addBtn),
      listEl);
    // 2-daraja: kanal (postlar)
    headEl = h("div", {class: "ch-head"});
    postsEl = h("div", {class: "ch-posts"});
    const more = h("button", {class: "btn ghost sm ch-more hidden", type: "button", text: "Oldingi postlar", onclick: () => loadPosts(true)});
    st.moreBtn = more; postsEl.append(more);
    const ta = h("textarea", {class: "ch-ta", rows: "1", maxlength: "4000", placeholder: "Kanalga post yozing…", "aria-label": "Post matni"});
    ta.addEventListener("input", () => { ta.style.height = "auto"; ta.style.height = Math.min(ta.scrollHeight, 160) + "px"; });
    const send = h("button", {class: "ch-send", type: "button", "aria-label": "Yuborish", onclick: () => sendPost(ta)}, B.icon("send"));
    composer = h("div", {class: "ch-comp hidden"}, ta, send);
    chView = h("div", {class: "ch-view hidden"}, headEl, h("div", {class: "ch-posts-wrap"}, postsEl), composer);
    // 3-daraja: kommentlar
    cmList = h("div", {class: "ch-cmlist"});
    cmBody = h("div", {class: "ch-cmbody"});
    cmInput = h("textarea", {class: "ch-ta", rows: "1", maxlength: "1000", placeholder: "Komment yozing…", "aria-label": "Komment matni"});
    cmInput.addEventListener("input", () => { cmInput.style.height = "auto"; cmInput.style.height = Math.min(cmInput.scrollHeight, 120) + "px"; });
    const cmSend = h("button", {class: "ch-send", type: "button", "aria-label": "Yuborish", onclick: sendComment}, B.icon("send"));
    cmEl = h("div", {class: "ch-cm hidden", role: "dialog", "aria-label": "Kommentlar"},
      h("div", {class: "ch-head"},
        h("button", {class: "icon-btn", type: "button", "aria-label": "Orqaga", onclick: () => hideComments(false)}, B.icon("back")),
        h("div", {class: "ch-title"}, h("b", {text: "Kommentlar"}), h("small", {id: "chCmCount", text: ""}))),
      cmBody, h("div", {class: "ch-comp"}, cmInput, cmSend));
    ov = h("div", {class: "ch-ov hidden", role: "dialog", "aria-label": "Kanallar"}, listView, chView, cmEl);
    document.body.append(ov);
    st.addBtn = addBtn;
  }

  /* ---------------- 1-daraja: ro'yxat ---------------- */
  async function loadList() {
    try { st.list = (await B.api("/channels")).channels; } catch (err) { if (!st.list.length) fail(err); }
    if (st.cur) {                                     // ochiq kanal endi ko'rinmasa (shaxsiy qilingan/o'chirilgan) — ro'yxatga qaytamiz
      const fresh = st.list.find(c => c.id === st.cur.id);
      if (!fresh) { B.toast("Kanal endi mavjud emas yoki sizga yopilgan", "warn"); backToList(false); }
      else { st.cur = fresh; renderHead(); }
    }
    renderList(); updateBadge();
  }
  function renderList() {
    if (!ov) return;
    const h = B.h;
    st.addBtn.classList.toggle("hidden", !admin());
    listEl.textContent = "";
    if (!st.list.length) {
      listEl.append(h("div", {class: "ch-none"}, B.icon("megaphone", "ic ch-none-ic"),
        h("div", {text: "Hozircha kanallar yo'q"}),
        h("small", {text: admin() ? "Yuqoridagi «+» tugmasi bilan kanal yarating." : "Shaxsiy kanalga qo'shilish uchun qulf tugmasini bosing."})));
      return;
    }
    st.list.forEach(c => {
      const n = st.unread.get(c.id) || 0;
      const sub = "@" + c.username + " · " + c.posts + " post" + (c.private ? " · shaxsiy" : "");
      listEl.append(h("button", {class: "ch-item", type: "button", onclick: () => openChannel(c)},
        chAvatar(c, "l"),
        h("div", {class: "ch-meta"},
          h("div", {class: "ch-name"}, h("span", {text: c.nickname}), c.private ? lockIc() : null),
          h("div", {class: "ch-sub", text: sub})),
        n ? h("span", {class: "pill", text: n > 99 ? "99+" : String(n)}) : null));
    });
  }
  function updateBadge() {
    let t = 0; st.unread.forEach(v => { t += v; });
    const b = document.getElementById("chnBadge");
    if (b) { b.classList.toggle("hidden", !t); b.textContent = t > 99 ? "99+" : String(t); }
  }

  /* ---------------- 2-daraja: kanal ---------------- */
  function renderHead() {
    const c = st.cur, h = B.h;
    headEl.textContent = "";
    headEl.append(
      h("button", {class: "icon-btn", type: "button", "aria-label": "Orqaga", onclick: () => backToList(false)}, B.icon("back")),
      chAvatar(c, "m"),
      h("div", {class: "ch-title"}, h("b", {}, c.nickname, c.private ? lockIc() : null),
        h("small", {text: "@" + c.username + (c.private ? " · shaxsiy" : " · ommaviy") + (c.can_manage && c.private ? " · " + (c.members || 0) + " a'zo" : "")})));
    if (c.can_manage) headEl.append(h("button", {class: "icon-btn", type: "button", "aria-label": "Kanal sozlamalari", title: "Kanal sozlamalari", onclick: () => formModal(c)}, B.icon("edit")));
    else if (c.private && c.joined) headEl.append(h("button", {class: "icon-btn", type: "button", "aria-label": "Kanaldan chiqish", title: "Kanaldan chiqish", onclick: leaveChannel}, B.icon("logout")));
    composer.classList.toggle("hidden", !c.can_manage);
  }
  function openChannel(c) {
    st.cur = c; st.posts = []; st.more = false; st.cards.clear(); st.sent.clear(); st.pend.clear();
    st.unread.delete(c.id); updateBadge(); renderList();
    listView.classList.add("hidden"); chView.classList.remove("hidden");
    B.navPush("chn2");
    renderHead();
    postsEl.textContent = ""; postsEl.append(st.moreBtn); st.moreBtn.classList.add("hidden");
    loadPosts(false);
  }
  function backToList(fromNav) {
    if (!st.cur) return;
    hideComments(true);
    st.cur = null; clearTimeout(st.timer); if (st.io) { st.io.disconnect(); st.io = null; }
    chView.classList.add("hidden"); listView.classList.remove("hidden");
    if (!fromNav) B.navPop("chn2");
    renderList();
  }
  async function leaveChannel() {
    const c = st.cur; if (!c) return;
    if (!await B.confirmDlg("Kanaldan chiqsangiz, qayta qo'shilish uchun username va parol kerak bo'ladi.", {title: "Kanaldan chiqish", okText: "Chiqish", danger: true})) return;
    try { await B.api("/channels/" + c.id + "/leave", {method: "POST"}); backToList(false); loadList(); } catch (err) { fail(err); }
  }

  async function loadPosts(older) {
    const c = st.cur; if (!c) return;
    const first = st.posts.length ? st.posts[0].id : 0;
    try {
      const j = await B.api("/channels/" + c.id + "/posts" + (older && first ? "?before=" + first : ""));
      if (!st.cur || st.cur.id !== c.id) return;
      st.more = j.more; st.moreBtn.classList.toggle("hidden", !j.more);
      if (older) {
        const prevH = postsEl.scrollHeight, prevT = postsEl.scrollTop;
        st.posts = j.posts.concat(st.posts);
        renderPosts();
        postsEl.scrollTop = prevT + (postsEl.scrollHeight - prevH);
      } else { st.posts = j.posts; renderPosts(); scrollBottom(postsEl); }
    } catch (err) { fail(err); }
  }
  function renderPosts() {
    const h = B.h;
    [...postsEl.children].forEach(ch => { if (ch !== st.moreBtn) ch.remove(); });
    st.cards.clear();
    if (st.io) st.io.disconnect();
    st.io = new IntersectionObserver(es => {
      es.forEach(e => {
        const id = +e.target.dataset.id;
        if (e.isIntersecting && !st.sent.has(id) && !document.hidden) { st.pend.add(id); scheduleViews(); }
      });
    }, {root: postsEl, threshold: 0.5});
    let lastDay = "";
    st.posts.forEach(p => {
      const day = B.dayLabel(p.ts);
      if (day !== lastDay) { postsEl.append(h("div", {class: "ch-day", text: day})); lastDay = day; }
      postsEl.append(card(p));
    });
    if (!st.posts.length) postsEl.append(h("div", {class: "ch-none sm", "data-empty": "1", text: "Hozircha postlar yo'q"}));
  }
  function card(p) {
    const h = B.h, c = st.cur;
    const text = h("div", {class: "ch-ptext", text: p.text});
    const views = h("span", {class: "ch-views", title: "Ko'rishlar soni"}, B.icon("eye"), h("b", {text: String(p.views)}));
    const when = h("span", {class: "ch-when", text: B.hhmm(p.ts) + (p.edited ? " · tahrirlangan" : "")});
    const acts = c.can_manage ? h("span", {class: "ch-pacts"},
      h("button", {class: "icon-btn sm", type: "button", "aria-label": "Tahrirlash", onclick: () => editPost(p)}, B.icon("edit")),
      h("button", {class: "icon-btn sm", type: "button", "aria-label": "O'chirish", onclick: () => deletePost(p)}, B.icon("trash"))) : null;
    const cm = h("button", {class: "ch-pcom", type: "button", onclick: () => openComments(p)}, B.icon("chat"), h("span"));
    const el = h("article", {class: "ch-post", "data-id": String(p.id)}, text, h("div", {class: "ch-pmeta"}, views, when, acts), cm);
    const refs = {el, text, views: views.querySelector("b"), when, cm: cm.querySelector("span")};
    st.cards.set(p.id, refs); paintCard(p, refs);
    st.io.observe(el);
    return el;
  }
  function paintCard(p, r) {
    r = r || st.cards.get(p.id); if (!r) return;
    r.text.textContent = p.text; r.views.textContent = String(p.views);
    r.when.textContent = B.hhmm(p.ts) + (p.edited ? " · tahrirlangan" : "");
    r.cm.textContent = p.comments ? p.comments + " ta komment" : "Komment yozish";
  }
  const byId = id => st.posts.find(p => p.id === id);

  function scheduleViews() {
    if (st.timer) return;
    st.timer = setTimeout(async () => {
      st.timer = 0;
      const c = st.cur; if (!c || !st.pend.size) return;
      const ids = [...st.pend]; st.pend.clear(); ids.forEach(i => st.sent.add(i));
      try { await B.api("/channels/" + c.id + "/views", {method: "POST", body: {ids}}); } catch (_) { ids.forEach(i => st.sent.delete(i)); }
    }, 1200);
  }

  async function sendPost(ta) {
    const c = st.cur, text = ta.value.trim(); if (!c || !text) return;
    ta.disabled = true;
    try {
      await B.api("/channels/" + c.id + "/posts", {method: "POST", body: {text}});
      ta.value = ""; ta.style.height = "auto";             // post WebSocket hodisasi bilan ham, shu yerda ham chiqadi (takrorlanmaydi)
    } catch (err) { fail(err); }
    ta.disabled = false; ta.focus();
  }
  async function editPost(p) {
    const t = await B.promptDlg("Postni tahrirlash", "Yangi matn:", p.text, {okText: "Saqlash"});
    if (t === null || !t.trim() || t === p.text) return;
    try { await B.api("/channels/" + st.cur.id + "/posts/" + p.id, {method: "PATCH", body: {text: t}}); } catch (err) { fail(err); }
  }
  async function deletePost(p) {
    if (!await B.confirmDlg("Post va uning barcha kommentlari o'chiriladi.", {title: "Postni o'chirish", okText: "O'chirish", danger: true})) return;
    try { await B.api("/channels/" + st.cur.id + "/posts/" + p.id, {method: "DELETE"}); } catch (err) { fail(err); }
  }

  /* ---------------- 3-daraja: kommentlar ---------------- */
  async function openComments(p) {
    st.cm = {post: p, items: [], more: false};
    cmEl.classList.remove("hidden"); B.navPush("chn3");
    cmInput.value = ""; cmInput.style.height = "auto";
    renderComments();
    await loadComments(false);
    scrollBottom(cmBody);
  }
  function hideComments(fromNav) {
    if (!st.cm) return;
    st.cm = null; cmEl.classList.add("hidden");
    if (!fromNav) B.navPop("chn3");
  }
  async function loadComments(older) {
    const m = st.cm; if (!m || !st.cur) return;
    const first = m.items.length ? m.items[0].id : 0;
    try {
      const j = await B.api("/channels/" + st.cur.id + "/posts/" + m.post.id + "/comments" + (older && first ? "?before=" + first : ""));
      if (st.cm !== m) return;
      m.more = j.more; m.items = older ? j.comments.concat(m.items) : j.comments;
      const prevH = cmBody.scrollHeight, prevT = cmBody.scrollTop;
      renderComments();
      if (older) cmBody.scrollTop = prevT + (cmBody.scrollHeight - prevH);
    } catch (err) { fail(err); }
  }
  function renderComments() {
    const m = st.cm; if (!m) return;
    const h = B.h, me = B.me();
    cmBody.textContent = "";
    cmBody.append(h("div", {class: "ch-cmpost"}, h("div", {class: "ch-cmpost-t", text: m.post.text.length > 400 ? m.post.text.slice(0, 400) + "…" : m.post.text}),
      h("small", {text: st.cur.nickname + " · " + B.hhmm(m.post.ts)})));
    if (m.more) cmBody.append(h("button", {class: "btn ghost sm ch-more", type: "button", text: "Oldingi kommentlar", onclick: () => loadComments(true)}));
    cmList = h("div", {class: "ch-cmlist"});
    m.items.forEach(c => cmList.append(commentEl(c, me)));
    if (!m.items.length) cmList.append(h("div", {class: "ch-none sm", text: "Hali komment yo'q. Birinchi bo'ling!"}));
    cmBody.append(cmList);
    const cnt = document.getElementById("chCmCount"); if (cnt) cnt.textContent = (m.post.comments || m.items.length) + " ta";
  }
  function commentEl(c, me) {
    const h = B.h, own = me && c.user.id === me.id;
    const del = (own || admin()) ? h("button", {class: "icon-btn sm", type: "button", "aria-label": "O'chirish", onclick: () => delComment(c)}, B.icon("trash")) : null;
    return h("div", {class: "ch-cm-i", "data-id": String(c.id)}, B.avatar(c.user, "s"),
      h("div", {class: "ch-cm-b"},
        h("div", {class: "ch-cm-h"}, B.nameEl(c.user, {colored: true}), h("small", {text: B.hhmm(c.ts)}), del),
        h("div", {class: "ch-cm-t", text: c.text})));
  }
  async function sendComment() {
    const m = st.cm, text = cmInput.value.trim(); if (!m || !text || !st.cur) return;
    cmInput.disabled = true;
    try {
      await B.api("/channels/" + st.cur.id + "/posts/" + m.post.id + "/comments", {method: "POST", body: {text}});
      cmInput.value = ""; cmInput.style.height = "auto";
    } catch (err) { fail(err); }
    cmInput.disabled = false; cmInput.focus();
  }
  async function delComment(c) {
    const m = st.cm; if (!m) return;
    if (!await B.confirmDlg("Komment o'chirilsinmi?", {title: "Kommentni o'chirish", okText: "O'chirish", danger: true})) return;
    try { await B.api("/channels/" + st.cur.id + "/posts/" + m.post.id + "/comments/" + c.id, {method: "DELETE"}); } catch (err) { fail(err); }
  }

  /* ---------------- admin va qo'shilish oynalari ---------------- */
  function formModal(ch) {
    const h = B.h, editing = !!ch;
    B.openModal(() => {
      const nick = h("input", {type: "text", class: "fld", maxlength: "40", placeholder: "Masalan: Yangiliklar"}); nick.value = ch ? ch.nickname : "";
      const user = h("input", {type: "text", class: "fld", maxlength: "20", autocapitalize: "none", autocorrect: "off", spellcheck: "false", placeholder: "kanal_nomi"}); user.value = ch ? ch.username : "";
      const priv = h("input", {type: "checkbox", id: "chPriv"}); priv.checked = ch ? ch.private : false;
      const pw = h("input", {type: "password", class: "fld", maxlength: "64", autocomplete: "new-password", placeholder: editing && ch.private ? "Bo'sh qoldirsangiz o'zgarmaydi" : "Kamida 4 belgi"});
      const pwWrap = h("label", {class: "fl"}, "Kanal paroli", pw);
      const hint = h("div", {class: "hint", text: ""});
      const file = h("input", {type: "file", accept: "image/png,image/jpeg,image/webp,image/gif", class: "hidden"});
      const picked = h("small", {class: "ch-picked", text: ch && ch.avatar ? "Hozirgi rasm saqlanadi" : "Rasm tanlanmagan"});
      file.addEventListener("change", () => {
        const f = file.files[0];
        if (f && f.size > 2 * 1024 * 1024) { B.toast("Rasm 2 MB dan oshmasligi kerak", "error"); file.value = ""; picked.textContent = "Rasm tanlanmagan"; return; }
        picked.textContent = f ? f.name : "Rasm tanlanmagan";
      });
      const sync = () => {
        pwWrap.classList.toggle("hidden", !priv.checked);
        hint.textContent = priv.checked
          ? "Shaxsiy kanal ro'yxatda ko'rinmaydi: faqat adminlar ko'radi. Boshqalar kanal username'i va shu parol bilan qo'shiladi."
          : "Ommaviy kanalni barcha a'zolar ko'radi, o'qiydi va komment yoza oladi.";
      };
      priv.addEventListener("change", sync); sync();
      const save = async btn => {
        btn.disabled = true;
        try {
          const body = {nickname: nick.value, username: user.value, private: priv.checked};
          if (priv.checked && pw.value) body.password = pw.value;
          const j = await B.api(editing ? "/channels/" + ch.id : "/channels", {method: editing ? "PATCH" : "POST", body});
          let saved = j.channel;
          if (file.files[0]) { const fd = new FormData(); fd.append("file", file.files[0]); saved = (await B.api("/channels/" + saved.id + "/avatar", {method: "POST", body: fd})).channel; }
          B.closeModal(); B.toast(editing ? "Kanal saqlandi" : "Kanal yaratildi", "ok");
          if (st.cur && st.cur.id === saved.id) { st.cur = saved; renderHead(); }
          loadList();
        } catch (err) { fail(err); }
        btn.disabled = false;
      };
      const saveBtn = h("button", {class: "btn ch-wide", type: "button", text: editing ? "Saqlash" : "Kanal yaratish", onclick: e => save(e.currentTarget)});
      const removeAv = editing && ch.avatar ? h("button", {class: "btn ghost sm", type: "button", text: "Rasmni olib tashlash", onclick: async () => {
        try { const j = await B.api("/channels/" + ch.id + "/avatar", {method: "DELETE"}); ch.avatar = null; picked.textContent = "Rasm yo'q"; if (st.cur && st.cur.id === ch.id) { st.cur = j.channel; renderHead(); } loadList(); } catch (err) { fail(err); }
      }}) : null;
      const del = editing ? h("div", {class: "setsec"}, h("button", {class: "btn ghost dangerline", type: "button", text: "Kanalni o'chirish", onclick: async () => {
        if (!await B.confirmDlg("Kanal, uning barcha postlari va kommentlari butunlay o'chiriladi. Buni qaytarib bo'lmaydi.", {title: "Kanalni o'chirish", okText: "O'chirish", danger: true})) return;
        try { await B.api("/channels/" + ch.id, {method: "DELETE"}); B.closeModal(); B.toast("Kanal o'chirildi", "ok"); if (st.cur && st.cur.id === ch.id) backToList(false); loadList(); } catch (err) { fail(err); }
      }})) : null;
      return h("div", {}, B.sheetHead(editing ? "Kanal sozlamalari" : "Yangi kanal"),
        h("div", {class: "sh-body"},
          h("label", {class: "fl"}, "Kanal nomi (nickname)", nick),
          h("label", {class: "fl"}, "Kanal username'i", user),
          h("div", {class: "fl"}, "Kanal rasmi", h("div", {class: "ch-pick"}, h("button", {class: "btn ghost sm", type: "button", onclick: () => file.click()}, B.icon("camera", "ic vb"), " Rasm tanlash"), removeAv, picked), file),
          h("label", {class: "ch-chk"}, priv, h("span", {text: " Shaxsiy kanal (yashirin)"})),
          pwWrap, hint, saveBtn, del));
    }, false);
  }
  function joinModal() {
    const h = B.h;
    B.openModal(() => {
      const user = h("input", {type: "text", class: "fld", maxlength: "21", autocapitalize: "none", autocorrect: "off", spellcheck: "false", placeholder: "@kanal_nomi"});
      const pw = h("input", {type: "password", class: "fld", maxlength: "64", autocomplete: "off", placeholder: "Kanal paroli"});
      const go = async btn => {
        btn.disabled = true;
        try {
          const j = await B.api("/channels/join", {method: "POST", body: {username: user.value, password: pw.value}});
          B.closeModal(); B.toast("Kanalga qo'shildingiz", "ok");
          await loadList(); const c = st.list.find(x => x.id === j.channel.id); if (c) openChannel(c);
        } catch (err) { fail(err); }
        btn.disabled = false;
      };
      return h("div", {}, B.sheetHead("Shaxsiy kanalga qo'shilish"), h("div", {class: "sh-body"},
        h("div", {class: "hint", text: "Shaxsiy kanallar ro'yxatda ko'rinmaydi. Admin bergan kanal username'i va parolini kiriting."}),
        h("label", {class: "fl"}, "Kanal username'i", user), h("label", {class: "fl"}, "Parol", pw),
        h("button", {class: "btn ch-wide", type: "button", text: "Qo'shilish", onclick: e => go(e.currentTarget)})));
    }, false);
  }

  /* ---------------- ochish/yopish ---------------- */
  function open() {
    if (!ov) build();
    if (!ov.classList.contains("hidden")) return;
    ov.classList.remove("hidden"); listView.classList.remove("hidden"); chView.classList.add("hidden"); cmEl.classList.add("hidden");
    B.navPush("chn1");
    renderList(); loadList();
  }
  function closeOverlay(fromNav) {
    if (!ov || ov.classList.contains("hidden")) return;
    hideComments(true);
    if (st.cur) { st.cur = null; clearTimeout(st.timer); if (st.io) { st.io.disconnect(); st.io = null; } if (!fromNav) B.navPop("chn2"); }
    ov.classList.add("hidden");
    if (!fromNav) B.navPop("chn1");
  }
  /** Orqaga tugmasi/jesti (app.js navigatsiyasi) shu yerga keladi */
  function nav(level) {
    if (level === 3) hideComments(true);
    else if (level === 2) backToList(true);
    else closeOverlay(true);
  }
  /** Chiqishda (showAuth): hamma narsa tozalanadi */
  function reset() {
    if (ov) { ov.classList.add("hidden"); if (st.io) st.io.disconnect(); }
    clearTimeout(st.timer); st.timer = 0;
    st.list = []; st.cur = null; st.posts = []; st.cm = null; st.cards.clear(); st.unread.clear(); st.sent.clear(); st.pend.clear();
    updateBadge();
  }

  /* ---------------- real vaqt hodisalari ---------------- */
  function onEvent(m) {
    if (!B) return false;
    const cur = st.cur && m.ch === st.cur.id ? st.cur : null;
    switch (m.type) {
      case "channels_changed": loadList(); return true;
      case "channel_post": {
        const c = st.list.find(x => x.id === m.ch);
        if (c) { c.posts++; c.last_post = m.post.id; st.list.sort((a, b) => (b.id === m.ch) - (a.id === m.ch)); }
        const mine = !!(B.me() && m.post.by === B.me().id);
        if (cur) {
          if (st.posts.some(p => p.id === m.post.id)) return true;
          const stick = nearBottom(postsEl);
          st.posts.push(m.post);
          postsEl.querySelectorAll("[data-empty]").forEach(e => e.remove());
          const day = B.dayLabel(m.post.ts), prev = st.posts[st.posts.length - 2];
          if (!prev || B.dayLabel(prev.ts) !== day) postsEl.append(B.h("div", {class: "ch-day", text: day}));
          postsEl.append(card(m.post));
          if (stick || admin()) scrollBottom(postsEl);
        } else if (!mine) { st.unread.set(m.ch, (st.unread.get(m.ch) || 0) + 1); }
        if (!ov || ov.classList.contains("hidden") || !cur) { renderList(); updateBadge(); }
        return true; }
      case "channel_post_edited": {
        const p = byId(m.post.id); if (p) { Object.assign(p, m.post); paintCard(p); if (st.cm && st.cm.post.id === p.id) st.cm.post = p; }
        return true; }
      case "channel_post_deleted": {
        const c = st.list.find(x => x.id === m.ch); if (c && c.posts > 0) c.posts--;
        if (cur) {
          st.posts = st.posts.filter(p => p.id !== m.id);
          const r = st.cards.get(m.id); if (r) { r.el.remove(); st.cards.delete(m.id); }
          if (st.cm && st.cm.post.id === m.id) { hideComments(false); B.toast("Post o'chirildi", "info"); }
        }
        return true; }
      case "channel_views": {
        if (cur) Object.entries(m.views).forEach(([id, n]) => { const p = byId(+id); if (p) { p.views = n; paintCard(p); } });
        return true; }
      case "channel_comment": {
        const p = byId(m.post);
        if (p) { p.comments = m.count; paintCard(p); }
        if (st.cm && cur && st.cm.post.id === m.post && !st.cm.items.some(i => i.id === m.comment.id)) {
          const stick = nearBottom(cmBody);
          st.cm.post.comments = m.count; st.cm.items.push(m.comment);
          cmList.querySelectorAll(".ch-none").forEach(e => e.remove());
          cmList.append(commentEl(m.comment, B.me()));
          const cnt = document.getElementById("chCmCount"); if (cnt) cnt.textContent = m.count + " ta";
          if (stick || (B.me() && m.comment.user.id === B.me().id)) scrollBottom(cmBody);
        }
        return true; }
      case "channel_comment_deleted": {
        const p = byId(m.post); if (p) { p.comments = m.count; paintCard(p); }
        if (st.cm && cur && st.cm.post.id === m.post) {
          st.cm.items = st.cm.items.filter(i => i.id !== m.id); st.cm.post.comments = m.count;
          const el = cmList.querySelector('[data-id="' + m.id + '"]'); if (el) el.remove();
          const cnt = document.getElementById("chCmCount"); if (cnt) cnt.textContent = m.count + " ta";
        }
        return true; }
    }
    return false;
  }

  window.Channels = {
    init(bridge) { B = bridge; if (!ov) build(); st.addBtn.classList.toggle("hidden", !admin()); },
    open, nav, reset, onEvent, loadList,
    openById(id) { loadList().then(() => { const c = st.list.find(x => x.id === id); if (c) { open(); openChannel(c); } }); },
  };
})();
