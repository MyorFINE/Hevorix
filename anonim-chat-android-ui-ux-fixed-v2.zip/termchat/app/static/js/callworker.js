/* Anonim Chat — qo'ng'iroq audio kadrlarini shifrlash/ochish (RTCRtpScriptTransform ishchisi). Kalit yo'q bo'lsa kadrlar TASHLANADI. */
"use strict";
importScripts("/static/js/callcrypto.js");
let send = null, recv = null;
self.onmessage = e => {
  const d = e.data || {};
  if (d.type === "keys") { send = CallCrypto.makeCipher(d.send); recv = CallCrypto.makeCipher(d.recv); }
  else if (d.type === "wipe") { send = recv = null; }
};
self.onrtctransform = ev => {
  const t = ev.transformer, op = t.options && t.options.operation;
  t.readable.pipeThrough(CallCrypto.makeTransform(() => (op === "encrypt" ? send : recv), op)).pipeTo(t.writable);
};
