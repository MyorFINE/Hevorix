
"use strict";
(root => {
const MAX_SEC = 60, MIN_SEC = 1, SIZE = 480, FPS = 30, VIDEO_BPS = 1000000, THUMB = 40;
const VMIMES = ["video/webm;codecs=vp8", "video/webm", "video/mp4;codecs=avc1.42E01E", "video/mp4"];
const MAGIC = [0x56, 0x4e, 0x30, 0x31];
const HEAD = 12;

function pack(video, audio) {
  const v = video instanceof Uint8Array ? video : new Uint8Array(video), a = audio ? (audio instanceof Uint8Array ? audio : new Uint8Array(audio)) : new Uint8Array(0);
  if (!v.length) throw new Error("video bo'sh");
  const out = new Uint8Array(HEAD + v.length + a.length), dv = new DataView(out.buffer);
  out.set(MAGIC, 0); dv.setUint32(4, v.length); dv.setUint32(8, a.length);
  out.set(v, HEAD); out.set(a, HEAD + v.length);
  return out;
}
function unpack(bytes) {
  const b = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  if (b.length < HEAD + 1 || MAGIC.some((x, i) => b[i] !== x)) throw new Error("video xabar formati noto'g'ri");
  const dv = new DataView(b.buffer, b.byteOffset, b.byteLength), vl = dv.getUint32(4), al = dv.getUint32(8);
  if (vl < 1 || vl + al !== b.length - HEAD) throw new Error("video xabar buzilgan");
  return {video: b.subarray(HEAD, HEAD + vl), audio: al ? b.subarray(HEAD + vl) : null};
}

const vcons = (facing, exact, deviceId) => {
  const v = {width: {ideal: 720}, height: {ideal: 720}, frameRate: {ideal: FPS, max: FPS}};
  if (deviceId) v.deviceId = {exact: deviceId}; else v.facingMode = exact ? {exact: facing} : {ideal: facing};
  return v;
};
const ACONS = {echoCancellation: true, noiseSuppression: true, autoGainControl: true, channelCount: 1};

function camError(e) {
  const n = e && e.name;
  return new Error(n === "NotAllowedError" || n === "SecurityError" ? "Kamera yoki mikrofonga ruxsat berilmagan. Brauzer sozlamalaridan ruxsat bering"
    : n === "NotFoundError" || n === "OverconstrainedError" ? "Kamera topilmadi"
    : n === "NotReadableError" || n === "AbortError" ? "Kamera band (boshqa ilova ishlatayotgan bo'lishi mumkin)" : "Kamerani ochib bo'lmadi");
}

function makeThumb(cv) {
  try {
    const t = root.document.createElement("canvas"); t.width = t.height = THUMB;
    t.getContext("2d").drawImage(cv, 0, 0, THUMB, THUMB);
    return t.toDataURL("image/jpeg", 0.5);
  } catch (_) { return null; }
}

async function record({facing = "user", preview, onLimit, onLost} = {}) {
  if (!root.isSecureContext) throw new Error("Kamera faqat HTTPS (xavfsiz ulanish) orqali ishlaydi");
  const md = root.navigator && root.navigator.mediaDevices, doc = root.document;
  if (!md || !md.getUserMedia || !root.MediaRecorder) throw new Error("Brauzeringiz video yozishni qo'llamaydi");
  if (!root.HTMLCanvasElement || !root.HTMLCanvasElement.prototype.captureStream) throw new Error("Brauzeringiz dumaloq video yozishni qo'llamaydi");

  let stream;
  try { stream = await md.getUserMedia({audio: ACONS, video: vcons(facing, false)}); }
  catch (e) {
    if (e && (e.name === "NotFoundError" || e.name === "OverconstrainedError")) {
      try { stream = await md.getUserMedia({video: vcons(facing, false)}); } catch (e2) { throw camError(e2); }
    } else throw camError(e);
  }
  const aTracks = stream.getAudioTracks();
  let vstream = new MediaStream(stream.getVideoTracks());
  const astream = aTracks.length ? new MediaStream(aTracks) : null;
  const killAll = () => { [vstream, astream, stream].forEach(s => { if (s) s.getTracks().forEach(t => { t.onended = null; try { t.stop(); } catch (_) {} }); }); };

  const v = preview || doc.createElement("video");
  v.muted = true; v.playsInline = true; v.setAttribute("playsinline", ""); v.setAttribute("webkit-playsinline", ""); v.srcObject = vstream;
  try { await v.play(); } catch (_) {}
  await new Promise(res => { if (v.videoWidth) return res(); const t = setTimeout(res, 2500); v.onloadedmetadata = () => { clearTimeout(t); res(); }; });
  if (!v.videoWidth) { killAll(); v.srcObject = null; throw new Error("Kamera kadr bermadi"); }

  const cv = doc.createElement("canvas"); cv.width = cv.height = SIZE;
  const cx = cv.getContext("2d", {alpha: false}); cx.fillStyle = "#000"; cx.fillRect(0, 0, SIZE, SIZE);
  let raf = 0, stopped = false;
  const draw = () => {
    if (stopped) return;
    if (v.readyState >= 2 && v.videoWidth > 0) { const w = v.videoWidth, hh = v.videoHeight, s = Math.min(w, hh); cx.drawImage(v, (w - s) / 2, (hh - s) / 2, s, s, 0, 0, SIZE, SIZE); }
    raf = root.requestAnimationFrame(draw);
  };
  draw();

  const vmime = VMIMES.find(t => root.MediaRecorder.isTypeSupported && root.MediaRecorder.isTypeSupported(t)) || "";
  let vrec, arec = null;
  try {
    vrec = new root.MediaRecorder(cv.captureStream(FPS), Object.assign({videoBitsPerSecond: VIDEO_BPS}, vmime ? {mimeType: vmime} : {}));
  } catch (_) { stopped = true; root.cancelAnimationFrame(raf); killAll(); v.srcObject = null; throw new Error("Video yozishni boshlab bo'lmadi"); }

  let discard = false, failed = false, timer = 0, flipping = false, lastDevice = "";
  const lost = () => { if (!discard && !stopped && onLost) onLost(); };
  const chunks = [];
  vrec.ondataavailable = e => { if (e.data && e.data.size) chunks.push(e.data); };
  vrec.onerror = () => { failed = true; lost(); };
  let vres; const vdone = new Promise(res => { vres = res; });
  const vfinal = () => vres(discard || failed ? null : new Blob(chunks.splice(0), {type: vrec.mimeType || vmime || "video/webm"}));
  vrec.onstop = vfinal;
  const vstop = () => { try { if (vrec.state !== "inactive") vrec.stop(); else vfinal(); } catch (_) { vfinal(); } };

  let canFlip = true;
  try { canFlip = (await md.enumerateDevices()).filter(d => d.kind === "videoinput").length > 1; } catch (_) {}

  if (astream) {
    try { arec = await root.Voice.record({stream: astream, onLost: lost, maxSec: MAX_SEC + 30}); }
    catch (_) { arec = null; }
  }
  const trackOf = () => vstream.getVideoTracks()[0], setOf = () => { try { return trackOf().getSettings() || {}; } catch (_) { return {}; } };
  const watch = () => { const t = trackOf(); if (t) t.onended = () => { if (!flipping) lost(); }; };
  let facingNow = setOf().facingMode || facing; lastDevice = setOf().deviceId || ""; watch();

  const t0 = root.performance.now();
  vrec.start(500);
  timer = setTimeout(() => { if (onLimit) onLimit(); }, MAX_SEC * 1000);

  const release = () => {
    stopped = true; clearTimeout(timer); root.cancelAnimationFrame(raf);
    killAll(); try { v.pause(); } catch (_) {} v.srcObject = null;
  };

  async function flip() {
    if (flipping || stopped) return false;
    flipping = true;
    const want = facingNow === "user" ? "environment" : "user", old = vstream;
    old.getTracks().forEach(t => { t.onended = null; t.stop(); });
    let ns = null, ok = true;
    try { ns = await md.getUserMedia({video: vcons(want, true)}); }
    catch (_) {
      try {
        const devs = (await md.enumerateDevices()).filter(d => d.kind === "videoinput");
        if (devs.length > 1) {
          const i = devs.findIndex(d => d.deviceId === lastDevice), next = devs[(i + 1) % devs.length];
          ns = await md.getUserMedia({video: vcons(want, false, next.deviceId)});
        }
      } catch (_) {}
    }
    if (!ns) {
      ok = false;
      try { ns = await md.getUserMedia({video: vcons(facingNow, false, lastDevice || "")}); }
      catch (_) { try { ns = await md.getUserMedia({video: vcons(facingNow, false)}); } catch (_2) { ns = null; } }
    }
    if (stopped) { if (ns) ns.getTracks().forEach(t => t.stop()); flipping = false; return false; }
    if (!ns) { flipping = false; lost(); return false; }
    vstream = new MediaStream(ns.getVideoTracks()); v.srcObject = vstream;
    try { await v.play(); } catch (_) {}
    const st = setOf(); lastDevice = st.deviceId || lastDevice;
    if (ok) facingNow = st.facingMode || want;
    watch(); flipping = false;
    return ok;
  }

  const elapsed = () => (root.performance.now() - t0) / 1000;

  return {
    elapsed, facing: () => facingNow, canFlip, flip, maxSec: MAX_SEC,
    stop: async () => {
      if (stopped) return null;
      const duration = elapsed(), thumb = makeThumb(cv);
      root.cancelAnimationFrame(raf); stopped = true;
      const ap = arec ? arec.stop() : Promise.resolve(null);
      vstop();
      const [video, audio] = await Promise.all([vdone, ap]);
      release();
      if (!video || !video.size) return null;
      return {video, audio, thumb, duration, mime: (video.type || vmime || "video/webm").split(";")[0]};
    },
    cancel: () => {
      discard = true; const ap = arec ? arec.cancel() : Promise.resolve(null);
      stopped = true; root.cancelAnimationFrame(raf); vstop();
      return Promise.all([vdone, ap]).then(() => { release(); return null; });
    },
  };
}

root.VNote = {record, pack, unpack, MAX_SEC, MIN_SEC, SIZE, MAGIC};
})(typeof globalThis !== "undefined" ? globalThis : window);
