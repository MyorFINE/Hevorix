"use strict";
/* =====================================================================
   Xabarlar ro'yxati: ekrandan UZOQDAGI qatorlarni «muzlatish» (virtual ro'yxat)
   IntersectionObserver ekrandan ~2,5 ekran narida turgan xabar qatorlarini topadi va ularga `vs-off` klassini beradi
   (CSS: content-visibility:hidden — brauzer ichini chizmaydi va maketga solmaydi). Qator DOM'dan OLIB TASHLANMAYDI
   va balandligi o'lchab saqlanadi, shuning uchun: scroll balandligi o'zgarmaydi, jumpTo/querySelector/tanlash/reaksiyalar/
   media holati — hammasi avvalgidek ishlaydi. Qator ekranga yaqinlashganda (rootMargin) o'zi qaytadan ochiladi.
   app.js ga TEGILMAYDI: modul `#msgs` ni alohida kuzatadi. Brauzer qo'llamasa yoki o'chirilgan bo'lsa — hech narsa qilmaydi.
   O'chirish: localStorage.ac_vs = "0".
   ===================================================================== */
(() => {
  const box = document.getElementById("msgs");
  if (!box || !("IntersectionObserver" in window) || !("MutationObserver" in window)) return;
  try {
    if (!(window.CSS && CSS.supports && CSS.supports("content-visibility", "hidden"))) return;
    if (localStorage.getItem("ac_vs") === "0") return;
  } catch (_) { /* localStorage yo'q bo'lsa ham ishlayveradi */ }

  const OFF = "vs-off";
  const MARGIN = "250% 0px 250% 0px";                    // ekrandan 2,5 balandlik tepada va pastda qator «jonli» turadi
  let io = null, mo = null, rz = 0, lastW = box.clientWidth;

  const isRow = n => n && n.nodeType === 1 && n.classList.contains("row");

  /* Qatorni muzlatmaslik shartlari: ijro etilayotgan media, fokus, animatsiya, hali o'lchanmagan (ko'rinmas) qator */
  function busy(row) {
    if (row.classList.contains("flash") || row.classList.contains("enter")) return true;
    if (document.activeElement && row.contains(document.activeElement)) return true;
    for (const m of row.querySelectorAll("video,audio")) if (!m.paused) return true;
    return false;
  }

  function freeze(row) {
    if (row.classList.contains(OFF) || !row.isConnected || busy(row)) return;
    const r = row.getBoundingClientRect();
    if (!r.height) return;                                // display:none / hali joylanmagan — o'lchab bo'lmaydi
    const cs = getComputedStyle(row);
    const pad = (parseFloat(cs.paddingTop) || 0) + (parseFloat(cs.paddingBottom) || 0) + (parseFloat(cs.borderTopWidth) || 0) + (parseFloat(cs.borderBottomWidth) || 0);
    row.style.setProperty("--vs-h", Math.max(0, r.height - pad) + "px");
    row.classList.add(OFF);
  }

  function thaw(row) {
    if (!row.classList.contains(OFF)) return;
    row.classList.remove(OFF);
    row.style.removeProperty("--vs-h");
  }

  function onIntersect(entries) {
    for (const e of entries) {
      if (e.isIntersecting) thaw(e.target); else freeze(e.target);
    }
  }

  function watch(row) { if (io) io.observe(row); }
  function unwatch(row) { if (io) io.unobserve(row); thaw(row); }

  function onMutate(records) {
    for (const rec of records) {
      for (const n of rec.removedNodes) { if (isRow(n)) unwatch(n); }
      for (const n of rec.addedNodes) { if (isRow(n)) watch(n); }
    }
  }

  /* Maket o'zgarsa (kenglik, belgilash rejimi) o'lchangan balandliklar eskiradi: hammasini ochib, qayta kuzatamiz */
  function reset() {
    if (!io) return;
    for (const row of box.querySelectorAll(".row")) { io.unobserve(row); thaw(row); io.observe(row); }
  }

  function start() {
    io = new IntersectionObserver(onIntersect, {root: box, rootMargin: MARGIN});
    mo = new MutationObserver(onMutate);
    mo.observe(box, {childList: true});
    for (const row of box.querySelectorAll(".row")) watch(row);

    window.addEventListener("resize", () => {
      clearTimeout(rz);
      rz = setTimeout(() => { const w = box.clientWidth; if (w !== lastW) { lastW = w; reset(); } }, 200);
    }, {passive: true});
    const chat = document.getElementById("chat");
    if (chat) new MutationObserver(() => { reset(); }).observe(chat, {attributes: true, attributeFilter: ["class"]});
  }

  start();
  window.__vlist = {reset, count: () => box.querySelectorAll("." + OFF).length};   // diagnostika/testlar uchun
})();
