
(function (root) {
  "use strict";
  const P = 1, N = 2, B = 3, R = 4, Q = 5, K = 6;
  const FILES = "abcdefgh", LETTER = {1: "p", 2: "n", 3: "b", 4: "r", 5: "q", 6: "k"}, FROM_LETTER = {p: 1, n: 2, b: 3, r: 4, q: 5, k: 6};
  const START_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";
  const sqName = i => FILES[i & 7] + ((i >> 3) + 1);
  const sqIdx = s => (s.charCodeAt(1) - 49) * 8 + s.charCodeAt(0) - 97;

  const KN = [], KG = [], RAYS = [];
  (function () {
    const kn = [[1, 2], [2, 1], [2, -1], [1, -2], [-1, -2], [-2, -1], [-2, 1], [-1, 2]];
    const kg = [[0, 1], [1, 1], [1, 0], [1, -1], [0, -1], [-1, -1], [-1, 0], [-1, 1]];
    const dirs = [[0, 1], [1, 0], [0, -1], [-1, 0], [1, 1], [1, -1], [-1, -1], [-1, 1]];
    for (let s = 0; s < 64; s++) {
      const f = s & 7, r = s >> 3;
      KN[s] = []; KG[s] = []; RAYS[s] = [];
      kn.forEach(([df, dr]) => { const x = f + df, y = r + dr; if (x >= 0 && x < 8 && y >= 0 && y < 8) KN[s].push(y * 8 + x); });
      kg.forEach(([df, dr]) => { const x = f + df, y = r + dr; if (x >= 0 && x < 8 && y >= 0 && y < 8) KG[s].push(y * 8 + x); });
      dirs.forEach(([df, dr]) => { const ray = []; let x = f + df, y = r + dr; while (x >= 0 && x < 8 && y >= 0 && y < 8) { ray.push(y * 8 + x); x += df; y += dr; } RAYS[s].push(ray); });
    }
  })();
  const CR = new Int8Array(64).fill(15);
  CR[4] &= ~3; CR[0] &= ~2; CR[7] &= ~1; CR[60] &= ~12; CR[56] &= ~8; CR[63] &= ~4;

  let seed = 0x9e3779b9;
  const rnd32 = () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0; let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return (t ^ t >>> 14) | 0; };
  const ZP1 = [], ZP2 = [], ZC1 = [], ZC2 = [], ZE1 = [], ZE2 = [];
  for (let p = 0; p < 12; p++) { ZP1.push(new Int32Array(64).map(rnd32)); ZP2.push(new Int32Array(64).map(rnd32)); }
  for (let i = 0; i < 16; i++) { ZC1.push(rnd32()); ZC2.push(rnd32()); }
  for (let i = 0; i < 8; i++) { ZE1.push(rnd32()); ZE2.push(rnd32()); }
  const ZT1 = rnd32(), ZT2 = rnd32();
  const pidx = p => p > 0 ? p - 1 : 5 - p;

  class Pos {
    constructor(fen) {
      this.b = new Int8Array(64); this.turn = 1; this.cast = 0; this.ep = -1; this.half = 0; this.full = 1;
      this.kp = [4, 60]; this.h1 = 0; this.h2 = 0; this.u = []; this.keys = [];
      this.setFen(fen || START_FEN);
    }
    setFen(fen) {
      const parts = String(fen).trim().split(/\s+/);
      if (parts.length < 2) throw new Error("FEN noto'g'ri");
      this.b.fill(0); let r = 7, f = 0, kw = 0, kb = 0;
      for (const c of parts[0]) {
        if (c === "/") { r--; f = 0; continue; }
        if (c >= "1" && c <= "8") { f += +c; continue; }
        const t = FROM_LETTER[c.toLowerCase()]; if (!t || r < 0 || f > 7) throw new Error("FEN noto'g'ri");
        const s = r * 8 + f; this.b[s] = c === c.toLowerCase() ? -t : t;
        if (t === K) { if (c === "K") { this.kp[0] = s; kw++; } else { this.kp[1] = s; kb++; } }
        f++;
      }
      if (kw !== 1 || kb !== 1) throw new Error("FEN: har tomonda bitta shoh bo'lishi kerak");
      this.turn = parts[1] === "b" ? -1 : 1;
      const c = parts[2] || "-"; this.cast = (c.includes("K") ? 1 : 0) | (c.includes("Q") ? 2 : 0) | (c.includes("k") ? 4 : 0) | (c.includes("q") ? 8 : 0);
      this.ep = parts[3] && parts[3] !== "-" ? sqIdx(parts[3]) : -1;
      this.half = Math.max(0, parseInt(parts[4], 10) || 0); this.full = Math.max(1, parseInt(parts[5], 10) || 1);
      this.u = []; this.hash(); this.keys = [this.h1];
    }
    epHashable() {
      if (this.ep < 0) return false;
      const b = this.b, us = this.turn, f = this.ep & 7, base = this.ep - 8 * us;
      return (f > 0 && b[base - 1] === us) || (f < 7 && b[base + 1] === us);
    }
    hash() {
      let a = 0, c = 0;
      for (let s = 0; s < 64; s++) { const p = this.b[s]; if (p) { const i = pidx(p); a ^= ZP1[i][s]; c ^= ZP2[i][s]; } }
      if (this.turn === -1) { a ^= ZT1; c ^= ZT2; }
      a ^= ZC1[this.cast]; c ^= ZC2[this.cast];
      if (this.epHashable()) { a ^= ZE1[this.ep & 7]; c ^= ZE2[this.ep & 7]; }
      this.h1 = a; this.h2 = c;
    }
    fen() {
      let s = "";
      for (let r = 7; r >= 0; r--) {
        let e = 0;
        for (let f = 0; f < 8; f++) {
          const p = this.b[r * 8 + f];
          if (!p) { e++; continue; }
          if (e) { s += e; e = 0; }
          const l = LETTER[Math.abs(p)]; s += p > 0 ? l.toUpperCase() : l;
        }
        if (e) s += e; if (r) s += "/";
      }
      const c = (this.cast & 1 ? "K" : "") + (this.cast & 2 ? "Q" : "") + (this.cast & 4 ? "k" : "") + (this.cast & 8 ? "q" : "");
      return s + " " + (this.turn === 1 ? "w" : "b") + " " + (c || "-") + " " + (this.ep >= 0 ? sqName(this.ep) : "-") + " " + this.half + " " + this.full;
    }
    boardString() {
      let s = ""; for (let i = 0; i < 64; i++) { const p = this.b[i]; s += p ? (p > 0 ? LETTER[p].toUpperCase() : LETTER[-p]) : "."; } return s;
    }
    attacked(sq, by) {
      const b = this.b, f = sq & 7;
      if (by === 1) { if (f > 0 && b[sq - 9] === P) return true; if (f < 7 && b[sq - 7] === P) return true; }
      else { if (f > 0 && b[sq + 7] === -P) return true; if (f < 7 && b[sq + 9] === -P) return true; }
      const kn = KN[sq]; for (let i = 0; i < kn.length; i++) if (b[kn[i]] === by * N) return true;
      const kg = KG[sq]; for (let i = 0; i < kg.length; i++) if (b[kg[i]] === by * K) return true;
      const rays = RAYS[sq];
      for (let d = 0; d < 8; d++) {
        const ray = rays[d];
        for (let i = 0; i < ray.length; i++) {
          const p = b[ray[i]]; if (!p) continue;
          if (p * by > 0) { const t = Math.abs(p); if (t === Q || (d < 4 ? t === R : t === B)) return true; }
          break;
        }
      }
      return false;
    }
    inCheck() { return this.attacked(this.kp[this.turn === 1 ? 0 : 1], -this.turn); }
    gen(caps) {
      const b = this.b, us = this.turn, out = [];
      for (let s = 0; s < 64; s++) {
        const p = b[s]; if (p * us <= 0) continue;
        const t = Math.abs(p);
        if (t === P) {
          const r = s >> 3, f = s & 7, fwd = s + 8 * us, last = us === 1 ? 7 : 0, start = us === 1 ? 1 : 6;
          if (!b[fwd]) {
            if ((fwd >> 3) === last) { for (let q = Q; q >= N; q--) out.push(s | fwd << 6 | q << 12); }
            else if (!caps) { out.push(s | fwd << 6); if (r === start && !b[fwd + 8 * us]) out.push(s | (fwd + 8 * us) << 6 | 8 << 16); }
          }
          for (const df of [-1, 1]) {
            const x = f + df; if (x < 0 || x > 7) continue;
            const to = fwd + df;
            if (b[to] * us < 0) {
              if ((to >> 3) === last) { for (let q = Q; q >= N; q--) out.push(s | to << 6 | q << 12 | 1 << 16); }
              else out.push(s | to << 6 | 1 << 16);
            } else if (to === this.ep && !b[to]) out.push(s | to << 6 | 3 << 16);
          }
        } else if (t === N || t === K) {
          const tg = t === N ? KN[s] : KG[s];
          for (let i = 0; i < tg.length; i++) {
            const to = tg[i], v = b[to];
            if (!v) { if (!caps) out.push(s | to << 6); } else if (v * us < 0) out.push(s | to << 6 | 1 << 16);
          }
          if (t === K && !caps) this.genCastle(out, s, us);
        } else {
          const rays = RAYS[s], from = t === B ? 4 : 0, to2 = t === R ? 4 : 8;
          for (let d = from; d < to2; d++) {
            const ray = rays[d];
            for (let i = 0; i < ray.length; i++) {
              const to = ray[i], v = b[to];
              if (!v) { if (!caps) out.push(s | to << 6); continue; }
              if (v * us < 0) out.push(s | to << 6 | 1 << 16);
              break;
            }
          }
        }
      }
      return out;
    }
    genCastle(out, s, us) {
      const b = this.b, c = this.cast;
      if (us === 1 && s === 4) {
        if ((c & 1) && b[7] === R && !b[5] && !b[6] && !this.attacked(4, -1) && !this.attacked(5, -1)) out.push(4 | 6 << 6 | 4 << 16);
        if ((c & 2) && b[0] === R && !b[3] && !b[2] && !b[1] && !this.attacked(4, -1) && !this.attacked(3, -1)) out.push(4 | 2 << 6 | 4 << 16);
      } else if (us === -1 && s === 60) {
        if ((c & 4) && b[63] === -R && !b[61] && !b[62] && !this.attacked(60, 1) && !this.attacked(61, 1)) out.push(60 | 62 << 6 | 4 << 16);
        if ((c & 8) && b[56] === -R && !b[59] && !b[58] && !b[57] && !this.attacked(60, 1) && !this.attacked(59, 1)) out.push(60 | 58 << 6 | 4 << 16);
      }
    }
    make(m) {
      const b = this.b, f = m & 63, t = (m >> 6) & 63, pr = (m >> 12) & 15, fl = m >> 16, p = b[f], us = this.turn;
      let cap = b[t], capSq = t;
      this.u.push(m, p, 0, this.cast, this.ep, this.half, this.h1, this.h2);
      let a = this.h1, c = this.h2;
      if (this.epHashable()) { a ^= ZE1[this.ep & 7]; c ^= ZE2[this.ep & 7]; }
      a ^= ZC1[this.cast]; c ^= ZC2[this.cast];
      if (fl & 2) { capSq = t - 8 * us; cap = b[capSq]; }
      this.u[this.u.length - 6] = cap;
      if (cap) { const i = pidx(cap); a ^= ZP1[i][capSq]; c ^= ZP2[i][capSq]; b[capSq] = 0; }
      const pi = pidx(p); a ^= ZP1[pi][f]; c ^= ZP2[pi][f]; b[f] = 0;
      const np = pr ? us * pr : p, ni = pidx(np); b[t] = np; a ^= ZP1[ni][t]; c ^= ZP2[ni][t];
      if (fl & 4) {
        const rf = t > f ? f + 3 : f - 4, rt = t > f ? f + 1 : f - 1, ri = pidx(b[rf]);
        a ^= ZP1[ri][rf] ^ ZP1[ri][rt]; c ^= ZP2[ri][rf] ^ ZP2[ri][rt]; b[rt] = b[rf]; b[rf] = 0;
      }
      if (Math.abs(p) === K) this.kp[us === 1 ? 0 : 1] = t;
      this.cast &= CR[f] & CR[t];
      this.ep = (fl & 8) ? (f + t) >> 1 : -1;
      this.half = (Math.abs(p) === P || cap) ? 0 : this.half + 1;
      if (us === -1) this.full++;
      this.turn = -us; a ^= ZT1; c ^= ZT2;
      a ^= ZC1[this.cast]; c ^= ZC2[this.cast];
      if (this.epHashable()) { a ^= ZE1[this.ep & 7]; c ^= ZE2[this.ep & 7]; }
      this.h1 = a; this.h2 = c; this.keys.push(a);
    }
    undo() {
      const u = this.u, n = u.length; if (!n) return;
      const m = u[n - 8], p = u[n - 7], cap = u[n - 6];
      this.cast = u[n - 5]; this.ep = u[n - 4]; this.half = u[n - 3]; this.h1 = u[n - 2]; this.h2 = u[n - 1]; u.length = n - 8; this.keys.pop();
      const b = this.b, f = m & 63, t = (m >> 6) & 63, fl = m >> 16, us = p > 0 ? 1 : -1;
      this.turn = us; if (us === -1) this.full--;
      b[f] = p; b[t] = 0;
      if (fl & 2) b[t - 8 * us] = cap; else if (cap) b[t] = cap;
      if (fl & 4) { const rf = t > f ? f + 3 : f - 4, rt = t > f ? f + 1 : f - 1; b[rf] = b[rt]; b[rt] = 0; }
      if (Math.abs(p) === K) this.kp[us === 1 ? 0 : 1] = f;
    }
    makeNull() {
      this.u.push(0, 0, 0, this.cast, this.ep, this.half, this.h1, this.h2);
      if (this.epHashable()) { this.h1 ^= ZE1[this.ep & 7]; this.h2 ^= ZE2[this.ep & 7]; }
      this.ep = -1; this.turn = -this.turn; this.h1 ^= ZT1; this.h2 ^= ZT2; this.half++; this.keys.push(this.h1);
    }
    undoNull() {
      const u = this.u, n = u.length;
      this.cast = u[n - 5]; this.ep = u[n - 4]; this.half = u[n - 3]; this.h1 = u[n - 2]; this.h2 = u[n - 1]; u.length = n - 8; this.keys.pop(); this.turn = -this.turn;
    }
    legal() {
      const out = [], ps = this.gen(false), us = this.turn, ki = us === 1 ? 0 : 1;
      for (let i = 0; i < ps.length; i++) {
        this.make(ps[i]);
        if (!this.attacked(this.kp[ki], this.turn)) out.push(ps[i]);
        this.undo();
      }
      return out;
    }
    toUci(m) { return sqName(m & 63) + sqName((m >> 6) & 63) + (((m >> 12) & 15) ? LETTER[(m >> 12) & 15] : ""); }
    findUci(u, list) {
      list = list || this.legal(); const f = sqIdx(u.slice(0, 2)), t = sqIdx(u.slice(2, 4)), pr = u[4] ? FROM_LETTER[u[4]] : 0;
      for (const m of list) if ((m & 63) === f && ((m >> 6) & 63) === t && ((m >> 12) & 15) === pr) return m;
      return 0;
    }
    insufficient() {
      let minors = 0, bishopsLight = 0, bishopsDark = 0;
      for (let s = 0; s < 64; s++) {
        const t = Math.abs(this.b[s]); if (!t || t === K) continue;
        if (t === P || t === R || t === Q) return false;
        minors++; if (t === B) { ((s >> 3) + (s & 7)) % 2 ? bishopsLight++ : bishopsDark++; }
      }
      if (minors <= 1) return true;
      return minors === bishopsLight + bishopsDark && (bishopsLight === 0 || bishopsDark === 0);
    }
    repetitions() {
      const k = this.keys, cur = k[k.length - 1]; let n = 1;
      for (let i = k.length - 3, lim = Math.max(0, k.length - 1 - this.half); i >= lim; i -= 2) if (k[i] === cur) n++;
      return n;
    }
    status(list) {
      list = list || this.legal();
      if (!list.length) return this.inCheck() ? {over: true, result: this.turn === 1 ? "b" : "w", reason: "checkmate"} : {over: true, result: "d", reason: "stalemate"};
      if (this.insufficient()) return {over: true, result: "d", reason: "insufficient"};
      if (this.half >= 100) return {over: true, result: "d", reason: "fifty"};
      if (this.repetitions() >= 3) return {over: true, result: "d", reason: "repetition"};
      return {over: false};
    }
  }

  const VAL = [0, 100, 320, 330, 500, 900, 0];

  const PST = {
    1: [0, 0, 0, 0, 0, 0, 0, 0, 50, 50, 50, 50, 50, 50, 50, 50, 10, 10, 20, 30, 30, 20, 10, 10, 5, 5, 10, 25, 25, 10, 5, 5, 0, 0, 0, 20, 20, 0, 0, 0, 5, -5, -10, 0, 0, -10, -5, 5, 5, 10, 10, -20, -20, 10, 10, 5, 0, 0, 0, 0, 0, 0, 0, 0],
    2: [-50, -40, -30, -30, -30, -30, -40, -50, -40, -20, 0, 0, 0, 0, -20, -40, -30, 0, 10, 15, 15, 10, 0, -30, -30, 5, 15, 20, 20, 15, 5, -30, -30, 0, 15, 20, 20, 15, 0, -30, -30, 5, 10, 15, 15, 10, 5, -30, -40, -20, 0, 5, 5, 0, -20, -40, -50, -40, -30, -30, -30, -30, -40, -50],
    3: [-20, -10, -10, -10, -10, -10, -10, -20, -10, 0, 0, 0, 0, 0, 0, -10, -10, 0, 5, 10, 10, 5, 0, -10, -10, 5, 5, 10, 10, 5, 5, -10, -10, 0, 10, 10, 10, 10, 0, -10, -10, 10, 10, 10, 10, 10, 10, -10, -10, 5, 0, 0, 0, 0, 5, -10, -20, -10, -10, -10, -10, -10, -10, -20],
    4: [0, 0, 0, 0, 0, 0, 0, 0, 5, 10, 10, 10, 10, 10, 10, 5, -5, 0, 0, 0, 0, 0, 0, -5, -5, 0, 0, 0, 0, 0, 0, -5, -5, 0, 0, 0, 0, 0, 0, -5, -5, 0, 0, 0, 0, 0, 0, -5, -5, 0, 0, 0, 0, 0, 0, -5, 0, 0, 0, 5, 5, 0, 0, 0],
    5: [-20, -10, -10, -5, -5, -10, -10, -20, -10, 0, 0, 0, 0, 0, 0, -10, -10, 0, 5, 5, 5, 5, 0, -10, -5, 0, 5, 5, 5, 5, 0, -5, 0, 0, 5, 5, 5, 5, 0, -5, -10, 5, 5, 5, 5, 5, 0, -10, -10, 0, 5, 0, 0, 0, 0, -10, -20, -10, -10, -5, -5, -10, -10, -20],
    6: [-30, -40, -40, -50, -50, -40, -40, -30, -30, -40, -40, -50, -50, -40, -40, -30, -30, -40, -40, -50, -50, -40, -40, -30, -30, -40, -40, -50, -50, -40, -40, -30, -20, -30, -30, -40, -40, -30, -30, -20, -10, -20, -20, -20, -20, -20, -20, -10, 20, 20, 0, 0, 0, 0, 20, 20, 20, 30, 10, 0, 0, 10, 30, 20],
  };
  const KEND = [-50, -40, -30, -20, -20, -30, -40, -50, -30, -20, -10, 0, 0, -10, -20, -30, -30, -10, 20, 30, 30, 20, -10, -30, -30, -10, 30, 40, 40, 30, -10, -30, -30, -10, 30, 40, 40, 30, -10, -30, -30, -10, 20, 30, 30, 20, -10, -30, -30, -30, 0, 0, 0, 0, -30, -30, -50, -30, -30, -30, -30, -30, -30, -50];
  const WI = (s) => (7 - (s >> 3)) * 8 + (s & 7), BI = (s) => s;

  function evaluate(pos) {
    const b = pos.b; let score = 0, npm = 0, wb = 0, bb = 0;
    const wp = new Int8Array(8), bp = new Int8Array(8);
    for (let s = 0; s < 64; s++) {
      const p = b[s]; if (!p) continue;
      const t = Math.abs(p);
      if (t !== P && t !== K) npm += VAL[t];
      if (p > 0) { if (t === P) wp[s & 7]++; if (t === B) wb++; } else { if (t === P) bp[s & 7]++; if (t === B) bb++; }
    }
    const endg = npm <= 2600, k0 = pos.kp[0], k1 = pos.kp[1];
    for (let s = 0; s < 64; s++) {
      const p = b[s]; if (!p) continue;
      const t = Math.abs(p), w = p > 0;
      let v = VAL[t] + (t === K ? (endg ? KEND[w ? WI(s) : BI(s)] : PST[6][w ? WI(s) : BI(s)]) : PST[t][w ? WI(s) : BI(s)]);
      if (t === P) {
        const f = s & 7, r = s >> 3, enemy = w ? bp : wp;
        let passed = true;
        for (let df = -1; df <= 1; df++) { const x = f + df; if (x < 0 || x > 7) continue; if (enemy[x]) { passed = false; break; } }
        if (passed) { const adv = w ? r : 7 - r; v += adv * adv * 2 + (endg ? adv * 6 : 0); }
        if ((w ? wp : bp)[f] > 1) v -= 12;
      }
      score += w ? v : -v;
    }
    if (wb >= 2) score += 30; if (bb >= 2) score -= 30;
    if (endg) {
      const dw = Math.abs((k0 & 7) - 3.5) + Math.abs((k0 >> 3) - 3.5), db = Math.abs((k1 & 7) - 3.5) + Math.abs((k1 >> 3) - 3.5);
      if (score > 200) score += Math.round(db * 6); else if (score < -200) score -= Math.round(dw * 6);
    }
    return (pos.turn === 1 ? score : -score) + 8;
  }

  const INF = 32000, MATE = 30000;
  const TT_BITS = 17, TT_SIZE = 1 << TT_BITS, TT_MASK = TT_SIZE - 1;
  class Searcher {
    constructor() {
      this.tk = new Int32Array(TT_SIZE); this.tm = new Int32Array(TT_SIZE); this.ts = new Int16Array(TT_SIZE); this.tf = new Int8Array(TT_SIZE); this.td = new Int8Array(TT_SIZE);
      this.killers = []; for (let i = 0; i < 64; i++) this.killers.push([0, 0]);
      this.hist = new Int32Array(2 * 64 * 64);
    }
    clear() { this.tk.fill(0); this.tf.fill(0); this.hist.fill(0); }
    order(pos, list, ttm, ply) {
      const b = pos.b, sc = new Array(list.length), k = this.killers[ply] || [0, 0], side = pos.turn === 1 ? 0 : 1;
      for (let i = 0; i < list.length; i++) {
        const m = list[i], f = m & 63, t = (m >> 6) & 63, fl = m >> 16, pr = (m >> 12) & 15;
        let s;
        if (m === ttm) s = 1e7;
        else if (fl & 1) s = 1e6 + (fl & 2 ? 100 : VAL[Math.abs(b[t])]) * 10 - VAL[Math.abs(b[f])] / 10 + (pr ? 500 : 0);
        else if (pr) s = 9e5 + pr;
        else if (m === k[0]) s = 8e5; else if (m === k[1]) s = 7e5;
        else s = this.hist[(side * 64 + f) * 64 + t];
        sc[i] = s;
      }
      const idx = list.map((_, i) => i).sort((x, y) => sc[y] - sc[x]);
      return idx.map(i => list[i]);
    }
    tick() {
      if ((++this.nodes & 1023) === 0 && performance.now() > this.deadline) this.stop = true;
      return this.stop;
    }
    quiesce(pos, alpha, beta, ply, qd) {
      if (this.tick()) return 0;
      const stand = evaluate(pos);
      if (stand >= beta) return stand;
      if (qd > 8) return stand;
      if (stand > alpha) alpha = stand;
      const list = this.order(pos, pos.gen(true), 0, 63), us = pos.turn === 1 ? 0 : 1;
      for (let i = 0; i < list.length; i++) {
        const m = list[i];
        if (!((m >> 12) & 15) && stand + VAL[Math.abs(pos.b[(m >> 6) & 63])] + 200 < alpha && !(m >> 16 & 2)) continue;
        pos.make(m);
        if (pos.attacked(pos.kp[us], pos.turn)) { pos.undo(); continue; }
        const v = -this.quiesce(pos, -beta, -alpha, ply + 1, qd + 1);
        pos.undo();
        if (this.stop) return 0;
        if (v >= beta) return v;
        if (v > alpha) alpha = v;
      }
      return alpha;
    }
    search(pos, depth, alpha, beta, ply, nullOk) {
      if (this.stop) return 0;
      if (ply > 0) {
        if (pos.half >= 100) return 0;
        const k = pos.keys, cur = k[k.length - 1];
        for (let i = k.length - 3, lim = Math.max(0, k.length - 1 - pos.half); i >= lim; i -= 2) if (k[i] === cur) return 0;
      }
      const us = pos.turn === 1 ? 0 : 1, check = pos.attacked(pos.kp[us], -pos.turn);
      if (check) depth++;
      if (depth <= 0) return this.quiesce(pos, alpha, beta, ply, 0);
      if (this.tick()) return 0;
      const pv = beta - alpha > 1, slot = pos.h1 & TT_MASK;
      let ttm = 0;
      if (this.tf[slot] && this.tk[slot] === pos.h2) {
        ttm = this.tm[slot];
        if (this.td[slot] >= depth && !pv && ply > 0) {
          let s = this.ts[slot]; if (s > MATE - 200) s -= ply; else if (s < -MATE + 200) s += ply;
          const f = this.tf[slot];
          if (f === 1 || (f === 2 && s >= beta) || (f === 3 && s <= alpha)) return s;
        }
      }
      if (nullOk && !check && depth >= 3 && !pv) {
        let has = false; for (let s = 0; s < 64; s++) { const p = pos.b[s]; if (p * pos.turn > 0 && Math.abs(p) > P && Math.abs(p) !== K) { has = true; break; } }
        if (has && evaluate(pos) >= beta) {
          pos.makeNull();
          const v = -this.search(pos, depth - 1 - (depth > 6 ? 3 : 2), -beta, -beta + 1, ply + 1, false);
          pos.undoNull();
          if (this.stop) return 0;
          if (v >= beta) return v >= MATE - 200 ? beta : v;
        }
      }
      const list = this.order(pos, pos.gen(false), ttm, ply), orig = alpha;
      let best = -INF, bm = 0, n = 0;
      for (let i = 0; i < list.length; i++) {
        const m = list[i];
        pos.make(m);
        if (pos.attacked(pos.kp[us], pos.turn)) { pos.undo(); continue; }
        n++;
        const quiet = !(m >> 16 & 1) && !((m >> 12) & 15);
        let v;
        if (n === 1) v = -this.search(pos, depth - 1, -beta, -alpha, ply + 1, true);
        else {
          let red = 0;
          if (quiet && !check && depth >= 3 && n > 3) red = 1;
          v = -this.search(pos, depth - 1 - red, -alpha - 1, -alpha, ply + 1, true);
          if (v > alpha && (red || v < beta)) v = -this.search(pos, depth - 1, -beta, -alpha, ply + 1, true);
        }
        pos.undo();
        if (this.stop) return 0;
        if (v > best) { best = v; bm = m; }
        if (v > alpha) {
          alpha = v;
          if (alpha >= beta) {
            if (quiet) {
              const kk = this.killers[ply]; if (kk && kk[0] !== m) { kk[1] = kk[0]; kk[0] = m; }
              this.hist[(us * 64 + (m & 63)) * 64 + ((m >> 6) & 63)] += depth * depth;
            }
            break;
          }
        }
      }
      if (!n) return check ? -MATE + ply : 0;
      const flag = best <= orig ? 3 : best >= beta ? 2 : 1;
      let sv = best; if (sv > MATE - 200) sv += ply; else if (sv < -MATE + 200) sv -= ply;
      if (!this.tf[slot] || this.td[slot] <= depth || this.tk[slot] !== pos.h2) { this.tk[slot] = pos.h2; this.tm[slot] = bm; this.ts[slot] = sv; this.tf[slot] = flag; this.td[slot] = Math.min(127, depth); }
      return best;
    }

    best(pos, maxDepth, ms) {
      this.nodes = 0; this.stop = false; this.deadline = performance.now() + ms;
      const rootList = pos.legal(); if (!rootList.length) return null;
      let bestMove = rootList[0], score = 0, done = 0;
      if (rootList.length === 1) return {move: bestMove, score: 0, depth: 0, nodes: 0};
      for (let d = 1; d <= maxDepth; d++) {
        let alpha = -INF, bm = 0, bs = -INF; const list = this.order(pos, rootList, bestMove, 0), us = pos.turn === 1 ? 0 : 1;
        for (let i = 0; i < list.length; i++) {
          const m = list[i]; pos.make(m);
          let v;
          if (i === 0) v = -this.search(pos, d - 1, -INF, -alpha, 1, true);
          else { v = -this.search(pos, d - 1, -alpha - 1, -alpha, 1, true); if (v > alpha && !this.stop) v = -this.search(pos, d - 1, -INF, -alpha, 1, true); }
          pos.undo();
          if (this.stop) break;
          if (v > bs) { bs = v; bm = m; if (v > alpha) alpha = v; }
        }
        if (this.stop) { if (bm && d > 1 && bs > score - 150) { bestMove = bm; } break; }
        bestMove = bm; score = bs; done = d;
        if (Math.abs(score) > MATE - 100 && d >= 3) break;
        if (performance.now() > this.deadline) break;
      }
      return {move: bestMove, score, depth: done, nodes: this.nodes};
    }

    scoreAll(pos, depth, ms) {
      this.nodes = 0; this.stop = false; this.deadline = performance.now() + ms;
      const list = pos.legal(), res = [];
      for (const m of list) {
        pos.make(m);
        const v = -this.search(pos, depth - 1, -INF, INF, 1, false);
        pos.undo();
        res.push({m, v: this.stop ? -INF : v});
        this.stop = false; this.deadline = performance.now() + ms;
      }
      return res;
    }
  }

  const LEVELS = {
    1: {name: "Yangi boshlovchi", depth: 1, ms: 250, noise: 220, blunder: 0.22},
    2: {name: "Havaskor", depth: 2, ms: 500, noise: 90, blunder: 0.06},
    3: {name: "O'rta", depth: 3, ms: 900, noise: 30, blunder: 0},
    4: {name: "Kuchli", depth: 5, ms: 1600, noise: 0, blunder: 0},
    5: {name: "Usta", depth: 9, ms: 3500, noise: 0, blunder: 0},
  };
  const BOOK = {
    "": ["e2e4", "d2d4", "c2c4", "g1f3"],
    "e2e4": ["e7e5", "c7c5", "e7e6", "c7c6"], "d2d4": ["d7d5", "g8f6", "e7e6"], "c2c4": ["e7e5", "g8f6", "c7c5"], "g1f3": ["d7d5", "g8f6", "c7c5"],
    "e2e4 e7e5": ["g1f3"], "e2e4 e7e5 g1f3": ["b8c6"], "e2e4 e7e5 g1f3 b8c6": ["f1b5", "f1c4", "d2d4"],
    "e2e4 c7c5": ["g1f3"], "e2e4 c7c5 g1f3": ["d7d6", "b8c6", "e7e6"], "e2e4 e7e6": ["d2d4"], "e2e4 c7c6": ["d2d4"],
    "d2d4 d7d5": ["c2c4", "g1f3"], "d2d4 g8f6": ["c2c4", "g1f3"], "d2d4 d7d5 c2c4": ["e7e6", "c7c6"], "d2d4 g8f6 c2c4": ["e7e6", "g7g6"],
    "g1f3 d7d5": ["d2d4", "g2g3"], "g1f3 g8f6": ["c2c4", "d2d4"],
  };
  let SEARCHER = null;
  function pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

  function chooseMove(startFen, moves, level, opts) {
    opts = opts || {};
    const pos = new Pos(startFen);
    for (const u of moves) { const m = pos.findUci(u); if (!m) throw new Error("yurish noto'g'ri: " + u); pos.make(m); }
    const list = pos.legal(); if (!list.length) return null;
    const cfg = opts.hint ? {depth: 5, ms: 1100, noise: 0, blunder: 0} : (LEVELS[level] || LEVELS[3]);
    if (!SEARCHER) SEARCHER = new Searcher();
    const S = SEARCHER;
    if (!opts.hint && level >= 3 && startFen === START_FEN && moves.length < 8) {
      const cand = (BOOK[moves.join(" ")] || []).map(u => pos.findUci(u, list)).filter(Boolean);
      if (cand.length) return {uci: pos.toUci(pick(cand)), score: 0, depth: 0, book: true};
    }

    if (!opts.hint && cfg.noise) {
      for (const m of list) { pos.make(m); const mate = pos.legal().length === 0 && pos.inCheck(); pos.undo(); if (mate && Math.random() < (level === 1 ? 0.75 : 0.95)) return {uci: pos.toUci(m), score: MATE, depth: 1}; }
      if (cfg.blunder && Math.random() < cfg.blunder) return {uci: pos.toUci(pick(list)), score: 0, depth: 0, random: true};
    }
    if (cfg.noise) {
      const all = S.scoreAll(pos, cfg.depth, cfg.ms);
      let bm = list[0], bs = -Infinity;
      for (const {m, v} of all) { const s = v + (Math.random() * 2 - 1) * cfg.noise; if (s > bs) { bs = s; bm = m; } }
      return {uci: pos.toUci(bm), score: Math.round(bs), depth: cfg.depth};
    }
    const r = S.best(pos, cfg.depth, cfg.ms);
    return r ? {uci: pos.toUci(r.move), score: r.score, depth: r.depth, nodes: r.nodes} : null;
  }

  function perft(pos, d) {
    if (d === 0) return 1;
    let n = 0; const l = pos.legal();
    if (d === 1) return l.length;
    for (const m of l) { pos.make(m); n += perft(pos, d - 1); pos.undo(); }
    return n;
  }

  const api = {Pos, START_FEN, LEVELS, chooseMove, perft, sqName, sqIdx, evaluate, FROM_LETTER};
  root.TCChess = api;

  if (typeof WorkerGlobalScope !== "undefined" && typeof self !== "undefined" && self instanceof WorkerGlobalScope) {
    self.onmessage = e => {
      const d = e.data || {};
      try { const r = chooseMove(d.fen || START_FEN, d.moves || [], d.level || 3, {hint: !!d.hint}); self.postMessage({id: d.id, ok: true, uci: r && r.uci, score: r && r.score, depth: r && r.depth}); }
      catch (err) { self.postMessage({id: d.id, ok: false, error: String(err && err.message || err)}); }
    };
  }
})(typeof self !== "undefined" ? self : this);
