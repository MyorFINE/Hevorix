"use strict";
(() => {

const NS = "http://www.w3.org/2000/svg";
const $ = id => document.getElementById(id);
const APP_NAME = "Anonim Chat by Hevorix";
const LS_THEME = "termchat_theme";
const LS_STAY = "termchat_stay";
const WS_UNAUTHORIZED = 4401, WS_FORBIDDEN = 4403, WS_IP_BLOCKED = 4410;
const IDLE_MS = 5 * 60 * 1000;
const HB_MS = 15000, HB_DEAD_MS = 40000;
const delay = ms => new Promise(r => setTimeout(r, ms));
try { localStorage.removeItem("termchat_token"); } catch (_) {}
const PALETTE = ["#e17076", "#e0954f", "#a695e7", "#7bc862", "#4fb6b9", "#65aadd", "#ee7aae"];
const MONTHS = ["yanvar", "fevral", "mart", "aprel", "may", "iyun", "iyul", "avgust", "sentabr", "oktabr", "noyabr", "dekabr"];
const COARSE = matchMedia("(pointer: coarse)").matches;
const isMobile = () => matchMedia("(max-width: 760px)").matches;

const S = {
  token: null, me: null, ws: null, retry: 0, wantClose: false, mode: "login",
  users: new Map(),
  members: [],
  online: new Set(),
  group: {msgs: [], unread: 0, more: false},
  dms: new Map(),
  chn: new Map(),
  chList: [],
  active: null,
  tab: "chats", query: "", editing: null, away: 0, modal: null,
  replying: null,
  pendingImg: null,
  sending: false,
  rec: null, recBusy: false, recTimer: 0,
  recKind: "voice", recMode: "voice", vfacing: "user", starting: false, startAbort: false, flipping: false, noClickUntil: 0,
  imgs: new Map(),
  sel: null,
  played: new Map(),
  previews: new Map(),
  fx: new Map(),
  chat: {slowmode: 0, locked: false},
};

function h(tag, props, ...kids) {
  const e = document.createElement(tag);
  if (props) for (const [k, v] of Object.entries(props)) {
    if (v == null || v === false) continue;
    if (k === "class") e.className = v;
    else if (k === "text") e.textContent = v;
    else if (k.startsWith("on")) e.addEventListener(k.slice(2), v);
    else e.setAttribute(k, v === true ? "" : v);
  }
  for (const c of kids.flat()) {
    if (c == null || c === false) continue;
    e.append(c.nodeType ? c : document.createTextNode(String(c)));
  }
  return e;
}
function svgUse(href, cls) {
  const s = document.createElementNS(NS, "svg"); s.setAttribute("class", cls);
  const u = document.createElementNS(NS, "use"); u.setAttribute("href", href); s.append(u);
  return s;
}
const icon = (name, cls) => svgUse("#i-" + name, cls || "ic");
const pad2 = n => String(n).padStart(2, "0");
const hhmm = ts => { const d = new Date(ts * 1000); return pad2(d.getHours()) + ":" + pad2(d.getMinutes()); };
const dayKey = ts => { const d = new Date(ts * 1000); return d.getFullYear() + "-" + d.getMonth() + "-" + d.getDate(); };
function dayLabel(ts) {
  const d = new Date(ts * 1000), now = new Date();
  if (dayKey(ts) === dayKey(now / 1000)) return "Bugun";
  const y = new Date(now); y.setDate(now.getDate() - 1);
  if (dayKey(ts) === dayKey(y / 1000)) return "Kecha";
  return d.getDate() + "-" + MONTHS[d.getMonth()] + (d.getFullYear() !== now.getFullYear() ? ", " + d.getFullYear() : "");
}
function listTime(ts) {
  const d = new Date(ts * 1000), now = new Date();
  if (dayKey(ts) === dayKey(now / 1000)) return hhmm(ts);
  const y = new Date(now); y.setDate(now.getDate() - 1);
  if (dayKey(ts) === dayKey(y / 1000)) return "Kecha";
  return pad2(d.getDate()) + "." + pad2(d.getMonth() + 1) + "." + String(d.getFullYear()).slice(2);
}
const colorOf = id => PALETTE[Math.abs(id) % PALETTE.length];
const isStaff = u => !!u && (u.role === "owner" || u.role === "admin");
const HEX = /^#[0-9a-f]{6}$/i, TONES = {owner: "#f7b733", admin: "#7b61ff"};
const hexRgb = x => { const n = parseInt(x.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
const mixHex = (x, to, t) => "#" + hexRgb(x).map((v, i) => Math.round(v + (to[i] - v) * t).toString(16).padStart(2, "0")).join("");
function toneOf(u) {
  const base = HEX.test(u.color || "") ? u.color.toLowerCase() : TONES[u.role];
  const [r, g, b] = hexRgb(base);
  return {p2: base, p1: mixHex(base, [255, 255, 255], .55), p3: mixHex(base, [0, 0, 0], .4), pr: r + "," + g + "," + b,
    pt: (0.299 * r + 0.587 * g + 0.114 * b) / 255 > .6 ? "#2b2000" : "#fff"};
}

function tint(el, u) {
  if (!isStaff(u)) return el;
  const t = toneOf(u);
  ["p1", "p2", "p3", "pr", "pt"].forEach(k => el.style.setProperty("--" + k, t[k]));
  return el;
}
const roleLabel = r => r === "owner" ? "Platforma egasi" : r === "admin" ? "Administrator" : "";
const U = id => S.users.get(id) || {id, nickname: "Noma'lum", username: "?", role: "user", bio: "", avatar: null};
const isOnline = id => S.me && (id === S.me.id || S.online.has(id));
const onlineCount = () => new Set([...S.online, S.me.id]).size;
const amAdmin = () => isStaff(S.me);
const dmOf = uid => {
  if (!S.dms.has(uid)) S.dms.set(uid, {msgs: [], loaded: false, buffer: [], unread: 0, last: null, more: false});
  return S.dms.get(uid);
};
const chOf = id => {
  if (!S.chn.has(id)) S.chn.set(id, {msgs: [], loaded: false, buffer: [], unread: 0, last: null, more: false});
  return S.chn.get(id);
};
const chInfo = id => S.chList.find(c => c.id === id) || null;
const isActiveChan = id => !!S.active && S.active.kind === "channel" && S.active.id === id;
function upsertUser(u) {
  if (!u || u.id == null) return;
  const merged = Object.assign({}, S.users.get(u.id), u);
  S.users.set(u.id, merged);
  if (S.me && u.id === S.me.id) S.me = Object.assign({}, S.me, u);
}

function toast(text, level) {
  const t = h("div", {class: "toast " + (level || "info"), text});
  $("toasts").append(t);
  while ($("toasts").children.length > 4) $("toasts").firstChild.remove();
  setTimeout(() => t.remove(), level === "error" ? 5000 : 3500);
}

async function api(path, opts = {}) {
  const headers = Object.assign({Authorization: "Bearer " + S.token}, opts.headers || {});
  let body = opts.body;
  if (body && !(body instanceof FormData)) { headers["Content-Type"] = "application/json"; body = JSON.stringify(body); }
  const r = await SC.fetch("/api" + path, {method: opts.method || "GET", headers, body});
  const j = await r.json().catch(() => ({}));
  if (r.status === 401) { showAuth("Sessiya tugagan, qayta kiring"); throw new Error("401"); }
  if (!r.ok) throw new Error(typeof j.detail === "string" ? j.detail : "Xato, qayta urinib ko'ring");
  return j;
}
function wsTry(obj) {
  if (S.offline || !S.ws || S.ws.readyState !== 1) return false;
  try { S.ws.send(JSON.stringify(obj)); return true; } catch (_) { return false; }
}
function wsSend(obj) {
  if (S.offline) { toast("Oflayn rejim: faqat o'qish mumkin", "error"); return false; }
  if (!S.ws || S.ws.readyState !== 1) { toast("Ulanish yo'q, biroz kuting…", "error"); return false; }
  S.ws.send(JSON.stringify(obj));
  return true;
}

const LS_PINS = "termchat_pins";
const X = {id: 0, username: "", priv: null, ecdhPub: "", signPub: "", fp: "", iter: 0, self: null, rooms: new Map(), keyIds: new Map(),
           epoch: 0, state: null, peers: new Map(), peerReq: new Map(), pending: new Set(), changed: new Map(), ready: null, serving: false, rotating: false};
function xReset() {
  X.id = 0; X.priv = null; X.self = null; X.rooms = new Map(); X.keyIds = new Map(); X.epoch = 0; X.state = null; X.peers = new Map(); X.peerReq = new Map();
  X.pending = new Set(); X.changed = new Map(); X.ready = null; X.serving = false; X.rotating = false;
}
const pinStore = () => { try { return JSON.parse(localStorage.getItem(LS_PINS + "_" + X.id) || "{}"); } catch (_) { return {}; } };
const savePins = p => { try { localStorage.setItem(LS_PINS + "_" + X.id, JSON.stringify(p)); } catch (_) {} };

async function xInstall(me, username, ident, pubs, iter, remember) {
  const priv = await E2E.importPrivate(ident);
  X.id = me.id; X.username = username; X.priv = priv; X.ecdhPub = pubs.ecdh_pub; X.signPub = pubs.sign_pub; X.iter = iter;
  X.self = await E2E.importPeer({e: pubs.ecdh_pub, s: pubs.sign_pub}); X.fp = X.self.fp;

}
async function xGenerate(username, password, iter) {
  const kd = await E2E.deriveFromPassword(username, password, iter);
  const ident = await E2E.generateIdentity();
  const keys = {ecdh_pub: ident.ecdhPub, sign_pub: ident.signPub, key_blob: await E2E.wrapIdentity(ident, kd.kek, username), kdf_iter: iter};
  return {kd, ident, keys};
}

async function xUnlock(info, me, username, password) {
  if (info.upgrade) {
    const g = await xGenerate(username, password, E2E.KDF_DEFAULT);
    await api("/e2ee/setup", {method: "POST", body: {old: password, auth: g.kd.auth, keys: g.keys}});
    await xInstall(me, username, g.ident, g.keys, E2E.KDF_DEFAULT, true);
    return;
  }
  const e = info.e2ee, kd = await E2E.deriveFromPassword(username, password, e.kdf_iter || E2E.KDF_DEFAULT);
  let ident;
  try { ident = await E2E.unwrapIdentity(e.key_blob, kd.kek, username); } catch (_) { throw new Error("Parol noto'g'ri (kalitlarni ochib bo'lmadi)"); }
  await xInstall(me, username, ident, e, e.kdf_iter || E2E.KDF_DEFAULT, true);
}

async function xRestore(info, me) {
  if (!info.upgrade && info.e2ee.ecdh_pub) {
    const rec = await E2E.loadIdentity(me.id);
    if (rec && rec.ecdhPub === info.e2ee.ecdh_pub && rec.signPub === info.e2ee.sign_pub) {
      X.id = me.id; X.username = me.username; X.priv = {ecdhPriv: rec.ecdhPriv, signPriv: rec.signPriv};
      X.ecdhPub = rec.ecdhPub; X.signPub = rec.signPub; X.iter = rec.iter || info.e2ee.kdf_iter;
      X.self = await E2E.importPeer({e: rec.ecdhPub, s: rec.signPub}); X.fp = X.self.fp;
      return true;
    }
  }
  for (let tries = 0; tries < 5; tries++) {
    const pw = await promptDlg(info.upgrade ? "Shifrlashni yoqish" : "Kalitlarni ochish",
      info.upgrade ? "Xabarlaringiz endi uchdan-uchga shifrlanadi. Davom etish uchun parolingizni kiriting (kalitlar shu qurilmada yaratiladi)."
        : "Shifrlash kalitlari bu qurilmada yo'q. Ularni ochish uchun parolingizni kiriting.", "", {type: "password", okText: "Ochish"});
    if (pw === null) return false;
    try { await xUnlock(info, me, me.username, pw); return true; } catch (err) { toast(err.message, "error"); }
  }
  return false;
}

function peer(uid) {
  if (uid === X.id) return Promise.resolve(X.self);
  const p = X.peers.get(uid);
  if (p) return Promise.resolve(p);
  let req = X.peerReq.get(uid);
  if (!req) { req = loadPeer(uid).finally(() => X.peerReq.delete(uid)); X.peerReq.set(uid, req); }
  return req;
}
async function loadPeer(uid) {
  let p;
  const m = S.members.find(x => x.id === uid);
  let keys = m && m.ek ? {e: m.ek, s: m.sk} : null;
  if (!keys) { const j = await api("/e2ee/keys?ids=" + uid); keys = j.keys[String(uid)]; }
  if (!keys) throw new Error("Bu foydalanuvchida E2EE kalitlari yo'q");
  p = await E2E.importPeer(keys);
  const pins = pinStore();
  if (pins[uid] && pins[uid] !== p.fp) { p.changed = true; X.changed.set(uid, {old: pins[uid], now: p.fp}); }
  else if (!pins[uid]) { pins[uid] = p.fp; savePins(pins); }
  X.peers.set(uid, p);
  return p;
}
function acceptKeyChange(uid) {
  const c = X.changed.get(uid); if (!c) return;
  const pins = pinStore(); pins[uid] = c.now; savePins(pins);
  X.changed.delete(uid); const p = X.peers.get(uid); if (p) p.changed = false;
}

async function loadRoom() {
  const st = await api("/e2ee/room"); X.state = st; X.epoch = st.epoch;
  for (const w of st.mine) {
    if (X.rooms.has(w.epoch)) continue;
    const ep = st.epochs.find(e => e.epoch === w.epoch);
    try {
      const wp = await peer(w.by);
      const key = await E2E.unwrapRoomKey(w.wrapped, w.epoch, X.priv.ecdhPriv, X.id, wp.ecdh, w.by);
      if (!ep || !(await E2E.verifyEpochCheck(ep.check, key, w.epoch))) throw new Error("tekshiruv");
      X.rooms.set(w.epoch, key); X.keyIds.set(w.epoch, await E2E.keyId(key));
    } catch (_) {
      try { await api("/e2ee/room/wrap/" + w.epoch, {method: "DELETE"}); } catch (__) {}
    }
  }
  if (st.epoch === 0) await initRoom();
  else if (X.rooms.has(st.epoch)) { rehydratePending(); serveWraps(); }
  if (!X.rooms.has(X.epoch) && X.epoch) renderHeader();
}
async function initRoom() {
  const key = await E2E.newRoomKey(), withKeys = S.members.filter(m => m.ek && !m.banned && !m.deleted);
  const list = withKeys.some(m => m.id === X.id) ? withKeys : withKeys.concat([{id: X.id, ek: X.ecdhPub}]);
  const wraps = [];
  for (const m of list) wraps.push({user_id: m.id, wrapped: await E2E.wrapRoomKey(key, 1, X.priv.ecdhPriv, X.id, (await peer(m.id)).ecdh, m.id)});
  try { await api("/e2ee/room/init", {method: "POST", body: {check: await E2E.epochCheck(key, 1), wraps}}); }
  catch (_) {  }
  const st = await api("/e2ee/room"); if (st.epoch) { X.state = st; X.epoch = st.epoch; await loadRoomKeysOnly(); }
}
async function loadRoomKeysOnly() { if (X.epoch) await loadRoom(); }
async function serveWraps() {
  if (X.serving || !X.rooms.size) return;
  X.serving = true;
  try {
    const j = await api("/e2ee/room/missing"), byEp = new Map();
    j.missing.forEach(m => { if (X.rooms.has(m.epoch) && m.user_id !== X.id) (byEp.get(m.epoch) || byEp.set(m.epoch, []).get(m.epoch)).push(m); });
    for (const [ep, list] of byEp) {
      const wraps = [];
      for (const m of list.slice(0, 100)) {
        try {
          const pk = await E2E.importEcdhPub(m.ecdh_pub);
          wraps.push({user_id: m.user_id, wrapped: await E2E.wrapRoomKey(X.rooms.get(ep), ep, X.priv.ecdhPriv, X.id, pk, m.user_id)});
        } catch (_) {}
      }
      if (wraps.length) await api("/e2ee/room/wrap", {method: "POST", body: {epoch: ep, wraps}});
    }
  } catch (_) {}
  X.serving = false;
}
async function rotateRoom(reason) {
  if (X.rotating || !amAdmin() || !X.rooms.has(X.epoch)) return;
  X.rotating = true;
  try {
    await loadMembers();
    const key = await E2E.newRoomKey(), ep = X.epoch + 1, wraps = [];
    for (const m of S.members.filter(m => m.ek && !m.banned && !m.deleted))
      wraps.push({user_id: m.id, wrapped: await E2E.wrapRoomKey(key, ep, X.priv.ecdhPriv, X.id, (await peer(m.id)).ecdh, m.id)});
    await api("/e2ee/room/rotate", {method: "POST", body: {from_epoch: X.epoch, check: await E2E.epochCheck(key, ep), wraps, reason: (reason || "rotate").slice(0, 20)}});
    toast("Guruh kaliti yangilandi (yangi xabarlar eski a'zolar uchun yopiq)", "ok");
  } catch (_) {}
  X.rotating = false;
  try { await loadRoom(); } catch (_) {}
}

const fileIco = f => f.voice ? "🎤 " : f.vnote ? "📹 " : "📎 ";
const fileWhat = f => f.voice ? "Ovozli xabar" : f.vnote ? "Video xabar" : f.name;
const THUMB_RE = /^data:image\/jpeg;base64,[A-Za-z0-9+/]{16,4200}={0,2}$/;
const replyInfo = m => ({id: m.id, uid: m.user.id, nickname: m.user.nickname, text: snippetOf(m.content), image: !!m.image, file: !!m.file, voice: !!(m.file && m.file.voice), vnote: !!(m.file && m.file.vnote), file_name: m.file ? fileWhat(m.file) : null});
async function hydrate(m) {
  if (!m || m.service || !m.e2e) { if (m && !m.service && !m.e2e) m.legacy = true; return m; }
  m.locked = false; m.bad = false; m.verified = false;
  try {
    const env = E2E.parseEnvelope(m.e2e), sender = m.user.id, me = X.id;
    let key;
    if (m.ch || m.to == null) {
      key = X.rooms.get(env.ep);
      if (!key) { m.locked = true; m.content = ""; X.pending.add(m); return m; }
    } else {
      const other = sender === me ? m.to : sender, op = await peer(other);
      if (op.changed) throw new Error("kalit o'zgargan");
      key = await E2E.dmKey(X.priv.ecdhPriv, op.ecdh, sender, m.to);
    }
    const sp = await peer(sender);
    const r = await E2E.openMessage(m.e2e, {sender, peer: m.to, key, signKey: sp.sign, room: m.ch ? "c:" + m.ch : undefined});
    const p = r.payload; m.verified = r.verified && !sp.changed;
    m.content = typeof p.t === "string" ? p.t : "";
    m.reply = p.r ? Object.assign({deleted: false}, p.r) : null;
    m._r = p.r || null; m._f = p.f || null;
    m._fw = p.fw && typeof p.fw === "object" && typeof p.fw.n === "string" ? {n: p.fw.n.slice(0, 40), id: Number.isInteger(p.fw.id) ? p.fw.id : 0} : null;
    m.fwd = m._fw;
    if (p.f) {
      m.mkey = p.f.k;
      if (p.f.img) { m.image = "e2e"; m.thumb = p.f.th || null; m.w = p.f.w || null; m.h = p.f.h || null; }
      else m.file = {url: m.blob ? m.blob.url : "", name: p.f.name || "fayl", size: p.f.size || 0, mime: p.f.mime || "application/octet-stream", e2e: true, key: p.f.k,
        voice: p.f.vo === 1 && p.f.mime === "audio/wav", wf: typeof p.f.wf === "string" && /^[0-9a-v]{16,96}$/.test(p.f.wf) ? p.f.wf : "", dur: typeof p.f.d === "number" && p.f.d > 0 && p.f.d < 900 ? p.f.d : 0,
        vnote: p.f.rv === 1 && (p.f.mime === "video/webm" || p.f.mime === "video/mp4"), th: typeof p.f.th === "string" && THUMB_RE.test(p.f.th) ? p.f.th : null};
    }
    X.pending.delete(m);
  } catch (err) { m.bad = true; m.content = ""; X.pending.delete(m); }
  return m;
}
async function rehydratePending() {
  const list = [...X.pending]; if (!list.length) return;
  for (const m of list) await hydrate(m);
  renderMessages(false); renderList();
}
const hydrateAll = list => Promise.all(list.map(hydrate));

async function hydrateComment(c) {
  if (!c.e2e) { c.text = typeof c.content === "string" ? c.content : ""; c.verified = false; c.legacy = true; return c; }
  c.locked = false; c.bad = false; c.verified = false; c.text = "";
  try {
    const env = E2E.parseEnvelope(c.e2e), key = X.rooms.get(env.ep);
    if (!key) { c.locked = true; return c; }
    const sp = await peer(c.user.id);
    const r = await E2E.openMessage(c.e2e, {sender: c.user.id, peer: null, key, signKey: sp.sign, room: "k:" + c.post});
    c.verified = r.verified && !sp.changed;
    c.text = typeof r.payload.t === "string" ? r.payload.t : "";
  } catch (_) { c.bad = true; }
  return c;
}
async function sealComment(postId, text) {
  const key = X.rooms.get(X.epoch);
  if (!key) throw new Error(X.epoch ? "Guruh kaliti hali kelmagan. Biroz kuting…" : "Guruh kaliti yaratilmoqda, biroz kuting…");
  return E2E.sealMessage({sender: X.id, peer: null, ep: X.epoch, key, signKey: X.priv.signPriv, payload: {t: text}, room: "k:" + postId, kind: "c"});
}

async function e2eFetchBlob(m) {
  const url = m.blob ? m.blob.url : (m.file && m.file.url);
  if (m.expired || !url) { const ex = new Error("expired"); ex.expired = true; throw ex; }
  const r = await SC.fetch(url, {headers: {Authorization: "Bearer " + S.token}});
  if (!r.ok) throw new Error("fayl");
  return E2E.decryptFile(r.bytes, m.mkey || m.file.key);
}
const EXPIRED_MSG = "Fayl muddati tugagan (24 soatdan keyin o'chiriladi)";
const blobUrls = new Map();
function e2eImageUrl(m) {
  if (!blobUrls.has(m.id)) blobUrls.set(m.id, e2eFetchBlob(m).then(b => URL.createObjectURL(new Blob([b], {type: (m._f && m._f.mime) || "image/jpeg"}))).catch(e => { blobUrls.delete(m.id); throw e; }));
  return blobUrls.get(m.id);
}
const imgSrcOf = m => m.e2e ? e2eImageUrl(m) : Promise.resolve(m.image);

async function cleanImage(blob) {
  const out = {blob, w: 0, h: 0, th: null};
  try {
    const bmp = await createImageBitmap(blob);
    out.w = bmp.width; out.h = bmp.height;
    if (blob.type !== "image/gif") {
      const c = document.createElement("canvas"); c.width = bmp.width; c.height = bmp.height;
      c.getContext("2d").drawImage(bmp, 0, 0);
      const png = blob.type === "image/png", re = await new Promise(r => c.toBlob(r, png ? "image/png" : "image/jpeg", 0.92));
      if (re) out.blob = re;
    }
    const k = 40 / Math.max(bmp.width, bmp.height), t = document.createElement("canvas");
    t.width = Math.max(1, Math.round(bmp.width * k)); t.height = Math.max(1, Math.round(bmp.height * k));
    t.getContext("2d").drawImage(bmp, 0, 0, t.width, t.height);
    out.th = t.toDataURL("image/jpeg", 0.5);
  } catch (_) {}
  return out;
}

async function keyForActive() { return keyForTarget(S.active); }
async function keyForTarget(tg) {
  if (tg.kind === "channel") {
    if (!amAdmin()) throw new Error("Kanalga faqat adminlar post yoza oladi");
    const key = X.rooms.get(X.epoch);
    if (!key) throw new Error(X.epoch ? "Guruh kaliti hali kelmagan: kalitli a'zo onlayn bo'lishi kerak. Biroz kuting…" : "Guruh kaliti yaratilmoqda, biroz kuting…");
    return {key, peer: null, ep: X.epoch, room: "c:" + tg.id, kind: "c"};
  }
  if (tg.kind === "group") {
    const key = X.rooms.get(X.epoch);
    if (!key) throw new Error(X.epoch ? "Guruh kaliti hali kelmagan: kalitli a'zo onlayn bo'lishi kerak. Biroz kuting…" : "Guruh kaliti yaratilmoqda, biroz kuting…");
    return {key, peer: null, ep: X.epoch};
  }
  const uid = tg.uid, p = await peer(uid);
  if (p.changed) throw new Error("Bu foydalanuvchining shifrlash kaliti o'zgargan! 🔒 tugmasida tekshirib, qabul qiling");
  return {key: await E2E.dmKey(X.priv.ecdhPriv, p.ecdh, X.id, uid), peer: uid, ep: 0};
}
async function sealFor(ctx, payload) {
  return E2E.sealMessage({sender: X.id, peer: ctx.peer, ep: ctx.ep, key: ctx.key, signKey: X.priv.signPriv, payload, room: ctx.room, kind: ctx.kind});
}
function withTarget(msg, tg) {
  if (tg.kind === "dm") msg.to = tg.uid; else if (tg.kind === "channel") msg.ch = tg.id;
  return msg;
}

function paintAv(el, u) {
  el.textContent = "";
  el.style.setProperty("--avc", colorOf(u.id));
  if (u.deleted) { el.classList.add("del"); el.append(icon("ghost")); return; }
  if (u.avatar) el.append(h("img", {src: u.avatar, alt: "", draggable: "false", decoding: "async"}));
  else el.append(h("span", {text: (Array.from((u.nickname || "?").trim())[0] || "?").toUpperCase()}));
}
function avatar(u, size, withDot) {
  const el = h("div", {class: "av av-" + size + (isStaff(u) ? " ring " + u.role : "") + (!u.deleted && FRAME_KEYS.has(u.frame) ? " fr-" + u.frame : "")});
  tint(el, u); paintAv(el, u);
  if (withDot && !u.deleted && isOnline(u.id)) el.append(h("span", {class: "dot-on"}));
  return el;
}
function groupAvatar(size) { return h("div", {class: "av av-" + size + " grp"}, icon("group")); }
const hasEmoji = u => !!u && !!u.badge && u.badge !== "none" && u.badge !== "check";
const isVerified = u => !!u && !isStaff(u) && !u.deleted && u.badge === "check";
function badge(u, big) {
  if (hasEmoji(u) && Rich.isEmojiToken(u.badge)) {
    return Rich.emojiEl(u.badge, "eb ceb" + (u.badge_anim ? " a-" + u.badge_anim : "") + (big ? " big" : ""), isStaff(u) ? roleLabel(u.role) : null);
  }
  if (hasEmoji(u)) {
    return h("span", {class: "eb" + (u.badge_anim ? " a-" + u.badge_anim : "") + (big ? " big" : ""),
      title: isStaff(u) ? roleLabel(u.role) : "Maxsus nishon", "aria-label": "Nishon", text: u.badge});
  }
  if (!isStaff(u) && !isVerified(u)) return null;
  if (isStaff(u) && u.badge === "none") return null;
  const s = svgUse("#i-vb", "vb " + u.role + (big ? " big" : ""));
  const t = document.createElementNS(NS, "title");
  t.textContent = u.role === "owner" ? "Tasdiqlangan — platforma egasi" : u.role === "admin" ? "Tasdiqlangan administrator" : "Tasdiqlangan foydalanuvchi";
  s.prepend(t);
  return s;
}
function newTag(u, big) {
  return u && u.new && !u.deleted && !isStaff(u) ? h("span", {class: "newb" + (big ? " big" : ""), title: "Yangi foydalanuvchi — hali ishonch qozonmagan. Ehtiyot bo'ling", text: "⚠ Yangi"}) : null;
}
function nameEl(u, opts = {}) {
  const nt = h("span", {class: "nt", text: u.nickname});
  if (opts.colored && !isStaff(u) && !u.deleted) nt.style.color = colorOf(u.id);
  const nk = opts.nofx ? null : fxOf(u, "nick");
  if (nk) { fxText(nt, nk); if (nk === "wave") fxWave(nt, u.nickname); }
  return tint(h("span", {class: "nm" + (isStaff(u) ? " prem " + u.role : "") + (u.deleted ? " deleted" : "")}, nt, badge(u, opts.big), newTag(u, opts.big)), u);
}
const statusText = u => u.deleted ? "akkaunt o'chirilgan" : isOnline(u.id) ? "onlayn" : lastSeenText(u);

const BANNERS = [["aurora", "Aurora"], ["sunset", "Shafaq"], ["ocean", "Okean"], ["forest", "O'rmon"], ["midnight", "Yarim tun"],
  ["rose", "Atirgul"], ["gold", "Oltin"], ["fire", "Olov"], ["ice", "Muz"], ["violet", "Binafsha"]];
const FRAMES = [["gold", "Oltin"], ["rainbow", "Kamalak"], ["fire", "Olov"], ["ice", "Muz"], ["emerald", "Zumrad"], ["rose", "Atirgul"]];
const BANNER_KEYS = new Set(BANNERS.map(x => x[0])), FRAME_KEYS = new Set(FRAMES.map(x => x[0]));
const FX_TXT = [["shimmer", "Yaltirash"], ["aurora", "Aurora"], ["sunrise", "Shafaq"], ["ocean", "Okean"], ["gold", "Oltin"], ["candy", "Konfet"],
  ["glitch", "Glitch"], ["float", "Suzish"], ["pulse", "Puls"]];
const FX = {
  nick: {label: "Nickname", items: FX_TXT.concat([["wave", "To'lqin"]])},
  user: {label: "Username", items: FX_TXT},
  bio: {label: "Bio", items: FX_TXT.slice(0, 6).concat([["breathe", "Nafas"]])},
  page: {label: "Profil sahifasi", items: [["flow", "Oqma fon"], ["stars", "Yulduzlar"], ["float", "Suzuvchi avatar"]]},
  reply: {label: "Reply", items: [["line", "Oqma chiziq"], ["tint", "Rangli fon"], ["stripes", "Yo'l-yo'l"], ["slidein", "Sirpanib kirish"]]},
  link: {label: "Havola", items: [["run", "Chiziq yugurishi"], ["pill", "Kapsula"], ["flow", "Oqma rang"], ["arrow", "↗ Strelka"]]},
};
const FX_AREAS = Object.keys(FX);
const FX_KEYS = {}; FX_AREAS.forEach(k => { FX_KEYS[k] = new Set(FX[k].items.map(x => x[0])); });
const FX_GRAD = new Set(["shimmer", "aurora", "sunrise", "ocean", "gold", "candy"]);
const FX_MQ = typeof matchMedia === "function" ? matchMedia("(prefers-reduced-motion: reduce)") : null;
const fxOf = (u, area) => !(FX_MQ && FX_MQ.matches) && u && !u.deleted && u.fx && typeof u.fx === "object" && typeof u.fx[area] === "string" && FX_KEYS[area] && FX_KEYS[area].has(u.fx[area]) ? u.fx[area] : null;
const fxMap = u => { const o = {}; FX_AREAS.forEach(a => { o[a] = fxOf(u, a) || ""; }); return o; };
function fxText(el, key) {
  if (!key) return el;
  if (FX_GRAD.has(key)) el.classList.add("fxt", "fxg-" + key); else el.classList.add("fxa-" + key);
  return el;
}
function fxWave(nt, text) {
  nt.textContent = ""; nt.setAttribute("aria-label", text);
  Array.from(text).forEach((ch, i) => { const sp = h("span", {class: "fxw", "aria-hidden": "true", text: ch}); sp.style.setProperty("--i", String(Math.min(i, 40))); nt.append(sp); });
  return nt;
}
function fxBubble(bubble, u) {
  const l = fxOf(u, "link");
  if (l) bubble.classList.add("fxl-" + l);
  return bubble;
}
function fxPlay(el, ms) {
  el.classList.remove("fxgo"); void el.offsetWidth; el.classList.add("fxgo");
  clearTimeout(el._fxT); el._fxT = setTimeout(() => el.classList.remove("fxgo"), ms || 3400);
}
const pageCls = u => { const k = fxOf(u, "page"); return k ? " fxp-" + k : ""; };
const bannerCls = u => u && !u.deleted && BANNER_KEYS.has(u.banner) ? " bn-" + u.banner : "";
const titleEl = u => u && !u.deleted && u.title ? h("div", {class: "ptitle", text: u.title}) : null;

function openProfileEditor(uid) {
  openPage(() => {
    const t0 = U(uid), self = uid === S.me.id, staff = isStaff(t0), admin = amAdmin();
    const trustOf = x => x.trust === 1 ? "new" : x.trust === 0 ? "trusted" : "auto";
    const base = {fx: fxMap(t0), banner: BANNER_KEYS.has(t0.banner) ? t0.banner : "",
      frame: FRAME_KEYS.has(t0.frame) ? t0.frame : "", title: t0.title || "", color: HEX.test(t0.color || "") ? t0.color.toLowerCase() : "", trust: trustOf(t0)};
    const d = Object.assign({}, base, {fx: Object.assign({}, base.fx)});
    const prev = h("div", {class: "pe-prev"});
    const paintPrev = play => {
      const cur = U(uid), autoNew = base.trust === "auto" ? !!cur.new : (Date.now() / 1000 - (cur.joined || 0)) < 7 * 86400;
      const pu = Object.assign({}, cur, {fx: d.fx, banner: d.banner || null, frame: d.frame || null,
        title: d.title.trim() || null, color: d.color || cur.color, new: d.trust === "new" ? true : d.trust === "trusted" ? false : autoNew});
      prev.textContent = "";
      const top = tint(h("div", {class: "tg-top" + (isStaff(pu) ? " prem " + pu.role : "") + bannerCls(pu) + pageCls(pu)}), pu);
      top.append(avatar(pu, "l"), h("div", {class: "pname"}, nameEl(pu, {big: true})), titleEl(pu), h("div", {class: "pstat on", text: "onlayn"}));
      top.append(fxText(h("div", {class: "pe-un", text: "@" + pu.username}), fxOf(pu, "user")));
      if (pu.new && !isStaff(pu)) top.append(h("div", {class: "chip warn", text: "⚠ Yangi foydalanuvchi — hali ishonish qiyin"}));
      top.append(fxText(h("div", {class: "pe-bio", text: pu.bio || "Bio shunday ko'rinadi ✨"}), fxOf(pu, "bio")));
      const mk = kind => {
        const b = fxBubble(h("div", {class: "bubble pe-bub"}), pu);
        b.append(h("div", {class: "bname"}, nameEl(pu, {colored: true})));
        if (kind === "reply") b.append(replyQuote({nickname: "Aziz", text: "Salom, qalaysan?"}, pu));
        b.append(btextEl("btext", kind === "reply" ? "Yaxshi, rahmat! Reply shunday ko'rinadi" : kind === "link" ? "Mana havola: https://example.com/dizayn" : "Salom! Xabarim shunday ko'rinadi ✨", true));
        b.append(h("span", {class: "meta", text: "12:00"}));
        return h("div", {class: "pe-msg"}, b);
      };
      const msgs = h("div", {class: "pe-msgs"}, mk("plain"), mk("reply"), mk("link"));
      msgs.addEventListener("click", e => { if (e.target.closest("a")) e.preventDefault(); }, true);
      const again = h("button", {class: "btn ghost sm pe-again", type: "button", text: "▶ Qayta ko'rsatish"});
      again.addEventListener("click", () => fxPlay(msgs, 3400));
      prev.append(top, msgs, h("div", {class: "pe-row pe-pad"}, again));
      if (play) fxPlay(msgs, 3400);
    };
    const set = (k, v) => { d[k] = v; paintPrev(); };
    const setFx = (area, k) => { d.fx[area] = k; paintPrev(area === "reply"); };
    const field = (label, k, o = {}) => {
      const i = h("input", {class: "fld", maxlength: String(o.max), placeholder: o.ph || "", "aria-label": label});
      i.value = d[k]; i.addEventListener("input", () => set(k, i.value));
      return h("label", {class: "fl"}, label, i);
    };
    const seg = (items, cur, onPick) => {
      const box = h("div", {class: "pe-seg", role: "radiogroup"});
      const paint = () => { box.textContent = ""; items.forEach(([k, t]) => { const b = h("button", {type: "button", class: "pe-sg" + (k === cur() ? " on" : ""), role: "radio", "aria-checked": String(k === cur()), text: t}); b.addEventListener("click", () => { onPick(k); paint(); }); box.append(b); }); };
      paint(); return box;
    };
    const apply = j => { upsertUser(j.user); if (S.members.some(x => x.id === uid)) S.members = S.members.map(x => x.id === uid ? Object.assign({}, x, j.user, {trust: j.trust}) : x); S.users.set(uid, Object.assign({}, S.users.get(uid), {trust: j.trust})); renderList(); renderMessages(false); };

    const checkRow = staff || !admin || self ? null : switchRow("check", "Tasdiqlangan galochka", () => U(uid).badge === "check", async () => {
      const on = U(uid).badge === "check";
      try { const j = await api("/admin/badge", {method: "POST", body: {user_id: uid, badge: on ? "" : "check", anim: ""}}); upsertUser(j.user); renderList(); renderMessages(false); paintPrev(); }
      catch (err) { toast(err.message, "error"); }
    }, "Ismi yonida ko'k galochka chiqadi. Emoji nishon uchun pastdagi tugmani bosing.");

    const bnSw = h("div", {class: "pe-sws"}), frSw = h("div", {class: "pe-sws"});
    const paintBn = () => {
      bnSw.textContent = "";
      const none = h("button", {type: "button", class: "pe-bn pe-off" + (!d.banner ? " on" : ""), title: "Fonsiz", "aria-label": "Fonsiz", text: "∅"}); none.addEventListener("click", () => { set("banner", ""); paintBn(); }); bnSw.append(none);
      BANNERS.forEach(([k, n]) => { const b = h("button", {type: "button", class: "pe-bn bn-" + k + (d.banner === k ? " on" : ""), title: n, "aria-label": n}); b.addEventListener("click", () => { set("banner", k); paintBn(); }); bnSw.append(b); });
    };
    const paintFr = () => {
      frSw.textContent = "";
      const none = h("button", {type: "button", class: "pe-fr pe-off" + (!d.frame ? " on" : ""), title: "Ramkasiz", "aria-label": "Ramkasiz", text: "∅"}); none.addEventListener("click", () => { set("frame", ""); paintFr(); }); frSw.append(none);
      FRAMES.forEach(([k, n]) => { const b = h("button", {type: "button", class: "pe-fr" + (d.frame === k ? " on" : ""), title: n, "aria-label": n}, h("span", {class: "av av-s fr-" + k})); b.addEventListener("click", () => { set("frame", k); paintFr(); }); frSw.append(b); });
    };
    paintBn(); paintFr();

    const colSw = h("div", {class: "pe-sws"});
    const paintCol = () => {
      colSw.textContent = "";
      PRESETS.forEach(c => { const b = h("button", {type: "button", class: "sw" + (d.color === c ? " on" : ""), title: c, "aria-label": c}); b.style.background = c; b.addEventListener("click", () => { set("color", c); paintCol(); }); colSw.append(b); });
      const pick = h("input", {type: "color"}); pick.value = d.color || TONES[t0.role] || "#7b61ff"; pick.addEventListener("input", () => set("color", pick.value)); pick.addEventListener("change", paintCol);
      colSw.append(h("label", {class: "sw-custom", title: "Boshqa rang"}, pick), h("button", {type: "button", class: "btn ghost sm", text: "Standart", onclick: () => { set("color", ""); paintCol(); }}));
    };
    paintCol();

    const save = h("button", {class: "btn", type: "button", text: "Saqlash"});
    save.addEventListener("click", async () => {
      // O'z dizayni: hamma /profile/design orqali. Unvon va ishonch belgisi: faqat admin, /admin/user/profile orqali.
      const own = {}, adm = {};
      if (self) {
        ["banner", "frame", "color"].forEach(k => { if (d[k] !== base[k]) own[k] = d[k]; });
        const fx = {}; FX_AREAS.forEach(a => { if ((d.fx[a] || "") !== (base.fx[a] || "")) fx[a] = d.fx[a] || ""; });
        if (Object.keys(fx).length) own.fx = fx;
      }
      if (admin) ["title", "trust"].forEach(k => { if (d[k] !== base[k] && (!self || k === "title")) adm[k] = d[k]; });
      if (!Object.keys(own).length && !Object.keys(adm).length) { toast("O'zgarish yo'q", "info"); return; }
      save.disabled = true; save.textContent = "Saqlanmoqda…";
      try {
        let j = null;
        if (Object.keys(own).length) j = await api("/profile/design", {method: "POST", body: own});
        if (Object.keys(adm).length) j = await api("/admin/user/profile", {method: "POST", body: Object.assign({user_id: uid}, adm)});
        apply(j); toast("Saqlandi", "ok"); closePage();
      }
      catch (err) { toast(err.message, "error"); save.disabled = false; save.textContent = "Saqlash"; }
    });
    paintPrev();
    const hint = (t) => h("p", {class: "tg-hint", text: t});
    const fxSec = (area, note) => h("div", {}, secTitle(FX[area].label), seg([["", "Yo'q"]].concat(FX[area].items), () => d.fx[area] || "", k => setFx(area, k)), note ? hint(note) : null);
    const reduced = FX_MQ && FX_MQ.matches ? hint("Bu qurilmada «animatsiyani kamaytirish» yoqilgan, shuning uchun effektlar namunada ko'rinmaydi. Saqlansa, boshqalarda ishlaydi.") : null;
    const titleSec = h("div", {}, secTitle("Unvon"), h("div", {class: "inf-form"}, field("Ism ostidagi qisqa yozuv", "title", {max: 24, ph: "Masalan: Moderator, VIP, Yordamchi"})));
    const saveRow = h("div", {class: "pe-save"}, save);
    const body = self
      ? h("div", {class: "pg-body pe-body"}, prev, reduced,
          admin ? null : hint("Nishon, unvon va ishonch belgisini faqat adminlar beradi. Qolgan dizaynni o'zingiz sozlaysiz."),
          fxSec("nick"), fxSec("user"), fxSec("bio"),
          fxSec("page", "Profil sahifasining o'zi uchun. Fon rangi va avatar ramkasi pastda alohida tanlanadi."),
          fxSec("reply", "Reply qilganingizda iqtibos qutisi shunday ko'rinadi."),
          fxSec("link", "Siz yuborgan havolalar shunday ko'rinadi."),
          secTitle("Profil foni"), bnSw,
          secTitle("Avatar ramkasi"), frSw,
          staff ? h("div", {}, secTitle("Profil rangi"), colSw) : null,
          admin ? titleSec : null,
          saveRow)
      : h("div", {class: "pg-body pe-body"}, prev,
          hint("Admin foydalanuvchiga dizayn bermaydi — dizaynni har kim o'zi sozlaydi. Bu yerda faqat unvon, ishonch belgisi va nishon beriladi."),
          staff ? null : h("div", {}, secTitle("Ishonch belgisi"),
            seg([["auto", "Avtomatik"], ["trusted", "Ishonchli"], ["new", "Yangi (ogohlantirish)"]], () => d.trust, k => set("trust", k)),
            hint("Avtomatik: akkaunt yoshi bo'yicha. «Ishonchli» — «⚠ Yangi» belgisi yo'qoladi. «Yangi» — eski akkauntda ham belgi ko'rsatiladi.")),
          checkRow ? h("div", {}, secTitle("Galochka va nishon"), checkRow) : secTitle("Nishon"),
          h("div", {class: "pe-row pe-pad"}, h("button", {class: "btn ghost sm", type: "button", onclick: () => openBadgePicker(U(uid), () => openProfileEditor(uid))}, "Emoji nishon tanlash")),
          titleSec,
          saveRow);
    return h("div", {}, pageHead(self ? "Profil dizayni" : "Unvon va ishonch: @" + t0.username), body);
  });
}

function setMode(m) {
  S.mode = m;
  $("tabL").classList.toggle("on", m === "login");
  $("tabR").classList.toggle("on", m === "register");
  $("nickWrap").classList.toggle("hidden", m === "login");
  $("regHint").classList.toggle("hidden", m === "login");
  $("submitBtn").textContent = m === "login" ? "Kirish" : "Ro'yxatdan o'tish";
  $("f_pass").autocomplete = m === "login" ? "current-password" : "new-password";
  $("autherr").textContent = "";
  $("unameChk").classList.add("hidden");
  if (m === "register") $("f_user").dispatchEvent(new Event("input"));
}
let unameTimer = null, unameSeq = 0;
$("f_user").addEventListener("input", () => {
  clearTimeout(unameTimer);
  const chk = $("unameChk"), v = $("f_user").value.trim().replace(/^@/, "");
  if (S.mode !== "register" || !v) { chk.classList.add("hidden"); return; }
  unameTimer = setTimeout(async () => {
    const seq = ++unameSeq;
    try {
      const r = await SC.fetch("/api/username/" + encodeURIComponent(v));
      if (!r.ok) return;
      const j = await r.json();
      if (seq !== unameSeq || S.mode !== "register") return;
      chk.className = "uchk " + (j.available ? "ok" : "bad");
      chk.textContent = j.available ? "✓ Username bo'sh" : "✗ " + j.reason;
    } catch (_) {}
  }, 300);
});
if (!SC.supported()) $("autherr").textContent = "Shifrlash uchun HTTPS (xavfsiz ulanish) kerak. Saytni https:// orqali oching.";
$("tabL").onclick = () => setMode("login");
$("tabR").onclick = () => setMode("register");

const JSON_H = {"Content-Type": "application/json"};
$("form").addEventListener("submit", async e => {
  e.preventDefault();
  const btn = $("submitBtn"); btn.disabled = true; $("autherr").textContent = "";
  const username = $("f_user").value.trim().replace(/^@/, ""), password = $("f_pass").value;
  try {
    if (!SC.supported()) throw new Error("Shifrlash uchun HTTPS (xavfsiz ulanish) kerak");
    $("autherr").textContent = "Shifrlash kalitlari tayyorlanmoqda…";
    await new Promise(r => setTimeout(r, 30));
    let r, gen = null;
    if (S.mode === "register") {
      gen = await xGenerate(username, password, E2E.KDF_DEFAULT);
      r = await SC.fetch("/api/register", {method: "POST", headers: JSON_H, body: JSON.stringify({username, nickname: $("f_nick").value.trim() || username, password: gen.kd.auth, e2ee: gen.keys, remember: $("f_stay").checked})});
    } else {
      const kr = await SC.fetch("/api/kdf", {method: "POST", headers: JSON_H, body: JSON.stringify({username})});
      const kp = await kr.json().catch(() => ({}));
      const secret = kp.auth_v === 0 ? password : (await E2E.deriveFromPassword(username, password, kp.kdf_iter || E2E.KDF_DEFAULT)).auth;
      r = await SC.fetch("/api/login", {method: "POST", headers: JSON_H, body: JSON.stringify({username, password: secret, remember: $("f_stay").checked})});
    }
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(typeof j.detail === "string" ? j.detail : "Xato, qayta urinib ko'ring");
    S.token = j.token; SC.setToken(S.token); S.lastAct = Date.now(); xReset();
    try {
      if (gen) await xInstall(j.me, j.me.username, gen.ident, gen.keys, E2E.KDF_DEFAULT, true);
      else await xUnlock({upgrade: j.upgrade, e2ee: j.e2ee}, j.me, j.me.username, password);
    } catch (err) { try { await SC.fetch("/api/logout", {method: "POST", headers: {Authorization: "Bearer " + S.token}}); } catch (_) {} S.token = null; SC.setToken(null); throw err; }
    $("f_pass").value = ""; $("autherr").textContent = "";
    if ($("f_stay").checked) await persistStay(); else await forgetStay();
    Off.arm({user: username, password, stay: $("f_stay").checked});
    openApp();
  } catch (err) { $("autherr").textContent = err.message; }
  btn.disabled = false;
});

function resetState() {
  S.offline = false; document.body.classList.remove("offline-mode");
  S.me = null; S.users = new Map(); S.members = []; S.online = new Set();
  S.group = {msgs: [], unread: 0, more: false}; S.dms = new Map(); S.chn = new Map(); S.chList = []; S.active = null; S.editing = null; S.query = ""; S.tab = "chats";
  S.replying = null; S.pendingImg = null; S.sending = false; S.sel = null; S.imgs = new Map();
  S.played.forEach(u => URL.revokeObjectURL(u)); S.played = new Map(); S.chat = {slowmode: 0, locked: false}; S.previews = new Map(); S.fx = new Map();
  cancelRecording(); voiceStop(); Pend.clear(); typingReset();
  ["replybar", "imgbar", "editbar"].forEach(id => $(id).classList.add("hidden"));
  $("search").value = ""; $("msgs").textContent = ""; $("inp").value = "";
  EM.data = null; EM.refresh = null; EM.tab = "std"; Rich.setEmojis([], true); $("emojiBtn").classList.add("hidden"); closeEmojiPanel();
}
function showAuth(msg) {
  $("f_user").value = ""; $("f_pass").value = "";
  S.wantClose = true;
  if (S.ws) try { S.ws.close(); } catch (_) {}
  SC.setToken(null); S.token = null; clearInterval(S.hb); S.hb = 0; clearTimeout(S.rt);
  try { localStorage.removeItem(LS_STAY); } catch (_) {} $("f_stay").checked = false;
  E2E.clearIdentity(); xReset(); blobUrls.forEach(p => p.then(u => URL.revokeObjectURL(u)).catch(() => {})); blobUrls.clear();
  closeModal(); closeCtx(); resetPages(); resetState(); Channels.reset(); Gaming.reset();
  document.body.classList.remove("in-chat"); navReset();
  $("app").classList.add("hidden"); $("auth").classList.remove("hidden");
  $("autherr").textContent = msg || "";
  document.title = APP_NAME;
}

async function askNotifications() {
  if (!S.token || !Push.shouldAsk()) return;
  Push.markAsked();
  const ok = await confirmDlg("Brauzer yopiq bo'lsa ham umumiy chatga yoki lichkangizga yozishsa, darhol xabar olasiz. Xabar matni bildirishnomada ko'rsatilmaydi.",
    {title: "Bildirishnomalarni yoqamizmi?", okText: "Yoqish"});
  if (!ok || !S.token) return;
  try { await Push.enable(api); toast("Bildirishnomalar yoqildi", "ok"); } catch (err) { toast(err.message, "error"); }
}
function applyPendingChannel() { const p = S.pendingOpen; if (p && p.k === "c") { S.pendingOpen = null; Channels.openById(p.u); } }
function openFromNotification(k, u) {
  if (!S.token || !S.me) { S.pendingOpen = {k, u}; return; }
  if (k === "c") { Channels.openById(u); return; }
  if (k === "x") { Gaming.openFromPush(); return; }
  if (k === "d" && u && u !== S.me.id) { if (S.users.has(u)) openChat({kind: "dm", uid: u}); else { S.pendingOpen = {k, u}; loadMembers().then(applyPendingOpen); } }
  else openChat({kind: "group"});
}
function applyPendingOpen() {
  const p = S.pendingOpen; if (!p) return;
  if (p.k === "d" && !S.users.has(p.u)) return;
  S.pendingOpen = null; openFromNotification(p.k, p.u);
}
window.addEventListener("ac-open-chat", e => openFromNotification(e.detail.k, e.detail.u));
try {
  const o = new URLSearchParams(location.search).get("o");
  if (o) {
    if (o === "g") S.pendingOpen = {k: "g"};
    else if (/^d\d{1,9}$/.test(o)) S.pendingOpen = {k: "d", u: parseInt(o.slice(1), 10)};
    else if (/^c\d{1,9}$/.test(o)) S.pendingOpen = {k: "c", u: parseInt(o.slice(1), 10)};
    else if (o === "x") S.pendingOpen = {k: "x"};
    history.replaceState(null, "", "/");
  }
} catch (_) {}
async function logout() {
  try { await Promise.race([Push.onLogout(api), delay(3000)]); } catch (_) {}
  try { await SC.fetch("/api/logout", {method: "POST", headers: {Authorization: "Bearer " + S.token}}); } catch (_) {}
  await Off.wipe();
  showAuth("");
}

const LS_SND = "ac_sound";
const LS_MUTED = "ac_muted_dm";
const mutedDm = (() => { try { return new Set(JSON.parse(localStorage.getItem(LS_MUTED) || "[]").filter(Number.isInteger)); } catch (_) { return new Set(); } })();
const isMuted = uid => mutedDm.has(uid);
function toggleMute(uid) {
  if (!mutedDm.delete(uid)) mutedDm.add(uid);
  try { localStorage.setItem(LS_MUTED, JSON.stringify([...mutedDm])); } catch (_) {}
  return mutedDm.has(uid);
}
const sndOn = () => { try { return localStorage.getItem(LS_SND) !== "off"; } catch (_) { return true; } };
let actx = null, lastTing = 0;
const audioCtx = () => { if (!actx) { const C = window.AudioContext || window.webkitAudioContext; if (C) { try { actx = new C(); } catch (_) {} } } return actx; };
["pointerdown", "keydown", "touchstart"].forEach(ev => addEventListener(ev, () => { const c = audioCtx(); if (c && c.state === "suspended") c.resume().catch(() => {}); }, {passive: true, capture: true}));
function ting(force) {
  if (!force && !sndOn()) return;
  const c = audioCtx(); if (!c || c.state !== "running") return;
  const t = c.currentTime;
  [[988, 0], [1480, 0.11]].forEach(([f, d]) => {
    const o = c.createOscillator(), g = c.createGain();
    o.type = "sine"; o.frequency.value = f;
    g.gain.setValueAtTime(0.0001, t + d); g.gain.exponentialRampToValueAtTime(0.28, t + d + 0.012); g.gain.exponentialRampToValueAtTime(0.0001, t + d + 0.42);
    o.connect(g); g.connect(c.destination); o.start(t + d); o.stop(t + d + 0.45);
  });
}
function pingSound(viewing) {
  if (viewing && !document.hidden) return;
  const n = Date.now(); if (n - lastTing < 700) return; lastTing = n;
  ting();
}

document.addEventListener("visibilitychange", () => { if (!document.hidden) { try { if (navigator.clearAppBadge) navigator.clearAppBadge(); } catch (_) {} } });

function toggleTheme() {
  const dark = document.documentElement.dataset.theme === "dark";
  if (window.ChatStyle) { ChatStyle.set({style: dark ? "classic" : "night"}); return; }
  const t = dark ? "light" : "dark";
  document.documentElement.dataset.theme = t;
  const mc = document.querySelector('meta[name="theme-color"]'); if (mc) mc.setAttribute("content", t === "dark" ? "#17212b" : "#ffffff");
  try { localStorage.setItem(LS_THEME, t); } catch (_) {}
}

function sendPresence() {
  const ws = S.ws; if (ws && ws.readyState === 1) ws.send(JSON.stringify({type: document.hidden && !isOwnerMe() ? "away" : "back"}));
}
function startHeartbeat(ws) {
  clearInterval(S.hb);
  S.hb = setInterval(() => {
    if (ws !== S.ws || ws.readyState !== 1) return;
    if (Date.now() - S.lastRx > HB_DEAD_MS) { try { ws.close(); } catch (_) {} return; }
    ws.send(JSON.stringify({type: "ping", i: Math.round((Date.now() - S.lastAct) / 1000)}));
  }, HB_MS);
}
function reconnectNow() {
  if (!S.token || S.wantClose) return;
  clearTimeout(S.rt); S.retry = 0;
  connect();
}
function connect() {
  S.wantClose = false;
  clearInterval(S.hb); clearTimeout(S.rt);
  if (S.ws) { const old = S.ws; S.ws = null; old.onclose = old.onmessage = old.onopen = null; try { old.close(); } catch (_) {} }
  const ws = SC.socket(S.token);
  S.ws = ws; S.q = Promise.resolve(); S.lastRx = Date.now();
  ws.onopen = () => { S.retry = 0; S.lastRx = Date.now(); $("connbar").classList.add("hidden"); startHeartbeat(ws); if (document.hidden) sendPresence(); Pend.flush(); };
  ws.onmessage = ev => {
    if (ws !== S.ws) return;
    S.lastRx = Date.now();
    S.q = S.q.then(async () => {
      const m = JSON.parse(ev.data);
      if (m.type === "pong") return;
      await Promise.race([prepare(m), delay(12000)]);
      if (ws === S.ws) onMessage(m);
    }).catch(err => console.error(err));
  };
  ws.onclose = ev => {
    if (S.wantClose || ws !== S.ws) return;
    clearInterval(S.hb); S.hb = 0; Pend.onClose();
    if (ev.code === WS_UNAUTHORIZED) return showAuth("Sessiya tugagan, qayta kiring");
    if (ev.code === WS_FORBIDDEN) return showAuth("Siz ban qilingansiz");
    if (ev.code === WS_IP_BLOCKED) return showAuth("IP manzilingiz bloklangan");
    $("connbar").textContent = connText(); $("connbar").classList.remove("hidden");
    S.retry++;
    S.rt = setTimeout(() => { if (S.token && !S.wantClose) connect(); }, Math.min(600 * S.retry, 6000));
  };
}

S.lastAct = Date.now();
(function () {
  let t = 0;
  const hit = () => { S.lastAct = Date.now(); };
  const slow = () => { const n = Date.now(); if (n - t > 1500) { t = n; S.lastAct = n; } };
  ["pointerdown", "keydown", "touchstart", "click", "input"].forEach(e => addEventListener(e, hit, {passive: true, capture: true}));
  ["pointermove", "wheel", "touchmove", "scroll"].forEach(e => addEventListener(e, slow, {passive: true, capture: true}));
})();

const stayOn = () => { try { return !!localStorage.getItem(LS_STAY); } catch (_) { return false; } };
const isOwnerMe = () => !!(S.me && S.me.role === "owner");
const idleOff = () => stayOn() || isOwnerMe();
const idleExpired = () => !idleOff() && Date.now() - S.lastAct > IDLE_MS;
async function persistStay() {
  try {
    localStorage.setItem(LS_STAY, S.token);
    await E2E.saveIdentity(X.id, {ecdhPriv: X.priv.ecdhPriv, signPriv: X.priv.signPriv, ecdhPub: X.ecdhPub, signPub: X.signPub, iter: X.iter});
  } catch (_) {}
  Off.armStay();
}
async function forgetStay() {
  try { localStorage.removeItem(LS_STAY); } catch (_) {}
  Off.disarmStay();
  try { await E2E.clearIdentity(); } catch (_) {}
}
async function toggleStay() {
  if (stayOn()) {
    try { await api("/session/persist", {method: "POST", body: {on: false}}); } catch (_) {}
    await forgetStay(); S.lastAct = Date.now();
    toast("Endi sahifa har safar ochilganda login so'raladi", "ok");
  } else {
    const ok = await confirmDlg("Bu qurilmada sahifani ochgan zahoti login so'ralmasdan kirasiz; sessiya va shifrlash kalitlari shu qurilmada saqlanadi. Qurilmani begonalarga bermang. Davom etamizmi?",
      {title: "Login so'rashni o'chirish", okText: "O'chirish"});
    if (!ok) return;
    try { await api("/session/persist", {method: "POST", body: {on: true}}); await persistStay(); toast("Bu qurilmada endi login so'ralmaydi", "ok"); }
    catch (err) { toast(err.message, "error"); }
  }
}
async function resumeStay(tok, tries) {
  $("autherr").textContent = "Kirilmoqda…";
  S.token = tok; SC.setToken(tok);
  let j;
  try { j = await api("/me"); }
  catch (err) {
    if (String(err.message) === "401") return;
    S.token = null; SC.setToken(null);
    try { await Off.ready(); } catch (_) {}
    if (Off.info && Off.info.mode === "stay" && !S.offline) { Off.open(); return; }
    $("autherr").textContent = "Ulanish yo'q, qayta urinilmoqda…";
    if (tries < 20) setTimeout(() => resumeStay(tok, tries + 1), 3000);
    return;
  }
  xReset(); S.lastAct = Date.now();
  let ok = false;
  try { ok = await xRestore({upgrade: j.upgrade, e2ee: j.e2ee}, j.me); } catch (_) {}
  if (!ok) { try { await SC.fetch("/api/logout", {method: "POST", headers: {Authorization: "Bearer " + tok}}); } catch (_) {} showAuth("Kalitlarni ochib bo'lmadi, qayta kiring"); return; }
  $("autherr").textContent = "";
  Off.armStay();
  openApp();
}
async function idleLogout() {
  if (!S.token) return;
  const t = S.token;
  showAuth("Uzoq vaqt faol bo'lmadingiz. Xavfsizlik uchun qayta kiring");
  try { await Promise.race([SC.fetch("/api/logout", {method: "POST", headers: {Authorization: "Bearer " + t}}), delay(4000)]); } catch (_) {}
}
function checkIdle() {
  if (!S.token) return;

  if ([...document.querySelectorAll("video,audio")].some(m => !m.paused && !m.ended) || (VP.audio && !VP.audio.paused)) S.lastAct = Date.now();
  if (idleExpired()) idleLogout();
}
setInterval(checkIdle, 10000);

document.addEventListener("visibilitychange", () => {
  if (!S.token) return;
  if (document.hidden) { S.hiddenAt = Date.now(); sendPresence(); return; }
  if (idleExpired()) { idleLogout(); return; }
  if (!S.ws || S.ws.readyState !== 1) reconnectNow(); else sendPresence();
});
addEventListener("pagehide", () => { if (S.token && S.ws) { try { S.ws.close(); } catch (_) {} } });
addEventListener("pageshow", e => { if (e.persisted && S.token) { if (idleExpired()) idleLogout(); else reconnectNow(); } });
addEventListener("online", () => { if (S.token && (!S.ws || S.ws.readyState !== 1)) reconnectNow(); });
const connText = () => navigator.onLine === false ? "📴 Internet yo'q — yozganlaringiz navbatda turadi va ulanishi bilan yuboriladi" : "Ulanish uzildi, qayta ulanmoqda…";
addEventListener("offline", () => { if (S.token && !S.offline) { $("connbar").textContent = connText(); $("connbar").classList.remove("hidden"); } });
addEventListener("online", () => { if (S.token && !S.offline) $("connbar").textContent = "Ulanmoqda…"; });

async function prepare(m) {
  if (X.ready) await Promise.race([X.ready, delay(8000)]);
  if (m.type === "init") await hydrateAll(m.history);
  else if (m.type === "message") await hydrate(m);
  else if (m.type === "message_edited" && m.e2e) {
    const {list} = findMsg(m.id, m.to, m.from, m.ch), x = list.find(i => i.id === m.id);
    if (x) { m._h = Object.assign({}, x, {e2e: m.e2e}); await hydrate(m._h); }
  }
}
function eachMsg(fn) { S.group.msgs.forEach(fn); S.dms.forEach(d => { d.msgs.forEach(fn); d.buffer.forEach(fn); }); }
const snippetOf = t => {
  t = (t || "").replace(/\s+/g, " ");
  if (t.length <= 100) return t;
  let cut = 100;
  for (const m of Rich.emojiMatches(t)) if (m.i < cut && m.i + m.t.length > cut) { cut = m.i; break; }
  return t.slice(0, cut);
};
function partnerOf(m) { return m.user.id === S.me.id ? m.to : m.user.id; }
function findMsg(id, to, from, ch) {
  if (ch) return {list: chOf(ch).msgs, dm: null, ch};
  if (to == null) return {list: S.group.msgs, dm: null};
  const dm = dmOf(from === S.me.id ? to : from);
  return {list: dm.msgs, dm};
}
const atBottom = () => { const b = $("msgs"); return b.scrollHeight - b.scrollTop - b.clientHeight < 80; };
const isActiveGroup = () => S.active && S.active.kind === "group";
const isActiveDm = uid => S.active && S.active.kind === "dm" && S.active.uid === uid;

function onMessage(m) {
  switch (m.type) {
    case "init": {
      setTimeout(() => Gaming.sync(), 500);
      S.me = Object.assign({}, S.me, m.me); upsertUser(m.me);
      S.online = new Set(m.online_ids);
      m.history.forEach(x => upsertUser(x.user));
      mergeHistory(S.group, m.history, !!m.more);
      S.chat = m.chat || {slowmode: 0, locked: false};
      loadMembers(); loadDialogs();
      if (S.active && S.active.kind === "dm") reloadActiveDm();
      if (S.active && (S.active.kind === "group" || S.active.kind === "dm")) pinsRefresh();
      if (S.active && S.active.kind === "channel") reloadActiveChannel();
      if (!S.active && !isMobile()) openChat({kind: "group"}); else { renderList(); renderHeader(); renderMessages(true); }
      if (S.pendingOpen) { if (S.pendingOpen.k !== "d") applyPendingOpen(); else if (X.ready) X.ready.then(applyPendingOpen); }
      break; }
    case "nack": Pend.nack(m); break;
    case "message": {
      upsertUser(m.user);
      if (m.ch) { onChannelPost(m); break; }
      const mine = m.user.id === S.me.id;
      if (mine && m.id != null) {
        const arr = m.to == null ? S.group.msgs : (() => { const d = dmOf(partnerOf(m)); return d.loaded ? d.msgs : d.buffer; })();
        if (arr.slice(-80).some(x => x && x.id === m.id)) { const q = m.cid && Pend.list.find(x => x.cid === m.cid); if (q) Pend.drop(q); break; }
      }
      if (mine) Pend.settle(m); else typingClearFrom(m.user.id);
      const muted = !mine && m.to != null && isMuted(m.user.id);
      if (!mine && !muted) pingSound(m.to == null ? isActiveGroup() : isActiveDm(partnerOf(m)));
      if (!mine && !muted && document.hidden && Date.now() - (S.hiddenAt || 0) < 7000)
        Push.local({k: m.to == null ? "g" : "d", u: m.user.id, i: m.id, n: m.user.nickname || m.user.username, t: Math.floor(Date.now() / 1000)});
      if (m.to == null) {
        const stick = atBottom();
        S.group.msgs.push(m);
        if (isActiveGroup()) {
          appendMessage(m, mine || stick);
          if (!mine && !stick) bumpAway();
        } else if (!mine) S.group.unread++;
      } else {
        const pid = partnerOf(m), dm = dmOf(pid);
        if (!S.users.has(pid)) loadMembers();
        dm.last = m;
        if (dm.loaded) dm.msgs.push(m); else dm.buffer.push(m);
        if (isActiveDm(pid)) {
          const stick = atBottom();
          appendMessage(m, mine || stick);
          if (!mine) {
            if (!document.hidden) { dm.unread = 0; wsSend({type: "read", with: pid}); }
            else dm.unread++;
            if (!stick) bumpAway();
          }
        } else if (!mine) dm.unread++;
      }
      renderList();
      break; }
    case "message_edited": {
      const {list, dm, ch} = findMsg(m.id, m.to, m.from, m.ch);
      const x = list.find(i => i.id === m.id);
      if (m._h) m.content = m._h.content;
      if (x) {
        if (m._h) Object.assign(x, {content: m._h.content, e2e: m.e2e, verified: m._h.verified, bad: m._h.bad, locked: m._h.locked, _r: m._h._r, reply: m._h.reply});
        else x.content = m.content;
        x.edited = true;
      }
      eachMsg(y => { if (y.reply && y.reply.id === m.id && !y.reply.deleted) y.reply.text = snippetOf(m.content); });
      if (dm && dm.last && dm.last.id === m.id) { dm.last.content = m.content; dm.last.edited = true; if (m._h) Object.assign(dm.last, {e2e: m.e2e, bad: m._h.bad, locked: m._h.locked}); }
      if (ch) { const st = chOf(ch); if (st.last && st.last.id === m.id && st.last !== x && m._h) Object.assign(st.last, {content: m._h.content, e2e: m.e2e, bad: m._h.bad, locked: m._h.locked}); }
      renderMessages(false); renderList();
      break; }
    case "message_reaction": {
      const {list, dm} = findMsg(m.id, m.to, m.from, m.ch);
      const x = list.find(i => i.id === m.id) || (dm && dm.buffer.find(i => i.id === m.id));
      if (x) { x.rx = m.rx || {}; patchReactions(x); }
      break; }
    case "pins_changed": pinsOnEvent(m); break;
    case "message_deleted": {
      pinDrop(m.id);
      const {list, dm, ch} = findMsg(m.id, m.to, m.from, m.ch);
      const i = list.findIndex(x => x.id === m.id);
      if (i >= 0) list.splice(i, 1);
      eachMsg(y => { if (y.reply && y.reply.id === m.id) y.reply = {id: m.id, deleted: true}; });
      if (S.editing && S.editing.id === m.id) cancelEdit();
      if (S.replying && S.replying.id === m.id) cancelReply();
      if (VP.id === m.id) voiceStop();
      if (VN.id === m.id) vnStop();
      if (S.sel && S.sel.delete(m.id)) updateSelBar();
      if (ch) {
        const st = chOf(ch), info = chInfo(ch);
        st.buffer = st.buffer.filter(x => x.id !== m.id);
        if (st.last && st.last.id === m.id) st.last = st.msgs.length ? st.msgs[st.msgs.length - 1] : null;
        if (info && info.posts > 0) info.posts--;
        Channels.postGone(ch, m.id);
      }
      if (dm) {
        dm.buffer = dm.buffer.filter(x => x.id !== m.id);
        if (dm.last && dm.last.id === m.id) { dm.last = dm.msgs.length ? dm.msgs[dm.msgs.length - 1] : null; if (!dm.loaded || !dm.last) loadDialogs(); }
      }
      scheduleRender();
      break; }
    case "channels_changed": case "channel_post": case "channel_post_edited": case "channel_post_deleted":
    case "channel_views": case "channel_comment": case "channel_comment_deleted":
      Channels.onEvent(m); break;
    case "chat_settings":
      S.chat = {slowmode: m.slowmode || 0, locked: !!m.locked};
      renderHeader();
      if (isActiveGroup() && !amAdmin()) toast(S.chat.locked ? "Admin umumiy chatni qulfladi" : (S.chat.slowmode ? "Sekin rejim: " + S.chat.slowmode + " soniya" : "Umumiy chat ochildi"), "warn");
      break;
    case "media_removed": {
      const x = S.group.msgs.find(i => i.id === m.id);
      if (x) { x.image = null; x.thumb = null; x.w = x.h = null; x.file = null; }
      S.imgs.delete(m.id); if (VP.id === m.id) voiceStop(); if (VN.id === m.id) vnStop();
      const u = S.played.get(m.id); if (u) { URL.revokeObjectURL(u); S.played.delete(m.id); }
      eachMsg(y => { if (y.reply && y.reply.id === m.id) { y.reply.image = false; y.reply.file = false; } });
      renderMessages(false); renderList();
      break; }
    case "e2ee_room": case "e2ee_wrap": loadRoom().catch(() => {}); break;
    case "e2ee_rotate_hint": if (amAdmin()) rotateRoom(m.reason); break;
    case "report_new": toast("Yangi shikoyat keldi (☰ → Admin sozlamalari → Shikoyatlar)", "warn"); break;
    case "chat_cleared": {
      const gone = new Set(S.group.msgs.map(x => x.id));
      eachMsg(y => { if (y.reply && gone.has(y.reply.id)) y.reply = {id: y.reply.id, deleted: true}; });
      S.group.msgs = []; S.group.pins = [];
      if (isActiveGroup()) { cancelEdit(); cancelReply(); exitSelect(); }
      renderMessages(false); renderList();
      toast(m.by === S.me.id ? "Chat tozalandi" : "Admin umumiy chatni tozaladi", "ok");
      break; }
    case "read": {
      const dm = S.dms.get(m.by);
      if (dm) {
        dm.msgs.forEach(x => { if (x.user.id === S.me.id) x.read = true; });
        if (dm.last && dm.last.user.id === S.me.id) dm.last.read = true;
        if (isActiveDm(m.by)) renderMessages(false);
      }
      break; }
    case "typing": onTyping(m); break;
    case "presence":
      if (m.online) S.online.add(m.uid); else { S.online.delete(m.uid); const pu = S.users.get(m.uid); if (pu && m.ts) pu.last_seen = m.ts; typingClearFrom(m.uid); }
      if (!S.users.has(m.uid)) loadMembers();
      renderList(); renderHeader(); refreshModal();
      break;
    case "members_changed": loadMembers(); loadDialogs(); break;
    case "dm_cleared": {
      const other = m.a === S.me.id ? m.b : m.a;
      S.dms.delete(other);
      const wasActive = isActiveDm(other);
      if (wasActive) closeChat();
      renderList();
      toast(m.a === S.me.id ? "Suhbat o'chirildi" : "Suhbat o'chirildi (boshqa tomon o'chirdi)", "ok");
      break; }
    case "user_removed":
      upsertUser(m.user);
      S.members = S.members.filter(x => x.id !== m.user.id); S.online.delete(m.user.id);
      renderList(); renderHeader(); renderMessages(false); refreshModal();
      break;
    case "account_removed": showAuth("Akkauntingiz o'chirildi"); break;
    case "emoji_update": loadEmojis(); break;
    case "game_invite": case "game_invite_sent": case "game_invite_end": case "game_state": case "game_over": case "game_react": Gaming.onWs(m); break;
    case "user_update":
      upsertUser(m.user);
      renderList(); renderHeader(); renderMessages(false); refreshModal();
      break;
    case "system":
      toast(m.lines.join("\n"), m.level);
      if (m.level === "warn") { S.group.msgs.push({service: true, text: m.lines.join(" "), ts: Date.now() / 1000}); if (isActiveGroup()) renderMessages(false); }
      break;
    case "banned": showAuth("Siz ban qilindingiz" + (m.reason ? ": " + m.reason : "")); break;
  }
}

function onChannelPost(m) {
  const mine = m.user.id === S.me.id, st = chOf(m.ch), info = chInfo(m.ch);
  if (mine) {
    const known = x => x && x.id === m.id;
    if (st.msgs.slice(-80).some(known) || st.buffer.slice(-80).some(known)) {
      const q = (m.cid && Pend.list.find(x => x.cid === m.cid)) || Pend.list.find(x => x.key === "c" + m.ch && (x.stage === "sent" || x.stage === "wait"));
      if (q) Pend.drop(q);
      return;
    }
    Pend.settle(m);
  }
  if (!mine) pingSound(isActiveChan(m.ch));
  if (!mine && document.hidden && Date.now() - (S.hiddenAt || 0) < 7000)
    Push.local({k: "c", u: m.ch, i: m.id, n: info ? info.nickname : "Kanal", t: Math.floor(Date.now() / 1000)});
  if (info) { info.posts++; info.last_post = m.id; info.last_ts = m.ts; S.chList.sort((a, b) => (b.last_ts || b.created || 0) - (a.last_ts || a.created || 0)); }
  else Channels.loadList();
  st.last = m;
  if (st.loaded) { if (!st.msgs.some(x => x.id === m.id)) st.msgs.push(m); }
  else if (!st.buffer.some(x => x.id === m.id)) st.buffer.push(m);
  if (isActiveChan(m.ch)) {
    const stick = atBottom();
    appendMessage(m, mine || stick);
    if (!mine && !stick) bumpAway();
    renderHeader();
  } else if (!mine) st.unread++;
  renderList();
}
async function loadChannelPosts(id) {
  const st = chOf(id);
  const j = await api("/channels/" + id + "/posts?limit=10");
  if (X.ready) await Promise.race([X.ready, delay(8000)]);
  await hydrateAll(j.posts);
  j.posts.forEach(x => upsertUser(x.user));
  const ids = new Set(j.posts.map(x => x.id));
  const fresh = j.posts.concat(st.buffer.filter(x => !ids.has(x.id))).sort((a, b) => a.id - b.id);
  mergeHistory(st, fresh, !!j.more);
  st.buffer = []; st.loaded = true;
  if (st.msgs.length) st.last = st.msgs[st.msgs.length - 1];
}
async function reloadActiveChannel() {
  const id = S.active.id;
  try { await loadChannelPosts(id); if (isActiveChan(id)) renderMessages(true); } catch (_) {}
}

async function setChannelList(list) {
  S.chList = list;
  renderList(); renderHeader();
  if (X.ready) await Promise.race([X.ready, delay(8000)]);
  for (const c of list) {
    if (!c.last) continue;
    const st = chOf(c.id);
    if (st.last && st.last.id >= c.last.id) continue;
    upsertUser(c.last.user); await hydrate(c.last); st.last = c.last;
  }
  renderList();
}
function chanAvatar(c, size) {
  const el = h("div", {class: "av av-" + size + " chn"});
  el.style.setProperty("--avc", colorOf((c.id || 0) + 3));
  if (c.avatar) el.append(h("img", {src: c.avatar, alt: "", draggable: "false"}));
  else el.append(h("span", {text: (Array.from((c.nickname || "?").trim())[0] || "?").toUpperCase()}));
  return el;
}

function patchPost(ch, pid, fields) {
  const m = chOf(ch).msgs.find(x => x.id === pid);
  if (m) Object.assign(m, fields);
  if (!isActiveChan(ch)) return;
  const row = document.querySelector('#msgs .row[data-id="' + Number(pid) + '"]'); if (!row) return;
  const v = row.querySelector(".vws b"); if (v && fields.views != null) v.textContent = String(fields.views);
  const c = row.querySelector(".cmb-t"); if (c && fields.comments != null) c.textContent = fields.comments ? fields.comments + " ta izoh" : "Izoh qoldirish";
}

async function loadMembers() {
  try {
    const j = await api("/members");
    S.members = j.members; S.online = new Set(j.online_ids);
    j.members.forEach(upsertUser);
    renderList(); renderHeader(); refreshModal();
    serveWraps();
  } catch (_) {}
}
async function loadDialogs() {
  try {
    const j = await api("/dialogs");
    if (X.ready) await X.ready;
    await hydrateAll(j.dialogs.map(d => d.last).filter(Boolean));
    const seen = new Set();
    j.dialogs.forEach(d => {
      upsertUser(d.user); seen.add(d.user.id);
      const dm = dmOf(d.user.id); dm.last = d.last; dm.unread = isActiveDm(d.user.id) ? 0 : d.unread;
    });
    S.dms.forEach((dm, uid) => {
      if (seen.has(uid)) return;
      if (isActiveDm(uid)) { dm.msgs = []; dm.buffer = []; dm.last = null; renderMessages(false); }
      else S.dms.delete(uid);
    });
    renderList();
  } catch (_) {}
}
async function loadDm(uid) {
  const dm = dmOf(uid);
  const j = await api("/dm/" + uid);
  if (X.ready) await Promise.race([X.ready, delay(8000)]);
  await hydrateAll(j.history);
  const ids = new Set(j.history.map(x => x.id));
  const fresh = j.history.concat(dm.buffer.filter(x => !ids.has(x.id))).sort((a, b) => a.id - b.id);
  mergeHistory(dm, fresh, !!j.more);
  dm.buffer = []; dm.loaded = true;
  if (dm.msgs.length) dm.last = dm.msgs[dm.msgs.length - 1];
}

function mergeHistory(st, fresh, more) {
  const old = st.msgs.filter(x => !x.service && x.id);
  if (!old.length || !fresh.length || old[old.length - 1].id < fresh[0].id) { st.msgs = fresh.slice(); st.more = more; return; }
  const keep = old.filter(x => x.id < fresh[0].id);
  st.msgs = keep.concat(fresh);
  if (!keep.length) st.more = more;
}
async function loadOlder() {
  if (!S.active || S.olderBusy) return;
  const kind = S.active.kind, isG = kind === "group", isC = kind === "channel", uid = S.active.uid, cid = S.active.id;
  const st = isG ? S.group : isC ? chOf(cid) : dmOf(uid);
  if (st.msgs.length > (S.win || WIN0)) {
    const bx = $("msgs"), ph = bx.scrollHeight, pt = bx.scrollTop;
    S.win = (S.win || WIN0) + 40; renderMessages(false); bx.scrollTop = pt + (bx.scrollHeight - ph); return;
  }
  if (!st.more) return;
  const first = st.msgs.find(x => !x.service && x.id); if (!first) return;
  S.olderBusy = true;
  const box = $("msgs"), btn = box.querySelector(".older"); if (btn) btn.textContent = "Yuklanmoqda…";
  try {
    const j = await api(isG ? "/group/history?before=" + first.id : isC ? "/channels/" + cid + "/posts?limit=20&before=" + first.id : "/dm/" + uid + "?before=" + first.id);
    const older = isC ? j.posts : j.history;
    if (X.ready) await Promise.race([X.ready, delay(8000)]);
    await hydrateAll(older);
    older.forEach(x => upsertUser(x.user));
    const have = new Set(st.msgs.map(x => x.id));
    st.msgs = older.filter(x => !have.has(x.id)).concat(st.msgs);
    S.win = (S.win || WIN0) + older.length;
    st.more = !!j.more;
    if (S.active && S.active.kind === kind && (isG || (isC ? S.active.id === cid : S.active.uid === uid))) {
      const prevH = box.scrollHeight, prevT = box.scrollTop;
      renderMessages(false);
      box.scrollTop = prevT + (box.scrollHeight - prevH);
    }
  } catch (err) { toast(err.message, "error"); if (btn) btn.textContent = "⬆ Oldingi xabarlar"; }
  S.olderBusy = false;
}
async function reloadActiveDm() {
  const uid = S.active.uid;
  try { await loadDm(uid); if (isActiveDm(uid)) { renderMessages(true); wsSend({type: "read", with: uid}); } } catch (_) {}
}

function itemEl({av, title, sub, subOn, time, unread, active, onclick, onctx}) {
  const el = h("div", {class: "item" + (active ? " active" : ""), onclick, oncontextmenu: onctx ? e => { e.preventDefault(); e.stopPropagation(); onctx(e.clientX, e.clientY); } : null},
    av,
    h("div", {class: "i-mid"},
      h("div", {class: "i-top"}, h("div", {class: "i-title"}, title), time ? h("span", {class: "i-time", text: time}) : null),
      h("div", {class: "i-bot"}, h("div", {class: "i-sub" + (subOn ? " on" : "")}, sub),
        unread ? h("span", {class: "pill", text: unread > 99 ? "99+" : String(unread)}) : null)));
  if (onctx) longPress(el, (x, y) => onctx(x, y, true));
  return el;
}
const typingSub = key => { const t = typingLabel(key); return t ? h("span", {class: "typing"}, t) : null; };
function previewOf(m, withAuthor, plain) {
  if (!m) return "";
  const mine = !plain && m.user.id === S.me.id;
  let body = m.locked ? "🔒 Shifrlangan xabar" : m.bad ? "⚠ Shifrni ochib bo'lmadi" : m.content;
  if (!m.locked && !m.bad && m.content) {
    const rp = Rich.parse(m.content), rc = rp.find(x => x.k !== "text");
    if (rc) body = (rc.k === "term" ? "⌨ Linux buyruq: " + Rich.copyTextOf(rc).split("\n")[0] : "‹/› " + (rc.label || "Kod") + ": " + rc.code.split("\n")[0]);
  }
  const text = (m.image ? "📷 " : m.file ? fileIco(m.file) : "") + (body ? body.replace(/\s+/g, " ") : (m.image ? "Rasm" : m.file ? fileWhat(m.file) : ""));
  const shown = Rich.hasInlineEmoji(text) ? Rich.preview(text) : text;
  if (mine) return [h("b", {text: "Siz: "}), shown];
  return withAuthor ? [h("b", {text: m.user.nickname + ": "}), shown] : shown;
}
function groupItem() {
  const last = [...S.group.msgs].reverse().find(x => !x.service);
  return itemEl({
    av: groupAvatar("m"), title: h("span", {class: "nt", text: "Umumiy chat"}),
    sub: typingSub("g") || (last ? previewOf(last, true) : "Hozircha xabar yo'q"), subOn: !!typingLabel("g"), time: last ? listTime(last.ts) : "",
    unread: S.group.unread, active: isActiveGroup(), onclick: () => openChat({kind: "group"}),
  });
}
function dmItem(u, dm) {
  return itemEl({
    av: avatar(u, "m", true), title: nameEl(u), sub: typingSub("d" + u.id) || previewOf(dm.last, false), subOn: !!typingLabel("d" + u.id), time: listTime(dm.last.ts),
    unread: dm.unread, active: isActiveDm(u.id), onclick: () => openChat({kind: "dm", uid: u.id}),
    onctx: (x, y, touch) => dmMenu(x, y, u.id, touch),
  });
}
function chanItem(c) {
  const st = chOf(c.id), last = st.last;
  return itemEl({
    av: chanAvatar(c, "m"), title: [h("span", {class: "nt", text: c.nickname}), c.private ? icon("lock", "ic ch-lock") : null],
    sub: last ? previewOf(last, false, true) : c.posts ? c.posts + " post" : "Hozircha post yo'q",
    time: last ? listTime(last.ts) : "", unread: st.unread, active: isActiveChan(c.id), onclick: () => openChat({kind: "channel", id: c.id}),
  });
}
function memberItem(u) {
  const sub = (isStaff(u) ? roleLabel(u.role) + " • " : "") + statusText(u);
  return itemEl({
    av: avatar(u, "m", true), title: nameEl(u), sub, subOn: isOnline(u.id),
    active: isActiveDm(u.id), onclick: () => openChat({kind: "dm", uid: u.id}),
  });
}
function renderList() {
  if (!S.me) return;
  Off.dirty();
  const list = $("list"), top = list.scrollTop;
  list.textContent = "";
  const q = S.query.trim().toLowerCase();
  const match = u => !q || u.nickname.toLowerCase().includes(q) || u.username.toLowerCase().includes(q);
  if (S.tab === "chats") {
    if (!q || "umumiy chat".includes(q)) list.append(groupItem());
    const dms = [...S.dms.entries()].filter(([, d]) => d.last).sort((a, b) => b[1].last.ts - a[1].last.ts);
    dms.forEach(([id, d]) => { const u = U(id); if (match(u)) list.append(dmItem(u, d)); });
    if (q) {
      const shown = new Set(dms.map(([id]) => id));
      const others = S.members.filter(m => m.id !== S.me.id && !shown.has(m.id) && match(m));
      if (others.length) { list.append(h("div", {class: "sect", text: "A'zolar"})); others.forEach(m => list.append(memberItem(U(m.id)))); }
    }
    if (!list.children.length) list.append(h("div", {class: "none", text: "Hech narsa topilmadi"}));
  } else if (S.tab === "channels") {
    list.append(h("div", {class: "chn-bar"},
      amAdmin() ? h("button", {class: "btn ghost sm", type: "button", onclick: () => Channels.create()}, icon("plus"), " Kanal yaratish") : null,
      h("button", {class: "btn ghost sm", type: "button", onclick: () => Channels.join()}, icon("lock"), " Shaxsiy kanalga qo'shilish")));
    const cs = S.chList.filter(c => !q || c.nickname.toLowerCase().includes(q) || c.username.toLowerCase().includes(q));
    cs.forEach(c => list.append(chanItem(c)));
    if (!cs.length) list.append(h("div", {class: "none", text: S.chList.length ? "Hech narsa topilmadi" : "Hozircha kanallar yo'q"}));
  } else {
    Gaming.tabList(list);
  }
  list.scrollTop = top;
  updateBadges();
}
function updateBadges() {
  let total = S.group.unread, ctot = 0;
  S.dms.forEach(d => { total += d.unread; });
  S.chn.forEach(c => { ctot += c.unread; });
  const b = $("chatsBadge");
  b.classList.toggle("hidden", !total); b.textContent = total > 99 ? "99+" : String(total);
  const cb = $("chnBadge");
  cb.classList.toggle("hidden", !ctot); cb.textContent = ctot > 99 ? "99+" : String(ctot);
  document.title = (total + ctot ? "(" + (total + ctot) + ") " : "") + APP_NAME;
}
document.querySelectorAll(".tabs button[data-tab]").forEach(btn => btn.addEventListener("click", () => {
  S.tab = btn.dataset.tab;
  document.querySelectorAll(".tabs button").forEach(x => x.classList.toggle("on", x === btn));
  renderList();
  if (S.tab === "channels") Channels.loadList();
}));
$("search").addEventListener("input", e => { S.query = e.target.value; renderList(); });

const ADM_SECTIONS = [
  ["ips", "shield", "IP lar va profillar"],
  ["users", "user", "Foydalanuvchilar, nishon va zaxira"],
  ["log", "list", "Harakatlar logi"],
  ["blocks", "ban", "Bloklangan IP lar"],
  ["media", "attach", "Media boshqaruvi"],
  ["reports", "flag", "Shikoyatlar"],
  ["mod", "shield", "Moderatsiya sozlamalari"],
];
const ADM_TITLES = {msgs: "Xabarlar", emoji: "Emoji boshqaruvi"};
ADM_SECTIONS.forEach(([k, , t]) => { ADM_TITLES[k] = t; });
function openAdminHome() {
  if (!amAdmin()) return;
  openPage(() => {
    const wrap = h("div", {}, pageHead("Admin sozlamalari"), gapEl());
    ADM_SECTIONS.forEach(([k, ic, t]) => wrap.append(setRow(ic, t, () => openAdmin(k))));
    wrap.append(gapEl(), setRow("chat", "Xabarlar", () => openAdmin("msgs")), setRow("emoji", "Emoji boshqaruvi", () => openAdmin("emoji")));
    wrap.append(gapEl(), setRow("trash", "Umumiy chatni tozalash", () => clearGroupChat(), null, true));
    return wrap;
  });
}

function currentMsgs() {
  if (!S.active) return [];
  if (S.active.kind === "channel") return chOf(S.active.id).msgs;
  return S.active.kind === "group" ? S.group.msgs : dmOf(S.active.uid).msgs;
}

const chatKey = t => !t ? "" : t.kind === "dm" ? "d" + t.uid : t.kind === "channel" ? "c" + t.id : "g";
let _closeT = 0;
function wipeChatDom() {
  const box = $("msgs"); box.textContent = ""; box._for = ""; box._n = 0;
  $("hav").textContent = ""; $("htitle").textContent = ""; $("hsub").textContent = ""; $("pinBar").classList.add("hidden");
}
async function openChat(target) {
  clearTimeout(_closeT);
  if (chatKey(target) !== $("msgs")._for) wipeChatDom();
  $("chat").classList.add("opening"); requestAnimationFrame(() => requestAnimationFrame(() => $("chat").classList.remove("opening")));
  if (S.sel) { S.sel = null; $("chat").classList.remove("selecting"); navPop("sel"); }
  Channels.closeComments(false);
  Typing.stop(); S.active = target; S.win = WIN0;
  cancelRecording(); cancelEdit(); cancelReply(); clearPendingImage(); $("inp").value = ""; autosize(); S.away = 0; bumpAway(true);
  $("empty").classList.add("hidden"); $("chat").classList.remove("hidden");
  document.body.classList.add("in-chat");
  if (isMobile()) navPush("chat");
  if (target.kind === "group") S.group.unread = 0;
  else if (target.kind === "channel") {
    const st = chOf(target.id); st.unread = 0;
    if (!st.loaded) {
      renderHeader(); $("msgs").textContent = "";
      try { await loadChannelPosts(target.id); } catch (err) { toast(err.message, "error"); }
      if (!isActiveChan(target.id)) return;
    }
  } else {
    const dm = dmOf(target.uid); dm.unread = 0;
    if (!dm.loaded) {
      renderHeader(); $("msgs").textContent = "";
      try { await loadDm(target.uid); } catch (err) { toast(err.message, "error"); }
      if (!isActiveDm(target.uid)) return;
    }
    if (!S.offline) wsSend({type: "read", with: target.uid});
  }
  renderHeader(); renderMessages(true); renderList();
  pinsRefresh();
  autosize();
  if (!isMobile()) $("inp").focus();
  Composer.guard(); requestAnimationFrame(Composer.guard); setTimeout(Composer.guard, 350); setTimeout(Composer.guard, 1200);
}
function closeChat() {
  Typing.stop(); voiceStop();
  Channels.closeComments(false);
  if (S.sel) { S.sel = null; $("chat").classList.remove("selecting"); navPop("sel"); }
  S.active = null; cancelEdit(); cancelReply(); clearPendingImage();
  document.body.classList.remove("in-chat"); navPop("chat");
  if (!isMobile()) { $("chat").classList.add("hidden"); $("empty").classList.remove("hidden"); wipeChatDom(); }
  else {
    clearTimeout(_closeT);
    _closeT = setTimeout(() => { if (!S.active) { wipeChatDom(); $("chat").classList.add("hidden"); } }, 520);
  }
  renderList();
}
function renderHeader() {
  if (!S.active || !S.me) return;
  const av = $("hav"), title = $("htitle"), sub = $("hsub");
  av.textContent = ""; title.textContent = ""; sub.className = "hsub";
  if (S.active.kind === "group") {
    av.append(groupAvatar("m")); title.append(h("span", {class: "nt", text: "Umumiy chat"}));
    sub.textContent = (S.members.length || 1) + " a'zo" + (S.offline ? "" : ", " + onlineCount() + " onlayn") + (S.chat.locked ? " • 🔒 qulflangan" : S.chat.slowmode ? " • 🐢 " + S.chat.slowmode + " s" : "") + (X.epoch && !X.rooms.has(X.epoch) ? " • ⏳ kalit kutilmoqda" : "");
    const tg = typingLabel("g"); if (tg) { sub.textContent = tg; sub.classList.add("on", "typing"); }
  } else if (S.active.kind === "channel") {
    const c = chInfo(S.active.id);
    av.append(chanAvatar(c || {id: S.active.id, nickname: "?"}, "m"));
    title.append(h("span", {class: "nt", text: c ? c.nickname : "Kanal"})); if (c && c.private) title.append(icon("lock", "ic ch-lock"));
    sub.textContent = c ? "@" + c.username + " • " + c.posts + " post" + (c.private ? " • shaxsiy" : "") + (c.can_manage && c.private ? " • " + (c.members || 0) + " a'zo" : "") : "";
  } else {
    const u = U(S.active.uid);
    av.append(avatar(u, "m", true)); title.append(nameEl(u));
    sub.textContent = statusText(u) + (X.changed.has(u.id) ? " • ⚠ kalit o'zgargan" : ""); if (isOnline(u.id)) sub.classList.add("on");
    const td = typingLabel("d" + u.id); if (td) { sub.textContent = td; sub.classList.add("on", "typing"); }
  }
  $("chMore").classList.toggle("hidden", S.active.kind === "group");
  const g = syncChatGate();
  inp.placeholder = S.active.kind === "channel" ? "Kanalga post yozing…" : "Xabar yozing…";
  if (g.chanRO || g.locked || g.dead) { cancelEdit(); cancelReply(); clearPendingImage(); }
}

function syncChatGate() {
  const c = $("chat"), a = S.active;
  const chanRO = !!a && a.kind === "channel" && !amAdmin();
  const dead = !!a && a.kind === "dm" && !!(U(a.uid) || {}).deleted;
  const locked = !!a && a.kind === "group" && !!S.chat.locked && !amAdmin();
  c.classList.toggle("readonly", chanRO); c.classList.toggle("dead", dead); c.classList.toggle("locked", locked);
  c.classList.toggle("offline", !!S.offline);
  return {chanRO, dead, locked, offline: !!S.offline};
}
$("hinfo").addEventListener("click", () => {
  if (!S.active) return;
  if (S.active.kind === "group") openGroupInfo(); else if (S.active.kind === "channel") Channels.info(S.active.id); else openProfile(S.active.uid);
});
$("backBtn").addEventListener("click", closeChat);

function bumpAway(reset) {
  if (reset) S.away = 0; else S.away++;
  const tb = $("tbBadge");
  tb.textContent = String(S.away); tb.classList.toggle("hidden", !S.away);
}
const WIN0 = 80;
function msgFlags(list, k) {
  const c = list[k], p = list[k - 1], n = list[k + 1], d = dayKey(c.ts);
  return [!p || p.service || p.user.id !== c.user.id || dayKey(p.ts) !== d || c.ts - p.ts > 300,
          !n || n.service || n.user.id !== c.user.id || dayKey(n.ts) !== d || n.ts - c.ts > 300];
}
function renderMessages(stick) {
  if (!S.active || !S.me) return;
  const box = $("msgs"), prevTop = box.scrollTop;
  const all = currentMsgs(), isGroup = S.active.kind === "group", chan = S.active.kind === "channel";
  const hiddenN = Math.max(0, all.length - (S.win || WIN0)), list = hiddenN ? all.slice(hiddenN) : all;
  box.textContent = "";
  let prev = null, lastDay = "";
  const pg = isGroup ? S.group : chan ? chOf(S.active.id) : dmOf(S.active.uid);
  if (pg.more || hiddenN) box.append(h("button", {class: "older", type: "button", text: "⬆ Oldingi xabarlar", onclick: loadOlder}));
  if (!list.length) box.append(h("div", {class: "blank", text: chan ? "Kanalda hali post yo'q" : isGroup ? "Hozircha xabar yo'q. Birinchi bo'lib yozing 👋" : "Suhbatni boshlang — xabar yozing 👋"}));
  list.forEach((m, i) => {
    if (m.service) { box.append(h("div", {class: "svc", text: m.text})); prev = null; return; }
    const day = dayKey(m.ts);
    if (day !== lastDay) { box.append(h("div", {class: "day", text: dayLabel(m.ts)})); lastDay = day; prev = null; }
    const next = list[i + 1];
    const first = !prev || prev.user.id !== m.user.id || m.ts - prev.ts > 300;
    const last = !next || next.service || next.user.id !== m.user.id || dayKey(next.ts) !== day || next.ts - m.ts > 300;
    box.append(bubbleRow(m, isGroup, chan || first, chan || last, chan));
    prev = m;
  });
  box._stick = !!stick; box._n = list.length; box._for = chatKey(S.active);
  if (chan) Channels.track(box, S.active.id);
  if (stick) { box.scrollTop = box.scrollHeight; bumpAway(true); } else box.scrollTop = prevTop;
  Pend.mount(!!stick);
  toggleToBottom(); renderPinBar(); markPins();
  if ((pg.more || hiddenN) && !S.olderBusy && box.scrollHeight <= box.clientHeight + 60) setTimeout(loadOlder, 0);
}
function appendMessage(m, stick) {
  const box = $("msgs"), list = currentMsgs(), i = list.length - 1;
  if (!S.active || !S.me || S.sel || list[i] !== m || box.querySelector(".blank")) return renderMessages(stick);
  if (stick && (box._n || 0) >= 220) { S.win = WIN0; return renderMessages(true); }
  const isG = S.active.kind === "group", chan = S.active.kind === "channel", prevM = list[i - 1];
  let prevRow = null;
  if (prevM && !prevM.service) {
    prevRow = box.querySelector('.row[data-id="' + Number(prevM.id) + '"]');
    if (!prevRow || prevRow !== box.lastElementChild) return renderMessages(stick);
  } else if (prevM && prevM.service && !(box.lastElementChild && box.lastElementChild.classList.contains("svc"))) return renderMessages(stick);
  else if (!prevM && box.lastElementChild && !box.lastElementChild.classList.contains("older")) return renderMessages(stick);
  if (m.service) box.append(h("div", {class: "svc", text: m.text}));
  else {
    let j = i - 1; while (j >= 0 && list[j].service) j--;
    if (j < 0 || dayKey(list[j].ts) !== dayKey(m.ts)) box.append(h("div", {class: "day", text: dayLabel(m.ts)}));
    if (prevRow && !chan) {
      const [pf, pl] = msgFlags(list, i - 1);
      if (pl !== prevRow.classList.contains("last")) prevRow.replaceWith(bubbleRow(prevM, isG, pf, pl));
    }
    const [f, l] = chan ? [true, true] : msgFlags(list, i), row = bubbleRow(m, isG, f, l, chan);
    row.classList.add("enter"); box.append(row);
    fxPlay(row);
    setTimeout(() => row.classList.remove("enter"), 450);
  }
  box._n = (box._n || 0) + 1; box._stick = !!stick;
  if (chan) Channels.track(box, S.active.id);
  Pend.mount(!!stick);
  if (stick) { box.scrollTop = box.scrollHeight; bumpAway(true); }
  toggleToBottom();
}
const quoteBody = t => Rich.hasInlineEmoji(t) ? Rich.preview(t) : document.createTextNode(t);
function replyQuote(r, by) {
  const gone = !!r.deleted, rk = by && !gone ? fxOf(by, "reply") : null;
  const q = h("div", {class: "rq" + (gone ? " gone" : "") + (rk ? " fxr-" + rk : ""), role: "button"},
    h("b", {text: gone ? "Xabar" : r.nickname}),
    h("span", {}, quoteBody(gone ? "O'chirilgan xabar" : (r.image ? "📷 " : r.file ? (r.voice ? "🎤 " : r.vnote ? "📹 " : "📎 ") : "") + (r.text || (r.image ? "Rasm" : r.file ? (r.file_name || "Fayl") : "")))));
  q.addEventListener("click", e => { e.stopPropagation(); if (!gone) jumpTo(r.id); });
  return q;
}
function jumpTo(id) {
  const box = $("msgs"), row = box.querySelector('.row[data-id="' + Number(id) + '"]');
  if (!row) { toast("Bu xabar yuklangan tarixda yo'q (eski)", "warn"); return; }
  box._stick = false;
  row.scrollIntoView({block: "center", behavior: "smooth"});
  row.classList.remove("flash"); void row.offsetWidth; row.classList.add("flash");
  setTimeout(() => row.classList.remove("flash"), 1400);
}

// ===== Advanced: saqlash papkasi va avtomatik yuklash (faqat shu qurilmada saqlanadi) =====
const AUTO_TRIED = new Set();
const DL = (() => {
  const LSK = "termchat_adl", DEF = {on: false, pm: true, grp: true, ch: true, mb: 10, since: 0, done: []};
  let cfg = Object.assign({}, DEF);
  try { const j = JSON.parse(localStorage.getItem(LSK) || "null"); if (j && typeof j === "object") cfg = Object.assign({}, DEF, j); } catch (_) {}
  if (!Array.isArray(cfg.done)) cfg.done = [];
  const persist = () => { try { localStorage.setItem(LSK, JSON.stringify(cfg)); } catch (_) {} };
  const idb = () => new Promise((res, rej) => { const r = indexedDB.open("termchat_fs", 1); r.onupgradeneeded = () => r.result.createObjectStore("kv"); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
  const idbDo = async (mode, fn) => { const db = await idb(); try { return await new Promise((res, rej) => { const rq = fn(db.transaction("kv", mode).objectStore("kv")); rq.onsuccess = () => res(rq.result); rq.onerror = () => rej(rq.error); }); } finally { db.close(); } };
  let dirH = null, loaded = false;
  const supported = () => typeof window.showDirectoryPicker === "function" && !!window.indexedDB;
  async function dir() { if (!loaded) { loaded = true; try { dirH = (await idbDo("readonly", st => st.get("dir"))) || null; } catch (_) { dirH = null; } } return dirH; }
  async function pick() {
    const d = await window.showDirectoryPicker({id: "termchat", mode: "readwrite"});
    await idbDo("readwrite", st => st.put(d, "dir")); dirH = d; loaded = true; return d;
  }
  async function clear() { try { await idbDo("readwrite", st => st.delete("dir")); } catch (_) {} dirH = null; loaded = true; }
  // ask=true: ruxsat so'raladi (faqat foydalanuvchi bosganda); ask=false: faqat jim tekshiradi
  async function perm(ask) {
    const d = await dir(); if (!d) return null;
    try {
      let r = await d.queryPermission({mode: "readwrite"});
      if (r === "prompt" && ask) r = await d.requestPermission({mode: "readwrite"});
      return r === "granted" ? d : null;
    } catch (_) { return null; }
  }
  async function freeName(d, name) {
    const i = name.lastIndexOf("."), base = i > 0 ? name.slice(0, i) : name, ext = i > 0 ? name.slice(i) : "";
    for (let k = 0; k < 500; k++) {
      const n = k ? base + " (" + k + ")" + ext : name;
      try { await d.getFileHandle(n); } catch (e) { if (e && e.name === "NotFoundError") return n; throw e; }
    }
    return Date.now() + "_" + name;
  }
  async function write(name, data, ask) {
    const d = await perm(ask); if (!d) return null;
    const n = await freeName(d, name), fh = await d.getFileHandle(n, {create: true}), w = await fh.createWritable();
    try { await w.write(data); await w.close(); } catch (err) { try { await w.abort(); } catch (_) {} throw err; }
    return n;
  }
  const kindOf = m => m.ch ? "ch" : m.to == null ? "grp" : "pm";
  function auto(m, size) {
    if (!cfg.on || !m || m.pending || m.locked || m.bad) return false;
    if (!cfg[kindOf(m)]) return false;
    if (!m.ch && m.user && S.me && m.user.id === S.me.id) return false;
    if (size && size > cfg.mb * 1048576) return false;
    return true;
  }
  return {
    cfg: () => cfg, supported, dir, pick, clear, perm, write, auto,
    set(p) { Object.assign(cfg, p); persist(); },
    isDone: id => cfg.done.includes(id),
    markDone(id) { cfg.done.push(id); if (cfg.done.length > 400) cfg.done.splice(0, cfg.done.length - 400); persist(); },
  };
})();
function autoFile(m, box, playable) {
  const f = m.file; if (!f || AUTO_TRIED.has(m.id) || !DL.auto(m, f.size)) return;
  if (playable) { AUTO_TRIED.add(m.id); setTimeout(() => { if (!S.played.has(m.id) && box.isConnected) playFile(m, box); }, 80); return; }
  if (!(m.ts * 1000 >= DL.cfg().since) || DL.isDone(m.id)) return;
  AUTO_TRIED.add(m.id);
  (async () => {
    try {
      if (!(await DL.perm(false))) return;
      const blob = await fetchFileBlob(m, "application/octet-stream");
      const n = await DL.write(safeName(f.name), blob, false);
      if (n) { DL.markDone(m.id); toast("Avtomatik yuklandi: " + n, "ok"); }
    } catch (_) {}
  })();
}

function imageBox(m, mine) {
  const ratio = Math.min(2.4, Math.max(0.8, m.w && m.h ? m.w / m.h : 4 / 3));

  if (mine && !S.imgs.has(m.id)) S.imgs.set(m.id, "open");
  const st = S.imgs.get(m.id);
  const box = h("div", {class: "imgbox" + (st === "open" ? " open" : st === "loading" ? " loading" : ""), role: "button", tabindex: "0",
    "aria-label": st === "open" ? "Rasmni kattalashtirish" : "Rasmni yuklash"});
  box.style.aspectRatio = String(ratio);
  if (st !== "open") {
    const th = h("img", {class: "mthumb", alt: "", draggable: "false"});
    th.addEventListener("error", () => { th.remove(); box.classList.add("nothumb"); });
    if (m.thumb) th.src = m.thumb; else box.classList.add("nothumb");
    const dl = h("span", {class: "mdl", "aria-hidden": "true"}, icon("dl"), spinnerEl());
    box.append(th, dl);
  } else {
    box.append(fullImg(m));
  }
  const act = e => {
    e.stopPropagation();
    const cur = S.imgs.get(m.id);
    if (cur === "open") { imgSrcOf(m).then(openLightbox).catch(e => toast(e && e.expired ? EXPIRED_MSG : "Rasmni ochib bo'lmadi", "error")); return; }
    if (cur === "loading") return;
    startImageLoad(m, box);
  };
  box.addEventListener("click", act);
  box.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); act(e); } });
  if (st === undefined && !AUTO_TRIED.has(m.id) && DL.auto(m, 0)) {
    AUTO_TRIED.add(m.id);
    setTimeout(() => { const b = document.querySelector('#msgs .row[data-id="' + m.id + '"] .imgbox'); if (b && !S.imgs.has(m.id)) startImageLoad(m, b, true); }, 60);
  }
  return box;
}

const fmtSize = n => n < 1024 ? n + " B" : n < 1048576 ? Math.round(n / 1024) + " KB" : (n / 1048576).toFixed(1) + " MB";
const fileExt = name => { const i = (name || "").lastIndexOf("."); return i > 0 && i < name.length - 1 ? name.slice(i + 1, i + 5).toUpperCase() : "FAYL"; };
const PLAYABLE = /^(video\/(mp4|webm|ogg|quicktime)|audio\/(mpeg|mp3|ogg|wav|x-wav|webm|mp4|aac|flac|x-m4a))$/;
async function fetchFileBlob(m, type) {
  if (m.file.e2e) return new Blob([await e2eFetchBlob(m)], {type});
  const r = await SC.fetch(m.file.url, {headers: {Authorization: "Bearer " + S.token}});
  if (!r.ok) throw new Error("fayl");
  return new Blob([r.bytes], {type});
}
async function downloadFile(m, box) {
  if (box.classList.contains("loading")) return;
  box.classList.add("loading");
  try {
    const blob = await fetchFileBlob(m, "application/octet-stream");
    try { const n = await DL.write(safeName(m.file.name), blob, true); if (n) { toast("Saqlandi: " + n, "ok"); box.classList.remove("loading"); return; } } catch (_) {}
    const url = URL.createObjectURL(blob), a = h("a", {href: url, download: m.file.name});
    document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  } catch (e) { toast(e && e.expired ? EXPIRED_MSG : "Faylni yuklab bo'lmadi", "error"); }
  box.classList.remove("loading");
}
async function playFile(m, box) {
  if (box.classList.contains("loading")) return;
  box.classList.add("loading");
  try {
    const blob = await fetchFileBlob(m, m.file.mime);
    S.played.set(m.id, URL.createObjectURL(blob));
    renderMessages(false);
  } catch (e) { toast(e && e.expired ? EXPIRED_MSG : "Faylni yuklab bo'lmadi", "error"); box.classList.remove("loading"); }
}
const fxNow = (key, ts) => {
  const seen = S.fx.get(key);
  if (seen) return Date.now() - seen < 4000;
  S.fx.set(key, Date.now());
  return !ts || Date.now() / 1000 - ts < 90;
};
async function copyQuiet(t) {
  try { await navigator.clipboard.writeText(t); return true; }
  catch (_) {
    const ta = h("textarea", {class: "offscreen"}); ta.value = t; document.body.append(ta); ta.select();
    let ok = false; try { ok = document.execCommand("copy"); } catch (_e) {}
    ta.remove(); return ok;
  }
}
async function togglePreview(m, box) {
  if (S.previews.has(m.id)) { S.previews.delete(m.id); renderMessages(false); return; }
  if (box.classList.contains("loading")) return;
  const fk = Rich.fileKind(m.file.name); if (!fk) return;
  const limit = fk.kind === "pcap" ? MAX_MEDIA : 400 * 1024;
  if (m.file.size > limit) { toast("Fayl juda katta: ko'rish uchun yuklab oling (" + fmtSize(limit) + " gacha ko'rsatiladi)", "error"); return; }
  box.classList.add("loading");
  try {
    const blob = await fetchFileBlob(m, "application/octet-stream");
    const bytes = new Uint8Array(await blob.arrayBuffer());
    if (fk.kind === "pcap") S.previews.set(m.id, {kind: "pcap", info: Rich.parsePcap(bytes)});
    else {
      if (!Rich.isTextual(bytes)) { toast("Bu fayl matn emas: faqat yuklab olish mumkin", "error"); box.classList.remove("loading"); return; }
      let text = new TextDecoder("utf-8").decode(bytes).replace(/\r\n?/g, "\n"), cut = false;
      if (text.length > 120000) { text = text.slice(0, 120000); cut = true; }
      S.previews.set(m.id, {kind: "code", lang: fk.lang, label: fk.label, text, cut});
    }
    renderMessages(false);
  } catch (err) { toast(err && /pcap|qisqa/i.test(err.message || "") ? err.message : "Faylni ochib bo'lmadi", "error"); }
  box.classList.remove("loading");
}
function previewEl(m, pv) {
  const u = U(m.user.id);
  if (pv.kind === "pcap") {
    const info = pv.info;
    return Rich.terminal(Rich.pcapLines(info, m.file.name), {user: u.username, host: "kali", kali: true, tag: "PCAP", fx: fxNow("pv" + m.id), copy: copyQuiet,
      copyText: Rich.pcapText(info, m.file.name), info: info.count + " paket • " + info.linkName + " • faqat o'qiladi"});
  }
  const box = Rich.codeBlock(pv.text, pv.lang, {label: pv.label + " • " + m.file.name, copy: copyQuiet});
  if (pv.cut) box.append(h("div", {class: "cfoot-i cut", text: "Fayl katta: faqat boshi ko'rsatildi. To'liq nusxa uchun yuklab oling."}));
  return box;
}
function fileBox(m) {
  if (m.file.voice) return voiceBox(m);
  if (m.file.vnote) return vnoteBox(m);
  const f = m.file, playable = PLAYABLE.test(f.mime), fk = playable ? null : Rich.fileKind(f.name);
  if (playable && S.played.has(m.id)) {
    const el = h(f.mime.startsWith("video/") ? "video" : "audio", {controls: true, preload: "metadata", playsinline: true});
    el.src = S.played.get(m.id);
    return h("div", {class: "mplayer"}, el, h("div", {class: "mpn", text: f.name + " • " + fmtSize(f.size)}));
  }
  const box = h("div", {class: "filebox" + (fk ? " kind-" + fk.kind : ""), role: "button", tabindex: "0", "aria-label": "Faylni yuklab olish: " + f.name});
  if (fk) box.style.setProperty("--lc", fk.color);
  const act = h("span", {class: "fdl", "aria-hidden": "true"}, icon("dl"), spinnerEl());
  box.append(h("span", {class: "fico"}, h("b", {text: fk ? fk.ext.toUpperCase().slice(0, 6) : fileExt(f.name)})),
    h("span", {class: "fmeta"}, h("b", {class: "fname", text: f.name}),
      h("small", {text: fk ? (fk.kind === "pcap" ? "Linux • tcpdump/Wireshark • " : fk.label + " • faqat ko'rish • ") + fmtSize(f.size) : fmtSize(f.size)})));
  if (playable) {
    const pl = h("button", {class: "fplay", type: "button", title: "Ijro etish", "aria-label": "Ijro etish"}, icon("play"));
    pl.addEventListener("click", e => { e.stopPropagation(); playFile(m, box); });
    box.append(pl);
  }
  if (fk) {
    const open = S.previews.has(m.id), t = open ? "Yopish" : fk.kind === "pcap" ? "Tahlil qilish" : "Kodni ko'rish";
    const vw = h("button", {class: "fplay fview" + (open ? " on" : ""), type: "button", title: t, "aria-label": t}, icon(open ? "close" : "eye"));
    vw.addEventListener("click", e => { e.stopPropagation(); togglePreview(m, box); });
    for (const ev of ["pointerdown", "touchstart"]) vw.addEventListener(ev, e => e.stopPropagation(), {passive: true});
    box.append(vw);
  }
  box.append(act);
  autoFile(m, box, playable);
  const go = e => { e.stopPropagation(); downloadFile(m, box); };
  box.addEventListener("click", go);
  box.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); go(e); } });
  if (!fk) return box;
  const wrap = h("div", {class: "cfile kind-" + fk.kind}, box);
  const pv = S.previews.get(m.id);
  if (pv) wrap.append(previewEl(m, pv));
  return wrap;
}
function spinnerEl() {
  const NSV = "http://www.w3.org/2000/svg";
  const s = document.createElementNS(NSV, "svg"); s.setAttribute("class", "mspin"); s.setAttribute("viewBox", "0 0 50 50");
  const c = document.createElementNS(NSV, "circle");
  [["cx", 25], ["cy", 25], ["r", 22], ["fill", "none"], ["stroke-width", 3], ["stroke-linecap", "round"]].forEach(([k, v]) => c.setAttribute(k, v));
  s.append(c); return s;
}

const VP = {id: null, m: null, audio: null, url: null, rate: 1, loading: false, pending: null, done: false};
const fmtDur = s => { s = Math.max(0, Math.round(s || 0)); return Math.floor(s / 60) + ":" + pad2(s % 60); };

// --- Haqiqiy ovoz to'lqini (Telegramdagidek): WAV namunalaridan 48 ta ustun hisoblanadi ---
const WF_N = 48, WF_CH = "0123456789abcdefghijklmnopqrstuv";
function wfFromWav(u8) {
  try {
    if (!u8 || u8.length < 64) return "";
    let off = 44;
    for (let i = 12; i < Math.min(u8.length - 8, 400);) {
      const id = String.fromCharCode(u8[i], u8[i + 1], u8[i + 2], u8[i + 3]), sz = u8[i + 4] | (u8[i + 5] << 8) | (u8[i + 6] << 16) | (u8[i + 7] << 24);
      if (id === "data") { off = i + 8; break; }
      if (sz < 0) break;
      i += 8 + sz + (sz & 1);
    }
    const n = (u8.length - off) >> 1; if (n < WF_N) return "";
    const dv = new DataView(u8.buffer, u8.byteOffset + off, n * 2), v = new Array(WF_N).fill(0);
    for (let b = 0; b < WF_N; b++) {
      const a = Math.floor(b * n / WF_N), z = Math.max(a + 1, Math.floor((b + 1) * n / WF_N));
      let sum = 0, pk = 0;
      for (let k = a; k < z; k++) { const x = Math.abs(dv.getInt16(k * 2, true)) / 32768; sum += x * x; if (x > pk) pk = x; }
      v[b] = Math.sqrt(sum / (z - a)) * 0.7 + pk * 0.3;
    }
    const mx = Math.max(...v); if (!(mx > 0.002)) return "";
    return v.map(x => WF_CH[Math.max(0, Math.min(31, Math.round(Math.pow(x / mx, 0.7) * 31)))]).join("");
  } catch (_) { return ""; }
}
const wfParse = str => typeof str === "string" && /^[0-9a-v]{16,96}$/.test(str) ? Array.from(str, c => parseInt(c, 32) / 31) : null;
const WFC = new Map(), WFX = new Set();
let wfChain = Promise.resolve();
const wfOf = m => WFC.get(m.id) || (m.file && m.file.wf) || "";
function wfSet(id, str) {
  if (!str) return; WFC.set(id, str);
  document.querySelectorAll('.vbox[data-vid="' + id + '"]').forEach(b => setBars(b, wfParse(str)));
}
function wfCompute(m) {
  if (WFX.has(m.id) || wfOf(m)) return; WFX.add(m.id);
  wfChain = wfChain.then(async () => {
    try { const blob = await fetchFileBlob(m, "audio/wav"); wfSet(m.id, wfFromWav(new Uint8Array(await blob.arrayBuffer()))); } catch (_) {}
  });
}
const wfIO = "IntersectionObserver" in window ? new IntersectionObserver(es => es.forEach(e => {
  wfIO.unobserve(e.target); if (e.isIntersecting && e.target.isConnected && e.target._m) wfCompute(e.target._m);
}), {rootMargin: "240px"}) : null;
function setBars(box, vals) {
  const wave = box._wave; if (!wave) return;
  const arr = vals || new Array(WF_N).fill(0.1);
  wave.textContent = ""; box.classList.toggle("wf-flat", !vals);
  arr.forEach(v => { const b = document.createElement("i"); b.style.height = (14 + 86 * v).toFixed(0) + "%"; wave.append(b); });
  box._lit = 0; paintVoice(box);
}

// --- Eshitilgan ovozlar (nuqtacha shu orqali yo'qoladi) ---
const Heard = (() => {
  const K = "termchat_voice_heard"; let a = [];
  try { a = JSON.parse(localStorage.getItem(K) || "[]"); if (!Array.isArray(a)) a = []; } catch (_) { a = []; }
  const set = new Set(a);
  return {has: id => set.has(id), add(id) {
    if (set.has(id)) return; set.add(id); a.push(id); if (a.length > 600) set.delete(a.shift());
    try { localStorage.setItem(K, JSON.stringify(a)); } catch (_) {}
  }};
})();

function voiceStop() {
  if (VP.audio) { try { VP.audio.pause(); VP.audio.removeAttribute("src"); VP.audio.load(); } catch (_) {} }
  if (VP.url) URL.revokeObjectURL(VP.url);
  VP.id = VP.m = VP.audio = VP.url = null; VP.loading = false; VP.pending = null; VP.done = false;
  paintVoices();
  vnStop();
}
function paintVoice(box) {
  const vid = box.dataset.vid; if (!vid) return;
  const id = +vid, cur = VP.id === id, a = cur ? VP.audio : null;
  const dur = a && isFinite(a.duration) && a.duration > 0 ? a.duration : +box.dataset.dur;
  box.classList.toggle("active", !!a);
  box.classList.toggle("playing", !!a && !a.paused);
  box.classList.toggle("loading", cur && VP.loading);
  box.classList.toggle("unheard", box.dataset.own !== "1" && !Heard.has(id));
  const dragging = typeof box._drag === "number";
  const frac = dragging ? box._drag : a && dur ? Math.min(1, a.currentTime / dur) : 0;
  const bars = box._wave && box._wave.children, lit = bars ? Math.round(frac * bars.length) : 0, was = box._lit || 0;
  if (bars && lit !== was) { for (let i = Math.min(lit, was); i < Math.max(lit, was); i++) if (bars[i]) bars[i].classList.toggle("on", i < lit); box._lit = lit; }
  const sz = +box.dataset.size;
  box.querySelector(".vtime").textContent = dragging ? fmtDur(box._drag * dur) + " / " + fmtDur(dur) : a && (a.currentTime > 0 || !a.paused) ? fmtDur(a.currentTime) + " / " + fmtDur(dur) : fmtDur(dur) + (sz ? ", " + fmtSize(sz) : "");
  box.querySelector(".vspd").textContent = VP.rate + "x";
}
function paintVoiceBar() {
  const bar = $("voiceBar"); if (!bar) return;
  const m = VP.m, on = !!(VP.id && m && !VP.done && S.me);
  bar.classList.toggle("hidden", !on); if (!on) return;
  const a = VP.audio, dur = a && isFinite(a.duration) && a.duration > 0 ? a.duration : (m.file && m.file.dur) || 0;
  $("vbTitle").textContent = m.user.id === S.me.id ? "Siz" : (U(m.user.id).nickname || "");
  $("vbSub").textContent = "Ovozli xabar" + (a ? " • " + fmtDur(a.currentTime) + " / " + fmtDur(dur) : "");
  bar.classList.toggle("playing", !!a && !a.paused); bar.classList.toggle("loading", VP.loading);
  $("vbSpd").textContent = VP.rate + "x";
}
function paintVoices() { document.querySelectorAll(".vbox").forEach(paintVoice); paintVoiceBar(); }
function voiceSeek(m, frac) {
  frac = Math.max(0, Math.min(1, frac));
  const a = VP.id === m.id ? VP.audio : null;
  if (a && isFinite(a.duration) && a.duration > 0) { a.currentTime = frac * a.duration; if (a.paused) a.play().catch(() => {}); paintVoices(); return; }
  const p = VP.id === m.id && VP.audio ? null : voiceToggle(m);
  VP.pending = {id: m.id, frac};
  if (p) p.catch(() => {});
}
async function voiceToggle(m) {
  if (VP.id === m.id && VP.audio) { if (VP.audio.paused) VP.audio.play().catch(() => {}); else VP.audio.pause(); paintVoices(); return; }
  if (VP.loading) return;
  voiceStop();
  VP.id = m.id; VP.m = m; VP.loading = true; paintVoices();
  try {
    const blob = await fetchFileBlob(m, "audio/wav");
    if (VP.id !== m.id) return;
    if (!wfOf(m)) blob.arrayBuffer().then(ab => wfSet(m.id, wfFromWav(new Uint8Array(ab)))).catch(() => {});
    const url = URL.createObjectURL(blob), a = new Audio();
    a.preload = "auto"; a.src = url; a.playbackRate = VP.rate;
    a.addEventListener("play", () => { VP.done = false; Heard.add(m.id); });
    ["timeupdate", "play", "pause", "loadedmetadata", "durationchange"].forEach(ev => a.addEventListener(ev, paintVoices));
    a.addEventListener("loadedmetadata", () => {
      const pd = VP.pending; if (!pd || pd.id !== m.id || VP.audio !== a) return;
      const d = isFinite(a.duration) && a.duration > 0 ? a.duration : (m.file.dur || 0);
      if (d) { try { a.currentTime = pd.frac * d; } catch (_) {} }
      VP.pending = null;
    });
    a.addEventListener("ended", () => { a.currentTime = 0; VP.done = true; paintVoices(); });
    a.addEventListener("error", () => { if (VP.audio === a) { toast("Ovozni ijro etib bo'lmadi", "error"); voiceStop(); } });
    VP.audio = a; VP.url = url; VP.loading = false; paintVoices();
    await a.play().catch(() => {});
  } catch (_) { if (VP.id === m.id) { toast("Ovozni yuklab bo'lmadi", "error"); voiceStop(); } }
}
function voiceBox(m) {
  const f = m.file, dur = f.dur || Math.max(1, (f.size - 44) / 32000);
  const box = h("div", {class: "vbox"});
  box.dataset.vid = m.id; box.dataset.dur = dur; box.dataset.size = f.size || 0;
  if (m.user && S.me && m.user.id === S.me.id && !m.ch) box.dataset.own = "1";
  const play = h("button", {class: "vplay", type: "button", "aria-label": "Ovozli xabarni ijro etish"}, icon("play", "ic vi-play"), icon("pause", "ic vi-pause"), spinnerEl());
  play.addEventListener("click", e => { e.stopPropagation(); voiceToggle(m); });
  const wave = h("div", {class: "vwave"}), track = h("div", {class: "vtrack", role: "slider", tabindex: "0", "aria-label": "Ovozli xabar vaqti", "aria-valuemin": "0", "aria-valuemax": "100"}, wave);
  box._wave = wave; box._m = m;
  const fracOf = e => { const r = track.getBoundingClientRect(); return r.width ? Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)) : 0; };
  let drag = null;
  track.addEventListener("pointerdown", e => {
    if (e.button) return; e.stopPropagation();
    try { track.setPointerCapture(e.pointerId); } catch (_) {}
    drag = e.pointerId; box._drag = fracOf(e); box.classList.add("seeking"); paintVoice(box);
  });
  track.addEventListener("pointermove", e => { if (drag !== e.pointerId) return; box._drag = fracOf(e); paintVoice(box); });
  const endDrag = (e, ok) => {
    if (drag !== e.pointerId) return;
    const f = box._drag; drag = null; box._drag = null; box.classList.remove("seeking");
    if (ok && typeof f === "number") voiceSeek(m, f);
    paintVoices();
  };
  track.addEventListener("pointerup", e => endDrag(e, true));
  track.addEventListener("pointercancel", e => endDrag(e, false));
  track.addEventListener("click", e => e.stopPropagation());
  track.addEventListener("keydown", e => {
    if (e.key !== "ArrowLeft" && e.key !== "ArrowRight") return;
    const a = VP.id === m.id ? VP.audio : null; if (!a || !isFinite(a.duration) || a.duration <= 0) return;
    e.preventDefault(); e.stopPropagation(); a.currentTime = Math.max(0, Math.min(a.duration, a.currentTime + (e.key === "ArrowRight" ? 5 : -5))); paintVoices();
  });
  const spd = h("button", {class: "vspd", type: "button", title: "Tezlik", "aria-label": "Ijro tezligi"});
  spd.addEventListener("click", e => { e.stopPropagation(); VP.rate = VP.rate === 1 ? 1.5 : VP.rate === 1.5 ? 2 : 1; if (VP.audio) VP.audio.playbackRate = VP.rate; paintVoices(); });
  box.append(play, h("div", {class: "vmid"}, track, h("div", {class: "vmeta"}, h("span", {class: "vinfo"}, h("span", {class: "vtime"}), h("span", {class: "vdot", "aria-label": "Eshitilmagan", title: "Eshitilmagan"})), spd)));
  setBars(box, wfParse(wfOf(m)));
  if (!wfOf(m) && !WFX.has(m.id)) { if (wfIO) wfIO.observe(box); else wfCompute(m); }
  return box;
}

// --- Tepadagi ovoz paneli (pin paneli kabi): ijro paytida ko'rinib turadi ---
$("vbPlay").addEventListener("click", () => {
  const a = VP.audio; if (!a) return;
  if (a.paused) a.play().catch(() => {}); else a.pause();
  paintVoices();
});
$("vbSpd").addEventListener("click", e => { e.stopPropagation(); VP.rate = VP.rate === 1 ? 1.5 : VP.rate === 1.5 ? 2 : 1; if (VP.audio) VP.audio.playbackRate = VP.rate; paintVoices(); });
$("vbX").addEventListener("click", e => { e.stopPropagation(); voiceStop(); });
$("vbMain").addEventListener("click", async () => {
  const m = VP.m; if (!m) return;
  const here = () => $("msgs").querySelector('.row[data-id="' + Number(m.id) + '"]');
  if (here()) { jumpTo(m.id); return; }
  const t = m.ch ? {kind: "channel", id: m.ch} : m.to == null ? {kind: "group"} : {kind: "dm", uid: partnerOf(m)};
  try { await openChat(t); } catch (_) {}
  if (here()) jumpTo(m.id); else toast("Xabar topilmadi (eski yoki o'chirilgan)", "warn");
});

const VN = {id: null, video: null, audio: null, vurl: null, aurl: null, loading: false, ended: false, raf: 0, seq: 0};
let vnHost = null;
function vnHostEl() { if (!vnHost) { vnHost = h("div", {class: "vn-host", "aria-hidden": "true"}); document.body.append(vnHost); } return vnHost; }
const vnMaster = () => VN.audio || VN.video;
function vnStop() {
  VN.seq++; if (VN.raf) cancelAnimationFrame(VN.raf);
  const {video: v, audio: a, vurl, aurl} = VN;
  if (a) { try { a.pause(); a.removeAttribute("src"); a.load(); } catch (_) {} }
  if (v) { try { v.pause(); v.removeAttribute("src"); v.load(); } catch (_) {} v.remove(); }
  [vurl, aurl].forEach(u => { if (u) URL.revokeObjectURL(u); });
  Object.assign(VN, {id: null, video: null, audio: null, vurl: null, aurl: null, loading: false, ended: false, raf: 0});
  paintVNs();
}
function drawCover(cv, v) {
  const w = v.videoWidth, hh = v.videoHeight; if (!w || !hh) return;
  const s = Math.min(w, hh), n = cv.width;
  cv.getContext("2d").drawImage(v, (w - s) / 2, (hh - s) / 2, s, s, 0, 0, n, n);
}
function paintVN(box) {
  const id = +box.dataset.vnid, cur = VN.id === id, v = cur ? VN.video : null, a = cur ? vnMaster() : null;
  const ready = !!(cur && v && !VN.loading), playing = ready && !!a && !a.paused && !VN.ended;
  const total = +box.dataset.dur || (a && isFinite(a.duration) ? a.duration : 0), t = ready && !VN.ended && a ? a.currentTime : 0;
  box.classList.toggle("ready", ready); box.classList.toggle("playing", playing); box.classList.toggle("loading", cur && VN.loading);
  box.querySelector(".vnr-fg").setAttribute("stroke-dashoffset", String(301.6 * (1 - (total ? Math.min(1, t / total) : 0))));
  box.querySelector(".vndur").textContent = ready && (playing || t > 0) ? fmtDur(t) + " / " + fmtDur(total) : fmtDur(total);
  if (ready && v.readyState >= 2) drawCover(box.querySelector("canvas"), v);
}
function paintVNs() { document.querySelectorAll(".vnbox").forEach(paintVN); }
function vnTick() {
  VN.raf = 0;
  const v = VN.video, a = VN.audio; if (!v) return;
  if (a && !a.paused && !v.seeking) {
    if (v.paused && !v.ended) v.play().catch(() => {});
    if (Math.abs(v.currentTime - a.currentTime) > 0.25) { try { v.currentTime = a.currentTime; } catch (_) {} }
  }
  paintVNs();
  const m = vnMaster();
  if (m && !m.paused && !VN.ended) VN.raf = requestAnimationFrame(vnTick);
}
const vnKick = () => { if (!VN.raf) VN.raf = requestAnimationFrame(vnTick); };
async function vnPlayBoth() {
  const v = VN.video, a = VN.audio; if (!v) return;
  try { await Promise.all([v.play(), a ? a.play() : null]); vnKick(); }
  catch (_) { try { v.pause(); if (a) a.pause(); } catch (__) {} toast("Ijro etib bo'lmadi. Yana bir bor bosing", "error"); }
  paintVNs();
}
async function vnToggle(m) {
  if (VN.id === m.id) {
    if (VN.loading || !VN.video) return;
    const v = VN.video, a = VN.audio;
    if (VN.ended) { VN.ended = false; try { v.currentTime = 0; if (a) a.currentTime = 0; } catch (_) {} await vnPlayBoth(); }
    else if (vnMaster().paused) await vnPlayBoth();
    else { v.pause(); if (a) a.pause(); }
    paintVNs(); return;
  }
  voiceStop();
  const token = VN.seq; VN.id = m.id; VN.loading = true; paintVNs();
  const alive = () => VN.seq === token && VN.id === m.id;
  let v = null, a = null, vurl = null, aurl = null, adopted = false;
  try {
    const parts = VNote.unpack(await e2eFetchBlob(m));
    if (!alive()) return;
    v = document.createElement("video");
    if (!v.canPlayType(m.file.mime)) throw new Error("format");
    v.muted = true; v.playsInline = true; v.preload = "auto"; v.disablePictureInPicture = true; v.disableRemotePlayback = true;
    v.setAttribute("controlsList", "nodownload noremoteplayback"); v.oncontextmenu = e => { e.preventDefault(); return false; };
    v.setAttribute("playsinline", ""); v.setAttribute("webkit-playsinline", "");
    vurl = URL.createObjectURL(new Blob([parts.video], {type: m.file.mime}));
    if (parts.audio) { aurl = URL.createObjectURL(new Blob([parts.audio], {type: "audio/wav"})); a = new Audio(); a.preload = "auto"; a.src = aurl; }
    vnHostEl().append(v); v.src = vurl;
    await new Promise((res, rej) => {
      if (v.readyState >= 2) return res();
      const t = setTimeout(() => rej(new Error("vaqt")), 15000);
      v.addEventListener("loadeddata", () => { clearTimeout(t); res(); }, {once: true});
      v.addEventListener("error", () => { clearTimeout(t); rej(new Error("video")); }, {once: true});
    });
    if (!alive()) return;
    adopted = true;
    Object.assign(VN, {video: v, audio: a, vurl, aurl, loading: false, ended: false});
    const mst = a || v;
    ["play", "pause", "seeked", "loadedmetadata"].forEach(ev => mst.addEventListener(ev, () => { paintVNs(); if (!mst.paused) vnKick(); }));
    v.addEventListener("seeked", paintVNs);
    mst.addEventListener("ended", () => {
      if (VN.video !== v) return;
      VN.ended = true; v.pause(); if (a) a.pause();
      try { v.currentTime = 0; } catch (_) {}
      paintVNs();
    });
    if (a) a.addEventListener("error", () => { if (VN.audio === a) { toast("Ovozni ijro etib bo'lmadi", "error"); vnStop(); } });
    v.addEventListener("error", () => { if (VN.video === v) { toast("Videoni ijro etib bo'lmadi", "error"); vnStop(); } });
    paintVNs();
    await vnPlayBoth();
  } catch (_) {
    if (!adopted) { if (v) v.remove(); [vurl, aurl].forEach(u => { if (u) URL.revokeObjectURL(u); }); }
    if (alive()) { toast("Video xabarni ochib bo'lmadi", "error"); vnStop(); }
  }
}
function vnoteBox(m) {
  const f = m.file, NSV = "http://www.w3.org/2000/svg";
  const box = h("div", {class: "vnbox", role: "button", tabindex: "0", "aria-label": "Video xabarni ijro etish"});
  box.dataset.vnid = m.id; box.dataset.dur = f.dur || 0;
  const c = h("div", {class: "vnc"});
  if (f.th) c.append(h("img", {class: "vnth", alt: "", draggable: "false", src: f.th}));
  c.append(h("canvas", {width: 360, height: 360}), h("span", {class: "vnplay", "aria-hidden": "true"}, icon("play", "ic"), spinnerEl()), h("span", {class: "vndur"}));
  const ring = document.createElementNS(NSV, "svg"); ring.setAttribute("class", "vnring"); ring.setAttribute("viewBox", "0 0 100 100"); ring.setAttribute("aria-hidden", "true");
  [["vnr-bg", false], ["vnr-fg", true]].forEach(([cls, fg]) => {
    const ci = document.createElementNS(NSV, "circle"); ci.setAttribute("class", cls); ci.setAttribute("cx", 50); ci.setAttribute("cy", 50); ci.setAttribute("r", 48);
    if (fg) ci.setAttribute("stroke-dashoffset", "301.6"); ring.append(ci);
  });
  box.append(c, ring);
  ["contextmenu", "dragstart", "selectstart"].forEach(ev => box.addEventListener(ev, e => e.preventDefault()));
  const go = e => { e.stopPropagation(); vnToggle(m); };
  box.addEventListener("click", go);
  box.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); go(e); } });
  paintVN(box);
  return box;
}
function fullImg(m) {
  const img = h("img", {class: "mimg", alt: "Rasm", draggable: "false"});
  img.addEventListener("load", () => { const b = $("msgs"); if (b._stick) b.scrollTop = b.scrollHeight; });
  imgSrcOf(m).then(u => { img.src = u; }).catch(() => {});
  return img;
}
function startImageLoad(m, box, quiet) {
  S.imgs.set(m.id, "loading"); box.classList.add("loading");
  const t0 = performance.now(), pre = new Image();
  const done = (ok, err) => {
    const wait = Math.max(0, 550 - (performance.now() - t0));
    setTimeout(() => {
      if (!ok) {
        S.imgs.delete(m.id); if (!quiet) toast(err && err.expired ? EXPIRED_MSG : "Rasmni yuklab bo'lmadi", "error");
        const b = document.querySelector('#msgs .row[data-id="' + m.id + '"] .imgbox'); if (b) b.classList.remove("loading");
        return;
      }
      S.imgs.set(m.id, "open");
      const cur = document.querySelector('#msgs .row[data-id="' + m.id + '"] .imgbox');
      if (!cur) return;
      const img = fullImg(m); img.classList.add("reveal");
      cur.classList.remove("loading"); cur.classList.add("open"); cur.setAttribute("aria-label", "Rasmni kattalashtirish");
      cur.append(img);
      void cur.offsetWidth;
      requestAnimationFrame(() => cur.classList.add("clear"));
      setTimeout(() => cur.querySelectorAll(".mthumb,.mdl").forEach(x => x.remove()), 450);
    }, wait);
  };
  pre.onload = () => done(true); pre.onerror = () => done(false);
  imgSrcOf(m).then(u => { pre.src = u; }).catch(e => done(false, e));
}

const RX_QUICK = ["❤️", "👍", "👎", "🔥", "😂", "😮", "😢"];

function rxGroups() {
  const cut = (a, b) => STD_EMOJIS.slice(STD_EMOJIS.indexOf(a), STD_EMOJIS.indexOf(b) + 1);
  const g = [
    {k: "f", title: "Yuzlar va hissiyotlar", label: "😀", items: cut("😀", "🙊")},
    {k: "h", title: "Qo'l va tana", label: "👍", items: cut("👍", "🧠")},
    {k: "l", title: "Yuraklar", label: "❤️", items: cut("❤️", "💯")},
    {k: "o", title: "Belgilar va narsalar", label: "🎉", items: cut("✨", "🍺")}];
  if (EM.data && emojiPerms().use) {
    emojiTabs().filter(t => t.k !== "std").forEach(t => {
      const items = (t.items || []).filter(x => Rich.hasInlineEmoji(x.token)).map(x => x.token);
      if (items.length) g.push({k: t.k, title: t.label, label: "📦", icon: items[0], items});
    });
  }
  return g;
}

function rxPackView(mk, st, gridCls) {
  const gs = rxGroups(), wrap = h("div", {class: "rx-pv"});
  if (!gs.some(g => g.k === st.k)) st.k = gs[0].k;
  const paint = () => {
    const keep = wrap.querySelector(".rx-tabs"), left = keep ? keep.scrollLeft : 0;
    wrap.textContent = "";
    const bar = h("div", {class: "rx-tabs", role: "tablist"});
    gs.forEach(g => {
      const b = h("button", {type: "button", class: "rx-tab" + (g.k === st.k ? " on" : ""), title: g.title, "aria-label": g.title, role: "tab"}, g.icon ? rxGlyph(g.icon) : h("span", {class: "rx-e", text: g.label}));
      b.addEventListener("click", ev => { ev.stopPropagation(); st.k = g.k; paint(); });
      bar.append(b);
    });
    hScroll(bar);
    const cur = gs.find(g => g.k === st.k), grid = h("div", {class: gridCls});
    cur.items.forEach(e => grid.append(mk(e)));
    wrap.append(bar, h("small", {class: "rx-cap", text: cur.title + " • " + cur.items.length + " ta"}), grid);
    bar.scrollLeft = left; keepTabVisible(bar);
  };
  paint();
  return wrap;
}

function rxGlyph(e, cls) {
  if (Rich.isEmojiToken(e) && Rich.hasInlineEmoji(e)) { const i = Rich.chatEmoji(e, false); i.classList.add("rxi"); return i; }
  return h("span", {class: cls || "rx-e", text: Rich.isEmojiToken(e) ? "◈" : e});
}
const RX_KEY = "tc_rx";
const rxPrefs = (() => {
  let p = {}; try { p = JSON.parse(localStorage.getItem(RX_KEY) || "{}") || {}; } catch (_) {}
  const ok = typeof p.emoji === "string" && p.emoji.length <= 20 && !/[A-Za-z0-9]/.test(p.emoji.replace(/^:[a-z0-9_]{2,32}:$/, ""));
  return {dbl: p.dbl !== false, emoji: ok ? p.emoji : "❤️"};
})();
const rxSave = () => { try { localStorage.setItem(RX_KEY, JSON.stringify(rxPrefs)); } catch (_) {} };
const canReact = m => !!m && !m.service && m.id != null && !$("chat").classList.contains("dead");
function rxMine(m) {
  for (const [e, ids] of Object.entries(m.rx || {})) if (ids.includes(S.me.id)) return e;
  return null;
}
function reactTo(m, emoji) { if (canReact(m)) wsSend({type: "react", id: m.id, emoji}); }
function rxChip(e) {
  const chip = h("button", {class: "rx", type: "button"}, rxGlyph(e), h("b", {class: "cnt"}));
  chip.dataset.e = e;
  chip.addEventListener("click", ev => {
    ev.stopPropagation();
    const m = chip._m; if (!m) return;
    if (rxMine(m) !== e) { const r = chip.getBoundingClientRect(); rxBurst(e, r.left + r.width / 2, r.top + r.height / 2, {mini: true}); haptic(8); }
    reactTo(m, e);
  });
  return chip;
}
function rxCount(chip, n, anim) {
  const b = chip.querySelector(".cnt"), old = b.firstElementChild;
  if (!old) { b.append(h("span", {text: String(n)})); b.dataset.n = String(n); return; }
  const prev = Number(b.dataset.n); if (prev === n) return;
  b.dataset.n = String(n);
  if (!anim) { old.textContent = String(n); return; }
  const up = n > prev;
  b.querySelectorAll("span").forEach(x => { x.classList.add(up ? "up-out" : "down-out"); setTimeout(() => x.remove(), 240); });
  b.append(h("span", {class: up ? "up-in" : "down-in", text: String(n)}));
}
function rxSync(box, m, anim) {
  const want = Object.entries(m.rx || {}).filter(([, ids]) => ids.length), keys = new Set(want.map(([e]) => e)), have = new Map();
  [...box.children].forEach(c => {
    if (c.classList.contains("out")) return;
    if (keys.has(c.dataset.e)) have.set(c.dataset.e, c);
    else if (anim) { c.classList.add("out"); setTimeout(() => c.remove(), 230); } else c.remove();
  });
  let prev = null;
  want.forEach(([e, ids]) => {
    let c = have.get(e); const fresh = !c;
    if (fresh) c = rxChip(e);
    c._m = m;
    const mine = ids.includes(S.me.id), was = c.classList.contains("mine"), before = Number((c.querySelector(".cnt") || {dataset: {}}).dataset.n || 0);
    c.classList.toggle("mine", mine);
    c.title = ids.slice(0, 12).map(id => U(id).nickname).join(", ") + (ids.length > 12 ? " va yana " + (ids.length - 12) + " kishi" : "");
    c.setAttribute("aria-label", e + " " + ids.length + (mine ? " (siz qo'ygansiz)" : ""));
    rxCount(c, ids.length, anim && !fresh);
    if (anim) {
      const once = cls => { c.classList.add(cls); const rm = () => c.classList.remove(cls); c.addEventListener("animationend", rm, {once: true}); setTimeout(rm, 900); };
      if (fresh) once("in");
      else if (mine && !was) { const g = c.firstElementChild; g.classList.add("pop"); setTimeout(() => g.classList.remove("pop"), 520); }
      else if (!mine && ids.length > before) once("bump");
    }
    const nxt = prev ? prev.nextElementSibling : box.firstElementChild;
    if (c !== nxt) box.insertBefore(c, nxt);
    prev = c;
  });
}
function reactionsEl(m) {
  if (!Object.values(m.rx || {}).some(a => a.length)) return null;
  const box = h("div", {class: "rxs"}); rxSync(box, m, false); return box;
}
function patchReactions(m) {
  const row = document.querySelector('#msgs .row[data-id="' + Number(m.id) + '"]'); if (!row) return;
  const has = Object.values(m.rx || {}).some(a => a.length);
  let box = row.querySelector(".rxs");
  if (!box) {
    if (!has) return;
    box = h("div", {class: "rxs"});
    if (row.classList.contains("chan")) { const meta = row.querySelector(".bubble > .bfoot, .bubble > .meta"); (meta ? meta.before(box) : row.querySelector(".bubble").append(box)); }
    else row.append(box);
    if (!row.classList.contains("chan")) row.classList.add("has-rx");
  }
  rxSync(box, m, true);
  if (!has) setTimeout(() => { if (!box.querySelector(".rx:not(.out)")) { box.remove(); row.classList.remove("has-rx"); } }, 260);
}
function rxBurst(emoji, x, y, o) {
  o = o || {};
  const fx = h("span", {class: "rx-fx", "aria-hidden": "true"}); fx.style.left = x + "px"; fx.style.top = y + "px";
  if (!o.mini) fx.append(h("span", {class: "rx-burst"}, rxGlyph(emoji, "rx-bg")));
  const n = o.mini ? 5 : 8;
  for (let i = 0; i < n; i++) {
    const ang = (Math.PI * 2 * i) / n + Math.random() * .5 - .25, d = (o.mini ? 30 : 64) + Math.random() * 22;
    const sp = h("span", {class: "rx-sp"}, rxGlyph(emoji, "rx-sg"));
    sp.style.setProperty("--dx", (Math.cos(ang) * d).toFixed(1) + "px"); sp.style.setProperty("--dy", (Math.sin(ang) * d - (o.mini ? 6 : 16)).toFixed(1) + "px");
    sp.style.setProperty("--s", (0.55 + Math.random() * 0.45).toFixed(2)); sp.style.animationDelay = (Math.random() * 70 | 0) + "ms";
    fx.append(sp);
  }
  document.body.append(fx); setTimeout(() => fx.remove(), 1000);
  if (o.bubble) { const bb = o.bubble; bb.classList.remove("rx-bump"); void bb.offsetWidth; bb.classList.add("rx-bump"); setTimeout(() => bb.classList.remove("rx-bump"), 380); }
}
function rxPicker(m) {
  const mine = rxMine(m), box = h("div", {class: "rx-pick", role: "group", "aria-label": "Reaksiya"});
  const pick = (e, btn) => ev => {
    ev.stopPropagation(); const r = btn.getBoundingClientRect(); closeCtx();
    if (e !== mine) rxBurst(e, r.left + r.width / 2, r.top); reactTo(m, e);
  };
  const cell = e => { const b = h("button", {class: "rx-pk" + (e === mine ? " on" : ""), type: "button", "aria-label": e}, rxGlyph(e)); b.addEventListener("click", pick(e, b)); return b; };
  const row = h("div", {class: "rx-row"});
  RX_QUICK.forEach((e, i) => { const c = cell(e); c.style.setProperty("--i", String(i)); row.append(c); });
  const more = h("button", {class: "rx-pk rx-more", type: "button", "aria-label": "Barcha reaksiyalar", "aria-expanded": "false"}, icon("down"));
  const all = h("div", {class: "rx-all hidden"});
  let built = false;
  more.addEventListener("click", ev => {
    ev.stopPropagation();
    if (!built) {
      built = true;
      all.append(rxPackView(cell, {k: null}, "rx-grid-all"));
    }
    const c = $("ctx"), sheet = c.classList.contains("as-sheet");
    if (c._anchorB == null) c._anchorB = c.getBoundingClientRect().bottom;
    const open = all.classList.toggle("hidden") === false;
    more.classList.toggle("up", open); more.setAttribute("aria-expanded", String(open));
    if (!sheet) {
      const hh = c.getBoundingClientRect().height;
      let top = Math.max(8, c._anchorB - hh);
      if (top + hh > innerHeight - 8) top = Math.max(8, innerHeight - 8 - hh);
      c.style.top = top + "px";
    }
  });
  more.style.setProperty("--i", String(RX_QUICK.length)); row.append(more); box.append(row, all);
  return box;
}
const TAP_SKIP = "a,button,input,textarea,select,[role=button],.mplayer,.vtrack,.vspd,.cbtn,.code-scroll,.term-scroll,.rxs";
function attachTap(bubble, m) {
  // Oddiy bosish menyu OCHMAYDI. Menyu faqat: kompyuterda sichqonchaning o'ng tugmasi
  // (bubble "contextmenu"), telefonda esa bosib turish (attachTouch) orqali ochiladi.
  // Bu yerda faqat ikki marta bosib reaksiya qo'yish qoladi.
  let last = 0;
  bubble.addEventListener("click", e => {
    if (e.defaultPrevented || S.sel) return;
    if (e.target.closest && e.target.closest(TAP_SKIP)) return;
    if (!(rxPrefs.dbl && canReact(m))) return;
    const now = Date.now();
    if (last && now - last < 320) {
      last = 0;
      try { getSelection().removeAllRanges(); } catch (_) {}
      const emo = rxPrefs.emoji;
      rxBurst(emo, e.clientX, e.clientY, {bubble}); haptic(10);
      if (rxMine(m) !== emo) reactTo(m, emo);
      return;
    }
    last = now;
  });
}
function bubbleRow(m, isGroup, first, last, chan) {
  const own = m.user.id === S.me.id, mine = chan ? false : own, u = U(m.user.id);
  const row = h("div", {class: "row" + (mine ? " mine" : "") + (first ? " first" : "") + (last ? " last" : "") + (isGroup ? "" : " dm") + (chan ? " chan" : "")});
  row.dataset.id = m.id;
  if (S.sel) {
    const can = canDelete(m);
    row.classList.add(can ? "selectable" : "locked");
    if (can) {
      if (S.sel.has(m.id)) row.classList.add("selected");
      row.append(h("span", {class: "chk", "aria-hidden": "true"}, icon("check")));
    }
    row.addEventListener("click", e => { e.preventDefault(); e.stopPropagation(); toggleSel(m, row); }, true);
  }
  const slot = h("div", {class: "slot"});

  if (isGroup && !mine && last) { const a = avatar(u, "s"); a.style.cursor = "pointer"; a.addEventListener("click", () => openProfile(u.id)); slot.append(a); }
  const meta = h("span", {class: "meta"});
  if (m.edited) meta.append("tahrirlangan ");
  if (m.e2e) meta.append(h("span", {class: "lk" + (m.locked ? "" : (m.verified && !m.bad ? " ok" : " bad")),
    title: m.locked ? "Shifrlangan, kalit kutilmoqda" : m.verified && !m.bad ? "Uchdan-uchga shifrlangan, imzosi tasdiqlangan" : "Imzo yoki shifrni tekshirib bo'lmadi!",
    text: m.locked ? "🔒" : m.verified && !m.bad ? "🔒" : "⚠"}), " ");
  else if (m.legacy) meta.append(h("span", {class: "lk bad", title: "Eski xabar: E2EE'dan oldin yozilgan, server o'qiy oladi", text: "🔓"}), " ");
  if (chan) meta.append(h("span", {class: "vws", title: "Ko'rishlar soni"}, icon("eye"), h("b", {text: String(m.views || 0)})), " ");
  meta.append(hhmm(m.ts));
  if (mine) meta.append(icon(m.to != null && m.read ? "checks" : "check", m.to != null && m.read ? "ic rd" : "ic"));
  const bubble = tint(h("div", {class: "bubble" + (isStaff(u) ? " prem " + u.role : "") + (m.image ? " has-img" + (m.content ? "" : " img-only") : "") + (m.file ? " has-file" + (S.previews.has(m.id) ? " has-pv" : "") + (m.file.voice ? " has-voice" : "") + (m.file.vnote ? " has-vnote" + (m.content ? "" : " vn-only") : "") : "")}), u);
  if (!m.deleted) fxBubble(bubble, u);
  if (isGroup && !mine && first) {
    const ne = nameEl(u, {colored: true});
    ne.classList.add("lnk");
    ne.addEventListener("click", e => { e.stopPropagation(); openProfile(u.id); });
    bubble.append(h("div", {class: "bname"}, ne));
  }
  if (m.fwd) bubble.append(h("div", {class: "fwd", title: "Yuboruvchi ko'rsatgan asl muallif (tekshirib bo'lmaydi)"}, icon("forward"), h("span", {text: "Oldinga yuborilgan: "}), h("b", {text: m.fwd.n})));
  if (m.reply) bubble.append(replyQuote(m.reply, u));
  if (m.image) bubble.append(imageBox(m, mine || own));
  if (m.file) bubble.append(fileBox(m));
  if (!mine && m.content && !m.locked && !m.bad && Rich.mentionsOf(m.content, LINKCTX).includes(S.me.username)) bubble.classList.add("mentioned-me");
  const more = h("button", {class: "more", type: "button", "aria-label": "Amallar"}, icon("down"));
  const shown = m.locked ? "🔒 Xabar kaliti kutilmoqda…" : m.bad ? "⚠ Shifrni ochib bo'lmadi" : m.content;
  const parts = !m.locked && !m.bad && m.content ? Rich.parse(m.content) : null;
  if (parts && Rich.hasRich(parts)) {
    bubble.classList.add("has-code");
    parts.forEach((p, i) => {
      if (p.k === "text") { if (p.t) bubble.append(btextEl("btext rich-t", p.t, true)); return; }
      bubble.append(Rich.render(p, {user: u.username, fx: p.k === "term" && fxNow(m.id + ":" + i, m.ts), copy: copyQuiet}));
    });
  } else if (shown || !(m.image || m.file)) bubble.append(btextEl("btext" + (m.locked || m.bad ? " dim" : ""), shown, !m.locked && !m.bad));
  const rxEl = reactionsEl(m);
  if (rxEl && chan) bubble.append(rxEl);
  const soloOne = bubble.querySelector(".soloemo-1 .ce.solo");
  if (soloOne) { soloOne.classList.add("stk"); soloOne.addEventListener("click", e => { if (S.sel) return; e.stopPropagation(); openStickerPack(soloOne.alt); }); }
  if (bubble.querySelector(".bigemo")) {
    bubble.classList.add("has-big");
    if (bubble.querySelector(".bigemo-1")) bubble.classList.add("has-big-1");
    const stk = bubble.querySelector(".bigemo-1 .ce.big");
    if (stk) {
      stk.classList.add("stk");
      stk.addEventListener("click", e => { if (S.sel) return; e.stopPropagation(); openStickerPack(stk.alt); });
    }
    bubble.append(h("div", {class: "bfoot"}, meta), more);
  } else bubble.append(meta, more);
  if (chan) bubble.append(h("button", {class: "cmbtn", type: "button", onclick: e => { e.stopPropagation(); Channels.openComments(m); }},
    icon("chat"), h("span", {class: "cmb-t", text: m.comments ? m.comments + " ta izoh" : "Izoh qoldirish"}), h("span", {class: "cmb-go", text: "›"})));
  bubble.addEventListener("contextmenu", e => { e.preventDefault(); if (S.sel) return toggleSel(m, row); if (Date.now() - (S.ctxAt || 0) < 900) return; openCtx(e.clientX, e.clientY, m); });
  attachTouch(bubble, row, m);
  attachTap(bubble, m);
  row.append(slot, bubble);
  if (rxEl && !chan) { row.append(rxEl); row.classList.add("has-rx"); }
  return row;
}
const BIG_STD_ONE = /\p{Extended_Pictographic}(?:\uFE0F|[\u{1F3FB}-\u{1F3FF}]|\u200D\p{Extended_Pictographic}\uFE0F?)*/gu;
const BIG_STD = /^(?:\p{Extended_Pictographic}(?:\uFE0F|[\u{1F3FB}-\u{1F3FF}]|\u200D\p{Extended_Pictographic}\uFE0F?)*\s*){1,3}$/u;

function userIdByName(name) {
  for (const u of S.users.values()) if (u.username === name && !u.deleted) return u.id;
  return null;
}
const LINKCTX = {mention: userIdByName, onMention: name => { const id = userIdByName(name); if (id != null) openProfile(id); }};
function btextEl(cls, text, rich) {
  const d = h("div", {class: cls});
  if (rich && (Rich.hasInlineEmoji(text) || Rich.hasLinks(text, LINKCTX))) d.append(Rich.inline(text, LINKCTX)); else d.textContent = text == null ? "" : text;
  if (rich && !d.querySelector(".ce.big") && d.querySelectorAll(".ce.solo").length) d.classList.add("soloemo", d.querySelectorAll(".ce.solo").length === 1 ? "soloemo-1" : "soloemo-n");
  if (rich && (d.querySelector(".ce.big") || (typeof text === "string" && text.length <= 40 && BIG_STD.test(text.trim())))) {
    d.classList.add("bigemo");
    const cnt = d.querySelector(".ce.big") ? d.querySelectorAll(".ce.big").length : ((String(text).match(BIG_STD_ONE) || []).length);
    if (!d.querySelector(".ce.big")) d.classList.add("bigemo-std");
    d.classList.add(cnt === 1 ? "bigemo-1" : "bigemo-n");
  }
  return d;
}
function toggleToBottom() {
  const b = $("msgs");
  $("toBottom").classList.toggle("hidden", b.scrollHeight - b.scrollTop - b.clientHeight < 240);
}
let scrollTick = 0;
$("msgs").addEventListener("scroll", () => {
  if (scrollTick) return;
  scrollTick = requestAnimationFrame(() => {
    scrollTick = 0;
    const b = $("msgs"), bot = atBottom(); b._stick = bot; toggleToBottom();
    if (bot && S.away) bumpAway(true);
    closeCtx(); if (b.scrollTop < 160) loadOlder();
  });
}, {passive: true});
$("msgs").addEventListener("wheel", e => { if (e.deltaY < 0 && $("msgs").scrollTop <= 0) loadOlder(); }, {passive: true});
$("msgs").addEventListener("touchmove", () => { if ($("msgs").scrollTop <= 0) loadOlder(); }, {passive: true});
$("toBottom").addEventListener("click", () => { const b = $("msgs"); b.scrollTop = b.scrollHeight; bumpAway(true); });

function openMenu(x, y, items, sheet) {
  S.ctxAt = Date.now();
  const ctx = $("ctx"); ctx.textContent = "";
  items.forEach(it => {
    const b = h("button", {class: "dd-i", type: "button", onclick: () => { closeCtx(); it.fn(); }}, icon(it.ic), it.text);
    if (it.danger) b.style.color = "var(--err)";
    ctx.append(b);
  });
  showCtx(ctx, x, y, false);
}
function showCtx(ctx, x, y, asSheet) {
  ctx.classList.remove("hidden");
  ctx.classList.toggle("as-sheet", asSheet);
  $("ctxBack").classList.toggle("hidden", !asSheet);
  if (isMobile()) navPush("ctx");
  const w = ctx.offsetWidth, hgt = ctx.offsetHeight;
  ctx.style.left = Math.max(8, Math.min(x, innerWidth - w - 8)) + "px";
  ctx.style.top = Math.max(8, Math.min(y, innerHeight - hgt - 8)) + "px";
}
function dmMenu(x, y, uid, sheet) {
  openMenu(x, y, [
    {ic: "user", text: "Profilni ko'rish", fn: () => openProfile(uid)},
    {ic: "trash", text: "Suhbatni o'chirish", danger: true, fn: () => deleteDmChat(uid)},
  ], sheet);
}
$("chMore").addEventListener("click", e => {
  e.stopPropagation();
  if (!S.active || S.active.kind === "group") return;
  const r = $("chMore").getBoundingClientRect();
  if (S.active.kind === "channel") Channels.menu(r.right - 220, r.bottom + 4, S.active.id);
  else dmMenu(r.right - 200, r.bottom + 4, S.active.uid);
});
async function deleteDmChat(uid) {
  const u = U(uid);
  const ok = await confirmDlg("Bu suhbat (" + u.nickname + " bilan) ikkala tomon uchun ham butunlay o'chiriladi: xabarlar va rasmlar ikkalangizdan ham yo'qoladi. Buni qaytarib bo'lmaydi.",
    {title: "Suhbatni o'chirish", okText: "O'chirish", danger: true});
  if (ok) wsSend({type: "delete_dm", with: uid});
}

let renderQueued = false;
function scheduleRender() {
  if (renderQueued) return; renderQueued = true;
  requestAnimationFrame(() => { renderQueued = false; renderMessages(false); renderList(); });
}
function enterSelect(firstId) {
  if (!S.active) return;
  cancelEdit(); cancelReply();
  S.sel = new Set(); if (firstId != null) S.sel.add(firstId);
  $("chat").classList.add("selecting"); navPush("sel");
  renderMessages(false); updateSelBar();
}
function exitSelect() {
  if (!S.sel) return;
  S.sel = null; $("chat").classList.remove("selecting"); navPop("sel");
  renderMessages(false);
}
function toggleSel(m, row) {
  if (!S.sel || !canDelete(m)) return;
  if (S.sel.has(m.id)) S.sel.delete(m.id); else S.sel.add(m.id);
  if (row) row.classList.toggle("selected", S.sel.has(m.id));
  updateSelBar();
}
function updateSelBar() {
  if (!S.sel) return;
  $("selCount").textContent = String(S.sel.size);
  $("selDel").disabled = !S.sel.size;
  const all = currentMsgs().filter(x => !x.service && canDelete(x));
  $("selAll").textContent = all.length && all.every(x => S.sel.has(x.id)) ? "Bekor" : "Hammasi";
}
$("selCancel").addEventListener("click", exitSelect);
$("selAll").addEventListener("click", () => {
  if (!S.sel) return;
  const all = currentMsgs().filter(x => !x.service && canDelete(x));
  if (all.length && all.every(x => S.sel.has(x.id))) S.sel.clear(); else all.forEach(x => S.sel.add(x.id));
  document.querySelectorAll("#msgs .row[data-id]").forEach(r => r.classList.toggle("selected", S.sel.has(Number(r.dataset.id))));
  updateSelBar();
});
$("selDel").addEventListener("click", async () => {
  if (!S.sel || !S.sel.size) return;
  const ids = [...S.sel], n = ids.length;
  const ok = await confirmDlg(n + " ta xabar o'chirilsinmi?", {title: "Xabarlarni o'chirish", okText: "O'chirish", danger: true});
  if (!ok || !S.sel) return;
  for (let i = 0; i < ids.length; i += 200) wsSend({type: "delete_many", ids: ids.slice(i, i + 200)});
  exitSelect();
});
async function clearGroupChat() {
  if (!amAdmin()) return;
  const ok = await confirmDlg("Umumiy chatdagi BARCHA xabarlar hamma uchun o'chiriladi. Buni qaytarib bo'lmaydi.",
    {title: "Chatni tozalash", okText: "Tozalash", danger: true});
  if (ok) wsSend({type: "clear_chat"});
}

function canDelete(m) {
  if (m.ch) return amAdmin();
  if (m.user.id === S.me.id) return true;
  if (m.to != null || !amAdmin()) return false;
  const t = U(m.user.id);
  return t.role === "user" || (t.role === "admin" && S.me.role === "owner");
}
function openCtx(x, y, m) {
  S.ctxAt = Date.now();
  const ctx = $("ctx"); ctx.textContent = ""; ctx._anchorB = null; ctx.style.top = "";
  const add = (ic, text, fn, danger) => {
    const b = h("button", {class: "dd-i", type: "button", onclick: () => { closeCtx(); fn(); }}, icon(ic), text);
    if (danger) b.style.color = "var(--err)";
    ctx.append(b);
  };
  const usable = !m.locked && !m.bad;
  const chan = !!m.ch;
  if (S.offline) {
    if (m.content && usable) add("copy", "Nusxalash", () => copyText(m.content));
    else { toast("Oflayn rejim: bu xabar bilan amal qilib bo'lmaydi", "info"); return; }
    showCtx(ctx, x, y, false); return;
  }
  if (canReact(m)) ctx.append(rxPicker(m));
  if (chan) add("chat", "Izohlar", () => Channels.openComments(m));
  if (usable && !m.legacy && !chan) add("reply", "Javob berish", () => startReply(m));
  if (m.content && usable) add("copy", "Nusxalash", () => copyText(m.content));
  if (usable && canPin(m)) { const pd = isPinned(m); add(pd ? "unpin" : "pin", pd ? "Unpin qilish" : "Pin qilish", () => togglePin(m)); }
  if (usable && (m.image || (m.file && !m.file.vnote))) add("save", "Saqlash (Save as)", () => saveAs(m));
  if (usable && !m.legacy && !m.service && (m.content || m.image || m.file)) add("forward", "Oldinga yuborish", () => forwardMessage(m));
  if (m.user.id !== S.me.id && !chan) add("user", "Profilni ko'rish", () => openProfile(m.user.id));
  if (m.user.id !== S.me.id && m.to == null && !m.service && !chan) add("flag", "Shikoyat qilish", () => reportMessage(m));
  if (m.user.id === S.me.id && usable && !m.legacy) add("edit", "Tahrirlash", () => startEdit(m));
  if (canDelete(m)) add("select", "Belgilash", () => enterSelect(m.id));
  if (canDelete(m)) add("trash", "O'chirish", async () => { if (await confirmDlg("Bu xabar o'chirilsinmi?", {title: "Xabarni o'chirish", okText: "O'chirish", danger: true})) wsSend({type: "delete", id: m.id}); }, true);
  const row = document.querySelector('#msgs .row[data-id="' + Number(m.id) + '"]'); if (row) row.classList.add("ctx-on");
  showCtx(ctx, x, y, false);
}
function closeCtx() {
  const c = $("ctx"); if (c.classList.contains("hidden")) return;
  c.classList.add("hidden"); $("ctxBack").classList.add("hidden");
  document.querySelectorAll("#msgs .row.ctx-on").forEach(r => r.classList.remove("ctx-on"));
  navPop("ctx");
}

const pinSt = () => !S.active ? null : S.active.kind === "group" ? S.group : S.active.kind === "dm" ? dmOf(S.active.uid) : null;
const pinStOf = m => m.to == null ? S.group : dmOf(partnerOf(m));
function canPin(m) { return !!m && !m.ch && !m.service && m.id != null && !m.pending && (m.to != null || amAdmin()); }
function isPinned(m) { const st = pinStOf(m); return !!(st.pins && st.pins.some(p => p.id === m.id)); }
async function togglePin(m) {
  const on = !isPinned(m);
  if (m.to == null) { wsSend({type: "pin", id: m.id, on}); return; }
  const r = await askDialog({title: on ? "Xabarni pin qilish" : "Pinni olib tashlash",
    text: on ? "Xabar sizning suhbatingizda yuqoriga mahkamlanadi." : "Xabar sizdan pin olib tashlanadi.",
    okText: "OK", check: {label: on ? "Suhbatdosh uchun ham pin qilish" : "Suhbatdosh uchun ham olib tashlash", checked: true}});
  if (!r) return;
  wsSend({type: "pin", id: m.id, on, both: !!r.checked});
}
const pinRow = id => $("msgs").querySelector('.row[data-id="' + Number(id) + '"]');
function markPins() {
  const st = pinSt(), box = $("msgs"); if (!st) return;
  const ids = new Set((st.pins || []).map(p => p.id));
  box.querySelectorAll(".row[data-id]").forEach(r => {
    const on = ids.has(Number(r.dataset.id)), meta = r.querySelector(".bubble .meta"), mk = meta && meta.querySelector(".pinmark");
    if (on && meta && !mk) meta.prepend(icon("pin", "ic pinmark"));
    else if (!on && mk) mk.remove();
  });
}
function renderPinBar() {
  const bar = $("pinBar"), st = pinSt(), list = (st && st.pins) || [];
  if (!st || !list.length) { bar.classList.add("hidden"); return; }
  if (st.pinIdx == null || st.pinIdx >= list.length || st.pinIdx < 0) st.pinIdx = list.length - 1;
  const m = list[st.pinIdx];
  $("pinTitle").textContent = "Pin qilingan xabar" + (list.length > 1 ? " #" + (st.pinIdx + 1) + "/" + list.length : "");
  const t = $("pinText"); t.textContent = ""; t.append(...[].concat(previewOf(m, true, false)));
  $("pinX").classList.toggle("hidden", !canPin(m));
  bar.classList.remove("hidden");
}
async function pinGoTo(id) {
  const st = pinSt(); if (!st) return;
  if (!pinRow(id)) {
    let i = st.msgs.findIndex(x => x.id === id);
    for (let n = 0; i < 0 && st.more && n < 30; n++) { await loadOlder(); i = st.msgs.findIndex(x => x.id === id); }
    if (i >= 0) { S.win = Math.max(S.win || WIN0, st.msgs.length - i + 6); renderMessages(false); }
  }
  if (pinRow(id)) jumpTo(id); else toast("Xabar topilmadi (eski yoki o'chirilgan)", "warn");
}
function pinBarClick() {
  const st = pinSt(); if (!st || !st.pins || !st.pins.length) return;
  const m = st.pins[st.pinIdx != null ? st.pinIdx : st.pins.length - 1];
  st.pinIdx = (st.pins.indexOf(m) - 1 + st.pins.length) % st.pins.length;
  renderPinBar(); pinGoTo(m.id);
}
async function pinsRefresh(kind, uid) {
  kind = kind || (S.active && S.active.kind); if (kind !== "group" && kind !== "dm") return;
  uid = uid != null ? uid : (S.active && S.active.uid);
  const st = kind === "group" ? S.group : dmOf(uid);
  try {
    const j = await api(kind === "group" ? "/pins/group" : "/pins/dm/" + uid);
    if (X.ready) await Promise.race([X.ready, delay(8000)]);
    await hydrateAll(j.pins); j.pins.forEach(x => upsertUser(x.user));
    st.pins = j.pins; st.pinIdx = null;
  } catch (_) { return; }
  if (pinSt() === st) { renderPinBar(); markPins(); }
}
function pinsOnEvent(m) { if (m.scope === "g") pinsRefresh("group"); else pinsRefresh("dm", m.with); }
function pinDrop(id) {
  const all = [S.group].concat([...S.dms.values()]);
  all.forEach(st => { if (st.pins && st.pins.some(p => p.id === id)) st.pins = st.pins.filter(p => p.id !== id); });
  if (S.active) renderPinBar();
}
$("pinBarMain").addEventListener("click", pinBarClick);
$("pinX").addEventListener("click", e => { e.stopPropagation(); const st = pinSt(); if (!st || !st.pins) return; const m = st.pins[st.pinIdx != null ? st.pinIdx : st.pins.length - 1]; if (m && canPin(m)) togglePin(m); });

const safeName = n => String(n || "fayl").replace(/[\\/:*?"<>|\u0000-\u001f]/g, "_").replace(/^\.+/, "").trim().slice(0, 120) || "fayl";
async function messageBytes(m) {
  if (m.e2e) return e2eFetchBlob(m);
  const url = m.image || (m.file && m.file.url);
  const r = await SC.fetch(url, {headers: {Authorization: "Bearer " + S.token}});
  if (!r.ok) throw new Error("fayl");
  return r.bytes;
}
async function saveBytesAs(getBytes, name) {
  if (await DL.dir()) {
    try { const n = await DL.write(name, await getBytes(), true); if (n) return n; }
    catch (err) { if (!err || err.name !== "NotAllowedError") throw err; }
  }
  let handle = null;
  if (window.showSaveFilePicker) {
    try { handle = await window.showSaveFilePicker({suggestedName: name}); }
    catch (err) { if (err && err.name === "AbortError") return false; handle = null; }
  }
  let bytes;
  try { bytes = await getBytes(); } catch (err) { if (handle && handle.remove) handle.remove().catch(() => {}); throw err; }
  if (handle) {
    const w = await handle.createWritable();
    try { await w.write(bytes); await w.close(); } catch (err) { try { await w.abort(); } catch (_) {} throw err; }
    return true;
  }
  const url = URL.createObjectURL(new Blob([bytes], {type: "application/octet-stream"}));
  const a = h("a", {href: url, download: name}); document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60000);
  return true;
}
async function saveAs(m) {
  if (m.file && m.file.vnote) { toast("Dumaloq videoni saqlab bo'lmaydi", "error"); return; }
  const name = safeName((m._f && m._f.name) || (m.file && m.file.name) || (m.image ? "rasm.jpg" : "fayl"));
  try { const r = await saveBytesAs(() => messageBytes(m), name); if (r) toast("Saqlandi: " + (typeof r === "string" ? r : name), "ok"); }
  catch (_) { toast("Faylni saqlab bo'lmadi", "error"); }
}
function forwardMessage(m) {
  const picked = new Map();
  let filter = "", busy = false;
  const targets = () => [{key: "g", kind: "group"}].concat(S.members.filter(x => x.id !== S.me.id && !x.deleted && !x.banned).map(x => ({key: "u" + x.id, kind: "dm", uid: x.id})));
  const what = m.image ? "📷 Rasm" : m.file ? fileIco(m.file) + fileWhat(m.file) : "";
  openModal(() => {
    const list = h("div", {class: "fwl"}), send = h("button", {class: "btn", type: "button", disabled: true, text: "Yuborish"});
    const noteTxt = (what ? what + (m.content ? " • " : "") : "") + (m.content ? snippetOf(m.content).slice(0, 80) : "");
    const note = h("div", {class: "fw-note"}, Rich.hasInlineEmoji(noteTxt) ? Rich.preview(noteTxt) : noteTxt);
    const upd = () => { send.disabled = busy || !picked.size; send.textContent = picked.size ? "Yuborish (" + picked.size + ")" : "Yuborish"; };
    const fill = () => {
      list.textContent = "";
      const q = filter.trim().toLowerCase().replace(/^@/, "");
      targets().forEach(t => {
        const u = t.kind === "dm" ? U(t.uid) : null;
        if (q && (!u || !(u.nickname.toLowerCase().includes(q) || u.username.toLowerCase().includes(q)))) { if (!(t.kind === "group" && "umumiy chat".includes(q))) return; }
        const ck = h("input", {type: "checkbox", class: "ck", tabindex: "-1", "aria-hidden": "true"}); ck.checked = picked.has(t.key);
        const row = h("button", {class: "frow" + (ck.checked ? " on" : ""), type: "button"},
          u ? avatar(u, "m", true) : groupAvatar("m"),
          h("div", {class: "utx"}, u ? nameEl(u) : h("span", {class: "nt", text: "Umumiy chat"}), h("span", {class: "fsub", text: u ? "@" + u.username : (S.members.length || 1) + " a'zo"})), ck);
        row.addEventListener("click", () => { if (busy) return; if (picked.has(t.key)) picked.delete(t.key); else picked.set(t.key, t); ck.checked = picked.has(t.key); row.classList.toggle("on", ck.checked); upd(); });
        list.append(row);
      });
      if (!list.children.length) list.append(h("div", {class: "none", text: "Hech narsa topilmadi"}));
    };
    const search = h("input", {type: "text", class: "gsearch", placeholder: "Qidirish", autocomplete: "off"});
    search.addEventListener("input", () => { filter = search.value; fill(); });
    send.addEventListener("click", async () => {
      if (busy || !picked.size) return;
      busy = true; upd(); send.textContent = "Shifrlanmoqda…"; search.disabled = true;
      const r = await doForward(m, [...picked.values()]);
      busy = false; closeModal();
      if (r.ok) toast("Oldinga yuborildi" + (r.ok > 1 ? " (" + r.ok + " ta suhbat)" : ""), "ok");
      if (r.errs.length) toast(r.errs[0] + (r.errs.length > 1 ? " (+" + (r.errs.length - 1) + " ta xato)" : ""), "error");
    });
    fill();
    return h("div", {}, sheetHead("Oldinga yuborish"), note, search, list, h("div", {class: "fw-bar"}, send));
  }, false);
}
async function doForward(m, targets) {
  const res = {ok: 0, errs: []};
  let enc = null;
  const fw = m._fw || (m.ch ? {n: (chInfo(m.ch) || {}).nickname || "Kanal", id: 0} : {n: m.user.nickname, id: m.user.id});
  try { if (m._f) enc = await E2E.encryptFile(new Uint8Array(await messageBytes(m))); }
  catch (_) { res.errs.push("Faylni ochib bo'lmadi"); return res; }
  for (const t of targets) {
    const label = t.kind === "group" ? "Umumiy chat" : U(t.uid).nickname;
    try {
      if (t.kind === "group" && S.chat.locked && !amAdmin()) throw new Error("chat qulflangan");
      if (t.kind === "dm" && U(t.uid).deleted) throw new Error("akkaunt o'chirilgan");
      const ctx = await keyForTarget(t), payload = {t: m.content || "", fw};
      let blobName = null;
      if (enc) {
        const r = await SC.fetch("/api/e2ee/blob", {method: "POST", headers: {Authorization: "Bearer " + S.token, "Content-Type": "application/octet-stream"}, body: enc.blob});
        const j = await r.json().catch(() => ({}));
        if (!r.ok) throw new Error(typeof j.detail === "string" ? j.detail : "fayl yuklanmadi");
        blobName = j.blob; payload.f = Object.assign({}, m._f, {k: enc.key});
      }
      const msg = {type: "send", e2e: await sealFor(ctx, payload)};
      if (blobName) msg.blob = blobName;
      withTarget(msg, t);
      if (!wsSend(msg)) throw new Error("ulanish yo'q");
      res.ok++;
    } catch (err) { res.errs.push(label + ": " + err.message); }
  }
  return res;
}
async function reportMessage(m) {
  const reason = await promptDlg("Shikoyat qilish", m.e2e
    ? "Xabarlar shifrlangan, adminlar ularni o'qiy olmaydi. Shikoyat yuborsangiz, FAQAT shu bitta xabarning matni adminlarga ochib beriladi. Nima uchun shikoyat qilyapsiz? (ixtiyoriy)"
    : "Nima uchun shikoyat qilyapsiz? (ixtiyoriy)", "", {okText: "Yuborish", placeholder: "Sabab"});
  if (reason === null) return;
  try { await api("/report", {method: "POST", body: {message_id: m.id, reason, evidence: m.e2e ? (m.content || "") : ""}}); toast("Shikoyat adminlarga yuborildi", "ok"); }
  catch (err) { toast(err.message, "error"); }
}
document.addEventListener("click", e => {
  if (Date.now() - (S.ctxAt || 0) > 350) closeCtx();
});
async function copyText(t) {
  try { await navigator.clipboard.writeText(t); toast("Nusxalandi", "ok"); }
  catch (_) {
    const ta = h("textarea", {class: "offscreen"}); ta.value = t; document.body.append(ta); ta.select();
    try { document.execCommand("copy"); toast("Nusxalandi", "ok"); } catch (_e) {}
    ta.remove();
  }
}

(() => {
  const el = $("inp");
  if (!el || el.tagName === "TEXTAREA") return;
  let plain = true;
  try { el.contentEditable = "plaintext-only"; plain = el.contentEditable === "plaintext-only"; } catch (_) { plain = false; }
  if (!plain) el.contentEditable = "true";
  let max = parseInt(el.getAttribute("data-maxlength") || "3000", 10) || 3000, composing = false, last = null;

  const ser = (node, top = true) => {
    let out = "";
    for (let n = node.firstChild; n; n = n.nextSibling) {
      if (n.nodeType === 3) out += n.nodeValue.replace(/\u00a0/g, " ");
      else if (n.nodeType === 1) {
        if (n.nodeName === "IMG") out += n.dataset.t || n.alt || "";
        else if (n.nodeName === "BR") { if (n.nextSibling || !top) out += "\n"; }
        else {
          if (/^(DIV|P|LI)$/.test(n.nodeName) && out && !out.endsWith("\n")) out += "\n";
          out += ser(n, false);
        }
      }
    }
    return out;
  };
  const emojiImg = token => {
    const i = Rich.chatEmoji(token, false);
    i.className = "ce ci"; i.title = ""; i.dataset.t = token; i.contentEditable = "false"; i.draggable = false;
    return i;
  };
  const frag = text => {
    const f = document.createDocumentFragment(), ms = Rich.emojiMatches(text);
    let at = 0;
    for (const m of ms) {
      if (m.i > at) f.append(document.createTextNode(text.slice(at, m.i)));
      f.append(emojiImg(m.t)); at = m.i + m.t.length;
    }
    if (at < text.length) f.append(document.createTextNode(text.slice(at)));
    return f;
  };
  const selRange = () => {
    const s = getSelection();
    if (!s || !s.rangeCount) return null;
    const r = s.getRangeAt(0);
    return el.contains(r.startContainer) && el.contains(r.endContainer) ? r : null;
  };
  const lenBefore = (node, off) => { const r = document.createRange(); r.selectNodeContents(el); r.setEnd(node, off); return ser(r.cloneContents()).length; };
  const getSel = () => {
    const r = selRange();
    if (r) return (last = [lenBefore(r.startContainer, r.startOffset), lenBefore(r.endContainer, r.endOffset)]);
    const n = ser(el).length;
    return last ? [Math.min(last[0], n), Math.min(last[1], n)] : [n, n];
  };
  const locate = off => {
    let acc = 0;
    const w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT);
    for (let n = w.nextNode(); n; n = w.nextNode()) {
      if (n.nodeType === 3) {
        const len = n.nodeValue.length;
        if (off <= acc + len) return [n, Math.max(0, off - acc)];
        acc += len;
      } else if (n.nodeName === "IMG") {
        const L = (n.dataset.t || "").length, p = n.parentNode, idx = Array.prototype.indexOf.call(p.childNodes, n);
        if (off <= acc) return [p, idx];
        if (off <= acc + L) return [p, idx + 1];
        acc += L;
      }
    }
    return [el, el.childNodes.length];
  };
  const setSel = (a, b) => {
    const s = getSelection(), r = document.createRange(), p = locate(a), q = b === a ? p : locate(b);
    r.setStart(p[0], p[1]); r.setEnd(q[0], q[1]);
    s.removeAllRanges(); s.addRange(r); last = [a, b];
  };
  const fire = () => el.dispatchEvent(new Event("input", {bubbles: true}));

  Object.defineProperty(el, "value", {configurable: true,
    get() { return ser(el); },
    set(v) { v = v == null ? "" : String(v); el.textContent = ""; last = null; if (v) el.append(frag(v)); }});
  Object.defineProperty(el, "selectionStart", {configurable: true, get() { return getSel()[0]; }, set(v) { setSel(v, getSel()[1] < v ? v : getSel()[1]); }});
  Object.defineProperty(el, "selectionEnd", {configurable: true, get() { return getSel()[1]; }, set(v) { setSel(Math.min(getSel()[0], v), v); }});
  Object.defineProperty(el, "placeholder", {configurable: true, get() { return el.dataset.placeholder || ""; }, set(v) { el.dataset.placeholder = v; }});
  Object.defineProperty(el, "maxLength", {configurable: true, get() { return max; }, set(v) { max = (v | 0) || max; }});
  el.setSelectionRange = (a, b) => setSel(a, b == null ? a : b);
  el.setRangeText = (text, s, e, mode) => {
    if (s == null) { const c = getSel(); s = c[0]; e = c[1]; }
    const p = locate(s), q = locate(e), r = document.createRange();
    r.setStart(p[0], p[1]); r.setEnd(q[0], q[1]); r.deleteContents();
    r.insertNode(frag(String(text)));
    el.normalize();
    const end = s + String(text).length;
    if (mode === "select") setSel(s, end); else if (mode === "start") setSel(s, s); else if (mode !== "preserve") setSel(end, end);
  };
  const nativeFocus = el.focus.bind(el);
  el.focus = o => { const had = !!selRange(); nativeFocus(o); if (!had) { const n = last ? getSel()[1] : ser(el).length; setSel(n, n); } };
  const put = text => {
    const c = getSel(), room = max - (ser(el).length - (c[1] - c[0]));
    if (room <= 0) { try { toast("Xabar juda uzun", "warn"); } catch (_) {} return; }
    el.setRangeText(text.length > room ? text.slice(0, room) : text, c[0], c[1], "end"); fire();
  };

  document.addEventListener("selectionchange", () => { if (selRange()) getSel(); });
  el.addEventListener("compositionstart", () => { composing = true; });
  el.addEventListener("compositionend", () => { composing = false; });
  el.addEventListener("beforeinput", e => {
    const t = e.inputType;
    if (t === "insertParagraph" || t === "insertLineBreak") { e.preventDefault(); put("\n"); return; }
    if (t === "insertFromPaste" || t === "insertFromDrop" || t === "insertFromPasteAsQuotation") {
      const txt = (e.dataTransfer && e.dataTransfer.getData("text/plain")) || e.data || "";
      e.preventDefault();
      if (txt) put(txt.replace(/\r\n?/g, "\n"));
      return;
    }
    if (t === "insertText" && e.data && !composing) {
      const c = getSel();
      if (ser(el).length - (c[1] - c[0]) + e.data.length > max) { e.preventDefault(); try { toast("Xabar juda uzun", "warn"); } catch (_) {} }
    }
  });
  el.addEventListener("input", () => {
    if (composing) return;
    const v = ser(el);
    if (!v && el.firstChild) { el.textContent = ""; return; }
    if (v.length > max) { const c = getSel()[0]; el.value = v.slice(0, max); const n = Math.min(c, max); setSel(n, n); }
  });
  el.addEventListener("copy", e => {
    const r = selRange();
    if (!r || r.collapsed || !e.clipboardData) return;
    e.clipboardData.setData("text/plain", ser(r.cloneContents())); e.preventDefault();
  });
  el.addEventListener("cut", e => {
    const r = selRange();
    if (!r || r.collapsed || !e.clipboardData) return;
    e.clipboardData.setData("text/plain", ser(r.cloneContents())); e.preventDefault();
    r.deleteContents(); el.normalize(); fire();
  });
})();

const MEN = {el: null, items: [], sel: 0, start: -1};
const inp = $("inp");
function autosize() { inp.style.height = "auto"; inp.style.height = Math.min(inp.scrollHeight, 140) + "px"; syncSend(); updateMention(); }
function syncSend() {
  $("sendBtn").classList.toggle("on", !!inp.value.trim() || !!S.pendingImg);
  $("composer").classList.toggle("has-text", !!inp.value.trim() || !!S.pendingImg || !!S.editing);
}
inp.addEventListener("input", autosize);
inp.addEventListener("focus", () => setTimeout(() => { const b = $("msgs"); if (b._stick) b.scrollTop = b.scrollHeight; }, 320));
inp.addEventListener("keydown", e => {
  if (mentionKey(e)) return;
  if (e.key === "Enter" && !e.shiftKey && !COARSE && !e.isComposing) { e.preventDefault(); submit(); }
  else if (e.key === "Escape") { if (S.editing) cancelEdit(); else if (S.pendingImg) clearPendingImage(); else if (S.replying) cancelReply(); }
  else if (e.key === "ArrowUp" && !inp.value && S.active) {
    const mine = [...currentMsgs()].reverse().find(x => !x.service && x.user.id === S.me.id && !x.legacy && !x.bad && !x.locked);
    if (mine) { e.preventDefault(); startEdit(mine); }
  }
});
inp.addEventListener("paste", e => {
  const f = (e.clipboardData && e.clipboardData.files || [])[0];
  if (f) { e.preventDefault(); setPendingImage(f); return; }
  const txt = e.clipboardData && e.clipboardData.getData("text/plain");
  const whole = !inp.value.trim() || (inp.selectionStart === 0 && inp.selectionEnd === inp.value.length);
  if (!txt || !whole || S.editing) return;
  const fz = Rich.fenceFor(txt.replace(/\r\n?/g, "\n"));
  if (!fz || fz.text.length > inp.maxLength) return;
  e.preventDefault();
  inp.value = fz.text; inp.setSelectionRange(fz.text.length, fz.text.length); autosize();
  toast("Aniqlandi: " + fz.label + ". Xavfsiz ko'rinishda yuboriladi", "ok");
});

function mentionQuery() {
  const pos = inp.selectionStart;
  if (pos == null || pos !== inp.selectionEnd) return null;
  const m = /(?:^|[\s(])@([A-Za-z0-9_]{0,20})$/.exec(inp.value.slice(0, pos));
  return m ? {q: m[1].toLowerCase(), start: pos - m[1].length - 1, pos} : null;
}
function mentionCandidates(q) {
  const rank = u => { const un = u.username, nn = (u.nickname || "").toLowerCase(); return !q ? 1 : un.startsWith(q) ? 0 : nn.startsWith(q) ? 1 : un.includes(q) ? 2 : nn.includes(q) ? 3 : 9; };
  return S.members.map(m => U(m.id)).filter(u => u.id !== S.me.id && !u.deleted && !u.banned && u.username && rank(u) < 9)
    .sort((a, b) => rank(a) - rank(b) || (a.role === "owner" ? -1 : 0) - (b.role === "owner" ? -1 : 0) || a.username.localeCompare(b.username)).slice(0, 6);
}
function closeMention() { if (MEN.el) { MEN.el.remove(); MEN.el = null; } MEN.items = []; }
function pickMention(u) {
  const q = mentionQuery(); if (!q) { closeMention(); return; }
  const ins = "@" + u.username + " ";
  if (inp.value.length - (q.pos - q.start) + ins.length > inp.maxLength) { toast("Xabar juda uzun", "warn"); return; }
  inp.setRangeText(ins, q.start, q.pos, "end"); closeMention(); autosize();
  if (!COARSE) inp.focus({preventScroll: true});
}
function paintMention() {
  if (!MEN.el) { MEN.el = h("div", {class: "mention-panel", role: "listbox", "aria-label": "Foydalanuvchini belgilash"}); MEN.el.addEventListener("mousedown", e => e.preventDefault()); document.body.append(MEN.el); }
  MEN.el.textContent = "";
  MEN.items.forEach((u, i) => {
    const b = h("button", {class: "mn-i" + (i === MEN.sel ? " on" : ""), type: "button", role: "option", "aria-selected": String(i === MEN.sel)},
      avatar(u, "s"), h("div", {class: "mn-t"}, h("b", {}, nameEl(u)), h("small", {text: "@" + u.username})));
    b.addEventListener("click", () => pickMention(u));
    MEN.el.append(b);
  });
  const r = inp.getBoundingClientRect(), w = Math.min(320, innerWidth - 16);
  MEN.el.style.width = w + "px"; MEN.el.style.left = Math.max(8, Math.min(r.left, innerWidth - w - 8)) + "px"; MEN.el.style.bottom = Math.max(8, innerHeight - r.top + 8) + "px";
}
function updateMention() {
  const q = S.me && !S.editing ? mentionQuery() : null;
  const list = q ? mentionCandidates(q.q) : [];
  if (!list.length) { closeMention(); return; }
  const same = MEN.items.length === list.length && MEN.items.every((u, i) => u.id === list[i].id);
  MEN.items = list; if (!same) MEN.sel = 0;
  paintMention();
}
function mentionKey(e) {
  if (!MEN.el || !MEN.items.length || e.isComposing) return false;
  const n = MEN.items.length;
  if (e.key === "ArrowDown" || e.key === "ArrowUp") { e.preventDefault(); MEN.sel = (MEN.sel + (e.key === "ArrowDown" ? 1 : n - 1)) % n; paintMention(); return true; }
  if (e.key === "Tab" || (e.key === "Enter" && !e.shiftKey && !COARSE)) { e.preventDefault(); pickMention(MEN.items[MEN.sel]); return true; }
  if (e.key === "Escape") { e.preventDefault(); closeMention(); return true; }
  return false;
}
inp.addEventListener("keyup", e => { if (e.key === "ArrowLeft" || e.key === "ArrowRight" || e.key === "Home" || e.key === "End") updateMention(); });
inp.addEventListener("click", updateMention);
inp.addEventListener("blur", () => setTimeout(closeMention, 150));
$("sendBtn").addEventListener("click", submit);

function startEdit(m) {
  cancelReply(); clearPendingImage();
  S.editing = m; inp.value = m.content; autosize(); inp.focus();
  const ebt = m.content ? m.content.replace(/\s+/g, " ") : (m.file ? (m.file.voice ? "🎤 Ovozli xabar izohi" : m.file.vnote ? "📹 Video xabar izohi" : "📎 Fayl izohi") : "📷 Rasm izohi");
  $("ebText").replaceChildren(Rich.hasInlineEmoji(ebt) ? Rich.preview(ebt) : document.createTextNode(ebt));
  $("editbar").classList.remove("hidden");
}
function cancelEdit() {
  if (!S.editing) return;
  S.editing = null; inp.value = ""; autosize(); $("editbar").classList.add("hidden");
}
$("ebCancel").addEventListener("click", cancelEdit);

function startReply(m) {
  if (m.ch) return;
  cancelEdit();
  S.replying = replyInfo(m);
  $("rbName").textContent = m.user.nickname;
  const rbt = (m.image ? "📷 " : m.file ? fileIco(m.file) : "") + (m.content ? m.content.replace(/\s+/g, " ") : (m.file ? fileWhat(m.file) : "Rasm"));
  $("rbText").replaceChildren(Rich.hasInlineEmoji(rbt) ? Rich.preview(rbt) : document.createTextNode(rbt));
  $("replybar").classList.remove("hidden");
  inp.focus();
}
function cancelReply() { S.replying = null; $("replybar").classList.add("hidden"); }
$("rbCancel").addEventListener("click", cancelReply);

const IMG_TYPES = ["image/png", "image/jpeg", "image/webp", "image/gif"], MAX_MEDIA = 50 * 1024 * 1024;
async function shrinkImage(f) {
  if (f.type === "image/gif" || f.size <= 1.5 * 1024 * 1024 || !self.createImageBitmap) return f;
  try {
    const bmp = await createImageBitmap(f), k = Math.min(1, 1920 / Math.max(bmp.width, bmp.height));
    const c = document.createElement("canvas"); c.width = Math.round(bmp.width * k); c.height = Math.round(bmp.height * k);
    const g = c.getContext("2d"); g.fillStyle = "#fff"; g.fillRect(0, 0, c.width, c.height); g.drawImage(bmp, 0, 0, c.width, c.height);
    const blob = await new Promise(r => c.toBlob(r, "image/jpeg", 0.85));
    return blob && blob.size < f.size ? blob : f;
  } catch (_) { return f; }
}
async function setPendingImage(file) {
  if (!S.active || !file) return;
  if (S.active.kind === "group" && S.chat.locked && !amAdmin()) { toast("Umumiy chat qulflangan", "error"); return; }
  const isImg = IMG_TYPES.includes(file.type);
  const blob = isImg ? await shrinkImage(file) : file;
  if (blob.size > MAX_MEDIA) { toast("Fayl 50 MB dan oshmasligi kerak", "error"); return; }
  if (!blob.size) { toast("Fayl bo'sh", "error"); return; }
  cancelEdit(); clearPendingImage();
  const ext = blob.type === "image/jpeg" ? "jpg" : (blob.type.split("/")[1] || "png");
  S.pendingImg = {blob, isImg, url: isImg ? URL.createObjectURL(blob) : null, name: isImg ? "rasm." + ext : (file.name || "fayl")};
  $("ibThumb").classList.toggle("hidden", !isImg); $("ibIcon").classList.toggle("hidden", isImg);
  if (isImg) $("ibThumb").src = S.pendingImg.url; else $("ibThumb").removeAttribute("src");
  $("ibTitle").textContent = isImg ? "Rasm" : S.pendingImg.name;
  $("ibInfo").textContent = "Izoh yozib yuboring (ixtiyoriy) • " + fmtSize(blob.size);
  $("imgbar").classList.remove("hidden");
  syncSend(); inp.focus();
}
function clearPendingImage() {
  if (S.pendingImg && S.pendingImg.url) URL.revokeObjectURL(S.pendingImg.url);
  S.pendingImg = null; $("ibThumb").removeAttribute("src"); $("imgbar").classList.add("hidden"); syncSend();
}
$("attachBtn").addEventListener("click", () => $("imgFile").click());
$("imgFile").addEventListener("change", () => { const f = $("imgFile").files[0]; $("imgFile").value = ""; if (f) setPendingImage(f); });
$("ibCancel").addEventListener("click", clearPendingImage);
["dragenter", "dragover"].forEach(ev => $("chat").addEventListener(ev, e => { if (e.dataTransfer && [...e.dataTransfer.types].includes("Files")) { e.preventDefault(); $("chat").classList.add("drop"); } }));
["dragleave", "drop"].forEach(ev => $("chat").addEventListener(ev, e => { if (ev === "dragleave" && $("chat").contains(e.relatedTarget)) return; $("chat").classList.remove("drop"); }));
$("chat").addEventListener("drop", e => { const f = e.dataTransfer && e.dataTransfer.files[0]; if (f) { e.preventDefault(); setPendingImage(f); } });

async function sendImage(caption) {
  if (S.sending) return;
  const img = S.pendingImg, reply = S.replying;
  const pend = Pend.add(S.active, {kind: "file", name: img.name, size: img.blob.size, isImg: img.isImg, text: caption, url: img.isImg ? URL.createObjectURL(img.blob) : null}), relTy = Typing.hold("file");
  inp.value = ""; clearPendingImage(); cancelReply(); autosize();
  Pend.go(pend, async p => {
    if (!p.fileMeta) {
      let blob = img.blob, f = {name: img.name, mime: blob.type || "application/octet-stream", size: blob.size, img: false};
      if (img.isImg) {
        let c; try { c = await cleanImage(blob); } catch (_) { throw Object.assign(new Error("Rasmni o'qib bo'lmadi"), {final: true}); }
        blob = c.blob; f = Object.assign(f, {mime: blob.type || f.mime, size: blob.size, img: true, w: c.w, h: c.h, th: c.th});
      }
      const e = await E2E.encryptFile(new Uint8Array(await blob.arrayBuffer()));
      f.k = e.key; p.fileMeta = f; p.encBlob = e.blob;
    }
    if (!p.blobName) {
      if (!p.upJob) p.upJob = uploadEnc(p.encBlob, "Fayl yuklanmadi").then(n => { p.blobName = n; p.encBlob = null; return n; }, e => { p.upJob = null; throw e; });
      await p.upJob;
    }
    const payload = {t: caption, f: p.fileMeta}; if (reply) payload.r = reply;
    return withTarget({type: "send", cid: p.cid, e2e: await sealFor(await keyForTarget(p.target), payload), blob: p.blobName}, p.target);
  }).finally(relTy);
}
async function submit() {
  const text = inp.value.trim();
  if (!S.active || S.sending) return;
  if (S.active.kind === "dm" && U(S.active.uid).deleted) { toast("Bu akkaunt o'chirilgan. Xabar yuborib bo'lmaydi", "error"); return; }
  if (S.pendingImg) { sendImage(text); return; }
  if (!S.editing && !text) return;
  if (S.editing && !text && !S.editing._f) return;
  if (S.editing && text === S.editing.content) { cancelEdit(); return; }
  S.sending = true;
  let pend = null;
  try {
    if (S.editing) {
      const ctx = await keyForActive(), payload = {t: text};
      const m = S.editing;
      if (m._r) payload.r = m._r; if (m._f) payload.f = m._f; if (m._fw) payload.fw = m._fw;
      if (wsSend({type: "edit", id: m.id, e2e: await sealFor(ctx, payload)})) cancelEdit();
    } else {
      const payload = {t: text};
      if (S.replying) payload.r = S.replying;
      pend = Pend.add(S.active, {kind: "text", text});
      inp.value = ""; cancelReply(); autosize(); inp.focus(); Typing.stop();
      Pend.go(pend, async p => withTarget({type: "send", cid: p.cid, e2e: await sealFor(await keyForTarget(p.target), payload)}, p.target));
    }
  } catch (err) {
    toast(err.message, "error");
    if (pend) Pend.wait(pend);
  }
  S.sending = false;
}

const TYPING_TXT = {text: "yozmoqda", file: "fayl yubormoqda", emoji: "emoji tanlamoqda", voice: "ovozli xabar yozmoqda", vnote: "dumaloq video yozmoqda"};
const TYPING_RANK = {emoji: 1, text: 2, file: 3, voice: 4, vnote: 5};
const TYPING_TTL = 6000, TYPING_BEAT = 2500;
const TY = {seen: new Map(), cur: {kind: "", at: 0, key: ""}, tick: 0, paint: 0};

function lastSeenText(u) {
  const ts = u && u.last_seen;
  if (u && u.seen_hidden && !(S.me && u.id === S.me.id)) return "yaqinda onlayn bo'lgan";
  if (!ts) return "oflayn";
  const now = Date.now() / 1000;
  if (now - ts < 60) return "last seen hozirgina";
  if (dayKey(ts) === dayKey(now)) return "last seen bugun " + hhmm(ts);
  const y = new Date(); y.setDate(y.getDate() - 1);
  if (dayKey(ts) === dayKey(y / 1000)) return "last seen kecha " + hhmm(ts);
  const d = new Date(ts * 1000);
  return "last seen " + pad2(d.getDate()) + "." + pad2(d.getMonth() + 1) + "." + String(d.getFullYear()).slice(2) + " " + hhmm(ts);
}
function tyKeyOf(t) { return !t ? "" : t.kind === "group" ? "g" : t.kind === "dm" ? "d" + t.uid : ""; }
function typingNow(key) {
  const mp = TY.seen.get(key); if (!mp) return [];
  const t = Date.now(), out = [];
  mp.forEach((v, uid) => { if (v.until > t) out.push({uid, kind: v.kind}); else mp.delete(uid); });
  return out;
}
function typingLabel(key) {
  const list = typingNow(key); if (!list.length) return "";
  const top = list.reduce((a, b) => (TYPING_RANK[b.kind] || 0) > (TYPING_RANK[a.kind] || 0) ? b : a);
  if (key[0] === "d") return TYPING_TXT[top.kind] || "yozmoqda";
  const names = list.map(x => (U(x.uid).nickname || "Kimdir"));
  if (list.length === 1) return names[0] + " " + (TYPING_TXT[top.kind] || "yozmoqda");
  const same = list.every(x => x.kind === top.kind);
  return (list.length === 2 ? names[0] + " va " + names[1] : list.length + " kishi") + " " + (same ? (TYPING_TXT[top.kind] || "yozmoqda") : "yozmoqda");
}
function typingRepaint() {
  if (TY.paint) return;
  TY.paint = setTimeout(() => { TY.paint = 0; if (!S.me) return; try { renderHeader(); renderList(); } catch (_) {} }, 120);
}
function typingSchedule() {
  clearTimeout(TY.tick);
  let next = Infinity; const t = Date.now();
  TY.seen.forEach(mp => mp.forEach(v => { if (v.until > t) next = Math.min(next, v.until); }));
  if (next < Infinity) TY.tick = setTimeout(() => { typingRepaint(); typingSchedule(); }, Math.max(50, next - t + 30));
}
function onTyping(m) {
  if (!S.me || m.uid === S.me.id) return;
  const key = m.group ? "g" : "d" + m.uid;
  let mp = TY.seen.get(key); if (!mp) TY.seen.set(key, mp = new Map());
  if (m.kind === "stop") mp.delete(m.uid); else if (TYPING_TXT[m.kind]) mp.set(m.uid, {kind: m.kind, until: Date.now() + TYPING_TTL});
  typingRepaint(); typingSchedule();
}
function typingClearFrom(uid) {
  let hit = false; TY.seen.forEach(mp => { if (mp.delete(uid)) hit = true; });
  if (hit) typingRepaint();
}
function typingReset() { TY.seen.clear(); clearTimeout(TY.tick); TY.cur = {kind: "", at: 0, key: ""}; }

const Typing = {
  send(kind) {
    const key = tyKeyOf(S.active); if (!key || !S.ws || S.ws.readyState !== 1) return;
    const c = TY.cur, now = Date.now();
    if (c.key === key && c.kind && now - c.at < TYPING_BEAT + 500) {
      if ((TYPING_RANK[kind] || 0) < (TYPING_RANK[c.kind] || 0)) return;
      if (kind === c.kind && now - c.at < TYPING_BEAT) return;
    } else if (c.key && c.key !== key) this.stop();
    TY.cur = {kind, at: now, key};
    const msg = {type: "typing", kind}; if (S.active.kind === "dm") msg.to = S.active.uid;
    wsSend(msg);
  },
  stop() {
    const c = TY.cur; if (!c.kind) return;
    TY.cur = {kind: "", at: 0, key: ""};
    if (!S.ws || S.ws.readyState !== 1) return;
    const msg = {type: "typing", kind: "stop"}; if (c.key[0] === "d") msg.to = +c.key.slice(1);
    wsSend(msg);
  },
  hold(kind) {
    this.send(kind);
    const t = setInterval(() => this.send(kind), TYPING_BEAT);
    let off = false;
    return () => { if (off) return; off = true; clearInterval(t); this.stop(); };
  },
};
inp.addEventListener("input", () => { if (S.editing) return; if (inp.value.trim()) Typing.send("text"); else Typing.stop(); });
inp.addEventListener("blur", () => { if (!inp.value.trim()) Typing.stop(); });

const Pend = {
  list: [],
  ACK_MS: 15000,
  MAKE_MS: 60000,
  q: Promise.resolve(), tick: 0,
  makeMs(p) { const sz = (p.info && p.info.size) || 0; return Math.min(330000, Pend.MAKE_MS + Math.round(sz / 20)); },
  add(target, info) {
    const p = {key: chatKey(target), target, info, stage: "enc", el: null, meta: null, timer: 0, sentAt: 0, t0: Date.now(), cid: Pend.rid(), gen: 0, busy: false, msg: null, make: null};
    p.el = Pend.build(p); Pend.list.push(p); Pend.mount(true); return p;
  },
  rid() { const a = new Uint8Array(12); crypto.getRandomValues(a); return Array.from(a, b => b.toString(16).padStart(2, "0")).join(""); },
  label(p) { return p.stage === "enc" ? "shifrlanmoqda…" : p.stage === "up" ? "yuborilmoqda…" : p.stage === "wait" ? "kutilmoqda…" : ""; },
  build(p) {
    const i = p.info, row = h("div", {class: "row mine last pending" + (p.target.kind === "group" ? "" : " dm")});
    const img = i.kind === "file" && i.isImg && i.url, cap = i.kind === "file" ? (i.text || "") : "";
    const bubble = h("div", {class: "bubble pending" + (img ? " has-img" + (cap ? "" : " img-only") : "") + (i.kind === "file" && !img ? " has-file" : "")
      + (i.kind === "voice" ? " has-file has-voice" : "") + (i.kind === "vnote" ? " has-file has-vnote vn-only" : "")});
    if (i.kind === "text") bubble.append(btextEl("btext", i.text, true));
    else if (img) {
      const pic = h("img", {alt: "", draggable: "false", decoding: "async"}), box = h("div", {class: "imgbox open pnd-imgbox"}, pic);
      box.style.aspectRatio = "1.333";
      pic.addEventListener("load", () => { if (pic.naturalWidth && pic.naturalHeight) box.style.aspectRatio = String(Math.min(2.4, Math.max(0.8, pic.naturalWidth / pic.naturalHeight))); });
      pic.src = i.url;
      bubble.append(box);
      if (cap) bubble.append(btextEl("btext", cap, true));
    } else if (i.kind === "file") {
      bubble.append(h("div", {class: "pnd-filebox"}, h("span", {class: "pnd-fico"}, icon("file", "ic pnd-fi"), h("span", {class: "pnd-ring sm", "aria-hidden": "true"})),
        h("div", {class: "pnd-finfo"}, h("b", {text: i.name || "Fayl"}), h("small", {text: i.size ? fmtSize(i.size) : ""}))));
      if (cap) bubble.append(btextEl("btext", cap, true));
    } else if (i.kind === "voice") {
      const d = Math.max(0, Math.round(i.dur || 0));
      bubble.append(h("div", {class: "vbox loading pnd-vbox"},
        h("span", {class: "vplay", "aria-hidden": "true"}, icon("play", "ic vi-play"), spinnerEl()),
        h("div", {class: "vmid"}, h("div", {class: "vtrack"}, h("div", {class: "vline"}, h("div", {class: "vfill"}))),
          h("div", {class: "vmeta"}, h("span", {class: "vtime", text: fmtDur(d)})))));
    } else {
      const vc = h("div", {class: "vnc"});
      if (i.thumb) vc.append(h("img", {class: "vnth", src: i.thumb, alt: "", draggable: "false"}));
      bubble.append(h("div", {class: "vnbox pnd-vnbox"}, vc));
    }
    p.meta = h("span", {class: "meta pnd-meta"});
    if (i.kind === "text" && bubble.querySelector(".bigemo")) {
      bubble.classList.add("has-big");
      if (bubble.querySelector(".bigemo-1")) bubble.classList.add("has-big-1");
      bubble.append(h("div", {class: "bfoot"}, p.meta));
    } else bubble.append(p.meta);
    row.append(h("div", {class: "slot"}), bubble);
    p.el = row; Pend.paint(p);
    return row;
  },
  paint(p) {
    if (!p.meta) return;
    p.meta.textContent = "";
    p.meta.append(h("span", {class: "lk ok", text: "🔒"}), " ", hhmm(Math.floor((p.t0 || (p.t0 = Date.now())) / 1000)), " ");
    if (p.stage === "sent") p.meta.append(icon("check", "ic pnd-ok"));
    else {
      p.meta.append(h("span", {class: "pnd-lbl"}, h("i", {class: "pnd-spin", "aria-hidden": "true"}), Pend.label(p)));
      if (p.info && (p.info.kind === "file" || p.stage === "wait")) p.meta.append(h("button", {class: "pnd-x", type: "button", title: "Bekor qilish", "aria-label": "Yuborishni bekor qilish",
        onclick: e => { e.stopPropagation(); Pend.cancel(p); }}, icon("close", "ic")));
    }
  },
  cancel(p) { if (!p) return; if (p.ac) { try { p.ac.abort(); } catch (_) {} } Pend.drop(p); toast("Yuborish bekor qilindi", "info"); },
  stage(p, st) { if (!p) return; p.stage = st; Pend.paint(p); },
  sent(p) {
    if (!p) return;
    clearTimeout(p.timer); p.stage = "sent"; p.sentAt = Date.now(); Pend.paint(p);
    p.timer = setTimeout(() => { if (Pend.list.includes(p) && p.stage === "sent") Pend.wait(p); }, Pend.ACK_MS);
  },
  wait(p) {
    if (!p || !Pend.list.includes(p)) return;
    clearTimeout(p.timer); p.stage = "wait"; Pend.paint(p); Pend.ticker();
  },
  fail(p) { Pend.wait(p); },
  ticker() { if (!Pend.tick) Pend.tick = setInterval(() => { if (!Pend.list.length) { clearInterval(Pend.tick); Pend.tick = 0; } else Pend.flush(); }, 3000); },
  go(p, make) { p.make = make; Pend.ticker(); return Pend.enqueue(p); },
  enqueue(p) { Pend.q = Pend.q.then(() => Pend.pump(p)).catch(() => {}); return Pend.q; },
  async pump(p) {
    if (!Pend.list.includes(p) || p.busy || (p.stage === "sent")) return;
    p.busy = true; const g = ++p.gen;
    try {
      if (!p.msg) {
        Pend.stage(p, "up");
        let tm = 0;
        const msg = await Promise.race([p.make(p), new Promise((_, rej) => { tm = setTimeout(() => rej(new Error("timeout")), Pend.makeMs(p)); })]).finally(() => clearTimeout(tm));
        if (g !== p.gen || !Pend.list.includes(p)) { p.busy = false; return; }
        p.msg = msg;
      }
      if (!wsTry(p.msg)) throw new Error("offline");
      Pend.sent(p);
    } catch (err) {
      if (err && err.final) { toast(err.message, "error"); Pend.drop(p); }
      else Pend.wait(p);
    }
    p.busy = false;
  },
  async flush() {
    if (S.offline || !S.ws || S.ws.readyState !== 1) return;
    for (const p of Pend.list.slice()) { if (p.stage === "wait" && !p.busy) await Pend.enqueue(p); if (p.stage === "wait") break; }
  },
  onClose() { Pend.list.forEach(p => { if (p.stage === "sent") Pend.wait(p); }); },
  nack(m) {
    const p = Pend.list.find(x => x.cid === m.cid); if (!p) return;
    if (m.final) Pend.drop(p);
    else Pend.wait(p);
  },
  drop(p) {
    clearTimeout(p.timer); p.gen++;
    if (p.info && p.info.url) { try { URL.revokeObjectURL(p.info.url); } catch (_) {} }
    const i = Pend.list.indexOf(p); if (i >= 0) Pend.list.splice(i, 1);
    if (p.el) p.el.remove();
  },
  mount(stick) {
    if (!S.active) return;
    const k = chatKey(S.active), mine = Pend.list.filter(p => p.key === k);
    if (!mine.length) return;
    const box = $("msgs"), blank = box.querySelector(".blank"); if (blank) blank.remove();
    mine.forEach(p => box.append(p.el));
    if (stick || box._stick) { box.scrollTop = box.scrollHeight; box._stick = true; }
  },
  settle(m) {
    const k = m.ch ? "c" + m.ch : m.to == null ? "g" : "d" + partnerOf(m);
    const isFile = !!(m.file || m.image), same = x => x.key === k && (x.info.kind === "text") === !isFile;
    const p = (m.cid && Pend.list.find(x => x.cid === m.cid)) || Pend.list.find(x => same(x) && x.stage === "sent") || Pend.list.find(x => same(x) && x.stage === "wait") || Pend.list.find(x => same(x)) || Pend.list.find(x => x.key === k && x.stage === "sent");
    if (p) Pend.drop(p);
  },
  clear() { Pend.list.slice().forEach(Pend.drop); clearInterval(Pend.tick); Pend.tick = 0; },
};
async function uploadEnc(blob, failText, signal) {
  const r = await SC.fetch("/api/e2ee/blob", {method: "POST", headers: {Authorization: "Bearer " + S.token, "Content-Type": "application/octet-stream"}, body: blob});
  const j = await r.json().catch(() => ({}));
  if (!r.ok) { const e = new Error(typeof j.detail === "string" ? j.detail : failText); e.final = r.status >= 400 && r.status < 500 && ![401, 408, 409, 423, 425, 429].includes(r.status); throw e; }
  return j.blob;
}
addEventListener("online", () => { if (Pend.list.length) { reconnectNow(); setTimeout(() => Pend.flush(), 400); } });
document.addEventListener("visibilitychange", () => { if (!document.hidden && Pend.list.length) { if (!S.ws || S.ws.readyState !== 1) reconnectNow(); Pend.flush(); } });
(function () {
  const f = SC.fetch;
  SC.fetch = function () { if (S.offline) { const e = new Error("Oflayn rejim: bu amal uchun internet kerak"); e.offline = true; return Promise.reject(e); } return f.apply(SC, arguments); };
})();

const Off = (() => {
  const DB = "tc_offline", ST = "kv", LIM = {group: 150, dm: 100, dms: 60, ch: 60, chs: 30};
  const te = new TextEncoder(), td = new TextDecoder();
  let key = null, mode = "", timer = 0, saving = false, info = null, probing = null;
  const idb = () => new Promise((res, rej) => {
    if (!window.indexedDB || !crypto || !crypto.subtle) return rej(new Error("IndexedDB yo'q"));
    const r = indexedDB.open(DB, 1);
    r.onupgradeneeded = () => r.result.createObjectStore(ST);
    r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
  });
  const run = (m, fn) => idb().then(db => new Promise((res, rej) => {
    const tx = db.transaction(ST, m), st = tx.objectStore(ST), rq = fn(st);
    tx.oncomplete = () => { db.close(); res(rq && rq.result); }; tx.onerror = tx.onabort = () => { db.close(); rej(tx.error); };
  }));
  const get = k => run("readonly", st => st.get(k)), set = (k, v) => run("readwrite", st => st.put(v, k)), del = k => run("readwrite", st => st.delete(k));
  async function pwKey(pass, salt) {
    const base = await crypto.subtle.importKey("raw", te.encode(pass), "PBKDF2", false, ["deriveKey"]);
    return crypto.subtle.deriveKey({name: "PBKDF2", hash: "SHA-256", salt, iterations: 200000}, base, {name: "AES-GCM", length: 256}, false, ["encrypt", "decrypt"]);
  }
  async function stayKey(create) {
    let k = null; try { k = await get("stayKey"); } catch (_) {}
    if (!k && create) { k = await crypto.subtle.generateKey({name: "AES-GCM", length: 256}, false, ["encrypt", "decrypt"]); await set("stayKey", k); }
    return k;
  }
  const tail = (a, n) => a.length > n ? a.slice(a.length - n) : a;
  const plain = (k, v) => (typeof v === "function" || (v && v.nodeType)) ? undefined : v;
  function slimMsgs(list) { return list.filter(m => m && !m.service && m.user).map(m => Object.assign({}, m, {user: m.user.id})); }
  function build() {
    const dms = [...S.dms.entries()].filter(([, d]) => d.msgs.length).sort((a, b) => (b[1].msgs.at(-1).ts || 0) - (a[1].msgs.at(-1).ts || 0)).slice(0, LIM.dms);
    const chs = [...S.chn.entries()].filter(([, c]) => c.msgs.length).slice(0, LIM.chs);
    return {
      v: 1, ts: Date.now(), me: S.me, chat: S.chat, chList: S.chList, members: S.members,
      users: [...S.users.values()].filter(u => u && u.id != null),
      group: {msgs: slimMsgs(tail(S.group.msgs, LIM.group)), more: !!S.group.more},
      dms: dms.map(([uid, d]) => [uid, slimMsgs(tail(d.msgs, LIM.dm)), !!d.more]),
      chn: chs.map(([id, c]) => [id, slimMsgs(tail(c.msgs, LIM.ch)), !!c.more]),
    };
  }
  async function save() {
    timer = 0;
    if (!key || !S.me || S.offline || saving || !S.token) return;
    saving = true;
    try {
      const iv = crypto.getRandomValues(new Uint8Array(12));
      const data = await crypto.subtle.encrypt({name: "AES-GCM", iv}, key, te.encode(JSON.stringify(build(), plain)));
      await set("snap", {v: 1, mode, user: String(S.me.username || "").toLowerCase(), nick: S.me.nickname, ts: Date.now(), iv, data});
      info = {mode, user: String(S.me.username || "").toLowerCase(), ts: Date.now()}; lastSig = sig(); lastAt = Date.now(); showBtn();
    } catch (_) {}
    saving = false;
  }
  let lastSig = "", lastAt = 0;
  const sig = () => {
    let g = S.group.msgs.length + ":" + ((S.group.msgs[S.group.msgs.length - 1] || {}).id) + "|" + S.users.size + "|" + S.members.length;
    S.dms.forEach((d, k) => { g += "," + k + ":" + d.msgs.length + ":" + ((d.msgs[d.msgs.length - 1] || {}).id); });
    return g;
  };
  const dirty = () => {
    if (!key || S.offline || timer) return;
    const now = Date.now(); if (sig() === lastSig && now - lastAt < 300000) return;
    timer = setTimeout(save, Math.max(4000, 20000 - (now - lastAt)));
  };
  const flush = () => { if (!key || S.offline || !S.me) return; clearTimeout(timer); timer = 0; if (sig() !== lastSig || Date.now() - lastAt > 60000) save(); };
  async function arm({user, password, stay}) {
    try {
      if (stay) { key = await stayKey(true); mode = "stay"; try { await del("meta"); } catch (_) {} }
      else {
        let meta = null; try { meta = await get("meta"); } catch (_) {}
        const same = meta && meta.user === String(user).toLowerCase() && meta.salt;
        const salt = same ? meta.salt : crypto.getRandomValues(new Uint8Array(16));
        if (!same) { try { await del("snap"); } catch (_) {} }
        key = await pwKey(password, salt); mode = "pw";
        await set("meta", {user: String(user).toLowerCase(), salt});
        try { await del("stayKey"); } catch (_) {}
      }
      dirty();
    } catch (_) { key = null; }
  }
  async function armStay() {
    try { key = await stayKey(true); mode = "stay"; try { await del("meta"); } catch (_) {} dirty(); } catch (_) { key = null; }
  }
  async function disarmStay() {
    if (mode === "stay") { key = null; mode = ""; }
    try { const r = await get("snap"); await del("stayKey"); if (r && r.mode === "stay") { await del("snap"); info = null; } } catch (_) {}
    showBtn();
  }
  async function wipe() { key = null; mode = ""; info = null; clearTimeout(timer); timer = 0; try { await del("snap"); await del("meta"); await del("stayKey"); } catch (_) {} showBtn(); }
  async function probe() {
    try { const r = await get("snap"); info = r ? {mode: r.mode, user: r.user, ts: r.ts} : null; } catch (_) { info = null; }
    showBtn();
  }
  const ago = ts => { const m = Math.max(0, Math.round((Date.now() - ts) / 60000)); return m < 1 ? "hozirgina" : m < 60 ? m + " daqiqa oldin" : m < 1440 ? Math.round(m / 60) + " soat oldin" : Math.round(m / 1440) + " kun oldin"; };
  function showBtn() { const b = $("offBtn"); if (b) { b.classList.toggle("hidden", !info); b.querySelector("span").textContent = info && info.mode === "pw" ? "Oflayn ko'rish (parol kerak)" : "Oflayn ko'rish"; } }

  async function open() {
    const err = $("autherr"); err.textContent = "";
    let rec = null; try { rec = await get("snap"); } catch (_) {}
    if (!rec) { err.textContent = "Oflayn xotira yo'q: avval internet bilan bir marta kiring."; return; }
    let k = null;
    try {
      if (rec.mode === "stay") k = await stayKey(false);
      else {
        const user = $("f_user").value.trim().replace(/^@/, "").toLowerCase(), pass = $("f_pass").value;
        if (!pass) { err.textContent = "Oflayn ochish uchun parolni kiriting (xabarlar parol bilan shifrlangan)."; return; }
        if (user && user !== rec.user) { err.textContent = "Bu qurilmadagi oflayn xotira boshqa akkauntniki."; return; }
        const meta = await get("meta");
        if (!meta || !meta.salt) { err.textContent = "Oflayn xotira buzilgan. Internet bilan qayta kiring."; return; }
        err.textContent = "Ochilmoqda…"; await new Promise(r => setTimeout(r, 30));
        k = await pwKey(pass, meta.salt);
      }
      if (!k) throw new Error("kalit yo'q");
      const snap = JSON.parse(td.decode(await crypto.subtle.decrypt({name: "AES-GCM", iv: rec.iv}, k, rec.data)));
      apply(snap, rec);
    } catch (_) { err.textContent = rec.mode === "pw" ? "Parol noto'g'ri yoki oflayn xotira buzilgan." : "Oflayn xotirani ochib bo'lmadi. Internet bilan kiring."; }
  }
  function apply(snap, rec) {
    resetState(); S.offline = true; S.token = null;
    S.me = snap.me; snap.users.forEach(u => S.users.set(u.id, u)); upsertUser(snap.me);
    S.members = snap.members || []; S.chat = snap.chat || {slowmode: 0, locked: false};
    const back = list => list.map(m => Object.assign(m, {user: S.users.get(m.user) || U(m.user)}));
    S.group.msgs = back(snap.group.msgs); S.group.more = false; S.chList = [];
    snap.dms.forEach(([uid, msgs]) => { const d = dmOf(uid); d.msgs = back(msgs); d.loaded = true; d.more = false; d.last = d.msgs[d.msgs.length - 1] || null; });
    $("auth").classList.add("hidden"); $("app").classList.remove("hidden");
    document.querySelectorAll(".tabs button").forEach(x => x.classList.toggle("on", x.dataset.tab === "chats"));
    $("chat").classList.add("hidden"); $("empty").classList.remove("hidden");
    document.body.classList.add("offline-mode");
    const cb = $("connbar"); cb.textContent = "📴 Oflayn rejim — faqat o'qish • oxirgi yangilanish: " + fmtDT(Math.floor((snap.ts || rec.ts) / 1000)); cb.classList.remove("hidden");
    const sub = $("obSub"); if (sub) sub.textContent = "Xabar yozish uchun internet kerak • nusxa " + ago(snap.ts || rec.ts);
    $("f_pass").value = ""; renderList();
    if (!isMobile()) openChat({kind: "group"});
  }
  function leave() {
    if (!S.offline) return;
    S.offline = false; document.body.classList.remove("offline-mode"); $("chat").classList.remove("offline"); $("connbar").textContent = "Ulanmoqda…";
    let tok = ""; try { tok = localStorage.getItem(LS_STAY) || ""; } catch (_) {}
    if (tok) { closeChat(); resumeStay(tok, 0); } else showAuth("Internet qaytdi. Yangilash uchun qayta kiring.");
  }
  addEventListener("online", () => { if (S.offline) setTimeout(leave, 600); });
  document.addEventListener("visibilitychange", () => { if (document.hidden) flush(); });
  addEventListener("pagehide", flush);
  $("offBtn").addEventListener("click", open);
  const retryBtn = $("obRetry");
  if (retryBtn) retryBtn.addEventListener("click", () => {
    if (!S.offline) return;
    if (navigator.onLine === false) { toast("Internet hali yo'q", "warn"); return; }
    toast("Ulanmoqda…", "info"); leave();
  });
  const chessBtn = $("obChess"); if (chessBtn) chessBtn.addEventListener("click", () => { S.tab = "games"; document.querySelectorAll(".tabs button").forEach(x => x.classList.toggle("on", x.dataset.tab === "games")); try { renderList(); } catch (_) {} });
  probing = probe();
  return {arm, armStay, disarmStay, wipe, dirty, probe, open, leave, save, ready: () => probing, get info() { return info; }};
})();

const HOLD_MS = 260, CANCEL_DX = 90, LOCK_DY = 70;
const micEl = $("micBtn");
const vibrate = ms => { try { if (navigator.vibrate) navigator.vibrate(ms); } catch (_) {} };
try { S.recMode = localStorage.getItem("tc_recmode") === "video" ? "video" : "voice"; } catch (_) {}
function applyRecMode() {
  const v = S.recMode === "video";
  $("composer").classList.toggle("mode-video", v);
  micEl.setAttribute("aria-label", v ? "Dumaloq video xabar" : "Ovozli xabar");
  micEl.title = v ? "Dumaloq video: bosib turing — yozish, qo'yib yuboring — yuborish. Bir marta bosing — ovozga qaytadi"
                  : "Ovozli xabar: bosib turing — yozish, qo'yib yuboring — yuborish. Bir marta bosing — videoga o'tadi";
}
function toggleRecMode() {
  S.recMode = S.recMode === "video" ? "voice" : "video";
  try { localStorage.setItem("tc_recmode", S.recMode); } catch (_) {}
  applyRecMode(); vibrate(10);
  toast(S.recMode === "video" ? "📹 Dumaloq video — yozish uchun tugmani bosib turing" : "🎤 Ovozli xabar — yozish uchun tugmani bosib turing", "info");
}
applyRecMode();

function resetDragUi() { $("recLock").style.transform = ""; $("recbar").style.transform = ""; $("composer").classList.remove("rec-near-cancel", "rec-near-lock"); }
function showVnUi(on, hint) {
  const ov = $("vnov");
  if (!on) { ov.classList.add("hidden"); ov.setAttribute("aria-hidden", "true"); return; }
  const r = $("msgs").getBoundingClientRect();
  Object.assign(ov.style, {left: r.left + "px", top: r.top + "px", width: r.width + "px", height: r.height + "px"});
  ov.style.setProperty("--vnd", Math.round(Math.max(140, Math.min(340, r.width * 0.8, r.height - 96))) + "px");
  $("vnHint").textContent = hint || "";
  ov.classList.remove("hidden"); ov.setAttribute("aria-hidden", "false");
}
function setRecUi(mode) {
  const c = $("composer"), vid = S.recKind === "video", on = mode !== "off";
  c.classList.toggle("recording", on); c.classList.toggle("rec-hold", mode === "hold");
  c.classList.toggle("rec-lock", mode === "lock" || mode === "busy"); c.classList.toggle("rec-busy", mode === "busy");
  c.classList.toggle("rec-video", on && vid);
  micEl.classList.toggle("on", mode === "hold" || mode === "lock"); micEl.disabled = mode === "busy"; $("recCancel").disabled = mode === "busy";
  micEl.setAttribute("aria-label", mode === "lock" ? "Yuborish" : mode === "off" ? (S.recMode === "video" ? "Dumaloq video xabar" : "Ovozli xabar") : "Yozilmoqda");
  $("recLbl").textContent = mode === "hold" ? "‹ Bekor qilish uchun chapga suring" : mode === "busy" ? (vid ? "Video tayyorlanmoqda…" : "Ovoz tayyorlanmoqda…")
    : mode === "lock" ? (vid ? "Video shifrlanib yuboriladi" : "Ovoz o'zgartirilib shifrlanadi") : "";
  if (mode === "hold" || mode === "lock") { if (!S.recTyping) S.recTyping = Typing.hold(vid ? "vnote" : "voice"); }
  else if (S.recTyping) { S.recTyping(); S.recTyping = null; }
  if (mode !== "hold") resetDragUi();
  if (mode === "off") { $("recTime").textContent = "0:00"; $("vnProg").setAttribute("stroke-dashoffset", "301.6"); }
  showVnUi(vid && (mode === "hold" || mode === "lock"), mode === "hold" ? "↑ qulflash   ← bekor qilish" : mode === "lock" && S.rec && S.rec.canFlip ? "Doirani bosing — old/orqa kamera" : "");
}
function cancelRecording() {
  if (S.starting) S.startAbort = true;
  if (!S.rec || S.recBusy) return;
  const r = S.rec; S.rec = null; clearInterval(S.recTimer);
  Promise.resolve(r.cancel()).catch(() => {}); setRecUi("off");
}
function tickRec() {
  const r = S.rec; if (!r) return;
  const t = r.elapsed(); $("recTime").textContent = fmtDur(t);
  if (S.recKind === "video") $("vnProg").setAttribute("stroke-dashoffset", String(301.6 * (1 - Math.min(1, t / VNote.MAX_SEC))));
}
async function startRecording(kind) {
  if (S.rec || S.recBusy || S.sending || S.starting || !S.active) return false;
  if (S.editing || S.pendingImg || inp.value.trim()) return false;
  if (S.active.kind === "group" && S.chat.locked && !amAdmin()) { toast("Umumiy chat qulflangan", "error"); return false; }
  if (S.active.kind === "dm" && U(S.active.uid).deleted) { toast("Bu akkaunt o'chirilgan. Xabar yuborib bo'lmaydi", "error"); return false; }
  const at = S.active, video = kind === "video"; let rec = null;
  S.starting = true; S.startAbort = false; S.recKind = kind;
  if (video) { $("vnov").classList.add("front"); $("vnov").classList.remove("can-flip"); showVnUi(true, "Kamera ochilmoqda…"); }
  try {
    const cb = {
      onLimit: () => { toast(video ? "Video 1 daqiqaga yetdi, yuborilmoqda" : "Yozuv " + Math.round(Voice.MAX_SEC / 60) + " daqiqaga yetdi, yuborilmoqda", "warn"); finishRecording(); },
      onLost: () => { if (rec && S.rec === rec) { cancelRecording(); toast(video ? "Kamera yoki mikrofon uzildi, yozuv bekor qilindi" : "Mikrofon uzildi, yozuv bekor qilindi", "error"); } },
    };
    rec = video ? await VNote.record(Object.assign({facing: S.vfacing, preview: $("vnPrev")}, cb)) : await Voice.record(cb);
    if (S.startAbort || S.active !== at) { Promise.resolve(rec.cancel()).catch(() => {}); rec = null; showVnUi(false); return false; }
    S.rec = rec;
    if (video) { $("vnov").classList.toggle("front", rec.facing() === "user"); $("vnov").classList.toggle("can-flip", !!rec.canFlip); }
    S.recTimer = setInterval(tickRec, video ? 100 : 250);
    vibrate(20);
    return true;
  } catch (err) { showVnUi(false); toast(err.message || (video ? "Kamerani ochib bo'lmadi" : "Mikrofonni ochib bo'lmadi"), "error"); return false; }
  finally { S.starting = false; }
}
async function flipCamera() {
  const r = S.rec;
  if (!r || S.recKind !== "video" || S.recBusy || S.flipping || !r.canFlip) return;
  S.flipping = true; const st = $("vnStage"); st.classList.add("flipping");
  try {
    const ok = await r.flip();
    if (S.rec !== r) return;
    $("vnov").classList.toggle("front", r.facing() === "user"); S.vfacing = r.facing() === "environment" ? "environment" : "user";
    if (!ok) toast("Kamerani almashtirib bo'lmadi", "warn");
  } finally { st.classList.remove("flipping"); S.flipping = false; }
}
$("vnStage").addEventListener("click", flipCamera);

function sendEncryptedFile(target, e, f, failText, pend) {
  const reply = S.replying; cancelReply();
  Pend.go(pend, async p => {
    if (!p.blobName) p.blobName = await uploadEnc(e.blob, failText);
    const payload = {t: "", f}; if (reply) payload.r = reply;
    return withTarget({type: "send", cid: p.cid, e2e: await sealFor(await keyForTarget(p.target), payload), blob: p.blobName}, p.target);
  });
}
async function sendVoice(wav, dur) {
  const target = S.active, pend = Pend.add(target, {kind: "voice", size: wav.size, dur});
  try {
    const raw = new Uint8Array(await wav.arrayBuffer());
    const e = await E2E.encryptFile(raw);
    const meta = {name: "ovozli-xabar.wav", mime: "audio/wav", size: wav.size, img: false, k: e.key, vo: 1, d: Math.round(dur * 10) / 10};
    const wf = wfFromWav(raw); if (wf) meta.wf = wf;
    sendEncryptedFile(target, e, meta, "Ovoz yuklanmadi", pend);
  } catch (err) { Pend.drop(pend); throw err; }
}
async function sendVideoNote(out, wav, dur) {
  const target = S.active, pend = Pend.add(target, {kind: "vnote", thumb: out.thumb && THUMB_RE.test(out.thumb) ? out.thumb : null});
  try {
    const packed = VNote.pack(new Uint8Array(await out.video.arrayBuffer()), wav ? new Uint8Array(await wav.arrayBuffer()) : null);
    const e = await E2E.encryptFile(packed);
    const f = {name: "video-xabar.vn", mime: out.mime, size: packed.length, img: false, k: e.key, rv: 1, d: Math.round(dur * 10) / 10};
    if (out.thumb && THUMB_RE.test(out.thumb)) f.th = out.thumb;
    sendEncryptedFile(target, e, f, "Video yuklanmadi", pend);
  } catch (err) { Pend.drop(pend); throw err; }
}
async function finishRecording() {
  const rec = S.rec; if (!rec || S.recBusy) return;
  const kind = S.recKind;
  S.recBusy = true; S.sending = true; clearInterval(S.recTimer); setRecUi("busy");
  const at = S.active;
  try {
    if (kind === "video") {
      const out = await rec.stop();
      if (!out) throw new Error("Yozuv olinmadi");
      if (out.duration < VNote.MIN_SEC) { toast("Video juda qisqa — yuborilmadi", "warn"); return; }
      let wav = null, dur = out.duration;
      if (out.audio) {
        const d = await Voice.disguise(out.audio);
        out.audio = null;
        if (!d) { toast("Video juda qisqa — yuborilmadi", "warn"); return; }
        wav = d.wav; dur = d.duration;
      }
      if (S.active !== at) { toast("Chat almashtirildi — video xabar yuborilmadi", "warn"); return; }
      await sendVideoNote(out, wav, dur);
    } else {
      const raw = await rec.stop();
      if (!raw) throw new Error("Yozuv olinmadi");
      const out = await Voice.disguise(raw);
      if (!out) { toast("Ovoz juda qisqa — yuborilmadi", "warn"); return; }
      if (S.active !== at) { toast("Chat almashtirildi — ovozli xabar yuborilmadi", "warn"); return; }
      await sendVoice(out.wav, out.duration);
    }
  } catch (err) { toast(err.message || (kind === "video" ? "Video xabar yuborilmadi" : "Ovozli xabar yuborilmadi"), "error"); }
  finally { S.rec = null; S.recBusy = false; S.sending = false; setRecUi("off"); syncSend(); }
}

let G = null;
const noClick = () => { S.noClickUntil = Date.now() + 350; };
async function beginHold(g) {
  if (G !== g || g.aborted) return;
  g.started = true;
  const t0 = performance.now();
  const ok = await startRecording(S.recMode);
  if (!ok) { if (G === g) G = null; return; }
  if (g.released || g.cancelled) {
    cancelRecording();
    if (performance.now() - t0 > 700) toast("Ruxsat berildi. Endi tugmani bosib turing", "ok");
    return;
  }
  setRecUi(g.locked || performance.now() - t0 > 700 ? "lock" : "hold");
}
function endPress(e, cancel) {
  const g = G; if (!g || e.pointerId !== g.id) return;
  G = null; clearTimeout(g.timer); g.timer = 0;
  try { micEl.releasePointerCapture(g.id); } catch (_) {}
  noClick();
  if (!g.started) { if (!g.aborted && !cancel) toggleRecMode(); return; }
  g.released = true;
  if (g.cancelled || g.locked) return;
  if (S.rec && !S.recBusy) {
    if (cancel) cancelRecording();
    else if (S.rec.elapsed() < 0.5) { cancelRecording(); toast("Yozish uchun tugmani bosib turing", "warn"); }
    else finishRecording();
  }
}
micEl.addEventListener("pointerdown", e => {
  if (G && !S.starting && !S.rec) G = null;
  if ((e.pointerType === "mouse" && e.button !== 0) || G || S.recBusy || S.rec || S.starting) return;
  const g = G = {id: e.pointerId, x0: e.clientX, y0: e.clientY, started: false, released: false, locked: false, cancelled: false, aborted: false, timer: 0};
  try { micEl.setPointerCapture(e.pointerId); } catch (_) {}
  g.timer = setTimeout(() => { g.timer = 0; beginHold(g); }, HOLD_MS);
});
micEl.addEventListener("pointermove", e => {
  const g = G; if (!g || e.pointerId !== g.id) return;
  const dx = e.clientX - g.x0, dy = e.clientY - g.y0;
  if (!g.started) { if (g.timer && Math.hypot(dx, dy) > 16) { clearTimeout(g.timer); g.timer = 0; g.aborted = true; } return; }
  if (!S.rec || S.recBusy || g.locked || g.cancelled) return;
  const c = $("composer");
  c.classList.toggle("rec-near-cancel", dx < -CANCEL_DX * 0.6); c.classList.toggle("rec-near-lock", dy < -LOCK_DY * 0.6);
  $("recbar").style.transform = "translateX(" + Math.max(-110, Math.min(0, dx * 0.7)) + "px)";
  $("recLock").style.transform = "translateY(" + Math.max(-30, Math.min(0, dy * 0.45)) + "px)";
  if (dx < -CANCEL_DX) { g.cancelled = true; vibrate(15); cancelRecording(); }
  else if (dy < -LOCK_DY) { g.locked = true; vibrate(20); setRecUi("lock"); }
});
micEl.addEventListener("pointerup", e => endPress(e, false));
micEl.addEventListener("pointercancel", e => endPress(e, true));
micEl.addEventListener("lostpointercapture", e => endPress(e, true));
micEl.addEventListener("contextmenu", e => e.preventDefault());
micEl.addEventListener("click", e => {
  if (Date.now() < S.noClickUntil) return;
  if (S.rec) { if (!S.recBusy) finishRecording(); return; }
  if (e.detail === 0 && !S.starting) startRecording(S.recMode).then(ok => { if (ok) setRecUi("lock"); });
});
micEl.addEventListener("keydown", e => { if (!S.rec && (e.key === "ArrowLeft" || e.key === "ArrowRight")) { e.preventDefault(); toggleRecMode(); } });
$("recCancel").addEventListener("click", cancelRecording);
document.addEventListener("keydown", e => { if (e.key === "Escape" && S.rec && !S.recBusy) { e.preventDefault(); e.stopPropagation(); cancelRecording(); } }, true);
document.addEventListener("visibilitychange", () => { if (document.hidden && S.rec && !S.recBusy) { cancelRecording(); toast("Ilovadan chiqilgani uchun yozuv bekor qilindi", "warn"); } });
addEventListener("pagehide", cancelRecording);
document.addEventListener("visibilitychange", () => {
  if (!document.hidden && S.active && S.active.kind === "dm") {
    const dm = dmOf(S.active.uid);
    if (dm.unread) { dm.unread = 0; wsSend({type: "read", with: S.active.uid}); renderList(); }
  }
});

function askDialog({title, text, okText = "OK", cancelText = "Bekor qilish", danger = false, input = null, alertOnly = false, check = null}) {
  return new Promise(resolve => {
    const root = $("dlg"), prevFocus = document.activeElement;
    let field = null, cb = null;
    const done = v => {
      if (done.d) return; done.d = true; S.dlgCancel = null; navPop("dlg");
      root.classList.add("hidden"); root.setAttribute("aria-hidden", "true"); root.textContent = "";
      document.removeEventListener("keydown", onKey, true);
      if (prevFocus && prevFocus.focus) try { prevFocus.focus(); } catch (_) {}
      resolve(v);
    };
    const ok = () => done(input ? field.value : check ? {checked: !!(cb && cb.checked)} : true);
    const cancel = () => done(input ? null : false);
    const onKey = e => {
      if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); cancel(); }
      else if (e.key === "Enter" && !(e.target && e.target.tagName === "BUTTON")) { e.preventDefault(); e.stopPropagation(); ok(); }
    };
    const card = h("div", {class: "dlg-card", role: alertOnly ? "alertdialog" : "dialog", "aria-modal": "true"});
    if (title) card.append(h("h3", {class: "dlg-t", text: title}));
    if (text) card.append(h("p", {class: "dlg-m", text}));
    if (input) { field = h("input", {class: "dlg-in", type: input.type || "text", autocomplete: "off", spellcheck: "false", placeholder: input.placeholder || ""}); field.value = input.value || ""; card.append(field); }
    if (check) { cb = h("input", {type: "checkbox", class: "dlg-cb-i"}); cb.checked = !!check.checked; card.append(h("label", {class: "dlg-cb"}, cb, h("span", {text: check.label}))); }
    const btns = h("div", {class: "dlg-b"});
    if (!alertOnly) btns.append(h("button", {class: "dlg-btn", type: "button", text: cancelText, onclick: cancel}));
    const okBtn = h("button", {class: "dlg-btn" + (danger ? " danger" : ""), type: "button", text: okText, onclick: ok});
    btns.append(okBtn); card.append(btns);
    root.textContent = ""; root.append(card);
    root.onmousedown = root.onclick = e => { if (e.target === root) cancel(); };
    root.classList.remove("hidden"); root.setAttribute("aria-hidden", "false");
    S.dlgCancel = cancel; navPush("dlg");
    document.addEventListener("keydown", onKey, true);
    setTimeout(() => { (field || okBtn).focus(); if (field) field.select(); }, 30);
  });
}
const confirmDlg = (text, o = {}) => askDialog({title: o.title, text, okText: o.okText || "OK", danger: !!o.danger});
const promptDlg = (title, text, value = "", o = {}) => askDialog({title, text, input: {value, placeholder: o.placeholder, type: o.type}, okText: o.okText || "OK", danger: !!o.danger});

document.addEventListener("contextmenu", e => {
  if (e.target.closest && e.target.closest("input, textarea")) return;
  e.preventDefault();
  if (!e.target.closest(".bubble")) closeCtx();
});

function showModal(node) {
  const sheet = $("sheet"), top = sheet.scrollTop;
  sheet.textContent = ""; sheet.append(node);
  $("modal").classList.remove("hidden");
  sheet.scrollTop = top;
}
function openModal(build, live, wide, fit) { if ($("modal").classList.contains("hidden")) navPush("modal"); S.modal = {build, live: !!live, at: performance.now()}; $("sheet").classList.toggle("wide", !!wide); $("sheet").classList.toggle("fit", !!fit); $("sheet").classList.remove("tgp"); showModal(build()); }
function closeModal() { const was = !$("modal").classList.contains("hidden"); S.modal = null; clearTimeout(_rmTimer); _rmTimer = 0; $("modal").classList.add("hidden"); $("sheet").classList.remove("wide", "fit", "tgp"); $("sheet").textContent = ""; if (was) navPop("modal"); }

let _rmTimer = 0;
function refreshModal() {
  refreshPages();
  if (!S.modal || !S.modal.live) return;
  if (_rmTimer) return;
  const wait = Math.max(150, 450 - (performance.now() - S.modal.at));
  _rmTimer = setTimeout(() => { _rmTimer = 0; if (S.modal && S.modal.live) requestAnimationFrame(() => { if (S.modal && S.modal.live) showModal(S.modal.build()); }); }, wait);
}
$("modal").addEventListener("mousedown", e => { if (e.target === $("modal")) closeModal(); });
$("modal").addEventListener("click", e => { if (e.target === $("modal")) closeModal(); });
function setPageZoom(on) {
  const v = document.querySelector('meta[name="viewport"]'); if (!v) return;
  v.setAttribute("content", "width=device-width, initial-scale=1, viewport-fit=cover, interactive-widget=resizes-content" + (on ? "" : ", maximum-scale=1, user-scalable=no"));
}
["gesturestart", "gesturechange", "gestureend"].forEach(t => document.addEventListener(t, e => { if (!e.target.closest || !e.target.closest("#lightbox")) e.preventDefault(); }, {passive: false}));
document.addEventListener("dblclick", e => { if (e.target.closest && e.target.closest(".modal,.dlg,.sheet,.ctx")) e.preventDefault(); });
function openLightbox(url) { setPageZoom(true); $("lbImg").src = url; $("lightbox").classList.remove("hidden"); navPush("lb"); }
function closeLightbox() { setPageZoom(false); const was = !$("lightbox").classList.contains("hidden"); $("lightbox").classList.add("hidden"); $("lbImg").removeAttribute("src"); if (was) navPop("lb"); }
$("lightbox").addEventListener("click", closeLightbox);

const AVV = {el: null, closing: false, uid: null, g: null};
const AV_EASE = "cubic-bezier(.22,.9,.28,1)";
function zoomAvatar(el, u) {
  if (!u.avatar) return el;
  el.classList.add("av-zoom"); el.dataset.uid = String(u.id);
  el.setAttribute("role", "button"); el.tabIndex = 0; el.setAttribute("aria-label", "Profil rasmini kattalashtirish");
  el.addEventListener("click", e => { e.stopPropagation(); openAvatarViewer(el, u); });
  el.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); openAvatarViewer(el, u); } });
  return el;
}
function avSource(uid) {
  const pg = PG.list[PG.list.length - 1];
  return (pg ? pg.el : document).querySelector('.av-zoom[data-uid="' + uid + '"]');
}
const avReduce = () => matchMedia("(prefers-reduced-motion: reduce)").matches || document.documentElement.classList.contains("no-ui-anim");
function avFrom(g, sr) {
  return "translate(" + (sr.left - g.fx) + "px," + (sr.top - g.fy) + "px) scale(" + (sr.width / g.side) + ")";
}
function openAvatarViewer(src, u) {
  if (AVV.el || !u.avatar) return;
  const vv = window.visualViewport, vw = Math.round(vv ? vv.width : innerWidth), vh = Math.round(vv ? vv.height : innerHeight);
  const mobile = vw <= 600, side = Math.round(Math.min(vw, vh * (mobile ? 0.8 : 0.78), 560));
  const g = {side, fx: Math.round((vw - side) / 2), fy: Math.round((vh - side) / 2 - (mobile ? 0 : 10)), endR: mobile ? "0%" : "3%"};
  const sr = src.getBoundingClientRect(), reduce = avReduce();
  const back = h("div", {class: "avv-back"});
  const img = h("img", {src: u.avatar, alt: "", draggable: "false", decoding: "async"});
  const box = h("div", {class: "avv-box"}, img);
  box.style.left = g.fx + "px"; box.style.top = g.fy + "px"; box.style.width = side + "px"; box.style.height = side + "px"; box.style.borderRadius = g.endR; box.style.transformOrigin = "0 0";
  const xb = h("button", {class: "avv-x", type: "button", "aria-label": "Yopish"}, icon("close"));
  const top = h("div", {class: "avv-top"}, h("div", {class: "avv-cap"}, h("b", {text: u.nickname || "@" + u.username}), h("small", {text: "@" + u.username + " • " + statusText(u)})), xb);
  const root = h("div", {class: "avv", role: "dialog", "aria-label": "Profil rasmi"}, back, box, top);
  Object.assign(AVV, {el: root, closing: false, uid: u.id, g, box, back, top});
  document.body.append(root);
  src.classList.add("av-hide");
  navPush("avv");
  if (!reduce) {
    box.animate([{transform: avFrom(g, sr), borderRadius: "50%"}, {transform: "none", borderRadius: g.endR}], {duration: 360, easing: AV_EASE});
    back.animate([{opacity: 0}, {opacity: 1}], {duration: 260, easing: "ease-out"});
    top.animate([{opacity: 0}, {opacity: 0, offset: .45}, {opacity: 1}], {duration: 420, easing: "ease-out"});
  } else back.animate([{opacity: 0}, {opacity: 1}], {duration: 120});

  let d = null;
  const dragTo = dy => {
    const k = 1 - Math.min(Math.abs(dy) / 1100, 0.22);
    box.style.transform = "translateY(" + dy + "px) scale(" + k + ")"; box.style.transformOrigin = "50% 50%";
    const o = 1 - Math.min(Math.abs(dy) / 380, 0.75); back.style.opacity = String(o); top.style.opacity = String(Math.max(0, 1 - Math.abs(dy) / 120));
  };
  root.addEventListener("pointerdown", e => {
    if (AVV.closing || e.target.closest(".avv-x") || (e.pointerType === "mouse" && e.button !== 0)) return;
    d = {y: e.clientY, t: e.timeStamp, dy: 0, moved: false, v: 0, ly: e.clientY, lt: e.timeStamp};
    try { root.setPointerCapture(e.pointerId); } catch (_) {}
  });
  root.addEventListener("pointermove", e => {
    if (!d) return;
    d.dy = e.clientY - d.y;
    if (!d.moved && Math.abs(d.dy) > 8) d.moved = true;
    const dt = e.timeStamp - d.lt; if (dt > 0) { d.v = (e.clientY - d.ly) / dt; d.ly = e.clientY; d.lt = e.timeStamp; }
    if (d.moved) dragTo(d.dy);
  });
  const end = e => {
    if (!d) return; const x = d; d = null;
    if (e.type === "pointercancel") x.moved = x.moved && Math.abs(x.dy) > 8;
    if (!x.moved) { if (e.type === "pointerup") closeAvatarViewer(); return; }
    if (Math.abs(x.dy) > 110 || Math.abs(x.v) > 0.7) { closeAvatarViewer(false, true); return; }
    const cur = box.style.transform;
    box.style.transform = ""; box.style.transformOrigin = "0 0";
    box.animate([{transform: cur, transformOrigin: "50% 50%"}, {transform: "none", transformOrigin: "50% 50%"}], {duration: 260, easing: "cubic-bezier(.3,1.35,.5,1)"});
    back.animate([{opacity: back.style.opacity || 1}, {opacity: 1}], {duration: 200}); back.style.opacity = ""; top.style.opacity = "";
  };
  root.addEventListener("pointerup", end); root.addEventListener("pointercancel", end);
  xb.addEventListener("click", e => { e.stopPropagation(); closeAvatarViewer(); });
  xb.focus({preventScroll: true});
}
function closeAvatarViewer(fromNav, dragged) {
  const root = AVV.el; if (!root || AVV.closing) return;
  AVV.closing = true;
  if (!fromNav) navPop("avv");
  const {box, back, top, g} = AVV, src = avSource(AVV.uid);
  const done = () => { root.remove(); if (AVV.el === root) { AVV.el = null; AVV.closing = false; } document.querySelectorAll(".av-hide").forEach(x => x.classList.remove("av-hide")); };
  const bo = parseFloat(back.style.opacity || "1");
  back.animate([{opacity: bo}, {opacity: 0}], {duration: 260, easing: "ease-in", fill: "forwards"});
  top.animate([{opacity: parseFloat(top.style.opacity || "1")}, {opacity: 0}], {duration: 140, fill: "forwards"});
  const sr = src ? src.getBoundingClientRect() : null, vh = innerHeight;
  const visible = sr && sr.width > 0 && sr.bottom > 0 && sr.top < vh;
  if (avReduce()) { setTimeout(done, 120); return; }
  const cur = getComputedStyle(box).transform, curT = cur && cur !== "none" ? cur : "none";
  box.style.transformOrigin = dragged ? "50% 50%" : "0 0";
  if (visible && !dragged) {
    const a = box.animate([{transform: curT, borderRadius: g.endR}, {transform: avFrom(g, sr), borderRadius: "50%"}], {duration: 300, easing: "cubic-bezier(.4,.1,.2,1)", fill: "forwards"});
    a.onfinish = done;
  } else if (visible) {
    box.style.transformOrigin = "0 0";

    const bx = box.getBoundingClientRect();
    const k0 = bx.width / g.side, from = "translate(" + (bx.left - g.fx) + "px," + (bx.top - g.fy) + "px) scale(" + k0 + ")";
    box.style.transform = "none";
    const a = box.animate([{transform: from, borderRadius: g.endR}, {transform: avFrom(g, sr), borderRadius: "50%"}], {duration: 280, easing: "cubic-bezier(.4,.1,.2,1)", fill: "forwards"});
    a.onfinish = done;
  } else {
    const a = box.animate([{transform: curT, opacity: 1}, {transform: (curT === "none" ? "" : curT + " ") + "scale(.85)", opacity: 0}], {duration: 240, easing: "ease-in", fill: "forwards"});
    a.onfinish = done;
  }
}
document.addEventListener("keydown", e => {
  if (e.key !== "Escape") return;
  if (AVV.el) closeAvatarViewer();
  else if (!$("lightbox").classList.contains("hidden")) closeLightbox();
  else if (S.sel && !S.modal && $("ctx").classList.contains("hidden")) exitSelect();
  else if (!$("ctx").classList.contains("hidden")) closeCtx();
  else if (S.modal) closeModal();
  else if (PG.list.length) closePage();
  else if (drawerIsOpen()) closeDrawer();
});

function sheetHead(title, onBack) {
  return h("div", {class: "sh-head"},
    onBack ? h("button", {class: "icon-btn", type: "button", onclick: onBack, "aria-label": "Orqaga"}, icon("back")) : null,
    h("span", {text: title}),
    h("button", {class: "icon-btn", type: "button", onclick: closeModal, "aria-label": "Yopish"}, icon("close")));
}

const PG = {list: []};
const PG_MS = 320;
function pageHead(title, right) {
  return h("div", {class: "pg-head"},
    h("button", {class: "icon-btn", type: "button", onclick: () => closePage(), "aria-label": "Orqaga"}, icon("back")),
    h("span", {class: "pg-title", text: title}), right || null);
}
function paintPage(p) {
  const top = p.el.scrollTop;
  p.refresh = null;
  p.el.textContent = "";
  p.el.append(p.build(p));
  p.el.scrollTop = top;
}
function openPage(build, live) {
  const layer = $("pages");
  const p = {el: h("section", {class: "pg tgp"}), build, live: !!live, at: performance.now(), name: "pg" + PG.list.length, refresh: null, closing: false};
  paintPage(p);
  const prev = PG.list[PG.list.length - 1]; if (prev) prev.el.classList.add("under");
  PG.list.push(p);
  layer.classList.add("on"); layer.append(p.el);
  navPush(p.name);
  void p.el.offsetWidth;
  requestAnimationFrame(() => p.el.classList.add("in"));
  return p;
}
function closePage() {
  const p = PG.list.pop(); if (!p) return;
  const prev = PG.list[PG.list.length - 1]; if (prev) prev.el.classList.remove("under");
  p.closing = true; p.el.classList.remove("in");
  setTimeout(() => { p.el.remove(); if (!PG.list.length) $("pages").classList.remove("on"); }, PG_MS);
  navPop(p.name);
}
function closeAllPages() { while (PG.list.length) closePage(); }
function resetPages() { if (AVV.el) { AVV.el.remove(); AVV.el = null; AVV.closing = false; } PG.list.forEach(p => p.el.remove()); PG.list.length = 0; $("pages").classList.remove("on"); closeDrawerNow(); }
let _rpTimer = 0;
function refreshPages() {
  if (_rpTimer || !PG.list.some(p => p.live || p.refresh)) return;
  const at = Math.max(...PG.list.map(p => p.at));
  _rpTimer = setTimeout(() => {
    _rpTimer = 0;
    requestAnimationFrame(() => PG.list.slice().forEach(p => { if (p.closing) return; if (p.refresh) p.refresh(); else if (p.live) paintPage(p); }));
  }, Math.max(150, 450 - (performance.now() - at)));
}
function repaintTopPage() { const p = PG.list[PG.list.length - 1]; if (p) paintPage(p); }
$("pages").addEventListener("click", e => { if (e.target === $("pages")) closeAllPages(); });

const drawerIsOpen = () => $("drawer").classList.contains("open");
function openDrawer() {
  if (drawerIsOpen()) return;
  renderDrawer();
  $("drawerBack").classList.add("show"); $("drawer").classList.add("open"); $("drawer").setAttribute("aria-hidden", "false");
  navPush("drawer");
}
function closeDrawerNow() { $("drawerBack").classList.remove("show"); $("drawer").classList.remove("open"); $("drawer").setAttribute("aria-hidden", "true"); }
function closeDrawer() { if (!drawerIsOpen()) return; closeDrawerNow(); navPop("drawer"); }
function renderDrawer() {
  const d = $("drawer"), me = S.me; d.textContent = "";
  const go = fn => () => {
    const dr = $("drawer"), bk = $("drawerBack"); dr.classList.add("snap"); bk.classList.add("snap");
    closeDrawer();
    setTimeout(() => { fn(); setTimeout(() => { dr.classList.remove("snap"); bk.classList.remove("snap"); }, 80); }, 0);
  };
  const item = (ic, text, fn) => h("button", {class: "dw-i", type: "button", onclick: go(fn)}, icon(ic), h("span", {text}));
  const dark = document.documentElement.dataset.theme === "dark";
  const sw = h("span", {class: "sw-t", role: "switch", "aria-checked": String(dark)});
  const night = h("button", {class: "dw-i", type: "button", onclick: () => { toggleTheme(); sw.setAttribute("aria-checked", String(document.documentElement.dataset.theme === "dark")); }},
    icon("moon"), h("span", {text: "Tungi rejim"}), sw);
  d.append(
    h("div", {class: "dw-head"}, avatar(me, "l"), h("div", {class: "dw-name"}, nameEl(me, {big: true})), h("div", {class: "dw-user", text: "@" + me.username})),
    h("div", {class: "dw-list"},
      item("user", "Mening profilim", () => openProfile(me.id)),
      item("group", "Foydalanuvchilar", openUsersPage),
      item("gear", "Sozlamalar", openSettingsPage),
      ...(amAdmin() ? [item("shield", "Admin sozlamalari", openAdminHome)] : []),
      night,
      item("lock", "Shifrlash: server nimani ko'radi?", () => openInspector("server"))),
    h("div", {class: "dw-foot", text: APP_NAME}));
}
$("menuBtn").addEventListener("click", e => { e.stopPropagation(); openDrawer(); });
$("drawerBack").addEventListener("click", closeDrawer);
(() => {
  let x0 = null, y0 = 0;
  const d = $("drawer");
  d.addEventListener("touchstart", e => { const t = e.touches[0]; x0 = t.clientX; y0 = t.clientY; }, {passive: true});
  d.addEventListener("touchend", e => { if (x0 == null) return; const t = e.changedTouches[0], dx = t.clientX - x0, dy = Math.abs(t.clientY - y0); x0 = null; if (dx < -60 && dy < 60) closeDrawer(); }, {passive: true});
})();

function switchRow(ic, text, getOn, onSet, hint) {
  const sw = h("span", {class: "sw-t", role: "switch", "aria-checked": String(!!getOn())});
  const row = h("button", {class: "set-row", type: "button", "aria-label": text}, icon(ic), h("span", {text}), sw);
  const sync = () => sw.setAttribute("aria-checked", String(!!getOn()));
  row.addEventListener("click", async () => { try { await onSet(!getOn()); } catch (err) { toast(err.message, "error"); } sync(); });
  return hint ? h("div", {}, row, h("p", {class: "tg-hint", text: hint})) : row;
}
const setRow = (ic, text, fn, val, danger) => h("button", {class: "set-row" + (danger ? " danger" : ""), type: "button", onclick: fn}, icon(ic), h("span", {text}), val ? h("span", {class: "sv", text: val}) : null);
const gapEl = () => h("div", {class: "tg-gap"});
const secTitle = (text, n) => h("div", {class: "sec-t"}, h("span", {text}), n == null ? null : h("b", {text: String(n)}));
function fmtDay(ts) {
  const d = new Date(ts * 1000), n = new Date();
  const same = d.getFullYear() === n.getFullYear() && d.getMonth() === n.getMonth() && d.getDate() === n.getDate();
  return (same ? "Bugun" : d.getDate() + "-" + MONTHS[d.getMonth()] + (d.getFullYear() !== n.getFullYear() ? " " + d.getFullYear() : "")) + ", " + hhmm(ts);
}

function usersBlock() {
  let filter = "";
  const el = h("div", {class: "ublock"});
  const title = h("div", {class: "sec-t"});
  const search = h("input", {type: "text", class: "gsearch", placeholder: "Foydalanuvchilarni qidirish", autocomplete: "off", autocapitalize: "none", spellcheck: "false", "aria-label": "Foydalanuvchilarni qidirish"});
  const list = h("div", {class: "mlist"});
  const rank = u => u.role === "owner" ? 0 : u.role === "admin" ? 1 : 2;
  const fill = () => {
    list.textContent = "";
    const q = filter.trim().toLowerCase();
    const all = S.members.map(m => U(m.id)).filter(u => !u.deleted);
    const shown = all.filter(u => !q || (u.nickname || "").toLowerCase().includes(q) || (u.username || "").toLowerCase().includes(q))
      .sort((a, b) => (rank(a) - rank(b)) || ((isOnline(b.id) ? 1 : 0) - (isOnline(a.id) ? 1 : 0)) || (a.nickname || "").localeCompare(b.nickname || ""));
    title.textContent = ""; title.append(h("span", {text: "Foydalanuvchilar"}), h("b", {text: String(all.length)}));
    shown.forEach(u => list.append(itemEl({
      av: avatar(u, "m", true), title: [nameEl(u), u.id === S.me.id ? h("span", {class: "i-time", text: "(siz)"}) : null],
      sub: (isStaff(u) ? roleLabel(u.role) + " • " : "") + statusText(u), subOn: isOnline(u.id),
      onclick: () => openProfile(u.id),
    })));
    if (!shown.length) list.append(h("div", {class: "none", text: "Hech narsa topilmadi"}));
  };
  search.addEventListener("input", () => { filter = search.value; fill(); });
  fill();
  el.append(title, search, list);
  return {el, fill};
}
function openUsersPage() { openPage(p => { const ub = usersBlock(); p.refresh = ub.fill; return h("div", {}, pageHead("Foydalanuvchilar"), ub.el); }); }

function mediaCounts(list, more) {
  const st = {img: 0, video: 0, file: 0, audio: 0, voice: 0, more: !!more};
  (list || []).forEach(m => {
    if (m.deleted) return;
    if (m.image) { st.img++; return; }
    const f = m.file; if (!f) return;
    const mime = f.mime || "";
    if (f.voice) st.voice++;
    else if (f.vnote || /^video\//.test(mime)) st.video++;
    else if (/^audio\//.test(mime)) st.audio++;
    else if (/^image\//.test(mime)) st.img++;
    else st.file++;
  });
  return st;
}
function mediaRows(st) {
  const plus = st.more ? "+" : "";
  const row = (ic, n, label) => h("div", {class: "tg-row"}, icon(ic), h("span", {text: n + plus + " " + label}));
  return h("div", {class: "tg-media"}, row("attach", st.img, "ta rasm"), row("videocam", st.video, "ta video"), row("file", st.file, "ta fayl"),
    row("headphones", st.audio, "ta audio fayl"), row("mic", st.voice, "ta ovozli xabar"));
}

function infoPage(o) {
  return openPage(p => {
    const wrap = h("div", {});
    const subEl = h("div", {class: "pstat", text: o.sub()});
    const media = h("div", {});
    const paintMedia = () => { const m = o.msgs(); media.textContent = ""; media.append(mediaRows(mediaCounts(m.list, m.more))); };
    paintMedia();
    wrap.append(pageHead(o.title),
      h("div", {class: "tg-top"}, o.av(), h("div", {class: "pname"}, h("span", {text: o.name})), subEl));
    if (o.rows && o.rows.length) wrap.append(h("div", {class: "tg-info"}, ...o.rows));
    wrap.append(gapEl(), media,
      h("p", {class: "tg-hint", text: "Sonlar shu qurilmaga yuklangan xabarlar bo'yicha (xabarlar shifrlangan, server sanay olmaydi). \"+\" — tepada yana eski xabarlar bor."}));
    let ub = null;
    if (o.users) { ub = usersBlock(); wrap.append(gapEl(), ub.el); }
    if (o.foot && o.foot.length) wrap.append(gapEl(), h("div", {class: "tg-modwrap"}, ...o.foot));
    p.refresh = () => { subEl.textContent = o.sub(); paintMedia(); if (ub) ub.fill(); };
    return wrap;
  }, false);
}
function openGroupInfo() {
  infoPage({
    title: "Guruh ma'lumoti", name: "Umumiy chat", av: () => groupAvatar("l"),
    sub: () => (S.members.length || 1) + " a'zo" + (S.offline ? "" : ", " + onlineCount() + " onlayn"),
    msgs: () => ({list: S.group.msgs, more: S.group.more}), users: true,
    foot: amAdmin() ? [h("button", {class: "btn danger sm", type: "button", onclick: () => { closeAllPages(); clearGroupChat(); }}, "Chatni tozalash")] : [],
  });
}

function openProfile(uid) {
  if (!S.users.has(uid)) loadMembers();
  openPage(() => profileView(uid), true);
}

function mediaStats(uid) {
  const dm = S.dms.get(uid);
  if (!dm || !dm.loaded) return null;
  const st = {img: 0, voice: 0, vnote: 0, file: 0, more: !!dm.more};
  dm.msgs.forEach(m => {
    if (m.deleted) return;
    if (m.image) st.img++;
    else if (m.file) { if (m.file.voice) st.voice++; else if (m.file.vnote) st.vnote++; else st.file++; }
  });
  return st;
}
function tgRow(ic, text) { return h("div", {class: "tg-row"}, icon(ic), h("span", {text})); }

function profileView(uid) {
  const u = U(uid), me = u.id === S.me.id;
  const wrap = h("div", {});
  if (u.deleted) {
    const bn = h("div", {class: "pbanner gone"});
    bn.append(h("button", {class: "pbtn l", type: "button", onclick: () => closePage(), "aria-label": "Orqaga"}, icon("back")));
    bn.append(h("button", {class: "pbtn r", type: "button", onclick: closeAllPages, "aria-label": "Yopish"}, icon("close")));
    wrap.append(bn, h("div", {class: "pbody"}, avatar(u, "l"),
      h("div", {class: "pname"}, nameEl(u, {big: true})),
      h("div", {class: "pstat", text: "Bu akkaunt o'chirilgan"}),
      h("div", {class: "gone-note", text: "Yozgan xabarlari chatda qoladi. Unga xabar yuborib bo'lmaydi."})));
    return wrap;
  }
  const top = tint(h("div", {class: "tg-top" + (isStaff(u) ? " prem " + u.role : "") + bannerCls(u) + pageCls(u)}), u);
  top.append(h("button", {class: "tg-back", type: "button", onclick: () => closePage(), "aria-label": "Orqaga"}, icon("back")),
    me ? h("button", {class: "tg-edit", type: "button", onclick: openInfoPage, "aria-label": "Profilni tahrirlash"}, icon("edit")) : "",
    zoomAvatar(avatar(u, "l"), u),
    h("div", {class: "pname"}, nameEl(u, {big: true})),
    titleEl(u),
    h("div", {class: "pstat" + (isOnline(u.id) ? " on" : ""), text: statusText(u)}));
  if (isStaff(u)) top.append(tint(h("div", {class: "chip prem " + u.role}, hasEmoji(u) ? badge(u) : (u.badge === "none" ? null : icon(u.role === "owner" ? "shield" : "check", "ic vb")), roleLabel(u.role)), u));
  else if (hasEmoji(u)) top.append(h("div", {class: "chip"}, badge(u), "Maxsus nishon"));
  else if (isVerified(u)) top.append(h("div", {class: "chip"}, badge(u), "Tasdiqlangan foydalanuvchi"));
  if (u.new && !isStaff(u)) top.append(h("div", {class: "chip warn", text: "⚠ Yangi foydalanuvchi — hali ishonish qiyin"}));
  wrap.append(top);

  const acts = h("div", {class: "tg-acts"});
  const act = (ic, label, fn, on) => h("button", {class: "tg-act" + (on ? " on" : ""), type: "button", onclick: fn, "aria-pressed": on == null ? null : String(!!on)}, icon(ic), h("span", {text: label}));
  if (!me) {
    acts.append(act("chat", "Xabar", () => { closeAllPages(); openChat({kind: "dm", uid: u.id}); }));
    const muted = isMuted(u.id);
    acts.append(act(muted ? "bell-off" : "bell", muted ? "Ovoz yoq" : "Mute", () => {
      const on = toggleMute(u.id);
      toast(on ? "Bu suhbat ovozi o'chirildi (shu qurilmada)" : "Suhbat ovozi yoqildi", "ok");
      repaintTopPage();
    }, muted));
  }
  if (!me) wrap.append(acts);
  wrap.append(h("div", {class: "tg-gap"}));

  const info = h("div", {class: "tg-info"});
  const copyRow = (val, label, copy) => h("div", {class: "tg-row copy", role: "button", tabindex: "0", title: "Nusxalash",
    onclick: () => copyText(copy), onkeydown: e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); copyText(copy); } }},
    h("div", {class: "tg-val", text: val}), h("div", {class: "tg-lab", text: label}));
  const unRow = copyRow("@" + u.username, "Username", "@" + u.username); fxText(unRow.firstChild, fxOf(u, "user"));
  info.append(unRow);
  if (u.bio) info.append(h("div", {class: "tg-row copy"}, fxText(h("div", {class: "tg-bio"}, Rich.inline(u.bio, LINKCTX)), fxOf(u, "bio")), h("div", {class: "tg-lab", text: "Bio"})));
  if (u.joined) { const d = new Date(u.joined * 1000); info.append(h("div", {class: "tg-row copy"}, h("div", {text: d.getDate() + "-" + MONTHS[d.getMonth()] + " " + d.getFullYear()}), h("div", {class: "tg-lab", text: "Qo'shilgan"}))); }
  wrap.append(info);

  const st = me ? null : mediaStats(u.id);
  if (st && (st.img || st.voice || st.vnote || st.file)) {
    const plus = st.more ? "+" : "";
    const rows = h("div", {class: "tg-media"});
    if (st.img) rows.append(tgRow("attach", st.img + plus + " ta rasm"));
    if (st.voice) rows.append(tgRow("mic", st.voice + plus + " ta ovozli xabar"));
    if (st.vnote) rows.append(tgRow("videocam", st.vnote + plus + " ta video xabar"));
    if (st.file) rows.append(tgRow("file", st.file + plus + " ta fayl"));
    wrap.append(h("div", {class: "tg-gap"}), rows);
  }
  if (!me && amAdmin() && u.role !== "owner" && (u.role !== "admin" || S.me.role === "owner")) wrap.append(h("div", {class: "tg-gap"}), h("div", {class: "tg-modwrap"}, modPanel(u)));
  return wrap;
}
function modPanel(u) {
  const cmd = text => wsSend({type: "cmd", text});
  const panel = h("div", {class: "mod"}, h("h4", {}, icon("shield"), "Moderatsiya"));
  const flags = h("div", {class: "mod-r"});
  if (u.banned) flags.append(h("span", {class: "flag", text: "Ban qilingan"}));
  if (u.muted) flags.append(h("span", {class: "flag w", text: "Mute qilingan"}));
  if (u.warns) flags.append(h("span", {class: "warnflag", text: "Ogohlantirish: " + u.warns + "/3"}));
  if (flags.children.length) panel.append(flags);
  const dur = h("select", {}, h("option", {value: "10", text: "10 daqiqa"}), h("option", {value: "60", text: "1 soat"}),
    h("option", {value: "1440", text: "1 kun"}), h("option", {value: "perm", text: "Doimiy"}));
  panel.append(h("div", {class: "mod-r"}, dur,
    h("button", {class: "btn ghost sm", type: "button", onclick: () => cmd("/mute " + u.username + " " + dur.value)}, "Mute"),
    u.muted ? h("button", {class: "btn ghost sm", type: "button", onclick: () => cmd("/unmute " + u.username)}, "Unmute") : null));
  panel.append(h("div", {class: "mod-r"},
    h("button", {class: "btn ghost sm", type: "button", onclick: async () => {
      const why = await promptDlg("Ogohlantirish", "@" + u.username + " ga ogohlantirish (3 tadan keyin 1 soat mute). Sabab:", "", {okText: "Ogohlantirish"});
      if (why !== null) cmd("/warn " + u.username + " " + why);
    }}, "Ogohlantirish"),
    u.warns ? h("button", {class: "btn ghost sm", type: "button", onclick: () => cmd("/unwarn " + u.username)}, "Olib tashlash") : null,
    h("button", {class: "btn ghost sm", type: "button", onclick: async () => {
      if (await confirmDlg("@" + u.username + " ning umumiy chatdagi oxirgi xabarlari (va fayllari) o'chiriladi.", {title: "Xabarlarini tozalash", okText: "Tozalash", danger: true})) cmd("/purge " + u.username);
    }}, "Xabarlarini tozalash"),
    h("button", {class: "btn ghost sm", type: "button", onclick: () => openBadgePicker(u)}, "Nishon / galochka"),
    h("button", {class: "btn ghost sm", type: "button", onclick: () => openProfileEditor(u.id)}, "Unvon / ishonch")));
  panel.append(h("div", {class: "mod-r"},
    u.banned
      ? h("button", {class: "btn ghost sm", type: "button", onclick: () => cmd("/unban " + u.username)}, "Bandan chiqarish")
      : h("button", {class: "btn danger sm", type: "button", onclick: async () => { if (await confirmDlg("@" + u.username + " ni ban qilasizmi?", {title: "Ban qilish", okText: "Ban qilish", danger: true})) cmd("/ban " + u.username); }}, "Ban qilish")));
  if (S.me.role === "owner") {
    panel.append(h("div", {class: "mod-r"}, u.role === "admin"
      ? h("button", {class: "btn ghost sm", type: "button", onclick: async () => { if (await confirmDlg("@" + u.username + " adminlikdan olinsinmi?", {title: "Adminlikdan olish", okText: "Olish", danger: true})) cmd("/rmadmin " + u.username); }}, "Adminlikdan olish")
      : h("button", {class: "btn ghost sm", type: "button", onclick: async () => { if (await confirmDlg("@" + u.username + " admin qilinsinmi?", {title: "Admin qilish", okText: "Admin qilish"})) cmd("/addadmin " + u.username); }}, "Admin qilish")));
  }
  const rows = panel.querySelectorAll(".mod-r");
  if (S.me.role === "owner" && rows.length >= 2) { const last = rows[rows.length - 1], prev = rows[rows.length - 2]; [...last.children].forEach(c => prev.append(c)); last.remove(); }
  panel.append(h("div", {class: "mod-r"}, h("button", {class: "btn danger sm", type: "button", onclick: async () => {
    if (await confirmDlg("@" + u.username + " akkaunti o'chiriladi va chatdan chiqarib tashlanadi. Yozgan xabarlari \"Deleted account\" nomi bilan qoladi. Buni qaytarib bo'lmaydi.",
      {title: "Akkauntni o'chirish", okText: "O'chirish", danger: true})) { cmd("/remove " + u.username); closePage(); }
  }}, "Akkauntni o'chirish")));
  return panel;
}

function ago(ts) {
  if (!ts) return "?";
  const s = Math.max(0, Date.now() / 1000 - ts);
  if (s < 60) return "hozirgina";
  const m = s / 60; if (m < 60) return Math.floor(m) + " daqiqa oldin";
  const hr = m / 60; if (hr < 24) return Math.floor(hr) + " soat oldin";
  const d = hr / 24; if (d < 30) return Math.floor(d) + " kun oldin";
  if (d < 365) return Math.floor(d / 30) + " oy oldin";
  return Math.floor(d / 365) + " yil oldin";
}
async function backupDownload() {
  const p1 = await promptDlg("Zaxira paroli", "Zaxira faylini shifrlash uchun parol-ibora kiriting (kamida 8 belgi). Uni yo'qotsangiz, fayl ochilmaydi va tiklab bo'lmaydi.", "", {type: "password", okText: "Davom etish"});
  if (p1 === null) return;
  if (p1.length < 8) { toast("Parol-ibora kamida 8 belgi bo'lishi kerak", "error"); return; }
  const p2 = await promptDlg("Parol-iborani takrorlang", "Xato yozilmaganini tekshirish uchun yana kiriting:", "", {type: "password", okText: "Yuklab olish"});
  if (p2 === null) return;
  if (p1 !== p2) { toast("Parol-iboralar mos kelmadi", "error"); return; }
  toast("Shifrlanmoqda…");
  try {
    const data = await api("/admin/backup");
    const bytes = await Backup.seal(data, p1), d = new Date();
    const name = "anonim-chat-users-" + d.getFullYear() + pad2(d.getMonth() + 1) + pad2(d.getDate()) + ".acdb";
    const url = URL.createObjectURL(new Blob([bytes], {type: "application/octet-stream"}));
    const a = h("a", {href: url, download: name}); document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
    toast(data.users.length + " ta akkaunt shifrlangan zaxiraga yozildi" + (data.avatars_skipped ? " (" + data.avatars_skipped + " ta katta rasm kiritilmadi)" : ""), "ok");
  } catch (err) { toast(err.message, "error"); }
}
function backupRestore(done) {
  const f = h("input", {type: "file", accept: ".acdb", class: "offscreen"});
  f.addEventListener("cancel", () => f.remove());
  f.addEventListener("change", async () => {
    const file = f.files[0]; f.remove();
    if (!file) return;
    try {
      if (file.size > 40 * 1048576) throw new Error("Fayl juda katta");
      const bytes = new Uint8Array(await file.arrayBuffer());
      const pass = await promptDlg("Zaxira paroli", "Zaxirani ochish uchun parol-iborani kiriting:", "", {type: "password", okText: "Ochish"});
      if (pass === null) return;
      toast("Ochilmoqda…");
      const data = await Backup.open(bytes, pass);
      const list = Array.isArray(data.users) ? data.users : [], adm = list.filter(u => u && u.role === "admin").length;
      if (!await confirmDlg(list.length + " ta akkaunt topildi (" + adm + " ta admin). Mavjud username'larga tegilmaydi — faqat yo'qlari tiklanadi. Xabarlar tiklanmaydi. Davom etilsinmi?", {title: "Zaxiradan tiklash", okText: "Tiklash"})) return;
      const j = await api("/admin/backup/restore", {method: "POST", body: {data}});
      toast(j.created + " ta akkaunt tiklandi" + (j.skipped ? ", " + j.skipped + " tasi allaqachon bor" : "") + (j.invalid ? ", " + j.invalid + " tasi yaroqsiz" : ""), j.created ? "ok" : "warn");
      loadMembers(); if (done) done();
    } catch (err) { toast(err.message, "error"); }
  });
  document.body.append(f); f.click();
}

const fmtDT = ts => { const d = new Date(ts * 1000); return pad2(d.getDate()) + "." + pad2(d.getMonth() + 1) + "." + String(d.getFullYear()).slice(2) + " " + hhmm(ts) + ":" + pad2(d.getSeconds()); };
function admErr(box, err) { box.textContent = ""; box.append(h("div", {class: "adm-empty", text: err.message})); }

function openAdmin(initial, preset) {
  preset = preset || {};
  const top = PG.list[PG.list.length - 1];
  if (top && top.adm === initial && !Object.keys(preset).length) { paintPage(top); return; }
  const pg = openPage(() => {
    const st = {tab: initial, q: preset.q || "", ip: preset.ip || "", user: preset.user || "", action: ""};
    const body = h("div", {class: "adm-body"});
    const loaders = {ips: loadIps, users: loadUsers, log: loadLog, msgs: loadMsgs, blocks: loadBlocks, media: loadMedia, reports: loadReports, mod: loadMod, emoji: () => emojiManager(body, () => st.tab === "emoji")};
    const load = () => { body.textContent = ""; loaders[st.tab](); };

    function loadUsers() {
      const owner = S.me.role === "owner";
      const filter = h("input", {type: "text", class: "fld", placeholder: "Nickname yoki @username bo'yicha qidirish", autocomplete: "off"});
      const list = h("div", {}), box = h("div", {class: "bk-box"});
      let all = [];
      const roleName = r => r === "owner" ? "Ega" : r === "admin" ? "Admin" : "Oddiy";
      const paint = () => {
        const q = filter.value.trim().toLowerCase().replace(/^@/, "");
        list.textContent = "";
        const rows = all.filter(u => !q || u.nickname.toLowerCase().includes(q) || u.username.toLowerCase().includes(q));
        if (!rows.length) list.append(h("div", {class: "adm-empty", text: "Hech narsa topilmadi"}));
        rows.forEach(u => {
          const can = u.role !== "owner" && (u.role !== "admin" || owner);
          list.append(h("div", {class: "urow"}, avatar(u, "m", true),
            h("div", {class: "utx"}, nameEl(u),
              h("div", {class: "usub"}, h("span", {class: "ubadge " + u.role, text: roleName(u.role)}), "@" + u.username + " • " + ago(u.joined) + " qo'shilgan" + (u.banned ? " • ban" : ""))),
            can ? h("div", {class: "urow-act"},
              h("button", {class: "btn ghost sm", type: "button", text: "Unvon", onclick: () => openProfileEditor(u.id)}),
              h("button", {class: "btn ghost sm", type: "button", text: "Nishon", onclick: () => openBadgePicker(u, () => openAdmin("users"))})) : h("span")));
        });
      };
      const fill = async () => {
        list.textContent = ""; list.append(h("div", {class: "adm-empty", text: "Yuklanmoqda…"}));
        try { const j = await api("/members"); j.members.forEach(upsertUser); all = j.members.map(x => U(x.id)); box.querySelector(".bk-n") && (box.querySelector(".bk-n").textContent = all.length + " ta akkaunt"); paint(); }
        catch (err) { admErr(list, err); }
      };
      if (owner) box.append(h("div", {}, h("b", {text: "Shifrlangan zaxira (.acdb). "}), "Username, nickname, rol, profil rasmi, qo'shilgan vaqt va kirish ma'lumoti sizning parol-iborangiz bilan BRAUZERDA shifrlanadi; parol-ibora serverga yuborilmaydi. Uni yo'qotsangiz fayl ochilmaydi. Xabarlar zaxiraga kirmaydi. ", h("span", {class: "bk-n"})),
        h("div", {class: "ep-row"}, h("button", {class: "btn sm", type: "button", text: "⬇ Bazani yuklab olish", onclick: backupDownload}),
          h("button", {class: "btn ghost sm", type: "button", text: "⬆ Zaxiradan tiklash", onclick: () => backupRestore(fill)})));
      else box.append("Bazani yuklab olish va zaxiradan tiklash faqat platforma egasiga ochiq: zaxira faylida kirish ma'lumotlari bor, ularni oddiy adminga berish E2EE'ni buzardi. Siz foydalanuvchilarga nishon/galochka bera olasiz.");
      filter.addEventListener("input", paint);
      body.append(box, h("div", {class: "adm-filters"}, filter), list);
      fill();
    }

    function loadIps() {
      const filter = h("input", {type: "text", class: "fld", placeholder: "IP yoki @username bo'yicha qidirish", autocomplete: "off"});
      filter.value = st.q;
      const list = h("div", {});
      let timer = null;
      const fill = async () => {
        list.textContent = ""; list.append(h("div", {class: "adm-empty", text: "Yuklanmoqda…"}));
        try {
          const j = await api("/admin/ips?q=" + encodeURIComponent(st.q));
          list.textContent = "";
          if (!j.ips.length) list.append(h("div", {class: "adm-empty", text: "Hech narsa topilmadi"}));
          j.ips.forEach(e => list.append(ipCard(e, fill)));
        } catch (err) { admErr(list, err); }
      };
      filter.addEventListener("input", () => { clearTimeout(timer); timer = setTimeout(() => { st.q = filter.value.trim(); fill(); }, 300); });
      body.append(h("div", {class: "adm-filters"}, filter), list);
      fill();
    }
    function ipCard(e, refresh) {
      const head = h("div", {class: "ipc-h"}, h("span", {class: "ip", text: e.ip}), e.blocked ? h("span", {class: "flag b", text: "Bloklangan"}) : null);
      const sum = h("div", {class: "ipc-s", text: e.profiles.length + " ta profil • " + e.logins + " kirish • " + e.sessions + " sessiya • " + e.msgs + " xabar" +
        (e.failed ? " • " + e.failed + " xato urinish" : "") + " • oxirgi: " + fmtDT(e.last_seen)});
      const card = h("div", {class: "ipc" + (e.blocked ? " blk" : "")}, head, sum);
      e.profiles.forEach(p => card.append(h("div", {class: "ipc-p"},
        h("div", {class: "who"}, h("b", {text: "@" + p.username}), p.nickname ? " (" + p.nickname + ")" : "", p.known ? "" : " — ro'yxatdan o'tmagan nom"),
        h("div", {class: "num", text: p.logins + " kirish • " + p.sessions + " sessiya • " + p.msgs + " xabar" + (p.failed ? " • " + p.failed + " xato" : "")}))));
      const acts = h("div", {class: "ipc-a"}, h("button", {class: "btn ghost sm", type: "button", text: "Loglari", onclick: () => openAdmin("log", {ip: e.ip})}));
      if (e.blocked) acts.append(h("button", {class: "btn ghost sm", type: "button", text: "Blokdan ochish", onclick: async () => {
        if (!await confirmDlg(e.ip + " blokdan ochilsinmi?", {title: "Blokdan ochish", okText: "Ochish"})) return;
        try { await api("/admin/unblock", {method: "POST", body: {ip: e.ip}}); toast("Blokdan ochildi", "ok"); refresh(); } catch (err) { toast(err.message, "error"); }
      }}));
      else acts.append(h("button", {class: "btn danger sm", type: "button", text: "Bloklash", onclick: async () => {
        const reason = await promptDlg("IP bloklash", e.ip + " bloklanadi. Sabab (ixtiyoriy):", "spam", {okText: "Bloklash"});
        if (reason === null) return;
        try { const j = await api("/admin/blocks", {method: "POST", body: {ip: e.ip, reason}}); toast("Bloklandi" + (j.kicked ? " (" + j.kicked + " ta ulanish uzildi)" : ""), "ok"); refresh(); }
        catch (err) { toast(err.message, "error"); }
      }}));
      card.append(acts);
      return card;
    }

    function loadLog() {
      const ipI = h("input", {type: "text", class: "fld", placeholder: "IP", autocomplete: "off"}); ipI.value = st.ip;
      const userI = h("input", {type: "text", class: "fld", placeholder: "@username", autocomplete: "off"}); userI.value = st.user;
      const sel = h("select", {}, h("option", {value: "", text: "Barcha amallar"}));
      const list = h("div", {}), more = h("button", {class: "btn ghost sm adm-more hidden", type: "button", text: "Yana yuklash"});
      let before = 0, filled = false, timer = null;
      const picked = new Set();
      const delSel = h("button", {class: "btn danger sm", type: "button", text: "Tanlanganlarni o'chirish"});
      const delAll = h("button", {class: "btn ghost sm dangerline", type: "button", text: "Filtrdagi hammasini o'chirish"});
      const updDel = () => { delSel.disabled = !picked.size; delSel.textContent = picked.size ? "Tanlanganlarni o'chirish (" + picked.size + ")" : "Tanlanganlarni o'chirish"; };
      delSel.addEventListener("click", async () => {
        if (!await confirmDlg(picked.size + " ta log yozuvi butunlay o'chiriladi.", {title: "Loglarni o'chirish", okText: "O'chirish", danger: true})) return;
        try { const j = await api("/admin/activity/delete", {method: "POST", body: {ids: [...picked]}}); toast(j.deleted + " ta yozuv o'chirildi", "ok"); picked.clear(); updDel(); page(true); }
        catch (err) { toast(err.message, "error"); }
      });
      delAll.addEventListener("click", async () => {
        const f = ipI.value.trim() || userI.value.trim() || sel.value;
        if (!await confirmDlg(f ? "Joriy filtrga mos BARCHA yozuvlar o'chiriladi." : "Harakatlar logining BUTUN tarixi o'chiriladi.", {title: "Loglarni o'chirish", okText: "Hammasini o'chirish", danger: true})) return;
        try { const j = await api("/admin/activity/delete", {method: "POST", body: {all: true, ip: ipI.value.trim(), user: userI.value.trim(), action: sel.value}}); toast(j.deleted + " ta yozuv o'chirildi", "ok"); picked.clear(); updDel(); page(true); }
        catch (err) { toast(err.message, "error"); }
      });
      const row = it => {
        const bad = ["login_failed", "blocked", "ip_block"].includes(it.action);
        const ipl = it.ip ? h("span", {class: "ipl", text: it.ip, onclick: () => { ipI.value = it.ip; page(true); }}) : null;
        const ck = h("input", {type: "checkbox", class: "ck", "aria-label": "Tanlash"});
        ck.addEventListener("change", () => { if (ck.checked) picked.add(it.id); else picked.delete(it.id); updDel(); });
        return h("div", {class: "lg sel"}, ck, h("div", {class: "t", text: fmtDT(it.ts)},),
          h("div", {class: "w"}, h("span", {class: "a" + (bad ? " bad" : ""), text: it.label}), it.username ? "@" + it.username + " " : "", ipl),
          it.detail ? h("div", {class: "d", text: it.detail}) : null);
      };
      const page = async reset => {
        if (reset) { before = 0; list.textContent = ""; picked.clear(); updDel(); }
        const qs = new URLSearchParams({ip: ipI.value.trim(), user: userI.value.trim(), action: sel.value, limit: "100"});
        if (before) qs.set("before", before);
        try {
          const j = await api("/admin/activity?" + qs.toString());
          if (!filled) { j.actions.forEach(a => sel.append(h("option", {value: a.key, text: a.label}))); filled = true; }
          j.items.forEach(it => list.append(row(it)));
          if (j.items.length) before = j.items[j.items.length - 1].id;
          more.classList.toggle("hidden", j.items.length < 100);
          if (reset && !j.items.length) list.append(h("div", {class: "adm-empty", text: "Yozuv topilmadi"}));
        } catch (err) { admErr(list, err); }
      };
      const again = () => { clearTimeout(timer); timer = setTimeout(() => page(true), 300); };
      ipI.addEventListener("input", again); userI.addEventListener("input", again); sel.addEventListener("change", () => page(true));
      more.addEventListener("click", () => page(false));
      body.append(h("div", {class: "adm-filters"}, ipI, userI, sel), h("div", {class: "adm-bar"}, delSel, delAll), list, more);
      updDel(); page(true);
    }

    function loadBlocks() {
      const ipI = h("input", {type: "text", class: "fld", placeholder: "Bloklash uchun IP (masalan 203.0.113.5)", autocomplete: "off"});
      const reasonI = h("input", {type: "text", class: "fld", placeholder: "Sabab (ixtiyoriy)", autocomplete: "off"});
      const list = h("div", {});
      const fill = async () => {
        list.textContent = "";
        try {
          const j = await api("/admin/blocks");
          if (!j.blocks.length) list.append(h("div", {class: "adm-empty", text: "Bloklangan IP yo'q"}));
          j.blocks.forEach(b => list.append(h("div", {class: "ipc blk"},
            h("div", {class: "ipc-h"}, h("span", {class: "ip", text: b.ip})),
            h("div", {class: "ipc-s", text: (b.reason ? b.reason + " • " : "") + "@" + b.by + " • " + fmtDT(b.ts)}),
            h("div", {class: "ipc-a"}, h("button", {class: "btn ghost sm", type: "button", text: "Blokdan ochish", onclick: async () => {
              try { await api("/admin/unblock", {method: "POST", body: {ip: b.ip}}); toast("Blokdan ochildi", "ok"); fill(); } catch (err) { toast(err.message, "error"); }
            }}),
            h("button", {class: "btn ghost sm", type: "button", text: "Loglari", onclick: () => openAdmin("log", {ip: b.ip})})))));
        } catch (err) { admErr(list, err); }
      };
      const add = h("button", {class: "btn danger sm", type: "button", text: "Bloklash", onclick: async () => {
        if (!ipI.value.trim()) return;
        try { await api("/admin/blocks", {method: "POST", body: {ip: ipI.value.trim(), reason: reasonI.value}}); ipI.value = ""; reasonI.value = ""; toast("Bloklandi", "ok"); fill(); }
        catch (err) { toast(err.message, "error"); }
      }});
      body.append(h("div", {class: "adm-filters"}, ipI, reasonI, add), list);
      fill();
    }

    function loadMsgs() {
      const qI = h("input", {type: "text", class: "fld", placeholder: "@username bo'yicha qidirish", autocomplete: "off"});
      const sel = h("select", {}, h("option", {value: "", text: "Barcha xabarlar"}), h("option", {value: "deleted", text: "Faqat o'chirilganlar"}), h("option", {value: "edited", text: "Faqat tahrirlanganlar"}));
      const list = h("div", {}), more = h("button", {class: "btn ghost sm adm-more hidden", type: "button", text: "Yana yuklash"});
      let next = 0, timer = null;
      const row = it => {
        const cipher = h("div", {class: "mcipher", text: it.cipher || "(shifr yo'q)"});
        const metaTxt = it.meta ? (it.meta.kind + " • epoch " + it.meta.epoch + " • shifr " + it.meta.cipher_bytes + " bayt • imzo " + it.meta.sig_bytes + " bayt")
          : (it.legacy ? "eski xabar (E2EE'dan oldin)" : "");
        const lock = h("div", {class: "mmeta", text: "🔒 " + metaTxt});
        const flags = h("span", {class: "mflags"},
          it.deleted ? h("span", {class: "flag b", text: "O'chirilgan"}) : null,
          it.edited ? h("span", {class: "flag w", text: "Tahrirlangan"}) : null,
          it.file ? h("span", {class: "flag", text: "Fayl " + fmtSize(it.file_bytes) + " (shifrlangan)"}) : null,
          it.legacy ? h("span", {class: "flag w", text: "Eski"}) : null);
        const card = h("div", {class: "lg mlg" + (it.deleted ? " gone" : "")},
          h("div", {class: "t", text: fmtDT(it.ts) + " • #" + it.id}),
          h("div", {class: "w"}, h("span", {class: "a", text: "@" + it.username}), it.nickname ? " (" + it.nickname + ") " : " ", flags),
          cipher, lock);
        it.history.forEach(hh => card.append(h("div", {class: "mhist"},
          h("b", {text: (hh.type === "edit" ? "Tahrir" : hh.type === "delete" ? "O'chirish" : hh.type) + " • " + fmtDT(hh.ts) + (hh.by ? " • @" + hh.by : "")}),
          hh.type === "edit" ? h("div", {class: "mcipher", text: hh.old + "\n→\n" + hh.new}) : h("div", {class: "mcipher", text: hh.old}))));
        return card;
      };
      const page = async reset => {
        if (reset) { next = 0; list.textContent = ""; }
        const qs = new URLSearchParams({q: qI.value.trim(), state: sel.value, limit: "50"});
        if (next) qs.set("before", next);
        try {
          const j = await api("/admin/messages?" + qs.toString());
          j.items.forEach(it => list.append(row(it)));
          next = j.next; more.classList.toggle("hidden", !next);
          if (reset && !j.items.length) list.append(h("div", {class: "adm-empty", text: "Xabar topilmadi"}));
        } catch (err) { admErr(list, err); }
      };
      qI.addEventListener("input", () => { clearTimeout(timer); timer = setTimeout(() => page(true), 300); });
      sel.addEventListener("change", () => page(true)); more.addEventListener("click", () => page(false));
      body.append(h("div", {class: "adm-note", text: "Uchdan-uchga shifrlash (E2EE): server ham, admin ham xabar matnini o'qiy olmaydi — bu yerda faqat shifrlangan konvertlar ko'rinadi. Matnni faqat chat a'zolarining qurilmalari ochadi. Lichka xabarlar bu yerda ko'rinmaydi."}),
        h("div", {class: "adm-filters"}, qI, sel),
        h("div", {class: "adm-bar"}, h("button", {class: "btn ghost sm dangerline", type: "button", text: "Tarixni tozalash", onclick: async () => {
          if (!await confirmDlg("O'chirilgan umumiy chat xabarlari bazadan butunlay o'chadi va tahrir/moderatsiya tarixi tozalanadi.", {title: "Xabarlar tarixini tozalash", okText: "Tozalash", danger: true})) return;
          try { const j = await api("/admin/messages/clean", {method: "POST"}); toast(j.messages + " ta xabar, " + j.history + " ta tarix tozalandi", "ok"); page(true); }
          catch (err) { toast(err.message, "error"); }
        }})), list, more);
      page(true);
    }

    function loadMedia() {
      const KL = {image: "Rasm", video: "Video", audio: "Audio", other: "Fayl"};
      const kind = h("select", {}, ...[["", "Barcha turlar"], ["image", "Rasmlar"], ["video", "Videolar"], ["audio", "Audio"], ["other", "Boshqa fayllar"]].map(([v, t]) => h("option", {value: v, text: t})));
      const size = h("select", {}, ...[["0", "Har qanday hajm"], ["1", "1 MB dan katta"], ["5", "5 MB dan katta"], ["20", "20 MB dan katta"]].map(([v, t]) => h("option", {value: v, text: t})));
      const who = h("input", {type: "text", class: "fld", placeholder: "@username", autocomplete: "off"});
      const info = h("div", {class: "mm-total"}), list = h("div", {}), more = h("button", {class: "btn ghost sm adm-more hidden", type: "button", text: "Yana yuklash"});
      const del = h("button", {class: "btn danger sm", type: "button", text: "Tanlanganlarni o'chirish", disabled: true});
      const all = h("button", {class: "btn ghost sm", type: "button", text: "Ko'ringanlarni belgilash"});
      const picked = new Set(), boxes = [];
      let next = 0, timer = null;
      const upd = () => { del.disabled = !picked.size; del.textContent = picked.size ? "O'chirish (" + picked.size + ")" : "Tanlanganlarni o'chirish"; };
      const row = it => {
        const ck = h("input", {type: "checkbox", class: "ck", "aria-label": "Tanlash"});
        const r = h("div", {class: "mrow"}, ck, h("div", {}, h("span", {class: "mk", text: it.kind === "e2e" ? "🔒 Shifrlangan" : (KL[it.kind] || "Fayl")}), "@" + it.username, h("div", {class: "ms", text: fmtDT(it.ts)})), h("span", {class: "sz", text: fmtSize(it.size)}));
        ck.addEventListener("change", () => { if (ck.checked) picked.add(it.id); else picked.delete(it.id); r.classList.toggle("on", ck.checked); upd(); });
        boxes.push([ck, it.id, r]); return r;
      };
      const page = async reset => {
        if (reset) { next = 0; list.textContent = ""; picked.clear(); boxes.length = 0; upd(); }
        const qs = new URLSearchParams({kind: kind.value, sender: who.value.trim(), min_mb: size.value, limit: "50"});
        if (next) qs.set("before", next);
        try {
          const j = await api("/admin/media?" + qs.toString());
          info.textContent = "Umumiy chatdagi media: " + j.totals.count + " ta, jami " + fmtSize(j.totals.size);
          j.items.forEach(it => list.append(row(it)));
          next = j.next; more.classList.toggle("hidden", !next);
          if (reset && !j.items.length) list.append(h("div", {class: "adm-empty", text: "Media topilmadi"}));
        } catch (err) { admErr(list, err); }
      };
      all.addEventListener("click", () => { boxes.forEach(([ck, id, r]) => { ck.checked = true; picked.add(id); r.classList.add("on"); }); upd(); });
      del.addEventListener("click", async () => {
        if (!picked.size) return;
        if (!await confirmDlg(picked.size + " ta media chatdan va serverdan butunlay o'chiriladi. Izohi bor xabarlarning matni qoladi.", {title: "Media o'chirish", okText: "O'chirish", danger: true})) return;
        try { const j = await api("/admin/media/delete", {method: "POST", body: {ids: [...picked]}}); toast(j.deleted + " ta media o'chirildi", "ok"); page(true); }
        catch (err) { toast(err.message, "error"); }
      });
      const again = () => { clearTimeout(timer); timer = setTimeout(() => page(true), 300); };
      kind.addEventListener("change", () => page(true)); size.addEventListener("change", () => page(true)); who.addEventListener("input", again);
      more.addEventListener("click", () => page(false));
      body.append(h("p", {class: "mm-note", text: "Fayllar diskda shifrlangan. Bu yerda fayl nomi va mazmuni ko'rsatilmaydi (adminga ham), lichka fayllari kirmaydi. Loglarga faqat o'chirilgan SON yoziladi."}),
        info, h("div", {class: "adm-filters"}, kind, size, who), h("div", {class: "adm-bar"}, all, del), list, more);
      page(true);
    }

    function loadReports() {
      const status = h("select", {}, h("option", {value: "open", text: "Ochiq shikoyatlar"}), h("option", {value: "closed", text: "Ko'rib chiqilganlar"}));
      const list = h("div", {}), more = h("button", {class: "btn ghost sm adm-more hidden", type: "button", text: "Yana yuklash"});
      let next = 0;
      const close = async (it, action) => {
        try { await api("/admin/reports/close", {method: "POST", body: {id: it.id, action}}); page(true); }
        catch (err) { toast(err.message, "error"); }
      };
      const card = it => {
        const c = h("div", {class: "rcard" + (it.status === "closed" ? " closed" : "")},
          h("div", {class: "rh"}, h("span", {text: fmtDT(it.ts) + " • #" + it.message_id}), h("span", {text: "@" + it.reporter + " → @" + it.target}),
            it.status === "closed" ? h("span", {class: "flag w", text: (it.action || "Yopilgan") + (it.by ? " (@" + it.by + ")" : "")}) : null),
          h("div", {class: "rt", text: it.text || (it.disclosed ? "(shikoyatchi matnni ochib bermadi)" : "(matnsiz)")}),
          it.reason ? h("div", {class: "rr", text: "Sabab: " + it.reason}) : null);
        if (it.disclosed) {
          const v = h("div", {class: "rv", text: "🔒 Xabar shifrlangan; matn — shikoyatchi ixtiyoriy ochib bergani. Tekshirilmoqda…"});
          c.append(v);
          (async () => {
            try {
              const env = E2E.parseEnvelope(it.cipher), key = env.k === "g" ? X.rooms.get(env.ep) : null;
              if (!key) { v.textContent = "🔒 Tekshirib bo'lmadi: bu xabar kaliti sizda yo'q (matn tasdiqlanmagan)."; return; }
              const senderPeer = await peer(it.target_id);
              const r = await E2E.openMessage(it.cipher, {sender: it.target_id, peer: null, key, signKey: senderPeer.sign});
              const ok = r.verified && typeof r.payload.t === "string" && r.payload.t === it.text;
              v.textContent = ok ? "✅ Matn asl shifrlangan xabarga mos (imzo tasdiqlandi)." : "⚠ Ochib berilgan matn asl xabarga MOS EMAS — soxta shikoyat bo'lishi mumkin!";
              v.classList.add(ok ? "ok" : "bad");
            } catch (_) { v.textContent = "⚠ Tekshirib bo'lmadi (shifrni ochishda xato)."; v.classList.add("bad"); }
          })();
        }
        if (it.status === "open") {
          const a = h("div", {class: "ra"});
          if (it.alive) a.append(h("button", {class: "btn danger sm", type: "button", text: "Xabarni o'chirish", onclick: () => close(it, "delete")}));
          a.append(h("button", {class: "btn ghost sm", type: "button", text: "Mute 10 daq", onclick: () => { if (wsSend({type: "cmd", text: "/mute " + it.target + " 10 shikoyat"})) close(it, "done"); }}),
            h("button", {class: "btn ghost sm", type: "button", text: "Ogohlantirish", onclick: () => { if (wsSend({type: "cmd", text: "/warn " + it.target + " shikoyat"})) close(it, "done"); }}),
            h("button", {class: "btn ghost sm", type: "button", text: "Rad etish", onclick: () => close(it, "dismiss")}));
          c.append(a);
        }
        return c;
      };
      const page = async reset => {
        if (reset) { next = 0; list.textContent = ""; }
        const qs = new URLSearchParams({status: status.value, limit: "30"}); if (next) qs.set("before", next);
        try {
          const j = await api("/admin/reports?" + qs.toString());
          j.items.forEach(it => list.append(card(it)));
          next = j.next; more.classList.toggle("hidden", !next);
          if (reset && !j.items.length) list.append(h("div", {class: "adm-empty", text: status.value === "open" ? "Ochiq shikoyat yo'q 🎉" : "Hech narsa yo'q"}));
        } catch (err) { admErr(list, err); }
      };
      status.addEventListener("change", () => page(true)); more.addEventListener("click", () => page(false));
      body.append(h("div", {class: "adm-filters"}, status), list, more); page(true);
    }

    async function loadMod() {
      let cfg;
      try { cfg = await api("/admin/modsettings"); } catch (err) { admErr(body, err); return; }
      const save = async patch => {
        try { cfg = await api("/admin/modsettings", {method: "POST", body: patch}); toast("Saqlandi", "ok"); }
        catch (err) { toast(err.message, "error"); }
      };
      const slow = h("select", {}, ...[[0, "O'chiq"], [5, "5 soniya"], [10, "10 soniya"], [30, "30 soniya"], [60, "1 daqiqa"], [300, "5 daqiqa"]].map(([v, t]) => h("option", {value: String(v), text: t})));
      if (![0, 5, 10, 30, 60, 300].includes(cfg.slowmode)) slow.append(h("option", {value: String(cfg.slowmode), text: cfg.slowmode + " soniya"}));
      slow.value = String(cfg.slowmode);
      const lock = h("input", {type: "checkbox"}); lock.checked = cfg.locked;
      lock.addEventListener("change", () => save({locked: lock.checked}));
      const e2eSection = () => {
        const box = h("div", {class: "msec"}, h("h4", {text: "🔐 Uchdan-uchga shifrlash (E2EE)"}));
        const info = h("p", {text: "Yuklanmoqda…"}); box.append(info);
        api("/admin/e2ee").then(st => {
          info.textContent = "Guruh kaliti avlodi: " + st.epoch + " • kalitli foydalanuvchilar: " + st.keyed_users + " • server o'qiy oladigan eski xabarlar: " + st.legacy_messages +
            ". Ban qilinganda kalit avtomatik yangilanadi, qo'lda ham yangilash mumkin.";
          box.append(h("div", {class: "ep-row"}, h("button", {class: "btn sm", type: "button", text: "Guruh kalitini yangilash", onclick: async () => {
            if (!X.rooms.has(X.epoch)) { toast("Sizda joriy guruh kaliti yo'q", "error"); return; }
            await rotateRoom("manual"); load();
          }})));
          if (S.me.role === "owner" && st.legacy_messages) box.append(h("div", {class: "ep-row"}, h("button", {class: "btn danger sm", type: "button", text: "Eski xabarlarni o'chirish (" + st.legacy_messages + ")", onclick: async () => {
            if (!await confirmDlg("Server o'qiy oladigan barcha eski xabarlar va ularning fayllari butunlay o'chadi. Qaytarib bo'lmaydi. Yangi (E2EE) xabarlarga tegilmaydi.", {title: "Eski xabarlarni o'chirish", okText: "O'chirish", danger: true})) return;
            try { const j = await api("/admin/e2ee/purge-legacy", {method: "POST"}); toast(j.deleted + " ta eski xabar o'chirildi", "ok"); load(); } catch (err) { toast(err.message, "error"); }
          }})));
        }).catch(err => { info.textContent = err.message; });
        return box;
      };
      body.append(
        h("div", {class: "msec"}, h("h4", {text: "🐢 Sekin rejim"}), h("p", {text: "Oddiy foydalanuvchilar umumiy chatga shuncha vaqtda bir marta yoza oladi. Adminlarga va lichkaga qo'llanmaydi."}),
          h("div", {class: "ep-row"}, slow, h("button", {class: "btn sm", type: "button", text: "Saqlash", onclick: () => save({slowmode: Number(slow.value)})}))),
        h("div", {class: "msec"}, h("h4", {text: "🔒 Chatni qulflash"}), h("p", {text: "Qulflanganda umumiy chatga faqat adminlar yoza oladi (lichka ishlayveradi)."}),
          h("label", {class: "tgl"}, h("span", {text: "Umumiy chat qulflangan"}), lock)),
        e2eSection(),
        h("div", {class: "msec"}, h("h4", {text: "🛡️ Avtomatik himoya"}), h("p", {text: "3 ta ogohlantirishdan keyin foydalanuvchi 1 soatga mute qilinadi. Spam (1 daqiqada 3 marta tezlik limitiga urilish) — 5 daqiqa avtomatik mute. Foydalanuvchi profilidagi Moderatsiya panelidan: ogohlantirish, xabarlarini tozalash, mute/ban."})));
    }

    load();
    return h("div", {}, pageHead(ADM_TITLES[initial] || "Admin"), body);
  });
  pg.adm = initial;
}

const BADGE_EMOJIS = "👑 ✅ ⭐ 🌟 💎 🔥 ⚡ 🚀 🛡️ 🏆 🎖️ 💜 ❤️ 💙 💚 🧡 😎 🤩 😈 👻 🦄 🐉 🦁 🐺 🦅 🌈 🌙 ☀️ ❄️ 🍀 🎯 🎨 🎧 🎮 💫 ✨ 🔱 ⚜️ 🧿 🪐 🍒 🍉 👾 🤖 🥇 📢 🎉 🌹 🦋 🐱 🐼 🍕".split(" ");
const BADGE_ANIMS = [["", "Yo'q"], ["pulse", "Puls"], ["bounce", "Sakrash"], ["spin", "Aylanish"], ["shake", "Silkinish"], ["float", "Suzish"], ["glow", "Nur"], ["flip", "Aylanma"], ["wave", "Silkitish"], ["rainbow", "Kamalak"]];

function hScroll(el) {
  el.addEventListener("wheel", e => { if (Math.abs(e.deltaY) > Math.abs(e.deltaX) && el.scrollWidth > el.clientWidth) { el.scrollLeft += e.deltaY; e.preventDefault(); } }, {passive: false});
  let down = false, moved = false, x0 = 0, s0 = 0;
  el.addEventListener("pointerdown", e => { if (e.pointerType !== "mouse") return; down = true; moved = false; x0 = e.clientX; s0 = el.scrollLeft; });
  el.addEventListener("pointermove", e => { if (!down) return; const dx = e.clientX - x0; if (Math.abs(dx) > 4) moved = true; if (moved) el.scrollLeft = s0 - dx; });
  const up = () => { down = false; };
  el.addEventListener("pointerup", up); el.addEventListener("pointerleave", up); el.addEventListener("pointercancel", up);
  el.addEventListener("click", e => { if (moved) { e.stopPropagation(); e.preventDefault(); moved = false; } }, true);
}
function onSwipe(el, fn) {
  let x0 = null, y0 = 0;
  el.addEventListener("touchstart", e => { const t = e.touches[0]; x0 = t.clientX; y0 = t.clientY; }, {passive: true});
  el.addEventListener("touchend", e => { if (x0 == null) return; const t = e.changedTouches[0], dx = t.clientX - x0, dy = Math.abs(t.clientY - y0); x0 = null; if (Math.abs(dx) > 50 && dy < 40) fn(dx < 0 ? 1 : -1); }, {passive: true});
}
function keepTabVisible(bar) {
  const on = bar.querySelector(".on"); if (!on || !bar.clientWidth) return;
  const l = on.offsetLeft, r = l + on.offsetWidth;
  if (l < bar.scrollLeft + 6) bar.scrollLeft = Math.max(0, l - 10);
  else if (r > bar.scrollLeft + bar.clientWidth - 6) bar.scrollLeft = r - bar.clientWidth + 10;
}

function badgeTabs() {
  const tabs = [{k: "std", label: "Emoji"}];
  if (EM.data) emojiTabs().filter(x => x.k !== "std").forEach(x => tabs.push(x));
  else { const l = Rich.emojiList(); if (l.length) tabs.push({k: "other", label: "Maxsus", items: l, icon: l[0]}); }
  return tabs;
}
function badgeEditor(t, onSaved, mid) {
  const base = () => t.id === S.me.id ? S.me : (U(t.id) || t);
  const cur = {badge: t.badge || "", anim: t.badge_anim || "", tab: "std"};
  const tabs = badgeTabs();
  const found = tabs.find(x => x.items && x.items.some(e => e.token === cur.badge)); if (found) cur.tab = found.k;
  const prev = h("div", {class: "bd-prev"}), bar = h("div", {class: "bd-tabs", role: "tablist"}), cap = h("div", {class: "ep-cap bd-cap"}),
    grid = h("div", {class: "bd-grid"}), anims = h("div", {class: "bd-anims"});
  const custom = h("input", {type: "text", class: "fld", maxlength: "16", placeholder: "Yoki o'z emojingizni yozing", autocomplete: "off", "aria-label": "O'z emojingiz"});
  hScroll(bar); hScroll(anims);
  const paintPrev = () => {
    const u = Object.assign({}, base(), {badge: cur.badge, badge_anim: cur.anim});
    prev.textContent = ""; prev.append(nameEl(u, {big: true}));
    if (!badge(u, true)) prev.append(h("small", {text: "  (nishon yo'q)"}));
  };
  const mark = () => {
    grid.querySelectorAll("button").forEach(x => x.classList.toggle("on", x.dataset.v === cur.badge));
    anims.querySelectorAll("button").forEach(x => x.classList.toggle("on", x.dataset.a === cur.anim));
    if (chk) chk.classList.toggle("on", cur.badge === "check");
  };
  const paint = () => { paintPrev(); mark(); };
  const pick = v => { cur.badge = v; custom.value = ""; paint(); };
  const paintGrid = dir => {
    grid.textContent = ""; grid.className = "bd-grid" + (dir ? " sl-" + dir : "");
    const c = tabs.find(x => x.k === cur.tab) || tabs[0];
    cap.textContent = c.k === "std" ? "Standart emojilar" : c.label + " • " + c.items.length + " ta";
    if (c.k === "std") BADGE_EMOJIS.forEach(e => { const b = h("button", {type: "button", text: e, "aria-label": e, onclick: () => pick(e)}); b.dataset.v = e; grid.append(b); });
    else if (!c.items.length) grid.append(h("div", {class: "ep-empty", text: "Bu to'plam hozircha bo'sh"}));
    else c.items.forEach(e => { const b = h("button", {type: "button", title: e.label || e.token, "aria-label": e.label || e.token, onclick: () => pick(e.token)}, Rich.chatEmoji(e.token, false)); b.dataset.v = e.token; grid.append(b); });
    mark();
  };
  const goTab = (k, dir) => {
    const i0 = tabs.findIndex(x => x.k === cur.tab), i1 = tabs.findIndex(x => x.k === k);
    cur.tab = k; bar.querySelectorAll("button").forEach(x => x.classList.toggle("on", x.dataset.k === k));
    keepTabVisible(bar); paintGrid(dir || (i1 > i0 ? "r" : "l"));
  };
  tabs.forEach(tb => {
    const b = h("button", {type: "button", role: "tab", class: tb.k === cur.tab ? "on" : "", title: tb.label, "aria-label": tb.label, onclick: () => goTab(tb.k)});
    if (tb.k === "std") b.textContent = "😀"; else if (tb.icon) b.append(Rich.chatEmoji(tb.icon.token, false)); else b.textContent = "📦";
    b.dataset.k = tb.k; bar.append(b);
  });
  onSwipe(grid, d => { const i = tabs.findIndex(x => x.k === cur.tab) + d; if (i >= 0 && i < tabs.length) goTab(tabs[i].k, d > 0 ? "r" : "l"); });
  BADGE_ANIMS.forEach(([k, n]) => { const b = h("button", {type: "button", text: n}); b.dataset.a = k; b.addEventListener("click", () => { cur.anim = k; paint(); }); anims.append(b); });
  custom.addEventListener("input", () => { const v = custom.value.trim(); if (v) { cur.badge = v; paint(); } });
  const chk = isStaff(t) ? null : h("button", {class: "bd-chip", type: "button", onclick: () => { cur.badge = "check"; cur.anim = ""; custom.value = ""; paint(); }}, "✔ Galochka");
  const clr = h("button", {class: "bd-chip", type: "button", onclick: () => { cur.badge = ""; cur.anim = ""; custom.value = ""; paint(); }}, isStaff(t) ? "Galochka (standart)" : "Olib tashlash");
  const hide = isStaff(t) ? h("button", {class: "bd-chip", type: "button", onclick: () => { cur.badge = "none"; cur.anim = ""; custom.value = ""; paint(); }}, "Yashirish") : null;
  const save = async () => {
    try {
      let u;
      if (t.id === S.me.id) u = (await api("/profile", {method: "PATCH", body: {badge: cur.badge, badge_anim: cur.anim}})).me;
      else u = (await api("/admin/badge", {method: "POST", body: {user_id: t.id, badge: cur.badge, anim: cur.anim}})).user;
      upsertUser(u); renderList(); renderHeader(); renderMessages(false);
      toast("Nishon saqlandi", "ok"); if (onSaved) onSaved(u);
      paintPrev();
    } catch (err) { toast(err.message, "error"); }
  };
  paintGrid(); paint();
  const root = h("div", {class: "bd"}, prev, mid || null, bar, cap, grid,
    h("div", {class: "bd-quick"}, chk, clr, hide),
    chk ? h("small", {class: "ep-cap", text: "Galochka foydalanuvchini admin qilmasdan beriladi."}) : null,
    h("div", {class: "bd-lab", text: "Animatsiya"}), anims, custom,
    h("div", {class: "bd-act"}, h("button", {class: "btn", type: "button", onclick: save}, "Saqlash")));
  root.repaint = paintPrev;
  requestAnimationFrame(() => keepTabVisible(bar));
  return root;
}

function lookSection() {
  let ed;
  const colors = colorSection(() => { if (ed) ed.repaint(); });
  ed = badgeEditor(S.me, null, colors);
  return h("div", {class: "setsec look"}, h("h4", {text: "Profil rangi va nishoni"}), ed);
}

const EM = {data: null, tab: "std", refresh: null};
const STD_EMOJIS = "😀 😃 😄 😁 😆 😅 😂 🤣 🙂 😉 😊 😇 🥰 😍 🤩 😘 😋 😛 😜 🤪 😎 🤓 🥳 😏 😒 😞 😔 😟 😕 🙁 😣 😖 😫 😩 🥺 😢 😭 😤 😠 😡 🤬 🤯 😳 🥵 🥶 😱 😨 😰 😥 😓 🤗 🤔 🤭 🤫 😶 😐 😑 😬 🙄 😯 😲 🥱 😴 🤤 😪 😵 🤐 🥴 🤢 🤮 🤧 😷 🤒 🤕 😈 👿 👹 👺 💀 👻 👽 🤖 💩 🙈 🙉 🙊 👍 👎 👌 ✌️ 🤞 🤟 🤘 👏 🙌 🙏 💪 👀 🧠 ❤️ 🧡 💛 💚 💙 💜 🖤 💔 💯 ✨ 🔥 ⚡ 🌈 ⭐ 🎉 🎁 🏆 🚀 💻 🔒 🔑 🛡️ ☕ 🍕 🍔 🍺".split(" ");

function emojiPerms() { return (EM.data && EM.data.perms) || {use: false, create: false, manage: false}; }
function emojiUsable(e) {
  const p = emojiPerms();
  if (p.manage) return true;
  const pk = e.pack != null ? EM.data.packs.find(x => x.id === e.pack) : null;
  return e.public !== false && (!pk || pk.public);
}
function syncEmojiBtn() { $("emojiBtn").classList.toggle("hidden", !emojiPerms().use); if (!emojiPerms().use) closeEmojiPanel(); }
async function loadEmojis() {
  try {
    const r = await api("/emojis");
    EM.data = r;
    const pm = new Map((r.packs || []).map(x => [x.id, x]));
    Rich.setEmojis(r.emojis.map(e => { const pk = e.pack != null ? pm.get(e.pack) : null; return pk ? {...e, kind: pk.kind, scale: pk.scale} : e; }), true);
    syncEmojiBtn();
    if (S.active) renderMessages(false);
    renderList();
    if (!$("emojiPanel").classList.contains("hidden")) paintEmojiPanel();
    if (EM.refresh) EM.refresh();
    warmStickers();
  } catch (_) {}
}

const WARM = {done: new Set(), q: [], run: 0};
function warmStickers() {
  try {
    if (!EM.data || S.offline) return;
    const mine = new Set(EM.data.mine || []), urls = [];
    emojiTabs("sticker").forEach(t => (t.items || []).forEach(e => { const i = Rich.emojiList().find(x => x.token === e.token); if (i && i.url && !WARM.done.has(i.url)) urls.push(i.url); }));
    const seen = new Set(); urls.forEach(u => { if (!seen.has(u)) { seen.add(u); WARM.done.add(u); WARM.q.push(u); } });
    const pump = () => {
      while (WARM.run < 3 && WARM.q.length) {
        const u = WARM.q.shift(), im = new Image(); WARM.run++;
        const fin = () => { WARM.run--; (window.requestIdleCallback || (f => setTimeout(f, 60)))(pump); };
        im.onload = im.onerror = fin; im.decoding = "async"; im.src = u;
      }
    };
    (window.requestIdleCallback || (f => setTimeout(f, 300)))(pump);
  } catch (_) {}
}

function insertEmoji(text) {
  const s = inp.selectionStart == null ? inp.value.length : inp.selectionStart, e = inp.selectionEnd == null ? s : inp.selectionEnd;
  if (inp.value.length - (e - s) + text.length > inp.maxLength) { toast("Xabar juda uzun", "warn"); return; }
  inp.setRangeText(text, s, e, "end"); autosize();
  if (!COARSE) inp.focus({preventScroll: true});
}
function emojiPanelOpen() { return !$("emojiPanel").classList.contains("hidden"); }
function closeEmojiPanel() { $("emojiPanel").classList.add("hidden"); $("emojiBtn").classList.remove("on"); if (EM.typing) { EM.typing(); EM.typing = null; } }
function placeEmojiPanel() {
  const b = $("emojiBtn").getBoundingClientRect(), p = $("emojiPanel"), w = Math.min(344, innerWidth - 16);
  p.style.left = Math.max(8, Math.min(b.right - w, innerWidth - w - 8)) + "px";
  p.style.bottom = Math.max(8, innerHeight - b.top + 8) + "px";
}
function emojiTabs(seg, all) {
  const d = EM.data, st = seg === "sticker";
  const tabs = st ? [] : [{k: "std", label: "😀"}];
  const usable = d.emojis.filter(e => !e.builtin ? emojiUsable(e) : true);
  d.packs.forEach(pk => {
    if ((pk.kind === "sticker") !== st) return;
    if (st && !all && !(d.mine || []).includes(pk.id)) return;
    const items = usable.filter(e => e.pack === pk.id);
    if (items.length || (emojiPerms().manage && (!st || all))) tabs.push({k: "p" + pk.id, id: pk.id, label: pk.name, items, icon: items[0], kind: pk.kind || "emoji", scale: pk.scale || 100});
  });
  if (!st) {
    const loose = usable.filter(e => e.pack == null || !d.packs.some(pk => pk.id === e.pack));
    if (loose.length) tabs.push({k: "other", label: tabs.length > 1 ? "Boshqa" : "Emojilar", items: loose, icon: loose[0], kind: "emoji", scale: 100});
  }
  const mine = st ? [] : addedPacks();
  if (mine.length) {
    const head = st ? [] : [tabs[0]], rest = st ? tabs : tabs.slice(1);
    return [...head, ...rest.filter(t => mine.includes(t.k)), ...rest.filter(t => !mine.includes(t.k))];
  }
  return tabs;
}

function addedPacks() { try { const a = JSON.parse(localStorage.getItem("tc_added_packs") || "[]"); return Array.isArray(a) ? a : []; } catch (_) { return []; } }
function setAddedPacks(a) { try { localStorage.setItem("tc_added_packs", JSON.stringify(a)); } catch (_) {} }
function packOfToken(token) {
  if (EM.data) { const t = [...emojiTabs("emoji"), ...emojiTabs("sticker", true)].find(x => x.k !== "std" && (x.items || []).some(e => e.token === token)); if (t) return t; }
  const l = Rich.emojiList().filter(e => e.token); const own = l.find(e => e.token === token);
  return own ? {k: "other", label: "Emoji", items: l.map(e => ({token: e.token, label: e.label}))} : null;
}

function attachHoldPreview(grid, sel) {
  let timer = 0, shown = null, ov = null, sx = 0, sy = 0, down = null;
  const itemAt = (x, y) => { const el = document.elementFromPoint(x, y); return el && el.closest ? el.closest(sel) : null; };
  const tokenOf = it => it && it.dataset ? it.dataset.token : "";
  const show = it => {
    const t = tokenOf(it); if (!t || !Rich.isEmojiToken(t) || !Rich.hasInlineEmoji(t)) return;
    if (!ov) { ov = h("div", {class: "stk-prev"}); document.body.append(ov); requestAnimationFrame(() => ov && ov.classList.add("on")); }
    ov.textContent = ""; const im = Rich.chatEmoji(t, false); im.classList.add("pv"); ov.append(im);
    shown = it; grid._held = true; haptic(8);
  };
  const hide = () => { clearTimeout(timer); timer = 0; down = null; shown = null; if (ov) { const o = ov; ov = null; o.classList.remove("on"); setTimeout(() => o.remove(), 140); } };
  grid.addEventListener("pointerdown", e => {
    if (e.button > 0) return;
    const it = itemAt(e.clientX, e.clientY); if (!it) return;
    down = it; sx = e.clientX; sy = e.clientY; grid._held = false;
    clearTimeout(timer); timer = setTimeout(() => { timer = 0; if (down) show(down); }, 230);
  });
  grid.addEventListener("pointermove", e => {
    if (shown) { const it = itemAt(e.clientX, e.clientY); if (it && it !== shown) show(it); return; }
    if (timer && Math.hypot(e.clientX - sx, e.clientY - sy) > 10) { clearTimeout(timer); timer = 0; down = null; }
  });
  ["pointerup", "pointercancel", "pointerleave"].forEach(ev => grid.addEventListener(ev, hide));
  grid.addEventListener("contextmenu", e => { if (e.target.closest && e.target.closest(sel)) e.preventDefault(); });
  grid.addEventListener("click", e => { if (grid._held) { e.stopImmediatePropagation(); e.preventDefault(); grid._held = false; } }, true);
}

async function toggleStickerPack(pid, on, label) {
  try {
    await api("/emoji-packs/" + pid + "/mine", {method: on ? "PUT" : "DELETE"});
    await loadEmojis();
    toast(on ? "«" + (label || "To'plam") + "» stikerlari qo'shildi" : "«" + (label || "To'plam") + "» olib tashlandi", "ok");
    return true;
  } catch (err) { toast(err.message, "error"); return false; }
}
function openStickerStore() {
  if (!EM.data || !emojiPerms().use) return;
  openModal(() => {
    const all = emojiTabs("sticker", true).filter(t => t.items.length), mine = EM.data.mine || [];
    const list = h("div", {class: "sks-list"});
    if (!all.length) list.append(h("div", {class: "adm-empty", text: "Hozircha stiker to'plamlari yo'q"}));
    all.forEach(t => {
      const on = mine.includes(t.id);
      const pv = h("div", {class: "sks-pv"}); t.items.slice(0, 4).forEach(e => pv.append(Rich.chatEmoji(e.token, false)));
      list.append(h("div", {class: "sks-row"}, pv,
        h("div", {class: "sks-n"}, h("b", {text: t.label}), h("small", {text: t.items.length + " ta stiker" + (on ? " • qo'shilgan" : "")})),
        h("button", {class: "btn sm" + (on ? " ghost" : ""), type: "button", text: on ? "Olib tashlash" : "Qo'shish", onclick: async ev => {
          const b = ev.currentTarget; b.disabled = true;
          if (await toggleStickerPack(t.id, !on, t.label)) { if (S.modal) showModal(S.modal.build()); } else b.disabled = false;
        }})));
    });
    return h("div", {}, sheetHead("Stiker qo'shish", closeModal),
      h("div", {class: "em-dlg"}, h("small", {class: "emx-hint", text: "Qo'shgan to'plamlaringiz emoji tanlagichdagi «Stikerlar» bo'limida chiqadi. Istasangiz keyin olib tashlashingiz mumkin."}), list));
  }, false, false, false);
}
function openStickerPack(token) {
  const pk = packOfToken(token);
  if (!pk || !pk.items.length) return;
  const canUse = !!EM.data && emojiPerms().use;
  openModal(() => {
    const srv = pk.kind === "sticker" && pk.id != null;
    const added = srv ? ((EM.data && EM.data.mine) || []).includes(pk.id) : addedPacks().includes(pk.k);
    const grid = h("div", {class: "spk-grid" + (pk.kind === "sticker" ? " stk" : "")});
    const sendable = pk.kind === "sticker" && !!S.active && !S.offline;
    pk.items.forEach((e, ix) => {
      const im = Rich.chatEmoji(e.token, false); if (ix >= 9) im.loading = "lazy";
      const c = h("div", {class: "spk-it" + (e.token === token ? " cur" : "") + (sendable ? " sendable" : ""), title: e.label || e.token, role: sendable ? "button" : null, tabindex: sendable ? "0" : null}, im);
      c.dataset.token = e.token;
      if (sendable) {
        const go = () => { if (!canUse) { toast("Stiker yuborishga ruxsat yo'q", "warn"); return; } closeModal(); sendSticker(e.token); };
        c.addEventListener("click", go);
        c.addEventListener("keydown", ev => { if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); go(); } });
      }
      grid.append(c);
    });
    attachHoldPreview(grid, ".spk-it");
    const btn = h("button", {class: "spk-add" + (added ? " done" : ""), type: "button", onclick: async () => {
      if (srv) { if (await toggleStickerPack(pk.id, !added, pk.label) && S.modal) showModal(S.modal.build()); return; }
      const a = addedPacks();
      if (added) setAddedPacks(a.filter(k => k !== pk.k)); else setAddedPacks([pk.k, ...a.filter(k => k !== pk.k)]);
      toast(added ? "To'plam olib tashlandi" : "«" + pk.label + "» qo'shildi — emoji tanlagichda birinchi turadi", "ok");
      if (S.modal) showModal(S.modal.build());
    }}, added ? "✓ Qo'shilgan — olib tashlash" : (srv ? "Stiker qo'shish" : "Emoji qo'shish"), added ? null : h("span", {class: "spk-n", text: String(pk.items.length)}));
    return h("div", {class: "spk"},
      h("div", {class: "spk-head"}, h("span", {class: "spk-t", text: pk.label}), h("span", {class: "spk-c", text: pk.items.length + " ta"}),
        h("button", {class: "icon-btn", type: "button", onclick: closeModal, "aria-label": "Yopish"}, icon("close"))),
      grid, canUse ? btn : null);
  }, false, false, true);
}
function paintEmojiPanel(dir) {
  const panel = $("emojiPanel"), d = EM.data, perms = emojiPerms();
  if (!d) return;
  const hasStk = emojiTabs("sticker", true).length > 0;
  if (!hasStk) EM.seg = "emoji";
  const seg = EM.seg === "sticker" ? "sticker" : "emoji", isStk = seg === "sticker";
  const tabs = emojiTabs(seg);
  const tabKey = isStk ? "stab" : "tab";
  if (!tabs.some(t => t.k === EM[tabKey])) EM[tabKey] = isStk ? (tabs[0] ? tabs[0].k : "") : (tabs.length > 1 ? tabs[1].k : "std");
  const oldBar = panel.querySelector(".ep-tabs"), keep = oldBar ? oldBar.scrollLeft : 0;
  panel.textContent = "";
  const go = (k, dr) => {
    const i0 = tabs.findIndex(x => x.k === EM[tabKey]), i1 = tabs.findIndex(x => x.k === k);
    EM[tabKey] = k; paintEmojiPanel(dr || (i1 > i0 ? "r" : "l"));
  };
  const bar = h("div", {class: "ep-tabs", role: "tablist"});
  tabs.forEach(t => {
    const b = h("button", {type: "button", class: t.k === EM[tabKey] ? "on" : "", title: t.label, "aria-label": t.label, role: "tab"});
    if (t.k === "std") b.textContent = t.label; else if (t.icon) b.append(Rich.chatEmoji(t.icon.token, false)); else b.textContent = "📦";
    b.addEventListener("click", () => go(t.k));
    bar.append(b);
  });
  hScroll(bar);
  const cur = tabs.find(t => t.k === EM[tabKey]) || tabs[0];
  const sc = ((cur && cur.scale) || 100) / 100;
  const img = Math.round(Math.min(isStk ? 110 : 56, (isStk ? 64 : 32) * sc)), cell = Math.max(isStk ? 84 : 42, img + (isStk ? 18 : 10));
  const cap = h("div", {class: "ep-cap2", text: !cur ? "" : cur.k === "std" ? "Standart emojilar" : cur.label + " • " + cur.items.length + " ta" + (isStk ? " • stiker" : "")});
  const grid = h("div", {class: "ep-grid" + (isStk ? " stk" : "") + (dir ? " sl-" + dir : "")});
  grid.style.setProperty("--cell", cell + "px"); grid.style.setProperty("--img", img + "px");
  if (!cur) grid.append(h("div", {class: "ep-empty", text: "Sizda stikerlar yo'q. «＋ Stiker qo'shish» tugmasi bilan to'plam qo'shing."}));
  else if (cur.k === "std") STD_EMOJIS.forEach(c => grid.append(h("button", {type: "button", text: c, "aria-label": c, onclick: () => insertEmoji(c)})));
  else if (!cur.items.length) grid.append(h("div", {class: "ep-empty", text: "Bu to'plam hozircha bo'sh"}));
  else cur.items.forEach(e => {
    const im = Rich.chatEmoji(e.token, false); if (isStk && cur.items.indexOf(e) >= 12) im.loading = "lazy";
    const b = h("button", {type: "button", title: e.token, "aria-label": e.label, onclick: () => isStk ? sendSticker(e.token) : insertEmoji(e.token)}, im);
    b.dataset.token = e.token; grid.append(b);
  });
  attachHoldPreview(grid, "button[data-token]");
  onSwipe(grid, dd => { const i = tabs.findIndex(x => x.k === EM[tabKey]) + dd; if (i >= 0 && i < tabs.length) go(tabs[i].k, dd > 0 ? "r" : "l"); });
  if (hasStk) {
    const sg = h("div", {class: "ep-seg"},
      h("button", {type: "button", class: isStk ? "" : "on", text: "Emoji", onclick: () => { EM.seg = "emoji"; paintEmojiPanel(); }}),
      h("button", {type: "button", class: isStk ? "on" : "", text: "Stikerlar", onclick: () => { EM.seg = "sticker"; paintEmojiPanel(); }}));
    panel.append(sg);
  }
  panel.append(bar, cap, grid);
  if (isStk) {
    const sf = h("div", {class: "ep-foot"}, h("button", {class: "btn ghost", type: "button", text: "＋ Stiker qo'shish", onclick: () => { closeEmojiPanel(); openStickerStore(); }}));
    if (cur && cur.id != null) sf.append(h("button", {class: "btn ghost", type: "button", text: "✕ Olib tashlash", onclick: async () => { if (await toggleStickerPack(cur.id, false, cur.label)) paintEmojiPanel(); }}));
    panel.append(sf);
  }
  bar.scrollLeft = keep; keepTabVisible(bar);
  if (perms.create || perms.manage) {
    const foot = h("div", {class: "ep-foot"});
    if (perms.create) foot.append(h("button", {class: "btn ghost", type: "button", text: "＋ Emoji yaratish", onclick: () => { closeEmojiPanel(); openEmojiCreate(); }}));
    if (perms.manage) foot.append(h("button", {class: "btn ghost", type: "button", text: "📦 ZIP to'plam", onclick: () => { closeEmojiPanel(); openEmojiZip(); }}));
    if (perms.manage) foot.append(h("button", {class: "btn ghost", type: "button", text: "⚙ Boshqarish", onclick: () => { closeEmojiPanel(); openAdmin("emoji"); }}));
    panel.append(foot);
  }
}

async function sendSticker(token) {
  if (!S.active || S.sending) return;
  if (S.editing) { toast("Tahrirlash paytida stiker yuborib bo'lmaydi", "warn"); return; }
  if (S.active.kind === "dm" && U(S.active.uid).deleted) { toast("Bu akkaunt o'chirilgan. Xabar yuborib bo'lmaydi", "error"); return; }
  S.sending = true;
  try {
    const payload = {t: token};
    if (S.replying) payload.r = S.replying;
    const pend = Pend.add(S.active, {kind: "text", text: token});
    cancelReply(); haptic(8);
    Pend.go(pend, async p => withTarget({type: "send", cid: p.cid, e2e: await sealFor(await keyForTarget(p.target), payload)}, p.target));
  } catch (err) { toast(err.message, "error"); }
  S.sending = false;
}
function toggleEmojiPanel() {
  if (emojiPanelOpen()) { closeEmojiPanel(); return; }
  if (!EM.data || !emojiPerms().use) return;
  paintEmojiPanel(); placeEmojiPanel();
  $("emojiPanel").classList.remove("hidden"); $("emojiBtn").classList.add("on");
  if (!EM.typing) EM.typing = Typing.hold("emoji");
  const eb = $("emojiPanel").querySelector(".ep-tabs"); if (eb) keepTabVisible(eb);
}
$("emojiBtn").addEventListener("mousedown", e => e.preventDefault());
$("emojiPanel").addEventListener("mousedown", e => { if (!e.target.closest("input,select,textarea")) e.preventDefault(); });
$("emojiBtn").addEventListener("click", toggleEmojiPanel);
document.addEventListener("click", e => {
  if (!emojiPanelOpen()) return;
  const path = e.composedPath ? e.composedPath() : [];
  if (path.includes($("emojiPanel")) || path.includes($("emojiBtn"))) return;
  closeEmojiPanel();
});
document.addEventListener("keydown", e => { if (e.key === "Escape" && emojiPanelOpen()) { e.stopPropagation(); closeEmojiPanel(); } }, true);
addEventListener("resize", () => { if (emojiPanelOpen()) placeEmojiPanel(); });

function openEmojiCreate(back) {
  const d = EM.data;
  if (!d || !d.perms.create) { toast("Emoji yaratishga ruxsatingiz yo'q", "error"); return; }
  const admin = d.perms.manage;
  const st = {file: null, seq: 0, timer: 0, touched: false};
  openModal(() => {
    const pvImg = h("img", {alt: "", draggable: "false", class: "hidden"});
    const hint = h("div", {class: "em-hint", text: "Rasm tanlang: .png (oddiy emoji) yoki .gif (animatsiyali emoji). JPG va WEBP ham mumkin, 20 MB gacha"});
    const pv = h("div", {class: "em-pv"}, pvImg, hint);
    const pick = h("input", {type: "file", accept: ".png,.gif,image/png,image/gif,image/jpeg,image/webp", class: "offscreen"});
    const pickBtn = h("button", {class: "btn ghost", type: "button", text: "🖼 Rasm tanlash", onclick: () => pick.click()});
    const name = h("input", {type: "text", class: "fld", maxlength: "32", placeholder: "masalan: kulgi_1", autocomplete: "off", autocapitalize: "off", spellcheck: "false"});
    const bg = h("input", {type: "checkbox"});
    const bgRow = h("label", {class: "em-chk"}, bg, h("span", {text: "Orqa fonni olib tashlash (remove background)"}));
    const bgNote = h("small", {text: "JPG yoki shaffof bo'lmagan rasm uchun. Bir xil rangli fonda yaxshi ishlaydi."});
    const tolVal = h("b", {text: "30"});
    const tol = h("input", {type: "range", min: "5", max: "80", value: "30"});
    const tolRow = h("div", {class: "em-row hidden"}, h("label", {text: "Fon sezgirligi (kattaroq = ko'proq o'chadi)"}), h("div", {class: "em-range"}, tol, tolVal));
    const anim = h("select", {class: "fld"}, ...BADGE_ANIMS.map(([v, t]) => h("option", {value: v, text: t})));
    const animRow = h("div", {class: "em-row"}, h("label", {text: "Animatsiya"}), anim);
    const packSel = h("select", {class: "fld"}), pub = h("select", {class: "fld"}, h("option", {value: "true", text: "Hamma ishlata oladi"}), h("option", {value: "false", text: "Faqat adminlar"}));
    const fillPacks = sel => {
      packSel.textContent = ""; packSel.append(h("option", {value: "", text: "To'plamsiz"}));
      EM.data.packs.forEach(p => packSel.append(h("option", {value: String(p.id), text: p.name + (p.public ? "" : " (yopiq)")})));
      packSel.value = sel == null ? "" : String(sel);
    };
    fillPacks(EM.tab.startsWith("p") ? Number(EM.tab.slice(1)) : null);
    const newPack = h("button", {class: "btn ghost sm", type: "button", text: "＋ Yangi to'plam", onclick: async () => {
      const nm = await promptDlg("Yangi emoji to'plami", "To'plam nomi (2–24 belgi):", "", {okText: "Yaratish", placeholder: "masalan: Mem emojilar"});
      if (!nm) return;
      try { const r = await api("/emoji-packs", {method: "POST", body: {name: nm, public: true}}); await loadEmojis(); fillPacks(r.id); toast("To'plam yaratildi", "ok"); }
      catch (err) { toast(err.message, "error"); }
    }});
    packSel.addEventListener("change", () => { const p = EM.data.packs.find(x => String(x.id) === packSel.value); if (p) pub.value = String(p.public); });
    const go = h("button", {class: "btn", type: "button", text: "Emoji yaratish", disabled: true});
    const showAnim = () => { BADGE_ANIMS.forEach(([v]) => { if (v) pvImg.classList.remove("a-" + v); }); if (anim.value) pvImg.classList.add("a-" + anim.value); };
    anim.addEventListener("change", showAnim);

    const setBgState = r => {
      const locked = r.source_alpha || r.animated;
      bg.disabled = locked; bgRow.classList.toggle("off", locked);
      if (locked) bg.checked = false;
      bgNote.textContent = r.animated ? "Animatsiyali fayl: orqa fon o'chirilmaydi, animatsiya saqlanadi."
        : r.source_alpha ? "Bu rasm shaffof (PNG): orqa fon yo'q, shundayligicha qoladi."
        : "JPG yoki shaffof bo'lmagan rasm uchun. Bir xil rangli fonda yaxshi ishlaydi.";
      tolRow.classList.toggle("hidden", !bg.checked || locked);
      animRow.classList.toggle("hidden", !!r.animated);
    };
    const preview = async () => {
      if (!st.file) return;
      const my = ++st.seq; pv.classList.add("busy"); go.disabled = true;
      const fd = new FormData(); fd.append("file", st.file); fd.append("remove_bg", bg.checked ? "true" : "false"); fd.append("tolerance", tol.value);
      try {
        const r = await api("/emoji/preview", {method: "POST", body: fd});
        if (my !== st.seq) return;
        pvImg.src = r.image; pvImg.classList.remove("hidden"); showAnim(); setBgState(r);
        hint.textContent = r.bg_removed ? "Orqa fon olib tashlandi" : r.transparent ? "Shaffof fon saqlandi" : "Orqa fon bilan (xohlasangiz, yuqoridan olib tashlang)";
        go.disabled = false;
      } catch (err) {
        if (my !== st.seq) return;
        hint.textContent = err.message; if (!bg.checked) pvImg.classList.add("hidden");
        go.disabled = !bg.checked;
      } finally { if (my === st.seq) pv.classList.remove("busy"); }
    };
    const later = () => { clearTimeout(st.timer); st.timer = setTimeout(preview, 350); };
    pick.addEventListener("change", () => {
      const f = pick.files[0]; pick.value = ""; if (!f) return;
      if (f.size > 20 * 1024 * 1024) { toast("Rasm 20 MB dan oshmasligi kerak", "error"); return; }
      st.file = f; bg.checked = false; tolRow.classList.add("hidden");
      if (!st.touched) { const n = f.name.replace(/\.[^.]+$/, "").toLowerCase().replace(/[^a-z0-9_]+/g, "_").replace(/^_+|_+$/g, "").slice(0, 32); name.value = n.length >= 2 ? n : "emoji"; }
      preview();
    });
    name.addEventListener("input", () => { st.touched = true; });
    bg.addEventListener("change", () => { tolRow.classList.toggle("hidden", !bg.checked); preview(); });
    tol.addEventListener("input", () => { tolVal.textContent = tol.value; later(); });
    go.addEventListener("click", async () => {
      if (!st.file) { toast("Avval rasm tanlang", "error"); return; }
      go.disabled = true; go.textContent = "Yaratilmoqda…";
      const fd = new FormData();
      fd.append("file", st.file); fd.append("name", name.value); fd.append("anim", anim.value); fd.append("remove_bg", bg.checked ? "true" : "false");
      fd.append("tolerance", tol.value);
      if (admin) { fd.append("pack_id", packSel.value); fd.append("public", pub.value); }
      try {
        const r = await api("/emoji", {method: "POST", body: fd});
        toast("Emoji tayyor: :" + r.name + ":", "ok");
        await loadEmojis();
        if (back) back(); else closeModal();
      } catch (err) { toast(err.message, "error"); go.disabled = false; go.textContent = "Emoji yaratish"; }
    });
    return h("div", {}, sheetHead("Emoji yaratish", back || null),
      h("div", {class: "em-dlg"}, pv, pickBtn, pick,
        h("div", {class: "em-row"}, h("label", {text: "Emoji nomi (:nom: ko'rinishida yoziladi)"}), name),
        bgRow, bgNote, tolRow, animRow,
        admin ? h("div", {class: "em-two"}, h("div", {class: "em-row"}, h("label", {text: "To'plam"}), packSel, newPack), h("div", {class: "em-row"}, h("label", {text: "Kim ishlata oladi"}), pub)) : null,
        go));
  });
}

function openEmojiZip(back) {
  const d = EM.data;
  if (!d || !d.perms.manage) { toast("ZIP to'plam yaratish faqat adminlar uchun", "error"); return; }
  const st = {file: null, items: []};
  openModal(() => {
    const pick = h("input", {type: "file", accept: ".zip,application/zip,application/x-zip-compressed", class: "offscreen"});
    const pickBtn = h("button", {class: "btn ghost", type: "button", text: "📦 ZIP fayl tanlash", onclick: () => pick.click()});
    const hint = h("div", {class: "em-hint", text: "ZIP ichida PNG (oddiy emoji) va GIF (animatsiyali emoji) fayllar bo'lsin. Soni cheklanmagan, ZIP 50 MB gacha."});
    const packName = h("input", {type: "text", class: "fld", maxlength: "24", placeholder: "masalan: Mem emojilar", autocomplete: "off"});
    const pub = h("select", {class: "fld"}, h("option", {value: "true", text: "Hamma ishlata oladi"}), h("option", {value: "false", text: "Faqat adminlar"}));
    const kindSel = h("select", {class: "fld"}, h("option", {value: "emoji", text: "Emoji — matn ichida kichik"}), h("option", {value: "sticker", text: "Stiker — yakka, katta"}));
    const list = h("div", {class: "emz-list hidden"}), skipped = h("small", {class: "emz-skip"}), count = h("div", {class: "em-hint hidden"});
    const form = h("div", {class: "hidden"},
      h("div", {class: "em-two"}, h("div", {class: "em-row"}, h("label", {text: "To'plam nomi"}), packName), h("div", {class: "em-row"}, h("label", {text: "Kim ishlata oladi"}), pub)),
      h("div", {class: "em-row"}, h("label", {text: "To'plam turi"}), kindSel));
    const go = h("button", {class: "btn", type: "button", text: "To'plam yaratish", disabled: true});
    const NAME = /^[a-z0-9_]{2,32}$/;
    const check = () => {
      const used = new Map(); let n = 0, bad = false;
      st.items.forEach(it => { if (!it.on) return; n++; used.set(it.name, (used.get(it.name) || 0) + 1); });
      st.items.forEach(it => {
        const e = it.on && (!NAME.test(it.name) || used.get(it.name) > 1 || EM.data.emojis.some(x => x.token === ":" + it.name + ":"));
        it.row.classList.toggle("bad", !!e); if (e) bad = true;
      });
      count.textContent = n + " ta emoji tanlandi" + (bad ? " — qizil nomlarni to'g'rilang (2–32 belgi, a–z, 0–9, _; takrorlanmasin)" : "");
      go.disabled = !n || bad || packName.value.trim().length < 2;
    };
    const paint = r => {
      list.textContent = ""; st.items = [];
      r.items.forEach(x => {
        const it = {file: x.file, name: x.name, on: true};
        const chk = h("input", {type: "checkbox", checked: true, "aria-label": "Qo'shish"});
        const nm = h("input", {type: "text", class: "fld", maxlength: "32", value: x.name, autocomplete: "off", autocapitalize: "off", spellcheck: "false", "aria-label": "Emoji nomi"});
        chk.addEventListener("change", () => { it.on = chk.checked; check(); });
        nm.addEventListener("input", () => { nm.value = nm.value.toLowerCase().replace(/[^a-z0-9_]/g, "_"); it.name = nm.value; check(); });
        it.row = h("div", {class: "emz-row"}, chk, h("img", {src: x.image, alt: "", draggable: "false"}), h("div", {class: "emz-n"}, nm, h("small", {text: x.animated ? "GIF • animatsiyali" : "PNG • oddiy"})));
        st.items.push(it); list.append(it.row);
      });
      skipped.textContent = r.skipped.length ? "O'tkazib yuborildi: " + r.skipped.map(k => k.file + " (" + k.error + ")").join(", ") : "";
      list.classList.remove("hidden"); form.classList.remove("hidden"); count.classList.remove("hidden"); check();
    };
    pick.addEventListener("change", async () => {
      const f = pick.files[0]; pick.value = ""; if (!f) return;
      if (f.size > 12 * 1024 * 1024) { toast("ZIP 12 MB dan oshmasligi kerak", "error"); return; }
      st.file = f; hint.textContent = "Ochilmoqda…"; go.disabled = true;
      const fd = new FormData(); fd.append("file", f);
      try {
        const r = await api("/emoji-pack/zip-preview", {method: "POST", body: fd});
        hint.textContent = f.name + " — " + r.items.length + " ta emoji topildi";
        if (!packName.value) packName.value = f.name.replace(/\.zip$/i, "").replace(/[_]+/g, " ").slice(0, 24);
        paint(r);
      } catch (err) { hint.textContent = err.message; list.classList.add("hidden"); form.classList.add("hidden"); count.classList.add("hidden"); st.items = []; }
    });
    packName.addEventListener("input", () => { if (st.items.length) check(); });
    go.addEventListener("click", async () => {
      const sel = st.items.filter(i => i.on);
      go.disabled = true; go.textContent = "Yaratilmoqda…";
      const fd = new FormData();
      fd.append("file", st.file); fd.append("pack_name", packName.value); fd.append("public", pub.value); fd.append("kind", kindSel.value);
      fd.append("items", JSON.stringify(sel.map(i => ({file: i.file, name: i.name}))));
      try {
        const r = await api("/emoji-pack/zip", {method: "POST", body: fd});
        toast("«" + r.pack + "»: " + r.created.length + " ta emoji qo'shildi" + (r.failed.length ? ", " + r.failed.length + " tasi yaratilmadi" : ""), r.failed.length ? "warn" : "ok");
        await loadEmojis();
        if (back) back(); else closeModal();
      } catch (err) { toast(err.message, "error"); go.disabled = false; go.textContent = "To'plam yaratish"; }
    });
    return h("div", {}, sheetHead("Emoji to'plami (ZIP)", back || null),
      h("div", {class: "em-dlg"}, hint, pickBtn, pick, form, count, list, skipped, go));
  }, false, false, false);
}

const PK_KIND = {emoji: "Emoji", sticker: "Stiker"};
const packOf = id => EM.data && EM.data.packs.find(x => x.id === id);

function emojiEditStrip(e, after) {
  const d = EM.data;
  const pk = h("select", {class: "fld"}, h("option", {value: "", text: "To'plamsiz"}), ...d.packs.map(p => h("option", {value: String(p.id), text: p.name + " (" + PK_KIND[p.kind || "emoji"].toLowerCase() + ")"}))); pk.value = e.pack == null ? "" : String(e.pack);
  const pb = h("select", {class: "fld"}, h("option", {value: "true", text: "Hamma"}), h("option", {value: "false", text: "Faqat adminlar"})); pb.value = String(e.public);
  const an = h("select", {class: "fld", disabled: e.animated}, ...BADGE_ANIMS.map(([v, t]) => h("option", {value: v, text: t}))); an.value = e.anim || "";
  const save = async () => { try { await api("/emoji/" + e.id, {method: "PATCH", body: {anim: an.value, pack_id: pk.value ? Number(pk.value) : null, public: pb.value === "true"}}); toast("Saqlandi", "ok"); } catch (err) { toast(err.message, "error"); } await loadEmojis(); after && after(); };
  [pk, pb, an].forEach(x => x.addEventListener("change", save));
  const del = h("button", {class: "btn danger sm", type: "button", text: "O'chirish", onclick: async () => {
    if (!await confirmDlg(e.token + " emojisi o'chadi. Eski xabarlarda u oddiy matn bo'lib ko'rinadi.", {title: "Emojini o'chirish", okText: "O'chirish", danger: true})) return;
    try { await api("/emoji/" + e.id, {method: "DELETE"}); toast("Emoji o'chirildi", "ok"); } catch (err) { toast(err.message, "error"); }
    await loadEmojis(); after && after(true);
  }});
  return h("div", {class: "emx-edit"},
    h("div", {class: "emx-eh"}, Rich.chatEmoji(e.token, false), h("b", {text: e.token}), h("small", {text: (e.author || "—") + (e.animated ? " • animatsiyali fayl" : "")})),
    h("div", {class: "emx-ef"}, h("label", {text: "To'plam"}), pk, h("label", {text: "Kim ishlatadi"}), pb, h("label", {text: "Animatsiya"}), an), del);
}

function openEmojiEdit(id, back) {
  openModal(() => {
    const e = EM.data && EM.data.emojis.find(x => x.id === id);
    if (!e) { closeModal(); return h("div"); }
    return h("div", {}, sheetHead("Emoji", back || closeModal), h("div", {class: "em-dlg"}, emojiEditStrip(e, gone => { if (gone) (back || closeModal)(); else showModal(S.modal.build()); })));
  }, false, false, false);
}

function openPackWindow(pid, back) {
  const first = packOf(pid); if (!first) return;
  const st = {name: first.name, pub: first.public, kind: first.kind || "emoji", scale: first.scale || 100, sel: null};
  const done = () => { if (back) back(); else closeModal(); };
  openModal(() => {
    const d = EM.data, pk = packOf(pid);
    if (!pk) { done(); return h("div"); }
    const items = d.emojis.filter(e => !e.builtin && e.pack === pid);
    const isStk = st.kind === "sticker";

    const kindBtn = (k, t) => h("button", {type: "button", class: st.kind === k ? "on" : "", text: t, onclick: () => { st.kind = k; showModal(S.modal.build()); }});
    const nm = h("input", {type: "text", class: "fld", maxlength: "24", value: st.name, autocomplete: "off"}); nm.addEventListener("input", () => { st.name = nm.value; });
    const pb = h("select", {class: "fld"}, h("option", {value: "true", text: "Hamma uchun"}), h("option", {value: "false", text: "Faqat adminlar"})); pb.value = String(st.pub); pb.addEventListener("change", () => { st.pub = pb.value === "true"; });

    const prev = h("div", {class: "emx-prev"}), grid = h("div", {class: "ep-grid emx-grid" + (isStk ? " stk" : "")});
    const val = h("b", {class: "emx-val"});
    const paintSize = () => {
      const sc = st.scale / 100;
      val.textContent = st.scale + "%";
      const img = Math.round(Math.min(isStk ? 110 : 56, (isStk ? 64 : 32) * sc)), cell = Math.max(isStk ? 84 : 42, img + (isStk ? 18 : 10));
      grid.style.setProperty("--cell", cell + "px"); grid.style.setProperty("--img", img + "px");
      prev.textContent = "";
      const t = items[0]; if (!t) { prev.append(h("small", {text: "Ko'rinish uchun to'plamga emoji qo'shing"})); return; }

      const fit = inner => {
        if (!inner || !inner.isConnected || !prev.clientWidth) return;
        inner.style.transform = "none";
        const k = Math.min(1, (prev.clientWidth - 16) / (inner.offsetWidth || 1), (prev.clientHeight - 16) / (inner.offsetHeight || 1));
        inner.style.transform = k < 0.999 ? "scale(" + Math.max(0.2, k).toFixed(3) + ")" : "none";
      };
      const put = (...nodes) => { const inner = h("div", {class: "emx-fitin"}, ...nodes); prev.append(inner); fit(inner); requestAnimationFrame(() => fit(inner)); setTimeout(() => fit(inner), 150); };
      const mk = (solo, big) => { const i = Rich.chatEmoji(t.token, false); i.className = "ce" + (big ? " big" : "") + (solo ? " solo" : ""); i.style.setProperty("--es", String(sc)); i.addEventListener("load", () => fit(prev.firstElementChild)); return i; };
      if (isStk) put(h("div", {class: "emx-bub"}, h("div", {class: "btext bigemo bigemo-1 emx-stk"}, mk(false, true))), h("small", {text: "Chatda yakka yuborilganda shunday ko'rinadi (matn bilan aralashmaydi)"}));
      else put(h("div", {class: "emx-bub"}, h("div", {class: "btext emx-line"}, "Salom ", mk(), " qalaysan ", mk(), "?")), h("div", {class: "emx-bub"}, h("div", {class: "btext soloemo soloemo-1"}, mk(true))), h("small", {text: "Matn ichida va yakka yuborilganda"}));
    };
    const rng = h("input", {type: "range", min: "50", max: "200", step: "5", value: String(st.scale), class: "emx-rng", "aria-label": "Hajm"});
    rng.addEventListener("input", () => { st.scale = Number(rng.value); paintSize(); });
    const step = dv => () => { st.scale = Math.max(50, Math.min(200, st.scale + dv)); rng.value = String(st.scale); paintSize(); };
    const size = h("div", {class: "emx-size"},
      h("div", {class: "emx-sh"}, h("span", {text: "Hajm"}), val, h("button", {class: "btn ghost sm", type: "button", text: "100%", onclick: () => { st.scale = 100; rng.value = "100"; paintSize(); }})),
      h("div", {class: "emx-sr"}, h("button", {class: "btn ghost sm", type: "button", text: "−", "aria-label": "Kichiklashtirish", onclick: step(-5)}), rng, h("button", {class: "btn ghost sm", type: "button", text: "＋", "aria-label": "Kattalashtirish", onclick: step(5)})));

    let edit = h("div");
    const paintEdit = () => { const e = items.find(x => x.id === st.sel); const n = e ? emojiEditStrip(e, gone => { if (gone) st.sel = null; showModal(S.modal.build()); }) : h("div"); edit.replaceWith(n); edit = n; };
    items.forEach(e => {
      const b = h("button", {type: "button", class: st.sel === e.id ? "on" : "", title: e.token, "aria-label": e.label, onclick: () => { st.sel = st.sel === e.id ? null : e.id; grid.querySelectorAll("button").forEach(x => x.classList.toggle("on", x.dataset.id === String(st.sel))); paintEdit(); }}, Rich.chatEmoji(e.token, false));
      b.dataset.id = String(e.id); grid.append(b);
    });
    if (!items.length) grid.append(h("div", {class: "ep-empty", text: "Bu to'plam hozircha bo'sh. «Emoji yaratish» yoki ZIP orqali qo'shing."}));
    if (st.sel != null && items.some(x => x.id === st.sel)) edit = emojiEditStrip(items.find(x => x.id === st.sel), gone => { if (gone) st.sel = null; showModal(S.modal.build()); });

    const savePack = h("button", {class: "btn", type: "button", text: "Saqlash", onclick: async () => {
      try { await api("/emoji-packs/" + pid, {method: "PATCH", body: {name: st.name, public: st.pub, kind: st.kind, scale: st.scale}}); toast("Saqlandi", "ok"); await loadEmojis(); done(); }
      catch (err) { toast(err.message, "error"); }
    }});
    const delPack = h("button", {class: "btn danger", type: "button", text: "To'plamni o'chirish", onclick: async () => {
      if (!await confirmDlg("«" + pk.name + "» to'plami o'chadi. Ichidagi emojilar o'chmaydi, to'plamsiz bo'lib qoladi.", {title: "To'plamni o'chirish", okText: "O'chirish", danger: true})) return;
      try { await api("/emoji-packs/" + pid, {method: "DELETE"}); toast("To'plam o'chirildi", "ok"); await loadEmojis(); done(); } catch (err) { toast(err.message, "error"); }
    }});
    paintSize();
    return h("div", {}, sheetHead(pk.name, done),
      h("div", {class: "em-dlg emx-win"},
        h("div", {class: "emx-seg"}, kindBtn("emoji", "Emoji"), kindBtn("sticker", "Stiker")),
        h("small", {class: "emx-hint", text: isStk ? "Stiker: faqat yakka yuboriladi, katta ko'rinadi. Tanlagichda alohida «Stikerlar» bo'limida turadi." : "Emoji: matn ichida kichik turadi. Yakka yuborilsa ham o'rtacha o'lchamda (katta qilinsa xira bo'ladi)."}),
        h("div", {class: "em-two"}, h("div", {class: "em-row"}, h("label", {text: "Nomi"}), nm), h("div", {class: "em-row"}, h("label", {text: "Kim ishlata oladi"}), pb)),
        h("div", {class: "emx-sticky"}, size, prev),
        h("div", {class: "ep-cap2", text: "Ichidagi emojilar • " + items.length + " ta (bosib tahrirlang)"}), grid, edit,
        h("div", {class: "emx-act"}, savePack, delPack)));
  }, false, false, false);
}

function emojiManager(body, alive) {
  const act = async (fn, okText) => { try { await fn(); if (okText) toast(okText, "ok"); } catch (err) { toast(err.message, "error"); } await loadEmojis(); };
  let q = "", usersOpen = false, newKind = "emoji";
  const reopen = () => openAdmin("emoji");
  const paint = () => {
    const d = EM.data;
    body.textContent = "";
    if (!d || !d.perms.manage) { body.append(h("div", {class: "adm-empty", text: "Yuklanmoqda…"})); return; }

    const mode = h("select", {class: "fld"}, h("option", {value: "off", text: "Faqat adminlar (va ruxsat berilganlar)"}), h("option", {value: "use", text: "Hamma ochiq emojilarni ishlatadi"}));
    mode.value = d.global;
    mode.addEventListener("change", () => act(() => api("/emoji-settings", {method: "PUT", body: {mode: mode.value}}), "Saqlandi"));
    const top = h("div", {class: "em-sec emx-top"}, h("div", {class: "emx-row"}, h("label", {text: "Oddiy foydalanuvchilar"}), mode),
      h("div", {class: "ep-row"}, h("button", {class: "btn sm", type: "button", text: "＋ Emoji", onclick: () => openEmojiCreate(reopen)}), h("button", {class: "btn sm", type: "button", text: "📦 ZIP to'plam", onclick: () => openEmojiZip(reopen)})));

    const packs = h("div", {class: "em-sec"}, h("h4", {text: "📦 To'plamlar (" + d.packs.length + ")"}));
    const plist = h("div", {class: "emx-plist"});
    d.packs.forEach(pk => {
      const its = d.emojis.filter(e => !e.builtin && e.pack === pk.id);
      const ic = h("span", {class: "emx-ic"}); if (its[0]) ic.append(Rich.chatEmoji(its[0].token, false)); else ic.textContent = "📦";
      plist.append(h("button", {class: "emx-pack", type: "button", onclick: () => openPackWindow(pk.id, reopen)}, ic,
        h("span", {class: "emx-pn"}, h("b", {text: pk.name}), h("small", {text: (pk.kind === "sticker" ? "Stiker" : "Emoji") + " • " + its.length + " ta • " + (pk.scale || 100) + "%" + (pk.public ? "" : " • yopiq")})),
        h("span", {class: "emx-badge " + (pk.kind === "sticker" ? "stk" : "emo"), text: pk.kind === "sticker" ? "STIKER" : "EMOJI"}), h("span", {class: "emx-go", text: "›"})));
    });
    if (!d.packs.length) plist.append(h("p", {class: "adm-note", text: "Hali to'plam yo'q."}));
    packs.append(plist);
    const newName = h("input", {type: "text", class: "fld", maxlength: "24", placeholder: "Yangi to'plam nomi", autocomplete: "off"});
    const kbox = h("div", {class: "emx-seg sm"});
    [["emoji", "Emoji"], ["sticker", "Stiker"]].forEach(([k, t]) => { const b = h("button", {type: "button", class: newKind === k ? "on" : "", text: t}); b.dataset.k = k; b.addEventListener("click", () => { newKind = k; kbox.querySelectorAll("button").forEach(x => x.classList.toggle("on", x.dataset.k === newKind)); }); kbox.append(b); });
    packs.append(h("div", {class: "emx-new"}, newName, kbox, h("button", {class: "btn sm", type: "button", text: "Yaratish", onclick: () => {
      if (!newName.value.trim()) return;
      act(() => api("/emoji-packs", {method: "POST", body: {name: newName.value, public: true, kind: newKind}}), "To'plam yaratildi");
    }})));

    const loose = d.emojis.filter(e => !e.builtin && (e.pack == null || !d.packs.some(pk => pk.id === e.pack)));
    const looseSec = h("div", {class: "em-sec"});
    if (loose.length) {
      looseSec.append(h("h4", {text: "🖼 To'plamsiz emojilar (" + loose.length + ")"}));
      const g = h("div", {class: "emx-cells"});
      loose.forEach(e => g.append(h("button", {type: "button", title: e.token, onclick: () => openEmojiEdit(e.id, reopen)}, Rich.chatEmoji(e.token, false))));
      looseSec.append(g);
    }

    const users = h("div", {class: "em-sec"}, h("button", {class: "emx-fold", type: "button", onclick: () => { usersOpen = !usersOpen; paint(); }}, h("span", {text: "👤 Foydalanuvchilar ruxsati"}), h("span", {text: usersOpen ? "▾" : "▸"})));
    if (usersOpen) {
      users.append(h("p", {class: "adm-note", text: "«Yaratadi» ruxsati olgan foydalanuvchi o'z emojisini yarata oladi. Adminlarda hammasi doim bor."}));
      const search = h("input", {type: "text", class: "fld", placeholder: "Nickname yoki @username", autocomplete: "off", value: q});
      const ulist = h("div", {});
      const fillUsers = () => {
        ulist.textContent = "";
        const t = q.trim().toLowerCase().replace(/^@/, "");
        const ms = S.members.filter(m => m.role === "user" && !m.deleted && (!t || (m.nickname || "").toLowerCase().includes(t) || (m.username || "").toLowerCase().includes(t))).slice(0, 60);
        if (!ms.length) ulist.append(h("div", {class: "adm-empty", text: "Hech kim topilmadi"}));
        ms.forEach(m => {
          const sel = h("select", {class: "fld"}, h("option", {value: "0", text: "Umumiy sozlama"}), h("option", {value: "1", text: "Ishlatadi"}), h("option", {value: "2", text: "Ishlatadi + yaratadi"}));
          sel.value = String((d.user_perms || {})[String(m.id)] || 0);
          sel.addEventListener("change", () => act(() => api("/emoji-perm/" + m.id, {method: "PUT", body: {perm: Number(sel.value)}}), "Ruxsat saqlandi"));
          ulist.append(h("div", {class: "em-urow"}, h("span", {text: m.nickname + " @" + m.username}), sel));
        });
      };
      search.addEventListener("input", () => { q = search.value; fillUsers(); });
      fillUsers();
      users.append(search, ulist);
    }
    body.append(top, packs, looseSec, users);
  };
  const refresh = () => {
    if (!body.isConnected || (alive && !alive())) { if (EM.refresh === refresh) EM.refresh = null; return; }
    paint();
  };
  EM.refresh = refresh;
  paint();
  if (!EM.data) loadEmojis();
}
function openBadgePicker(u, back) {
  const go = back || (() => openProfile(u.id));
  openModal(() => h("div", {}, sheetHead("Nishon: @" + u.username, go), h("div", {class: "sh-body"}, badgeEditor(U(u.id), go))), false);
}

function openInspector(tab) {
  openPage(() => {
    const st = {tab: tab || "flow"};
    const tabs = h("div", {class: "adm-tabs"}), body = h("div", {class: "adm-body enc"});
    const defs = [["flow", "Xabar yo'li"], ["server", "Server ko'radi"], ["keys", "Kalitlar"], ["limits", "Halol chegaralar"]];
    const paint = () => { tabs.textContent = ""; defs.forEach(([k, t]) => tabs.append(h("button", {type: "button", class: st.tab === k ? "on" : "", text: t, onclick: () => { st.tab = k; paint(); load(); }}))); };
    const load = () => { body.textContent = ""; ({flow: encFlow, server: encServer, keys: encKeys, limits: encLimits})[st.tab](body); };
    paint(); load();
    return h("div", {}, pageHead("🔒 Shifrlash: nima sodir bo'layapti?"), tabs, body);
  });
}
const mono = (t, cls) => h("div", {class: "enc-mono" + (cls ? " " + cls : ""), text: t});
const step = (n, title, ...kids) => h("div", {class: "enc-step"}, h("div", {class: "enc-n", text: String(n)}), h("div", {class: "enc-b"}, h("b", {text: title}), ...kids));
const shortId = s => s && s.length > 28 ? s.slice(0, 22) + "…" + s.slice(-6) : (s || "");

function encFlow(body) {
  const out = h("div", {});
  const inp2 = h("textarea", {class: "fld", rows: "2", maxlength: "200"}); inp2.value = "Salom! Bu sinov matni 🙂";
  const go = h("button", {class: "btn", type: "button", text: "Shifrlab ko'rish (yuborilmaydi)"});
  go.onclick = async () => {
    out.textContent = "";
    try {
      if (!S.active) throw new Error("Avval biror suhbatni oching (guruh yoki lichka) — kalit shu suhbatniki");
      const ctx = await keyForActive(), text = inp2.value.slice(0, 200);
      const env = await sealFor(ctx, {t: text}), t = E2E.trace[E2E.trace.length - 1];
      const dm = S.active.kind === "dm", p = dm ? await peer(S.active.uid) : null;
      const pkt = JSON.stringify(Object.assign({type: "send", e2e: env}, dm ? {to: S.active.uid} : {}));
      out.append(
        step(1, "Sizning matningiz (faqat qurilmangizda)", mono(t.plain), h("small", {text: "Uzunlik yashirilishi uchun " + t.plainBytes + " baytgacha to'ldiriladi."})),
        step(2, dm ? "Kalit: ikkingiz orasidagi ECDH kaliti" : "Kalit: guruh kaliti (avlod " + ctx.ep + ")",
          mono(dm ? "Sizning xavfsizlik raqamingiz: " + X.fp + "\n" + U(S.active.uid).nickname + ": " + p.fp : "Kalit ID: " + (X.keyIds.get(ctx.ep) || "?") + "  (kalitning o'zi emas, faqat belgisi)"),
          h("small", {text: dm ? "Bu kalit faqat sizning va suhbatdoshingizning maxfiy kalitlaridan hosil bo'ladi; server ikkalasini ham bilmaydi." : "Guruh kaliti serverda yo'q: har bir a'zo uchun uning ommaviy kaliti bilan o'ralgan nusxasi bor."})),
        step(3, "AES-256-GCM bilan shifrlash", mono("IV (tasodifiy): " + t.iv + "\nShifr: " + t.ctBytes + " bayt (shu jumladan 16 baytlik tekshiruv tegi)")),
        step(4, "ECDSA imzosi (yuboruvchi — siz)", mono(t.sigBytes + " bayt. Hech kim sizning nomingizdan soxta xabar yarata olmaydi.")),
        step(5, "Serverga ketadigan paket (ilova darajasida)", mono(shortId(pkt) === pkt ? pkt : pkt.slice(0, 90) + " … " + pkt.slice(-40), "net"),
          h("small", {text: "Mana shu — serverga boradigan hamma narsa: matn yo'q, faqat shifr. To'liq konvert:"}), mono(env, "net long")));
    } catch (err) { out.append(h("div", {class: "adm-empty", text: err.message})); }
  };
  const wire = h("div", {});
  const paintWire = () => {
    wire.textContent = "";
    const fr = SC.wire.slice(-4).reverse();
    if (!fr.length) wire.append(h("div", {class: "adm-empty", text: "Hozircha kadr yo'q"}));
    fr.forEach(f => wire.append(h("div", {class: "enc-frame"},
      h("b", {text: (f.dir === "→" ? "Siz → server" : "server → siz") + " • " + new Date(f.ts).toLocaleTimeString() + " • " + f.bytes + " belgi"}),
      h("small", {text: "Server (kanal ochilgach) ko'radigan ilova JSON'i:"}), mono(f.app, "net"),
      h("small", {text: "Tarmoqda (Chrome Network, Wireshark) ko'rinadigani:"}), mono(f.net + "…", "net"))));
  };
  paintWire();
  body.append(
    h("p", {class: "adm-note", text: "Xabaringiz brauzeringizda shifrlanadi va faqat shifr serverga boradi. Sinab ko'ring: matn kiriting — pastda shifrlash qadamlari haqiqiy kalitingiz bilan ko'rsatiladi (xabar yuborilmaydi)."}),
    inp2, go, out,
    h("h4", {class: "enc-h", text: "Tarmoqdagi oxirgi haqiqiy kadrlar"}),
    h("p", {class: "adm-note", text: "Ikki qatlam: tashqi — brauzer↔server kanali (Wireshark shuni ko'radi); ichki — xabar konverti, uni faqat suhbat a'zolari ocha oladi. Server kanalni ochadi, lekin konvertni ocha olmaydi."}),
    h("button", {class: "btn ghost sm", type: "button", text: "Yangilash", onclick: paintWire}), wire);
}

async function encServer(body) {
  body.append(h("div", {class: "adm-empty", text: "Serverdan so'ralmoqda…"}));
  let j;
  try { j = await api("/e2ee/server-view" + (S.active && S.active.kind === "dm" ? "?to=" + S.active.uid : "")); }
  catch (err) { body.textContent = ""; admErr(body, err); return; }
  body.textContent = "";
  const scope = j.scope === "group" ? "Umumiy chat" : "Lichka: " + (S.active ? U(S.active.uid).nickname : "");
  body.append(h("p", {class: "adm-note", text: scope + " — serverning o'z bazasidagi so'nggi qatorlar (server aynan shuni qaytardi). Chap tomonda — qurilmangizda ochilgan matn, o'ngda — server va admin ko'radigani."}));
  const mine = new Map(currentMsgs().map(m => [m.id, m]));
  if (!j.rows.length) body.append(h("div", {class: "adm-empty", text: "Bu suhbatda hali xabar yo'q"}));
  j.rows.forEach(r => {
    const local = mine.get(r.id);
    const you = local ? (local.locked ? "🔒 (kalit kutilmoqda)" : local.bad ? "⚠ (ochib bo'lmadi)" : (local.content || (local.image ? "📷 rasm" : local.file ? (local.file.voice ? "🎤 ovozli xabar" : local.file.vnote ? "📹 video xabar" : "📎 " + local.file.name) : ""))) : "(bu xabar yuklanmagan)";
    body.append(h("div", {class: "enc-row"},
      h("div", {class: "enc-rh"}, h("b", {text: "#" + r.id + " • @" + r.from}), h("span", {text: " • " + fmtDT(r.ts) + " • " + r.stored_bytes + " bayt" + (r.blob_bytes ? " • fayl " + fmtSize(r.blob_bytes) + " (shifrlangan)" : "") + (r.deleted ? " • o'chirilgan" : "") + (r.edited ? " • tahrirlangan" : "")}),
        r.e2e ? null : h("span", {class: "flag b", text: "ESKI: server o'qiy oladi"})),
      h("div", {class: "enc-cols"},
        h("div", {}, h("small", {text: "SIZ KO'RASIZ (qurilmada ochilgan)"}), h("div", {class: "enc-you", text: you})),
        h("div", {}, h("small", {text: "SERVER BAZASIDA"}), mono(r.stored, "net")),
        h("div", {}, h("small", {text: "ADMIN LOGIDA"}), mono(r.admin_sees, "net")))));
  });
  const li = arr => h("ul", {class: "enc-ul"}, ...arr.map(t => h("li", {text: t})));
  body.append(
    h("h4", {class: "enc-h", text: "Server biladi"}), li(j.knows.biladi),
    h("h4", {class: "enc-h", text: "Server bilmaydi"}), li(j.knows.bilmaydi),
    h("h4", {class: "enc-h", text: "Sizning yozuvingiz serverda"}),
    mono("Ommaviy kalit (ECDH): " + shortId(j.me.ecdh_pub) + "\nOmmaviy kalit (imzo): " + shortId(j.me.sign_pub) + "\nMaxfiy kalitlar zaxirasi: " + j.me.key_blob_bytes + " bayt, parolingiz kalitida shifrlangan — serverda ochib bo'lmaydi" +
      "\nGuruh kaliti (sizga o'ralgan nusxa): " + (j.room.my_wrap ? "avlod " + j.room.my_wrap.epoch + ", o'ragan: @" + (U(j.room.my_wrap.by).username || j.room.my_wrap.by) : "hali yo'q"), "net"),
    h("h4", {class: "enc-h", text: "Harakatlaringiz logi (adminga ko'rinadigan)"}),
    ...(j.activity.length ? j.activity.map(a => h("div", {class: "enc-act", text: fmtDT(a.ts) + " • " + a.ip + " • " + a.action + (a.detail ? " • " + a.detail : "")})) : [h("div", {class: "adm-empty", text: "Yozuv yo'q"})]),
    j.legacy_messages ? h("p", {class: "adm-note warn", text: "⚠ Bazada hali " + j.legacy_messages + " ta ESKI (E2EE'dan oldingi) xabar bor — ularni server o'qiy oladi. Ega ularni Moderatsiya bo'limidan o'chira oladi."}) : h("p", {class: "adm-note ok", text: "✅ Bazada server o'qiy oladigan xabar yo'q."}));
}

async function encKeys(body) {
  const cur = X.epoch;
  body.append(
    h("p", {class: "adm-note", text: "Barmoq izi — kalitingizning qisqa belgisi. Suhbatdoshingiz bilan uni boshqa kanalda (yuzma-yuz, telefon) solishtiring: mos kelsa, o'rtada hech kim yo'q."}),
    h("h4", {class: "enc-h", text: "Sizning barmoq izingiz"}), mono(X.fp || "—", "fp"),
    h("button", {class: "btn ghost sm", type: "button", text: "Nusxalash", onclick: () => copyText(X.fp)}),
    h("h4", {class: "enc-h", text: "Guruh kaliti"}),
    mono("Joriy avlod: " + (cur || "yo'q") + (X.rooms.has(cur) ? " • sizda bor • kalit ID: " + X.keyIds.get(cur) : " • sizda hali yo'q") + "\nSizda bor avlodlar: " + ([...X.rooms.keys()].join(", ") || "—")));
  const changed = [...X.changed.entries()];
  if (changed.length) {
    body.append(h("p", {class: "adm-note warn", text: "⚠ Quyidagi foydalanuvchilarning kaliti ilgari ko'rganingizdan FARQ QILADI. Bu server almashtirgan kalit bo'lishi mumkin. Barmoq izini tekshirmaguncha ularga yozmang."}));
    changed.forEach(([uid, c]) => body.append(h("div", {class: "enc-row"}, h("b", {text: "@" + U(uid).username}), mono("Avval: " + c.old + "\nHozir: " + c.now),
      h("button", {class: "btn danger sm", type: "button", text: "Yangi kalitni qabul qilish", onclick: () => { acceptKeyChange(uid); toast("Qabul qilindi", "ok"); renderHeader(); body.textContent = ""; encKeys(body); }}))));
  }
  body.append(h("h4", {class: "enc-h", text: "A'zolar barmoq izlari"}));
  const list = h("div", {}); body.append(list);
  const members = S.members.filter(m => m.ek && m.id !== S.me.id).slice(0, 80);
  for (const m of members) {
    try {
      const p = await peer(m.id);
      list.append(h("div", {class: "enc-mem"}, h("b", {text: m.nickname + " @" + m.username}), mono(p.fp + (p.changed ? "   ⚠ O'ZGARGAN" : ""), p.changed ? "bad" : "fp")));
    } catch (_) {}
  }
  if (!members.length) list.append(h("div", {class: "adm-empty", text: "Boshqa a'zo yo'q"}));
}

function encLimits(body) {
  const li = arr => h("ul", {class: "enc-ul"}, ...arr.map(t => h("li", {text: t})));
  body.append(
    h("p", {class: "adm-note", text: "Haqiqiy E2EE nimani kafolatlaydi va nimani kafolatlamaydi — halol ro'yxat:"}),
    h("h4", {class: "enc-h", text: "✅ Kafolat"}),
    li(["Server, hosting egasi va admin xabar matnini, fayl mazmunini va nomini o'qiy olmaydi: ular faqat shifrni ko'radi.",
        "Parolingiz serverga umuman bormaydi — faqat undan olingan qaytarib bo'lmaydigan kirish kaliti boradi. Maxfiy kalitlaringiz parol kalitida shifrlangan.",
        "Har bir xabar imzolangan: server yoki boshqa a'zo sizning nomingizdan soxta xabar yarata olmaydi.",
        "Ban qilingan a'zodan keyin guruh kaliti yangilanadi: u yangi xabarlarni o'qiy olmaydi."]),
    h("h4", {class: "enc-h", text: "⚠ Cheklovlar"}),
    li(["Guruhga qo'shilgan har kim (admin ham, agar a'zo bo'lsa) o'z qurilmasida xabarlarni ko'radi — bu ochiq guruh: ro'yxatdan o'tgan har kim kalit oladi.",
        "Server yashirincha SOXTA a'zo qo'shib, unga kalit o'ratishi mumkin. Himoya: «Kalitlar» bo'limida barmoq izlarini tekshiring; ilgari ko'rilgan kalit o'zgarsa, ogohlantirish chiqadi.",
        "Bu sahifaning kodini ham server beradi. Zararli server kodni almashtirishi mumkin: SRI faqat tashqi o'zgarishdan himoya qiladi. To'liq ishonch uchun kodni tekshiring yoki serverni o'zingiz yuriting.",
        "Metama'lumotlar ko'rinadi: kim, qachon, kimga (lichkada), xabar hajmi, IP. Profil (nickname, bio, rasm) ochiq.",
        "Parolni yo'qotsangiz, eski xabarlarni tiklab bo'lmaydi (kalit zaxirasi faqat parol bilan ochiladi).",
        "Lichkada «oldinga maxfiylik» yo'q (kalit doimiy). Shikoyat yuborganingizda faqat o'sha bitta xabar ixtiyoriy ochib beriladi."]));
}
$("encBtn").addEventListener("click", () => openInspector("flow"));

function openSettingsPage() {
  openPage(() => {
    const me = S.me, dark = document.documentElement.dataset.theme === "dark";
    const wrap = h("div", {}, pageHead("Sozlamalar"));
    wrap.append(h("button", {class: "set-card", type: "button", onclick: () => openProfile(me.id)},
      avatar(me, "m"), h("div", {class: "sc-t"}, h("b", {}, nameEl(me)), h("small", {text: "@" + me.username}))));
    wrap.append(gapEl(),
      setRow("user", "Mening akkauntim", openInfoPage),
      setRow("bell", "Bildirishnomalar va ovozlar", openNotifPage),
      setRow("battery", "Batareya va animatsiyalar", openAnimPage),
      setRow("edit", "Profil dizayni", () => openProfileEditor(S.me.id)),
      setRow("chat", "Chat sozlamalari", openChatStylePage),
      ...(amAdmin() ? [setRow("gear", "Server holati", openServerStatus)] : []),
      setRow("lock", "Maxfiylik va xavfsizlik", openPrivacyPage),
      setRow("emoji", "Reaksiya sozlamalari", openReactionSettings),
      setRow("speaker", "Karnay va kamera", openMediaPermPage),
      setRow("gear", "Qo'shimcha (Advanced)", openAdvancedPage),
      gapEl(),
      switchRow("moon", "Tungi mavzu", () => document.documentElement.dataset.theme === "dark", () => { toggleTheme(); }));
    wrap.append(gapEl(), setRow("logout", "Chiqish", () => { closeAllPages(); logout(); }, null, true));
    if (me.role !== "owner") wrap.append(setRow("trash", "Akkauntni o'chirish", deleteMyAccount, null, true));
    return wrap;
  }, true);
}

function openServerStatus() {
  openPage(p => {
    if (p._ss) { p._ss.stop(); }
    const fmtDur = sec => { sec = Math.max(0, Math.floor(sec)); const d = Math.floor(sec / 86400), hh = Math.floor(sec % 86400 / 3600), m = Math.floor(sec % 3600 / 60), ss = sec % 60;
      return (d ? d + " kun " : "") + (d || hh ? hh + " soat " : "") + (m || hh || d ? m + " daq " : "") + ss + " s"; };
    const pct = (a, b) => b ? Math.max(0, Math.min(100, a / b * 100)) : 0;
    const dash = "—";
    const mk = (title) => { const val = h("div", {class: "ss-v", text: dash}), sub = h("div", {class: "ss-s", text: ""}), bar = h("i"), track = h("div", {class: "ss-bar"}, bar);
      const el = h("div", {class: "ss-card"}, h("div", {class: "ss-t", text: title}), val, track, sub);
      return {el, val, sub, bar, track}; };
    const cards = {cpu: mk("Protsessor (CPU)"), mem: mk("Xotira (RAM)"), disk: mk("Disk"), ping: mk("Aloqa tezligi"), ws: mk("Jonli ulanishlar"), http: mk("So'rovlar"), db: mk("Baza (SQLite)"), up: mk("Ishlash vaqti")};
    ["ping", "ws", "http", "db", "up"].forEach(k => cards[k].track.classList.add("hidden"));
    const statePill = h("span", {class: "ss-pill", text: "Yuklanmoqda…"});
    const live = h("span", {class: "ss-live", text: "● jonli"});
    const spark = h("div", {class: "ss-spark"});
    const hist = [];
    const drawSpark = () => {
      if (hist.length < 2) return;
      const mx = Math.max(60, ...hist), pts = hist.map((v, i) => (i / (hist.length - 1) * 300).toFixed(1) + "," + (52 - v / mx * 48).toFixed(1)).join(" ");
      spark.innerHTML = '<svg viewBox="0 0 300 56" preserveAspectRatio="none"><polyline fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" vector-effect="non-scaling-stroke" points="' + pts + '"/></svg>';
    };
    const lvl = (el, v) => { el.classList.toggle("warn", v >= 70 && v < 90); el.classList.toggle("bad", v >= 90); };
    const note = h("p", {class: "adm-note", text: "Ko'rsatkichlar Render serverining o'zidan olinadi va har 2 soniyada yangilanadi. CPU — faqat shu ilova protsessi (1 yadro = 100%)."});
    const body = h("div", {class: "pg-body ss-body"},
      h("div", {class: "ss-top"}, statePill, live),
      h("div", {class: "ss-grid"}, cards.up.el, cards.ping.el, cards.cpu.el, cards.mem.el, cards.disk.el, cards.ws.el, cards.http.el, cards.db.el),
      h("div", {class: "ss-card ss-wide"}, h("div", {class: "ss-t", text: "Aloqa kechikishi (oxirgi 30 o'lchov, ms)"}), spark),
      note);
    const st = {on: true, busy: false, timer: 0, fails: 0, seen: false};
    const tick = async () => {
      if (!st.on) return;

      if (p.el && p.el.isConnected) st.seen = true;
      if (p.closing || (st.seen && !p.el.isConnected)) { stop(); return; }
      if (!st.seen) return;
      if (st.busy || document.hidden) return;
      st.busy = true;
      const t0 = performance.now();
      try {
        const d = await api("/admin/server-status");
        const rtt = performance.now() - t0; st.fails = 0;
        statePill.textContent = d.ok ? "✅ Server ishlayapti" : "⚠ Bazada muammo"; statePill.className = "ss-pill " + (d.ok ? "ok" : "bad");
        live.classList.remove("off");
        cards.up.val.textContent = fmtDur(d.uptime); cards.up.sub.textContent = "Versiya " + d.version + " • PID " + d.pid + " • oqimlar: " + d.threads;
        cards.ping.val.textContent = Math.round(rtt) + " ms"; cards.ping.val.className = "ss-v" + (rtt > 800 ? " bad" : rtt > 300 ? " warn" : "");
        cards.ping.sub.textContent = rtt > 800 ? "Juda sekin" : rtt > 300 ? "Sekinroq" : "Yaxshi";
        hist.push(Math.round(rtt)); if (hist.length > 30) hist.shift(); drawSpark();
        const c = d.cpu, cp = c.process_pct;
        cards.cpu.val.textContent = cp == null ? dash : cp.toFixed(1) + "%";
        cards.cpu.bar.style.width = Math.min(100, cp || 0) + "%"; lvl(cards.cpu.el, cp || 0);
        cards.cpu.sub.textContent = (c.load ? "Yuklama: " + c.load.map(x => x.toFixed(2)).join(" / ") + " • " : "") + c.cores + " yadro";
        const m = d.mem;
        if (m && m.total) { const pc = pct(m.used, m.total); cards.mem.val.textContent = fmtSize(m.used) + " / " + fmtSize(m.total); cards.mem.bar.style.width = pc + "%"; lvl(cards.mem.el, pc);
          cards.mem.sub.textContent = pc.toFixed(0) + "% band" + (m.process ? " • ilova: " + fmtSize(m.process) : ""); }
        else { cards.mem.val.textContent = m && m.process ? fmtSize(m.process) : dash; cards.mem.sub.textContent = "Ilova protsessi"; }
        const k = d.disk, dt = d.data || {};
        if (k) { const pc = pct(k.used, k.total); cards.disk.val.textContent = fmtSize(k.free) + " bo'sh"; cards.disk.bar.style.width = pc + "%"; lvl(cards.disk.el, pc);
          cards.disk.sub.textContent = "Ma'lumotlar: " + fmtSize(dt.total || 0) + " (baza " + fmtSize(dt.db || 0) + ", media " + fmtSize((dt.media || 0) + (dt.uploads || 0)) + ", emoji " + fmtSize(dt.emoji || 0) + ")"; }
        const w = d.ws; cards.ws.val.textContent = w.connections + " ulanish"; cards.ws.sub.textContent = "Onlayn: " + w.online + " • yashirin (away): " + w.away + " • eng ko'pi: " + w.peak;
        const r = d.http; cards.http.val.textContent = r.rps.toFixed(1) + " /s"; cards.http.sub.textContent = "Jami: " + r.total + " • xatolar (5xx): " + r.errors;
        const b = d.db; cards.db.val.textContent = b.ok ? b.ping_ms.toFixed(1) + " ms" : "XATO"; cards.db.val.className = "ss-v" + (b.ok ? "" : " bad");
        cards.db.sub.textContent = b.users + " foydalanuvchi • " + b.messages + " xabar • " + b.sessions + " sessiya";
      } catch (err) {
        if (err.message === "401") { stop(); return; }
        st.fails++; statePill.textContent = "❌ Server javob bermayapti"; statePill.className = "ss-pill bad"; live.classList.add("off");
      } finally { st.busy = false; }
    };
    const onVis = () => { if (!document.hidden && st.on) tick(); };
    const stop = () => { st.on = false; clearInterval(st.timer); document.removeEventListener("visibilitychange", onVis); };
    p._ss = {stop};
    st.timer = setInterval(tick, 2000);
    requestAnimationFrame(() => requestAnimationFrame(tick));
    document.addEventListener("visibilitychange", onVis);
    return h("div", {}, pageHead("Server holati"), body);
  });
}

function openInfoPage() {
  openPage(p => {
    const me = S.me;
    const avBox = h("div", {class: "tg-top inf-top"});
    const paintAvatar = () => {
      avBox.textContent = "";
      avBox.append(h("div", {class: "inf-av"}, avatar(S.me, "l"),
        h("button", {class: "inf-cam", type: "button", "aria-label": "Profil rasmini o'zgartirish", onclick: () => $("file").click()}, icon("camera"))));
    };
    paintAvatar();
    const gal = h("div", {class: "gal inf-gal"});
    const nick = h("input", {type: "text", class: "fld", maxlength: "24", "aria-label": "Nickname"}); nick.value = me.nickname;
    const bio = h("textarea", {class: "fld", rows: "3", maxlength: "140", placeholder: "O'zingiz haqingizda…", "aria-label": "Bio"}); bio.value = me.bio || "";
    const cnt = h("span", {class: "inf-cnt", text: String(140 - bio.value.length)});
    bio.addEventListener("input", () => { cnt.textContent = String(140 - bio.value.length); });
    const loadGallery = async () => {
      try {
        const j = await api("/avatars");
        gal.textContent = "";
        j.avatars.forEach(a => {
          const del = h("button", {type: "button", title: "O'chirish", "aria-label": "O'chirish"}, icon("close"));
          del.addEventListener("click", async e => { e.stopPropagation(); try { await api("/avatars/" + a.id, {method: "DELETE"}); loadGallery(); } catch (err) { toast(err.message, "error"); } });
          const g = h("div", {class: "gi" + (a.active ? " act" : ""), title: a.active ? "Faol rasm" : "Faollashtirish"}, h("img", {src: a.url, alt: ""}), del);
          g.addEventListener("click", async () => { if (a.active) return; try { await api("/avatars/" + a.id + "/use", {method: "POST"}); loadGallery(); } catch (err) { toast(err.message, "error"); } });
          gal.append(g);
        });
        if (j.avatars.some(a => a.active)) gal.append(h("button", {class: "btn ghost sm", type: "button", onclick: async () => { try { await api("/avatar/clear", {method: "POST"}); loadGallery(); } catch (err) { toast(err.message, "error"); } }}, "Rasmni olib tashlash"));
        setTimeout(paintAvatar, 500);
      } catch (_) {}
    };
    S.reloadGallery = loadGallery; loadGallery();
    const save = async btn => {
      btn.disabled = true;
      try {
        const j = await api("/profile", {method: "PATCH", body: {nickname: nick.value, bio: bio.value}});
        if (j && j.me) { upsertUser(j.me); renderList(); renderHeader(); renderMessages(false); }
        toast("Profil saqlandi", "ok");
      } catch (err) { toast(err.message, "error"); }
      btn.disabled = false;
    };
    p.refresh = paintAvatar;
    return h("div", {}, pageHead("Ma'lumot"), avBox, gal,
      h("div", {class: "inf-form"},
        h("label", {class: "fl"}, "Nickname", nick),
        h("div", {class: "fl"}, h("span", {class: "inf-lab"}, "Bio", cnt), bio, h("small", {class: "inf-hint", text: "Yosh, kasb yoki shahar kabi qisqa ma'lumot. Havola (https://…) va @username qo'ysangiz, profilingizda bosiladigan bo'ladi."})),
        h("div", {class: "tg-row copy", role: "button", tabindex: "0", title: "Nusxalash", onclick: () => copyText("@" + me.username)},
          h("div", {class: "tg-val", text: "@" + me.username}), h("div", {class: "tg-lab", text: "Username (o'zgarmaydi)"})),
        h("button", {class: "btn", type: "button", onclick: e => save(e.currentTarget)}, "Saqlash")),
      isStaff(me) ? h("div", {class: "inf-look"}, lookSection()) : null);
  });
}

const CS_ACCENTS = ["#3390ec", "#35b7f3", "#4f9a4a", "#d8579f", "#e0873a", "#9a78d9", "#d9534f", "#66799a", "#d9a63c"];
function openChatStylePage() {
  openPage(() => {
    const CS = window.ChatStyle, cur = CS.get(), acc = cur.accent || "#3390ec";
    const wrap = h("div", {}, pageHead("Chat sozlamalari"));
    const THEMES = [
      {k: "classic", t: "Klassik", bg: "#cfdde6", pi: "#ffffff", po: "#eeffde"},
      {k: "day", t: "Kunduzgi", bg: "#e3eaf1", pi: "#ffffff", po: acc},
      {k: "tinted", t: "Rangli", bg: "color-mix(in srgb," + acc + " 26%,#0b1118)", pi: "color-mix(in srgb," + acc + " 34%,#121a23)", po: "color-mix(in srgb," + acc + " 70%,#121a23)"},
      {k: "night", t: "Tungi", bg: "#0e1621", pi: "#182533", po: "#2b5278"},
    ];
    const grid = h("div", {class: "cs-themes", role: "radiogroup", "aria-label": "Mavzu"});
    THEMES.forEach(th => {
      const on = cur.style === th.k, tile = h("i", {class: "cs-tile"}, h("b", {class: "cs-b1"}), h("b", {class: "cs-b2"}), h("u", {class: "cs-rad"}));
      tile.style.setProperty("--pb", th.bg); tile.style.setProperty("--pi", th.pi); tile.style.setProperty("--po", th.po);
      const b = h("button", {class: "cs-th" + (on ? " on" : ""), type: "button", role: "radio", "aria-checked": String(on)}, tile, h("span", {text: th.t}));
      b.addEventListener("click", () => { CS.set({style: th.k}); repaintTopPage(); });
      grid.append(b);
    });
    const sws = h("div", {class: "swatches cs-sws"});
    CS_ACCENTS.forEach((c, i) => {
      const on = i === 0 ? !cur.accent : !!cur.accent && cur.accent.toLowerCase() === c;
      const b = h("button", {class: "sw" + (on ? " on" : ""), type: "button", "aria-label": i === 0 ? "Standart rang" : "Aksent rang " + c});
      b.style.background = c;
      b.addEventListener("click", () => { CS.set({accent: i === 0 ? null : c}); repaintTopPage(); });
      sws.append(b);
    });
    const colorIn = h("input", {type: "color", value: acc, "aria-label": "O'zingiz tanlagan rang"});
    colorIn.addEventListener("input", () => CS.set({accent: colorIn.value}));
    colorIn.addEventListener("change", () => repaintTopPage());
    sws.append(h("label", {class: "sw-custom", title: "O'zingiz tanlang"}, colorIn));

    // chat foni
    const fileIn = h("input", {type: "file", accept: "image/*", class: "hidden"});
    fileIn.addEventListener("change", async () => {
      const f = fileIn.files && fileIn.files[0]; fileIn.value = ""; if (!f) return;
      if (!/^image\//.test(f.type)) { toast("Rasm faylini tanlang", "error"); return; }
      if (f.size > 20 * 1048576) { toast("Rasm juda katta (20 MB gacha)", "error"); return; }
      try {
        const u = URL.createObjectURL(f), im = new Image();
        await new Promise((res, rej) => { im.onload = res; im.onerror = rej; im.src = u; });
        URL.revokeObjectURL(u);
        const k = Math.min(1, 1400 / Math.max(im.naturalWidth, im.naturalHeight)), c = document.createElement("canvas");
        c.width = Math.max(1, Math.round(im.naturalWidth * k)); c.height = Math.max(1, Math.round(im.naturalHeight * k));
        c.getContext("2d").drawImage(im, 0, 0, c.width, c.height);
        CS.setWallFile(c.toDataURL("image/jpeg", 0.78));
        toast("Chat foni o'zgartirildi", "ok"); repaintTopPage();
      } catch (_) { toast("Rasmni qo'yib bo'lmadi (xotira yetmadi yoki fayl buzuq)", "error"); }
    });
    const wps = h("div", {class: "cs-wps"});
    CS.WALLS.forEach(w => {
      const b = h("button", {class: "cs-wp" + (cur.wp === w.id ? " on" : ""), type: "button", "aria-label": "Chat foni: " + w.t, title: w.t});
      if (w.css) { b.style.backgroundImage = w.css; if (w.size) { b.style.backgroundSize = w.size; b.style.backgroundRepeat = w.rep; } else b.style.backgroundSize = "cover"; }
      else b.append(h("span", {text: "Aa"}));
      b.addEventListener("click", () => { CS.set({wp: w.id}); repaintTopPage(); });
      wps.append(b);
    });
    const fileUrl = CS.wallFile();
    if (fileUrl) {
      const b = h("button", {class: "cs-wp" + (cur.wp === "file" ? " on" : ""), type: "button", "aria-label": "Mening rasmim", title: "Mening rasmim"});
      b.style.backgroundImage = 'url("' + fileUrl + '")'; b.style.backgroundSize = "cover";
      b.addEventListener("click", () => { CS.set({wp: "file"}); repaintTopPage(); });
      wps.append(b);
    }
    wrap.append(secTitle("Mavzular"), grid, sws, gapEl(),
      secTitle("Chat foni (oboi)"), wps,
      setRow("file", "Fayldan tanlash", () => fileIn.click()),
      ...(cur.wp !== "none" ? [setRow("trash", "Fonni olib tashlash", () => { CS.set({wp: "none"}); repaintTopPage(); }, null, true)] : []),
      fileIn,
      h("p", {class: "tg-hint", text: "Mavzu, rang va chat foni faqat shu qurilmada saqlanadi. «Rangli» mavzu tanlangan aksent rangga moslashadi; «Kunduzgi» mavzuda o'zingiz yozgan xabarlar aksent rangda ko'rinadi."}));
    return wrap;
  });
}

function openAdvancedPage() {
  openPage(() => {
    const c = DL.cfg(), sup = DL.supported();
    const wrap = h("div", {}, pageHead("Qo'shimcha (Advanced)"));
    const pickRow = setRow("save", "Saqlash papkasi", async () => {
      if (!sup) { toast("Bu brauzer papka tanlashni qo'llamaydi", "error"); return; }
      try { const d = await DL.pick(); toast("Papka tanlandi: " + d.name, "ok"); repaintTopPage(); }
      catch (e) { if (!e || e.name !== "AbortError") toast("Bu papkani tanlab bo'lmadi. Yuklamalar/Ish stoli kabi tizim papkasining o'zini emas, ichidan yangi papka oching.", "error"); }
    }, sup ? "…" : "Qo'llanmaydi");
    const sv = pickRow.querySelector(".sv");
    const clearRow = setRow("trash", "Papkani olib tashlash", async () => { await DL.clear(); toast("Odatiy yuklash joyiga qaytildi", "info"); repaintTopPage(); }, null, true);
    clearRow.classList.add("hidden");
    DL.dir().then(d => { if (sv && sup) sv.textContent = d ? d.name : "Tanlanmagan"; if (d) clearRow.classList.remove("hidden"); });
    wrap.append(secTitle("Saqlash joyi"), pickRow, clearRow,
      h("p", {class: "tg-hint", text: sup
        ? "Fayl yoki rasmni «Saqlash (Save as)» qilsangiz, u avtomatik shu papkaga tushadi. Brauzer qayta ochilganda bir marta ruxsat so'rashi mumkin."
        : "Bu brauzer papka tanlashni qo'llab-quvvatlamaydi (kompyuterda Chrome yoki Edge kerak). Fayllar brauzerning odatiy yuklashlar papkasiga tushadi."}),
      gapEl(), secTitle("Avtomatik yuklash"),
      switchRow("dl", "Avtomatik yuklash", () => DL.cfg().on, on => { DL.set(on ? {on, since: Date.now()} : {on}); repaintTopPage(); },
        "Yoqilsa, chatga kirganingizda media va fayllar o'zi yuklanadi. Qaysi chatlarda ishlashini pastda alohida tanlang."));
    const per = h("div", {class: "cs-per" + (c.on ? "" : " off")},
      switchRow("user", "Shaxsiy chatlardan", () => DL.cfg().pm, on => { DL.set({pm: on}); }),
      switchRow("group", "Umumiy chatdan", () => DL.cfg().grp, on => { DL.set({grp: on}); }),
      switchRow("megaphone", "Kanallardan", () => DL.cfg().ch, on => { DL.set({ch: on}); }));
    const MBS = [2, 5, 10, 25, 50];
    wrap.append(per,
      setRow("file", "Eng katta hajm", () => { DL.set({mb: MBS[(MBS.indexOf(DL.cfg().mb) + 1) % MBS.length] || 10}); repaintTopPage(); }, c.mb + " MB"),
      h("p", {class: "tg-hint", text: "Avtomatik yuklashda: rasmlar chatda o'zi ochiladi, audio va video fayllar ijroga tayyorlanadi, boshqa fayllar (yoqilganidan keyin kelganlari) tanlangan papkaga o'zi tushadi. Papka tanlanmagan yoki ruxsat berilmagan bo'lsa, oddiy fayllar avtomatik saqlanmaydi. O'zingiz yuborgan xabarlar yuklanmaydi. Sozlamalar faqat shu qurilmada saqlanadi."}));
    return wrap;
  });
}

function openAnimPage() {
  openPage(() => {
    const AP = window.AnimPrefs;
    const sw = (ic, title, k, hint) => switchRow(ic, title, () => AP.on(k), on => { AP.set(k, on); }, hint);
    return h("div", {}, pageHead("Batareya va animatsiyalar"),
      sw("emoji", "Animatsion stikerlar", "stk",
        "O'chirilsa, stikerlar harakatlanmaydi — animatsiyasiz, oddiy rasm kabi ko'rinadi."),
      sw("emoji", "Animatsion emojilar", "emo",
        "O'chirilsa, animatsiyali emojilar harakatlanmaydi — oddiy emoji kabi ko'rinadi."),
      sw("battery", "Interfeys animatsiyalari", "ui",
        "O'chirilsa, oynalar, menyular, xabarlar va tugmalardagi animatsiyalar o'chiriladi."),
      h("p", {class: "tg-hint", text: "Animatsiyalarni o'chirish batareyani tejaydi va kuchsizroq qurilmalarda ilovani tezlashtiradi. Bu sozlamalar faqat shu qurilmada saqlanadi."}));
  });
}

function openNotifPage() {
  openPage(() => {
    const st = Push.state();
    const pushHint = !st.ok ? (st.why === "ios-install" ? "iPhone'da avval ilovani bosh ekranga o'rnating (Ulashish → Bosh ekranga qo'shish)." : "Bu brauzer bildirishnomalarni qo'llab-quvvatlamaydi.")
      : st.permission === "denied" ? "Bildirishnomalar brauzer sozlamalarida bloklangan. Sayt sozlamalaridan ruxsat bering."
      : "Yoqilsa, brauzer yopiq bo'lsa ham xabar keladi. Xabar matni bildirishnomada ko'rsatilmaydi.";
    return h("div", {}, pageHead("Bildirishnomalar va ovozlar"),
      switchRow("bell", "Bildirishnomalar", () => Push.state().on, async on => {
        if (on) { await Push.enable(api); toast("Bildirishnomalar yoqildi", "ok"); }
        else { await Push.disable(api); toast("Bu qurilmada bildirishnomalar o'chirildi", "info"); }
      }, pushHint),
      gapEl(),
      switchRow("speaker", "Xabar ovozi", sndOn, on => {
        try { localStorage.setItem(LS_SND, on ? "on" : "off"); } catch (_) {}
        if (on) ting(true);
      }, "Ilova ochiq bo'lganda boshqa suhbatga xabar kelsa qisqa ovoz chiqadi."));
  });
}

async function changePassword(oldPw, newPw) {
  if (!oldPw) throw new Error("Eski parolni kiriting");
  if (newPw.length < 6) throw new Error("Yangi parol kamida 6 belgi bo'lishi kerak");
  const info = await api("/me"), e = info.e2ee, un = S.me.username;
  const ko = await E2E.deriveFromPassword(un, oldPw, e.kdf_iter || E2E.KDF_DEFAULT);
  let ident; try { ident = await E2E.unwrapIdentity(e.key_blob, ko.kek, un); } catch (_) { throw new Error("Eski parol noto'g'ri"); }
  const kn = await E2E.deriveFromPassword(un, newPw, E2E.KDF_DEFAULT);
  await api("/password", {method: "POST", body: {old: ko.auth, new: kn.auth, key_blob: await E2E.wrapIdentity(ident, kn.kek, un), kdf_iter: E2E.KDF_DEFAULT}});
}

function fmtSpan(sec) {
  sec = Math.max(0, Math.floor(sec));
  const d = Math.floor(sec / 86400), hr = Math.floor(sec % 86400 / 3600), m = Math.floor(sec % 3600 / 60);
  if (d) return d + " kun " + hr + " soat";
  if (hr) return hr + " soat " + m + " daq";
  if (m) return m + " daqiqa";
  return "1 daqiqadan kam";
}

async function setPrivacy(patchObj) {
  S.priv = await api("/privacy", {method: "POST", body: patchObj});
}
function openPrivacyPage() {
  api("/privacy").then(j => { S.priv = j; const p = PG.list[PG.list.length - 1]; if (p && p.el.textContent.includes("Maxfiylik va xavfsizlik")) paintPage(p); }).catch(() => {});
  openPage(p => {
    p.refresh = null;
    return h("div", {}, pageHead("Maxfiylik va xavfsizlik"),
      secTitle("Kirish"),
      switchRow("lock", "Har kirishda login so'rash", () => !stayOn(), async () => { await toggleStay(); },
        "Yoqilsa, sahifa har safar ochilganda username va parol so'raladi. O'chirilsa, bu qurilmada login so'ralmasdan kirasiz — qurilmani begonalarga bermang."),
      gapEl(),
      secTitle("Ko'rinish"),
      switchRow("eye", "Last seen ni ko'rsatish", () => !(S.priv && S.priv.hide_seen), async on => { await setPrivacy({hide_seen: !on}); },
        "O'chirilsa, boshqalar oxirgi marta qachon onlayn bo'lganingizni ko'rmaydi («yaqinda onlayn bo'lgan» deb chiqadi). Onlayn holatingiz o'zgarmaydi."),
      switchRow("ghost", "Yashirin profil rejimi", () => !!(S.priv && S.priv.ghost), async on => { await setPrivacy({ghost: on}); },
        "Yoqilsa, siz doim oflayn ko'rinasiz: onlayn holat, last seen va «yozmoqda…» belgilari boshqalarga ko'rinmaydi. Siz xabarlarni odatdagidek yozasiz va o'qiysiz."),
      gapEl(),
      secTitle("Xabarlar"),
      switchRow("timer", "Xabarlarimni avtomatik o'chirish", () => !!(S.priv && S.priv.auto_del), async on => {
        if (on && !await confirmDlg("Shu paytdan boshlab yozgan xabarlaringiz 24 soatdan keyin hammada o'chib ketadi. Bu qaytarilmaydi.", {title: "Avtomatik o'chirish", okText: "Yoqish"})) return;
        await setPrivacy({auto_del: on});
      }, "Yoqilsa, shundan keyin yozgan xabarlaringiz 24 soatdan so'ng o'zi o'chadi. Yoqishdan oldingi xabarlarga tegilmaydi. Muddatidan oldin o'chirsangiz ham, yoqilgan va o'chirilgan vaqt orasida yozilgan xabarlar o'z vaqtida tozalanadi."),
      switchRow("ban", "Menga yozishni cheklash", () => !!(S.priv && S.priv.dm_closed), async on => { await setPrivacy({dm_closed: on}); },
        "Yoqilsa, sizga shaxsiy xabarni faqat admin yoza oladi. Siz o'zingiz yozgan odam esa sizga javob yoza oladi. O'chirilsa, hamma yoza oladi."),
      gapEl(),
      secTitle("Xavfsizlik"),
      setRow("key", "Parolni almashtirish", openChangePasswordPage),
      setRow("devices", "Ulangan qurilmalar", openDevicesPage),
      h("p", {class: "tg-hint", text: "Akkauntingizga qaysi qurilmalardan kirilganini ko'ring va keraklisini o'zingiz chiqarib yuboring."}));
  });
}

function openChangePasswordPage() {
  openPage(() => {
    const fld = (label, ac) => { const i = h("input", {type: "password", class: "fld", autocomplete: ac, maxlength: "128", "aria-label": label}); return {i, lab: h("label", {class: "fl"}, label, i)}; };
    const old = fld("Eski parol", "current-password"), nw = fld("Yangi parol (kamida 6 belgi)", "new-password"), rep = fld("Yangi parolni qayta kiriting", "new-password");
    const msg = h("p", {class: "tg-hint flat", role: "alert"});
    const btn = h("button", {class: "btn", type: "button", text: "Parolni almashtirish"});
    const submit = async () => {
      msg.textContent = ""; msg.style.color = "";
      const fail = t => { msg.textContent = t; msg.style.color = "var(--err)"; };
      if (!old.i.value) return fail("Eski parolni kiriting");
      if (nw.i.value.length < 6) return fail("Yangi parol kamida 6 belgi bo'lishi kerak");
      if (nw.i.value !== rep.i.value) return fail("Yangi parollar bir-biriga mos kelmadi");
      if (nw.i.value === old.i.value) return fail("Yangi parol eskisidan farq qilishi kerak");
      btn.disabled = true; btn.textContent = "Almashtirilmoqda…";
      try {
        await changePassword(old.i.value, nw.i.value);
        toast("Parol almashtirildi. Boshqa qurilmalardan chiqarildingiz", "ok");
        closePage();
      } catch (err) { fail(err.message); btn.disabled = false; btn.textContent = "Parolni almashtirish"; }
    };
    btn.addEventListener("click", submit);
    [old, nw, rep].forEach(f => f.i.addEventListener("keydown", e => { if (e.key === "Enter") submit(); }));
    return h("div", {}, pageHead("Parolni almashtirish"),
      h("div", {class: "inf-form"}, old.lab, nw.lab, rep.lab, msg, btn),
      h("p", {class: "tg-hint", text: "Parol almashtirilganda shifrlash kalitlaringiz yangi parol bilan brauzerda qayta o'raladi, boshqa barcha qurilmalar akkauntdan chiqariladi."}));
  });
}

function openDevicesPage() {
  openPage(p => {
    const box = h("div", {class: "dev-list"}, h("div", {class: "none", text: "Yuklanmoqda…"}));
    const load = async () => {
      try {
        const j = await api("/sessions");
        box.textContent = "";
        const cur = j.sessions.find(s => s.current), others = j.sessions.filter(s => !s.current);
        const item = s => h("div", {class: "dev-i"},
          icon(/iPhone|iPad|Android/.test(s.device) ? "phone" : "devices"),
          h("div", {class: "dev-t"},
            h("b", {text: s.device + (s.current ? " (shu qurilma)" : "")}),
            h("small", {text: "Kirgan: " + fmtDay(s.created)}),
            h("small", {text: s.online ? "Hozir onlayn" : "Oxirgi faollik: " + ago(s.last_active)}),
            h("small", {text: "Onlayn bo'lgan vaqt: " + fmtSpan(s.duration)})),
          s.current ? null : h("button", {class: "btn ghost sm", type: "button", onclick: async ev => {
            if (!await confirmDlg(s.device + " qurilmasi akkauntdan chiqariladi.", {title: "Qurilmani chiqarish", okText: "Chiqarish", danger: true})) return;
            ev.target.disabled = true;
            try { await api("/sessions/" + s.id, {method: "DELETE"}); toast("Qurilma chiqarildi", "ok"); } catch (err) { toast(err.message, "error"); }
            load();
          }}, "Chiqarish"));
        if (cur) box.append(secTitle("Hozirgi qurilma"), item(cur));
        box.append(secTitle("Boshqa qurilmalar", others.length));
        if (!others.length) box.append(h("div", {class: "none", text: "Boshqa qurilmalar ulanmagan"}));
        others.forEach(s => box.append(item(s)));
        if (others.length) box.append(h("div", {class: "tg-modwrap"}, h("button", {class: "btn danger sm", type: "button", onclick: async () => {
          if (!await confirmDlg("Hozirgisidan boshqa barcha qurilmalar akkauntdan chiqariladi.", {title: "Boshqa qurilmalardan chiqish", okText: "Hammasini chiqarish", danger: true})) return;
          try { await api("/sessions/revoke-others", {method: "POST"}); toast("Boshqa qurilmalar chiqarildi", "ok"); } catch (err) { toast(err.message, "error"); }
          load();
        }}, "Boshqa barcha qurilmalardan chiqish")));
      } catch (err) { box.textContent = ""; box.append(h("div", {class: "none", text: err.message})); }
    };
    p.refresh = null;
    load();
    const timer = setInterval(() => { if (!p.el.isConnected || p.closing) clearInterval(timer); else load(); }, 30000);
    return h("div", {}, pageHead("Ulangan qurilmalar"), box);
  });
}

function openReactionSettings() {
  openPage(() => {
    const mk = e => {
      const b = h("button", {class: "rx-opt" + (e === rxPrefs.emoji ? " on" : ""), type: "button", "aria-label": e}, rxGlyph(e));
      b.addEventListener("click", () => {
        rxPrefs.emoji = e; rxSave();
        pv.querySelectorAll(".rx-opt").forEach(x => x.classList.toggle("on", x === b));
        const r = b.getBoundingClientRect(); rxBurst(e, r.left + r.width / 2, r.top);
      });
      return b;
    };
    const pv = rxPackView(mk, {k: null}, "rx-grid");
    const grid = h("div", {class: "rx-gwrap" + (rxPrefs.dbl ? "" : " off")}, pv);
    return h("div", {}, pageHead("Reaksiya sozlamalari"),
      switchRow("emoji", "Ikki marta bosganda reaksiya", () => rxPrefs.dbl, on => { rxPrefs.dbl = on; rxSave(); grid.classList.toggle("off", !on); },
        "Xabar yoki post ustiga ketma-ket 2 marta bosilsa, pastdagi reaksiya qo'yiladi. O'chirilsa, reaksiyani xabar menyusidan tanlaysiz."),
      gapEl(),
      h("div", {class: "inf-form"}, h("div", {class: "sec-t flat"}, h("span", {text: "Ikki marta bosganda qo'yiladigan reaksiya"})), grid,
        h("p", {class: "tg-hint flat", text: "Bir xabarga bitta reaksiya qo'yiladi. Reaksiya ustiga bosib uni olib tashlash yoki almashtirish mumkin."})));
  });
}

const PERM_TXT = {granted: "Ruxsat berilgan", denied: "Bloklangan", prompt: "Hali so'ralmagan", unknown: "Noma'lum"};
async function permState(name) { try { return (await navigator.permissions.query({name})).state; } catch (_) { return "unknown"; } }
async function requestPerm(kind) {
  if (kind === "notifications") {
    if (!("Notification" in window)) throw new Error("Bu brauzer bildirishnomalarni qo'llab-quvvatlamaydi");
    const r = await Notification.requestPermission();
    if (r !== "granted") throw new Error("Ruxsat berilmadi");
    return;
  }
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) throw new Error("Bu brauzer kamera/mikrofonni qo'llab-quvvatlamaydi (yoki sahifa HTTPS emas)");
  try {
    const s = await navigator.mediaDevices.getUserMedia(kind === "camera" ? {video: true} : {audio: true});
    s.getTracks().forEach(t => t.stop());
  } catch (err) { throw new Error(err && err.name === "NotFoundError" ? "Bunday qurilma topilmadi" : "Ruxsat berilmadi. Brauzerning sayt sozlamalaridan ruxsat bering"); }
}
function openMediaPermPage() {
  openPage(() => {
    const perms = h("div", {}), devs = h("div", {});
    const defs = [["camera", "videocam", "Kamera", "camera"], ["microphone", "mic", "Mikrofon", "microphone"], ["notifications", "bell", "Bildirishnomalar", "notifications"]];
    const load = async () => {
      const rows = [];
      for (const [name, ic, label, kind] of defs) {
        const stt = await permState(name === "notifications" ? "notifications" : name);
        const granted = stt === "granted";
        rows.push(h("div", {class: "perm-i"}, icon(ic), h("div", {class: "perm-t"}, h("b", {text: label}), h("small", {class: "st-" + stt, text: PERM_TXT[stt] || PERM_TXT.unknown})),
          granted
            ? h("button", {class: "btn ghost sm", type: "button", onclick: () => confirmDlg("Brauzer ruxsatni sahifaning o'zidan olib tashlashga yo'l qo'ymaydi. Brauzerda: manzil satridagi qulf (yoki sozlamalar) belgisi → Sayt sozlamalari → «" + label + "» ni «Bloklash» yoki «So'rash» ga o'zgartiring.", {title: label + ": ruxsatni o'chirish", okText: "Tushunarli"})}, "O'chirish")
            : stt === "denied"
              ? h("button", {class: "btn ghost sm", type: "button", onclick: () => confirmDlg("Ruxsat brauzerda bloklangan. Qulf belgisi → Sayt sozlamalari → «" + label + "» ni «Ruxsat berish» ga o'zgartiring, so'ng sahifani yangilang.", {title: label + ": bloklangan", okText: "Tushunarli"})}, "Qanday?")
              : h("button", {class: "btn sm", type: "button", onclick: async () => { try { await requestPerm(kind); toast(label + ": ruxsat berildi", "ok"); } catch (err) { toast(err.message, "error"); } load(); }}, "Ruxsat berish")));
      }
      perms.textContent = ""; perms.append(...rows);
      devs.textContent = "";
      let list = [];
      try { list = navigator.mediaDevices && navigator.mediaDevices.enumerateDevices ? await navigator.mediaDevices.enumerateDevices() : []; } catch (_) {}
      const group = (kindName, ic, title) => {
        const items = list.filter(d => d.kind === kindName);
        devs.append(secTitle(title, items.length));
        if (!items.length) devs.append(h("div", {class: "perm-none", text: kindName === "audiooutput" ? "Brauzer karnaylar ro'yxatini ko'rsatmaydi (standart karnay ishlatiladi)" : "Qurilma topilmadi"}));
        items.forEach((d, i) => devs.append(h("div", {class: "tg-row"}, icon(ic), h("span", {text: d.label || (title.replace(/lar$/, "") + " " + (i + 1) + " (nomi ruxsatdan keyin ko'rinadi)")}))));
      };
      group("audioinput", "mic", "Mikrofonlar"); group("videoinput", "videocam", "Kameralar"); group("audiooutput", "speaker", "Karnaylar");
    };
    load();
    return h("div", {}, pageHead("Karnay va kamera"), secTitle("Ruxsatlar"), perms,
      h("p", {class: "tg-hint", text: "Kamera va mikrofon faqat ovozli yoki video xabar yozganingizda ishlatiladi."}), gapEl(), devs);
  });
}

async function deleteMyAccount() {
  const ok = await confirmDlg("Akkauntingiz butunlay o'chiriladi: profil, rasmlar va parol yo'qoladi. Yozgan xabarlaringiz chatda \"Deleted account\" nomi bilan qoladi. Buni qaytarib bo'lmaydi.",
    {title: "Akkauntni o'chirish", okText: "Davom etish", danger: true});
  if (!ok) return;
  const pw = await promptDlg("Parolni tasdiqlang", "Akkauntni o'chirish uchun parolingizni kiriting:", "", {type: "password", okText: "O'chirish", danger: true});
  if (pw === null) return;
  try {
    const e = (await api("/me")).e2ee, kd = await E2E.deriveFromPassword(S.me.username, pw, e.kdf_iter || E2E.KDF_DEFAULT);
    await api("/account/delete", {method: "POST", body: {password: kd.auth}}); showAuth("Akkauntingiz o'chirildi");
  }
  catch (err) { toast(err.message, "error"); }
}
const PRESETS = ["#f7b733", "#7b61ff", "#ef4444", "#f97316", "#22c55e", "#14b8a6", "#3b82f6", "#ec4899"];
function colorSection(onChange) {
  const sec = h("div", {class: onChange ? "bd-colors" : "setsec"}, onChange ? h("div", {class: "bd-lab", text: "Ism rangi"}) : h("h4", {text: "Profil rangi"}));
  const preview = onChange ? null : h("div", {class: "pname"}), sw = h("div", {class: "swatches"});
  if (preview) { preview.style.fontSize = "17px"; preview.style.margin = "0 0 10px"; }
  hScroll(sw);
  const save = async c => {
    try {
      const j = await api("/profile", {method: "PATCH", body: {color: c}});
      upsertUser(j.me); paint(); renderList(); renderHeader(); renderMessages(false);
      if (onChange) onChange();
      toast(c ? "Rang saqlandi" : "Standart rang tiklandi", "ok");
    } catch (err) { toast(err.message, "error"); }
  };
  const paint = () => {
    if (preview) { preview.textContent = ""; preview.append(nameEl(S.me, {big: true})); }
    sw.textContent = "";
    const cur = (S.me.color || "").toLowerCase();
    PRESETS.forEach(c => {
      const b = h("button", {type: "button", class: "sw" + (cur === c ? " on" : ""), title: c, "aria-label": c});
      b.style.background = c; b.addEventListener("click", () => save(c)); sw.append(b);
    });
    const pick = h("input", {type: "color"}); pick.value = HEX.test(cur) ? cur : TONES[S.me.role];
    pick.addEventListener("change", () => save(pick.value));
    sw.append(h("label", {class: "sw-custom", title: "Boshqa rang tanlash"}, pick),
      h("button", {type: "button", class: "btn ghost sm", text: "Standart", onclick: () => save("")}));
  };
  paint(); sec.append(...(preview ? [preview] : []), sw);
  return sec;
}
$("file").addEventListener("change", async () => {
  const f = $("file").files[0]; $("file").value = ""; if (!f) return;
  if (f.size > 2 * 1024 * 1024) { toast("Rasm 2 MB dan oshmasligi kerak", "error"); return; }
  const fd = new FormData(); fd.append("file", f);
  try { await api("/avatar", {method: "POST", body: fd}); toast("Profil rasmi yangilandi", "ok"); if (S.reloadGallery) S.reloadGallery(); }
  catch (err) { toast(err.message, "error"); }
});

const haptic = ms => { try { if (navigator.vibrate) navigator.vibrate(ms); } catch (_) {} };
document.addEventListener("touchstart", () => {}, {passive: true});

const NAV = {stack: [], ops: [], busy: false, timer: 0};
const NAV_CLOSE = {
  chat: () => closeChat(), modal: () => closeModal(), lb: () => closeLightbox(), avv: () => closeAvatarViewer(true),
  ctx: () => closeCtx(), sel: () => exitSelect(), dlg: () => { if (S.dlgCancel) S.dlgCancel(); },
  cm: () => Channels.closeComments(true),
  drawer: () => closeDrawerNow(),
  ...Object.fromEntries(Array.from({length: 12}, (_, i) => ["pg" + i, () => closePage()])),
};
function navKick() {
  while (!NAV.busy && NAV.ops.length) {
    const op = NAV.ops.shift();
    if (op.t === "push") { try { history.pushState({tc: op.d}, ""); } catch (_) {} }
    else {
      NAV.busy = true; clearTimeout(NAV.timer);
      NAV.timer = setTimeout(() => { NAV.busy = false; navKick(); }, 450);
      try { history.back(); } catch (_) { NAV.busy = false; }
    }
  }
}
function navPush(name) {
  if (NAV.stack.includes(name)) return;
  NAV.stack.push(name); NAV.ops.push({t: "push", d: NAV.stack.length}); navKick();
}
function navPop(name) {
  const i = NAV.stack.lastIndexOf(name); if (i < 0) return;
  const top = i === NAV.stack.length - 1;
  NAV.stack.splice(i, 1);
  if (top) { NAV.ops.push({t: "back"}); navKick(); }
}
function navReset() {
  const n = NAV.stack.length; NAV.stack.length = 0; NAV.ops.length = 0;
  if (n) try { history.go(-n); } catch (_) {}
}
addEventListener("popstate", e => {
  if (NAV.busy) { NAV.busy = false; clearTimeout(NAV.timer); navKick(); return; }
  const target = (e.state && e.state.tc) | 0;
  while (NAV.stack.length > target) { const fn = NAV_CLOSE[NAV.stack.pop()]; if (fn) fn(); }
});
try { if (history.state && history.state.tc) history.replaceState(null, ""); } catch (_) {}

const Composer = (() => {
  const vv = window.visualViewport;
  const root = document.documentElement;
  const touchy = () => COARSE || matchMedia("(max-width:760px)").matches || (navigator.maxTouchPoints || 0) > 0;
  const isField = el => !!el && (el.tagName === "TEXTAREA" || (el.tagName === "INPUT" && !/^(checkbox|radio|button|submit|reset|file|range|color|image)$/i.test(el.type)));
  const viewH = () => Math.round(vv ? vv.height : innerHeight);
  const viewTop = () => Math.round(vv ? vv.offsetTop : 0);
  let raf = 0;

  const sync = () => {
    raf = 0;
    if (!touchy() || (vv && vv.scale > 1.02)) {
      root.style.removeProperty("--vvh"); root.style.removeProperty("--vvt"); document.body.classList.remove("kb"); return;
    }
    const hgt = viewH();
    if (hgt >= 120) { root.style.setProperty("--vvh", hgt + "px"); root.style.setProperty("--vvt", viewTop() + "px"); }
    document.body.classList.toggle("kb", innerHeight - hgt > 120 && isField(document.activeElement));
    if (scrollY || document.scrollingElement && document.scrollingElement.scrollTop) scrollTo(0, 0);
    const b = $("msgs"); if (b && b._stick) b.scrollTop = b.scrollHeight;
  };
  const queue = () => { if (!raf) raf = requestAnimationFrame(sync); };

  const guard = () => {
    const chat = $("chat"), c = $("composer"), ta = $("inp");
    if (!chat || !c || !ta) return;
    sync();
    if (!S.active || !S.me) return;
    if (chat.classList.contains("hidden")) { chat.classList.remove("hidden"); $("empty").classList.add("hidden"); }
    if (S.active && isMobile() && !document.body.classList.contains("in-chat") && !PG.list.length) document.body.classList.add("in-chat");
    const gate = syncChatGate();
    if (!S.sel) chat.classList.remove("selecting");
    if (c.classList.contains("recording") && !S.rec && !S.recBusy && !S.starting) setRecUi("off");
    if (S.offline) { if (c.style.display) c.style.removeProperty("display"); return; }
    const gated = gate.chanRO || gate.dead || gate.locked || chat.classList.contains("selecting");
    if (gated) return;
    c.hidden = false; c.removeAttribute("aria-hidden");
    let r = c.getBoundingClientRect();
    const limit = viewTop() + viewH() + 2;
    if (!r.height || r.bottom > limit || r.top < 0) {
      root.style.setProperty("--vvh", viewH() + "px"); root.style.setProperty("--vvt", viewTop() + "px");
      [document.scrollingElement, document.body, $("main"), chat].forEach(e => { if (e && e.scrollTop) e.scrollTop = 0; });
      scrollTo(0, 0);
      void c.offsetHeight;
      r = c.getBoundingClientRect();
      if (!r.height) c.style.setProperty("display", "flex", "important");
    } else if (c.style.display) c.style.removeProperty("display");
    if (!c.classList.contains("recording") && ta.getBoundingClientRect().height < 20) { ta.style.height = ""; autosize(); }
  };

  if (vv) { vv.addEventListener("resize", queue); vv.addEventListener("scroll", queue); }
  addEventListener("resize", queue);
  addEventListener("orientationchange", () => { setTimeout(queue, 350); setTimeout(guard, 600); });
  addEventListener("pageshow", () => { queue(); setTimeout(guard, 50); setTimeout(guard, 500); });
  addEventListener("focus", () => setTimeout(guard, 80));
  addEventListener("online", () => setTimeout(guard, 80));
  document.addEventListener("visibilitychange", () => { if (!document.hidden) { queue(); setTimeout(guard, 60); setTimeout(guard, 500); setTimeout(guard, 1500); } });
  document.addEventListener("focusin", () => setTimeout(queue, 60));
  document.addEventListener("focusout", () => { setTimeout(queue, 120); setTimeout(queue, 500); setTimeout(guard, 700); });
  setInterval(() => { if (!document.hidden && S.active) guard(); }, 1500);
  queue();
  return {guard, sync};
})();

function longPress(el, fn) {
  let t = 0, sx = 0, sy = 0, quiet = 0;
  el.addEventListener("touchstart", e => {
    if (e.touches.length !== 1) return;
    sx = e.touches[0].clientX; sy = e.touches[0].clientY; clearTimeout(t);
    t = setTimeout(() => { quiet = Date.now() + 600; haptic(12); fn(sx, sy); }, 480);
  }, {passive: true});
  el.addEventListener("touchmove", e => { const p = e.touches[0]; if (Math.abs(p.clientX - sx) > 9 || Math.abs(p.clientY - sy) > 9) clearTimeout(t); }, {passive: true});
  ["touchend", "touchcancel"].forEach(ev => el.addEventListener(ev, () => clearTimeout(t), {passive: true}));
  el.addEventListener("click", e => { if (Date.now() < quiet) { e.preventDefault(); e.stopImmediatePropagation(); } }, true);
}

function canSwipeReply(m) {
  const c = $("chat");
  return !S.offline && !S.sel && !m.service && !m.locked && !m.bad && !m.legacy && !c.classList.contains("dead") && !c.classList.contains("locked");
}
function attachTouch(bubble, row, m) {
  const TH = 56;
  let tPress = 0, tCtx = 0, sx = 0, sy = 0, dx = 0, mode = "", ind = null, hit = false, quiet = 0;
  const stopTimers = () => { clearTimeout(tPress); clearTimeout(tCtx); tPress = tCtx = 0; row.classList.remove("pressing"); };
  bubble.addEventListener("click", e => { if (Date.now() < quiet) { e.preventDefault(); e.stopPropagation(); } }, true);
  bubble.addEventListener("touchstart", e => {
    stopTimers(); dx = 0; hit = false;
    if (S.sel || e.touches.length !== 1) { mode = "x"; return; }
    mode = "";
    const t = e.touches[0]; sx = t.clientX; sy = t.clientY;
    tPress = setTimeout(() => row.classList.add("pressing"), 140);
    tCtx = setTimeout(() => { tCtx = 0; mode = "ctx"; row.classList.remove("pressing"); haptic(12); openCtx(sx, sy, m); }, 450);
  }, {passive: true});
  bubble.addEventListener("touchmove", e => {
    if (mode !== "" && mode !== "swipe") return;
    const t = e.touches[0], mx = t.clientX - sx, my = t.clientY - sy;
    if (mode === "") {
      if (Math.abs(mx) < 9 && Math.abs(my) < 9) return;
      stopTimers();
      const skip = e.target.closest && e.target.closest(".vtrack,.vspd,.mplayer,.code-scroll,.term-scroll,.cbtn");
      if (Math.abs(mx) < Math.abs(my) * 1.5 || mx > 0 || skip || !canSwipeReply(m)) { mode = "scroll"; return; }
      mode = "swipe"; bubble.style.transition = "none";
      ind = h("span", {class: "swipe-ind", "aria-hidden": "true"}, icon("reply")); row.append(ind);
    }
    const raw = mx < 0 ? -mx : 0;
    dx = -(raw <= TH ? raw : TH + (raw - TH) * 0.2);
    const k = Math.min(1, raw / TH);
    bubble.style.transform = "translateX(" + dx + "px)";
    ind.style.opacity = String(k); ind.style.transform = "scale(" + (0.6 + 0.4 * k) + ")";
    const nowHit = raw >= TH;
    if (nowHit !== hit) { hit = nowHit; row.classList.toggle("swipe-hit", hit); if (hit) haptic(8); }
  }, {passive: true});
  const end = cancelled => {
    stopTimers();
    if (mode === "ctx") quiet = Date.now() + 600;
    if (mode === "swipe") {
      const fire = !cancelled && hit;
      bubble.style.transition = ""; bubble.style.transform = "";
      if (ind) { const el = ind; el.style.opacity = "0"; setTimeout(() => el.remove(), 220); ind = null; }
      row.classList.remove("swipe-hit");
      quiet = Date.now() + 400;
      if (fire) startReply(m);
    }
    mode = ""; hit = false;
  };
  bubble.addEventListener("touchend", () => end(false), {passive: true});
  bubble.addEventListener("touchcancel", () => end(true), {passive: true});
}

(() => {
  const sheet = $("sheet");
  let y0 = 0, dy = 0, drag = false;
  sheet.addEventListener("touchstart", e => {
    drag = false;
    if (!isMobile() || e.touches.length !== 1 || !e.target.closest(".sh-head, .pbanner")) return;
    y0 = e.touches[0].clientY; dy = 0; drag = true;
  }, {passive: true});
  sheet.addEventListener("touchmove", e => {
    if (!drag) return;
    dy = Math.max(0, e.touches[0].clientY - y0);
    if (dy > 6) { sheet.style.transition = "none"; sheet.style.transform = "translateY(" + dy + "px)"; }
  }, {passive: true});
  const end = () => {
    if (!drag) return; drag = false;
    const close = dy > 110; dy = 0;
    sheet.style.transition = "transform .2s ease";
    sheet.style.transform = close ? "translateY(100%)" : "";
    setTimeout(() => { if (close) closeModal(); sheet.style.transition = ""; sheet.style.transform = ""; }, 200);
  };
  sheet.addEventListener("touchend", end, {passive: true});
  sheet.addEventListener("touchcancel", end, {passive: true});
})();

const chBridge = {api, h, icon, toast, confirmDlg, promptDlg, openModal, closeModal, sheetHead, navPush, navPop, hhmm, dayLabel, avatar, nameEl,
                  amAdmin: () => amAdmin(), me: () => S.me, openMenu, openProfile: id => openProfile(id), infoPage, closePage, closeAllPages, refreshPages, chanData: id => S.chn.get(id), setChannelList, chanAvatar, patchPost,
                  openChat, closeChat, active: () => S.active, info: chInfo, hydrateComment, sealComment, renderList, renderHeader,
                  list: () => S.chList, isMobile, fmtDT: ts => fmtDT(ts)};
function openApp() {
  resetState();
  $("auth").classList.add("hidden"); $("app").classList.remove("hidden");
  document.querySelectorAll(".tabs button").forEach(x => x.classList.toggle("on", x.dataset.tab === "chats"));
  $("chat").classList.add("hidden"); $("empty").classList.remove("hidden");
  S.wantClose = false;
  loadEmojis();
  X.ready = (async () => { await loadMembers(); try { await loadRoom(); } catch (_) {} applyPendingOpen(); })();
  connect();
  Channels.init(chBridge); Channels.loadList().then(applyPendingChannel).catch(() => {});
  Push.sync(api).catch(() => {});
  setTimeout(askNotifications, 2500);
}

(function boot() {
  let tok = ""; try { tok = localStorage.getItem(LS_STAY) || ""; } catch (_) {}
  if (tok) resumeStay(tok, 0);
  else { try { E2E.clearIdentity(); } catch (_) {} }
})();

setInterval(() => { if (S.token && S.me && isStaff(S.me) && X.rooms.size) serveWraps(); }, 30000);

const OffChess = (() => {
  const GLYPH = {k: "♚", q: "♛", r: "♜", b: "♝", n: "♞", p: "♟\uFE0E"};
  const VAL = {p: 1, n: 3, b: 3, r: 5, q: 9, k: 0};
  const START = "RNBQKBNRPPPPPPPP" + ".".repeat(32) + "pppppppprnbqkbnr";
  const LS_GAME = "tc_offchess", LS_CFG = "tc_offchess_cfg", LS_STAT = "tc_offchess_stat";
  const REASON = {
    checkmate: "Mat", stalemate: "Pat — yurish qolmadi", insufficient: "Material yetarli emas", fifty: "50 yurish qoidasi",
    repetition: "Bir xil holat uch marta takrorlandi", resign: "Taslim bo'lindi",
  };
  const LV_INFO = {1: "Xato qiladi — o'rganish uchun", 2: "Ba'zan xato qiladi", 3: "Oddiy o'yinchidek", 4: "Taktikani yaxshi ko'radi", 5: "Eng kuchli • o'ylash uzoqroq"};
  const sqName = i => "abcdefgh"[i & 7] + ((i >> 3) + 1);
  const sqIdx = s => (s.charCodeAt(1) - 49) * 8 + s.charCodeAt(0) - 97;
  const lsGet = (k, d) => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (_) { return d; } };
  const lsSet = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (_) {} };
  const lsDel = k => { try { localStorage.removeItem(k); } catch (_) {} };
  const snd = () => { try { return Gaming.snd; } catch (_) { return null; } };
  const sound = (name, ...a) => { try { const s = snd(); if (s && s[name]) s[name](...a); } catch (_) {} };

  const O = {el: null, main: null, g: null, bd: START.split(""), dom: new Array(64).fill(null), sqs: [], layer: null, boardEl: null, sheet: null,
    worker: null, wOk: true, req: 0, pending: new Map(), top: null, bot: null, hs: null, hList: null, hPrev: null, hNext: null, hLive: null, undoBtn: null, hintBtn: null,
    sel: null, drag: null, askingPromo: false, hintTimer: 0, botTimer: 0};

  function engineOk() { return !!window.TCChess; }
  function ensureWorker() {
    if (O.worker || !O.wOk) return O.worker;
    try {
      const w = new Worker("/static/js/chessbot.js");
      w.onmessage = e => { const d = e.data || {}, p = O.pending.get(d.id); if (p) { O.pending.delete(d.id); clearTimeout(p.t); p.res(d); } };
      w.onerror = () => { O.wOk = false; try { w.terminate(); } catch (_) {} O.worker = null; flushPending(); };
      O.worker = w;
    } catch (_) { O.wOk = false; O.worker = null; }
    return O.worker;
  }
  function flushPending() {
    const list = [...O.pending.values()]; O.pending.clear();
    list.forEach(p => { clearTimeout(p.t); runMain(p.q).then(p.res); });
  }
  function runMain(q) {
    return new Promise(res => setTimeout(() => {
      try { const r = window.TCChess.chooseMove(q.fen, q.moves, q.level, {hint: q.hint}); res({ok: true, uci: r && r.uci}); }
      catch (err) { res({ok: false, error: String(err && err.message || err)}); }
    }, 30));
  }
  function askBot(moves, level, hint) {
    const q = {fen: window.TCChess.START_FEN, moves: moves.slice(), level, hint: !!hint};
    const w = ensureWorker();
    if (!w) return runMain(q);
    return new Promise(res => {
      const id = ++O.req, t = setTimeout(() => {
        if (!O.pending.has(id)) return; O.pending.delete(id); runMain(q).then(res);
      }, 15000);
      O.pending.set(id, {res, t, q});
      try { w.postMessage(Object.assign({id}, q)); } catch (_) { O.pending.delete(id); clearTimeout(t); runMain(q).then(res); }
    });
  }

  const cfg = () => Object.assign({level: 3, side: "r"}, lsGet(LS_CFG, {}));
  const stat = () => Object.assign({w: 0, l: 0, d: 0}, lsGet(LS_STAT, {}));
  function newGame(level, side, moves) {
    const T = window.TCChess, pos = new T.Pos();
    const g = {level, side, pos, moves: [], mv: [], boards: [START], over: null, thinking: false, view: null, last: null, hint: null, token: 0, counted: false};
    for (const u of (moves || [])) { if (!playUci(g, u)) return null; }
    return g;
  }
  function playUci(g, u) {
    const pos = g.pos, list = pos.legal(), m = pos.findUci(u, list); if (!m) return false;
    const f = m & 63, t = (m >> 6) & 63, fl = m >> 16, pr = (m >> 12) & 15, ch = pos.b[f];
    const cap = fl & 2 ? pos.b[t - 8 * pos.turn] : pos.b[t];
    pos.make(m);
    const sym = v => v ? (v > 0 ? "PNBRQK"[v - 1] : "pnbrqk"[-v - 1]) : "";
    const chk = pos.inCheck();
    g.moves.push(u); g.mv.push({ch: sym(ch), f, t, cap: sym(cap), promo: pr ? "pnbrqk"[pr - 1] : "", check: chk});
    g.boards.push(pos.boardString());
    g.last = [f, t];
    const st = pos.status(); if (st.over) g.over = {result: st.result, reason: st.reason};
    return true;
  }
  const myTurn = g => g && !g.over && (g.pos.turn === 1 ? "w" : "b") === g.side;
  const saveGame = () => {
    const g = O.g; if (!g) return;
    lsSet(LS_GAME, {v: 1, side: g.side, level: g.level, moves: g.moves, over: !!g.over, ts: Date.now()});
  };
  function loadSaved() {
    const s = lsGet(LS_GAME, null);
    if (!s || s.v !== 1 || !Array.isArray(s.moves) || s.moves.length > 800 || s.over || !s.moves.length || (s.side !== "w" && s.side !== "b") || !(s.level >= 1 && s.level <= 5)) return null;
    return s;
  }

  const xy = i => { const f = i & 7, r = i >> 3; return O.g && O.g.side === "b" ? [7 - f, r] : [f, 7 - r]; };
  function place(el, i) { const [x, y] = xy(i); el.dataset.x = x; el.dataset.y = y; el.style.transform = "translate(" + x * 100 + "%," + y * 100 + "%)"; }
  function mkPiece(ch, i) {
    const t = ch.toLowerCase(), el = h("div", {class: "gp " + (ch === t ? "pb" : "pw")}, h("span", {text: GLYPH[t]}));
    place(el, i); return el;
  }
  function rebuildPieces() {
    if (!O.layer) return;
    O.layer.textContent = ""; O.dom.fill(null);
    for (let i = 0; i < 64; i++) if (O.bd[i] !== ".") { const el = mkPiece(O.bd[i], i); O.layer.append(el); O.dom[i] = el; }
  }
  function boardBlock() {
    const b = h("div", {class: "gm-board oc-board"}), grid = h("div", {class: "gm-sqs"}), side = O.g.side;
    O.sqs = new Array(64);
    for (let y = 0; y < 8; y++) for (let x = 0; x < 8; x++) {
      const i = side === "b" ? y * 8 + (7 - x) : (7 - y) * 8 + x, dark = ((i & 7) + (i >> 3)) % 2 === 0;
      const s = h("div", {class: "sq " + (dark ? "dk" : "lt")});
      if (x === 0) s.append(h("i", {class: "rk", text: String((i >> 3) + 1)}));
      if (y === 7) s.append(h("i", {class: "fl", text: "abcdefgh"[i & 7]}));
      O.sqs[i] = s; grid.append(s);
    }
    O.layer = h("div", {class: "gm-pcs"}); b.append(grid, O.layer); O.boardEl = b; rebuildPieces();
    b.addEventListener("pointerdown", onDown); b.addEventListener("pointermove", onMove);
    b.addEventListener("pointerup", onUp); b.addEventListener("pointercancel", onUp);
    return b;
  }
  function applyMove(f, t, promo) {
    const el = O.dom[f]; if (!el) { O.bd = O.g.boards[O.g.boards.length - 1].split(""); rebuildPieces(); return false; }
    const ch = O.bd[f], pt = ch.toLowerCase();
    let capEl = O.dom[t], capped = O.bd[t] !== ".";
    if (pt === "p" && (f & 7) !== (t & 7) && O.bd[t] === ".") { const c = ch === "P" ? t - 8 : t + 8; capEl = O.dom[c]; capped = true; O.dom[c] = null; O.bd[c] = "."; }
    if (capEl) { capEl.classList.add("cap"); setTimeout(() => capEl.remove(), 280); }
    O.dom[t] = el; O.dom[f] = null; O.bd[t] = ch; O.bd[f] = ".";
    el.classList.add("mv"); setTimeout(() => el.classList.remove("mv"), 300); place(el, t);
    if (pt === "p" && ((t >> 3) === 0 || (t >> 3) === 7)) { const np = promo || "q"; O.bd[t] = ch === "P" ? np.toUpperCase() : np; el.firstChild.textContent = GLYPH[np]; el.classList.add("promo"); }
    if (pt === "k" && Math.abs(t - f) === 2) {
      const rf = t > f ? f + 3 : f - 4, rt = t > f ? f + 1 : f - 1, rel = O.dom[rf];
      if (rel) { O.dom[rt] = rel; O.dom[rf] = null; O.bd[rt] = O.bd[rf]; O.bd[rf] = "."; rel.classList.add("mv"); setTimeout(() => rel.classList.remove("mv"), 300); place(rel, rt); }
    }
    return capped;
  }
  function targetsOf(i) {
    const g = O.g; if (!g || !myTurn(g)) return [];
    const pos = g.pos, out = [];
    for (const m of pos.legal()) if ((m & 63) === i) out.push((m >> 6) & 63);
    return out;
  }
  function paintMarks() {
    if (!O.sqs.length || !O.sqs[0] || !O.g) return;
    const g = O.g, rv = g.view != null, mvv = rv && g.view > 0 ? g.mv[g.view - 1] : null;
    const last = rv ? (mvv ? [mvv.f, mvv.t] : []) : (g.last || []);
    let chk = -1;
    if (!rv && (!g.over || g.over.reason === "checkmate") && g.pos.inCheck()) chk = g.pos.kp[g.pos.turn === 1 ? 0 : 1];
    const tg = !rv && O.sel != null ? targetsOf(O.sel) : [], hint = !rv && g.hint ? g.hint : [];
    for (let i = 0; i < 64; i++) {
      const c = O.sqs[i].classList, t = tg.includes(i);
      c.toggle("last", last.includes(i)); c.toggle("chk", i === chk); c.toggle("sel", i === O.sel);
      c.toggle("tg", t && O.bd[i] === "."); c.toggle("tgc", t && O.bd[i] !== "."); c.toggle("hint", hint.includes(i));
    }
  }
  function sqAt(e) {
    const r = O.boardEl.getBoundingClientRect();
    const x = Math.floor((e.clientX - r.left) / r.width * 8), y = Math.floor((e.clientY - r.top) / r.height * 8);
    if (x < 0 || x > 7 || y < 0 || y > 7) return -1;
    return O.g.side === "b" ? y * 8 + (7 - x) : (7 - y) * 8 + x;
  }
  function onDown(e) {
    const g = O.g;
    if (!g || g.over || g.thinking || O.askingPromo || g.view != null || e.button > 0 || !myTurn(g)) return;
    const i = sqAt(e); if (i < 0) return;
    if (O.sel != null && targetsOf(O.sel).includes(i)) { doMove(O.sel, i); e.preventDefault(); return; }
    const ch = O.bd[i], own = ch !== "." && (ch === ch.toUpperCase()) === (g.side === "w");
    if (own && O.dom[i] && targetsOf(i).length) {
      O.sel = i; O.drag = {i, el: O.dom[i], x: e.clientX, y: e.clientY, moved: false, id: e.pointerId};
      try { O.boardEl.setPointerCapture(e.pointerId); } catch (_) {}
    } else O.sel = null;
    paintMarks(); e.preventDefault();
  }
  function onMove(e) {
    const d = O.drag; if (!d || e.pointerId !== d.id) return;
    const dx = e.clientX - d.x, dy = e.clientY - d.y;
    if (!d.moved && Math.hypot(dx, dy) > 7) { d.moved = true; d.el.classList.add("drag"); }
    if (d.moved) d.el.style.transform = "translate(calc(" + d.el.dataset.x * 100 + "% + " + dx + "px), calc(" + d.el.dataset.y * 100 + "% + " + dy + "px)) scale(1.18)";
  }
  function onUp(e) {
    const d = O.drag; if (!d || e.pointerId !== d.id) return;
    O.drag = null; d.el.classList.remove("drag");
    if (!d.moved) return;
    const to = sqAt(e);
    if (to >= 0 && targetsOf(d.i).includes(to)) doMove(d.i, to); else place(d.el, d.i);
  }
  function askPromo(white) {
    return new Promise(res => {
      O.askingPromo = true;
      const done = v => { O.askingPromo = false; ov.remove(); res(v); };
      const ov = h("div", {class: "gm-promo", onclick: e => { if (e.target === ov) done(null); }},
        h("div", {class: "gm-pbox"}, ["q", "r", "b", "n"].map(p => h("button", {type: "button", class: "gm-pp " + (white ? "pw" : "pb"), "aria-label": p, onclick: () => done(p)}, GLYPH[p]))));
      O.boardEl.append(ov);
    });
  }
  async function doMove(f, t) {
    const ch = O.bd[f];
    if (ch.toLowerCase() === "p" && ((t >> 3) === 7 || (t >> 3) === 0)) {
      const p = await askPromo(ch === "P");
      if (!p) { if (O.dom[f]) place(O.dom[f], f); return; }
      return commit(f, t, p);
    }
    commit(f, t, "");
  }

  function afterMove(mine) {
    const g = O.g, l = g.mv[g.mv.length - 1];
    const castle = l.ch.toLowerCase() === "k" && Math.abs(l.t - l.f) === 2;
    sound("move", mine, !!l.cap, {castle, promo: l.promo});
    if (!mine) haptic(12);
    if (g.pos.inCheck() && !g.over) sound("check");
    saveGame(); paintMarks(); paintPlayers(); paintHist(); syncButtons();
    if (g.over) return finish();
  }
  function commit(f, t, promo) {
    const g = O.g; if (!g || !myTurn(g)) return;
    const uci = sqName(f) + sqName(t) + (promo || "");
    O.sel = null; g.hint = null; clearTimeout(O.hintTimer);
    if (!playUci(g, uci)) { place(O.dom[f], f); paintMarks(); toast("Bu yurish mumkin emas", "warn"); return; }
    applyMove(f, t, promo);
    afterMove(true);
    if (!g.over) botTurn();
  }
  async function botTurn() {
    const g = O.g; if (!g || g.over || myTurn(g)) return;
    const token = ++g.token; g.thinking = true; paintPlayers(); syncButtons();
    const t0 = performance.now();
    let res;
    try { res = await askBot(g.moves, g.level, false); } catch (err) { res = {ok: false, error: String(err && err.message || err)}; }
    const wait = Math.max(0, (g.level <= 2 ? 450 : 250) - (performance.now() - t0));
    if (wait) await new Promise(r => O.botTimer = setTimeout(r, wait));
    if (O.g !== g || g.token !== token || g.over) return;
    g.thinking = false;
    let uci = res && res.ok && res.uci;
    if (!uci) {
      const l = g.pos.legal(); if (!l.length) { paintPlayers(); return; }
      uci = g.pos.toUci(l[Math.floor(Math.random() * l.length)]);
    }
    const f = sqIdx(uci.slice(0, 2)), t = sqIdx(uci.slice(2, 4)), promo = uci[4] || "";
    if (!playUci(g, uci)) { toast("Bot noto'g'ri yurish qildi — qayta urinilmoqda", "warn"); return botTurn(); }
    if (g.view == null) applyMove(f, t, promo); else {  }
    afterMove(false);
  }
  function finish() {
    const g = O.g, o = g.over; if (!o || g.counted) return; g.counted = true;
    const me = g.side, res = o.result === "d" ? "d" : o.result === me ? "w" : "l";
    const s = stat(); s[res === "w" ? "w" : res === "l" ? "l" : "d"]++; lsSet(LS_STAT, s);
    lsDel(LS_GAME); paintPlayers(); syncButtons();
    const why = o.reason === "resign" ? (res === "w" ? "Bot taslim bo'ldi" : "Siz taslim bo'ldingiz") : REASON[o.reason] || "";
    const card = h("div", {class: "gm-over", onclick: e => { if (e.target === card) card.remove(); }}, h("div", {class: "go-card"},
      h("div", {class: "go-t", text: res === "w" ? "🏆 Siz yutdingiz!" : res === "l" ? "Yutqazdingiz" : "🤝 Durang"}),
      h("div", {class: "go-r", text: why}),
      h("div", {class: "go-nr", text: "Oflayn o'yin — natija faqat shu qurilmada hisoblanadi."}),
      h("div", {class: "go-b"},
        h("button", {class: "btn", type: "button", text: "🔁 Qayta o'ynash", onclick: () => { card.remove(); startNew(g.level, g.side === "w" ? "b" : "w", true); }}),
        h("button", {class: "btn ghost", type: "button", text: "Menyu", onclick: () => { card.remove(); O.g = null; render(); }}))));
    O.el.append(card); O.overCard = card;
    haptic(res === "w" ? [60, 40, 120] : 40);
    setTimeout(() => sound(res === "w" ? "win" : res === "l" ? "lose" : "draw"), 350);
  }
  async function resign() {
    const g = O.g; if (!g || g.over) return;
    if (!await confirmDlg("Taslim bo'lsangiz o'yin tugaydi. Taslim bo'lasizmi?", {title: "Taslim bo'lish", okText: "Taslim bo'lish", danger: true})) return;
    if (O.g !== g || g.over) return;
    g.token++; g.thinking = false; g.over = {result: g.side === "w" ? "b" : "w", reason: "resign"}; finish();
  }
  function undo() {
    const g = O.g; if (!g || !canUndo(g)) return;
    const was = g.over; g.token++; g.thinking = false; clearTimeout(O.botTimer);
    let n = g.moves.length;
    do { n--; } while (n > 0 && ((n % 2 === 0 ? "w" : "b") !== g.side));
    const keep = g.moves.slice(0, n), ng = newGame(g.level, g.side, keep); if (!ng) return;
    ng.counted = false; O.g = ng; if (O.overCard) { O.overCard.remove(); O.overCard = null; }
    if (was) { const s = stat(); const r = was.result === "d" ? "d" : was.result === g.side ? "w" : "l"; if (g.counted) { s[r] = Math.max(0, s[r] - 1); lsSet(LS_STAT, s); } }
    O.bd = ng.boards[ng.boards.length - 1].split(""); rebuildPieces();
    O.sel = null; saveGame(); paintMarks(); paintPlayers(); paintHist(); syncButtons();
    if (!myTurn(ng) && !ng.over) botTurn();
  }
  const canUndo = g => !!g && g.moves.length > (g.side === "w" ? 0 : 1) && !(g.over && g.over.reason === "resign");
  async function hint() {
    const g = O.g; if (!g || g.over || g.thinking || !myTurn(g) || O.hinting) return;
    O.hinting = true; syncButtons(); toast("Maslahat o'ylanmoqda…", "info");
    let r = null; try { r = await askBot(g.moves, 4, true); } catch (_) {}
    O.hinting = false;
    if (O.g !== g || g.over || !myTurn(g)) { syncButtons(); return; }
    if (r && r.ok && r.uci) {
      g.hint = [sqIdx(r.uci.slice(0, 2)), sqIdx(r.uci.slice(2, 4))]; clearTimeout(O.hintTimer);
      O.hintTimer = setTimeout(() => { if (O.g === g) { g.hint = null; paintMarks(); } }, 4000);
      paintMarks(); toast("Maslahat: " + r.uci.slice(0, 2) + "–" + r.uci.slice(2, 4), "ok");
    } else toast("Maslahat topilmadi", "warn");
    syncButtons();
  }

  function setView(k) {
    const g = O.g; if (!g) return;
    const n = g.moves.length; g.view = k == null || k >= n ? null : Math.max(0, k);
    O.sel = null; O.drag = null;
    O.bd = (g.view == null ? g.boards[n] : g.boards[g.view]).split(""); rebuildPieces();
    if (O.boardEl) O.boardEl.classList.toggle("rev", g.view != null);
    paintMarks(); paintHist();
  }
  function buildHist() {
    const mkb = (txt, label, fn) => { const b = h("button", {class: "gm-hb", type: "button", "aria-label": label, text: txt}); b.addEventListener("click", fn); return b; };
    O.hPrev = mkb("◀", "Oldingi yurish", () => { const g = O.g; if (g) setView((g.view == null ? g.moves.length : g.view) - 1); });
    O.hNext = mkb("▶", "Keyingi yurish", () => { const g = O.g; if (g && g.view != null) setView(g.view + 1); });
    O.hLive = mkb("⏭", "Hozirgi holat", () => setView(null));
    O.hList = h("div", {class: "gm-hl"});
    O.hs = h("div", {class: "gm-hist"}, O.hPrev, O.hList, O.hNext, O.hLive);
    paintHist(); return O.hs;
  }
  function paintHist() {
    const g = O.g; if (!O.hs || !O.hList || !g) return;
    const n = g.moves.length, cur = g.view == null ? n : g.view;
    O.hList.textContent = "";
    if (!n) O.hList.append(h("span", {class: "gm-hn", text: "Yurishlar tarixi bu yerda ko'rinadi"}));
    let act = null;
    g.mv.forEach((m, i) => {
      if (i % 2 === 0) O.hList.append(h("span", {class: "gm-hn", text: (i / 2 + 1) + "."}));
      const white = m.ch === m.ch.toUpperCase(), pt = m.ch.toLowerCase();
      const b = h("button", {type: "button", class: "gm-hm " + (white ? "w" : "k") + (i + 1 === cur ? " on" : ""), title: (i + 1) + "-yurish"},
        h("i", {text: GLYPH[pt]}), h("span", {text: sqName(m.f) + (m.cap ? "×" : "–") + sqName(m.t) + (m.promo ? "=" + GLYPH[m.promo] : "") + (m.check ? "+" : "")}));
      b.addEventListener("click", () => setView(i + 1));
      if (i + 1 === cur) act = b;
      O.hList.append(b);
    });
    O.hPrev.disabled = cur <= 0; O.hNext.disabled = g.view == null; O.hLive.disabled = g.view == null;
    O.hs.classList.toggle("rev", g.view != null);
    if (act) O.hList.scrollLeft = act.offsetLeft - O.hList.clientWidth / 2 + act.offsetWidth / 2; else O.hList.scrollLeft = 0;
  }

  function playerRow(side) {
    const bot = side !== O.g.side, cap = h("span", {class: "gm-cap"}), pts = h("span", {class: "gm-pp2"});
    let av;
    if (bot) av = h("div", {class: "gm-botav", text: "🤖"});
    else { try { av = S.me ? avatar(S.me, "m", true) : h("div", {class: "gm-botav", text: "👤"}); } catch (_) { av = h("div", {class: "gm-botav", text: "👤"}); } }
    let name;
    if (bot) name = h("span", {text: "Bot • " + window.TCChess.LEVELS[O.g.level].name});
    else { try { name = S.me ? nameEl(S.me) : h("span", {text: "Siz"}); } catch (_) { name = h("span", {text: "Siz"}); } }
    const el = h("div", {class: "gm-pl"}, av, h("div", {class: "gm-pi"}, h("div", {class: "gm-pn"}, name), cap, pts));
    return {el, side, cap, pts};
  }
  function paintPlayers() {
    const g = O.g; if (!g || !O.top) return;
    const caps = {w: [], b: []};
    g.mv.forEach(m => { if (m.cap) (m.ch === m.ch.toUpperCase() ? caps.w : caps.b).push(m.cap); });
    const sum = a => a.reduce((n, c) => n + VAL[c.toLowerCase()], 0);
    [O.top, O.bot].forEach(r => {
      const mine = caps[r.side], other = caps[r.side === "w" ? "b" : "w"], diff = sum(mine) - sum(other);
      r.cap.textContent = "";
      [...mine].sort((a, b) => VAL[b.toLowerCase()] - VAL[a.toLowerCase()]).forEach(c => r.cap.append(h("span", {class: "gc " + (c === c.toLowerCase() ? "pb" : "pw"), text: GLYPH[c.toLowerCase()]})));
      if (diff > 0) r.cap.append(h("span", {class: "gm-diff", text: "+" + diff}));
      const botRow = r.side !== g.side;
      r.pts.textContent = "";
      if (botRow && g.thinking) r.pts.append(h("span", {class: "oc-think"}, h("i", {class: "pnd-spin", "aria-hidden": "true"}), " o'ylamoqda…"));
      else if (botRow) r.pts.append(h("span", {class: "gm-tot", text: LV_INFO[g.level]}));
      else r.pts.append(h("span", {class: "gm-tot", text: g.pos.turn === (g.side === "w" ? 1 : -1) && !g.over ? "Sizning yurishingiz" : g.over ? "" : "Kuting…"}));
      const turn = !g.over && (g.pos.turn === 1 ? "w" : "b") === r.side;
      r.el.classList.toggle("turn", turn);
    });
  }
  function syncButtons() {
    const g = O.g; if (!g) return;
    if (O.undoBtn) O.undoBtn.disabled = !canUndo(g);
    if (O.hintBtn) O.hintBtn.disabled = !!g.over || g.thinking || !myTurn(g) || !!O.hinting;
  }

  function open() {
    if (O.el) return;
    if (!engineOk()) { toast("Shaxmat dvigateli yuklanmadi. Sahifani yangilang (bir marta internet kerak).", "error"); return; }
    const root = h("div", {id: "ocx", class: "gm oc"});
    O.main = h("div", {class: "gm-main"});
    root.append(
      h("div", {class: "gm-top"},
        h("b", {class: "gm-ttl", text: "🤖 Bot bilan o'ynash"}),
        h("span", {class: "gm-sp"}),
        h("button", {class: "gm-x", type: "button", "aria-label": "Ovoz", onclick: ev => {
          let on = true; try { on = localStorage.getItem("tc_gsnd") !== "off"; } catch (_) {}
          on = !on; try { localStorage.setItem("tc_gsnd", on ? "on" : "off"); } catch (_) {}
          ev.currentTarget.textContent = on ? "🔊" : "🔇"; if (on) sound("start");
        }}, (() => { try { return localStorage.getItem("tc_gsnd") !== "off" ? "🔊" : "🔇"; } catch (_) { return "🔊"; } })()),
        h("button", {class: "gm-x", type: "button", "aria-label": "Yopish", onclick: () => close()}, "✕")),
      O.main);
    document.body.append(root); O.el = root;
    navPush("ocx");
    const saved = loadSaved();
    if (saved) { const g = newGame(saved.level, saved.side, saved.moves); if (g) { O.g = g; O.bd = g.boards[g.boards.length - 1].split(""); render(); if (!myTurn(g) && !g.over) botTurn(); return; } lsDel(LS_GAME); }
    O.g = null; render();
  }
  function close() {
    if (!O.el) return;
    if (O.g) { O.g.token++; O.g.thinking = false; }
    clearTimeout(O.botTimer); clearTimeout(O.hintTimer); O.hinting = false;
    if (O.g && !O.g.over) saveGame();
    O.el.remove(); O.el = null; O.main = null; O.sqs = []; O.boardEl = null; O.layer = null; O.top = O.bot = O.hs = O.undoBtn = O.hintBtn = null; O.overCard = null;
    navPop("ocx");
    if (S.tab === "games") { try { renderList(); } catch (_) {} }
  }
  function render() {
    if (!O.el) return;
    O.main.textContent = ""; O.top = O.bot = O.hs = O.undoBtn = O.hintBtn = null; O.sel = null; O.drag = null; O.sqs = []; O.boardEl = null; O.layer = null;
    if (O.g) buildGame(); else buildLobby();
  }
  function startNew(level, pref, keepPref) {
    if (!window.TCChess) return;
    const side = pref === "r" ? (Math.random() < 0.5 ? "w" : "b") : pref;
    if (O.g) { O.g.token++; O.g.thinking = false; }
    clearTimeout(O.botTimer); O.hinting = false;
    if (!keepPref) lsSet(LS_CFG, {level, side: pref});
    const g = newGame(level, side, []); if (!g) return;
    O.g = g; O.bd = START.split(""); lsDel(LS_GAME);
    if (O.overCard) { O.overCard.remove(); O.overCard = null; }
    render(); sound("start"); haptic([40, 40, 40]);
    if (!myTurn(g)) botTurn();
  }
  function buildLobby() {
    const c = cfg(), st = stat(), T = window.TCChess;
    let level = c.level, side = c.side;
    const lvRow = h("div", {class: "oc-lv"}), sdRow = h("div", {class: "gm-sides"});
    const info = h("p", {class: "gm-note oc-lvinfo"});
    const paintLv = () => {
      lvRow.textContent = "";
      for (let i = 1; i <= 5; i++) lvRow.append(h("button", {type: "button", class: "oc-lvb" + (i === level ? " on" : ""), "aria-pressed": String(i === level), onclick: () => { level = i; paintLv(); }}, h("b", {text: String(i)}), h("small", {text: T.LEVELS[i].name})));
      info.textContent = T.LEVELS[level].name + " — " + LV_INFO[level];
    };
    const paintSd = () => {
      sdRow.textContent = "";
      [["w", "♔", "Oq", "birinchi yurasiz"], ["r", "🎲", "Tasodifiy", "oq yoki qora"], ["b", "♚", "Qora", "bot birinchi yuradi"]].forEach(([k, ic, nm, sub]) =>
        sdRow.append(h("button", {type: "button", class: "gm-sd" + (k === side ? " on" : ""), "aria-pressed": String(k === side), onclick: () => { side = k; paintSd(); }}, h("span", {text: ic}), h("b", {text: nm}), h("small", {text: sub}))));
    };
    paintLv(); paintSd();
    const n = st.w + st.l + st.d;
    const root = h("div", {class: "gm-menu oc-menu"},
      h("div", {class: "gm-mh"}, h("div", {class: "gm-mart", text: "♞"}), h("b", {text: "Bot bilan o'ynash"}), h("small", {text: "5 daraja • internet shart emas"}),
        h("div", {class: "gm-mst"}, h("span", {class: "gm-chip", text: n ? "🏆 " + st.w + " / " + st.l + " / " + st.d + " (yutuq / mag'lub. / durang)" : "Hali o'ynalmagan — birinchi bo'ling!"}))),
      h("div", {class: "oc-sec", text: "Bot darajasi"}), lvRow, info,
      h("div", {class: "oc-sec", text: "Siz qaysi tomonda?"}), sdRow,
      h("button", {class: "btn oc-go", type: "button", text: "▶ O'yinni boshlash", onclick: () => startNew(level, side)}),
      h("p", {class: "gm-note oc-foot", text: "Natijalar va to'xtatilgan o'yin faqat shu qurilmada saqlanadi. Oflayn o'yin ochko bermaydi."}));
    O.main.append(root);
  }
  function buildGame() {
    const g = O.g, opp = g.side === "w" ? "b" : "w";
    O.bd = g.boards[g.moves.length].split("");
    O.top = playerRow(opp); O.bot = playerRow(g.side);
    O.undoBtn = h("button", {class: "gm-undo", type: "button", onclick: undo, title: "Yurishni qaytarish"}, "↩ Orqaga");
    O.hintBtn = h("button", {class: "gm-undo oc-hint", type: "button", onclick: hint}, "💡 Maslahat");
    const act = h("div", {class: "gm-act oc-act"},
      h("button", {class: "gm-resign", type: "button", onclick: resign}, "🏳 Taslim"), O.undoBtn, O.hintBtn,
      h("button", {class: "gm-undo", type: "button", onclick: newMenu}, "☰ Yangi"));
    O.main.append(h("div", {class: "gm-wrap"}, O.top.el, boardBlock(), O.bot.el, buildHist(), act));
    paintMarks(); paintPlayers(); paintHist(); syncButtons();
    if (g.over) { g.counted = true; }
  }
  async function newMenu() {
    const g = O.g; if (!g) return;
    if (!g.over && g.moves.length > 1 && !await confirmDlg("Joriy o'yin tashlab ketiladi (mag'lubiyat hisoblanmaydi). Yangi o'yin boshlaymizmi?", {title: "Yangi o'yin", okText: "Yangi o'yin"})) return;
    if (O.g !== g) return;
    g.token++; g.thinking = false; clearTimeout(O.botTimer); lsDel(LS_GAME); O.g = null; render();
  }
  function reset() {  }
  NAV_CLOSE.ocx = () => close();
  return {open, close, reset, isOpen: () => !!O.el, hasSaved: () => !!loadSaved() || !!(O.g && !O.g.over)};
})();

const Gaming = (() => {
  const GLYPH = {k: "♚", q: "♛", r: "♜", b: "♝", n: "♞", p: "♟\uFE0E"};
  const VAL = {p: 1, n: 3, b: 3, r: 5, q: 9, k: 0};
  const REACTS = ["😂", "😡", "😮", "👏", "😭", "🔥", "🤝", "😎", "👍", "❤️"];
  const START = "RNBQKBNRPPPPPPPP" + ".".repeat(32) + "pppppppprnbqkbnr";
  const REASON = {
    checkmate: "Mat", stalemate: "Pat — yurish qolmadi", insufficient: "Material yetarli emas", fifty: "50 yurish qoidasi",
    repetition: "Bir xil holat uch marta takrorlandi", timeout: "Vaqt tugadi", timeout_draw: "Vaqt tugadi, lekin mat qilish uchun material yetarli emas",
    abandon: "Aloqa uzilib qoldi", abort: "O'yin boshlanmadi — bekor qilindi",
  };
  const sqName = i => "abcdefgh"[i & 7] + ((i >> 3) + 1);
  const sqIdx = s => (s.charCodeAt(1) - 49) * 8 + s.charCodeAt(0) - 97;
  const G = {el: null, main: null, rxl: null, st: null, me: "w", bd: START.split(""), dom: new Array(64).fill(null), sqs: [], layer: null, boardEl: null,
    sel: null, drag: null, pend: false, waiting: false, wt: 0, inc: null, out: null, sheet: null, tick: 0, clock: null, overFor: null, rxAt: 0, incTimer: 0, top: null, bot: null, hist: [], boards: [START], mv: [], histKey: "", view: null, hs: null, undoBtn: null, tickSec: 0};
  const send = o => { if (wsTry(o)) return true; toast("Ulanish yo'q, biroz kutib qayta urinib ko'ring", "error"); return false; };

  const xy = i => { const f = i & 7, r = i >> 3; return G.me === "b" ? [7 - f, r] : [f, 7 - r]; };
  function place(el, i) { const [x, y] = xy(i); el.dataset.x = x; el.dataset.y = y; el.style.transform = "translate(" + x * 100 + "%," + y * 100 + "%)"; }
  function mkPiece(ch, i) {
    const t = ch.toLowerCase(), el = h("div", {class: "gp " + (ch === t ? "pb" : "pw")}, h("span", {text: GLYPH[t]}));
    place(el, i); return el;
  }
  function rebuildPieces() {
    G.layer.textContent = ""; G.dom.fill(null);
    for (let i = 0; i < 64; i++) if (G.bd[i] !== ".") { const el = mkPiece(G.bd[i], i); G.layer.append(el); G.dom[i] = el; }
  }
  function boardBlock(interactive) {
    const b = h("div", {class: "gm-board"});
    const grid = h("div", {class: "gm-sqs"});
    G.sqs = new Array(64);
    for (let y = 0; y < 8; y++) for (let x = 0; x < 8; x++) {
      const i = G.me === "b" ? y * 8 + (7 - x) : (7 - y) * 8 + x;
      const dark = ((i & 7) + (i >> 3)) % 2 === 0;
      const s = h("div", {class: "sq " + (dark ? "dk" : "lt")});
      if (x === 0) s.append(h("i", {class: "rk", text: String((i >> 3) + 1)}));
      if (y === 7) s.append(h("i", {class: "fl", text: "abcdefgh"[i & 7]}));
      G.sqs[i] = s; grid.append(s);
    }
    G.layer = h("div", {class: "gm-pcs"});
    b.append(grid, G.layer);
    G.boardEl = b;
    rebuildPieces();
    if (interactive) {
      b.addEventListener("pointerdown", onDown); b.addEventListener("pointermove", onMove);
      b.addEventListener("pointerup", onUp); b.addEventListener("pointercancel", onUp);
    }
    return b;
  }
  function fadeOut(el) { el.classList.add("cap"); setTimeout(() => el.remove(), 280); }
  function applyMove(f, t, promo) {
    const el = G.dom[f]; if (!el) return false;
    const ch = G.bd[f], pt = ch.toLowerCase();
    let capEl = G.dom[t], capped = G.bd[t] !== ".";
    if (pt === "p" && (f & 7) !== (t & 7) && G.bd[t] === ".") {
      const c = ch === "P" ? t - 8 : t + 8; capEl = G.dom[c]; capped = true; G.dom[c] = null; G.bd[c] = ".";
    }
    if (capEl) fadeOut(capEl);
    G.dom[t] = el; G.dom[f] = null; G.bd[t] = ch; G.bd[f] = ".";
    el.classList.add("mv"); setTimeout(() => el.classList.remove("mv"), 300);
    place(el, t);
    if (pt === "p" && ((t >> 3) === 0 || (t >> 3) === 7)) {
      const np = promo || "q"; G.bd[t] = ch === "P" ? np.toUpperCase() : np;
      el.firstChild.textContent = GLYPH[np]; el.classList.add("promo");
    }
    if (pt === "k" && Math.abs(t - f) === 2) {
      const rf = t > f ? f + 3 : f - 4, rt = t > f ? f + 1 : f - 1, rel = G.dom[rf];
      if (rel) { G.dom[rt] = rel; G.dom[rf] = null; G.bd[rt] = G.bd[rf]; G.bd[rf] = "."; rel.classList.add("mv"); setTimeout(() => rel.classList.remove("mv"), 300); place(rel, rt); }
    }
    return capped;
  }
  function reconcile(board) {
    if (G.bd.join("") === board) return;
    G.bd = board.split(""); rebuildPieces();
  }

  function stepBoard(bd, f, t, promo) {
    const ch = bd[f], pt = ch.toLowerCase();
    if (pt === "p" && (f & 7) !== (t & 7) && bd[t] === ".") bd[ch === "P" ? t - 8 : t + 8] = ".";
    bd[t] = ch; bd[f] = ".";
    if (pt === "p" && ((t >> 3) === 0 || (t >> 3) === 7)) { const np = promo || "q"; bd[t] = ch === "P" ? np.toUpperCase() : np; }
    if (pt === "k" && Math.abs(t - f) === 2) { const rf = t > f ? f + 3 : f - 4, rt = t > f ? f + 1 : f - 1; bd[rt] = bd[rf]; bd[rf] = "."; }
  }
  function refreshHist() {
    const hist = (G.st && G.st.hist) || [], key = hist.join(",");
    if (key === G.histKey) return;
    G.histKey = key; G.hist = hist; G.boards = [START]; G.mv = [];
    const bd = START.split("");
    hist.forEach(s => {
      const f = sqIdx(s.slice(0, 2)), t = sqIdx(s.slice(2, 4)), ch = bd[f];
      G.mv.push({ch, f, t, cap: bd[t] !== "." || (ch.toLowerCase() === "p" && (f & 7) !== (t & 7) && bd[t] === "."), promo: s[4] || ""});
      stepBoard(bd, f, t, s[4] || ""); G.boards.push(bd.join(""));
    });
  }
  function setView(k) {
    const n = G.hist.length;
    G.view = k == null || k >= n ? null : Math.max(0, k);
    G.sel = null; G.drag = null;
    if (G.layer) {
      G.bd = (G.view == null ? (G.st ? G.st.board : START) : G.boards[G.view]).split("");
      rebuildPieces();
    }
    if (G.boardEl) G.boardEl.classList.toggle("rev", G.view != null);
    paintMarks(); paintHist();
  }
  function buildHist() {
    const mkb = (txt, label, fn) => { const b = h("button", {class: "gm-hb", type: "button", "aria-label": label, text: txt}); b.addEventListener("click", fn); return b; };
    G.hPrev = mkb("◀", "Oldingi yurish", () => setView((G.view == null ? G.hist.length : G.view) - 1));
    G.hNext = mkb("▶", "Keyingi yurish", () => { if (G.view != null) setView(G.view + 1); });
    G.hLive = mkb("⏭", "Hozirgi holat", () => setView(null));
    G.hList = h("div", {class: "gm-hl"});
    G.hs = h("div", {class: "gm-hist"}, G.hPrev, G.hList, G.hNext, G.hLive);
    paintHist(); return G.hs;
  }
  function paintHist() {
    if (!G.hs || !G.hList) return;
    const n = G.hist.length, cur = G.view == null ? n : G.view;
    G.hList.textContent = "";
    if (!n) G.hList.append(h("span", {class: "gm-hn", text: "Yurishlar tarixi bu yerda ko'rinadi"}));
    let act = null;
    G.mv.forEach((m, i) => {
      if (i % 2 === 0) G.hList.append(h("span", {class: "gm-hn", text: (i / 2 + 1) + "."}));
      const white = m.ch === m.ch.toUpperCase(), pt = m.ch.toLowerCase();
      const b = h("button", {type: "button", class: "gm-hm " + (white ? "w" : "k") + (i + 1 === cur ? " on" : ""), title: (i + 1) + "-yurish"},
        h("i", {text: GLYPH[pt]}), h("span", {text: sqName(m.f) + (m.cap ? "×" : "–") + sqName(m.t) + (m.promo ? "=" + GLYPH[m.promo] : "")}));
      b.addEventListener("click", () => setView(i + 1));
      if (i + 1 === cur) act = b;
      G.hList.append(b);
    });
    G.hPrev.disabled = cur <= 0; G.hNext.disabled = G.view == null; G.hLive.disabled = G.view == null;
    G.hs.classList.toggle("rev", G.view != null);
    if (act) G.hList.scrollLeft = act.offsetLeft - G.hList.clientWidth / 2 + act.offsetWidth / 2; else G.hList.scrollLeft = 0;
  }
  function paintMarks() {
    if (!G.sqs.length || !G.sqs[0]) return;
    const st = G.st, rv = G.view != null, mvv = rv && G.view > 0 ? G.mv[G.view - 1] : null;
    const last = rv ? (mvv ? [mvv.f, mvv.t] : []) : st && st.last ? [sqIdx(st.last.from), sqIdx(st.last.to)] : [];
    const chk = !rv && st && st.check ? sqIdx(st.check) : -1;
    const tg = !rv && G.sel != null && st ? (st.legal[sqName(G.sel)] || []).map(sqIdx) : [];
    for (let i = 0; i < 64; i++) {
      const c = G.sqs[i].classList, t = tg.includes(i);
      c.toggle("last", last.includes(i)); c.toggle("chk", i === chk); c.toggle("sel", i === G.sel);
      c.toggle("tg", t && G.bd[i] === "."); c.toggle("tgc", t && G.bd[i] !== ".");
    }
  }
  let ac = null;

  const GSND_KEY = "tc_gsnd";
  const gSndOn = () => { try { return localStorage.getItem(GSND_KEY) !== "off"; } catch (_) { return true; } };
  const SND = (() => {
    let nb = null;
    const ctx = () => { if (!gSndOn()) return null; const c = audioCtx(); if (!c) return null; if (c.state === "suspended") c.resume().catch(() => {}); return c.state === "running" ? c : null; };
    const noise = c => nb && nb.sampleRate === c.sampleRate ? nb : (nb = (() => { const b = c.createBuffer(1, Math.floor(c.sampleRate * 0.25), c.sampleRate), d = b.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1; return b; })());
    function tone(c, t, f, dur, type, vol, f2) {
      const o = c.createOscillator(), g = c.createGain();
      o.type = type; o.frequency.setValueAtTime(f, t); if (f2) o.frequency.exponentialRampToValueAtTime(f2, t + dur);
      g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + 0.008); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      o.connect(g); g.connect(c.destination); o.start(t); o.stop(t + dur + 0.03);
    }
    function knock(c, t, body, bright, vol, dur) {
      tone(c, t, body, dur, "sine", vol, body * 0.55);
      const s = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
      s.buffer = noise(c); f.type = "bandpass"; f.frequency.value = bright; f.Q.value = 1.1;
      g.gain.setValueAtTime(vol * 1.4, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur * 0.55);
      s.connect(f); f.connect(g); g.connect(c.destination); s.start(t); s.stop(t + dur);
    }
    const seq = (notes, type, vol, dur, gap) => { const c = ctx(); if (!c) return; const t = c.currentTime; notes.forEach((f, i) => tone(c, t + i * gap, f, dur, type, vol)); };
    return {
      move(mine, cap, i) {
        const c = ctx(); if (!c) return; const t = c.currentTime, body = mine ? 150 : 225, bright = mine ? 950 : 1600, v = mine ? 0.24 : 0.17;
        knock(c, t, body, bright, v, 0.12);
        if (i && i.castle) knock(c, t + 0.11, body * 1.12, bright, v * 0.9, 0.12);
        if (cap) knock(c, t + 0.07, body * 0.7, bright * 0.6, v * 1.3, 0.2);
        if (i && i.promo) [880, 1175, 1568].forEach((f, n) => tone(c, t + 0.16 + n * 0.07, f, 0.22, "sine", 0.1));
      },
      check() { const c = ctx(); if (!c) return; const t = c.currentTime + 0.1; tone(c, t, 740, 0.14, "triangle", 0.13); tone(c, t + 0.13, 988, 0.22, "triangle", 0.13); },
      start() { seq([523, 659, 784], "sine", 0.13, 0.35, 0.09); },
      win() { seq([523, 659, 784, 1047], "triangle", 0.16, 0.42, 0.11); },
      lose() { seq([392, 311, 262], "sine", 0.15, 0.5, 0.17); },
      draw() { seq([494, 392], "sine", 0.14, 0.4, 0.15); },
      tick() { const c = ctx(); if (c) tone(c, c.currentTime, 1200, 0.05, "square", 0.045); },
      invite() { seq([784, 988, 1175], "sine", 0.14, 0.3, 0.1); },
      react(mine) { const c = ctx(); if (!c) return; const t = c.currentTime; tone(c, t, mine ? 620 : 480, 0.13, "sine", 0.13, mine ? 1000 : 760); tone(c, t + 0.07, mine ? 1250 : 960, 0.12, "sine", 0.07); },
    };
  })();

  function sqAt(e) {
    const r = G.boardEl.getBoundingClientRect();
    const x = Math.floor((e.clientX - r.left) / r.width * 8), y = Math.floor((e.clientY - r.top) / r.height * 8);
    if (x < 0 || x > 7 || y < 0 || y > 7) return -1;
    return G.me === "b" ? y * 8 + (7 - x) : (7 - y) * 8 + x;
  }
  const targets = i => (G.st && G.st.legal[sqName(i)] || []).map(sqIdx);
  function onDown(e) {
    if (!G.st || G.st.over || G.waiting || G.pend || G.view != null || e.button > 0) return;
    const i = sqAt(e); if (i < 0) return;
    if (G.sel != null && targets(G.sel).includes(i)) { doMove(G.sel, i); e.preventDefault(); return; }
    const ch = G.bd[i], own = ch !== "." && (ch === ch.toUpperCase()) === (G.me === "w");
    if (own && G.st.turn === G.me && G.st.legal[sqName(i)] && G.dom[i]) {
      G.sel = i; G.drag = {i, el: G.dom[i], x: e.clientX, y: e.clientY, moved: false, id: e.pointerId};
      try { G.boardEl.setPointerCapture(e.pointerId); } catch (_) {}
    } else G.sel = null;
    paintMarks(); e.preventDefault();
  }
  function onMove(e) {
    const d = G.drag; if (!d || e.pointerId !== d.id) return;
    const dx = e.clientX - d.x, dy = e.clientY - d.y;
    if (!d.moved && Math.hypot(dx, dy) > 7) { d.moved = true; d.el.classList.add("drag"); }
    if (d.moved) d.el.style.transform = "translate(calc(" + d.el.dataset.x * 100 + "% + " + dx + "px), calc(" + d.el.dataset.y * 100 + "% + " + dy + "px)) scale(1.18)";
  }
  function onUp(e) {
    const d = G.drag; if (!d || e.pointerId !== d.id) return;
    G.drag = null; d.el.classList.remove("drag");
    if (!d.moved) return;
    const to = sqAt(e);
    if (to >= 0 && targets(d.i).includes(to)) doMove(d.i, to); else place(d.el, d.i);
  }
  function askPromo(white) {
    return new Promise(res => {
      G.pend = true;
      const done = v => { G.pend = false; ov.remove(); res(v); };
      const ov = h("div", {class: "gm-promo", onclick: e => { if (e.target === ov) done(null); }},
        h("div", {class: "gm-pbox"}, ["q", "r", "b", "n"].map(p => h("button", {type: "button", class: "gm-pp " + (white ? "pw" : "pb"), "aria-label": p, onclick: () => done(p)}, GLYPH[p]))));
      G.boardEl.append(ov);
    });
  }
  async function doMove(f, t) {
    const ch = G.bd[f];
    if (ch.toLowerCase() === "p" && ((t >> 3) === 7 || (t >> 3) === 0)) {
      const p = await askPromo(ch === "P");
      if (!p) { if (G.dom[f]) place(G.dom[f], f); return; }
      return commit(f, t, p);
    }
    commit(f, t, "");
  }
  function commit(f, t, promo) {
    G.sel = null; G.waiting = true; clearTimeout(G.wt);
    G.wt = setTimeout(() => { if (G.waiting) { G.waiting = false; wsTry({type: "game_sync"}); } }, 2500);
    const mover = G.bd[f].toLowerCase(), cast = mover === "k" && Math.abs(t - f) === 2;
    const cap = applyMove(f, t, promo);
    SND.move(true, cap, {castle: cast, promo}); paintMarks();
    send({type: "game_move", gid: G.st.gid, from: sqName(f), to: sqName(t), promo: promo || undefined});
  }

  function openScreen() {
    if (G.el) return;
    if (G.st && G.st.over) { G.st = null; G.clock = null; G.waiting = false; G.overFor = null; }
    const root = h("div", {id: "gm", class: "gm"});
    G.main = h("div", {class: "gm-main"});
    G.rxl = h("div", {class: "gm-rxl", "aria-hidden": "true"});
    root.append(
      h("div", {class: "gm-top"},
        h("b", {class: "gm-ttl", text: "♟ Online Shaxmat"}),
        h("span", {class: "gm-sp"}),
        h("button", {class: "gm-x", type: "button", "aria-label": "Ovoz", onclick: ev => {
          const on = !gSndOn(); try { localStorage.setItem(GSND_KEY, on ? "on" : "off"); } catch (_) {}
          ev.currentTarget.textContent = on ? "🔊" : "🔇"; if (on) SND.start();
        }}, gSndOn() ? "🔊" : "🔇"),
        h("button", {class: "gm-x", type: "button", "aria-label": "Yopish", onclick: () => closeScreen()}, "✕")),
      G.main, G.rxl);
    document.body.append(root); G.el = root;
    navPush("game");
    render(); startTick();
  }
  function closeScreen() {
    if (!G.el) return;
    if (G.st && G.st.over) { G.st = null; G.clock = null; G.waiting = false; G.overFor = null; }
    closeSheet(); G.el.remove(); G.el = null; G.main = null; G.rxl = null; G.sqs = []; G.boardEl = null;
    navPop("game"); stopTick();
    if (S.tab === "games") renderList();
  }
  function render() {
    if (!G.el) return;
    G.main.textContent = ""; G.top = G.bot = G.hs = G.undoBtn = null; G.sel = null; G.drag = null; G.view = null;
    if (G.st) buildGame(); else buildLobby();
  }
  function menuItem(ico, title, sub, fn) {
    return h("button", {class: "gm-mi", type: "button", onclick: fn},
      h("span", {class: "gm-mic", text: ico}), h("span", {class: "gm-mt"}, h("b", {text: title}), h("small", {text: sub})), h("span", {class: "gm-mgo", text: "›"}));
  }
  function openBotSheet() {
    if (G.st && !G.st.over) { toast("Avval joriy o'yinni tugating", "warn"); return; }
    OffChess.open();
  }
  function openRules() {
    const li = (ico, t) => h("div", {class: "gm-rl"}, h("span", {text: ico}), h("div", {text: t}));
    openSheet("ℹ️ Qoidalar va ochkolar", h("div", {class: "gm-rules"},
      li("⏱", "Har bir o'yinchiga 10 daqiqa. Oxirgi 10 soniyada soat «tik» qiladi."),
      li("➕", "Taklif 60 soniya kutiladi. Oflayn foydalanuvchiga bildirishnoma boradi."),
      li("🏆", "Yutsangiz +10 ochko va tezlik, olingan toshlar, mat va pyonni ferzga chiqarish uchun bonus (jami +25 gacha). Yutqazsangiz −10."),
      li("🤝", "Durang — ochko o'zgarmaydi."),
      li("⚠️", "8 yarim yurishdan qisqa o'yinlar va bir juftlik bilan kuniga 5 tadan ortiq o'yin ochko bermaydi."),
      li("🤖", "Bot bilan o'yin ochko bermaydi va Score boardga yozilmaydi."),
      li("🔊", "Yurish ovozi: sizniki past va yumshoq, raqibniki balandroq. Yuqoridagi 🔊 tugmasi bilan o'chirasiz.")), {kind: "rules"});
  }
  async function openReactEditor() {
    const body = h("div", {class: "gm-rxe"}, h("div", {class: "none", text: "Yuklanmoqda…"}));
    openSheet("⚙ Shaxmat reaksiyalari", body, {kind: "rxedit"});
    let cfg;
    try { cfg = await api("/games/chess/reactions"); } catch (err) { if (G.sheet && G.sheet.kind === "rxedit") { body.textContent = ""; body.append(h("div", {class: "none", text: err.message})); } return; }
    if (!G.sheet || G.sheet.kind !== "rxedit") return;
    let items = cfg.items.slice();
    const cur = h("div", {class: "gm-rxcur"}), cnt = h("small", {class: "gm-rxcnt"}), pickEl = h("div", {class: "gm-rxpick"});
    const sync = () => {
      cur.textContent = "";
      items.forEach(e => cur.append(h("button", {type: "button", class: "gm-rxc", title: "Olib tashlash", onclick: () => { toggle(e); }}, rxGlyph(e, "gm-re-e"))));
      cnt.textContent = items.length + " / " + cfg.max + " (kamida " + cfg.min + ")";
      pickEl.querySelectorAll(".rx-opt").forEach(x => x.classList.toggle("on", items.includes(x._e)));
    };
    const toggle = e => {
      if (items.includes(e)) { if (items.length <= cfg.min) { toast("Kamida " + cfg.min + " ta reaksiya bo'lishi kerak", "warn"); return; } items = items.filter(x => x !== e); }
      else { if (items.length >= cfg.max) { toast("Ko'pi bilan " + cfg.max + " ta reaksiya", "warn"); return; } items.push(e); }
      sync();
    };
    const mk = e => { const b = h("button", {type: "button", class: "rx-opt", title: e}, rxGlyph(e)); b._e = e; b.addEventListener("click", ev => { ev.stopPropagation(); toggle(e); }); return b; };
    pickEl.append(rxPackView(mk, {k: null}, "rx-grid"));
    const save = async body2 => {
      try { const j = await api("/games/chess/reactions", {method: "PUT", body: body2}); toast("Saqlandi", "ok"); if (G.st) G.st.reacts = j.items; closeSheet("rxedit"); }
      catch (err) { toast(err.message, "error"); }
    };
    body.textContent = "";
    body.append(
      h("p", {class: "gm-note", text: "Shaxmat o'yinida hamma ko'radigan reaksiyalar. Bosib qo'shing yoki olib tashlang. Maxsus emojilar ham mumkin (hamma uchun ko'rinadi)."}),
      h("div", {class: "gm-rxh"}, h("b", {text: "Tanlanganlar"}), cnt), cur, pickEl,
      h("div", {class: "gm-rxb"},
        h("button", {class: "btn ghost", type: "button", text: "Standartga qaytarish", onclick: () => save({items: null})}),
        h("button", {class: "btn", type: "button", text: "Saqlash", onclick: () => save({items})})));
    sync();
  }
  function buildLobby() {
    G.me = "w"; G.bd = START.split("");
    const off = !!S.offline;
    const online = off ? 0 : S.members.filter(m => m.id !== S.me.id && !m.deleted && isOnline(m.id)).length;
    const stats = h("div", {class: "gm-mst"}), extra = h("div", {class: "gm-mx"});
    const saved = OffChess.hasSaved();
    const root = h("div", {class: "gm-menu"},
      h("div", {class: "gm-mh"}, h("div", {class: "gm-mart", text: "♞"}), h("b", {text: "Online Shaxmat"}), h("small", {text: off ? "Internet yo'q — faqat bot bilan o'ynash mumkin" : "Har bir o'yinchiga 10 daqiqa"}), stats),
      off ? null : menuItem("➕", "Taklif qilish", (online ? online + " ta onlayn • " : "") + "javob uchun 60 soniya", openInvite),
      menuItem("🤖", "Bot bilan o'ynash", saved ? "● To'xtatilgan o'yin bor — davom eting" : "5 daraja • maslahat • orqaga • ochko berilmaydi", openBotSheet),
      off ? null : menuItem("🏆", "Score board", "Faqat haqiqiy o'yinchilar o'rtasidagi o'yinlar", openScore),
      extra);
    extra.append(h("button", {class: "gm-ml", type: "button", onclick: openRules}, "ℹ️ Qoidalar"));
    if (off) { G.main.append(root); return; }
    G.main.append(root);
    api("/games/chess/scoreboard").then(j => {
      if (!root.isConnected) return; const me = j.me, n = me.wins + me.losses + me.draws;
      stats.textContent = "";
      if (!n) { stats.append(h("span", {class: "gm-chip", text: "Hali o'ynalmagan — birinchi bo'ling!"})); return; }
      stats.append(h("span", {class: "gm-chip", text: "🏆 " + me.points + " ochko"}), h("span", {class: "gm-chip", text: me.rank ? "# " + me.rank + " o'rin" : "— o'rin"}), h("span", {class: "gm-chip", text: me.wins + " / " + me.losses + " / " + me.draws}));
    }).catch(() => {});
    api("/games/chess/reactions").then(c => {
      if (root.isConnected && c.manage) extra.append(h("button", {class: "gm-ml", type: "button", onclick: openReactEditor}, "⚙ Reaksiyalar (admin)"));
    }).catch(() => {});
  }
  const BOT_NAME = "Bot";
    function playerRow(side) {
    const uid = side === "w" ? G.st.white : G.st.black, isBot = G.st.bot && uid === 0, u = isBot ? null : U(uid);
    const cap = h("span", {class: "gm-cap"}), pts = h("span", {class: "gm-pp2"}), clk = h("div", {class: "gm-clk", text: "10:00"});
    const el = h("div", {class: "gm-pl"}, isBot ? h("div", {class: "gm-botav", text: "🤖"}) : avatar(u, "m", true), h("div", {class: "gm-pi"}, h("div", {class: "gm-pn"}, isBot ? BOT_NAME : nameEl(u)), cap, pts), clk);
    return {el, side, cap, pts, clk};
  }
  function buildGame() {
    const st = G.st, opp = G.me === "w" ? "b" : "w";
    G.bd = st.board.split("");
    G.top = playerRow(opp); G.bot = playerRow(G.me);
    const reacts = h("div", {class: "gm-reacts"}, (st.reacts && st.reacts.length ? st.reacts : REACTS).map(e => {
      const b = h("button", {type: "button", class: "gm-re", title: e.startsWith(":") ? e.slice(1, -1) : e}, rxGlyph(e, "gm-re-e"));
      b.addEventListener("click", () => sendReact(e, b)); return b;
    }));
    G.undoBtn = st.bot ? h("button", {class: "gm-undo", type: "button", disabled: !st.canUndo, onclick: undoMove}, "↩ Qaytarish") : null;
    const act = h("div", {class: "gm-act"},
      h("button", {class: "gm-resign", type: "button", onclick: resign}, "🏳 Taslim"), G.undoBtn, st.bot ? h("span", {class: "gm-botnote", text: "Ochko berilmaydi"}) : reacts);
    G.main.append(h("div", {class: "gm-wrap"}, G.top.el, boardBlock(true), G.bot.el, buildHist(), act));
    paintMarks(); paintPlayers(); tickClocks();
  }
  function paintPlayers() {
    const st = G.st; if (!st || !G.top) return;
    [G.top, G.bot].forEach(r => {
      const mine = st.captured[r.side] || [], other = st.captured[r.side === "w" ? "b" : "w"] || [];
      const sum = a => a.reduce((n, c) => n + VAL[c.toLowerCase()], 0), diff = sum(mine) - sum(other);
      r.cap.textContent = "";
      [...mine].sort((a, b) => VAL[b.toLowerCase()] - VAL[a.toLowerCase()]).forEach(c => r.cap.append(h("span", {class: "gc " + (c === c.toLowerCase() ? "pb" : "pw"), text: GLYPH[c.toLowerCase()]})));
      if (diff > 0) r.cap.append(h("span", {class: "gm-diff", text: "+" + diff}));
      r.pts.textContent = "";
      if (st.bot) { r.pts.append(h("span", {class: "gm-tot", text: (r.side === (st.white === 0 ? "w" : "b")) ? "O'rtacha daraja" : "Ochkosiz o'yin"})); r.el.classList.toggle("turn", !st.over && st.turn === r.side); return; }
      r.pts.append(h("span", {class: "gm-tot", title: "Jami ochko", text: "🏆 " + st.base[r.side]}),
        h("span", {class: "gm-up", title: "Yutsa olinadigan ochko (tezlik va olingan toshlarga qarab o'sib boradi)", text: "+" + st.preview[r.side]}),
        h("span", {class: "gm-dn", title: "Yutqazsa", text: "−10"}));
      r.el.classList.toggle("turn", !st.over && st.turn === r.side);
    });
  }
  function fmt(ms) { const s = Math.ceil(Math.max(0, ms) / 1000); return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0"); }
  function tickClocks() {
    if (!G.el || !G.st || !G.clock) return;
    const c = G.clock, el = performance.now() - c.at;
    [G.top, G.bot].forEach(r => {
      if (!r) return;
      let ms = c[r.side]; if (c.running && c.turn === r.side) ms -= el;
      r.clk.textContent = fmt(ms); r.clk.classList.toggle("low", ms < 20000);
      if (r === G.bot && c.running && c.turn === r.side && ms > 0 && ms < 10000) { const sec = Math.ceil(ms / 1000); if (G.tickSec !== sec) { G.tickSec = sec; SND.tick(); } }
    });
  }
  function startTick() { if (!G.tick) G.tick = setInterval(tickClocks, 250); }
  function stopTick() { clearInterval(G.tick); G.tick = 0; }
  function undoMove() {
    if (!G.st || G.st.over || !G.st.bot || !G.st.canUndo || G.waiting) return;
    send({type: "game_undo", gid: G.st.gid});
  }
  async function resign() {
    if (!G.st || G.st.over) return;
    if (await confirmDlg(G.st.bot ? "Taslim bo'lsangiz o'yin tugaydi (bot bilan o'yinda ochko ayrilmaydi). Taslim bo'lasizmi?" : "Taslim bo'lsangiz o'yin tugaydi va 10 ochko ayriladi. Taslim bo'lasizmi?", {title: "Taslim bo'lish", okText: "Taslim bo'lish", danger: true})) send({type: "game_resign", gid: G.st.gid});
  }

  function onState(st) {
    const prev = G.st, first = !prev || prev.gid !== st.gid;
    G.st = st; G.waiting = false; clearTimeout(G.wt); G.me = st.white === S.me.id ? "w" : "b"; G.sel = null;
    refreshHist();
    if (first) {
      G.overFor = null; closeSheet(); hideInvite(); G.out = null;
      if (!G.el) openScreen(); else render();
      haptic([40, 40, 40]); SND.start();
      if (S.tab === "games") renderList();
    } else {
      const l = st.last, adv = !!l && st.plies === prev.plies + 1;
      if (st.plies < prev.plies) G.view = null;
      if (G.view == null) {
        if (adv && G.bd.join("") !== st.board) {
          const cap = applyMove(sqIdx(l.from), sqIdx(l.to), l.promo); SND.move(false, cap, l); haptic(12);
        }
        reconcile(st.board);
        if (G.boardEl) G.boardEl.classList.remove("rev");
      } else if (adv) SND.move(false, false, l);
      if (adv && st.check && !st.over) SND.check();
    }
    G.clock = Object.assign({}, st.clock, {at: performance.now()});
    paintMarks(); paintPlayers(); tickClocks(); paintHist();
    if (G.undoBtn) G.undoBtn.disabled = !st.canUndo || !!st.over;
    if (st.over) showOver(st);
  }
  function showOver(st) {
    if (G.overFor === st.gid || !G.el) return;
    G.overFor = st.gid;
    const o = st.over, me = G.me, res = o.result === "d" ? "d" : o.result === me ? "w" : "l", pts = o.pts[me];
    let why = REASON[o.reason] || "";
    if (o.reason === "resign") why = res === "w" ? "Raqib taslim bo'ldi" : "Siz taslim bo'ldingiz";
    const isBot = !!st.bot, num = h("div", {class: "go-pts " + (pts > 0 ? "up" : pts < 0 ? "dn" : "")}, "0");
    const lines = [];
    if (o.bonus && res === "w") lines.push(h("div", {class: "go-bd"}, "Asosiy +10", " • Tezlik +" + o.bonus.speed, " • Olingan toshlar +" + o.bonus.material, " • Taktika +" + o.bonus.tactic));
    if (!isBot && !o.rated && res !== "d") lines.push(h("div", {class: "go-nr", text: "Ochko berilmadi: o'yin juda qisqa edi yoki bu raqib bilan bugun juda ko'p o'ynalgan."}));
    const opp = me === "w" ? st.black : st.white;
    const card = h("div", {class: "gm-over"}, h("div", {class: "go-card"},
      h("div", {class: "go-t", text: res === "w" ? "🏆 Siz yutdingiz!" : res === "l" ? "Yutqazdingiz" : "🤝 Durang"}),
      h("div", {class: "go-r", text: why}), isBot ? h("div", {class: "go-nr", text: "Bot bilan o'yin — ochko berilmaydi va Score boardga yozilmaydi."}) : num, ...(isBot ? [] : lines),
      isBot ? null : h("div", {class: "go-tot", text: "Jami: " + o.total[me] + " ochko"}),
      h("div", {class: "go-b"},
        h("button", {class: "btn", type: "button", text: "🔁 Qayta o'ynash", onclick: () => { card.remove(); leaveGame(); if (isBot) send({type: "game_bot", side: "r"}); else send({type: "game_invite", to: opp}); }}),
        h("button", {class: "btn ghost", type: "button", text: "Yopish", onclick: () => { card.remove(); leaveGame(); }}))));
    G.el.append(card);
    const t0 = performance.now(), dur = 700;
    if (isBot) num.textContent = "";
    const step = now => { const k = Math.min(1, (now - t0) / dur); num.textContent = (pts > 0 ? "+" : pts < 0 ? "−" : "") + Math.round(Math.abs(pts) * k); if (k < 1 && num.isConnected) requestAnimationFrame(step); };
    requestAnimationFrame(step);
    haptic(res === "w" ? [60, 40, 120] : 40);
    setTimeout(() => (res === "w" ? SND.win : res === "l" ? SND.lose : SND.draw)(), 350);
    if (S.tab === "games") renderList();
  }
  function leaveGame() { G.st = null; G.clock = null; G.waiting = false; if (G.el) render(); if (S.tab === "games") renderList(); }

  function sendReact(e, btn) {
    if (!G.st || G.st.over) return;
    const n = Date.now(); if (n - G.rxAt < 900) return; G.rxAt = n;
    if (btn) { btn.classList.add("pop"); setTimeout(() => btn.classList.remove("pop"), 280); }
    send({type: "game_react", gid: G.st.gid, emoji: e});
  }
  function onReact(m) {
    if (!G.el || !G.st || G.st.gid !== m.gid || !G.rxl) return;
    const mine = m.uid === S.me.id;
    while (G.rxl.children.length > 4) G.rxl.firstChild.remove();
    const main = rxGlyph(m.emoji, "gmrx-e"); main.classList.add("gmrx-e");
    const stage = h("div", {class: "gmrx-st"}, main);
    for (let i = 0; i < 7; i++) {
      const a = (-90 + (i - 3) * 27 + Math.random() * 12 - 6) * Math.PI / 180, d = 70 + Math.random() * 70;
      const p = rxGlyph(m.emoji, "gmrx-p"); p.classList.add("gmrx-p");
      p.style.setProperty("--dx", Math.round(Math.cos(a) * d * 1.25) + "px"); p.style.setProperty("--dy", Math.round(Math.sin(a) * d) + "px");
      p.style.setProperty("--s", (0.3 + Math.random() * 0.3).toFixed(2)); p.style.animationDelay = i * 30 + "ms";
      stage.append(p);
    }
    const fx = h("div", {class: "gmrx " + (mine ? "me" : "op")}, stage, h("small", {text: mine ? "Siz" : U(m.uid).nickname}));
    G.rxl.append(fx); setTimeout(() => fx.remove(), 2400);
    SND.react(mine); if (!mine) haptic(25);
  }

  function closeSheet(kind) {
    if (!G.sheet || (kind && G.sheet.kind !== kind)) return;
    G.sheet.el.remove(); G.sheet = null;
  }
  function openSheet(title, body, opts = {}) {
    if (!G.el) openScreen();
    closeSheet();
    const back = h("div", {class: "gm-sheet", onclick: e => { if (e.target === back) dismiss(); }});
    const dismiss = () => { const s = G.sheet; closeSheet(); if (s && s.onClose) s.onClose(); };
    back.append(h("div", {class: "gm-panel"}, h("div", {class: "gm-ph"}, h("b", {text: title}), h("button", {class: "gm-x", type: "button", "aria-label": "Yopish", onclick: dismiss}, "✕")), body));
    G.el.append(back); G.sheet = {el: back, kind: opts.kind || "", onClose: opts.onClose};
  }
  async function openScore() {
    const body = h("div", {class: "gm-score"}, h("div", {class: "none", text: "Yuklanmoqda…"}));
    openSheet("🏆 Score board", body, {kind: "score"});
    try {
      const j = await api("/games/chess/scoreboard");
      if (!G.sheet || G.sheet.kind !== "score") return;
      body.textContent = "";
      const me = j.me;
      body.append(h("div", {class: "gs-me"},
        h("div", {}, h("b", {text: String(me.points)}), h("small", {text: "ochko"})),
        h("div", {}, h("b", {text: me.rank ? "#" + me.rank : "—"}), h("small", {text: "o'rin"})),
        h("div", {}, h("b", {text: me.wins + " / " + me.losses + " / " + me.draws}), h("small", {text: "yutuq / mag'lubiyat / durang"}))));
      if (!j.top.length) body.append(h("div", {class: "none", text: "Hali o'yin bo'lmagan. Birinchi bo'ling!"}));
      j.top.forEach((r, n) => {
        const u = U(r.uid), medal = ["🥇", "🥈", "🥉"][n] || String(n + 1);
        body.append(h("div", {class: "gs-row" + (r.uid === S.me.id ? " me" : "")},
          h("span", {class: "gs-n", text: medal}), avatar(u, "s"), h("div", {class: "gs-u"}, nameEl(u), h("small", {text: r.wins + " yutuq • " + r.losses + " mag'lub. • " + r.draws + " durang"})),
          h("b", {class: "gs-p", text: String(r.points)})));
      });
    } catch (err) { if (G.sheet && G.sheet.kind === "score") { body.textContent = ""; body.append(h("div", {class: "none", text: err.message})); } }
  }
  function openInvite() {
    if (G.st && !G.st.over) { toast("Avval joriy o'yinni tugating", "warn"); return; }
    if (G.out) { toast("Avvalgi taklifga javob kutilmoqda", "warn"); return; }
    const list = h("div", {class: "gm-list"});
    const q = h("input", {class: "gm-q", type: "search", placeholder: "Foydalanuvchini qidirish", autocomplete: "off", autocapitalize: "none", spellcheck: "false"});
    const draw = () => {
      list.textContent = "";
      const t = q.value.trim().toLowerCase();
      const all = S.members.filter(m => m.id !== S.me.id && !m.deleted).map(m => U(m.id))
        .filter(u => !t || u.nickname.toLowerCase().includes(t) || u.username.toLowerCase().includes(t))
        .sort((a, b) => a.nickname.localeCompare(b.nickname));
      const on = all.filter(u => isOnline(u.id)), off = all.filter(u => !isOnline(u.id));
      const row = (u, online) => h("div", {class: "gm-u"}, avatar(u, "m", true),
        h("div", {class: "gm-un"}, nameEl(u), h("small", {text: online ? "onlayn" : "oflayn • bildirishnoma yuboriladi"})),
        h("button", {class: "btn sm" + (online ? "" : " ghost"), type: "button", text: "Taklif", onclick: () => send({type: "game_invite", to: u.id})}));
      if (on.length) { list.append(h("div", {class: "sect", text: "Onlayn — " + on.length})); on.forEach(u => list.append(row(u, true))); }
      if (off.length) { list.append(h("div", {class: "sect", text: "Oflayn"})); off.forEach(u => list.append(row(u, false))); }
      if (!all.length) list.append(h("div", {class: "none", text: "Hech kim topilmadi"}));
    };
    q.addEventListener("input", draw); draw();
    openSheet("➕ O'yinga taklif", h("div", {}, q, list), {kind: "invite"});
  }
  function showWaiting(m) {
    if (!G.el) openScreen();
    const u = U(m.to), ttl = Math.max(1, (m.ttl || 60)) * 1000;
    const bar = h("i"); bar.style.animationDuration = ttl + "ms";
    const cancel = () => { if (G.out) send({type: "game_cancel", id: G.out.id}); };
    openSheet("Taklif yuborildi", h("div", {class: "gm-wait"},
      avatar(u, "l"), h("div", {class: "gw-n"}, nameEl(u)),
      h("div", {class: "gw-s", text: isOnline(m.to) ? "Javob kutilmoqda…" : "Foydalanuvchi oflayn — bildirishnoma yuborildi. Javob kutilmoqda…"}),
      h("div", {class: "gm-bar big"}, bar),
      h("button", {class: "btn ghost", type: "button", text: "Bekor qilish", onclick: cancel})), {kind: "wait", onClose: cancel});
  }

  function hideInvite() { clearTimeout(G.incTimer); if (G.inc) { G.inc.el.remove(); G.inc = null; } }
  function showInvite(m) {
    hideInvite();
    const u = U(m.frm), ttl = Math.max(1, (m.ttl || 60)) * 1000, bar = h("i"); bar.style.animationDuration = ttl + "ms";
    const answer = ok => { send({type: "game_reply", id: m.id, accept: ok}); hideInvite(); };
    const el = h("div", {class: "gm-inv", role: "alertdialog", "aria-label": "Shaxmat taklifi"},
      avatar(u, "m"),
      h("div", {class: "gm-ivt"}, h("b", {text: "♟ Shaxmatga taklif"}), h("span", {}, nameEl(u), " sizni o'yinga taklif qildi")),
      h("div", {class: "gm-ivb"}, h("button", {class: "btn sm", type: "button", text: "Qabul qilish", onclick: () => answer(true)}), h("button", {class: "btn sm ghost", type: "button", text: "Rad etish", onclick: () => answer(false)})),
      h("div", {class: "gm-bar"}, bar));
    document.body.append(el); G.inc = {id: m.id, el};
    haptic([70, 50, 70]);
    G.incTimer = setTimeout(hideInvite, ttl + 400);
  }
  function inviteEnd(m) {
    if (G.inc && G.inc.id === m.id) hideInvite();
    if (G.out && G.out.id === m.id) {
      G.out = null; closeSheet("wait");
      const nm = U(m.to).nickname;
      const t = {declined: nm + " taklifni rad etdi", expired: nm + " javob bermadi — taklif rad etildi", busy: nm + " hozir band", cancelled: "Taklif bekor qilindi"}[m.status];
      if (t) toast(t, m.status === "cancelled" ? "info" : "warn");
    }
  }

  function onWs(m) {
    switch (m.type) {
      case "game_invite": showInvite(m); SND.invite(); break;
      case "game_invite_sent": G.out = {id: m.id, to: m.to}; showWaiting(m); break;
      case "game_invite_end": inviteEnd(m); break;
      case "game_state": onState(m); break;
      case "game_react": onReact(m); break;
    }
  }
  function tabList(list) {
    if (S.offline) {
      list.append(h("button", {class: "gcard", type: "button", onclick: openScreen},
        h("div", {class: "gc-art", text: "♞"}),
        h("div", {class: "gc-t"}, h("b", {text: "Online Shaxmat"}), h("small", {class: OffChess.hasSaved() ? "live" : "", text: OffChess.hasSaved() ? "● To'xtatilgan bot o'yini bor" : "Oflayn: faqat bot bilan o'ynash"})),
        h("span", {class: "gc-on", text: "oflayn"})));
      return;
    }
    const online = S.members.filter(m => m.id !== S.me.id && !m.deleted && isOnline(m.id)).length, live = !!G.st && !G.st.over;
    list.append(h("button", {class: "gcard", type: "button", onclick: openScreen},
      h("div", {class: "gc-art", text: "♞"}),
      h("div", {class: "gc-t"}, h("b", {text: "Online Shaxmat"}), h("small", {class: live ? "live" : "", text: live ? "● O'yin davom etmoqda — qaytish" : "Do'stlar bilan real vaqtda • 10 daqiqa"})),
      h("span", {class: "gc-on", text: online + " onlayn"})));
  }
  function openFromPush() {
    S.tab = "games";
    document.querySelectorAll(".tabs button").forEach(x => x.classList.toggle("on", x.dataset.tab === "games"));
    renderList(); openScreen();
  }
  function reset() { hideInvite(); closeScreen(); G.st = null; G.out = null; G.clock = null; G.overFor = null; G.bd = START.split(""); }
  NAV_CLOSE.game = () => closeScreen();
  return {tabList, onWs, openFromPush, reset, sync: () => wsTry({type: "game_sync"}), snd: SND, sndOn: gSndOn};
})();
})();

(function () {
  let cur = null, raf = 0, timer = 0;
  const HOST = ".item, .pname, .hinfo, .bname, .rq";
  function stop() {
    cancelAnimationFrame(raf); clearTimeout(timer);
    if (cur) { cur.scrollLeft = 0; cur.style.textOverflow = ""; cur.classList.remove("scrolling"); }
    cur = null;
  }
  function start(nt) {
    const max = nt.scrollWidth - nt.clientWidth;
    if (max <= 2) return;
    cur = nt; nt.style.textOverflow = "clip"; nt.classList.add("scrolling");
    const SPEED = 45;
    const run = (dir, from) => {
      const t0 = performance.now();
      const step = now => {
        if (cur !== nt) return;
        const d = Math.min(1, (now - t0) / ((max / SPEED) * 1000));
        nt.scrollLeft = dir > 0 ? max * d : max * (1 - d);
        if (d < 1) raf = requestAnimationFrame(step);
        else timer = setTimeout(() => { if (cur === nt) run(-dir); }, 700);
      };
      raf = requestAnimationFrame(step);
    };
    timer = setTimeout(() => { if (cur === nt) run(1); }, 350);
  }
  document.addEventListener("mouseover", e => {
    const host = e.target.closest && e.target.closest(HOST);
    const nt = host && host.querySelector(".nm .nt");
    if (nt === cur) return;
    stop();
    if (nt) start(nt);
  });
  document.addEventListener("mouseleave", stop);
  document.addEventListener("scroll", stop, true);
})();
