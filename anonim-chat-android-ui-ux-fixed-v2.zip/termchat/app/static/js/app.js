"use strict";
(() => {
/* =====================================================================
   Anonim Chat by Hevorix — veb-mijoz
   Matn DOM'ga faqat textContent orqali chiqariladi (XSS yo'q, CSP qat'iy).
   ===================================================================== */
const NS = "http://www.w3.org/2000/svg";
const $ = id => document.getElementById(id);
const APP_NAME = "Anonim Chat by Hevorix";
const LS_THEME = "termchat_theme";
const LS_STAY = "termchat_stay";                // "bu qurilmada kirib qolish" yoqilgan bo'lsa — sessiya tokeni (foydalanuvchi o'zi tanlaydi)
const WS_UNAUTHORIZED = 4401, WS_FORBIDDEN = 4403, WS_IP_BLOCKED = 4410;
const IDLE_MS = 5 * 60 * 1000;                   // oyna/chat ochiq, lekin 5 daqiqa tegilmasa — qayta login talab qilinadi
const HB_MS = 15000, HB_DEAD_MS = 40000;         // yurak urishi: har 15 s ping; 40 s server javobi yo'q bo'lsa ulanish o'lik hisoblanadi
const delay = ms => new Promise(r => setTimeout(r, ms));
try { localStorage.removeItem("termchat_token"); } catch (_) {}      // eski versiyada saqlangan token endi ishlatilmaydi
const PALETTE = ["#e17076", "#e0954f", "#a695e7", "#7bc862", "#4fb6b9", "#65aadd", "#ee7aae"];
const MONTHS = ["yanvar", "fevral", "mart", "aprel", "may", "iyun", "iyul", "avgust", "sentabr", "oktabr", "noyabr", "dekabr"];
const COARSE = matchMedia("(pointer: coarse)").matches;
const isMobile = () => matchMedia("(max-width: 760px)").matches;

const S = {
  token: null, me: null, ws: null, retry: 0, wantClose: false, mode: "login",
  users: new Map(),            // id -> foydalanuvchi
  members: [],                 // a'zolar ro'yxati (serverdan)
  online: new Set(),
  group: {msgs: [], unread: 0, more: false},   // more: tepada yana eski xabarlar bor (tepaga chiqilganda yuklanadi)
  dms: new Map(),              // uid -> {msgs, loaded, buffer, unread, last}
  chn: new Map(),              // kanal id -> {msgs, loaded, buffer, unread, last, more} (kanal postlari, umumiy chat bilan bir xil xabar tizimi)
  chList: [],                  // kanallar ro'yxati (serverdan; js/channels.js yangilaydi)
  active: null,                // {kind:"group"} | {kind:"dm", uid} | {kind:"channel", id}
  tab: "chats", query: "", editing: null, away: 0, modal: null,
  replying: null,              // {id, nickname, text, image} — javob berilayotgan xabar
  pendingImg: null,            // {blob, url, name} — yuborishga tayyor rasm
  sending: false,
  rec: null, recBusy: false, recTimer: 0,   // ovoz/video yozilmoqda: Voice.record() yoki VNote.record() obyekti
  recKind: "voice", recMode: "voice", vfacing: "user", starting: false, startAbort: false, flipping: false, noClickUntil: 0,   // recMode: tugma rejimi (voice | video)
  imgs: new Map(),             // xabar id -> "loading" | "open" (rasm yuklash holati)
  sel: null,                   // Set<id> — belgilash rejimi yoqilgan bo'lsa
  played: new Map(),           // xabar id -> blob URL (ijro etilgan video/audio)
  previews: new Map(),         // xabar id -> {kind:"code"|"pcap", ...} — fayl ko'rinishi (faqat matn sifatida, hech narsa ishga tushmaydi)
  fx: new Map(),               // terminal animatsiyasi: kalit -> birinchi chizilgan vaqt (qayta-qayta animatsiya bo'lmasin)
  chat: {slowmode: 0, locked: false},   // umumiy chat moderatsiya holati (serverdan)
};

/* ---------------- yordamchilar ---------------- */
function h(tag, props, ...kids) {
  const e = document.createElement(tag);
  if (props) for (const [k, v] of Object.entries(props)) {
    if (v == null || v === false) continue;
    if (k === "class") e.className = v;
    else if (k === "text") e.textContent = v;
    else if (k.startsWith("on")) e.addEventListener(k.slice(2), v);
    else e.setAttribute(k, v === true ? "" : v);
  }
  for (const c of kids.flat()) {
    if (c == null || c === false) continue;
    e.append(c.nodeType ? c : document.createTextNode(String(c)));
  }
  return e;
}
function svgUse(href, cls) {
  const s = document.createElementNS(NS, "svg"); s.setAttribute("class", cls);
  const u = document.createElementNS(NS, "use"); u.setAttribute("href", href); s.append(u);
  return s;
}
const icon = (name, cls) => svgUse("#i-" + name, cls || "ic");
const pad2 = n => String(n).padStart(2, "0");
const hhmm = ts => { const d = new Date(ts * 1000); return pad2(d.getHours()) + ":" + pad2(d.getMinutes()); };
const dayKey = ts => { const d = new Date(ts * 1000); return d.getFullYear() + "-" + d.getMonth() + "-" + d.getDate(); };
function dayLabel(ts) {
  const d = new Date(ts * 1000), now = new Date();
  if (dayKey(ts) === dayKey(now / 1000)) return "Bugun";
  const y = new Date(now); y.setDate(now.getDate() - 1);
  if (dayKey(ts) === dayKey(y / 1000)) return "Kecha";
  return d.getDate() + "-" + MONTHS[d.getMonth()] + (d.getFullYear() !== now.getFullYear() ? ", " + d.getFullYear() : "");
}
function listTime(ts) {
  const d = new Date(ts * 1000), now = new Date();
  if (dayKey(ts) === dayKey(now / 1000)) return hhmm(ts);
  const y = new Date(now); y.setDate(now.getDate() - 1);
  if (dayKey(ts) === dayKey(y / 1000)) return "Kecha";
  return pad2(d.getDate()) + "." + pad2(d.getMonth() + 1) + "." + String(d.getFullYear()).slice(2);
}
const colorOf = id => PALETTE[Math.abs(id) % PALETTE.length];
const isStaff = u => !!u && (u.role === "owner" || u.role === "admin");
const HEX = /^#[0-9a-f]{6}$/i, TONES = {owner: "#f7b733", admin: "#7b61ff"};
const hexRgb = x => { const n = parseInt(x.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
const mixHex = (x, to, t) => "#" + hexRgb(x).map((v, i) => Math.round(v + (to[i] - v) * t).toString(16).padStart(2, "0")).join("");
function toneOf(u) {
  const base = HEX.test(u.color || "") ? u.color.toLowerCase() : TONES[u.role];
  const [r, g, b] = hexRgb(base);
  return {p2: base, p1: mixHex(base, [255, 255, 255], .55), p3: mixHex(base, [0, 0, 0], .4), pr: r + "," + g + "," + b,
    pt: (0.299 * r + 0.587 * g + 0.114 * b) / 255 > .6 ? "#2b2000" : "#fff"};
}
/** Ega/admin elementiga o'zi tanlagan rangni beradi (CSS o'zgaruvchilari; CSP uchun CSSOM orqali). */
function tint(el, u) {
  if (!isStaff(u)) return el;
  const t = toneOf(u);
  ["p1", "p2", "p3", "pr", "pt"].forEach(k => el.style.setProperty("--" + k, t[k]));
  return el;
}
const roleLabel = r => r === "owner" ? "Platforma egasi" : r === "admin" ? "Administrator" : "";
const U = id => S.users.get(id) || {id, nickname: "Noma'lum", username: "?", role: "user", bio: "", avatar: null};
const isOnline = id => S.me && (id === S.me.id || S.online.has(id));
const onlineCount = () => new Set([...S.online, S.me.id]).size;
const amAdmin = () => isStaff(S.me);
const dmOf = uid => {
  if (!S.dms.has(uid)) S.dms.set(uid, {msgs: [], loaded: false, buffer: [], unread: 0, last: null, more: false});
  return S.dms.get(uid);
};
const chOf = id => {
  if (!S.chn.has(id)) S.chn.set(id, {msgs: [], loaded: false, buffer: [], unread: 0, last: null, more: false});
  return S.chn.get(id);
};
const chInfo = id => S.chList.find(c => c.id === id) || null;
const isActiveChan = id => !!S.active && S.active.kind === "channel" && S.active.id === id;
function upsertUser(u) {
  if (!u || u.id == null) return;
  const merged = Object.assign({}, S.users.get(u.id), u);
  S.users.set(u.id, merged);
  if (S.me && u.id === S.me.id) S.me = Object.assign({}, S.me, u);
}

function toast(text, level) {
  const t = h("div", {class: "toast " + (level || "info"), text});
  $("toasts").append(t);
  while ($("toasts").children.length > 4) $("toasts").firstChild.remove();
  setTimeout(() => t.remove(), level === "error" ? 5000 : 3500);
}

async function api(path, opts = {}) {
  const headers = Object.assign({Authorization: "Bearer " + S.token}, opts.headers || {});
  let body = opts.body;
  if (body && !(body instanceof FormData)) { headers["Content-Type"] = "application/json"; body = JSON.stringify(body); }
  const r = await SC.fetch("/api" + path, {method: opts.method || "GET", headers, body});
  const j = await r.json().catch(() => ({}));
  if (r.status === 401) { showAuth("Sessiya tugagan, qayta kiring"); throw new Error("401"); }
  if (!r.ok) throw new Error(typeof j.detail === "string" ? j.detail : "Xato, qayta urinib ko'ring");
  return j;
}
function wsSend(obj) {
  if (!S.ws || S.ws.readyState !== 1) { toast("Ulanish yo'q, biroz kuting…", "error"); return false; }
  S.ws.send(JSON.stringify(obj));
  return true;
}

/* ---------------- E2EE: kalitlar, guruh kaliti, xabarlarni shifrlash/ochish ----------------
   Serverga faqat shifrlangan konvert ketadi. Maxfiy kalitlar qurilmada (IndexedDB, eksport qilib bo'lmaydigan) va
   parol bilan o'ralgan zaxirada (serverda, ochib bo'lmaydigan) saqlanadi. Protokol: js/e2ee.js */
const LS_PINS = "termchat_pins";
const X = {id: 0, username: "", priv: null, ecdhPub: "", signPub: "", fp: "", iter: 0, self: null, rooms: new Map(), keyIds: new Map(),
           epoch: 0, state: null, peers: new Map(), peerReq: new Map(), pending: new Set(), changed: new Map(), ready: null, serving: false, rotating: false};
function xReset() {
  X.id = 0; X.priv = null; X.self = null; X.rooms = new Map(); X.keyIds = new Map(); X.epoch = 0; X.state = null; X.peers = new Map(); X.peerReq = new Map();
  X.pending = new Set(); X.changed = new Map(); X.ready = null; X.serving = false; X.rotating = false;
}
const pinStore = () => { try { return JSON.parse(localStorage.getItem(LS_PINS + "_" + X.id) || "{}"); } catch (_) { return {}; } };
const savePins = p => { try { localStorage.setItem(LS_PINS + "_" + X.id, JSON.stringify(p)); } catch (_) {} };

/* --- shaxsiy kalitlarni sessiyaga o'rnatish --- */
async function xInstall(me, username, ident, pubs, iter, remember) {
  const priv = await E2E.importPrivate(ident);
  X.id = me.id; X.username = username; X.priv = priv; X.ecdhPub = pubs.ecdh_pub; X.signPub = pubs.sign_pub; X.iter = iter;
  X.self = await E2E.importPeer({e: pubs.ecdh_pub, s: pubs.sign_pub}); X.fp = X.self.fp;
  /* Maxfiy kalitlar qurilmada SAQLANMAYDI: har kirishda username + parol so'raladi, kalitlar paroldan qayta hosil bo'ladi. */
}
async function xGenerate(username, password, iter) {
  const kd = await E2E.deriveFromPassword(username, password, iter);
  const ident = await E2E.generateIdentity();
  const keys = {ecdh_pub: ident.ecdhPub, sign_pub: ident.signPub, key_blob: await E2E.wrapIdentity(ident, kd.kek, username), kdf_iter: iter};
  return {kd, ident, keys};
}
/* --- tizimga kirgandan keyin: kalitlarni tayyorlash (yangi akkaunt, eski akkauntni yangilash yoki parol bilan ochish) --- */
async function xUnlock(info, me, username, password) {
  if (info.upgrade) {                                           // eski akkaunt: kalitlar brauzerda yaratiladi, parol hash'i almashadi
    const g = await xGenerate(username, password, E2E.KDF_DEFAULT);
    await api("/e2ee/setup", {method: "POST", body: {old: password, auth: g.kd.auth, keys: g.keys}});
    await xInstall(me, username, g.ident, g.keys, E2E.KDF_DEFAULT, true);
    return;
  }
  const e = info.e2ee, kd = await E2E.deriveFromPassword(username, password, e.kdf_iter || E2E.KDF_DEFAULT);
  let ident;
  try { ident = await E2E.unwrapIdentity(e.key_blob, kd.kek, username); } catch (_) { throw new Error("Parol noto'g'ri (kalitlarni ochib bo'lmadi)"); }
  await xInstall(me, username, ident, e, e.kdf_iter || E2E.KDF_DEFAULT, true);
}
/* --- sahifa yangilanganda: kalitlar qurilmada bo'lsa parolsiz, bo'lmasa parol so'rab --- */
async function xRestore(info, me) {
  if (!info.upgrade && info.e2ee.ecdh_pub) {
    const rec = await E2E.loadIdentity(me.id);
    if (rec && rec.ecdhPub === info.e2ee.ecdh_pub && rec.signPub === info.e2ee.sign_pub) {
      X.id = me.id; X.username = me.username; X.priv = {ecdhPriv: rec.ecdhPriv, signPriv: rec.signPriv};
      X.ecdhPub = rec.ecdhPub; X.signPub = rec.signPub; X.iter = rec.iter || info.e2ee.kdf_iter;
      X.self = await E2E.importPeer({e: rec.ecdhPub, s: rec.signPub}); X.fp = X.self.fp;
      return true;
    }
  }
  for (let tries = 0; tries < 5; tries++) {
    const pw = await promptDlg(info.upgrade ? "Shifrlashni yoqish" : "Kalitlarni ochish",
      info.upgrade ? "Xabarlaringiz endi uchdan-uchga shifrlanadi. Davom etish uchun parolingizni kiriting (kalitlar shu qurilmada yaratiladi)."
        : "Shifrlash kalitlari bu qurilmada yo'q. Ularni ochish uchun parolingizni kiriting.", "", {type: "password", okText: "Ochish"});
    if (pw === null) return false;
    try { await xUnlock(info, me, me.username, pw); return true; } catch (err) { toast(err.message, "error"); }
  }
  return false;
}

/* --- boshqa foydalanuvchilarning ommaviy kalitlari (+ barmoq izini qadash, TOFU) --- */
function peer(uid) {
  if (uid === X.id) return Promise.resolve(X.self);
  const p = X.peers.get(uid);
  if (p) return Promise.resolve(p);
  let req = X.peerReq.get(uid);                          // bir vaqtda bir xil kalit so'rovi takrorlanmaydi
  if (!req) { req = loadPeer(uid).finally(() => X.peerReq.delete(uid)); X.peerReq.set(uid, req); }
  return req;
}
async function loadPeer(uid) {
  let p;
  const m = S.members.find(x => x.id === uid);
  let keys = m && m.ek ? {e: m.ek, s: m.sk} : null;
  if (!keys) { const j = await api("/e2ee/keys?ids=" + uid); keys = j.keys[String(uid)]; }
  if (!keys) throw new Error("Bu foydalanuvchida E2EE kalitlari yo'q");
  p = await E2E.importPeer(keys);
  const pins = pinStore();
  if (pins[uid] && pins[uid] !== p.fp) { p.changed = true; X.changed.set(uid, {old: pins[uid], now: p.fp}); }
  else if (!pins[uid]) { pins[uid] = p.fp; savePins(pins); }
  X.peers.set(uid, p);
  return p;
}
function acceptKeyChange(uid) {
  const c = X.changed.get(uid); if (!c) return;
  const pins = pinStore(); pins[uid] = c.now; savePins(pins);
  X.changed.delete(uid); const p = X.peers.get(uid); if (p) p.changed = false;
}

/* --- guruh kaliti --- */
async function loadRoom() {
  const st = await api("/e2ee/room"); X.state = st; X.epoch = st.epoch;
  for (const w of st.mine) {
    if (X.rooms.has(w.epoch)) continue;
    const ep = st.epochs.find(e => e.epoch === w.epoch);
    try {
      const wp = await peer(w.by);
      const key = await E2E.unwrapRoomKey(w.wrapped, w.epoch, X.priv.ecdhPriv, X.id, wp.ecdh, w.by);
      if (!ep || !(await E2E.verifyEpochCheck(ep.check, key, w.epoch))) throw new Error("tekshiruv");
      X.rooms.set(w.epoch, key); X.keyIds.set(w.epoch, await E2E.keyId(key));
    } catch (_) {                                              // soxta/buzilgan o'ralgan kalit: o'chirib, boshqa a'zodan qayta so'raymiz
      try { await api("/e2ee/room/wrap/" + w.epoch, {method: "DELETE"}); } catch (__) {}
    }
  }
  if (st.epoch === 0) await initRoom();
  else if (X.rooms.has(st.epoch)) { rehydratePending(); serveWraps(); }
  if (!X.rooms.has(X.epoch) && X.epoch) renderHeader();
}
async function initRoom() {
  const key = await E2E.newRoomKey(), withKeys = S.members.filter(m => m.ek && !m.banned && !m.deleted);
  const list = withKeys.some(m => m.id === X.id) ? withKeys : withKeys.concat([{id: X.id, ek: X.ecdhPub}]);
  const wraps = [];
  for (const m of list) wraps.push({user_id: m.id, wrapped: await E2E.wrapRoomKey(key, 1, X.priv.ecdhPriv, X.id, (await peer(m.id)).ecdh, m.id)});
  try { await api("/e2ee/room/init", {method: "POST", body: {check: await E2E.epochCheck(key, 1), wraps}}); }
  catch (_) { /* boshqa a'zo oldinroq yaratdi */ }
  const st = await api("/e2ee/room"); if (st.epoch) { X.state = st; X.epoch = st.epoch; await loadRoomKeysOnly(); }
}
async function loadRoomKeysOnly() { if (X.epoch) await loadRoom(); }
async function serveWraps() {                                   // yangi a'zolarga (kaliti hali yo'qlarga) kalitni o'rab beramiz
  if (X.serving || !X.rooms.size) return;
  X.serving = true;
  try {
    const j = await api("/e2ee/room/missing"), byEp = new Map();
    j.missing.forEach(m => { if (X.rooms.has(m.epoch) && m.user_id !== X.id) (byEp.get(m.epoch) || byEp.set(m.epoch, []).get(m.epoch)).push(m); });
    for (const [ep, list] of byEp) {
      const wraps = [];
      for (const m of list.slice(0, 100)) {
        try {
          const pk = await E2E.importEcdhPub(m.ecdh_pub);
          wraps.push({user_id: m.user_id, wrapped: await E2E.wrapRoomKey(X.rooms.get(ep), ep, X.priv.ecdhPriv, X.id, pk, m.user_id)});
        } catch (_) {}
      }
      if (wraps.length) await api("/e2ee/room/wrap", {method: "POST", body: {epoch: ep, wraps}});
    }
  } catch (_) {}
  X.serving = false;
}
async function rotateRoom(reason) {                              // ban/chiqib ketishdan keyin: yangi kalit, faqat joriy a'zolarga
  if (X.rotating || !amAdmin() || !X.rooms.has(X.epoch)) return;
  X.rotating = true;
  try {
    await loadMembers();
    const key = await E2E.newRoomKey(), ep = X.epoch + 1, wraps = [];
    for (const m of S.members.filter(m => m.ek && !m.banned && !m.deleted))
      wraps.push({user_id: m.id, wrapped: await E2E.wrapRoomKey(key, ep, X.priv.ecdhPriv, X.id, (await peer(m.id)).ecdh, m.id)});
    await api("/e2ee/room/rotate", {method: "POST", body: {from_epoch: X.epoch, check: await E2E.epochCheck(key, ep), wraps, reason: (reason || "rotate").slice(0, 20)}});
    toast("Guruh kaliti yangilandi (yangi xabarlar eski a'zolar uchun yopiq)", "ok");
  } catch (_) {}
  X.rotating = false;
  try { await loadRoom(); } catch (_) {}
}

/* --- xabar konvertini ochish --- */
const fileIco = f => f.voice ? "🎤 " : f.vnote ? "📹 " : "📎 ";
const fileWhat = f => f.voice ? "Ovozli xabar" : f.vnote ? "Video xabar" : f.name;
const THUMB_RE = /^data:image\/jpeg;base64,[A-Za-z0-9+/]{16,4200}={0,2}$/;     // dumaloq video: xira kichik nusxa (begona ma'lumot — qat'iy tekshiriladi)
const replyInfo = m => ({id: m.id, uid: m.user.id, nickname: m.user.nickname, text: snippetOf(m.content), image: !!m.image, file: !!m.file, voice: !!(m.file && m.file.voice), vnote: !!(m.file && m.file.vnote), file_name: m.file ? fileWhat(m.file) : null});
async function hydrate(m) {
  if (!m || m.service || !m.e2e) { if (m && !m.service && !m.e2e) m.legacy = true; return m; }
  m.locked = false; m.bad = false; m.verified = false;
  try {
    const env = E2E.parseEnvelope(m.e2e), sender = m.user.id, me = X.id;
    let key;
    if (m.ch || m.to == null) {                                  // kanal posti ham guruh kaliti bilan shifrlanadi (xonasi AAD ichida)
      key = X.rooms.get(env.ep);
      if (!key) { m.locked = true; m.content = ""; X.pending.add(m); return m; }
    } else {
      const other = sender === me ? m.to : sender, op = await peer(other);
      if (op.changed) throw new Error("kalit o'zgargan");
      key = await E2E.dmKey(X.priv.ecdhPriv, op.ecdh, sender, m.to);
    }
    const sp = await peer(sender);
    const r = await E2E.openMessage(m.e2e, {sender, peer: m.to, key, signKey: sp.sign, room: m.ch ? "c:" + m.ch : undefined});
    const p = r.payload; m.verified = r.verified && !sp.changed;
    m.content = typeof p.t === "string" ? p.t : "";
    m.reply = p.r ? Object.assign({deleted: false}, p.r) : null;
    m._r = p.r || null; m._f = p.f || null;
    m._fw = p.fw && typeof p.fw === "object" && typeof p.fw.n === "string" ? {n: p.fw.n.slice(0, 40), id: Number.isInteger(p.fw.id) ? p.fw.id : 0} : null;
    m.fwd = m._fw;
    if (p.f) {
      m.mkey = p.f.k;
      if (p.f.img) { m.image = "e2e"; m.thumb = p.f.th || null; m.w = p.f.w || null; m.h = p.f.h || null; }
      else m.file = {url: m.blob ? m.blob.url : "", name: p.f.name || "fayl", size: p.f.size || 0, mime: p.f.mime || "application/octet-stream", e2e: true, key: p.f.k,
        voice: p.f.vo === 1 && p.f.mime === "audio/wav", dur: typeof p.f.d === "number" && p.f.d > 0 && p.f.d < 900 ? p.f.d : 0,
        vnote: p.f.rv === 1 && (p.f.mime === "video/webm" || p.f.mime === "video/mp4"), th: typeof p.f.th === "string" && THUMB_RE.test(p.f.th) ? p.f.th : null};
    }
    X.pending.delete(m);
  } catch (err) { m.bad = true; m.content = ""; X.pending.delete(m); }
  return m;
}
async function rehydratePending() {
  const list = [...X.pending]; if (!list.length) return;
  for (const m of list) await hydrate(m);
  renderMessages(false); renderList();
}
const hydrateAll = list => Promise.all(list.map(hydrate));
/* --- kanal posti ostidagi izohlar: guruh kaliti bilan, xonasi "k:<post id>" (boshqa post/kanalga ko'chirib bo'lmaydi) --- */
async function hydrateComment(c) {
  if (!c.e2e) { c.text = typeof c.content === "string" ? c.content : ""; c.verified = false; c.legacy = true; return c; }     // E2EE'dan oldingi izoh
  c.locked = false; c.bad = false; c.verified = false; c.text = "";
  try {
    const env = E2E.parseEnvelope(c.e2e), key = X.rooms.get(env.ep);
    if (!key) { c.locked = true; return c; }
    const sp = await peer(c.user.id);
    const r = await E2E.openMessage(c.e2e, {sender: c.user.id, peer: null, key, signKey: sp.sign, room: "k:" + c.post});
    c.verified = r.verified && !sp.changed;
    c.text = typeof r.payload.t === "string" ? r.payload.t : "";
  } catch (_) { c.bad = true; }
  return c;
}
async function sealComment(postId, text) {
  const key = X.rooms.get(X.epoch);
  if (!key) throw new Error(X.epoch ? "Guruh kaliti hali kelmagan. Biroz kuting…" : "Guruh kaliti yaratilmoqda, biroz kuting…");
  return E2E.sealMessage({sender: X.id, peer: null, ep: X.epoch, key, signKey: X.priv.signPriv, payload: {t: text}, room: "k:" + postId, kind: "c"});
}

/* --- shifrlangan fayllar --- */
async function e2eFetchBlob(m) {
  const url = m.blob ? m.blob.url : (m.file && m.file.url);
  const r = await SC.fetch(url, {headers: {Authorization: "Bearer " + S.token}});
  if (!r.ok) throw new Error("fayl");
  return E2E.decryptFile(r.bytes, m.mkey || m.file.key);
}
const blobUrls = new Map();                                       // xabar id -> ochilgan rasm URL'i
function e2eImageUrl(m) {
  if (!blobUrls.has(m.id)) blobUrls.set(m.id, e2eFetchBlob(m).then(b => URL.createObjectURL(new Blob([b], {type: (m._f && m._f.mime) || "image/jpeg"}))).catch(e => { blobUrls.delete(m.id); throw e; }));
  return blobUrls.get(m.id);
}
const imgSrcOf = m => m.e2e ? e2eImageUrl(m) : Promise.resolve(m.image);

async function cleanImage(blob) {                                 // EXIF/GPS metama'lumot olib tashlanadi (qayta kodlash) + xira kichik nusxa
  const out = {blob, w: 0, h: 0, th: null};
  try {
    const bmp = await createImageBitmap(blob);
    out.w = bmp.width; out.h = bmp.height;
    if (blob.type !== "image/gif") {
      const c = document.createElement("canvas"); c.width = bmp.width; c.height = bmp.height;
      c.getContext("2d").drawImage(bmp, 0, 0);
      const png = blob.type === "image/png", re = await new Promise(r => c.toBlob(r, png ? "image/png" : "image/jpeg", 0.92));
      if (re) out.blob = re;
    }
    const k = 40 / Math.max(bmp.width, bmp.height), t = document.createElement("canvas");
    t.width = Math.max(1, Math.round(bmp.width * k)); t.height = Math.max(1, Math.round(bmp.height * k));
    t.getContext("2d").drawImage(bmp, 0, 0, t.width, t.height);
    out.th = t.toDataURL("image/jpeg", 0.5);
  } catch (_) {}
  return out;
}

/* --- yuborish: konvertni yasab, serverga FAQAT shifrni beramiz --- */
async function keyForActive() { return keyForTarget(S.active); }
async function keyForTarget(tg) {
  if (tg.kind === "channel") {
    if (!amAdmin()) throw new Error("Kanalga faqat adminlar post yoza oladi");
    const key = X.rooms.get(X.epoch);
    if (!key) throw new Error(X.epoch ? "Guruh kaliti hali kelmagan: kalitli a'zo onlayn bo'lishi kerak. Biroz kuting…" : "Guruh kaliti yaratilmoqda, biroz kuting…");
    return {key, peer: null, ep: X.epoch, room: "c:" + tg.id, kind: "c"};
  }
  if (tg.kind === "group") {
    const key = X.rooms.get(X.epoch);
    if (!key) throw new Error(X.epoch ? "Guruh kaliti hali kelmagan: kalitli a'zo onlayn bo'lishi kerak. Biroz kuting…" : "Guruh kaliti yaratilmoqda, biroz kuting…");
    return {key, peer: null, ep: X.epoch};
  }
  const uid = tg.uid, p = await peer(uid);
  if (p.changed) throw new Error("Bu foydalanuvchining shifrlash kaliti o'zgargan! 🔒 tugmasida tekshirib, qabul qiling");
  return {key: await E2E.dmKey(X.priv.ecdhPriv, p.ecdh, X.id, uid), peer: uid, ep: 0};
}
async function sealFor(ctx, payload) {
  return E2E.sealMessage({sender: X.id, peer: ctx.peer, ep: ctx.ep, key: ctx.key, signKey: X.priv.signPriv, payload, room: ctx.room, kind: ctx.kind});
}
function withTarget(msg, tg) {                                   // yuboriladigan paketga manzil: lichka -> to, kanal -> ch
  if (tg.kind === "dm") msg.to = tg.uid; else if (tg.kind === "channel") msg.ch = tg.id;
  return msg;
}

/* ---------------- ko'rinish bo'laklari: avatar, nom, galochka ---------------- */
function paintAv(el, u) {
  el.textContent = "";
  el.style.setProperty("--avc", colorOf(u.id));
  if (u.deleted) { el.classList.add("del"); el.append(icon("ghost")); return; }          // o'chirilgan akkaunt: arvoh belgisi
  if (u.avatar) el.append(h("img", {src: u.avatar, alt: "", draggable: "false"}));
  else el.append(h("span", {text: (Array.from((u.nickname || "?").trim())[0] || "?").toUpperCase()}));
}
function avatar(u, size, withDot) {
  const el = h("div", {class: "av av-" + size + (isStaff(u) ? " ring " + u.role : "")});
  tint(el, u); paintAv(el, u);
  if (withDot && !u.deleted && isOnline(u.id)) el.append(h("span", {class: "dot-on"}));
  return el;
}
function groupAvatar(size) { return h("div", {class: "av av-" + size + " grp"}, icon("group")); }
const hasEmoji = u => !!u && !!u.badge && u.badge !== "none" && u.badge !== "check";
const isVerified = u => !!u && !isStaff(u) && !u.deleted && u.badge === "check";      // admin bergan galochka (admin qilmasdan)
function badge(u, big) {
  if (hasEmoji(u) && Rich.isEmojiToken(u.badge)) {      // maxsus rasmli emoji (Kali, Linux, Anonymous, Ghost...) — admin beradi
    return Rich.emojiEl(u.badge, "eb ceb" + (u.badge_anim ? " a-" + u.badge_anim : "") + (big ? " big" : ""), isStaff(u) ? roleLabel(u.role) : null);
  }
  if (hasEmoji(u)) {                                   // ega/admin tanlagan yoki ular bergan emoji nishon (animatsiya bilan)
    return h("span", {class: "eb" + (u.badge_anim ? " a-" + u.badge_anim : "") + (big ? " big" : ""),
      title: isStaff(u) ? roleLabel(u.role) : "Maxsus nishon", "aria-label": "Nishon", text: u.badge});
  }
  if (!isStaff(u) && !isVerified(u)) return null;
  if (isStaff(u) && u.badge === "none") return null;
  const s = svgUse("#i-vb", "vb " + u.role + (big ? " big" : ""));
  const t = document.createElementNS(NS, "title");
  t.textContent = u.role === "owner" ? "Tasdiqlangan — platforma egasi" : u.role === "admin" ? "Tasdiqlangan administrator" : "Tasdiqlangan foydalanuvchi";
  s.prepend(t);
  return s;
}
function newTag(u, big) {                              // yangi akkaunt: hali ishonish qiyin
  return u && u.new && !u.deleted && !isStaff(u) ? h("span", {class: "newb" + (big ? " big" : ""), title: "Yangi foydalanuvchi — hali ishonch qozonmagan. Ehtiyot bo'ling", text: "⚠ Yangi"}) : null;
}
function nameEl(u, opts = {}) {
  const nt = h("span", {class: "nt", text: u.nickname});
  if (opts.colored && !isStaff(u) && !u.deleted) nt.style.color = colorOf(u.id);
  return tint(h("span", {class: "nm" + (isStaff(u) ? " prem " + u.role : "") + (u.deleted ? " deleted" : "")}, nt, badge(u, opts.big), newTag(u, opts.big)), u);
}
const statusText = u => u.deleted ? "akkaunt o'chirilgan" : isOnline(u.id) ? "onlayn" : "oflayn";

/* ---------------- kirish / chiqish ---------------- */
function setMode(m) {
  S.mode = m;
  $("tabL").classList.toggle("on", m === "login");
  $("tabR").classList.toggle("on", m === "register");
  $("nickWrap").classList.toggle("hidden", m === "login");
  $("regHint").classList.toggle("hidden", m === "login");
  $("submitBtn").textContent = m === "login" ? "Kirish" : "Ro'yxatdan o'tish";
  $("f_pass").autocomplete = m === "login" ? "current-password" : "new-password";
  $("autherr").textContent = "";
  $("unameChk").classList.add("hidden");
  if (m === "register") $("f_user").dispatchEvent(new Event("input"));
}
let unameTimer = null, unameSeq = 0;
$("f_user").addEventListener("input", () => {            // katta-kichik harfga e'tiborsiz: server tekshiradi
  clearTimeout(unameTimer);
  const chk = $("unameChk"), v = $("f_user").value.trim().replace(/^@/, "");
  if (S.mode !== "register" || !v) { chk.classList.add("hidden"); return; }
  unameTimer = setTimeout(async () => {
    const seq = ++unameSeq;
    try {
      const r = await SC.fetch("/api/username/" + encodeURIComponent(v));
      if (!r.ok) return;
      const j = await r.json();
      if (seq !== unameSeq || S.mode !== "register") return;
      chk.className = "uchk " + (j.available ? "ok" : "bad");
      chk.textContent = j.available ? "✓ Username bo'sh" : "✗ " + j.reason;
    } catch (_) {}
  }, 300);
});
if (!SC.supported()) $("autherr").textContent = "Shifrlash uchun HTTPS (xavfsiz ulanish) kerak. Saytni https:// orqali oching.";
$("tabL").onclick = () => setMode("login");
$("tabR").onclick = () => setMode("register");

const JSON_H = {"Content-Type": "application/json"};
$("form").addEventListener("submit", async e => {
  e.preventDefault();
  const btn = $("submitBtn"); btn.disabled = true; $("autherr").textContent = "";
  const username = $("f_user").value.trim().replace(/^@/, ""), password = $("f_pass").value;
  try {
    if (!SC.supported()) throw new Error("Shifrlash uchun HTTPS (xavfsiz ulanish) kerak");
    $("autherr").textContent = "Shifrlash kalitlari tayyorlanmoqda…";
    await new Promise(r => setTimeout(r, 30));                // matn chiqishi uchun (PBKDF2 bir necha yuz ms)
    let r, gen = null;
    if (S.mode === "register") {
      gen = await xGenerate(username, password, E2E.KDF_DEFAULT);
      r = await SC.fetch("/api/register", {method: "POST", headers: JSON_H, body: JSON.stringify({username, nickname: $("f_nick").value.trim() || username, password: gen.kd.auth, e2ee: gen.keys, remember: $("f_stay").checked})});
    } else {
      const kr = await SC.fetch("/api/kdf", {method: "POST", headers: JSON_H, body: JSON.stringify({username})});
      const kp = await kr.json().catch(() => ({}));
      const secret = kp.auth_v === 0 ? password : (await E2E.deriveFromPassword(username, password, kp.kdf_iter || E2E.KDF_DEFAULT)).auth;
      r = await SC.fetch("/api/login", {method: "POST", headers: JSON_H, body: JSON.stringify({username, password: secret, remember: $("f_stay").checked})});
    }
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(typeof j.detail === "string" ? j.detail : "Xato, qayta urinib ko'ring");
    S.token = j.token; SC.setToken(S.token); S.lastAct = Date.now(); xReset();
    try {
      if (gen) await xInstall(j.me, j.me.username, gen.ident, gen.keys, E2E.KDF_DEFAULT, true);
      else await xUnlock({upgrade: j.upgrade, e2ee: j.e2ee}, j.me, j.me.username, password);
    } catch (err) { try { await SC.fetch("/api/logout", {method: "POST", headers: {Authorization: "Bearer " + S.token}}); } catch (_) {} S.token = null; SC.setToken(null); throw err; }
    $("f_pass").value = ""; $("autherr").textContent = "";
    if ($("f_stay").checked) await persistStay(); else await forgetStay();
    openApp();
  } catch (err) { $("autherr").textContent = err.message; }
  btn.disabled = false;
});

function resetState() {
  S.me = null; S.users = new Map(); S.members = []; S.online = new Set();
  S.group = {msgs: [], unread: 0, more: false}; S.dms = new Map(); S.chn = new Map(); S.chList = []; S.active = null; S.editing = null; S.query = ""; S.tab = "chats";
  S.replying = null; S.pendingImg = null; S.sending = false; S.sel = null; S.imgs = new Map();
  S.played.forEach(u => URL.revokeObjectURL(u)); S.played = new Map(); S.chat = {slowmode: 0, locked: false}; S.previews = new Map(); S.fx = new Map();
  cancelRecording(); voiceStop();
  ["replybar", "imgbar", "editbar"].forEach(id => $(id).classList.add("hidden"));
  $("search").value = ""; $("msgs").textContent = ""; $("inp").value = "";
  EM.data = null; EM.refresh = null; EM.tab = "std"; Rich.setEmojis([], true); $("emojiBtn").classList.add("hidden"); closeEmojiPanel();
}
function showAuth(msg) {
  $("f_user").value = ""; $("f_pass").value = "";            // har kirishda username va parol qaytadan kiritiladi
  S.wantClose = true;
  if (S.ws) try { S.ws.close(); } catch (_) {}
  SC.setToken(null); S.token = null; clearInterval(S.hb); S.hb = 0; clearTimeout(S.rt);
  try { localStorage.removeItem(LS_STAY); } catch (_) {} $("f_stay").checked = false;
  E2E.clearIdentity(); xReset(); blobUrls.forEach(p => p.then(u => URL.revokeObjectURL(u)).catch(() => {})); blobUrls.clear();
  closeModal(); closeCtx(); resetState(); Channels.reset();
  document.body.classList.remove("in-chat"); navReset();
  $("app").classList.add("hidden"); $("auth").classList.remove("hidden");
  $("autherr").textContent = msg || "";
  document.title = APP_NAME;
}
/* ---------------- bildirishnomalar (Web Push) ----------------
   Brauzer BUTUNLAY yopiq bo'lsa ham: umumiy chatga yozishsa — umumiy chat haqida, lichkaga yozishsa — lichka haqida bildirishnoma keladi.
   Onlayn bo'lsangiz xabarlar WebSocket orqali oddiy real vaqtda keladi (push yuborilmaydi). */
const notifLabel = () => {
  const st = Push.state();
  if (!st.ok) return st.why === "ios-install" ? "Bildirishnoma (ilovani o'rnating)" : "Bildirishnoma (qo'llab-quvvatlanmaydi)";
  if (st.permission === "denied") return "Bildirishnoma (bloklangan)";
  return st.on ? "Bildirishnomani o'chirish" : "Bildirishnomani yoqish";
};
async function toggleNotifications() {
  const st = Push.state();
  try {
    if (st.on) { await Push.disable(api); toast("Bu qurilmada bildirishnomalar o'chirildi", "info"); }
    else { await Push.enable(api); toast("Bildirishnomalar yoqildi: brauzer yopiq bo'lsa ham xabar keladi", "ok"); }
  } catch (err) { toast(err.message, "error"); }
}
async function askNotifications() {
  if (!S.token || !Push.shouldAsk()) return;
  Push.markAsked();
  const ok = await confirmDlg("Brauzer yopiq bo'lsa ham umumiy chatga yoki lichkangizga yozishsa, darhol xabar olasiz. Xabar matni bildirishnomada ko'rsatilmaydi.",
    {title: "Bildirishnomalarni yoqamizmi?", okText: "Yoqish"});
  if (!ok || !S.token) return;
  try { await Push.enable(api); toast("Bildirishnomalar yoqildi", "ok"); } catch (err) { toast(err.message, "error"); }
}
function applyPendingChannel() { const p = S.pendingOpen; if (p && p.k === "c") { S.pendingOpen = null; Channels.openById(p.u); } }
function openFromNotification(k, u) {                  // bildirishnoma bosildi: tegishli chatni ochamiz
  if (!S.token || !S.me) { S.pendingOpen = {k, u}; return; }
  if (k === "c") { Channels.openById(u); return; }
  if (k === "d" && u && u !== S.me.id) { if (S.users.has(u)) openChat({kind: "dm", uid: u}); else { S.pendingOpen = {k, u}; loadMembers().then(applyPendingOpen); } }
  else openChat({kind: "group"});
}
function applyPendingOpen() {
  const p = S.pendingOpen; if (!p) return;
  if (p.k === "d" && !S.users.has(p.u)) return;
  S.pendingOpen = null; openFromNotification(p.k, p.u);
}
window.addEventListener("ac-open-chat", e => openFromNotification(e.detail.k, e.detail.u));
try {                                                  // brauzer yopiq edi, bildirishnoma bosib ochildi: /?o=g yoki /?o=d12
  const o = new URLSearchParams(location.search).get("o");
  if (o) {
    if (o === "g") S.pendingOpen = {k: "g"};
    else if (/^d\d{1,9}$/.test(o)) S.pendingOpen = {k: "d", u: parseInt(o.slice(1), 10)};
    else if (/^c\d{1,9}$/.test(o)) S.pendingOpen = {k: "c", u: parseInt(o.slice(1), 10)};
    history.replaceState(null, "", "/");
  }
} catch (_) {}
async function logout() {
  try { await Promise.race([Push.onLogout(api), delay(3000)]); } catch (_) {}       // bu qurilmadagi bildirishnoma obunasi olib tashlanadi
  try { await SC.fetch("/api/logout", {method: "POST", headers: {Authorization: "Bearer " + S.token}}); } catch (_) {}
  showAuth("");
}

/* ---------------- mavzu ---------------- */
function toggleTheme() {
  const t = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
  document.documentElement.dataset.theme = t;
  const mc = document.querySelector('meta[name="theme-color"]'); if (mc) mc.setAttribute("content", t === "dark" ? "#17212b" : "#ffffff");
  try { localStorage.setItem(LS_THEME, t); } catch (_) {}
}

/* ---------------- WebSocket ---------------- */
function sendPresence() {                          // sahifa yashirilsa "away" (oflayn), qaytsa "back" (onlayn)
  const ws = S.ws; if (ws && ws.readyState === 1) ws.send(JSON.stringify({type: document.hidden && !isOwnerMe() ? "away" : "back"}));
}
function startHeartbeat(ws) {
  clearInterval(S.hb);
  S.hb = setInterval(() => {
    if (ws !== S.ws || ws.readyState !== 1) return;
    if (Date.now() - S.lastRx > HB_DEAD_MS) { try { ws.close(); } catch (_) {} return; }   // server javob bermayapti: ulanish o'lik -> qayta ulanamiz
    ws.send(JSON.stringify({type: "ping", i: Math.round((Date.now() - S.lastAct) / 1000)}));
  }, HB_MS);
}
function reconnectNow() {
  if (!S.token || S.wantClose) return;
  clearTimeout(S.rt); S.retry = 0;
  connect();
}
function connect() {
  S.wantClose = false;
  clearInterval(S.hb); clearTimeout(S.rt);
  if (S.ws) { const old = S.ws; S.ws = null; old.onclose = old.onmessage = old.onopen = null; try { old.close(); } catch (_) {} }   // eski ulanish chala qolmasin
  const ws = SC.socket(S.token);                     // shifrlangan WebSocket (token birinchi shifrlangan kadrda)
  S.ws = ws; S.q = Promise.resolve(); S.lastRx = Date.now();       // yangi ulanish — yangi navbat (eski qotib qolgan navbat bu yerga o'tmaydi)
  ws.onopen = () => { S.retry = 0; S.lastRx = Date.now(); $("connbar").classList.add("hidden"); startHeartbeat(ws); if (document.hidden) sendPresence(); };
  ws.onmessage = ev => {                              // tartib saqlanadi: har bir hodisa shifrdan ochilgach qayta ishlanadi
    if (ws !== S.ws) return;
    S.lastRx = Date.now();
    S.q = S.q.then(async () => {
      const m = JSON.parse(ev.data);
      if (m.type === "pong") return;
      await Promise.race([prepare(m), delay(12000)]);   // bitta xabar (kalit kutish, tarmoq) butun navbatni to'xtatib qo'ymasin
      if (ws === S.ws) onMessage(m);
    }).catch(err => console.error(err));
  };
  ws.onclose = ev => {
    if (S.wantClose || ws !== S.ws) return;
    clearInterval(S.hb); S.hb = 0;
    if (ev.code === WS_UNAUTHORIZED) return showAuth("Sessiya tugagan, qayta kiring");
    if (ev.code === WS_FORBIDDEN) return showAuth("Siz ban qilingansiz");
    if (ev.code === WS_IP_BLOCKED) return showAuth("IP manzilingiz bloklangan");
    $("connbar").classList.remove("hidden");
    S.retry++;
    S.rt = setTimeout(() => { if (S.token && !S.wantClose) connect(); }, Math.min(600 * S.retry, 6000));
  };
}

/* ---- faolsizlik: oyna/chat ochiq qolib 5 daqiqa tegilmasa — login so'raladi ---- */
S.lastAct = Date.now();
(function () {
  let t = 0;
  const hit = () => { S.lastAct = Date.now(); };
  const slow = () => { const n = Date.now(); if (n - t > 1500) { t = n; S.lastAct = n; } };
  ["pointerdown", "keydown", "touchstart", "click", "input"].forEach(e => addEventListener(e, hit, {passive: true, capture: true}));
  ["pointermove", "wheel", "touchmove", "scroll"].forEach(e => addEventListener(e, slow, {passive: true, capture: true}));
})();
/* "Har kirishda login so'rash" — foydalanuvchining o'z sozlamasi (standart: YOQILGAN). O'chirilsa token va kalitlar shu qurilmada saqlanadi.
   Hevorix (egasi) hech qachon faolsizlikdan chiqarilmaydi va "oflayn"ga o'tmaydi: u guruh kalitini tarqatadi. */
const stayOn = () => { try { return !!localStorage.getItem(LS_STAY); } catch (_) { return false; } };
const isOwnerMe = () => !!(S.me && S.me.role === "owner");
const idleOff = () => stayOn() || isOwnerMe();
const idleExpired = () => !idleOff() && Date.now() - S.lastAct > IDLE_MS;
async function persistStay() {
  try {
    localStorage.setItem(LS_STAY, S.token);
    await E2E.saveIdentity(X.id, {ecdhPriv: X.priv.ecdhPriv, signPriv: X.priv.signPriv, ecdhPub: X.ecdhPub, signPub: X.signPub, iter: X.iter});
  } catch (_) {}
}
async function forgetStay() {
  try { localStorage.removeItem(LS_STAY); } catch (_) {}
  try { await E2E.clearIdentity(); } catch (_) {}
}
async function toggleStay() {
  if (stayOn()) {                                                    // login so'rashni qaytadan yoqish
    try { await api("/session/persist", {method: "POST", body: {on: false}}); } catch (_) {}
    await forgetStay(); S.lastAct = Date.now();
    toast("Endi sahifa har safar ochilganda login so'raladi", "ok");
  } else {
    const ok = await confirmDlg("Bu qurilmada sahifani ochgan zahoti login so'ralmasdan kirasiz; sessiya va shifrlash kalitlari shu qurilmada saqlanadi. Qurilmani begonalarga bermang. Davom etamizmi?",
      {title: "Login so'rashni o'chirish", okText: "O'chirish"});
    if (!ok) return;
    try { await api("/session/persist", {method: "POST", body: {on: true}}); await persistStay(); toast("Bu qurilmada endi login so'ralmaydi", "ok"); }
    catch (err) { toast(err.message, "error"); }
  }
}
async function resumeStay(tok, tries) {
  $("autherr").textContent = "Kirilmoqda…";
  S.token = tok; SC.setToken(tok);
  let j;
  try { j = await api("/me"); }
  catch (err) {
    if (String(err.message) === "401") return;                      // api() sessiya tugaganini o'zi ko'rsatdi (showAuth)
    S.token = null; SC.setToken(null);
    $("autherr").textContent = "Ulanish yo'q, qayta urinilmoqda…";
    if (tries < 20) setTimeout(() => resumeStay(tok, tries + 1), 3000);
    return;
  }
  xReset(); S.lastAct = Date.now();
  let ok = false;
  try { ok = await xRestore({upgrade: j.upgrade, e2ee: j.e2ee}, j.me); } catch (_) {}
  if (!ok) { try { await SC.fetch("/api/logout", {method: "POST", headers: {Authorization: "Bearer " + tok}}); } catch (_) {} showAuth("Kalitlarni ochib bo'lmadi, qayta kiring"); return; }
  $("autherr").textContent = "";
  openApp();
}
async function idleLogout() {
  if (!S.token) return;
  const t = S.token;
  showAuth("Uzoq vaqt faol bo'lmadingiz. Xavfsizlik uchun qayta kiring");
  try { await Promise.race([SC.fetch("/api/logout", {method: "POST", headers: {Authorization: "Bearer " + t}}), delay(4000)]); } catch (_) {}
}
function checkIdle() {
  if (!S.token) return;
  // video/audio ijro etilayotgan bo'lsa foydalanuvchi faol hisoblanadi (uzun video ko'rayotganda chiqarib yubormaymiz)
  if ([...document.querySelectorAll("video,audio")].some(m => !m.paused && !m.ended) || (VP.audio && !VP.audio.paused)) S.lastAct = Date.now();
  if (idleExpired()) idleLogout();
}
setInterval(checkIdle, 10000);

/* ---- onlayn/oflayn: boshqa sahifa, ilova, ekran o'chishi, tarmoq ---- */
document.addEventListener("visibilitychange", () => {
  if (!S.token) return;
  if (document.hidden) { S.hiddenAt = Date.now(); sendPresence(); return; }          // yashirildi -> server ozgina kutib (miltillamasin) oflayn qiladi
  if (idleExpired()) { idleLogout(); return; }
  if (!S.ws || S.ws.readyState !== 1) reconnectNow(); else sendPresence();     // qaytdi -> onlayn; ulanish o'lgan bo'lsa darhol qayta ulanadi
});
addEventListener("pagehide", () => { if (S.token && S.ws) { try { S.ws.close(); } catch (_) {} } });   // oyna/tab yopildi: darhol oflayn
addEventListener("pageshow", e => { if (e.persisted && S.token) { if (idleExpired()) idleLogout(); else reconnectNow(); } });
addEventListener("online", () => { if (S.token && (!S.ws || S.ws.readyState !== 1)) reconnectNow(); });
addEventListener("offline", () => { if (S.token) $("connbar").classList.remove("hidden"); });

async function prepare(m) {
  if (X.ready) await Promise.race([X.ready, delay(8000)]);
  if (m.type === "init") await hydrateAll(m.history);
  else if (m.type === "message") await hydrate(m);
  else if (m.type === "message_edited" && m.e2e) {
    const {list} = findMsg(m.id, m.to, m.from, m.ch), x = list.find(i => i.id === m.id);
    if (x) { m._h = Object.assign({}, x, {e2e: m.e2e}); await hydrate(m._h); }
  }
}
function eachMsg(fn) { S.group.msgs.forEach(fn); S.dms.forEach(d => { d.msgs.forEach(fn); d.buffer.forEach(fn); }); }
const snippetOf = t => (t || "").replace(/\s+/g, " ").slice(0, 100);
function partnerOf(m) { return m.user.id === S.me.id ? m.to : m.user.id; }
function findMsg(id, to, from, ch) {
  if (ch) return {list: chOf(ch).msgs, dm: null, ch};
  if (to == null) return {list: S.group.msgs, dm: null};
  const dm = dmOf(from === S.me.id ? to : from);
  return {list: dm.msgs, dm};
}
const atBottom = () => { const b = $("msgs"); return b.scrollHeight - b.scrollTop - b.clientHeight < 80; };
const isActiveGroup = () => S.active && S.active.kind === "group";
const isActiveDm = uid => S.active && S.active.kind === "dm" && S.active.uid === uid;

function onMessage(m) {
  switch (m.type) {
    case "init": {
      S.me = Object.assign({}, S.me, m.me); upsertUser(m.me);
      S.online = new Set(m.online_ids);
      m.history.forEach(x => upsertUser(x.user));
      mergeHistory(S.group, m.history, !!m.more);           // qayta ulanganda tepaga chiqib yuklangan eski xabarlar yo'qolmaydi
      S.chat = m.chat || {slowmode: 0, locked: false};
      loadMembers(); loadDialogs();
      if (S.active && S.active.kind === "dm") reloadActiveDm();
      if (S.active && S.active.kind === "channel") reloadActiveChannel();
      if (!S.active && !isMobile()) openChat({kind: "group"}); else { renderList(); renderHeader(); renderMessages(true); }
      if (S.pendingOpen) { if (S.pendingOpen.k !== "d") applyPendingOpen(); else if (X.ready) X.ready.then(applyPendingOpen); }
      break; }
    case "message": {
      upsertUser(m.user);
      if (m.ch) { onChannelPost(m); break; }
      const mine = m.user.id === S.me.id;
      if (!mine && document.hidden && Date.now() - (S.hiddenAt || 0) < 7000)     // yashirilganiga <7 s: server hali oflayn deb push yubormagan
        Push.local({k: m.to == null ? "g" : "d", u: m.user.id, i: m.id, n: m.user.nickname || m.user.username, t: Math.floor(Date.now() / 1000)});
      if (m.to == null) {
        const stick = atBottom();
        S.group.msgs.push(m);
        if (isActiveGroup()) {
          appendMessage(m, mine || stick);
          if (!mine && !stick) bumpAway();
        } else if (!mine) S.group.unread++;
      } else {
        const pid = partnerOf(m), dm = dmOf(pid);
        if (!S.users.has(pid)) loadMembers();
        dm.last = m;
        if (dm.loaded) dm.msgs.push(m); else dm.buffer.push(m);
        if (isActiveDm(pid)) {
          const stick = atBottom();
          appendMessage(m, mine || stick);
          if (!mine) {
            if (!document.hidden) { dm.unread = 0; wsSend({type: "read", with: pid}); }
            else dm.unread++;
            if (!stick) bumpAway();
          }
        } else if (!mine) dm.unread++;
      }
      renderList();
      break; }
    case "message_edited": {
      const {list, dm, ch} = findMsg(m.id, m.to, m.from, m.ch);
      const x = list.find(i => i.id === m.id);
      if (m._h) m.content = m._h.content;
      if (x) {
        if (m._h) Object.assign(x, {content: m._h.content, e2e: m.e2e, verified: m._h.verified, bad: m._h.bad, locked: m._h.locked, _r: m._h._r, reply: m._h.reply});
        else x.content = m.content;
        x.edited = true;
      }
      eachMsg(y => { if (y.reply && y.reply.id === m.id && !y.reply.deleted) y.reply.text = snippetOf(m.content); });
      if (dm && dm.last && dm.last.id === m.id) { dm.last.content = m.content; dm.last.edited = true; if (m._h) Object.assign(dm.last, {e2e: m.e2e, bad: m._h.bad, locked: m._h.locked}); }
      if (ch) { const st = chOf(ch); if (st.last && st.last.id === m.id && st.last !== x && m._h) Object.assign(st.last, {content: m._h.content, e2e: m.e2e, bad: m._h.bad, locked: m._h.locked}); }
      renderMessages(false); renderList();
      break; }
    case "message_reaction": {
      const {list, dm} = findMsg(m.id, m.to, m.from, m.ch);
      const x = list.find(i => i.id === m.id) || (dm && dm.buffer.find(i => i.id === m.id));
      if (x) { x.rx = m.rx || {}; patchReactions(x); }
      break; }
    case "message_deleted": {
      const {list, dm, ch} = findMsg(m.id, m.to, m.from, m.ch);
      const i = list.findIndex(x => x.id === m.id);
      if (i >= 0) list.splice(i, 1);
      eachMsg(y => { if (y.reply && y.reply.id === m.id) y.reply = {id: m.id, deleted: true}; });
      if (S.editing && S.editing.id === m.id) cancelEdit();
      if (S.replying && S.replying.id === m.id) cancelReply();
      if (VP.id === m.id) voiceStop();
      if (VN.id === m.id) vnStop();
      if (S.sel && S.sel.delete(m.id)) updateSelBar();
      if (ch) {
        const st = chOf(ch), info = chInfo(ch);
        st.buffer = st.buffer.filter(x => x.id !== m.id);
        if (st.last && st.last.id === m.id) st.last = st.msgs.length ? st.msgs[st.msgs.length - 1] : null;
        if (info && info.posts > 0) info.posts--;
        Channels.postGone(ch, m.id);
      }
      if (dm) {
        dm.buffer = dm.buffer.filter(x => x.id !== m.id);
        if (dm.last && dm.last.id === m.id) { dm.last = dm.msgs.length ? dm.msgs[dm.msgs.length - 1] : null; if (!dm.loaded || !dm.last) loadDialogs(); }
      }
      scheduleRender();
      break; }
    case "channels_changed": case "channel_post": case "channel_post_edited": case "channel_post_deleted":
    case "channel_views": case "channel_comment": case "channel_comment_deleted":
      Channels.onEvent(m); break;
    case "chat_settings":
      S.chat = {slowmode: m.slowmode || 0, locked: !!m.locked};
      renderHeader();
      if (isActiveGroup() && !amAdmin()) toast(S.chat.locked ? "Admin umumiy chatni qulfladi" : (S.chat.slowmode ? "Sekin rejim: " + S.chat.slowmode + " soniya" : "Umumiy chat ochildi"), "warn");
      break;
    case "media_removed": {                              // admin faylni o'chirdi (izoh matni qoladi)
      const x = S.group.msgs.find(i => i.id === m.id);
      if (x) { x.image = null; x.thumb = null; x.w = x.h = null; x.file = null; }
      S.imgs.delete(m.id); if (VP.id === m.id) voiceStop(); if (VN.id === m.id) vnStop();
      const u = S.played.get(m.id); if (u) { URL.revokeObjectURL(u); S.played.delete(m.id); }
      eachMsg(y => { if (y.reply && y.reply.id === m.id) { y.reply.image = false; y.reply.file = false; } });
      renderMessages(false); renderList();
      break; }
    case "e2ee_room": case "e2ee_wrap": loadRoom().catch(() => {}); break;
    case "e2ee_rotate_hint": if (amAdmin()) rotateRoom(m.reason); break;
    case "report_new": toast("Yangi shikoyat keldi (⋮ → Shikoyatlar)", "warn"); break;
    case "chat_cleared": {
      const gone = new Set(S.group.msgs.map(x => x.id));
      eachMsg(y => { if (y.reply && gone.has(y.reply.id)) y.reply = {id: y.reply.id, deleted: true}; });
      S.group.msgs = [];
      if (isActiveGroup()) { cancelEdit(); cancelReply(); exitSelect(); }
      renderMessages(false); renderList();
      toast(m.by === S.me.id ? "Chat tozalandi" : "Admin umumiy chatni tozaladi", "ok");
      break; }
    case "read": {
      const dm = S.dms.get(m.by);
      if (dm) {
        dm.msgs.forEach(x => { if (x.user.id === S.me.id) x.read = true; });
        if (dm.last && dm.last.user.id === S.me.id) dm.last.read = true;
        if (isActiveDm(m.by)) renderMessages(false);
      }
      break; }
    case "presence":
      if (m.online) S.online.add(m.uid); else S.online.delete(m.uid);
      if (!S.users.has(m.uid)) loadMembers();
      renderList(); renderHeader(); refreshModal();
      break;
    case "members_changed": loadMembers(); loadDialogs(); break;
    case "dm_cleared": {
      const other = m.a === S.me.id ? m.b : m.a;
      S.dms.delete(other);
      const wasActive = isActiveDm(other);
      if (wasActive) closeChat();
      renderList();
      toast(m.a === S.me.id ? "Suhbat o'chirildi" : "Suhbat o'chirildi (boshqa tomon o'chirdi)", "ok");
      break; }
    case "user_removed":
      upsertUser(m.user);
      S.members = S.members.filter(x => x.id !== m.user.id); S.online.delete(m.user.id);
      renderList(); renderHeader(); renderMessages(false); refreshModal();
      break;
    case "account_removed": showAuth("Akkauntingiz o'chirildi"); break;
    case "emoji_update": loadEmojis(); break;
    case "user_update":
      upsertUser(m.user);
      renderList(); renderHeader(); renderMessages(false); refreshModal();
      break;
    case "system":
      toast(m.lines.join("\n"), m.level);
      if (m.level === "warn") { S.group.msgs.push({service: true, text: m.lines.join(" "), ts: Date.now() / 1000}); if (isActiveGroup()) renderMessages(false); }
      break;
    case "banned": showAuth("Siz ban qilindingiz" + (m.reason ? ": " + m.reason : "")); break;
  }
}

function onChannelPost(m) {
  const mine = m.user.id === S.me.id, st = chOf(m.ch), info = chInfo(m.ch);
  if (!mine && document.hidden && Date.now() - (S.hiddenAt || 0) < 7000)
    Push.local({k: "c", u: m.ch, i: m.id, n: info ? info.nickname : "Kanal", t: Math.floor(Date.now() / 1000)});
  if (info) { info.posts++; info.last_post = m.id; info.last_ts = m.ts; S.chList.sort((a, b) => (b.last_ts || b.created || 0) - (a.last_ts || a.created || 0)); }
  else Channels.loadList();
  st.last = m;
  if (st.loaded) { if (!st.msgs.some(x => x.id === m.id)) st.msgs.push(m); }
  else if (!st.buffer.some(x => x.id === m.id)) st.buffer.push(m);
  if (isActiveChan(m.ch)) {
    const stick = atBottom();
    appendMessage(m, mine || stick);
    if (!mine && !stick) bumpAway();
    renderHeader();
  } else if (!mine) st.unread++;
  renderList();
}
async function loadChannelPosts(id) {
  const st = chOf(id);
  const j = await api("/channels/" + id + "/posts?limit=10");
  if (X.ready) await Promise.race([X.ready, delay(8000)]);
  await hydrateAll(j.posts);
  j.posts.forEach(x => upsertUser(x.user));
  const ids = new Set(j.posts.map(x => x.id));
  const fresh = j.posts.concat(st.buffer.filter(x => !ids.has(x.id))).sort((a, b) => a.id - b.id);
  mergeHistory(st, fresh, !!j.more);
  st.buffer = []; st.loaded = true;
  if (st.msgs.length) st.last = st.msgs[st.msgs.length - 1];
}
async function reloadActiveChannel() {
  const id = S.active.id;
  try { await loadChannelPosts(id); if (isActiveChan(id)) renderMessages(true); } catch (_) {}
}
/** js/channels.js ro'yxatni yuklaganda chaqiradi: oxirgi postlar ham ochiladi (ro'yxatda ko'rinishi uchun). */
async function setChannelList(list) {
  S.chList = list;
  renderList(); renderHeader();
  if (X.ready) await Promise.race([X.ready, delay(8000)]);
  for (const c of list) {
    if (!c.last) continue;
    const st = chOf(c.id);
    if (st.last && st.last.id >= c.last.id) continue;
    upsertUser(c.last.user); await hydrate(c.last); st.last = c.last;
  }
  renderList();
}
function chanAvatar(c, size) {
  const el = h("div", {class: "av av-" + size + " chn"});
  el.style.setProperty("--avc", colorOf((c.id || 0) + 3));
  if (c.avatar) el.append(h("img", {src: c.avatar, alt: "", draggable: "false"}));
  else el.append(h("span", {text: (Array.from((c.nickname || "?").trim())[0] || "?").toUpperCase()}));
  return el;
}
/** Server hodisasi (ko'rishlar/izohlar soni) post kartasiga: xotira va ekran yangilanadi. */
function patchPost(ch, pid, fields) {
  const m = chOf(ch).msgs.find(x => x.id === pid);
  if (m) Object.assign(m, fields);
  if (!isActiveChan(ch)) return;
  const row = document.querySelector('#msgs .row[data-id="' + Number(pid) + '"]'); if (!row) return;
  const v = row.querySelector(".vws b"); if (v && fields.views != null) v.textContent = String(fields.views);
  const c = row.querySelector(".cmb-t"); if (c && fields.comments != null) c.textContent = fields.comments ? fields.comments + " ta izoh" : "Izoh qoldirish";
}

async function loadMembers() {
  try {
    const j = await api("/members");
    S.members = j.members; S.online = new Set(j.online_ids);
    j.members.forEach(upsertUser);
    renderList(); renderHeader(); refreshModal();
    serveWraps();
  } catch (_) {}
}
async function loadDialogs() {
  try {
    const j = await api("/dialogs");
    if (X.ready) await X.ready;
    await hydrateAll(j.dialogs.map(d => d.last).filter(Boolean));
    const seen = new Set();
    j.dialogs.forEach(d => {
      upsertUser(d.user); seen.add(d.user.id);
      const dm = dmOf(d.user.id); dm.last = d.last; dm.unread = isActiveDm(d.user.id) ? 0 : d.unread;
    });
    S.dms.forEach((dm, uid) => {                       // serverda yo'q suhbat (masalan, boshqa tomon o'chirgan)
      if (seen.has(uid)) return;
      if (isActiveDm(uid)) { dm.msgs = []; dm.buffer = []; dm.last = null; renderMessages(false); }
      else S.dms.delete(uid);
    });
    renderList();
  } catch (_) {}
}
async function loadDm(uid) {
  const dm = dmOf(uid);
  const j = await api("/dm/" + uid);
  if (X.ready) await Promise.race([X.ready, delay(8000)]);
  await hydrateAll(j.history);
  const ids = new Set(j.history.map(x => x.id));
  const fresh = j.history.concat(dm.buffer.filter(x => !ids.has(x.id))).sort((a, b) => a.id - b.id);
  mergeHistory(dm, fresh, !!j.more);
  dm.buffer = []; dm.loaded = true;
  if (dm.msgs.length) dm.last = dm.msgs[dm.msgs.length - 1];
}
/* Tarix: dastlab faqat oxirgi 10 ta xabar. Tepaga chiqilganda oldingilari sahifalab yuklanadi (loadOlder). */
function mergeHistory(st, fresh, more) {
  const old = st.msgs.filter(x => !x.service && x.id);
  if (!old.length || !fresh.length || old[old.length - 1].id < fresh[0].id) { st.msgs = fresh.slice(); st.more = more; return; }
  const keep = old.filter(x => x.id < fresh[0].id);            // yangi oynadan oldingi (tepaga chiqib yuklangan) xabarlar saqlanadi
  st.msgs = keep.concat(fresh);
  if (!keep.length) st.more = more;
}
async function loadOlder() {
  if (!S.active || S.olderBusy) return;
  const kind = S.active.kind, isG = kind === "group", isC = kind === "channel", uid = S.active.uid, cid = S.active.id;
  const st = isG ? S.group : isC ? chOf(cid) : dmOf(uid);
  if (st.msgs.length > (S.win || WIN0)) {                     // xotirada bor, lekin chizilmagan eski xabarlar: tarmoqsiz, darrov
    const bx = $("msgs"), ph = bx.scrollHeight, pt = bx.scrollTop;
    S.win = (S.win || WIN0) + 40; renderMessages(false); bx.scrollTop = pt + (bx.scrollHeight - ph); return;
  }
  if (!st.more) return;
  const first = st.msgs.find(x => !x.service && x.id); if (!first) return;
  S.olderBusy = true;
  const box = $("msgs"), btn = box.querySelector(".older"); if (btn) btn.textContent = "Yuklanmoqda…";
  try {
    const j = await api(isG ? "/group/history?before=" + first.id : isC ? "/channels/" + cid + "/posts?limit=20&before=" + first.id : "/dm/" + uid + "?before=" + first.id);
    const older = isC ? j.posts : j.history;
    if (X.ready) await Promise.race([X.ready, delay(8000)]);
    await hydrateAll(older);
    older.forEach(x => upsertUser(x.user));
    const have = new Set(st.msgs.map(x => x.id));
    st.msgs = older.filter(x => !have.has(x.id)).concat(st.msgs);
    S.win = (S.win || WIN0) + older.length;
    st.more = !!j.more;
    if (S.active && S.active.kind === kind && (isG || (isC ? S.active.id === cid : S.active.uid === uid))) {
      const prevH = box.scrollHeight, prevT = box.scrollTop;
      renderMessages(false);
      box.scrollTop = prevT + (box.scrollHeight - prevH);       // ko'rib turgan joyingiz joyida qoladi
    }
  } catch (err) { toast(err.message, "error"); if (btn) btn.textContent = "⬆ Oldingi xabarlar"; }
  S.olderBusy = false;
}
async function reloadActiveDm() {
  const uid = S.active.uid;
  try { await loadDm(uid); if (isActiveDm(uid)) { renderMessages(true); wsSend({type: "read", with: uid}); } } catch (_) {}
}

/* ---------------- chap panel: ro'yxat ---------------- */
function itemEl({av, title, sub, subOn, time, unread, active, onclick, onctx}) {
  const el = h("div", {class: "item" + (active ? " active" : ""), onclick, oncontextmenu: onctx ? e => { e.preventDefault(); e.stopPropagation(); onctx(e.clientX, e.clientY); } : null},
    av,
    h("div", {class: "i-mid"},
      h("div", {class: "i-top"}, h("div", {class: "i-title"}, title), time ? h("span", {class: "i-time", text: time}) : null),
      h("div", {class: "i-bot"}, h("div", {class: "i-sub" + (subOn ? " on" : "")}, sub),
        unread ? h("span", {class: "pill", text: unread > 99 ? "99+" : String(unread)}) : null)));
  if (onctx) longPress(el, (x, y) => onctx(x, y, true));
  return el;
}
function previewOf(m, withAuthor, plain) {
  if (!m) return "";
  const mine = !plain && m.user.id === S.me.id;
  let body = m.locked ? "🔒 Shifrlangan xabar" : m.bad ? "⚠ Shifrni ochib bo'lmadi" : m.content;
  if (!m.locked && !m.bad && m.content) {                                // kod / buyruq xabarlari ro'yxatda qisqa belgi bilan ko'rinadi
    const rp = Rich.parse(m.content), rc = rp.find(x => x.k !== "text");
    if (rc) body = (rc.k === "term" ? "⌨ Linux buyruq: " + Rich.copyTextOf(rc).split("\n")[0] : "‹/› " + (rc.label || "Kod") + ": " + rc.code.split("\n")[0]);
  }
  const text = (m.image ? "📷 " : m.file ? fileIco(m.file) : "") + (body ? body.replace(/\s+/g, " ") : (m.image ? "Rasm" : m.file ? fileWhat(m.file) : ""));
  if (mine) return [h("b", {text: "Siz: "}), text];
  return withAuthor ? [h("b", {text: m.user.nickname + ": "}), text] : text;
}
function groupItem() {
  const last = [...S.group.msgs].reverse().find(x => !x.service);
  return itemEl({
    av: groupAvatar("m"), title: h("span", {class: "nt", text: "Umumiy chat"}),
    sub: last ? previewOf(last, true) : "Hozircha xabar yo'q", time: last ? listTime(last.ts) : "",
    unread: S.group.unread, active: isActiveGroup(), onclick: () => openChat({kind: "group"}),
  });
}
function dmItem(u, dm) {
  return itemEl({
    av: avatar(u, "m", true), title: nameEl(u), sub: previewOf(dm.last, false), time: listTime(dm.last.ts),
    unread: dm.unread, active: isActiveDm(u.id), onclick: () => openChat({kind: "dm", uid: u.id}),
    onctx: (x, y, touch) => dmMenu(x, y, u.id, touch),
  });
}
function chanItem(c) {
  const st = chOf(c.id), last = st.last;
  return itemEl({
    av: chanAvatar(c, "m"), title: [h("span", {class: "nt", text: c.nickname}), c.private ? icon("lock", "ic ch-lock") : null],
    sub: last ? previewOf(last, false, true) : c.posts ? c.posts + " post" : "Hozircha post yo'q",
    time: last ? listTime(last.ts) : "", unread: st.unread, active: isActiveChan(c.id), onclick: () => openChat({kind: "channel", id: c.id}),
  });
}
function memberItem(u) {
  const sub = (isStaff(u) ? roleLabel(u.role) + " • " : "") + statusText(u);
  return itemEl({
    av: avatar(u, "m", true), title: nameEl(u), sub, subOn: isOnline(u.id),
    active: isActiveDm(u.id), onclick: () => openChat({kind: "dm", uid: u.id}),
  });
}
function renderList() {
  if (!S.me) return;
  $("moreBtn").classList.toggle("hidden", !amAdmin());
  const list = $("list"), top = list.scrollTop;
  list.textContent = "";
  const q = S.query.trim().toLowerCase();
  const match = u => !q || u.nickname.toLowerCase().includes(q) || u.username.toLowerCase().includes(q);
  if (S.tab === "chats") {
    if (!q || "umumiy chat".includes(q)) list.append(groupItem());
    const dms = [...S.dms.entries()].filter(([, d]) => d.last).sort((a, b) => b[1].last.ts - a[1].last.ts);
    dms.forEach(([id, d]) => { const u = U(id); if (match(u)) list.append(dmItem(u, d)); });
    if (q) {
      const shown = new Set(dms.map(([id]) => id));
      const others = S.members.filter(m => m.id !== S.me.id && !shown.has(m.id) && match(m));
      if (others.length) { list.append(h("div", {class: "sect", text: "A'zolar"})); others.forEach(m => list.append(memberItem(U(m.id)))); }
    }
    if (!list.children.length) list.append(h("div", {class: "none", text: "Hech narsa topilmadi"}));
  } else if (S.tab === "channels") {
    list.append(h("div", {class: "chn-bar"},
      amAdmin() ? h("button", {class: "btn ghost sm", type: "button", onclick: () => Channels.create()}, icon("plus"), " Kanal yaratish") : null,
      h("button", {class: "btn ghost sm", type: "button", onclick: () => Channels.join()}, icon("lock"), " Shaxsiy kanalga qo'shilish")));
    const cs = S.chList.filter(c => !q || c.nickname.toLowerCase().includes(q) || c.username.toLowerCase().includes(q));
    cs.forEach(c => list.append(chanItem(c)));
    if (!cs.length) list.append(h("div", {class: "none", text: S.chList.length ? "Hech narsa topilmadi" : "Hozircha kanallar yo'q"}));
  } else {
    const all = S.members.filter(m => m.id !== S.me.id && match(m)).map(m => U(m.id));
    const on = all.filter(u => isOnline(u.id)), off = all.filter(u => !isOnline(u.id));
    if (on.length) { list.append(h("div", {class: "sect", text: "Onlayn — " + on.length})); on.forEach(u => list.append(memberItem(u))); }
    if (off.length) { list.append(h("div", {class: "sect", text: "Oflayn"})); off.forEach(u => list.append(memberItem(u))); }
    if (!all.length) list.append(h("div", {class: "none", text: S.members.length > 1 ? "Hech narsa topilmadi" : "Hozircha boshqa a'zolar yo'q"}));
  }
  list.scrollTop = top;
  updateBadges();
}
function updateBadges() {
  let total = S.group.unread, ctot = 0;
  S.dms.forEach(d => { total += d.unread; });
  S.chn.forEach(c => { ctot += c.unread; });
  const b = $("chatsBadge");
  b.classList.toggle("hidden", !total); b.textContent = total > 99 ? "99+" : String(total);
  const cb = $("chnBadge");
  cb.classList.toggle("hidden", !ctot); cb.textContent = ctot > 99 ? "99+" : String(ctot);
  document.title = (total + ctot ? "(" + (total + ctot) + ") " : "") + APP_NAME;
}
document.querySelectorAll(".tabs button[data-tab]").forEach(btn => btn.addEventListener("click", () => {
  S.tab = btn.dataset.tab;
  document.querySelectorAll(".tabs button").forEach(x => x.classList.toggle("on", x === btn));
  renderList();
  if (S.tab === "channels") Channels.loadList();
}));
$("search").addEventListener("input", e => { S.query = e.target.value; renderList(); });

/* ---------------- menyu ---------------- */
function renderMenu() {
  const menu = $("menu"); menu.textContent = "";
  const dark = document.documentElement.dataset.theme === "dark";
  const add = (ic, text, fn) => menu.append(h("button", {class: "dd-i", type: "button", onclick: () => { menu.classList.add("hidden"); fn(); }}, icon(ic), text));
  add("user", "Mening profilim", () => openProfile(S.me.id));
  add("edit", "Profilni tahrirlash", openSettings);
  add("lock", "Shifrlash: server nimani ko'radi?", () => openInspector("server"));
  add("emoji", "Reaksiya sozlamalari", openReactionSettings);
  add("bell", notifLabel(), toggleNotifications);
  add("lock", stayOn() ? "Har kirishda login so'rash: o'chirilgan" : "Har kirishda login so'rash: yoqilgan", toggleStay);
  add(dark ? "sun" : "moon", dark ? "Kunduzgi mavzu" : "Tungi mavzu", toggleTheme);
  menu.append(h("div", {class: "dd-sep"}));
  add("logout", "Chiqish", logout);
}
$("menuBtn").addEventListener("click", e => { e.stopPropagation(); $("amenu").classList.add("hidden"); renderMenu(); $("menu").classList.toggle("hidden"); });

/* ---------------- admin: 3 nuqta menyusi ---------------- */
function renderAdminMenu() {
  const menu = $("amenu"); menu.textContent = "";
  const add = (ic, text, fn) => menu.append(h("button", {class: "dd-i", type: "button", onclick: () => { menu.classList.add("hidden"); fn(); }}, icon(ic), text));
  add("shield", "IP lar va profillar", () => openAdmin("ips"));
  add("user", "Foydalanuvchilar, nishon va zaxira", () => openAdmin("users"));
  add("list", "Harakatlar logi", () => openAdmin("log"));
  add("ban", "Bloklangan IP lar", () => openAdmin("blocks"));
  add("attach", "Media boshqaruvi", () => openAdmin("media"));
  add("flag", "Shikoyatlar", () => openAdmin("reports"));
  add("shield", "Moderatsiya sozlamalari", () => openAdmin("mod"));
  menu.append(h("div", {class: "dd-sep"}));
  const clr = h("button", {class: "dd-i", type: "button", onclick: () => { menu.classList.add("hidden"); clearGroupChat(); }}, icon("trash"), "Umumiy chatni tozalash");
  clr.style.color = "var(--err)"; menu.append(clr);
}
$("moreBtn").addEventListener("click", e => {
  e.stopPropagation(); $("menu").classList.add("hidden");
  renderAdminMenu(); $("amenu").classList.toggle("hidden");
});

/* ---------------- chat oynasi ---------------- */
function currentMsgs() {
  if (!S.active) return [];
  if (S.active.kind === "channel") return chOf(S.active.id).msgs;
  return S.active.kind === "group" ? S.group.msgs : dmOf(S.active.uid).msgs;
}
async function openChat(target) {
  if (S.sel) { S.sel = null; $("chat").classList.remove("selecting"); navPop("sel"); }
  Channels.closeComments(false);
  S.active = target; S.win = WIN0;
  cancelRecording(); cancelEdit(); cancelReply(); clearPendingImage(); $("inp").value = ""; autosize(); S.away = 0; bumpAway(true);
  $("empty").classList.add("hidden"); $("chat").classList.remove("hidden");
  document.body.classList.add("in-chat");
  if (isMobile()) navPush("chat");
  if (target.kind === "group") S.group.unread = 0;
  else if (target.kind === "channel") {
    const st = chOf(target.id); st.unread = 0;
    if (!st.loaded) {
      renderHeader(); $("msgs").textContent = "";
      try { await loadChannelPosts(target.id); } catch (err) { toast(err.message, "error"); }
      if (!isActiveChan(target.id)) return;
    }
  } else {
    const dm = dmOf(target.uid); dm.unread = 0;
    if (!dm.loaded) {
      renderHeader(); $("msgs").textContent = "";
      try { await loadDm(target.uid); } catch (err) { toast(err.message, "error"); }
      if (!isActiveDm(target.uid)) return;
    }
    wsSend({type: "read", with: target.uid});
  }
  renderHeader(); renderMessages(true); renderList();
  if (!isMobile()) $("inp").focus();
}
function closeChat() {
  Channels.closeComments(false);
  if (S.sel) { S.sel = null; $("chat").classList.remove("selecting"); navPop("sel"); }
  S.active = null; cancelEdit(); cancelReply(); clearPendingImage();
  document.body.classList.remove("in-chat"); navPop("chat");
  if (!isMobile()) { $("chat").classList.add("hidden"); $("empty").classList.remove("hidden"); }
  renderList();
}
function renderHeader() {
  if (!S.active || !S.me) return;
  const av = $("hav"), title = $("htitle"), sub = $("hsub");
  av.textContent = ""; title.textContent = ""; sub.className = "hsub";
  if (S.active.kind === "group") {
    av.append(groupAvatar("m")); title.append(h("span", {class: "nt", text: "Umumiy chat"}));
    sub.textContent = (S.members.length || 1) + " a'zo, " + onlineCount() + " onlayn" + (S.chat.locked ? " • 🔒 qulflangan" : S.chat.slowmode ? " • 🐢 " + S.chat.slowmode + " s" : "") + (X.epoch && !X.rooms.has(X.epoch) ? " • ⏳ kalit kutilmoqda" : "");
  } else if (S.active.kind === "channel") {
    const c = chInfo(S.active.id);
    av.append(chanAvatar(c || {id: S.active.id, nickname: "?"}, "m"));
    title.append(h("span", {class: "nt", text: c ? c.nickname : "Kanal"}), c && c.private ? icon("lock", "ic ch-lock") : null);
    sub.textContent = c ? "@" + c.username + " • " + c.posts + " post" + (c.private ? " • shaxsiy" : "") + (c.can_manage && c.private ? " • " + (c.members || 0) + " a'zo" : "") : "";
  } else {
    const u = U(S.active.uid);
    av.append(avatar(u, "m", true)); title.append(nameEl(u));
    sub.textContent = statusText(u) + (X.changed.has(u.id) ? " • ⚠ kalit o'zgargan" : ""); if (isOnline(u.id)) sub.classList.add("on");
  }
  $("chMore").classList.toggle("hidden", S.active.kind === "group");
  const chanRO = S.active.kind === "channel" && !amAdmin();           // oddiy a'zo kanalga yozolmaydi (faqat o'qiydi va izoh qoldiradi)
  $("chat").classList.toggle("readonly", chanRO);
  inp.placeholder = S.active.kind === "channel" ? "Kanalga post yozing…" : "Xabar yozing…";
  if (chanRO) { cancelEdit(); cancelReply(); clearPendingImage(); }
  const dead = S.active.kind === "dm" && !!U(S.active.uid).deleted;
  $("chat").classList.toggle("dead", dead);
  const locked = S.active.kind === "group" && S.chat.locked && !amAdmin();
  $("chat").classList.toggle("locked", locked);
  if (locked) { cancelEdit(); cancelReply(); clearPendingImage(); }
  if (dead) { cancelEdit(); cancelReply(); clearPendingImage(); }
}
$("hinfo").addEventListener("click", () => {
  if (!S.active) return;
  if (S.active.kind === "group") openGroupInfo(); else if (S.active.kind === "channel") Channels.info(S.active.id); else openProfile(S.active.uid);
});
$("backBtn").addEventListener("click", closeChat);

function bumpAway(reset) {
  if (reset) S.away = 0; else S.away++;
  const tb = $("tbBadge");
  tb.textContent = String(S.away); tb.classList.toggle("hidden", !S.away);
}
const WIN0 = 80;                                    // ekranda bir vaqtda ko'pi bilan shuncha xabar (eskilari tepaga chiqilganda qo'shiladi)
function msgFlags(list, k) {                        // xabar guruhining boshi/oxiri (avatar va masofa uchun)
  const c = list[k], p = list[k - 1], n = list[k + 1], d = dayKey(c.ts);
  return [!p || p.service || p.user.id !== c.user.id || dayKey(p.ts) !== d || c.ts - p.ts > 300,
          !n || n.service || n.user.id !== c.user.id || dayKey(n.ts) !== d || n.ts - c.ts > 300];
}
function renderMessages(stick) {
  if (!S.active || !S.me) return;
  const box = $("msgs"), prevTop = box.scrollTop;
  const all = currentMsgs(), isGroup = S.active.kind === "group", chan = S.active.kind === "channel";
  const hiddenN = Math.max(0, all.length - (S.win || WIN0)), list = hiddenN ? all.slice(hiddenN) : all;
  box.textContent = "";
  let prev = null, lastDay = "";
  const pg = isGroup ? S.group : chan ? chOf(S.active.id) : dmOf(S.active.uid);
  if (pg.more || hiddenN) box.append(h("button", {class: "older", type: "button", text: "⬆ Oldingi xabarlar", onclick: loadOlder}));
  if (!list.length) box.append(h("div", {class: "blank", text: chan ? "Kanalda hali post yo'q" : isGroup ? "Hozircha xabar yo'q. Birinchi bo'lib yozing 👋" : "Suhbatni boshlang — xabar yozing 👋"}));
  list.forEach((m, i) => {
    if (m.service) { box.append(h("div", {class: "svc", text: m.text})); prev = null; return; }
    const day = dayKey(m.ts);
    if (day !== lastDay) { box.append(h("div", {class: "day", text: dayLabel(m.ts)})); lastDay = day; prev = null; }
    const next = list[i + 1];
    const first = !prev || prev.user.id !== m.user.id || m.ts - prev.ts > 300;
    const last = !next || next.service || next.user.id !== m.user.id || dayKey(next.ts) !== day || next.ts - m.ts > 300;
    box.append(bubbleRow(m, isGroup, chan || first, chan || last, chan));
    prev = m;
  });
  box._stick = !!stick; box._n = list.length;
  if (chan) Channels.track(box, S.active.id);
  if (stick) { box.scrollTop = box.scrollHeight; bumpAway(true); } else box.scrollTop = prevTop;
  toggleToBottom();
  if ((pg.more || hiddenN) && !S.olderBusy && box.scrollHeight <= box.clientHeight + 60) setTimeout(loadOlder, 0);   // ekran to'lmasa tepaga chiqib bo'lmaydi: o'zi yuklaydi
}
function appendMessage(m, stick) {                 // tez yo'l: bitta qator qo'shiladi (rasmlar qayta yuklanmaydi, qotmaydi)
  const box = $("msgs"), list = currentMsgs(), i = list.length - 1;
  if (!S.active || !S.me || S.sel || list[i] !== m || box.querySelector(".blank")) return renderMessages(stick);
  if (stick && (box._n || 0) >= 220) { S.win = WIN0; return renderMessages(true); }      // DOM juda o'sib ketmasin
  const isG = S.active.kind === "group", chan = S.active.kind === "channel", prevM = list[i - 1];
  let prevRow = null;
  if (prevM && !prevM.service) {
    prevRow = box.querySelector('.row[data-id="' + Number(prevM.id) + '"]');
    if (!prevRow || prevRow !== box.lastElementChild) return renderMessages(stick);
  } else if (prevM && prevM.service && !(box.lastElementChild && box.lastElementChild.classList.contains("svc"))) return renderMessages(stick);
  else if (!prevM && box.lastElementChild && !box.lastElementChild.classList.contains("older")) return renderMessages(stick);
  if (m.service) box.append(h("div", {class: "svc", text: m.text}));
  else {
    let j = i - 1; while (j >= 0 && list[j].service) j--;
    if (j < 0 || dayKey(list[j].ts) !== dayKey(m.ts)) box.append(h("div", {class: "day", text: dayLabel(m.ts)}));
    if (prevRow && !chan) {                                          // oldingi qator endi «oxirgi» emas bo'lishi mumkin (avatar ko'chadi)
      const [pf, pl] = msgFlags(list, i - 1);
      if (pl !== prevRow.classList.contains("last")) prevRow.replaceWith(bubbleRow(prevM, isG, pf, pl));
    }
    const [f, l] = chan ? [true, true] : msgFlags(list, i), row = bubbleRow(m, isG, f, l, chan);
    row.classList.add("enter"); box.append(row);
    setTimeout(() => row.classList.remove("enter"), 450);
  }
  box._n = (box._n || 0) + 1; box._stick = !!stick;
  if (chan) Channels.track(box, S.active.id);
  if (stick) { box.scrollTop = box.scrollHeight; bumpAway(true); }
  toggleToBottom();
}
function replyQuote(r) {
  const gone = !!r.deleted;
  const q = h("div", {class: "rq" + (gone ? " gone" : ""), role: "button"},
    h("b", {text: gone ? "Xabar" : r.nickname}),
    h("span", {text: gone ? "O'chirilgan xabar" : (r.image ? "📷 " : r.file ? (r.voice ? "🎤 " : r.vnote ? "📹 " : "📎 ") : "") + (r.text || (r.image ? "Rasm" : r.file ? (r.file_name || "Fayl") : ""))}));
  q.addEventListener("click", e => { e.stopPropagation(); if (!gone) jumpTo(r.id); });
  return q;
}
function jumpTo(id) {
  const box = $("msgs"), row = box.querySelector('.row[data-id="' + Number(id) + '"]');
  if (!row) { toast("Bu xabar yuklangan tarixda yo'q (eski)", "warn"); return; }
  box._stick = false;
  row.scrollIntoView({block: "center", behavior: "smooth"});
  row.classList.remove("flash"); void row.offsetWidth; row.classList.add("flash");
  setTimeout(() => row.classList.remove("flash"), 1400);
}

/* ---------------- Rasm: avval xira, bosilganda yuklanadi va tiniq ochiladi ---------------- */
function imageBox(m, mine) {
  const ratio = Math.min(2.4, Math.max(0.8, m.w && m.h ? m.w / m.h : 4 / 3));
  // O'zim yuborgan rasm darrov ochiq; boshqalarniki bosilguncha yuklanmaydi.
  if (mine && !S.imgs.has(m.id)) S.imgs.set(m.id, "open");
  const st = S.imgs.get(m.id);
  const box = h("div", {class: "imgbox" + (st === "open" ? " open" : st === "loading" ? " loading" : ""), role: "button", tabindex: "0",
    "aria-label": st === "open" ? "Rasmni kattalashtirish" : "Rasmni yuklash"});
  box.style.aspectRatio = String(ratio);
  if (st !== "open") {
    const th = h("img", {class: "mthumb", alt: "", draggable: "false"});
    th.addEventListener("error", () => { th.remove(); box.classList.add("nothumb"); });
    if (m.thumb) th.src = m.thumb; else box.classList.add("nothumb");
    const dl = h("span", {class: "mdl", "aria-hidden": "true"}, icon("dl"), spinnerEl());
    box.append(th, dl);
  } else {
    box.append(fullImg(m));
  }
  const act = e => {
    e.stopPropagation();
    const cur = S.imgs.get(m.id);
    if (cur === "open") { imgSrcOf(m).then(openLightbox).catch(() => toast("Rasmni ochib bo'lmadi", "error")); return; }
    if (cur === "loading") return;
    startImageLoad(m, box);
  };
  box.addEventListener("click", act);
  box.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); act(e); } });
  return box;
}
/* ---------------- Fayl xabari: yuklab olish, video/audio ijro etish ---------------- */
const fmtSize = n => n < 1024 ? n + " B" : n < 1048576 ? Math.round(n / 1024) + " KB" : (n / 1048576).toFixed(1) + " MB";
const fileExt = name => { const i = (name || "").lastIndexOf("."); return i > 0 && i < name.length - 1 ? name.slice(i + 1, i + 5).toUpperCase() : "FAYL"; };
const PLAYABLE = /^(video\/(mp4|webm|ogg|quicktime)|audio\/(mpeg|mp3|ogg|wav|x-wav|webm|mp4|aac|flac|x-m4a))$/;
async function fetchFileBlob(m, type) {
  if (m.file.e2e) return new Blob([await e2eFetchBlob(m)], {type});          // shifrlangan fayl: qurilmada ochiladi
  const r = await SC.fetch(m.file.url, {headers: {Authorization: "Bearer " + S.token}});     // shifrlangan kanal orqali, tizim tokeni bilan
  if (!r.ok) throw new Error("fayl");
  return new Blob([r.bytes], {type});
}
async function downloadFile(m, box) {
  if (box.classList.contains("loading")) return;
  box.classList.add("loading");
  try {
    const blob = await fetchFileBlob(m, "application/octet-stream");                           // hech qachon sahifa sifatida ochilmaydi
    const url = URL.createObjectURL(blob), a = h("a", {href: url, download: m.file.name});
    document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  } catch (_) { toast("Faylni yuklab bo'lmadi", "error"); }
  box.classList.remove("loading");
}
async function playFile(m, box) {
  if (box.classList.contains("loading")) return;
  box.classList.add("loading");
  try {
    const blob = await fetchFileBlob(m, m.file.mime);
    S.played.set(m.id, URL.createObjectURL(blob));
    renderMessages(false);
  } catch (_) { toast("Faylni yuklab bo'lmadi", "error"); box.classList.remove("loading"); }
}
const fxNow = (key, ts) => {                                // terminal animatsiyasi: faqat yangi xabarda va faqat birinchi chizilganda
  const seen = S.fx.get(key);
  if (seen) return Date.now() - seen < 4000;
  S.fx.set(key, Date.now());
  return !ts || Date.now() / 1000 - ts < 90;
};
async function copyQuiet(t) {                                // kod/terminal blokidagi kichik «Nusxalash» tugmasi uchun (tugmaning o'zi holatni ko'rsatadi)
  try { await navigator.clipboard.writeText(t); return true; }
  catch (_) {
    const ta = h("textarea", {class: "offscreen"}); ta.value = t; document.body.append(ta); ta.select();
    let ok = false; try { ok = document.execCommand("copy"); } catch (_e) {}
    ta.remove(); return ok;
  }
}
async function togglePreview(m, box) {                      // .py/.cpp/.sh/... matn sifatida, .pcap tahlil sifatida ko'rsatiladi (hech narsa bajarilmaydi)
  if (S.previews.has(m.id)) { S.previews.delete(m.id); renderMessages(false); return; }
  if (box.classList.contains("loading")) return;
  const fk = Rich.fileKind(m.file.name); if (!fk) return;
  const limit = fk.kind === "pcap" ? MAX_MEDIA : 400 * 1024;
  if (m.file.size > limit) { toast("Fayl juda katta: ko'rish uchun yuklab oling (" + fmtSize(limit) + " gacha ko'rsatiladi)", "error"); return; }
  box.classList.add("loading");
  try {
    const blob = await fetchFileBlob(m, "application/octet-stream");
    const bytes = new Uint8Array(await blob.arrayBuffer());
    if (fk.kind === "pcap") S.previews.set(m.id, {kind: "pcap", info: Rich.parsePcap(bytes)});
    else {
      if (!Rich.isTextual(bytes)) { toast("Bu fayl matn emas: faqat yuklab olish mumkin", "error"); box.classList.remove("loading"); return; }
      let text = new TextDecoder("utf-8").decode(bytes).replace(/\r\n?/g, "\n"), cut = false;
      if (text.length > 120000) { text = text.slice(0, 120000); cut = true; }
      S.previews.set(m.id, {kind: "code", lang: fk.lang, label: fk.label, text, cut});
    }
    renderMessages(false);
  } catch (err) { toast(err && /pcap|qisqa/i.test(err.message || "") ? err.message : "Faylni ochib bo'lmadi", "error"); }
  box.classList.remove("loading");
}
function previewEl(m, pv) {
  const u = U(m.user.id);
  if (pv.kind === "pcap") {
    const info = pv.info;
    return Rich.terminal(Rich.pcapLines(info, m.file.name), {user: u.username, host: "kali", kali: true, tag: "PCAP", fx: fxNow("pv" + m.id), copy: copyQuiet,
      copyText: Rich.pcapText(info, m.file.name), info: info.count + " paket • " + info.linkName + " • faqat o'qiladi"});
  }
  const box = Rich.codeBlock(pv.text, pv.lang, {label: pv.label + " • " + m.file.name, copy: copyQuiet});
  if (pv.cut) box.append(h("div", {class: "cfoot-i cut", text: "Fayl katta: faqat boshi ko'rsatildi. To'liq nusxa uchun yuklab oling."}));
  return box;
}
function fileBox(m) {
  if (m.file.voice) return voiceBox(m);
  if (m.file.vnote) return vnoteBox(m);
  const f = m.file, playable = PLAYABLE.test(f.mime), fk = playable ? null : Rich.fileKind(f.name);
  if (playable && S.played.has(m.id)) {
    const el = h(f.mime.startsWith("video/") ? "video" : "audio", {controls: true, preload: "metadata", playsinline: true});
    el.src = S.played.get(m.id);
    return h("div", {class: "mplayer"}, el, h("div", {class: "mpn", text: f.name + " • " + fmtSize(f.size)}));
  }
  const box = h("div", {class: "filebox" + (fk ? " kind-" + fk.kind : ""), role: "button", tabindex: "0", "aria-label": "Faylni yuklab olish: " + f.name});
  if (fk) box.style.setProperty("--lc", fk.color);
  const act = h("span", {class: "fdl", "aria-hidden": "true"}, icon("dl"), spinnerEl());
  box.append(h("span", {class: "fico"}, h("b", {text: fk ? fk.ext.toUpperCase().slice(0, 6) : fileExt(f.name)})),
    h("span", {class: "fmeta"}, h("b", {class: "fname", text: f.name}),
      h("small", {text: fk ? (fk.kind === "pcap" ? "Linux • tcpdump/Wireshark • " : fk.label + " • faqat ko'rish • ") + fmtSize(f.size) : fmtSize(f.size)})));
  if (playable) {
    const pl = h("button", {class: "fplay", type: "button", title: "Ijro etish", "aria-label": "Ijro etish"}, icon("play"));
    pl.addEventListener("click", e => { e.stopPropagation(); playFile(m, box); });
    box.append(pl);
  }
  if (fk) {
    const open = S.previews.has(m.id), t = open ? "Yopish" : fk.kind === "pcap" ? "Tahlil qilish" : "Kodni ko'rish";
    const vw = h("button", {class: "fplay fview" + (open ? " on" : ""), type: "button", title: t, "aria-label": t}, icon(open ? "close" : "eye"));
    vw.addEventListener("click", e => { e.stopPropagation(); togglePreview(m, box); });
    for (const ev of ["pointerdown", "touchstart"]) vw.addEventListener(ev, e => e.stopPropagation(), {passive: true});
    box.append(vw);
  }
  box.append(act);
  const go = e => { e.stopPropagation(); downloadFile(m, box); };
  box.addEventListener("click", go);
  box.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); go(e); } });
  if (!fk) return box;
  const wrap = h("div", {class: "cfile kind-" + fk.kind}, box);
  const pv = S.previews.get(m.id);
  if (pv) wrap.append(previewEl(m, pv));
  return wrap;
}
function spinnerEl() {
  const NSV = "http://www.w3.org/2000/svg";
  const s = document.createElementNS(NSV, "svg"); s.setAttribute("class", "mspin"); s.setAttribute("viewBox", "0 0 50 50");
  const c = document.createElementNS(NSV, "circle");
  [["cx", 25], ["cy", 25], ["r", 22], ["fill", "none"], ["stroke-width", 3], ["stroke-linecap", "round"]].forEach(([k, v]) => c.setAttribute(k, v));
  s.append(c); return s;
}
/* ---------------- Ovozli xabar: ijro etish (bitta umumiy pleer, qayta chizishda holat saqlanadi) ---------------- */
const VP = {id: null, audio: null, url: null, rate: 1, loading: false};
const fmtDur = s => { s = Math.max(0, Math.round(s || 0)); return Math.floor(s / 60) + ":" + pad2(s % 60); };
function voiceStop() {
  if (VP.audio) { try { VP.audio.pause(); VP.audio.removeAttribute("src"); VP.audio.load(); } catch (_) {} }
  if (VP.url) URL.revokeObjectURL(VP.url);
  VP.id = VP.audio = VP.url = null; VP.loading = false;
  paintVoices();
  vnStop();                                                            // bir vaqtda faqat bitta ovoz/video xabar ijro etiladi
}
function paintVoice(box) {
  const id = +box.dataset.vid, cur = VP.id === id, a = cur ? VP.audio : null;
  const dur = a && isFinite(a.duration) && a.duration > 0 ? a.duration : +box.dataset.dur;
  box.classList.toggle("active", !!a);
  box.classList.toggle("playing", !!a && !a.paused);
  box.classList.toggle("loading", cur && VP.loading);
  box.querySelector(".vfill").style.width = (a && dur ? Math.min(100, a.currentTime / dur * 100) : 0) + "%";
  box.querySelector(".vtime").textContent = a && (a.currentTime > 0 || !a.paused) ? fmtDur(a.currentTime) + " / " + fmtDur(dur) : fmtDur(dur);
  box.querySelector(".vspd").textContent = VP.rate + "x";
}
function paintVoices() { document.querySelectorAll(".vbox").forEach(paintVoice); }
async function voiceToggle(m) {
  if (VP.id === m.id && VP.audio) { if (VP.audio.paused) VP.audio.play().catch(() => {}); else VP.audio.pause(); paintVoices(); return; }
  if (VP.loading) return;
  voiceStop();
  VP.id = m.id; VP.loading = true; paintVoices();
  try {
    const blob = await fetchFileBlob(m, "audio/wav");
    if (VP.id !== m.id) return;                                        // yuklanayotganda boshqa narsa bosildi
    const url = URL.createObjectURL(blob), a = new Audio();
    a.preload = "auto"; a.src = url; a.playbackRate = VP.rate;
    ["timeupdate", "play", "pause", "loadedmetadata", "durationchange"].forEach(ev => a.addEventListener(ev, paintVoices));
    a.addEventListener("ended", () => { a.currentTime = 0; paintVoices(); });
    a.addEventListener("error", () => { if (VP.audio === a) { toast("Ovozni ijro etib bo'lmadi", "error"); voiceStop(); } });
    VP.audio = a; VP.url = url; VP.loading = false; paintVoices();
    await a.play().catch(() => {});                                    // iOS: ruxsat bermasa, yana bir bosish ijro etadi
  } catch (_) { if (VP.id === m.id) { toast("Ovozni yuklab bo'lmadi", "error"); voiceStop(); } }
}
function voiceBox(m) {
  const f = m.file, dur = f.dur || Math.max(1, (f.size - 44) / 32000);
  const box = h("div", {class: "vbox"});
  box.dataset.vid = m.id; box.dataset.dur = dur;
  const play = h("button", {class: "vplay", type: "button", "aria-label": "Ovozli xabarni ijro etish"}, icon("play", "ic vi-play"), icon("pause", "ic vi-pause"), spinnerEl());
  play.addEventListener("click", e => { e.stopPropagation(); voiceToggle(m); });
  const fill = h("div", {class: "vfill"}), track = h("div", {class: "vtrack"}, h("div", {class: "vline"}, fill));
  track.addEventListener("click", e => {                               // bosilgan joyga o'tish (faqat yuklangan bo'lsa)
    e.stopPropagation();
    const a = VP.id === m.id ? VP.audio : null; if (!a || !isFinite(a.duration) || a.duration <= 0) return;
    const r = track.getBoundingClientRect(); a.currentTime = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)) * a.duration; paintVoices();
  });
  const spd = h("button", {class: "vspd", type: "button", title: "Tezlik", "aria-label": "Ijro tezligi"});
  spd.addEventListener("click", e => { e.stopPropagation(); VP.rate = VP.rate === 1 ? 1.5 : VP.rate === 1.5 ? 2 : 1; if (VP.audio) VP.audio.playbackRate = VP.rate; paintVoices(); });
  box.append(play, h("div", {class: "vmid"}, track, h("div", {class: "vmeta"}, h("span", {class: "vtime"}), spd)));
  paintVoice(box);
  return box;
}
/* ---------------- Dumaloq video xabar: ijro etish ----------------
   Video (ovozsiz) va o'zgartirilgan ovoz — ikkita alohida element; ovoz asosiy soat, video unga moslashtiriladi.
   Elementlar xabar ro'yxatiga qo'shilmaydi (yashirin joyda turadi), shu sabab xabarlar qayta chizilganda ijro uzilmaydi;
   kadrlar xabardagi dumaloq <canvas>'ga chiziladi. Fayl qurilmada ochiladi (E2EE), serverda ochiq holda hech qachon bo'lmaydi. */
const VN = {id: null, video: null, audio: null, vurl: null, aurl: null, loading: false, ended: false, raf: 0, seq: 0};
let vnHost = null;
function vnHostEl() { if (!vnHost) { vnHost = h("div", {class: "vn-host", "aria-hidden": "true"}); document.body.append(vnHost); } return vnHost; }
const vnMaster = () => VN.audio || VN.video;
function vnStop() {
  VN.seq++; if (VN.raf) cancelAnimationFrame(VN.raf);
  const {video: v, audio: a, vurl, aurl} = VN;
  if (a) { try { a.pause(); a.removeAttribute("src"); a.load(); } catch (_) {} }
  if (v) { try { v.pause(); v.removeAttribute("src"); v.load(); } catch (_) {} v.remove(); }
  [vurl, aurl].forEach(u => { if (u) URL.revokeObjectURL(u); });
  Object.assign(VN, {id: null, video: null, audio: null, vurl: null, aurl: null, loading: false, ended: false, raf: 0});
  paintVNs();
}
function drawCover(cv, v) {                                           // kvadratga markazdan kesib chizadi
  const w = v.videoWidth, hh = v.videoHeight; if (!w || !hh) return;
  const s = Math.min(w, hh), n = cv.width;
  cv.getContext("2d").drawImage(v, (w - s) / 2, (hh - s) / 2, s, s, 0, 0, n, n);
}
function paintVN(box) {
  const id = +box.dataset.vnid, cur = VN.id === id, v = cur ? VN.video : null, a = cur ? vnMaster() : null;
  const ready = !!(cur && v && !VN.loading), playing = ready && !!a && !a.paused && !VN.ended;
  const total = +box.dataset.dur || (a && isFinite(a.duration) ? a.duration : 0), t = ready && !VN.ended && a ? a.currentTime : 0;
  box.classList.toggle("ready", ready); box.classList.toggle("playing", playing); box.classList.toggle("loading", cur && VN.loading);
  box.querySelector(".vnr-fg").setAttribute("stroke-dashoffset", String(301.6 * (1 - (total ? Math.min(1, t / total) : 0))));
  box.querySelector(".vndur").textContent = ready && (playing || t > 0) ? fmtDur(t) + " / " + fmtDur(total) : fmtDur(total);
  if (ready && v.readyState >= 2) drawCover(box.querySelector("canvas"), v);
}
function paintVNs() { document.querySelectorAll(".vnbox").forEach(paintVN); }
function vnTick() {
  VN.raf = 0;
  const v = VN.video, a = VN.audio; if (!v) return;
  if (a && !a.paused && !v.seeking) {
    if (v.paused && !v.ended) v.play().catch(() => {});
    if (Math.abs(v.currentTime - a.currentTime) > 0.25) { try { v.currentTime = a.currentTime; } catch (_) {} }   // ovoz asosiy: video unga yetib oladi
  }
  paintVNs();
  const m = vnMaster();
  if (m && !m.paused && !VN.ended) VN.raf = requestAnimationFrame(vnTick);
}
const vnKick = () => { if (!VN.raf) VN.raf = requestAnimationFrame(vnTick); };
async function vnPlayBoth() {
  const v = VN.video, a = VN.audio; if (!v) return;
  try { await Promise.all([v.play(), a ? a.play() : null]); vnKick(); }
  catch (_) { try { v.pause(); if (a) a.pause(); } catch (__) {} toast("Ijro etib bo'lmadi. Yana bir bor bosing", "error"); }
  paintVNs();
}
async function vnToggle(m) {
  if (VN.id === m.id) {
    if (VN.loading || !VN.video) return;
    const v = VN.video, a = VN.audio;
    if (VN.ended) { VN.ended = false; try { v.currentTime = 0; if (a) a.currentTime = 0; } catch (_) {} await vnPlayBoth(); }
    else if (vnMaster().paused) await vnPlayBoth();
    else { v.pause(); if (a) a.pause(); }
    paintVNs(); return;
  }
  voiceStop();                                                         // boshqa ovoz/video to'xtaydi (vnStop ham shu yerda)
  const token = VN.seq; VN.id = m.id; VN.loading = true; paintVNs();
  const alive = () => VN.seq === token && VN.id === m.id;
  let v = null, a = null, vurl = null, aurl = null, adopted = false;
  try {
    const parts = VNote.unpack(await e2eFetchBlob(m));
    if (!alive()) return;
    v = document.createElement("video");
    if (!v.canPlayType(m.file.mime)) throw new Error("format");
    v.muted = true; v.playsInline = true; v.preload = "auto"; v.disablePictureInPicture = true;
    v.setAttribute("playsinline", ""); v.setAttribute("webkit-playsinline", "");
    vurl = URL.createObjectURL(new Blob([parts.video], {type: m.file.mime}));
    if (parts.audio) { aurl = URL.createObjectURL(new Blob([parts.audio], {type: "audio/wav"})); a = new Audio(); a.preload = "auto"; a.src = aurl; }
    vnHostEl().append(v); v.src = vurl;
    await new Promise((res, rej) => {
      if (v.readyState >= 2) return res();
      const t = setTimeout(() => rej(new Error("vaqt")), 15000);
      v.addEventListener("loadeddata", () => { clearTimeout(t); res(); }, {once: true});
      v.addEventListener("error", () => { clearTimeout(t); rej(new Error("video")); }, {once: true});
    });
    if (!alive()) return;
    adopted = true;
    Object.assign(VN, {video: v, audio: a, vurl, aurl, loading: false, ended: false});
    const mst = a || v;
    ["play", "pause", "seeked", "loadedmetadata"].forEach(ev => mst.addEventListener(ev, () => { paintVNs(); if (!mst.paused) vnKick(); }));
    v.addEventListener("seeked", paintVNs);
    mst.addEventListener("ended", () => {
      if (VN.video !== v) return;
      VN.ended = true; v.pause(); if (a) a.pause();
      try { v.currentTime = 0; } catch (_) {}
      paintVNs();
    });
    if (a) a.addEventListener("error", () => { if (VN.audio === a) { toast("Ovozni ijro etib bo'lmadi", "error"); vnStop(); } });
    v.addEventListener("error", () => { if (VN.video === v) { toast("Videoni ijro etib bo'lmadi", "error"); vnStop(); } });
    paintVNs();                                                        // 1-kadr ko'rinadi
    await vnPlayBoth();
  } catch (_) {
    if (!adopted) { if (v) v.remove(); [vurl, aurl].forEach(u => { if (u) URL.revokeObjectURL(u); }); }
    if (alive()) { toast("Video xabarni ochib bo'lmadi", "error"); vnStop(); }
  }
}
function vnoteBox(m) {
  const f = m.file, NSV = "http://www.w3.org/2000/svg";
  const box = h("div", {class: "vnbox", role: "button", tabindex: "0", "aria-label": "Video xabarni ijro etish"});
  box.dataset.vnid = m.id; box.dataset.dur = f.dur || 0;
  const c = h("div", {class: "vnc"});
  if (f.th) c.append(h("img", {class: "vnth", alt: "", draggable: "false", src: f.th}));
  c.append(h("canvas", {width: 360, height: 360}), h("span", {class: "vnplay", "aria-hidden": "true"}, icon("play", "ic"), spinnerEl()), h("span", {class: "vndur"}));
  const ring = document.createElementNS(NSV, "svg"); ring.setAttribute("class", "vnring"); ring.setAttribute("viewBox", "0 0 100 100"); ring.setAttribute("aria-hidden", "true");
  [["vnr-bg", false], ["vnr-fg", true]].forEach(([cls, fg]) => {
    const ci = document.createElementNS(NSV, "circle"); ci.setAttribute("class", cls); ci.setAttribute("cx", 50); ci.setAttribute("cy", 50); ci.setAttribute("r", 48);
    if (fg) ci.setAttribute("stroke-dashoffset", "301.6"); ring.append(ci);
  });
  box.append(c, ring);
  const go = e => { e.stopPropagation(); vnToggle(m); };
  box.addEventListener("click", go);
  box.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); go(e); } });
  paintVN(box);
  return box;
}
function fullImg(m) {
  const img = h("img", {class: "mimg", alt: "Rasm", draggable: "false"});
  img.addEventListener("load", () => { const b = $("msgs"); if (b._stick) b.scrollTop = b.scrollHeight; });
  imgSrcOf(m).then(u => { img.src = u; }).catch(() => {});
  return img;
}
function startImageLoad(m, box) {
  S.imgs.set(m.id, "loading"); box.classList.add("loading");
  const t0 = performance.now(), pre = new Image();
  const done = ok => {
    const wait = Math.max(0, 550 - (performance.now() - t0));      // animatsiya ko'rinib o'tishi uchun
    setTimeout(() => {
      if (!ok) {                                                    // xato: yana bosib ko'rish mumkin
        S.imgs.delete(m.id); toast("Rasmni yuklab bo'lmadi", "error");
        const b = document.querySelector('#msgs .row[data-id="' + m.id + '"] .imgbox'); if (b) b.classList.remove("loading");
        return;
      }
      S.imgs.set(m.id, "open");
      const cur = document.querySelector('#msgs .row[data-id="' + m.id + '"] .imgbox');   // qayta chizilgan bo'lishi mumkin
      if (!cur) return;
      const img = fullImg(m); img.classList.add("reveal");
      cur.classList.remove("loading"); cur.classList.add("open"); cur.setAttribute("aria-label", "Rasmni kattalashtirish");
      cur.append(img);
      void cur.offsetWidth;
      requestAnimationFrame(() => cur.classList.add("clear"));
      setTimeout(() => cur.querySelectorAll(".mthumb,.mdl").forEach(x => x.remove()), 450);
    }, wait);
  };
  pre.onload = () => done(true); pre.onerror = () => done(false);
  imgSrcOf(m).then(u => { pre.src = u; }).catch(() => done(false));
}
/* ---------------- Reaksiyalar (xabar va kanal postlariga; Telegramdagidek) ----------------
   Bir foydalanuvchi — bitta xabarga bitta reaksiya. Server ro'yxatni saqlaydi va hammaga tarqatadi (`rx: {emoji: [user_id]}`).
   Sozlamalar (ikki marta bosish yoqilgan/o'chirilgan va qaysi emoji) shu qurilmada saqlanadi. */
const RX_QUICK = ["❤️", "👍", "👎", "🔥", "😂", "😮", "😢"];          // menyudagi bir qatorli tezkor reaksiyalar; qolgani ↓ tugmasi ostida
function rxAll() {                                                    // barcha reaksiyalar: chatdagi standart emojilar + yaratilgan (maxsus) emojilar
  const out = STD_EMOJIS.map(e => ({e, custom: false}));
  if (EM.data && emojiPerms().use) EM.data.emojis.filter(x => emojiUsable(x) && Rich.hasInlineEmoji(x.token)).forEach(x => out.push({e: x.token, custom: true, label: x.label}));
  return out;
}
const rxValid = e => typeof e === "string" && (STD_EMOJIS.includes(e) || Rich.isEmojiToken(e));
function rxGlyph(e, cls) {                                            // oddiy emoji — matn, `:nom:` — rasm
  if (Rich.isEmojiToken(e) && Rich.hasInlineEmoji(e)) { const i = Rich.chatEmoji(e, false); i.classList.add("rxi"); return i; }
  return h("span", {class: cls || "rx-e", text: Rich.isEmojiToken(e) ? "◈" : e});
}
const RX_KEY = "tc_rx";
const rxPrefs = (() => {
  let p = {}; try { p = JSON.parse(localStorage.getItem(RX_KEY) || "{}") || {}; } catch (_) {}
  const ok = typeof p.emoji === "string" && p.emoji.length <= 20 && !/[A-Za-z0-9]/.test(p.emoji.replace(/^:[a-z0-9_]{2,14}:$/, ""));   // oddiy emoji yoki :nom: (STD_EMOJIS bu yerda hali e'lon qilinmagan)
  return {dbl: p.dbl !== false, emoji: ok ? p.emoji : "❤️"};
})();
const rxSave = () => { try { localStorage.setItem(RX_KEY, JSON.stringify(rxPrefs)); } catch (_) {} };
const canReact = m => !!m && !m.service && m.id != null && !$("chat").classList.contains("dead");
function rxMine(m) {
  for (const [e, ids] of Object.entries(m.rx || {})) if (ids.includes(S.me.id)) return e;
  return null;
}
function reactTo(m, emoji) { if (canReact(m)) wsSend({type: "react", id: m.id, emoji}); }       // bir xil emoji qayta — serverda olib tashlanadi
function rxChip(e) {
  const chip = h("button", {class: "rx", type: "button"}, rxGlyph(e), h("b", {class: "cnt"}));
  chip.dataset.e = e;
  chip.addEventListener("click", ev => {
    ev.stopPropagation();
    const m = chip._m; if (!m) return;
    if (rxMine(m) !== e) { const r = chip.getBoundingClientRect(); rxBurst(e, r.left + r.width / 2, r.top + r.height / 2, {mini: true}); haptic(8); }
    reactTo(m, e);                                   // bir xil emoji qayta bosilsa serverda olib tashlanadi
  });
  return chip;
}
function rxCount(chip, n, anim) {                    // son o'zgarganda raqam "yumalab" almashadi
  const b = chip.querySelector(".cnt"), old = b.firstElementChild;
  if (!old) { b.append(h("span", {text: String(n)})); b.dataset.n = String(n); return; }
  const prev = Number(b.dataset.n); if (prev === n) return;
  b.dataset.n = String(n);
  if (!anim) { old.textContent = String(n); return; }
  const up = n > prev;
  b.querySelectorAll("span").forEach(x => { x.classList.add(up ? "up-out" : "down-out"); setTimeout(() => x.remove(), 240); });
  b.append(h("span", {class: up ? "up-in" : "down-in", text: String(n)}));
}
function rxSync(box, m, anim) {                      // chiplarni qayta yaratmasdan yangilaydi: yangisi "pop" bilan chiqadi, yo'qolgani kichrayib ketadi
  const want = Object.entries(m.rx || {}).filter(([, ids]) => ids.length), keys = new Set(want.map(([e]) => e)), have = new Map();
  [...box.children].forEach(c => {
    if (c.classList.contains("out")) return;
    if (keys.has(c.dataset.e)) have.set(c.dataset.e, c);
    else if (anim) { c.classList.add("out"); setTimeout(() => c.remove(), 230); } else c.remove();
  });
  let prev = null;
  want.forEach(([e, ids]) => {
    let c = have.get(e); const fresh = !c;
    if (fresh) c = rxChip(e);
    c._m = m;
    const mine = ids.includes(S.me.id), was = c.classList.contains("mine"), before = Number((c.querySelector(".cnt") || {dataset: {}}).dataset.n || 0);
    c.classList.toggle("mine", mine);
    c.title = ids.slice(0, 12).map(id => U(id).nickname).join(", ") + (ids.length > 12 ? " va yana " + (ids.length - 12) + " kishi" : "");
    c.setAttribute("aria-label", e + " " + ids.length + (mine ? " (siz qo'ygansiz)" : ""));
    rxCount(c, ids.length, anim && !fresh);
    if (anim) {
      const once = cls => { c.classList.add(cls); c.addEventListener("animationend", () => c.classList.remove(cls), {once: true}); };
      if (fresh) once("in");
      else if (mine && !was) { const g = c.firstElementChild; g.classList.add("pop"); setTimeout(() => g.classList.remove("pop"), 520); }   // o'zingiz qo'ysangiz emoji "sakraydi"
      else if (!mine && ids.length > before) once("bump");                                                                                 // boshqa odam qo'shsa chip yengil to'lqin beradi
    }
    const nxt = prev ? prev.nextElementSibling : box.firstElementChild;
    if (c !== nxt) box.insertBefore(c, nxt);
    prev = c;
  });
}
function reactionsEl(m) {
  if (!Object.values(m.rx || {}).some(a => a.length)) return null;
  const box = h("div", {class: "rxs"}); rxSync(box, m, false); return box;
}
function patchReactions(m) {                          // faqat shu xabar qatoridagi chiplar yangilanadi (rasm/video qayta yuklanmaydi)
  const row = document.querySelector('#msgs .row[data-id="' + Number(m.id) + '"]'); if (!row) return;
  const has = Object.values(m.rx || {}).some(a => a.length);
  let box = row.querySelector(".rxs");
  if (!box) {
    if (!has) return;
    box = h("div", {class: "rxs"});
    if (row.classList.contains("chan")) { const meta = row.querySelector(".bubble > .bfoot, .bubble > .meta"); (meta ? meta.before(box) : row.querySelector(".bubble").append(box)); }
    else row.append(box);                             // oddiy xabarlarda chiplar pufak ostida (qatorning ikkinchi satri)
    row.classList.add("has-rx");
  }
  rxSync(box, m, true);
  if (!has) setTimeout(() => { if (!box.querySelector(".rx:not(.out)")) { box.remove(); row.classList.remove("has-rx"); } }, 260);
}
function rxBurst(emoji, x, y, o) {                    // ikki marta bosilganda: emoji "sakraydi" + atrofga mayda emojilar sochiladi
  o = o || {};
  const fx = h("span", {class: "rx-fx", "aria-hidden": "true"}); fx.style.left = x + "px"; fx.style.top = y + "px";
  if (!o.mini) fx.append(h("span", {class: "rx-burst"}, rxGlyph(emoji, "rx-bg")));
  const n = o.mini ? 5 : 8;
  for (let i = 0; i < n; i++) {
    const ang = (Math.PI * 2 * i) / n + Math.random() * .5 - .25, d = (o.mini ? 30 : 64) + Math.random() * 22;
    const sp = h("span", {class: "rx-sp"}, rxGlyph(emoji, "rx-sg"));
    sp.style.setProperty("--dx", (Math.cos(ang) * d).toFixed(1) + "px"); sp.style.setProperty("--dy", (Math.sin(ang) * d - (o.mini ? 6 : 16)).toFixed(1) + "px");
    sp.style.setProperty("--s", (0.55 + Math.random() * 0.45).toFixed(2)); sp.style.animationDelay = (Math.random() * 70 | 0) + "ms";
    fx.append(sp);
  }
  document.body.append(fx); setTimeout(() => fx.remove(), 1000);
  if (o.bubble) { const bb = o.bubble; bb.classList.remove("rx-bump"); void bb.offsetWidth; bb.classList.add("rx-bump"); setTimeout(() => bb.classList.remove("rx-bump"), 380); }
}
function rxPicker(m) {                                // menyu tepasida: bitta qator + ↓ (hamma emojilar)
  const mine = rxMine(m), box = h("div", {class: "rx-pick", role: "group", "aria-label": "Reaksiya"});
  const pick = (e, btn) => ev => {
    ev.stopPropagation(); const r = btn.getBoundingClientRect(); closeCtx();
    if (e !== mine) rxBurst(e, r.left + r.width / 2, r.top); reactTo(m, e);
  };
  const cell = e => { const b = h("button", {class: "rx-pk" + (e === mine ? " on" : ""), type: "button", "aria-label": e}, rxGlyph(e)); b.addEventListener("click", pick(e, b)); return b; };
  const row = h("div", {class: "rx-row"});
  RX_QUICK.forEach((e, i) => { const c = cell(e); c.style.setProperty("--i", String(i)); row.append(c); });
  const more = h("button", {class: "rx-pk rx-more", type: "button", "aria-label": "Barcha reaksiyalar", "aria-expanded": "false"}, icon("down"));
  const all = h("div", {class: "rx-all hidden"});
  let built = false;
  more.addEventListener("click", ev => {
    ev.stopPropagation();
    if (!built) {                                    // katta ro'yxat faqat kerak bo'lganda chiziladi
      built = true;
      const list = rxAll(), std = list.filter(x => !x.custom), cus = list.filter(x => x.custom);
      const grid = h("div", {class: "rx-grid-all"}); std.forEach(x => grid.append(cell(x.e))); all.append(grid);
      if (cus.length) { const g2 = h("div", {class: "rx-grid-all"}); cus.forEach(x => g2.append(cell(x.e))); all.append(h("small", {class: "rx-cap", text: "Maxsus emojilar"}), g2); }
    }
    const open = all.classList.toggle("hidden") === false;
    more.classList.toggle("up", open); more.setAttribute("aria-expanded", String(open));
    const c = $("ctx"), r = c.getBoundingClientRect();            // menyu kengaysa ekrandan chiqib ketmasin
    if (!c.classList.contains("as-sheet") && r.bottom > innerHeight - 8) c.style.top = Math.max(8, innerHeight - 8 - r.height) + "px";
  });
  more.style.setProperty("--i", String(RX_QUICK.length)); row.append(more); box.append(row, all);
  return box;
}
const TAP_SKIP = "a,button,input,textarea,select,[role=button],.mplayer,.vtrack,.vspd,.cbtn,.code-scroll,.term-scroll,.rxs";   // o'zining bosish amali bor elementlar
function attachTap(bubble, m) {
  let last = 0, timer = 0, lx = 0, ly = 0;
  bubble.addEventListener("click", e => {
    if (e.defaultPrevented || S.sel) return;                                 // uzoq bosish/surishdan keyingi bosish yoki belgilash rejimi
    if (e.target.closest && e.target.closest(TAP_SKIP)) return;
    const can = canReact(m), now = Date.now();
    if (rxPrefs.dbl && can && timer && now - last < 320) {                   // ikki marta ketma-ket: reaksiya
      clearTimeout(timer); timer = 0; last = 0;
      try { getSelection().removeAllRanges(); } catch (_) {}
      const emo = rxPrefs.emoji;
      rxBurst(emo, e.clientX, e.clientY, {bubble}); haptic(10);
      if (rxMine(m) !== emo) reactTo(m, emo);
      return;
    }
    let picked = ""; try { picked = String(getSelection() || "").trim(); } catch (_) {}
    if (picked) return;                                                      // kompyuter: matn belgilanayotgan bo'lsa menyu chiqmasin
    last = now; lx = e.clientX; ly = e.clientY; clearTimeout(timer);
    const open = () => { timer = 0; openCtx(lx, ly, m); };
    if (rxPrefs.dbl && can) timer = setTimeout(open, 280); else open();     // ikki marta bosish yoqilgan bo'lsa, ikkinchi bosishni biroz kutamiz
  });
}
function openReactionSettings() {
  openModal(() => {
    const grid = h("div", {class: "rx-grid" + (rxPrefs.dbl ? "" : " off")});
    const dbl = h("input", {type: "checkbox"}); dbl.checked = rxPrefs.dbl;
    dbl.addEventListener("change", () => { rxPrefs.dbl = dbl.checked; rxSave(); grid.classList.toggle("off", !rxPrefs.dbl); });
    rxAll().forEach(({e}) => {
      const b = h("button", {class: "rx-opt" + (e === rxPrefs.emoji ? " on" : ""), type: "button", "aria-label": e}, rxGlyph(e));
      b.addEventListener("click", () => {
        rxPrefs.emoji = e; rxSave();
        grid.querySelectorAll(".rx-opt").forEach(x => x.classList.toggle("on", x === b));
        const r = b.getBoundingClientRect(); rxBurst(e, r.left + r.width / 2, r.top);
      });
      grid.append(b);
    });
    return h("div", {},
      sheetHead("Reaksiya sozlamalari"),
      h("div", {class: "sh-body"},
        h("div", {class: "setsec"},
          h("label", {class: "tgl"}, h("span", {text: "Ikki marta bosganda reaksiya"}), dbl),
          h("p", {class: "hint", text: "Xabar yoki post ustiga ketma-ket 2 marta bosilsa, pastdagi reaksiya qo'yiladi. O'chirilsa, reaksiyani xabar menyusidan tanlaysiz."})),
        h("div", {class: "setsec"}, h("h4", {text: "Ikki marta bosganda qo'yiladigan reaksiya"}), grid,
          h("p", {class: "hint", text: "Bir xabarga bitta reaksiya qo'yiladi. Reaksiya ustiga bosib uni olib tashlash yoki almashtirish mumkin."}))));
  }, false);
}
function bubbleRow(m, isGroup, first, last, chan) {
  const own = m.user.id === S.me.id, mine = chan ? false : own, u = U(m.user.id);     // kanal postlari hammaga chap tomondan (Telegramdagidek)
  const row = h("div", {class: "row" + (mine ? " mine" : "") + (first ? " first" : "") + (last ? " last" : "") + (isGroup ? "" : " dm") + (chan ? " chan" : "")});
  row.dataset.id = m.id;
  if (S.sel) {
    const can = canDelete(m);
    row.classList.add(can ? "selectable" : "locked");
    if (can) {
      if (S.sel.has(m.id)) row.classList.add("selected");
      row.append(h("span", {class: "chk", "aria-hidden": "true"}, icon("check")));
    }
    row.addEventListener("click", e => { e.preventDefault(); e.stopPropagation(); toggleSel(m, row); }, true);
  }
  const slot = h("div", {class: "slot"});
  // Telegramdagidek: bir odamning ketma-ket xabarlarida avatar faqat eng oxirgisining yonida ko'rinadi,
  // qolganlarida o'sha joy bo'sh qoladi (xabarlar bir tekis turadi).
  if (isGroup && !mine && last) { const a = avatar(u, "s"); a.style.cursor = "pointer"; a.addEventListener("click", () => openProfile(u.id)); slot.append(a); }
  const meta = h("span", {class: "meta"});
  if (m.edited) meta.append("tahrirlangan ");
  if (m.e2e) meta.append(h("span", {class: "lk" + (m.locked ? "" : (m.verified && !m.bad ? " ok" : " bad")),
    title: m.locked ? "Shifrlangan, kalit kutilmoqda" : m.verified && !m.bad ? "Uchdan-uchga shifrlangan, imzosi tasdiqlangan" : "Imzo yoki shifrni tekshirib bo'lmadi!",
    text: m.locked ? "🔒" : m.verified && !m.bad ? "🔒" : "⚠"}), " ");
  else if (m.legacy) meta.append(h("span", {class: "lk bad", title: "Eski xabar: E2EE'dan oldin yozilgan, server o'qiy oladi", text: "🔓"}), " ");
  if (chan) meta.append(h("span", {class: "vws", title: "Ko'rishlar soni"}, icon("eye"), h("b", {text: String(m.views || 0)})), " ");
  meta.append(hhmm(m.ts));
  if (mine && m.to != null) meta.append(icon(m.read ? "checks" : "check", m.read ? "ic rd" : "ic"));
  const bubble = tint(h("div", {class: "bubble" + (isStaff(u) ? " prem " + u.role : "") + (m.image ? " has-img" + (m.content ? "" : " img-only") : "") + (m.file ? " has-file" + (S.previews.has(m.id) ? " has-pv" : "") + (m.file.voice ? " has-voice" : "") + (m.file.vnote ? " has-vnote" + (m.content ? "" : " vn-only") : "") : "")}), u);
  if (isGroup && !mine && first) {
    const ne = nameEl(u, {colored: true});                 // faqat ism (nickname) bosiladi; qatorning bo'sh joyi — oddiy xabar bosishi
    ne.classList.add("lnk");
    ne.addEventListener("click", e => { e.stopPropagation(); openProfile(u.id); });
    bubble.append(h("div", {class: "bname"}, ne));
  }
  if (m.fwd) bubble.append(h("div", {class: "fwd", title: "Yuboruvchi ko'rsatgan asl muallif (tekshirib bo'lmaydi)"}, icon("forward"), h("span", {text: "Oldinga yuborilgan: "}), h("b", {text: m.fwd.n})));
  if (m.reply) bubble.append(replyQuote(m.reply));
  if (m.image) bubble.append(imageBox(m, mine || own));
  if (m.file) bubble.append(fileBox(m));
  const more = h("button", {class: "more", type: "button", "aria-label": "Amallar"}, icon("down"));
  more.addEventListener("click", e => { e.stopPropagation(); const r = more.getBoundingClientRect(); openCtx(r.left, r.bottom + 4, m); });
  const shown = m.locked ? "🔒 Xabar kaliti kutilmoqda…" : m.bad ? "⚠ Shifrni ochib bo'lmadi" : m.content;
  const parts = !m.locked && !m.bad && m.content ? Rich.parse(m.content) : null;
  if (parts && Rich.hasRich(parts)) {                  // kod / Linux buyruqlari: alohida dizayn + pastida kichik «Nusxalash» tugmasi
    bubble.classList.add("has-code");
    parts.forEach((p, i) => {
      if (p.k === "text") { if (p.t) bubble.append(btextEl("btext rich-t", p.t, true)); return; }
      bubble.append(Rich.render(p, {user: u.username, fx: p.k === "term" && fxNow(m.id + ":" + i, m.ts), copy: copyQuiet}));
    });
  } else if (shown || !(m.image || m.file)) bubble.append(btextEl("btext" + (m.locked || m.bad ? " dim" : ""), shown, !m.locked && !m.bad));
  const rxEl = reactionsEl(m);
  if (rxEl && chan) bubble.append(rxEl);             // kanal postida chiplar post ichida (izoh tugmasi tepasida); oddiy xabarda — pufak ostida
  if (bubble.querySelector(".bigemo")) {            // stiker kabi katta emoji: vaqt emoji ostida alohida qatorda
    bubble.classList.add("has-big");
    bubble.append(h("div", {class: "bfoot"}, meta), more);
  } else bubble.append(meta, more);
  if (chan) bubble.append(h("button", {class: "cmbtn", type: "button", onclick: e => { e.stopPropagation(); Channels.openComments(m); }},
    icon("chat"), h("span", {class: "cmb-t", text: m.comments ? m.comments + " ta izoh" : "Izoh qoldirish"}), h("span", {class: "cmb-go", text: "›"})));
  bubble.addEventListener("contextmenu", e => { e.preventDefault(); if (S.sel) return toggleSel(m, row); openCtx(e.clientX, e.clientY, m); });
  attachTouch(bubble, row, m);          // uzoq bosish = menyu, chapga surish = javob
  attachTap(bubble, m);                 // bir marta bosish = menyu (javob, nusxa, uzatish...), ikki marta = reaksiya
  row.append(slot, bubble);
  if (rxEl && !chan) { row.append(rxEl); row.classList.add("has-rx"); }
  return row;
}
const BIG_STD = /^(?:\p{Extended_Pictographic}(?:\uFE0F|[\u{1F3FB}-\u{1F3FF}]|\u200D\p{Extended_Pictographic}\uFE0F?)*\s*){1,3}$/u;   // faqat 1–3 ta oddiy emoji
function btextEl(cls, text, rich) {                 // matn; ro'yxatdagi `:nom:` emojilar rasmga aylanadi (innerHTML ishlatilmaydi)
  const d = h("div", {class: cls});
  if (rich && Rich.hasInlineEmoji(text)) d.append(Rich.inline(text)); else d.textContent = text == null ? "" : text;
  if (rich && (d.querySelector(".ce.big") || (typeof text === "string" && text.length <= 40 && BIG_STD.test(text.trim())))) d.classList.add("bigemo");   // faqat emojidan iborat xabar — stiker kabi katta
  return d;
}
function toggleToBottom() {
  const b = $("msgs");
  $("toBottom").classList.toggle("hidden", b.scrollHeight - b.scrollTop - b.clientHeight < 240);
}
let scrollTick = 0;                               // scroll hodisasi kadrda bir marta ishlanadi (layout o'qish kam)
$("msgs").addEventListener("scroll", () => {
  if (scrollTick) return;
  scrollTick = requestAnimationFrame(() => {
    scrollTick = 0;
    const b = $("msgs"), bot = atBottom(); b._stick = bot; toggleToBottom();
    if (bot && S.away) bumpAway(true);
    closeCtx(); if (b.scrollTop < 160) loadOlder();
  });
}, {passive: true});
$("msgs").addEventListener("wheel", e => { if (e.deltaY < 0 && $("msgs").scrollTop <= 0) loadOlder(); }, {passive: true});     // kompyuter: eng tepada g'ildirak
$("msgs").addEventListener("touchmove", () => { if ($("msgs").scrollTop <= 0) loadOlder(); }, {passive: true});               // telefon: eng tepada tortish
$("toBottom").addEventListener("click", () => { const b = $("msgs"); b.scrollTop = b.scrollHeight; bumpAway(true); });



/* ---------------- Shaxsiy suhbat menyusi / suhbatni o'chirish ---------------- */
function openMenu(x, y, items, sheet) {
  S.ctxAt = Date.now();
  const ctx = $("ctx"); ctx.textContent = "";
  items.forEach(it => {
    const b = h("button", {class: "dd-i", type: "button", onclick: () => { closeCtx(); it.fn(); }}, icon(it.ic), it.text);
    if (it.danger) b.style.color = "var(--err)";
    ctx.append(b);
  });
  showCtx(ctx, x, y, !!sheet && isMobile());
}
function showCtx(ctx, x, y, asSheet) {              // telefonda: pastdan chiqadigan varaq; kompyuterda: kursor yonida
  ctx.classList.remove("hidden");
  ctx.classList.toggle("as-sheet", asSheet);
  $("ctxBack").classList.toggle("hidden", !asSheet);
  if (isMobile()) navPush("ctx");
  const w = ctx.offsetWidth, hgt = ctx.offsetHeight;
  ctx.style.left = Math.max(8, Math.min(x, innerWidth - w - 8)) + "px";
  ctx.style.top = Math.max(8, Math.min(y, innerHeight - hgt - 8)) + "px";
}
function dmMenu(x, y, uid, sheet) {
  openMenu(x, y, [
    {ic: "user", text: "Profilni ko'rish", fn: () => openProfile(uid)},
    {ic: "trash", text: "Suhbatni o'chirish", danger: true, fn: () => deleteDmChat(uid)},
  ], sheet);
}
$("chMore").addEventListener("click", e => {
  e.stopPropagation();
  if (!S.active || S.active.kind === "group") return;
  const r = $("chMore").getBoundingClientRect();
  if (S.active.kind === "channel") Channels.menu(r.right - 220, r.bottom + 4, S.active.id);
  else dmMenu(r.right - 200, r.bottom + 4, S.active.uid);
});
async function deleteDmChat(uid) {
  const u = U(uid);
  const ok = await confirmDlg("Bu suhbat (" + u.nickname + " bilan) ikkala tomon uchun ham butunlay o'chiriladi: xabarlar va rasmlar ikkalangizdan ham yo'qoladi. Buni qaytarib bo'lmaydi.",
    {title: "Suhbatni o'chirish", okText: "O'chirish", danger: true});
  if (ok) wsSend({type: "delete_dm", with: uid});
}

/* ---------------- Belgilash rejimi: ko'p xabarni birdaniga o'chirish ---------------- */
let renderQueued = false;
function scheduleRender() {                       // ketma-ket o'chirishlarda bir kadrda bir marta chizish
  if (renderQueued) return; renderQueued = true;
  requestAnimationFrame(() => { renderQueued = false; renderMessages(false); renderList(); });
}
function enterSelect(firstId) {
  if (!S.active) return;
  cancelEdit(); cancelReply();
  S.sel = new Set(); if (firstId != null) S.sel.add(firstId);
  $("chat").classList.add("selecting"); navPush("sel");
  renderMessages(false); updateSelBar();
}
function exitSelect() {
  if (!S.sel) return;
  S.sel = null; $("chat").classList.remove("selecting"); navPop("sel");
  renderMessages(false);
}
function toggleSel(m, row) {
  if (!S.sel || !canDelete(m)) return;
  if (S.sel.has(m.id)) S.sel.delete(m.id); else S.sel.add(m.id);
  if (row) row.classList.toggle("selected", S.sel.has(m.id));
  updateSelBar();
}
function updateSelBar() {
  if (!S.sel) return;
  $("selCount").textContent = String(S.sel.size);
  $("selDel").disabled = !S.sel.size;
  const all = currentMsgs().filter(x => !x.service && canDelete(x));
  $("selAll").textContent = all.length && all.every(x => S.sel.has(x.id)) ? "Bekor" : "Hammasi";
}
$("selCancel").addEventListener("click", exitSelect);
$("selAll").addEventListener("click", () => {
  if (!S.sel) return;
  const all = currentMsgs().filter(x => !x.service && canDelete(x));
  if (all.length && all.every(x => S.sel.has(x.id))) S.sel.clear(); else all.forEach(x => S.sel.add(x.id));
  document.querySelectorAll("#msgs .row[data-id]").forEach(r => r.classList.toggle("selected", S.sel.has(Number(r.dataset.id))));
  updateSelBar();
});
$("selDel").addEventListener("click", async () => {
  if (!S.sel || !S.sel.size) return;
  const ids = [...S.sel], n = ids.length;
  const ok = await confirmDlg(n + " ta xabar o'chirilsinmi?", {title: "Xabarlarni o'chirish", okText: "O'chirish", danger: true});
  if (!ok || !S.sel) return;
  for (let i = 0; i < ids.length; i += 200) wsSend({type: "delete_many", ids: ids.slice(i, i + 200)});
  exitSelect();
});
async function clearGroupChat() {
  if (!amAdmin()) return;
  const ok = await confirmDlg("Umumiy chatdagi BARCHA xabarlar hamma uchun o'chiriladi. Buni qaytarib bo'lmaydi.",
    {title: "Chatni tozalash", okText: "Tozalash", danger: true});
  if (ok) wsSend({type: "clear_chat"});
}

/* ---------------- kontekst menyu ---------------- */
function canDelete(m) {
  if (m.ch) return amAdmin();                         // kanal postini istalgan admin o'chira oladi
  if (m.user.id === S.me.id) return true;
  if (m.to != null || !amAdmin()) return false;
  const t = U(m.user.id);
  return t.role === "user" || (t.role === "admin" && S.me.role === "owner");
}
function openCtx(x, y, m) {
  S.ctxAt = Date.now();
  const ctx = $("ctx"); ctx.textContent = "";
  const add = (ic, text, fn, danger) => {
    const b = h("button", {class: "dd-i", type: "button", onclick: () => { closeCtx(); fn(); }}, icon(ic), text);
    if (danger) b.style.color = "var(--err)";
    ctx.append(b);
  };
  const usable = !m.locked && !m.bad;
  const chan = !!m.ch;
  if (canReact(m)) ctx.append(rxPicker(m));
  if (chan) add("chat", "Izohlar", () => Channels.openComments(m));
  if (usable && !m.legacy && !chan) add("reply", "Javob berish", () => startReply(m));
  if (m.content && usable) add("copy", "Nusxalash", () => copyText(m.content));
  if (usable && (m.image || m.file)) add("save", "Saqlash (Save as)", () => saveAs(m));
  if (usable && !m.legacy && !m.service && (m.content || m.image || m.file)) add("forward", "Oldinga yuborish", () => forwardMessage(m));
  if (m.user.id !== S.me.id && !chan) add("user", "Profilni ko'rish", () => openProfile(m.user.id));
  if (m.user.id !== S.me.id && m.to == null && !m.service && !chan) add("flag", "Shikoyat qilish", () => reportMessage(m));
  if (m.user.id === S.me.id && usable && !m.legacy) add("edit", "Tahrirlash", () => startEdit(m));
  if (canDelete(m)) add("select", "Belgilash", () => enterSelect(m.id));
  if (canDelete(m)) add("trash", "O'chirish", async () => { if (await confirmDlg("Bu xabar o'chirilsinmi?", {title: "Xabarni o'chirish", okText: "O'chirish", danger: true})) wsSend({type: "delete", id: m.id}); }, true);
  const row = document.querySelector('#msgs .row[data-id="' + Number(m.id) + '"]'); if (row) row.classList.add("ctx-on");
  showCtx(ctx, x, y, isMobile());
}
function closeCtx() {
  const c = $("ctx"); if (c.classList.contains("hidden")) return;
  c.classList.add("hidden"); $("ctxBack").classList.add("hidden");
  document.querySelectorAll("#msgs .row.ctx-on").forEach(r => r.classList.remove("ctx-on"));
  navPop("ctx");
}

/* ---------------- Saqlash (Save as) va Oldinga yuborish: hammasi qurilmada, E2EE saqlanadi ----------------
   Saqlash: fayl shifrlangan holda yuklanadi va FAQAT shu qurilmada ochiladi (server ochiq faylni ko'rmaydi).
   Oldinga yuborish: xabar/fayl qurilmada ochiladi va tanlangan suhbat uchun QAYTA shifrlanadi (yangi fayl kaliti,
   yangi konvert, o'z imzom). Server faqat yangi shifrni ko'radi; asl xabarga bog'liq emas (asl o'chsa ham nusxa qoladi). */
const safeName = n => String(n || "fayl").replace(/[\\/:*?"<>|\u0000-\u001f]/g, "_").replace(/^\.+/, "").trim().slice(0, 120) || "fayl";
async function messageBytes(m) {
  if (m.e2e) return e2eFetchBlob(m);
  const url = m.image || (m.file && m.file.url);                            // eski (E2EE'dan oldingi) xabar
  const r = await SC.fetch(url, {headers: {Authorization: "Bearer " + S.token}});
  if (!r.ok) throw new Error("fayl");
  return r.bytes;
}
async function saveBytesAs(getBytes, name) {
  let handle = null;
  if (window.showSaveFilePicker) {                                           // kompyuter: "Save as" oynasi (joy va nom tanlanadi). Bosish faolligi tugamasin deb — avval oyna
    try { handle = await window.showSaveFilePicker({suggestedName: name}); }
    catch (err) { if (err && err.name === "AbortError") return false; handle = null; }
  }
  let bytes;
  try { bytes = await getBytes(); } catch (err) { if (handle && handle.remove) handle.remove().catch(() => {}); throw err; }
  if (handle) {
    const w = await handle.createWritable();
    try { await w.write(bytes); await w.close(); } catch (err) { try { await w.abort(); } catch (_) {} throw err; }
    return true;
  }
  const url = URL.createObjectURL(new Blob([bytes], {type: "application/octet-stream"}));      // telefon/boshqa brauzer: yuklab olishlar papkasiga
  const a = h("a", {href: url, download: name}); document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60000);
  return true;
}
async function saveAs(m) {
  const name = safeName((m._f && m._f.name) || (m.file && m.file.name) || (m.image ? "rasm.jpg" : "fayl"));
  try { if (await saveBytesAs(() => messageBytes(m), name)) toast("Saqlandi: " + name, "ok"); }
  catch (_) { toast("Faylni saqlab bo'lmadi", "error"); }
}
function forwardMessage(m) {
  const picked = new Map();                                                  // kalit -> {kind, uid}
  let filter = "", busy = false;
  const targets = () => [{key: "g", kind: "group"}].concat(S.members.filter(x => x.id !== S.me.id && !x.deleted && !x.banned).map(x => ({key: "u" + x.id, kind: "dm", uid: x.id})));
  const what = m.image ? "📷 Rasm" : m.file ? fileIco(m.file) + fileWhat(m.file) : "";
  openModal(() => {
    const list = h("div", {class: "fwl"}), send = h("button", {class: "btn", type: "button", disabled: true, text: "Yuborish"});
    const note = h("div", {class: "fw-note", text: (what ? what + (m.content ? " • " : "") : "") + (m.content ? m.content.replace(/\s+/g, " ").slice(0, 80) : "")});
    const upd = () => { send.disabled = busy || !picked.size; send.textContent = picked.size ? "Yuborish (" + picked.size + ")" : "Yuborish"; };
    const fill = () => {
      list.textContent = "";
      const q = filter.trim().toLowerCase().replace(/^@/, "");
      targets().forEach(t => {
        const u = t.kind === "dm" ? U(t.uid) : null;
        if (q && (!u || !(u.nickname.toLowerCase().includes(q) || u.username.toLowerCase().includes(q)))) { if (!(t.kind === "group" && "umumiy chat".includes(q))) return; }
        const ck = h("input", {type: "checkbox", class: "ck", tabindex: "-1", "aria-hidden": "true"}); ck.checked = picked.has(t.key);
        const row = h("button", {class: "frow" + (ck.checked ? " on" : ""), type: "button"},
          u ? avatar(u, "m", true) : groupAvatar("m"),
          h("div", {class: "utx"}, u ? nameEl(u) : h("span", {class: "nt", text: "Umumiy chat"}), h("span", {class: "fsub", text: u ? "@" + u.username : (S.members.length || 1) + " a'zo"})), ck);
        row.addEventListener("click", () => { if (busy) return; if (picked.has(t.key)) picked.delete(t.key); else picked.set(t.key, t); ck.checked = picked.has(t.key); row.classList.toggle("on", ck.checked); upd(); });
        list.append(row);
      });
      if (!list.children.length) list.append(h("div", {class: "none", text: "Hech narsa topilmadi"}));
    };
    const search = h("input", {type: "text", class: "gsearch", placeholder: "Qidirish", autocomplete: "off"});
    search.addEventListener("input", () => { filter = search.value; fill(); });
    send.addEventListener("click", async () => {
      if (busy || !picked.size) return;
      busy = true; upd(); send.textContent = "Shifrlanmoqda…"; search.disabled = true;
      const r = await doForward(m, [...picked.values()]);
      busy = false; closeModal();
      if (r.ok) toast("Oldinga yuborildi" + (r.ok > 1 ? " (" + r.ok + " ta suhbat)" : ""), "ok");
      if (r.errs.length) toast(r.errs[0] + (r.errs.length > 1 ? " (+" + (r.errs.length - 1) + " ta xato)" : ""), "error");
    });
    fill();
    return h("div", {}, sheetHead("Oldinga yuborish"), note, search, list, h("div", {class: "fw-bar"}, send));
  }, false);
}
async function doForward(m, targets) {
  const res = {ok: 0, errs: []};
  let enc = null;
  const fw = m._fw || (m.ch ? {n: (chInfo(m.ch) || {}).nickname || "Kanal", id: 0} : {n: m.user.nickname, id: m.user.id});                    // asl muallif saqlanadi (zanjirda ham)
  try { if (m._f) enc = await E2E.encryptFile(new Uint8Array(await messageBytes(m))); }   // fayl bir marta yangi kalit bilan qayta shifrlanadi
  catch (_) { res.errs.push("Faylni ochib bo'lmadi"); return res; }
  for (const t of targets) {
    const label = t.kind === "group" ? "Umumiy chat" : U(t.uid).nickname;
    try {
      if (t.kind === "group" && S.chat.locked && !amAdmin()) throw new Error("chat qulflangan");
      if (t.kind === "dm" && U(t.uid).deleted) throw new Error("akkaunt o'chirilgan");
      const ctx = await keyForTarget(t), payload = {t: m.content || "", fw};
      let blobName = null;
      if (enc) {
        const r = await SC.fetch("/api/e2ee/blob", {method: "POST", headers: {Authorization: "Bearer " + S.token, "Content-Type": "application/octet-stream"}, body: enc.blob});
        const j = await r.json().catch(() => ({}));
        if (!r.ok) throw new Error(typeof j.detail === "string" ? j.detail : "fayl yuklanmadi");
        blobName = j.blob; payload.f = Object.assign({}, m._f, {k: enc.key});
      }
      const msg = {type: "send", e2e: await sealFor(ctx, payload)};
      if (blobName) msg.blob = blobName;
      withTarget(msg, t);
      if (!wsSend(msg)) throw new Error("ulanish yo'q");
      res.ok++;
    } catch (err) { res.errs.push(label + ": " + err.message); }
  }
  return res;
}
async function reportMessage(m) {
  const reason = await promptDlg("Shikoyat qilish", m.e2e
    ? "Xabarlar shifrlangan, adminlar ularni o'qiy olmaydi. Shikoyat yuborsangiz, FAQAT shu bitta xabarning matni adminlarga ochib beriladi. Nima uchun shikoyat qilyapsiz? (ixtiyoriy)"
    : "Nima uchun shikoyat qilyapsiz? (ixtiyoriy)", "", {okText: "Yuborish", placeholder: "Sabab"});
  if (reason === null) return;
  try { await api("/report", {method: "POST", body: {message_id: m.id, reason, evidence: m.e2e ? (m.content || "") : ""}}); toast("Shikoyat adminlarga yuborildi", "ok"); }
  catch (err) { toast(err.message, "error"); }
}
document.addEventListener("click", e => {
  if (Date.now() - (S.ctxAt || 0) > 350) closeCtx();
  if (!e.target.closest("#menu") && !e.target.closest("#menuBtn")) $("menu").classList.add("hidden");
  if (!e.target.closest("#amenu") && !e.target.closest("#moreBtn")) $("amenu").classList.add("hidden");
});
async function copyText(t) {
  try { await navigator.clipboard.writeText(t); toast("Nusxalandi", "ok"); }
  catch (_) {
    const ta = h("textarea", {class: "offscreen"}); ta.value = t; document.body.append(ta); ta.select();
    try { document.execCommand("copy"); toast("Nusxalandi", "ok"); } catch (_e) {}
    ta.remove();
  }
}

/* ---------------- yozish, tahrirlash ---------------- */
const inp = $("inp");
function autosize() { inp.style.height = "auto"; inp.style.height = Math.min(inp.scrollHeight, 140) + "px"; syncSend(); }
function syncSend() {
  $("sendBtn").classList.toggle("on", !!inp.value.trim() || !!S.pendingImg);
  $("composer").classList.toggle("has-text", !!inp.value.trim() || !!S.pendingImg || !!S.editing);   // matn bor: yuborish tugmasi, yo'q: mikrofon
}
inp.addEventListener("input", autosize);
inp.addEventListener("focus", () => setTimeout(() => { const b = $("msgs"); if (b._stick) b.scrollTop = b.scrollHeight; }, 320));
inp.addEventListener("keydown", e => {
  if (e.key === "Enter" && !e.shiftKey && !COARSE && !e.isComposing) { e.preventDefault(); submit(); }
  else if (e.key === "Escape") { if (S.editing) cancelEdit(); else if (S.pendingImg) clearPendingImage(); else if (S.replying) cancelReply(); }
  else if (e.key === "ArrowUp" && !inp.value && S.active) {       // oxirgi o'z xabarini tahrirlash
    const mine = [...currentMsgs()].reverse().find(x => !x.service && x.user.id === S.me.id && !x.legacy && !x.bad && !x.locked);
    if (mine) { e.preventDefault(); startEdit(mine); }
  }
});
inp.addEventListener("paste", e => {                              // Ctrl+V bilan rasm qo'yish; kod/buyruq qo'yilsa — avtomatik ``` blokiga o'raladi
  const f = (e.clipboardData && e.clipboardData.files || [])[0];
  if (f) { e.preventDefault(); setPendingImage(f); return; }
  const txt = e.clipboardData && e.clipboardData.getData("text/plain");
  const whole = !inp.value.trim() || (inp.selectionStart === 0 && inp.selectionEnd === inp.value.length);
  if (!txt || !whole || S.editing) return;
  const fz = Rich.fenceFor(txt.replace(/\r\n?/g, "\n"));
  if (!fz || fz.text.length > inp.maxLength) return;
  e.preventDefault();
  inp.value = fz.text; inp.setSelectionRange(fz.text.length, fz.text.length); autosize();
  toast("Aniqlandi: " + fz.label + ". Xavfsiz ko'rinishda yuboriladi", "ok");
});
$("sendBtn").addEventListener("click", submit);

function startEdit(m) {
  cancelReply(); clearPendingImage();
  S.editing = m; inp.value = m.content; autosize(); inp.focus();
  $("ebText").textContent = m.content ? m.content.replace(/\s+/g, " ") : (m.file ? (m.file.voice ? "🎤 Ovozli xabar izohi" : m.file.vnote ? "📹 Video xabar izohi" : "📎 Fayl izohi") : "📷 Rasm izohi");
  $("editbar").classList.remove("hidden");
}
function cancelEdit() {
  if (!S.editing) return;
  S.editing = null; inp.value = ""; autosize(); $("editbar").classList.add("hidden");
}
$("ebCancel").addEventListener("click", cancelEdit);

function startReply(m) {
  if (m.ch) return;                                   // kanal postlariga javob yo'q: izoh qoldiriladi
  cancelEdit();
  S.replying = replyInfo(m);
  $("rbName").textContent = m.user.nickname;
  $("rbText").textContent = (m.image ? "📷 " : m.file ? fileIco(m.file) : "") + (m.content ? m.content.replace(/\s+/g, " ") : (m.file ? fileWhat(m.file) : "Rasm"));
  $("replybar").classList.remove("hidden");
  inp.focus();
}
function cancelReply() { S.replying = null; $("replybar").classList.add("hidden"); }
$("rbCancel").addEventListener("click", cancelReply);

/* ---- rasm yuborish (izoh bilan) ---- */
const IMG_TYPES = ["image/png", "image/jpeg", "image/webp", "image/gif"], MAX_MEDIA = 50 * 1024 * 1024;
async function shrinkImage(f) {              // katta fotolarni yuborishdan oldin kichraytiradi (GIF tegilmaydi)
  if (f.type === "image/gif" || f.size <= 1.5 * 1024 * 1024 || !self.createImageBitmap) return f;
  try {
    const bmp = await createImageBitmap(f), k = Math.min(1, 1920 / Math.max(bmp.width, bmp.height));
    const c = document.createElement("canvas"); c.width = Math.round(bmp.width * k); c.height = Math.round(bmp.height * k);
    const g = c.getContext("2d"); g.fillStyle = "#fff"; g.fillRect(0, 0, c.width, c.height); g.drawImage(bmp, 0, 0, c.width, c.height);
    const blob = await new Promise(r => c.toBlob(r, "image/jpeg", 0.85));
    return blob && blob.size < f.size ? blob : f;
  } catch (_) { return f; }
}
async function setPendingImage(file) {              // istalgan turdagi fayl (50 MB gacha)
  if (!S.active || !file) return;
  if (S.active.kind === "group" && S.chat.locked && !amAdmin()) { toast("Umumiy chat qulflangan", "error"); return; }
  const isImg = IMG_TYPES.includes(file.type);
  const blob = isImg ? await shrinkImage(file) : file;
  if (blob.size > MAX_MEDIA) { toast("Fayl 50 MB dan oshmasligi kerak", "error"); return; }
  if (!blob.size) { toast("Fayl bo'sh", "error"); return; }
  cancelEdit(); clearPendingImage();
  const ext = blob.type === "image/jpeg" ? "jpg" : (blob.type.split("/")[1] || "png");
  S.pendingImg = {blob, isImg, url: isImg ? URL.createObjectURL(blob) : null, name: isImg ? "rasm." + ext : (file.name || "fayl")};
  $("ibThumb").classList.toggle("hidden", !isImg); $("ibIcon").classList.toggle("hidden", isImg);
  if (isImg) $("ibThumb").src = S.pendingImg.url; else $("ibThumb").removeAttribute("src");
  $("ibTitle").textContent = isImg ? "Rasm" : S.pendingImg.name;
  $("ibInfo").textContent = "Izoh yozib yuboring (ixtiyoriy) • " + fmtSize(blob.size);
  $("imgbar").classList.remove("hidden");
  syncSend(); inp.focus();
}
function clearPendingImage() {
  if (S.pendingImg && S.pendingImg.url) URL.revokeObjectURL(S.pendingImg.url);
  S.pendingImg = null; $("ibThumb").removeAttribute("src"); $("imgbar").classList.add("hidden"); syncSend();
}
$("attachBtn").addEventListener("click", () => $("imgFile").click());
$("imgFile").addEventListener("change", () => { const f = $("imgFile").files[0]; $("imgFile").value = ""; if (f) setPendingImage(f); });
$("ibCancel").addEventListener("click", clearPendingImage);
["dragenter", "dragover"].forEach(ev => $("chat").addEventListener(ev, e => { if (e.dataTransfer && [...e.dataTransfer.types].includes("Files")) { e.preventDefault(); $("chat").classList.add("drop"); } }));
["dragleave", "drop"].forEach(ev => $("chat").addEventListener(ev, e => { if (ev === "dragleave" && $("chat").contains(e.relatedTarget)) return; $("chat").classList.remove("drop"); }));
$("chat").addEventListener("drop", e => { const f = e.dataTransfer && e.dataTransfer.files[0]; if (f) { e.preventDefault(); setPendingImage(f); } });

async function sendImage(caption) {
  if (S.sending) return;
  S.sending = true; $("sendBtn").disabled = true;
  const img = S.pendingImg, keep = $("ibInfo").textContent;
  try {
    const ctx = await keyForActive();
    $("ibInfo").textContent = "Shifrlanmoqda…";
    let blob = img.blob, f = {name: img.name, mime: blob.type || "application/octet-stream", size: blob.size, img: false};
    if (img.isImg) { const c = await cleanImage(blob); blob = c.blob; f = Object.assign(f, {mime: blob.type || f.mime, size: blob.size, img: true, w: c.w, h: c.h, th: c.th}); }
    const e = await E2E.encryptFile(new Uint8Array(await blob.arrayBuffer()));
    f.k = e.key;
    $("ibInfo").textContent = "Yuborilmoqda… (" + fmtSize(e.blob.length) + ")";
    const r = await SC.fetch("/api/e2ee/blob", {method: "POST", headers: {Authorization: "Bearer " + S.token, "Content-Type": "application/octet-stream"}, body: e.blob});
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(typeof j.detail === "string" ? j.detail : "Fayl yuklanmadi");
    const payload = {t: caption, f}; if (S.replying) payload.r = S.replying;
    const msg = {type: "send", e2e: await sealFor(ctx, payload), blob: j.blob};
    withTarget(msg, S.active);
    if (!wsSend(msg)) throw new Error("Ulanish yo'q");
    inp.value = ""; clearPendingImage(); cancelReply(); autosize();
  } catch (err) { toast(err.message, "error"); if (S.pendingImg) $("ibInfo").textContent = keep; }
  S.sending = false; $("sendBtn").disabled = false;
}
async function submit() {
  const text = inp.value.trim();
  if (!S.active || S.sending) return;
  if (S.active.kind === "dm" && U(S.active.uid).deleted) { toast("Bu akkaunt o'chirilgan. Xabar yuborib bo'lmaydi", "error"); return; }
  if (S.pendingImg) { sendImage(text); return; }
  if (!S.editing && !text) return;
  if (S.editing && !text && !S.editing._f) return;
  if (S.editing && text === S.editing.content) { cancelEdit(); return; }
  S.sending = true;
  try {
    const ctx = await keyForActive(), payload = {t: text};
    if (S.editing) {                                                // tahrir: javob va fayl ma'lumoti saqlanadi, matn almashadi
      const m = S.editing;
      if (m._r) payload.r = m._r; if (m._f) payload.f = m._f; if (m._fw) payload.fw = m._fw;
      if (wsSend({type: "edit", id: m.id, e2e: await sealFor(ctx, payload)})) cancelEdit();
    } else {
      if (S.replying) payload.r = S.replying;
      const msg = {type: "send", e2e: await sealFor(ctx, payload)};
      withTarget(msg, S.active);
      if (wsSend(msg)) { inp.value = ""; cancelReply(); autosize(); inp.focus(); }
    }
  } catch (err) { toast(err.message, "error"); }
  S.sending = false;
}
/* ---------------- Ovozli xabar va dumaloq video: yozish -> (ovozni o'zgartirish) -> shifrlash -> yuborish ----------------
   Mikrofon tugmasi (Telegram kabi):
     bir marta bosish — rejim almashadi (🎤 ovoz <-> 📹 dumaloq video);
     bosib turish — yozish; qo'yib yuborish — yuborish; chapga surish — bekor qilish; yuqoriga surish — qulflash (qo'lsiz yozish).
   Qulflangan yozuvda tugma = yuborish, 🗑 = bekor qilish. Esc ham bekor qiladi. Videoda doirani bosish (yoki 🔄) — old/orqa kamera.
   Xom ovoz (ovozli xabarda ham, videodagi ovozda ham) faqat shu qurilma xotirasida, darhol o'zgartiriladi;
   serverga FAQAT o'zgargan va E2EE bilan shifrlangan fayl boradi. */
const HOLD_MS = 260, CANCEL_DX = 90, LOCK_DY = 70;
const micEl = $("micBtn");
const vibrate = ms => { try { if (navigator.vibrate) navigator.vibrate(ms); } catch (_) {} };
try { S.recMode = localStorage.getItem("tc_recmode") === "video" ? "video" : "voice"; } catch (_) {}
function applyRecMode() {
  const v = S.recMode === "video";
  $("composer").classList.toggle("mode-video", v);
  micEl.setAttribute("aria-label", v ? "Dumaloq video xabar" : "Ovozli xabar");
  micEl.title = v ? "Dumaloq video: bosib turing — yozish, qo'yib yuboring — yuborish. Bir marta bosing — ovozga qaytadi"
                  : "Ovozli xabar: bosib turing — yozish, qo'yib yuboring — yuborish. Bir marta bosing — videoga o'tadi";
}
function toggleRecMode() {
  S.recMode = S.recMode === "video" ? "voice" : "video";
  try { localStorage.setItem("tc_recmode", S.recMode); } catch (_) {}
  applyRecMode(); vibrate(10);
  toast(S.recMode === "video" ? "📹 Dumaloq video — yozish uchun tugmani bosib turing" : "🎤 Ovozli xabar — yozish uchun tugmani bosib turing", "info");
}
applyRecMode();

function resetDragUi() { $("recLock").style.transform = ""; $("recbar").style.transform = ""; $("composer").classList.remove("rec-near-cancel", "rec-near-lock"); }
function showVnUi(on, hint) {                                          // jonli dumaloq ko'rinish: xabarlar maydoni ustida
  const ov = $("vnov");
  if (!on) { ov.classList.add("hidden"); ov.setAttribute("aria-hidden", "true"); return; }
  const r = $("msgs").getBoundingClientRect();
  Object.assign(ov.style, {left: r.left + "px", top: r.top + "px", width: r.width + "px", height: r.height + "px"});
  ov.style.setProperty("--vnd", Math.round(Math.max(140, Math.min(340, r.width * 0.8, r.height - 96))) + "px");
  $("vnHint").textContent = hint || "";
  ov.classList.remove("hidden"); ov.setAttribute("aria-hidden", "false");
}
function setRecUi(mode) {                                              // "off" | "hold" (bosib turilgan) | "lock" (qulflangan) | "busy"
  const c = $("composer"), vid = S.recKind === "video", on = mode !== "off";
  c.classList.toggle("recording", on); c.classList.toggle("rec-hold", mode === "hold");
  c.classList.toggle("rec-lock", mode === "lock" || mode === "busy"); c.classList.toggle("rec-busy", mode === "busy");
  c.classList.toggle("rec-video", on && vid);
  micEl.classList.toggle("on", mode === "hold" || mode === "lock"); micEl.disabled = mode === "busy"; $("recCancel").disabled = mode === "busy";
  micEl.setAttribute("aria-label", mode === "lock" ? "Yuborish" : mode === "off" ? (S.recMode === "video" ? "Dumaloq video xabar" : "Ovozli xabar") : "Yozilmoqda");
  $("recLbl").textContent = mode === "hold" ? "‹ Bekor qilish uchun chapga suring" : mode === "busy" ? (vid ? "Video tayyorlanmoqda…" : "Ovoz tayyorlanmoqda…")
    : mode === "lock" ? (vid ? "Video shifrlanib yuboriladi" : "Ovoz o'zgartirilib shifrlanadi") : "";
  if (mode !== "hold") resetDragUi();
  if (mode === "off") { $("recTime").textContent = "0:00"; $("vnProg").setAttribute("stroke-dashoffset", "301.6"); }
  showVnUi(vid && (mode === "hold" || mode === "lock"), mode === "hold" ? "↑ qulflash   ← bekor qilish" : mode === "lock" && S.rec && S.rec.canFlip ? "Doirani bosing — old/orqa kamera" : "");
}
function cancelRecording() {
  if (S.starting) S.startAbort = true;                                 // kamera/mikrofon hali ochilmoqda: ochilgach bekor qilinadi
  if (!S.rec || S.recBusy) return;
  const r = S.rec; S.rec = null; clearInterval(S.recTimer);
  Promise.resolve(r.cancel()).catch(() => {}); setRecUi("off");
}
function tickRec() {
  const r = S.rec; if (!r) return;
  const t = r.elapsed(); $("recTime").textContent = fmtDur(t);
  if (S.recKind === "video") $("vnProg").setAttribute("stroke-dashoffset", String(301.6 * (1 - Math.min(1, t / VNote.MAX_SEC))));
}
async function startRecording(kind) {                                  // true: yozuv boshlandi (S.rec o'rnatildi; ko'rinishni chaqiruvchi o'rnatadi)
  if (S.rec || S.recBusy || S.sending || S.starting || !S.active) return false;
  if (S.editing || S.pendingImg || inp.value.trim()) return false;
  if (S.active.kind === "group" && S.chat.locked && !amAdmin()) { toast("Umumiy chat qulflangan", "error"); return false; }
  if (S.active.kind === "dm" && U(S.active.uid).deleted) { toast("Bu akkaunt o'chirilgan. Xabar yuborib bo'lmaydi", "error"); return false; }
  const at = S.active, video = kind === "video"; let rec = null;
  S.starting = true; S.startAbort = false; S.recKind = kind;
  if (video) { $("vnov").classList.add("front"); $("vnov").classList.remove("can-flip"); showVnUi(true, "Kamera ochilmoqda…"); }
  try {
    const cb = {
      onLimit: () => { toast(video ? "Video 1 daqiqaga yetdi, yuborilmoqda" : "Yozuv " + Math.round(Voice.MAX_SEC / 60) + " daqiqaga yetdi, yuborilmoqda", "warn"); finishRecording(); },
      onLost: () => { if (rec && S.rec === rec) { cancelRecording(); toast(video ? "Kamera yoki mikrofon uzildi, yozuv bekor qilindi" : "Mikrofon uzildi, yozuv bekor qilindi", "error"); } },
    };
    rec = video ? await VNote.record(Object.assign({facing: S.vfacing, preview: $("vnPrev")}, cb)) : await Voice.record(cb);
    if (S.startAbort || S.active !== at) { Promise.resolve(rec.cancel()).catch(() => {}); rec = null; showVnUi(false); return false; }   // ruxsat so'ralayotganda bekor qilindi / chat almashtirildi
    S.rec = rec;
    if (video) { $("vnov").classList.toggle("front", rec.facing() === "user"); $("vnov").classList.toggle("can-flip", !!rec.canFlip); }
    S.recTimer = setInterval(tickRec, video ? 100 : 250);
    vibrate(20);
    return true;
  } catch (err) { showVnUi(false); toast(err.message || (video ? "Kamerani ochib bo'lmadi" : "Mikrofonni ochib bo'lmadi"), "error"); return false; }
  finally { S.starting = false; }
}
async function flipCamera() {                                          // yozuv to'xtamasdan old <-> orqa kamera
  const r = S.rec;
  if (!r || S.recKind !== "video" || S.recBusy || S.flipping || !r.canFlip) return;
  S.flipping = true; const st = $("vnStage"); st.classList.add("flipping");
  try {
    const ok = await r.flip();
    if (S.rec !== r) return;
    $("vnov").classList.toggle("front", r.facing() === "user"); S.vfacing = r.facing() === "environment" ? "environment" : "user";
    if (!ok) toast("Kamerani almashtirib bo'lmadi", "warn");
  } finally { st.classList.remove("flipping"); S.flipping = false; }
}
$("vnStage").addEventListener("click", flipCamera);                    // 🔄 tugma ham shu yerga ko'tariladi

async function sendEncryptedFile(ctx, target, e, f, failText) {        // fayl allaqachon shifrlangan (e), xabar konverti ham shifrlanadi
  const r = await SC.fetch("/api/e2ee/blob", {method: "POST", headers: {Authorization: "Bearer " + S.token, "Content-Type": "application/octet-stream"}, body: e.blob});
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(typeof j.detail === "string" ? j.detail : failText);
  const payload = {t: "", f}; if (S.replying) payload.r = S.replying;
  const msg = {type: "send", e2e: await sealFor(ctx, payload), blob: j.blob};
  withTarget(msg, target);
  if (!wsSend(msg)) throw new Error("Ulanish yo'q");
  cancelReply();
}
async function sendVoice(wav, dur) {
  const ctx = await keyForActive(), target = S.active;
  const e = await E2E.encryptFile(new Uint8Array(await wav.arrayBuffer()));
  await sendEncryptedFile(ctx, target, e, {name: "ovozli-xabar.wav", mime: "audio/wav", size: wav.size, img: false, k: e.key, vo: 1, d: Math.round(dur * 10) / 10}, "Ovoz yuklanmadi");
}
async function sendVideoNote(out, wav, dur) {                          // paket: [ovozsiz video] + [o'zgartirilgan ovoz] -> BITTA E2EE fayl
  const ctx = await keyForActive(), target = S.active;
  const packed = VNote.pack(new Uint8Array(await out.video.arrayBuffer()), wav ? new Uint8Array(await wav.arrayBuffer()) : null);
  const e = await E2E.encryptFile(packed);
  const f = {name: "video-xabar.vn", mime: out.mime, size: packed.length, img: false, k: e.key, rv: 1, d: Math.round(dur * 10) / 10};
  if (out.thumb && THUMB_RE.test(out.thumb)) f.th = out.thumb;
  $("recLbl").textContent = "Shifrlanib yuborilmoqda…";
  await sendEncryptedFile(ctx, target, e, f, "Video yuklanmadi");
}
async function finishRecording() {
  const rec = S.rec; if (!rec || S.recBusy) return;
  const kind = S.recKind;
  S.recBusy = true; S.sending = true; clearInterval(S.recTimer); setRecUi("busy");
  const at = S.active;
  try {
    if (kind === "video") {
      const out = await rec.stop();
      if (!out) throw new Error("Yozuv olinmadi");
      if (out.duration < VNote.MIN_SEC) { toast("Video juda qisqa — yuborilmadi", "warn"); return; }
      let wav = null, dur = out.duration;
      if (out.audio) {
        const d = await Voice.disguise(out.audio);                     // asl ovoz shu yerda o'zgaradi
        out.audio = null;
        if (!d) { toast("Video juda qisqa — yuborilmadi", "warn"); return; }
        wav = d.wav; dur = d.duration;
      }
      if (S.active !== at) { toast("Chat almashtirildi — video xabar yuborilmadi", "warn"); return; }
      await sendVideoNote(out, wav, dur);
    } else {
      const raw = await rec.stop();
      if (!raw) throw new Error("Yozuv olinmadi");
      const out = await Voice.disguise(raw);                           // asl ovoz shu yerda o'zgaradi
      if (!out) { toast("Ovoz juda qisqa — yuborilmadi", "warn"); return; }
      if (S.active !== at) { toast("Chat almashtirildi — ovozli xabar yuborilmadi", "warn"); return; }
      await sendVoice(out.wav, out.duration);
    }
  } catch (err) { toast(err.message || (kind === "video" ? "Video xabar yuborilmadi" : "Ovozli xabar yuborilmadi"), "error"); }
  finally { S.rec = null; S.recBusy = false; S.sending = false; setRecUi("off"); syncSend(); }
}

/* --- bosish ishorasi (pointer): tap = rejim, bosib turish = yozish, surish = bekor/qulf --- */
let G = null;
const noClick = () => { S.noClickUntil = Date.now() + 350; };          // bosib turgandan keyin brauzer yuboradigan "click" e'tiborsiz qoladi
async function beginHold(g) {
  if (G !== g || g.aborted) return;
  g.started = true;
  const t0 = performance.now();
  const ok = await startRecording(S.recMode);
  if (!ok) { if (G === g) G = null; return; }
  if (g.released || g.cancelled) {                                     // tugma kamera/mikrofon ruxsati so'ralayotganda qo'yib yuborilgan
    cancelRecording();
    if (performance.now() - t0 > 700) toast("Ruxsat berildi. Endi tugmani bosib turing", "ok");
    return;
  }
  setRecUi(g.locked || performance.now() - t0 > 700 ? "lock" : "hold");   // ruxsat oynasi chiqqan bo'lsa barmoq holati ishonchsiz: qo'lsiz (qulflangan) rejim
}
function endPress(e, cancel) {
  const g = G; if (!g || e.pointerId !== g.id) return;
  G = null; clearTimeout(g.timer); g.timer = 0;
  try { micEl.releasePointerCapture(g.id); } catch (_) {}
  noClick();
  if (!g.started) { if (!g.aborted && !cancel) toggleRecMode(); return; }
  g.released = true;
  if (g.cancelled || g.locked) return;
  if (S.rec && !S.recBusy) {
    if (cancel) cancelRecording();
    else if (S.rec.elapsed() < 0.5) { cancelRecording(); toast("Yozish uchun tugmani bosib turing", "warn"); }
    else finishRecording();
  }
}
micEl.addEventListener("pointerdown", e => {
  if (G && !S.starting && !S.rec) G = null;                            // yo'qolgan eski ishora (pointerup kelmagan) — yangisi boshlanadi
  if ((e.pointerType === "mouse" && e.button !== 0) || G || S.recBusy || S.rec || S.starting) return;   // qulflangan yozuvda tugma "yuborish" (click)
  const g = G = {id: e.pointerId, x0: e.clientX, y0: e.clientY, started: false, released: false, locked: false, cancelled: false, aborted: false, timer: 0};
  try { micEl.setPointerCapture(e.pointerId); } catch (_) {}
  g.timer = setTimeout(() => { g.timer = 0; beginHold(g); }, HOLD_MS);
});
micEl.addEventListener("pointermove", e => {
  const g = G; if (!g || e.pointerId !== g.id) return;
  const dx = e.clientX - g.x0, dy = e.clientY - g.y0;
  if (!g.started) { if (g.timer && Math.hypot(dx, dy) > 16) { clearTimeout(g.timer); g.timer = 0; g.aborted = true; } return; }
  if (!S.rec || S.recBusy || g.locked || g.cancelled) return;
  const c = $("composer");
  c.classList.toggle("rec-near-cancel", dx < -CANCEL_DX * 0.6); c.classList.toggle("rec-near-lock", dy < -LOCK_DY * 0.6);
  $("recbar").style.transform = "translateX(" + Math.max(-110, Math.min(0, dx * 0.7)) + "px)";
  $("recLock").style.transform = "translateY(" + Math.max(-30, Math.min(0, dy * 0.45)) + "px)";
  if (dx < -CANCEL_DX) { g.cancelled = true; vibrate(15); cancelRecording(); }
  else if (dy < -LOCK_DY) { g.locked = true; vibrate(20); setRecUi("lock"); }
});
micEl.addEventListener("pointerup", e => endPress(e, false));
micEl.addEventListener("pointercancel", e => endPress(e, true));
micEl.addEventListener("lostpointercapture", e => endPress(e, true));
micEl.addEventListener("contextmenu", e => e.preventDefault());        // telefonda uzoq bosganda menyu chiqmasin
micEl.addEventListener("click", e => {
  if (Date.now() < S.noClickUntil) return;
  if (S.rec) { if (!S.recBusy) finishRecording(); return; }            // qulflangan yozuv: tugma = yuborish
  if (e.detail === 0 && !S.starting) startRecording(S.recMode).then(ok => { if (ok) setRecUi("lock"); });   // klaviatura: qulflangan yozuv boshlanadi
});
micEl.addEventListener("keydown", e => { if (!S.rec && (e.key === "ArrowLeft" || e.key === "ArrowRight")) { e.preventDefault(); toggleRecMode(); } });   // klaviatura: rejim almashtirish
$("recCancel").addEventListener("click", cancelRecording);
document.addEventListener("keydown", e => { if (e.key === "Escape" && S.rec && !S.recBusy) { e.preventDefault(); e.stopPropagation(); cancelRecording(); } }, true);
document.addEventListener("visibilitychange", () => { if (document.hidden && S.rec && !S.recBusy) { cancelRecording(); toast("Ilovadan chiqilgani uchun yozuv bekor qilindi", "warn"); } });
addEventListener("pagehide", cancelRecording);
document.addEventListener("visibilitychange", () => {
  if (!document.hidden && S.active && S.active.kind === "dm") {
    const dm = dmOf(S.active.uid);
    if (dm.unread) { dm.unread = 0; wsSend({type: "read", with: S.active.uid}); renderList(); }
  }
});


/* ---------------- Telegram uslubidagi dialoglar ---------------- */
function askDialog({title, text, okText = "OK", cancelText = "Bekor qilish", danger = false, input = null, alertOnly = false}) {
  return new Promise(resolve => {
    const root = $("dlg"), prevFocus = document.activeElement;
    let field = null;
    const done = v => {
      if (done.d) return; done.d = true; S.dlgCancel = null; navPop("dlg");
      root.classList.add("hidden"); root.setAttribute("aria-hidden", "true"); root.textContent = "";
      document.removeEventListener("keydown", onKey, true);
      if (prevFocus && prevFocus.focus) try { prevFocus.focus(); } catch (_) {}
      resolve(v);
    };
    const ok = () => done(input ? field.value : true);
    const cancel = () => done(input ? null : false);
    const onKey = e => {
      if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); cancel(); }
      else if (e.key === "Enter" && !(e.target && e.target.tagName === "BUTTON")) { e.preventDefault(); e.stopPropagation(); ok(); }
    };
    const card = h("div", {class: "dlg-card", role: alertOnly ? "alertdialog" : "dialog", "aria-modal": "true"});
    if (title) card.append(h("h3", {class: "dlg-t", text: title}));
    if (text) card.append(h("p", {class: "dlg-m", text}));
    if (input) { field = h("input", {class: "dlg-in", type: input.type || "text", autocomplete: "off", spellcheck: "false", placeholder: input.placeholder || ""}); field.value = input.value || ""; card.append(field); }
    const btns = h("div", {class: "dlg-b"});
    if (!alertOnly) btns.append(h("button", {class: "dlg-btn", type: "button", text: cancelText, onclick: cancel}));
    const okBtn = h("button", {class: "dlg-btn" + (danger ? " danger" : ""), type: "button", text: okText, onclick: ok});
    btns.append(okBtn); card.append(btns);
    root.textContent = ""; root.append(card);
    root.onmousedown = root.onclick = e => { if (e.target === root) cancel(); };
    root.classList.remove("hidden"); root.setAttribute("aria-hidden", "false");
    S.dlgCancel = cancel; navPush("dlg");
    document.addEventListener("keydown", onKey, true);
    setTimeout(() => { (field || okBtn).focus(); if (field) field.select(); }, 30);
  });
}
const confirmDlg = (text, o = {}) => askDialog({title: o.title, text, okText: o.okText || "OK", danger: !!o.danger});
const promptDlg = (title, text, value = "", o = {}) => askDialog({title, text, input: {value, placeholder: o.placeholder, type: o.type}, okText: o.okText || "OK", danger: !!o.danger});

/* Brauzerning o'z o'ng-tugma menyusini yopish (matn kiritish maydonlaridan tashqari) */
document.addEventListener("contextmenu", e => {
  if (e.target.closest && e.target.closest("input, textarea")) return;   // nusxalash/qo'yish uchun qoladi
  e.preventDefault();
  if (!e.target.closest(".bubble")) closeCtx();
});

/* ---------------- modal ---------------- */
function showModal(node) {
  const sheet = $("sheet"), top = sheet.scrollTop;
  sheet.textContent = ""; sheet.append(node);
  $("modal").classList.remove("hidden");
  sheet.scrollTop = top;
}
function openModal(build, live, wide, fit) { if ($("modal").classList.contains("hidden")) navPush("modal"); S.modal = {build, live: !!live}; $("sheet").classList.toggle("wide", !!wide); $("sheet").classList.toggle("fit", !!fit); showModal(build()); }
function closeModal() { const was = !$("modal").classList.contains("hidden"); S.modal = null; $("modal").classList.add("hidden"); $("sheet").classList.remove("wide", "fit"); $("sheet").textContent = ""; if (was) navPop("modal"); }
function refreshModal() { if (S.modal && S.modal.live) showModal(S.modal.build()); }
$("modal").addEventListener("mousedown", e => { if (e.target === $("modal")) closeModal(); });
$("modal").addEventListener("click", e => { if (e.target === $("modal")) closeModal(); });
function setPageZoom(on) {                           // oynalar zoom bo'lmaydi; faqat rasm ko'rish (lightbox) oynasida chimchilab kattalashtirish ishlaydi
  const v = document.querySelector('meta[name="viewport"]'); if (!v) return;
  v.setAttribute("content", "width=device-width, initial-scale=1, viewport-fit=cover, interactive-widget=resizes-content" + (on ? "" : ", maximum-scale=1, user-scalable=no"));
}
["gesturestart", "gesturechange", "gestureend"].forEach(t => document.addEventListener(t, e => { if (!e.target.closest || !e.target.closest("#lightbox")) e.preventDefault(); }, {passive: false}));   // iOS Safari: chimchilab zoom
document.addEventListener("dblclick", e => { if (e.target.closest && e.target.closest(".modal,.dlg,.sheet,.ctx")) e.preventDefault(); });
function openLightbox(url) { setPageZoom(true); $("lbImg").src = url; $("lightbox").classList.remove("hidden"); navPush("lb"); }
function closeLightbox() { setPageZoom(false); const was = !$("lightbox").classList.contains("hidden"); $("lightbox").classList.add("hidden"); $("lbImg").removeAttribute("src"); if (was) navPop("lb"); }
$("lightbox").addEventListener("click", closeLightbox);
document.addEventListener("keydown", e => {
  if (e.key !== "Escape") return;
  if (!$("lightbox").classList.contains("hidden")) closeLightbox();
  else if (S.sel && !S.modal && $("ctx").classList.contains("hidden")) exitSelect();
  else if (!$("ctx").classList.contains("hidden")) closeCtx();
  else if (S.modal) closeModal();
});

function sheetHead(title, onBack) {
  return h("div", {class: "sh-head"},
    onBack ? h("button", {class: "icon-btn", type: "button", onclick: onBack, "aria-label": "Orqaga"}, icon("back")) : null,
    h("span", {text: title}),
    h("button", {class: "icon-btn", type: "button", onclick: closeModal, "aria-label": "Yopish"}, icon("close")));
}

/* ---------- guruh ma'lumoti ---------- */
function openGroupInfo() {
  let filter = "";
  const build = () => {
    const wrap = h("div", {});
    const total = S.members.length || 1;
    wrap.append(
      h("div", {class: "sh-head"}, h("span", {text: "Guruh ma'lumoti"}),
        h("button", {class: "icon-btn", type: "button", onclick: closeModal, "aria-label": "Yopish"}, icon("close"))),
      h("div", {class: "ginfo"}, groupAvatar("l"), h("h3", {text: "Umumiy chat"}),
        h("p", {text: total + " a'zo, " + onlineCount() + " onlayn"})));
    const search = h("input", {type: "text", class: "gsearch", placeholder: "A'zolarni qidirish", autocomplete: "off"});
    search.value = filter;
    const list = h("div", {class: "mlist"});
    const fill = () => {
      list.textContent = "";
      const q = filter.trim().toLowerCase();
      S.members.map(m => U(m.id)).filter(u => !q || u.nickname.toLowerCase().includes(q) || u.username.toLowerCase().includes(q))
        .sort((a, b) => (isOnline(b.id) - isOnline(a.id)) || 0)
        .sort((a, b) => (isStaff(b) - isStaff(a)))
        .forEach(u => list.append(itemEl({
          av: avatar(u, "m", true), title: [nameEl(u), u.id === S.me.id ? h("span", {class: "i-time", text: "(siz)"}) : null],
          sub: (isStaff(u) ? roleLabel(u.role) + " • " : "") + statusText(u), subOn: isOnline(u.id),
          onclick: () => openProfile(u.id, openGroupInfo),
        })));
      if (!list.children.length) list.append(h("div", {class: "none", text: "Hech narsa topilmadi"}));
    };
    search.addEventListener("input", () => { filter = search.value; fill(); });
    fill();
    wrap.append(search, list);
    if (amAdmin()) wrap.append(h("div", {class: "g-clear"}, h("button", {class: "btn danger sm", type: "button", onclick: () => { closeModal(); clearGroupChat(); }}, "Chatni tozalash")));
    return wrap;
  };
  openModal(build, false, false, true);
}

/* ---------- profil ---------- */
function openProfile(uid, onBack) {
  if (!S.users.has(uid)) { loadMembers(); }
  openModal(() => profileView(uid, onBack), true, false, true);
}
function infoRow(label, value, wide) { return h("div", {class: "info-r" + (wide ? " wide" : "")}, h("small", {text: label}), h("div", {text: value})); }
function profileView(uid, onBack) {
  const u = U(uid), me = u.id === S.me.id;
  const wrap = h("div", {});
  if (u.deleted) {
    const bn = h("div", {class: "pbanner gone"});
    if (onBack) bn.append(h("button", {class: "pbtn l", type: "button", onclick: onBack, "aria-label": "Orqaga"}, icon("back")));
    bn.append(h("button", {class: "pbtn r", type: "button", onclick: closeModal, "aria-label": "Yopish"}, icon("close")));
    wrap.append(bn, h("div", {class: "pbody"}, avatar(u, "l"),
      h("div", {class: "pname"}, nameEl(u, {big: true})),
      h("div", {class: "pstat", text: "Bu akkaunt o'chirilgan"}),
      h("div", {class: "gone-note", text: "Yozgan xabarlari chatda qoladi. Unga xabar yuborib bo'lmaydi."})));
    return wrap;
  }
  const banner = tint(h("div", {class: "pbanner" + (isStaff(u) ? " prem " + u.role : "")}), u);
  if (onBack) banner.append(h("button", {class: "pbtn l", type: "button", onclick: onBack, "aria-label": "Orqaga"}, icon("back")));
  banner.append(h("button", {class: "pbtn r", type: "button", onclick: closeModal, "aria-label": "Yopish"}, icon("close")));
  const body = h("div", {class: "pbody"});
  body.append(avatar(u, "l"),
    h("div", {class: "pname"}, nameEl(u, {big: true})),
    h("div", {class: "pstat" + (isOnline(u.id) ? " on" : ""), text: statusText(u)}));
  if (isStaff(u)) body.append(tint(h("div", {class: "chip prem " + u.role}, hasEmoji(u) ? badge(u) : (u.badge === "none" ? null : icon(u.role === "owner" ? "shield" : "check", "ic vb")), roleLabel(u.role)), u));
  else if (hasEmoji(u)) body.append(h("div", {class: "chip"}, badge(u), "Maxsus nishon"));
  else if (isVerified(u)) body.append(h("div", {class: "chip"}, badge(u), "Tasdiqlangan foydalanuvchi"));
  if (u.new && !isStaff(u)) body.append(h("div", {class: "chip warn", text: "⚠ Yangi foydalanuvchi — hali ishonish qiyin"}));
  const info = h("div", {class: "info"});
  if (u.bio) info.append(infoRow("Bio", u.bio, true));
  info.append(infoRow("Username", "@" + u.username));
  if (u.joined) info.append(infoRow("Qo'shilgan", new Date(u.joined * 1000).getDate() + "-" + MONTHS[new Date(u.joined * 1000).getMonth()] + " " + new Date(u.joined * 1000).getFullYear()));
  body.append(info);
  const acts = h("div", {class: "acts"});
  if (me) acts.append(h("button", {class: "btn", type: "button", onclick: openSettings}, "Profilni tahrirlash"));
  else acts.append(h("button", {class: "btn", type: "button", onclick: () => { closeModal(); openChat({kind: "dm", uid: u.id}); }}, "Xabar yozish"));
  body.append(acts);
  if (!me && amAdmin() && u.role !== "owner" && (u.role !== "admin" || S.me.role === "owner")) body.append(modPanel(u));
  wrap.append(banner, body);
  return wrap;
}
function modPanel(u) {
  const cmd = text => wsSend({type: "cmd", text});
  const panel = h("div", {class: "mod"}, h("h4", {}, icon("shield"), "Moderatsiya"));
  const flags = h("div", {class: "mod-r"});
  if (u.banned) flags.append(h("span", {class: "flag", text: "Ban qilingan"}));
  if (u.muted) flags.append(h("span", {class: "flag w", text: "Mute qilingan"}));
  if (u.warns) flags.append(h("span", {class: "warnflag", text: "Ogohlantirish: " + u.warns + "/3"}));
  if (flags.children.length) panel.append(flags);
  const dur = h("select", {}, h("option", {value: "10", text: "10 daqiqa"}), h("option", {value: "60", text: "1 soat"}),
    h("option", {value: "1440", text: "1 kun"}), h("option", {value: "perm", text: "Doimiy"}));
  panel.append(h("div", {class: "mod-r"}, dur,
    h("button", {class: "btn ghost sm", type: "button", onclick: () => cmd("/mute " + u.username + " " + dur.value)}, "Mute"),
    u.muted ? h("button", {class: "btn ghost sm", type: "button", onclick: () => cmd("/unmute " + u.username)}, "Unmute") : null));
  panel.append(h("div", {class: "mod-r"},
    h("button", {class: "btn ghost sm", type: "button", onclick: async () => {
      const why = await promptDlg("Ogohlantirish", "@" + u.username + " ga ogohlantirish (3 tadan keyin 1 soat mute). Sabab:", "", {okText: "Ogohlantirish"});
      if (why !== null) cmd("/warn " + u.username + " " + why);
    }}, "Ogohlantirish"),
    u.warns ? h("button", {class: "btn ghost sm", type: "button", onclick: () => cmd("/unwarn " + u.username)}, "Olib tashlash") : null,
    h("button", {class: "btn ghost sm", type: "button", onclick: async () => {
      if (await confirmDlg("@" + u.username + " ning umumiy chatdagi oxirgi xabarlari (va fayllari) o'chiriladi.", {title: "Xabarlarini tozalash", okText: "Tozalash", danger: true})) cmd("/purge " + u.username);
    }}, "Xabarlarini tozalash"),
    h("button", {class: "btn ghost sm", type: "button", onclick: () => openBadgePicker(u)}, "Nishon / galochka")));
  panel.append(h("div", {class: "mod-r"},
    u.banned
      ? h("button", {class: "btn ghost sm", type: "button", onclick: () => cmd("/unban " + u.username)}, "Bandan chiqarish")
      : h("button", {class: "btn danger sm", type: "button", onclick: async () => { if (await confirmDlg("@" + u.username + " ni ban qilasizmi?", {title: "Ban qilish", okText: "Ban qilish", danger: true})) cmd("/ban " + u.username); }}, "Ban qilish")));
  if (S.me.role === "owner") {
    panel.append(h("div", {class: "mod-r"}, u.role === "admin"
      ? h("button", {class: "btn ghost sm", type: "button", onclick: async () => { if (await confirmDlg("@" + u.username + " adminlikdan olinsinmi?", {title: "Adminlikdan olish", okText: "Olish", danger: true})) cmd("/rmadmin " + u.username); }}, "Adminlikdan olish")
      : h("button", {class: "btn ghost sm", type: "button", onclick: async () => { if (await confirmDlg("@" + u.username + " admin qilinsinmi?", {title: "Admin qilish", okText: "Admin qilish"})) cmd("/addadmin " + u.username); }}, "Admin qilish")));
  }
  const rows = panel.querySelectorAll(".mod-r");
  if (S.me.role === "owner" && rows.length >= 2) { const last = rows[rows.length - 1], prev = rows[rows.length - 2]; [...last.children].forEach(c => prev.append(c)); last.remove(); }
  panel.append(h("div", {class: "mod-r"}, h("button", {class: "btn danger sm", type: "button", onclick: async () => {
    if (await confirmDlg("@" + u.username + " akkaunti o'chiriladi va chatdan chiqarib tashlanadi. Yozgan xabarlari \"Deleted account\" nomi bilan qoladi. Buni qaytarib bo'lmaydi.",
      {title: "Akkauntni o'chirish", okText: "O'chirish", danger: true})) { cmd("/remove " + u.username); closeModal(); }
  }}, "Akkauntni o'chirish")));
  return panel;
}



/* ---------- foydalanuvchilar zaxirasi (faqat ega): shifrlash/ochish brauzerda, js/backup.js ---------- */
function ago(ts) {
  if (!ts) return "?";
  const s = Math.max(0, Date.now() / 1000 - ts);
  if (s < 60) return "hozirgina";
  const m = s / 60; if (m < 60) return Math.floor(m) + " daqiqa oldin";
  const hr = m / 60; if (hr < 24) return Math.floor(hr) + " soat oldin";
  const d = hr / 24; if (d < 30) return Math.floor(d) + " kun oldin";
  if (d < 365) return Math.floor(d / 30) + " oy oldin";
  return Math.floor(d / 365) + " yil oldin";
}
async function backupDownload() {
  const p1 = await promptDlg("Zaxira paroli", "Zaxira faylini shifrlash uchun parol-ibora kiriting (kamida 8 belgi). Uni yo'qotsangiz, fayl ochilmaydi va tiklab bo'lmaydi.", "", {type: "password", okText: "Davom etish"});
  if (p1 === null) return;
  if (p1.length < 8) { toast("Parol-ibora kamida 8 belgi bo'lishi kerak", "error"); return; }
  const p2 = await promptDlg("Parol-iborani takrorlang", "Xato yozilmaganini tekshirish uchun yana kiriting:", "", {type: "password", okText: "Yuklab olish"});
  if (p2 === null) return;
  if (p1 !== p2) { toast("Parol-iboralar mos kelmadi", "error"); return; }
  toast("Shifrlanmoqda…");
  try {
    const data = await api("/admin/backup");
    const bytes = await Backup.seal(data, p1), d = new Date();
    const name = "anonim-chat-users-" + d.getFullYear() + pad2(d.getMonth() + 1) + pad2(d.getDate()) + ".acdb";
    const url = URL.createObjectURL(new Blob([bytes], {type: "application/octet-stream"}));
    const a = h("a", {href: url, download: name}); document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
    toast(data.users.length + " ta akkaunt shifrlangan zaxiraga yozildi" + (data.avatars_skipped ? " (" + data.avatars_skipped + " ta katta rasm kiritilmadi)" : ""), "ok");
  } catch (err) { toast(err.message, "error"); }
}
function backupRestore(done) {
  const f = h("input", {type: "file", accept: ".acdb", class: "offscreen"});
  f.addEventListener("cancel", () => f.remove());
  f.addEventListener("change", async () => {
    const file = f.files[0]; f.remove();
    if (!file) return;
    try {
      if (file.size > 40 * 1048576) throw new Error("Fayl juda katta");
      const bytes = new Uint8Array(await file.arrayBuffer());
      const pass = await promptDlg("Zaxira paroli", "Zaxirani ochish uchun parol-iborani kiriting:", "", {type: "password", okText: "Ochish"});
      if (pass === null) return;
      toast("Ochilmoqda…");
      const data = await Backup.open(bytes, pass);
      const list = Array.isArray(data.users) ? data.users : [], adm = list.filter(u => u && u.role === "admin").length;
      if (!await confirmDlg(list.length + " ta akkaunt topildi (" + adm + " ta admin). Mavjud username'larga tegilmaydi — faqat yo'qlari tiklanadi. Xabarlar tiklanmaydi. Davom etilsinmi?", {title: "Zaxiradan tiklash", okText: "Tiklash"})) return;
      const j = await api("/admin/backup/restore", {method: "POST", body: {data}});
      toast(j.created + " ta akkaunt tiklandi" + (j.skipped ? ", " + j.skipped + " tasi allaqachon bor" : "") + (j.invalid ? ", " + j.invalid + " tasi yaroqsiz" : ""), j.created ? "ok" : "warn");
      loadMembers(); if (done) done();
    } catch (err) { toast(err.message, "error"); }
  });
  document.body.append(f); f.click();
}

/* ---------- admin paneli: IP lar, harakatlar logi, bloklar ---------- */
const fmtDT = ts => { const d = new Date(ts * 1000); return pad2(d.getDate()) + "." + pad2(d.getMonth() + 1) + "." + String(d.getFullYear()).slice(2) + " " + hhmm(ts) + ":" + pad2(d.getSeconds()); };
function admErr(box, err) { box.textContent = ""; box.append(h("div", {class: "adm-empty", text: err.message})); }

function openAdmin(initial, preset) {
  preset = preset || {};
  openModal(() => {
    const st = {tab: initial, q: preset.q || "", ip: preset.ip || "", user: preset.user || "", action: ""};
    const tabs = h("div", {class: "adm-tabs"}), body = h("div", {class: "adm-body"});
    const defs = [["ips", "IP lar"], ["users", "Foydalanuvchilar"], ["log", "Harakatlar"], ["msgs", "Xabarlar"], ["blocks", "Bloklanganlar"], ["media", "Media"], ["reports", "Shikoyatlar"], ["mod", "Moderatsiya"], ["emoji", "Emoji"]];
    const loaders = {ips: loadIps, users: loadUsers, log: loadLog, msgs: loadMsgs, blocks: loadBlocks, media: loadMedia, reports: loadReports, mod: loadMod, emoji: () => emojiManager(body, () => st.tab === "emoji")};
    const paintTabs = () => {
      tabs.textContent = "";
      defs.forEach(([k, t]) => tabs.append(h("button", {type: "button", class: st.tab === k ? "on" : "", text: t, onclick: () => { st.tab = k; paintTabs(); load(); }})));
    };
    const load = () => { body.textContent = ""; loaders[st.tab](); };

    /* --- Foydalanuvchilar: ro'yxat, nishon (emoji/galochka) va shifrlangan zaxira --- */
    function loadUsers() {
      const owner = S.me.role === "owner";
      const filter = h("input", {type: "text", class: "fld", placeholder: "Nickname yoki @username bo'yicha qidirish", autocomplete: "off"});
      const list = h("div", {}), box = h("div", {class: "bk-box"});
      let all = [];
      const roleName = r => r === "owner" ? "Ega" : r === "admin" ? "Admin" : "Oddiy";
      const paint = () => {
        const q = filter.value.trim().toLowerCase().replace(/^@/, "");
        list.textContent = "";
        const rows = all.filter(u => !q || u.nickname.toLowerCase().includes(q) || u.username.toLowerCase().includes(q));
        if (!rows.length) list.append(h("div", {class: "adm-empty", text: "Hech narsa topilmadi"}));
        rows.forEach(u => {
          const can = u.role !== "owner" && (u.role !== "admin" || owner);
          list.append(h("div", {class: "urow"}, avatar(u, "m", true),
            h("div", {class: "utx"}, nameEl(u),
              h("div", {class: "usub"}, h("span", {class: "ubadge " + u.role, text: roleName(u.role)}), "@" + u.username + " • " + ago(u.joined) + " qo'shilgan" + (u.banned ? " • ban" : ""))),
            can ? h("button", {class: "btn ghost sm", type: "button", text: "Nishon", onclick: () => openBadgePicker(u, () => openAdmin("users"))}) : h("span")));
        });
      };
      const fill = async () => {
        list.textContent = ""; list.append(h("div", {class: "adm-empty", text: "Yuklanmoqda…"}));
        try { const j = await api("/members"); j.members.forEach(upsertUser); all = j.members.map(x => U(x.id)); box.querySelector(".bk-n") && (box.querySelector(".bk-n").textContent = all.length + " ta akkaunt"); paint(); }
        catch (err) { admErr(list, err); }
      };
      if (owner) box.append(h("div", {}, h("b", {text: "Shifrlangan zaxira (.acdb). "}), "Username, nickname, rol, profil rasmi, qo'shilgan vaqt va kirish ma'lumoti sizning parol-iborangiz bilan BRAUZERDA shifrlanadi; parol-ibora serverga yuborilmaydi. Uni yo'qotsangiz fayl ochilmaydi. Xabarlar zaxiraga kirmaydi. ", h("span", {class: "bk-n"})),
        h("div", {class: "ep-row"}, h("button", {class: "btn sm", type: "button", text: "⬇ Bazani yuklab olish", onclick: backupDownload}),
          h("button", {class: "btn ghost sm", type: "button", text: "⬆ Zaxiradan tiklash", onclick: () => backupRestore(fill)})));
      else box.append("Bazani yuklab olish va zaxiradan tiklash faqat platforma egasiga ochiq: zaxira faylida kirish ma'lumotlari bor, ularni oddiy adminga berish E2EE'ni buzardi. Siz foydalanuvchilarga nishon/galochka bera olasiz.");
      filter.addEventListener("input", paint);
      body.append(box, h("div", {class: "adm-filters"}, filter), list);
      fill();
    }

    /* --- IP lar: har bir IP dan qaysi profil necha marta kirgan --- */
    function loadIps() {
      const filter = h("input", {type: "text", class: "fld", placeholder: "IP yoki @username bo'yicha qidirish", autocomplete: "off"});
      filter.value = st.q;
      const list = h("div", {});
      let timer = null;
      const fill = async () => {
        list.textContent = ""; list.append(h("div", {class: "adm-empty", text: "Yuklanmoqda…"}));
        try {
          const j = await api("/admin/ips?q=" + encodeURIComponent(st.q));
          list.textContent = "";
          if (!j.ips.length) list.append(h("div", {class: "adm-empty", text: "Hech narsa topilmadi"}));
          j.ips.forEach(e => list.append(ipCard(e, fill)));
        } catch (err) { admErr(list, err); }
      };
      filter.addEventListener("input", () => { clearTimeout(timer); timer = setTimeout(() => { st.q = filter.value.trim(); fill(); }, 300); });
      body.append(h("div", {class: "adm-filters"}, filter), list);
      fill();
    }
    function ipCard(e, refresh) {
      const head = h("div", {class: "ipc-h"}, h("span", {class: "ip", text: e.ip}), e.blocked ? h("span", {class: "flag b", text: "Bloklangan"}) : null);
      const sum = h("div", {class: "ipc-s", text: e.profiles.length + " ta profil • " + e.logins + " kirish • " + e.sessions + " sessiya • " + e.msgs + " xabar" +
        (e.failed ? " • " + e.failed + " xato urinish" : "") + " • oxirgi: " + fmtDT(e.last_seen)});
      const card = h("div", {class: "ipc" + (e.blocked ? " blk" : "")}, head, sum);
      e.profiles.forEach(p => card.append(h("div", {class: "ipc-p"},
        h("div", {class: "who"}, h("b", {text: "@" + p.username}), p.nickname ? " (" + p.nickname + ")" : "", p.known ? "" : " — ro'yxatdan o'tmagan nom"),
        h("div", {class: "num", text: p.logins + " kirish • " + p.sessions + " sessiya • " + p.msgs + " xabar" + (p.failed ? " • " + p.failed + " xato" : "")}))));
      const acts = h("div", {class: "ipc-a"}, h("button", {class: "btn ghost sm", type: "button", text: "Loglari", onclick: () => openAdmin("log", {ip: e.ip})}));
      if (e.blocked) acts.append(h("button", {class: "btn ghost sm", type: "button", text: "Blokdan ochish", onclick: async () => {
        if (!await confirmDlg(e.ip + " blokdan ochilsinmi?", {title: "Blokdan ochish", okText: "Ochish"})) return;
        try { await api("/admin/unblock", {method: "POST", body: {ip: e.ip}}); toast("Blokdan ochildi", "ok"); refresh(); } catch (err) { toast(err.message, "error"); }
      }}));
      else acts.append(h("button", {class: "btn danger sm", type: "button", text: "Bloklash", onclick: async () => {
        const reason = await promptDlg("IP bloklash", e.ip + " bloklanadi. Sabab (ixtiyoriy):", "spam", {okText: "Bloklash"});
        if (reason === null) return;
        try { const j = await api("/admin/blocks", {method: "POST", body: {ip: e.ip, reason}}); toast("Bloklandi" + (j.kicked ? " (" + j.kicked + " ta ulanish uzildi)" : ""), "ok"); refresh(); }
        catch (err) { toast(err.message, "error"); }
      }}));
      card.append(acts);
      return card;
    }

    /* --- Harakatlar logi: filtrlar bilan --- */
    function loadLog() {
      const ipI = h("input", {type: "text", class: "fld", placeholder: "IP", autocomplete: "off"}); ipI.value = st.ip;
      const userI = h("input", {type: "text", class: "fld", placeholder: "@username", autocomplete: "off"}); userI.value = st.user;
      const sel = h("select", {}, h("option", {value: "", text: "Barcha amallar"}));
      const list = h("div", {}), more = h("button", {class: "btn ghost sm adm-more hidden", type: "button", text: "Yana yuklash"});
      let before = 0, filled = false, timer = null;
      const picked = new Set();
      const delSel = h("button", {class: "btn danger sm", type: "button", text: "Tanlanganlarni o'chirish"});
      const delAll = h("button", {class: "btn ghost sm dangerline", type: "button", text: "Filtrdagi hammasini o'chirish"});
      const updDel = () => { delSel.disabled = !picked.size; delSel.textContent = picked.size ? "Tanlanganlarni o'chirish (" + picked.size + ")" : "Tanlanganlarni o'chirish"; };
      delSel.addEventListener("click", async () => {
        if (!await confirmDlg(picked.size + " ta log yozuvi butunlay o'chiriladi.", {title: "Loglarni o'chirish", okText: "O'chirish", danger: true})) return;
        try { const j = await api("/admin/activity/delete", {method: "POST", body: {ids: [...picked]}}); toast(j.deleted + " ta yozuv o'chirildi", "ok"); picked.clear(); updDel(); page(true); }
        catch (err) { toast(err.message, "error"); }
      });
      delAll.addEventListener("click", async () => {
        const f = ipI.value.trim() || userI.value.trim() || sel.value;
        if (!await confirmDlg(f ? "Joriy filtrga mos BARCHA yozuvlar o'chiriladi." : "Harakatlar logining BUTUN tarixi o'chiriladi.", {title: "Loglarni o'chirish", okText: "Hammasini o'chirish", danger: true})) return;
        try { const j = await api("/admin/activity/delete", {method: "POST", body: {all: true, ip: ipI.value.trim(), user: userI.value.trim(), action: sel.value}}); toast(j.deleted + " ta yozuv o'chirildi", "ok"); picked.clear(); updDel(); page(true); }
        catch (err) { toast(err.message, "error"); }
      });
      const row = it => {
        const bad = ["login_failed", "blocked", "ip_block"].includes(it.action);
        const ipl = it.ip ? h("span", {class: "ipl", text: it.ip, onclick: () => { ipI.value = it.ip; page(true); }}) : null;
        const ck = h("input", {type: "checkbox", class: "ck", "aria-label": "Tanlash"});
        ck.addEventListener("change", () => { if (ck.checked) picked.add(it.id); else picked.delete(it.id); updDel(); });
        return h("div", {class: "lg sel"}, ck, h("div", {class: "t", text: fmtDT(it.ts)},),
          h("div", {class: "w"}, h("span", {class: "a" + (bad ? " bad" : ""), text: it.label}), it.username ? "@" + it.username + " " : "", ipl),
          it.detail ? h("div", {class: "d", text: it.detail}) : null);
      };
      const page = async reset => {
        if (reset) { before = 0; list.textContent = ""; picked.clear(); updDel(); }
        const qs = new URLSearchParams({ip: ipI.value.trim(), user: userI.value.trim(), action: sel.value, limit: "100"});
        if (before) qs.set("before", before);
        try {
          const j = await api("/admin/activity?" + qs.toString());
          if (!filled) { j.actions.forEach(a => sel.append(h("option", {value: a.key, text: a.label}))); filled = true; }
          j.items.forEach(it => list.append(row(it)));
          if (j.items.length) before = j.items[j.items.length - 1].id;
          more.classList.toggle("hidden", j.items.length < 100);
          if (reset && !j.items.length) list.append(h("div", {class: "adm-empty", text: "Yozuv topilmadi"}));
        } catch (err) { admErr(list, err); }
      };
      const again = () => { clearTimeout(timer); timer = setTimeout(() => page(true), 300); };
      ipI.addEventListener("input", again); userI.addEventListener("input", again); sel.addEventListener("change", () => page(true));
      more.addEventListener("click", () => page(false));
      body.append(h("div", {class: "adm-filters"}, ipI, userI, sel), h("div", {class: "adm-bar"}, delSel, delAll), list, more);
      updDel(); page(true);
    }

    /* --- Bloklangan IP lar --- */
    function loadBlocks() {
      const ipI = h("input", {type: "text", class: "fld", placeholder: "Bloklash uchun IP (masalan 203.0.113.5)", autocomplete: "off"});
      const reasonI = h("input", {type: "text", class: "fld", placeholder: "Sabab (ixtiyoriy)", autocomplete: "off"});
      const list = h("div", {});
      const fill = async () => {
        list.textContent = "";
        try {
          const j = await api("/admin/blocks");
          if (!j.blocks.length) list.append(h("div", {class: "adm-empty", text: "Bloklangan IP yo'q"}));
          j.blocks.forEach(b => list.append(h("div", {class: "ipc blk"},
            h("div", {class: "ipc-h"}, h("span", {class: "ip", text: b.ip})),
            h("div", {class: "ipc-s", text: (b.reason ? b.reason + " • " : "") + "@" + b.by + " • " + fmtDT(b.ts)}),
            h("div", {class: "ipc-a"}, h("button", {class: "btn ghost sm", type: "button", text: "Blokdan ochish", onclick: async () => {
              try { await api("/admin/unblock", {method: "POST", body: {ip: b.ip}}); toast("Blokdan ochildi", "ok"); fill(); } catch (err) { toast(err.message, "error"); }
            }}),
            h("button", {class: "btn ghost sm", type: "button", text: "Loglari", onclick: () => openAdmin("log", {ip: b.ip})})))));
        } catch (err) { admErr(list, err); }
      };
      const add = h("button", {class: "btn danger sm", type: "button", text: "Bloklash", onclick: async () => {
        if (!ipI.value.trim()) return;
        try { await api("/admin/blocks", {method: "POST", body: {ip: ipI.value.trim(), reason: reasonI.value}}); ipI.value = ""; reasonI.value = ""; toast("Bloklandi", "ok"); fill(); }
        catch (err) { toast(err.message, "error"); }
      }});
      body.append(h("div", {class: "adm-filters"}, ipI, reasonI, add), list);
      fill();
    }

    /* --- Xabarlar logi: bazada shifrlangan, serverda ochilgan (o'chirilgan/tahrirlanganlar ham) --- */
    function loadMsgs() {
      const qI = h("input", {type: "text", class: "fld", placeholder: "@username bo'yicha qidirish", autocomplete: "off"});
      const sel = h("select", {}, h("option", {value: "", text: "Barcha xabarlar"}), h("option", {value: "deleted", text: "Faqat o'chirilganlar"}), h("option", {value: "edited", text: "Faqat tahrirlanganlar"}));
      const list = h("div", {}), more = h("button", {class: "btn ghost sm adm-more hidden", type: "button", text: "Yana yuklash"});
      let next = 0, timer = null;
      const row = it => {
        const cipher = h("div", {class: "mcipher", text: it.cipher || "(shifr yo'q)"});
        const metaTxt = it.meta ? (it.meta.kind + " • epoch " + it.meta.epoch + " • shifr " + it.meta.cipher_bytes + " bayt • imzo " + it.meta.sig_bytes + " bayt")
          : (it.legacy ? "eski xabar (E2EE'dan oldin)" : "");
        const lock = h("div", {class: "mmeta", text: "🔒 " + metaTxt});
        const flags = h("span", {class: "mflags"},
          it.deleted ? h("span", {class: "flag b", text: "O'chirilgan"}) : null,
          it.edited ? h("span", {class: "flag w", text: "Tahrirlangan"}) : null,
          it.file ? h("span", {class: "flag", text: "Fayl " + fmtSize(it.file_bytes) + " (shifrlangan)"}) : null,
          it.legacy ? h("span", {class: "flag w", text: "Eski"}) : null);
        const card = h("div", {class: "lg mlg" + (it.deleted ? " gone" : "")},
          h("div", {class: "t", text: fmtDT(it.ts) + " • #" + it.id}),
          h("div", {class: "w"}, h("span", {class: "a", text: "@" + it.username}), it.nickname ? " (" + it.nickname + ") " : " ", flags),
          cipher, lock);
        it.history.forEach(hh => card.append(h("div", {class: "mhist"},
          h("b", {text: (hh.type === "edit" ? "Tahrir" : hh.type === "delete" ? "O'chirish" : hh.type) + " • " + fmtDT(hh.ts) + (hh.by ? " • @" + hh.by : "")}),
          hh.type === "edit" ? h("div", {class: "mcipher", text: hh.old + "\n→\n" + hh.new}) : h("div", {class: "mcipher", text: hh.old}))));
        return card;
      };
      const page = async reset => {
        if (reset) { next = 0; list.textContent = ""; }
        const qs = new URLSearchParams({q: qI.value.trim(), state: sel.value, limit: "50"});
        if (next) qs.set("before", next);
        try {
          const j = await api("/admin/messages?" + qs.toString());
          j.items.forEach(it => list.append(row(it)));
          next = j.next; more.classList.toggle("hidden", !next);
          if (reset && !j.items.length) list.append(h("div", {class: "adm-empty", text: "Xabar topilmadi"}));
        } catch (err) { admErr(list, err); }
      };
      qI.addEventListener("input", () => { clearTimeout(timer); timer = setTimeout(() => page(true), 300); });
      sel.addEventListener("change", () => page(true)); more.addEventListener("click", () => page(false));
      body.append(h("div", {class: "adm-note", text: "Uchdan-uchga shifrlash (E2EE): server ham, admin ham xabar matnini o'qiy olmaydi — bu yerda faqat shifrlangan konvertlar ko'rinadi. Matnni faqat chat a'zolarining qurilmalari ochadi. Lichka xabarlar bu yerda ko'rinmaydi."}),
        h("div", {class: "adm-filters"}, qI, sel),
        h("div", {class: "adm-bar"}, h("button", {class: "btn ghost sm dangerline", type: "button", text: "Tarixni tozalash", onclick: async () => {
          if (!await confirmDlg("O'chirilgan umumiy chat xabarlari bazadan butunlay o'chadi va tahrir/moderatsiya tarixi tozalanadi.", {title: "Xabarlar tarixini tozalash", okText: "Tozalash", danger: true})) return;
          try { const j = await api("/admin/messages/clean", {method: "POST"}); toast(j.messages + " ta xabar, " + j.history + " ta tarix tozalandi", "ok"); page(true); }
          catch (err) { toast(err.message, "error"); }
        }})), list, more);
      page(true);
    }


    /* --- Media boshqaruvi: fayl nomi/mazmuni ko'rinmaydi, faqat tur/hajm/vaqt/yuboruvchi --- */
    function loadMedia() {
      const KL = {image: "Rasm", video: "Video", audio: "Audio", other: "Fayl"};
      const kind = h("select", {}, ...[["", "Barcha turlar"], ["image", "Rasmlar"], ["video", "Videolar"], ["audio", "Audio"], ["other", "Boshqa fayllar"]].map(([v, t]) => h("option", {value: v, text: t})));
      const size = h("select", {}, ...[["0", "Har qanday hajm"], ["1", "1 MB dan katta"], ["5", "5 MB dan katta"], ["20", "20 MB dan katta"]].map(([v, t]) => h("option", {value: v, text: t})));
      const who = h("input", {type: "text", class: "fld", placeholder: "@username", autocomplete: "off"});
      const info = h("div", {class: "mm-total"}), list = h("div", {}), more = h("button", {class: "btn ghost sm adm-more hidden", type: "button", text: "Yana yuklash"});
      const del = h("button", {class: "btn danger sm", type: "button", text: "Tanlanganlarni o'chirish", disabled: true});
      const all = h("button", {class: "btn ghost sm", type: "button", text: "Ko'ringanlarni belgilash"});
      const picked = new Set(), boxes = [];
      let next = 0, timer = null;
      const upd = () => { del.disabled = !picked.size; del.textContent = picked.size ? "O'chirish (" + picked.size + ")" : "Tanlanganlarni o'chirish"; };
      const row = it => {
        const ck = h("input", {type: "checkbox", class: "ck", "aria-label": "Tanlash"});
        const r = h("div", {class: "mrow"}, ck, h("div", {}, h("span", {class: "mk", text: it.kind === "e2e" ? "🔒 Shifrlangan" : (KL[it.kind] || "Fayl")}), "@" + it.username, h("div", {class: "ms", text: fmtDT(it.ts)})), h("span", {class: "sz", text: fmtSize(it.size)}));
        ck.addEventListener("change", () => { if (ck.checked) picked.add(it.id); else picked.delete(it.id); r.classList.toggle("on", ck.checked); upd(); });
        boxes.push([ck, it.id, r]); return r;
      };
      const page = async reset => {
        if (reset) { next = 0; list.textContent = ""; picked.clear(); boxes.length = 0; upd(); }
        const qs = new URLSearchParams({kind: kind.value, sender: who.value.trim(), min_mb: size.value, limit: "50"});
        if (next) qs.set("before", next);
        try {
          const j = await api("/admin/media?" + qs.toString());
          info.textContent = "Umumiy chatdagi media: " + j.totals.count + " ta, jami " + fmtSize(j.totals.size);
          j.items.forEach(it => list.append(row(it)));
          next = j.next; more.classList.toggle("hidden", !next);
          if (reset && !j.items.length) list.append(h("div", {class: "adm-empty", text: "Media topilmadi"}));
        } catch (err) { admErr(list, err); }
      };
      all.addEventListener("click", () => { boxes.forEach(([ck, id, r]) => { ck.checked = true; picked.add(id); r.classList.add("on"); }); upd(); });
      del.addEventListener("click", async () => {
        if (!picked.size) return;
        if (!await confirmDlg(picked.size + " ta media chatdan va serverdan butunlay o'chiriladi. Izohi bor xabarlarning matni qoladi.", {title: "Media o'chirish", okText: "O'chirish", danger: true})) return;
        try { const j = await api("/admin/media/delete", {method: "POST", body: {ids: [...picked]}}); toast(j.deleted + " ta media o'chirildi", "ok"); page(true); }
        catch (err) { toast(err.message, "error"); }
      });
      const again = () => { clearTimeout(timer); timer = setTimeout(() => page(true), 300); };
      kind.addEventListener("change", () => page(true)); size.addEventListener("change", () => page(true)); who.addEventListener("input", again);
      more.addEventListener("click", () => page(false));
      body.append(h("p", {class: "mm-note", text: "Fayllar diskda shifrlangan. Bu yerda fayl nomi va mazmuni ko'rsatilmaydi (adminga ham), lichka fayllari kirmaydi. Loglarga faqat o'chirilgan SON yoziladi."}),
        info, h("div", {class: "adm-filters"}, kind, size, who), h("div", {class: "adm-bar"}, all, del), list, more);
      page(true);
    }

    /* --- Shikoyatlar --- */
    function loadReports() {
      const status = h("select", {}, h("option", {value: "open", text: "Ochiq shikoyatlar"}), h("option", {value: "closed", text: "Ko'rib chiqilganlar"}));
      const list = h("div", {}), more = h("button", {class: "btn ghost sm adm-more hidden", type: "button", text: "Yana yuklash"});
      let next = 0;
      const close = async (it, action) => {
        try { await api("/admin/reports/close", {method: "POST", body: {id: it.id, action}}); page(true); }
        catch (err) { toast(err.message, "error"); }
      };
      const card = it => {
        const c = h("div", {class: "rcard" + (it.status === "closed" ? " closed" : "")},
          h("div", {class: "rh"}, h("span", {text: fmtDT(it.ts) + " • #" + it.message_id}), h("span", {text: "@" + it.reporter + " → @" + it.target}),
            it.status === "closed" ? h("span", {class: "flag w", text: (it.action || "Yopilgan") + (it.by ? " (@" + it.by + ")" : "")}) : null),
          h("div", {class: "rt", text: it.text || (it.disclosed ? "(shikoyatchi matnni ochib bermadi)" : "(matnsiz)")}),
          it.reason ? h("div", {class: "rr", text: "Sabab: " + it.reason}) : null);
        if (it.disclosed) {                                   // E2EE: shikoyatchi bergan matn asl shifrlangan xabarga mosligini O'Z qurilmamizda tekshiramiz
          const v = h("div", {class: "rv", text: "🔒 Xabar shifrlangan; matn — shikoyatchi ixtiyoriy ochib bergani. Tekshirilmoqda…"});
          c.append(v);
          (async () => {
            try {
              const env = E2E.parseEnvelope(it.cipher), key = env.k === "g" ? X.rooms.get(env.ep) : null;
              if (!key) { v.textContent = "🔒 Tekshirib bo'lmadi: bu xabar kaliti sizda yo'q (matn tasdiqlanmagan)."; return; }
              const senderPeer = await peer(it.target_id);
              const r = await E2E.openMessage(it.cipher, {sender: it.target_id, peer: null, key, signKey: senderPeer.sign});
              const ok = r.verified && typeof r.payload.t === "string" && r.payload.t === it.text;
              v.textContent = ok ? "✅ Matn asl shifrlangan xabarga mos (imzo tasdiqlandi)." : "⚠ Ochib berilgan matn asl xabarga MOS EMAS — soxta shikoyat bo'lishi mumkin!";
              v.classList.add(ok ? "ok" : "bad");
            } catch (_) { v.textContent = "⚠ Tekshirib bo'lmadi (shifrni ochishda xato)."; v.classList.add("bad"); }
          })();
        }
        if (it.status === "open") {
          const a = h("div", {class: "ra"});
          if (it.alive) a.append(h("button", {class: "btn danger sm", type: "button", text: "Xabarni o'chirish", onclick: () => close(it, "delete")}));
          a.append(h("button", {class: "btn ghost sm", type: "button", text: "Mute 10 daq", onclick: () => { if (wsSend({type: "cmd", text: "/mute " + it.target + " 10 shikoyat"})) close(it, "done"); }}),
            h("button", {class: "btn ghost sm", type: "button", text: "Ogohlantirish", onclick: () => { if (wsSend({type: "cmd", text: "/warn " + it.target + " shikoyat"})) close(it, "done"); }}),
            h("button", {class: "btn ghost sm", type: "button", text: "Rad etish", onclick: () => close(it, "dismiss")}));
          c.append(a);
        }
        return c;
      };
      const page = async reset => {
        if (reset) { next = 0; list.textContent = ""; }
        const qs = new URLSearchParams({status: status.value, limit: "30"}); if (next) qs.set("before", next);
        try {
          const j = await api("/admin/reports?" + qs.toString());
          j.items.forEach(it => list.append(card(it)));
          next = j.next; more.classList.toggle("hidden", !next);
          if (reset && !j.items.length) list.append(h("div", {class: "adm-empty", text: status.value === "open" ? "Ochiq shikoyat yo'q 🎉" : "Hech narsa yo'q"}));
        } catch (err) { admErr(list, err); }
      };
      status.addEventListener("change", () => page(true)); more.addEventListener("click", () => page(false));
      body.append(h("div", {class: "adm-filters"}, status), list, more); page(true);
    }

    /* --- Moderatsiya sozlamalari: sekin rejim, qulf --- */
    async function loadMod() {
      let cfg;
      try { cfg = await api("/admin/modsettings"); } catch (err) { admErr(body, err); return; }
      const save = async patch => {
        try { cfg = await api("/admin/modsettings", {method: "POST", body: patch}); toast("Saqlandi", "ok"); }
        catch (err) { toast(err.message, "error"); }
      };
      const slow = h("select", {}, ...[[0, "O'chiq"], [5, "5 soniya"], [10, "10 soniya"], [30, "30 soniya"], [60, "1 daqiqa"], [300, "5 daqiqa"]].map(([v, t]) => h("option", {value: String(v), text: t})));
      if (![0, 5, 10, 30, 60, 300].includes(cfg.slowmode)) slow.append(h("option", {value: String(cfg.slowmode), text: cfg.slowmode + " soniya"}));
      slow.value = String(cfg.slowmode);
      const lock = h("input", {type: "checkbox"}); lock.checked = cfg.locked;
      lock.addEventListener("change", () => save({locked: lock.checked}));
      const e2eSection = () => {
        const box = h("div", {class: "msec"}, h("h4", {text: "🔐 Uchdan-uchga shifrlash (E2EE)"}));
        const info = h("p", {text: "Yuklanmoqda…"}); box.append(info);
        api("/admin/e2ee").then(st => {
          info.textContent = "Guruh kaliti avlodi: " + st.epoch + " • kalitli foydalanuvchilar: " + st.keyed_users + " • server o'qiy oladigan eski xabarlar: " + st.legacy_messages +
            ". Ban qilinganda kalit avtomatik yangilanadi, qo'lda ham yangilash mumkin.";
          box.append(h("div", {class: "ep-row"}, h("button", {class: "btn sm", type: "button", text: "Guruh kalitini yangilash", onclick: async () => {
            if (!X.rooms.has(X.epoch)) { toast("Sizda joriy guruh kaliti yo'q", "error"); return; }
            await rotateRoom("manual"); load();
          }})));
          if (S.me.role === "owner" && st.legacy_messages) box.append(h("div", {class: "ep-row"}, h("button", {class: "btn danger sm", type: "button", text: "Eski xabarlarni o'chirish (" + st.legacy_messages + ")", onclick: async () => {
            if (!await confirmDlg("Server o'qiy oladigan barcha eski xabarlar va ularning fayllari butunlay o'chadi. Qaytarib bo'lmaydi. Yangi (E2EE) xabarlarga tegilmaydi.", {title: "Eski xabarlarni o'chirish", okText: "O'chirish", danger: true})) return;
            try { const j = await api("/admin/e2ee/purge-legacy", {method: "POST"}); toast(j.deleted + " ta eski xabar o'chirildi", "ok"); load(); } catch (err) { toast(err.message, "error"); }
          }})));
        }).catch(err => { info.textContent = err.message; });
        return box;
      };
      body.append(
        h("div", {class: "msec"}, h("h4", {text: "🐢 Sekin rejim"}), h("p", {text: "Oddiy foydalanuvchilar umumiy chatga shuncha vaqtda bir marta yoza oladi. Adminlarga va lichkaga qo'llanmaydi."}),
          h("div", {class: "ep-row"}, slow, h("button", {class: "btn sm", type: "button", text: "Saqlash", onclick: () => save({slowmode: Number(slow.value)})}))),
        h("div", {class: "msec"}, h("h4", {text: "🔒 Chatni qulflash"}), h("p", {text: "Qulflanganda umumiy chatga faqat adminlar yoza oladi (lichka ishlayveradi)."}),
          h("label", {class: "tgl"}, h("span", {text: "Umumiy chat qulflangan"}), lock)),
        e2eSection(),
        h("div", {class: "msec"}, h("h4", {text: "🛡️ Avtomatik himoya"}), h("p", {text: "3 ta ogohlantirishdan keyin foydalanuvchi 1 soatga mute qilinadi. Spam (1 daqiqada 3 marta tezlik limitiga urilish) — 5 daqiqa avtomatik mute. Foydalanuvchi profilidagi Moderatsiya panelidan: ogohlantirish, xabarlarini tozalash, mute/ban."})));
    }

    paintTabs(); load();
    return h("div", {}, sheetHead("Admin: loglar, media va moderatsiya"), tabs, body);
  }, false, true);
}

/* ---------- emoji nishon: tanlash (o'zimga yoki foydalanuvchiga) ---------- */
const BADGE_EMOJIS = "👑 ✅ ⭐ 🌟 💎 🔥 ⚡ 🚀 🛡️ 🏆 🎖️ 💜 ❤️ 💙 💚 🧡 😎 🤩 😈 👻 🦄 🐉 🦁 🐺 🦅 🌈 🌙 ☀️ ❄️ 🍀 🎯 🎨 🎧 🎮 💫 ✨ 🔱 ⚜️ 🧿 🪐 🍒 🍉 👾 🤖 🥇 📢 🎉 🌹 🦋 🐱 🐼 🍕".split(" ");
const BADGE_ANIMS = [["", "Yo'q"], ["pulse", "Puls"], ["bounce", "Sakrash"], ["spin", "Aylanish"], ["shake", "Silkinish"], ["float", "Suzish"], ["glow", "Nur"], ["flip", "Aylanma"], ["wave", "Silkitish"], ["rainbow", "Kamalak"]];
function badgeEditor(t, onSaved) {
  const cur = {badge: t.badge || "", anim: t.badge_anim || ""};
  const prev = h("div", {class: "ep-prev"}), grid = h("div", {class: "ep-grid"}), anims = h("div", {class: "ep-anims"});
  const custom = h("input", {type: "text", class: "fld", maxlength: "16", placeholder: "Yoki o'z emojingizni kiriting", autocomplete: "off"});
  const chk = isStaff(t) ? null : h("button", {class: "btn ghost", type: "button", text: "✔ Galochka (tasdiqlangan)", onclick: () => { cur.badge = "check"; cur.anim = ""; custom.value = ""; paint(); }});
  const paint = () => {
    prev.textContent = "";
    const b = badge(Object.assign({}, t, {badge: cur.badge, badge_anim: cur.anim}), true);
    prev.append(nameEl(Object.assign({}, t, {badge: cur.badge, badge_anim: cur.anim}), {big: true}));
    if (!b) prev.append(h("small", {text: "  (nishon yo'q)"}));
    grid.querySelectorAll("button").forEach(x => x.classList.toggle("on", x.textContent === cur.badge));
    cgrid.querySelectorAll("button").forEach(x => x.classList.toggle("on", x.dataset.v === cur.badge));
    if (chk) chk.classList.toggle("on", cur.badge === "check");
    anims.querySelectorAll("button").forEach(x => x.classList.toggle("on", x.dataset.a === cur.anim));
  };
  const cgrid = h("div", {class: "ep-grid ep-custom"});
  Rich.emojiList().forEach(e => { const b = h("button", {type: "button", title: e.label, "aria-label": e.label, onclick: () => { cur.badge = e.token; custom.value = ""; paint(); }}, Rich.emojiEl(e.token, "ceb", e.label)); b.dataset.v = e.token; cgrid.append(b); });
  BADGE_EMOJIS.forEach(e => grid.append(h("button", {type: "button", text: e, "aria-label": e, onclick: () => { cur.badge = e; custom.value = ""; paint(); }})));
  BADGE_ANIMS.forEach(([k, n]) => { const b = h("button", {type: "button", text: n}); b.dataset.a = k; b.addEventListener("click", () => { cur.anim = k; paint(); }); anims.append(b); });
  custom.addEventListener("input", () => { const v = custom.value.trim(); if (v) { cur.badge = v; paint(); } });
  const save = async () => {
    try {
      let u;
      if (t.id === S.me.id) u = (await api("/profile", {method: "PATCH", body: {badge: cur.badge, badge_anim: cur.anim}})).me;
      else u = (await api("/admin/badge", {method: "POST", body: {user_id: t.id, badge: cur.badge, anim: cur.anim}})).user;
      upsertUser(u); renderList(); renderHeader(); renderMessages(false);
      toast("Nishon saqlandi", "ok"); if (onSaved) onSaved(u);
    } catch (err) { toast(err.message, "error"); }
  };
  const row = h("div", {class: "ep-row"},
    h("button", {class: "btn", type: "button", text: "Saqlash", onclick: save}),
    h("button", {class: "btn ghost", type: "button", text: isStaff(t) ? "Galochka (standart)" : "Olib tashlash", onclick: () => { cur.badge = ""; cur.anim = ""; custom.value = ""; paint(); }}),
    isStaff(t) ? h("button", {class: "btn ghost", type: "button", text: "Yashirish", onclick: () => { cur.badge = "none"; cur.anim = ""; custom.value = ""; paint(); }}) : null);
  paint();
  return h("div", {}, prev, chk ? h("div", {class: "ep-row"}, chk, h("small", {text: "Foydalanuvchini admin qilmasdan beriladi"})) : null,
    h("small", {class: "ep-cap", text: "Maxsus emojilar (Linux / hacker)"}), cgrid, grid, h("div", {class: "ep-row"}, custom), anims, row);
}
function badgeSection() { return h("div", {class: "setsec"}, h("h4", {text: "Profil nishoni (emoji va animatsiya)"}), badgeEditor(S.me)); }

/* =====================================================================
   Maxsus emojilar: tanlagich (yuborish tugmasi yonida), yaratish (rasm yuklab), boshqarish (admin)
   Xabarda emoji `:nom:` matni sifatida yuboriladi (E2EE ichida), ko'rsatishda rasmga aylanadi.
   ===================================================================== */
const EM = {data: null, tab: "std", refresh: null};
const STD_EMOJIS = "😀 😃 😄 😁 😆 😅 😂 🤣 🙂 😉 😊 😇 🥰 😍 🤩 😘 😋 😛 😜 🤪 😎 🤓 🥳 😏 😒 😞 😔 😟 😕 🙁 😣 😖 😫 😩 🥺 😢 😭 😤 😠 😡 🤬 🤯 😳 🥵 🥶 😱 😨 😰 😥 😓 🤗 🤔 🤭 🤫 😶 😐 😑 😬 🙄 😯 😲 🥱 😴 🤤 😪 😵 🤐 🥴 🤢 🤮 🤧 😷 🤒 🤕 😈 👿 👹 👺 💀 👻 👽 🤖 💩 🙈 🙉 🙊 👍 👎 👌 ✌️ 🤞 🤟 🤘 👏 🙌 🙏 💪 👀 🧠 ❤️ 🧡 💛 💚 💙 💜 🖤 💔 💯 ✨ 🔥 ⚡ 🌈 ⭐ 🎉 🎁 🏆 🚀 💻 🔒 🔑 🛡️ ☕ 🍕 🍔 🍺".split(" ");

function emojiPerms() { return (EM.data && EM.data.perms) || {use: false, create: false, manage: false}; }
function emojiUsable(e) {                                  // tanlagichda ko'rinadimi (admin hammasini ko'radi)
  const p = emojiPerms();
  if (p.manage) return true;
  const pk = e.pack != null ? EM.data.packs.find(x => x.id === e.pack) : null;
  return e.public !== false && (!pk || pk.public);
}
function syncEmojiBtn() { $("emojiBtn").classList.toggle("hidden", !emojiPerms().use); if (!emojiPerms().use) closeEmojiPanel(); }
async function loadEmojis() {
  try {
    const r = await api("/emojis");
    EM.data = r; Rich.setEmojis(r.emojis, true);
    syncEmojiBtn();
    if (S.active) renderMessages(false);                     // yangi/o'chirilgan emojilar xabarlarda darrov o'zgaradi
    if (!$("emojiPanel").classList.contains("hidden")) paintEmojiPanel();
    if (EM.refresh) EM.refresh();
  } catch (_) {}
}

function insertEmoji(text) {
  const s = inp.selectionStart == null ? inp.value.length : inp.selectionStart, e = inp.selectionEnd == null ? s : inp.selectionEnd;
  if (inp.value.length - (e - s) + text.length > inp.maxLength) { toast("Xabar juda uzun", "warn"); return; }
  inp.setRangeText(text, s, e, "end"); autosize();
  if (!COARSE) inp.focus({preventScroll: true});            // telefonda klaviatura o'zi chiqib ketmasin
}
function emojiPanelOpen() { return !$("emojiPanel").classList.contains("hidden"); }
function closeEmojiPanel() { $("emojiPanel").classList.add("hidden"); $("emojiBtn").classList.remove("on"); }
function placeEmojiPanel() {
  const b = $("emojiBtn").getBoundingClientRect(), p = $("emojiPanel"), w = Math.min(344, innerWidth - 16);
  p.style.left = Math.max(8, Math.min(b.right - w, innerWidth - w - 8)) + "px";
  p.style.bottom = Math.max(8, innerHeight - b.top + 8) + "px";
}
function emojiTabs() {
  const d = EM.data, tabs = [{k: "std", label: "😀"}];
  const usable = d.emojis.filter(e => !e.builtin ? emojiUsable(e) : true);
  d.packs.forEach(pk => {
    const items = usable.filter(e => e.pack === pk.id);
    if (items.length || emojiPerms().manage) tabs.push({k: "p" + pk.id, label: pk.name, items, icon: items[0]});
  });
  const loose = usable.filter(e => e.pack == null || !d.packs.some(pk => pk.id === e.pack));
  if (loose.length) tabs.push({k: "other", label: tabs.length > 1 ? "Boshqa" : "Emojilar", items: loose, icon: loose[0]});
  return tabs;
}
function paintEmojiPanel() {
  const panel = $("emojiPanel"), d = EM.data, perms = emojiPerms();
  if (!d) return;
  const tabs = emojiTabs();
  if (!tabs.some(t => t.k === EM.tab)) EM.tab = tabs.length > 1 ? tabs[1].k : "std";
  panel.textContent = "";
  const bar = h("div", {class: "ep-tabs", role: "tablist"});
  tabs.forEach(t => {
    const b = h("button", {type: "button", class: t.k === EM.tab ? "on" : "", title: t.label, role: "tab"});
    if (t.k === "std") b.textContent = t.label;
    else { if (t.icon) b.append(Rich.chatEmoji(t.icon.token, false)); b.append(h("span", {text: t.label})); }
    b.addEventListener("click", () => { EM.tab = t.k; paintEmojiPanel(); });
    bar.append(b);
  });
  const grid = h("div", {class: "ep-grid"});
  const cur = tabs.find(t => t.k === EM.tab) || tabs[0];
  if (cur.k === "std") STD_EMOJIS.forEach(c => grid.append(h("button", {type: "button", text: c, "aria-label": c, onclick: () => insertEmoji(c)})));
  else if (!cur.items.length) grid.append(h("div", {class: "ep-empty", text: "Bu to'plam hozircha bo'sh"}));
  else cur.items.forEach(e => {
    const b = h("button", {type: "button", title: e.token, "aria-label": e.label, onclick: () => insertEmoji(e.token)}, Rich.chatEmoji(e.token, false));
    grid.append(b);
  });
  panel.append(bar, grid);
  if (perms.create || perms.manage) {
    const foot = h("div", {class: "ep-foot"});
    if (perms.create) foot.append(h("button", {class: "btn ghost", type: "button", text: "＋ Emoji yaratish", onclick: () => { closeEmojiPanel(); openEmojiCreate(); }}));
    if (perms.manage) foot.append(h("button", {class: "btn ghost", type: "button", text: "⚙ Boshqarish", onclick: () => { closeEmojiPanel(); openAdmin("emoji"); }}));
    panel.append(foot);
  }
}
function toggleEmojiPanel() {
  if (emojiPanelOpen()) { closeEmojiPanel(); return; }
  if (!EM.data || !emojiPerms().use) return;
  paintEmojiPanel(); placeEmojiPanel();
  $("emojiPanel").classList.remove("hidden"); $("emojiBtn").classList.add("on");
}
$("emojiBtn").addEventListener("mousedown", e => e.preventDefault());           // yozish maydonidan fokus ketmasin
$("emojiPanel").addEventListener("mousedown", e => { if (!e.target.closest("input,select,textarea")) e.preventDefault(); });
$("emojiBtn").addEventListener("click", toggleEmojiPanel);
document.addEventListener("click", e => {            // katalog (tab) almashganda panel qayta chiziladi: bosilgan tugma DOM'dan chiqib ketadi, shuning uchun yo'lni hodisa vaqtidagi holatdan olamiz
  if (!emojiPanelOpen()) return;
  const path = e.composedPath ? e.composedPath() : [];
  if (path.includes($("emojiPanel")) || path.includes($("emojiBtn"))) return;
  closeEmojiPanel();
});
document.addEventListener("keydown", e => { if (e.key === "Escape" && emojiPanelOpen()) { e.stopPropagation(); closeEmojiPanel(); } }, true);
addEventListener("resize", () => { if (emojiPanelOpen()) placeEmojiPanel(); });

/* ---------- emoji yaratish: rasm tanlash -> (kerak bo'lsa) orqa fonni olib tashlash -> animatsiya -> saqlash ---------- */
function openEmojiCreate(back) {
  const d = EM.data;
  if (!d || !d.perms.create) { toast("Emoji yaratishga ruxsatingiz yo'q", "error"); return; }
  const admin = d.perms.manage;
  const st = {file: null, seq: 0, timer: 0, touched: false};
  openModal(() => {
    const pvImg = h("img", {alt: "", draggable: "false", class: "hidden"});
    const hint = h("div", {class: "em-hint", text: "Rasm tanlang (PNG, JPG, WEBP yoki GIF, 5 MB gacha)"});
    const pv = h("div", {class: "em-pv"}, pvImg, hint);
    const pick = h("input", {type: "file", accept: "image/png,image/jpeg,image/webp,image/gif", class: "offscreen"});
    const pickBtn = h("button", {class: "btn ghost", type: "button", text: "🖼 Rasm tanlash", onclick: () => pick.click()});
    const name = h("input", {type: "text", class: "fld", maxlength: "14", placeholder: "masalan: kulgi_1", autocomplete: "off", autocapitalize: "off", spellcheck: "false"});
    const bg = h("input", {type: "checkbox"});
    const bgRow = h("label", {class: "em-chk"}, bg, h("span", {text: "Orqa fonni olib tashlash (remove background)"}));
    const bgNote = h("small", {text: "JPG yoki shaffof bo'lmagan rasm uchun. Bir xil rangli fonda yaxshi ishlaydi."});
    const tolVal = h("b", {text: "30"});
    const tol = h("input", {type: "range", min: "5", max: "80", value: "30"});
    const tolRow = h("div", {class: "em-row hidden"}, h("label", {text: "Fon sezgirligi (kattaroq = ko'proq o'chadi)"}), h("div", {class: "em-range"}, tol, tolVal));
    const anim = h("select", {class: "fld"}, ...BADGE_ANIMS.map(([v, t]) => h("option", {value: v, text: t})));
    const animRow = h("div", {class: "em-row"}, h("label", {text: "Animatsiya"}), anim);
    const packSel = h("select", {class: "fld"}), pub = h("select", {class: "fld"}, h("option", {value: "true", text: "Hamma ishlata oladi"}), h("option", {value: "false", text: "Faqat adminlar"}));
    const fillPacks = sel => {
      packSel.textContent = ""; packSel.append(h("option", {value: "", text: "To'plamsiz"}));
      EM.data.packs.forEach(p => packSel.append(h("option", {value: String(p.id), text: p.name + (p.public ? "" : " (yopiq)")})));
      packSel.value = sel == null ? "" : String(sel);
    };
    fillPacks(EM.tab.startsWith("p") ? Number(EM.tab.slice(1)) : null);
    const newPack = h("button", {class: "btn ghost sm", type: "button", text: "＋ Yangi to'plam", onclick: async () => {
      const nm = await promptDlg("Yangi emoji to'plami", "To'plam nomi (2–24 belgi):", "", {okText: "Yaratish", placeholder: "masalan: Mem emojilar"});
      if (!nm) return;
      try { const r = await api("/emoji-packs", {method: "POST", body: {name: nm, public: true}}); await loadEmojis(); fillPacks(r.id); toast("To'plam yaratildi", "ok"); }
      catch (err) { toast(err.message, "error"); }
    }});
    packSel.addEventListener("change", () => { const p = EM.data.packs.find(x => String(x.id) === packSel.value); if (p) pub.value = String(p.public); });
    const go = h("button", {class: "btn", type: "button", text: "Emoji yaratish", disabled: true});
    const showAnim = () => { BADGE_ANIMS.forEach(([v]) => { if (v) pvImg.classList.remove("a-" + v); }); if (anim.value) pvImg.classList.add("a-" + anim.value); };
    anim.addEventListener("change", showAnim);

    const setBgState = r => {
      const locked = r.source_alpha || r.animated;
      bg.disabled = locked; bgRow.classList.toggle("off", locked);
      if (locked) bg.checked = false;
      bgNote.textContent = r.animated ? "Animatsiyali fayl: orqa fon o'chirilmaydi, animatsiya saqlanadi."
        : r.source_alpha ? "Bu rasm shaffof (PNG): orqa fon yo'q, shundayligicha qoladi."
        : "JPG yoki shaffof bo'lmagan rasm uchun. Bir xil rangli fonda yaxshi ishlaydi.";
      tolRow.classList.toggle("hidden", !bg.checked || locked);
      animRow.classList.toggle("hidden", !!r.animated);
    };
    const preview = async () => {
      if (!st.file) return;
      const my = ++st.seq; pv.classList.add("busy"); go.disabled = true;
      const fd = new FormData(); fd.append("file", st.file); fd.append("remove_bg", bg.checked ? "true" : "false"); fd.append("tolerance", tol.value);
      try {
        const r = await api("/emoji/preview", {method: "POST", body: fd});
        if (my !== st.seq) return;
        pvImg.src = r.image; pvImg.classList.remove("hidden"); showAnim(); setBgState(r);
        hint.textContent = r.bg_removed ? "Orqa fon olib tashlandi" : r.transparent ? "Shaffof fon saqlandi" : "Orqa fon bilan (xohlasangiz, yuqoridan olib tashlang)";
        go.disabled = false;
      } catch (err) {
        if (my !== st.seq) return;
        hint.textContent = err.message; if (!bg.checked) pvImg.classList.add("hidden");
        go.disabled = !bg.checked;                           // fon xatosida sozlamani o'zgartirib qayta urinish mumkin
      } finally { if (my === st.seq) pv.classList.remove("busy"); }
    };
    const later = () => { clearTimeout(st.timer); st.timer = setTimeout(preview, 350); };
    pick.addEventListener("change", () => {
      const f = pick.files[0]; pick.value = ""; if (!f) return;
      if (f.size > 5 * 1024 * 1024) { toast("Rasm 5 MB dan oshmasligi kerak", "error"); return; }
      st.file = f; bg.checked = false; tolRow.classList.add("hidden");
      if (!st.touched) { const n = f.name.replace(/\.[^.]+$/, "").toLowerCase().replace(/[^a-z0-9_]+/g, "_").replace(/^_+|_+$/g, "").slice(0, 14); name.value = n.length >= 2 ? n : "emoji"; }
      preview();
    });
    name.addEventListener("input", () => { st.touched = true; });
    bg.addEventListener("change", () => { tolRow.classList.toggle("hidden", !bg.checked); preview(); });
    tol.addEventListener("input", () => { tolVal.textContent = tol.value; later(); });
    go.addEventListener("click", async () => {
      if (!st.file) { toast("Avval rasm tanlang", "error"); return; }
      go.disabled = true; go.textContent = "Yaratilmoqda…";
      const fd = new FormData();
      fd.append("file", st.file); fd.append("name", name.value); fd.append("anim", anim.value); fd.append("remove_bg", bg.checked ? "true" : "false");
      fd.append("tolerance", tol.value);
      if (admin) { fd.append("pack_id", packSel.value); fd.append("public", pub.value); }
      try {
        const r = await api("/emoji", {method: "POST", body: fd});
        toast("Emoji tayyor: :" + r.name + ":", "ok");
        await loadEmojis();
        if (back) back(); else closeModal();
      } catch (err) { toast(err.message, "error"); go.disabled = false; go.textContent = "Emoji yaratish"; }
    });
    return h("div", {}, sheetHead("Emoji yaratish", back || null),
      h("div", {class: "em-dlg"}, pv, pickBtn, pick,
        h("div", {class: "em-row"}, h("label", {text: "Emoji nomi (:nom: ko'rinishida yoziladi)"}), name),
        bgRow, bgNote, tolRow, animRow,
        admin ? h("div", {class: "em-two"}, h("div", {class: "em-row"}, h("label", {text: "To'plam"}), packSel, newPack), h("div", {class: "em-row"}, h("label", {text: "Kim ishlata oladi"}), pub)) : null,
        go));
  });
}

/* ---------- emoji boshqaruvi (admin paneli, «Emoji» bo'limi) ---------- */
function emojiManager(body, alive) {
  const ANIM_OPTS = BADGE_ANIMS.map(([v, t]) => [v, t]);
  const act = async (fn, okText) => { try { await fn(); if (okText) toast(okText, "ok"); } catch (err) { toast(err.message, "error"); } await loadEmojis(); };
  let q = "";
  const paint = () => {
    const d = EM.data;
    body.textContent = "";
    if (!d || !d.perms.manage) { body.append(h("div", {class: "adm-empty", text: "Yuklanmoqda…"})); return; }

    const mode = h("select", {class: "fld"}, h("option", {value: "off", text: "Yopiq — faqat adminlar (va ruxsat berilganlar)"}), h("option", {value: "use", text: "Ochiq — hamma ochiq emojilarni ishlatadi"}));
    mode.value = d.global;
    mode.addEventListener("change", () => act(() => api("/emoji-settings", {method: "PUT", body: {mode: mode.value}}), "Saqlandi"));
    const top = h("div", {class: "em-sec"}, h("h4", {text: "😀 Oddiy foydalanuvchilar"}),
      h("p", {text: "Ochiq bo'lsa, hamma foydalanuvchida yuborish tugmasi yonida emoji tanlagich chiqadi (faqat «hamma ishlata oladi» deb belgilangan emojilar). Yaratish ruxsatini pastda alohida foydalanuvchiga berasiz."}), mode,
      h("div", {class: "ep-row"}, h("button", {class: "btn sm", type: "button", text: "＋ Emoji yaratish", onclick: () => openEmojiCreate(() => openAdmin("emoji"))})));

    const packs = h("div", {class: "em-sec"}, h("h4", {text: "📦 Emoji to'plamlari (pack)"}), h("p", {text: "To'plam emojilarni guruhlaydi. To'plamni yopsangiz, ichidagi emojilar faqat adminlarga ko'rinadi."}));
    d.packs.forEach(pk => {
      const nm = h("input", {type: "text", class: "fld", maxlength: "24", value: pk.name});
      const pb = h("select", {class: "fld"}, h("option", {value: "true", text: "Hamma uchun"}), h("option", {value: "false", text: "Faqat adminlar"})); pb.value = String(pk.public);
      packs.append(h("div", {class: "em-item"}, h("span", {text: "📦"}), nm, h("div", {class: "em-ctl"}, pb,
        h("button", {class: "btn ghost sm", type: "button", text: "Saqlash", onclick: () => act(() => api("/emoji-packs/" + pk.id, {method: "PATCH", body: {name: nm.value, public: pb.value === "true"}}), "Saqlandi")}),
        h("button", {class: "btn danger sm", type: "button", text: "O'chirish", onclick: async () => {
          if (!await confirmDlg("«" + pk.name + "» to'plami o'chadi. Ichidagi emojilar o'chmaydi, to'plamsiz bo'lib qoladi.", {title: "To'plamni o'chirish", okText: "O'chirish", danger: true})) return;
          act(() => api("/emoji-packs/" + pk.id, {method: "DELETE"}), "To'plam o'chirildi");
        }}))));
    });
    const newName = h("input", {type: "text", class: "fld", maxlength: "24", placeholder: "Yangi to'plam nomi", autocomplete: "off"});
    packs.append(h("div", {class: "ep-row"}, newName, h("button", {class: "btn sm", type: "button", text: "Yaratish", onclick: () => {
      if (!newName.value.trim()) return;
      act(() => api("/emoji-packs", {method: "POST", body: {name: newName.value, public: true}}), "To'plam yaratildi");
    }})));

    const list = h("div", {class: "em-sec"}, h("h4", {text: "🖼 Maxsus emojilar (" + d.emojis.filter(e => !e.builtin).length + ")"}));
    const mine = d.emojis.filter(e => !e.builtin);
    if (!mine.length) list.append(h("p", {text: "Hali emoji yo'q. «Emoji yaratish» tugmasi bilan rasm yuklab yarating."}));
    mine.forEach(e => {
      const pk = h("select", {class: "fld"}, h("option", {value: "", text: "To'plamsiz"}), ...d.packs.map(p => h("option", {value: String(p.id), text: p.name}))); pk.value = e.pack == null ? "" : String(e.pack);
      const pb = h("select", {class: "fld"}, h("option", {value: "true", text: "Hamma"}), h("option", {value: "false", text: "Faqat adminlar"})); pb.value = String(e.public);
      const an = h("select", {class: "fld", disabled: e.animated}, ...ANIM_OPTS.map(([v, t]) => h("option", {value: v, text: t}))); an.value = e.anim || "";
      const save = () => act(() => api("/emoji/" + e.id, {method: "PATCH", body: {anim: an.value, pack_id: pk.value ? Number(pk.value) : null, public: pb.value === "true"}}), "Saqlandi");
      [pk, pb, an].forEach(s => s.addEventListener("change", save));
      list.append(h("div", {class: "em-item"}, Rich.chatEmoji(e.token, false),
        h("div", {}, h("b", {text: e.token}), h("div", {class: "em-lbl", text: (e.author ? e.author : "—") + (e.animated ? " • animatsiyali fayl" : "")})),
        h("div", {class: "em-ctl"}, pk, pb, an, h("button", {class: "btn danger sm", type: "button", text: "O'chirish", onclick: async () => {
          if (!await confirmDlg(e.token + " emojisi o'chadi. Eski xabarlarda u oddiy matn bo'lib ko'rinadi.", {title: "Emojini o'chirish", okText: "O'chirish", danger: true})) return;
          act(() => api("/emoji/" + e.id, {method: "DELETE"}), "Emoji o'chirildi");
        }}))));
    });

    const users = h("div", {class: "em-sec"}, h("h4", {text: "👤 Foydalanuvchilar ruxsati"}),
      h("p", {text: "«Yaratadi» ruxsati olgan foydalanuvchi o'z emojisini yarata oladi (eng ko'pi bilan " + 30 + " ta, hamma ko'radi). Adminlarda hammasi doim bor."}));
    const search = h("input", {type: "text", class: "fld", placeholder: "Nickname yoki @username", autocomplete: "off", value: q});
    const ulist = h("div", {});
    const fillUsers = () => {
      ulist.textContent = "";
      const t = q.trim().toLowerCase().replace(/^@/, "");
      const ms = S.members.filter(m => m.role === "user" && !m.deleted && (!t || (m.nickname || "").toLowerCase().includes(t) || (m.username || "").toLowerCase().includes(t))).slice(0, 60);
      if (!ms.length) ulist.append(h("div", {class: "adm-empty", text: "Hech kim topilmadi"}));
      ms.forEach(m => {
        const sel = h("select", {class: "fld"}, h("option", {value: "0", text: "Umumiy sozlama"}), h("option", {value: "1", text: "Ishlatadi"}), h("option", {value: "2", text: "Ishlatadi + yaratadi"}));
        sel.value = String((d.user_perms || {})[String(m.id)] || 0);
        sel.addEventListener("change", () => act(() => api("/emoji-perm/" + m.id, {method: "PUT", body: {perm: Number(sel.value)}}), "Ruxsat saqlandi"));
        ulist.append(h("div", {class: "em-urow"}, h("span", {text: m.nickname + " @" + m.username}), sel));
      });
    };
    search.addEventListener("input", () => { q = search.value; fillUsers(); });
    fillUsers();
    users.append(search, ulist);
    body.append(top, packs, list, users);
  };
  const refresh = () => {                              // katalog o'zgarganda (WS) faqat «Emoji» bo'limi ochiq turganda qayta chiziladi
    if (!body.isConnected || (alive && !alive())) { if (EM.refresh === refresh) EM.refresh = null; return; }
    paint();
  };
  EM.refresh = refresh;
  paint();
  if (!EM.data) loadEmojis();
}
function openBadgePicker(u, back) {
  const go = back || (() => openProfile(u.id));
  openModal(() => h("div", {}, sheetHead("Nishon: @" + u.username, go), h("div", {class: "sh-body"}, badgeEditor(U(u.id), go))), false);
}

/* ---------- sozlamalar (o'z profilim) ---------- */
/* ---------------- Shifrlash inspektori: xabar qanday shifrlanadi va server nimani ko'radi ---------------- */
function openInspector(tab) {
  openModal(() => {
    const st = {tab: tab || "flow"};
    const tabs = h("div", {class: "adm-tabs"}), body = h("div", {class: "adm-body enc"});
    const defs = [["flow", "Xabar yo'li"], ["server", "Server ko'radi"], ["keys", "Kalitlar"], ["limits", "Halol chegaralar"]];
    const paint = () => { tabs.textContent = ""; defs.forEach(([k, t]) => tabs.append(h("button", {type: "button", class: st.tab === k ? "on" : "", text: t, onclick: () => { st.tab = k; paint(); load(); }}))); };
    const load = () => { body.textContent = ""; ({flow: encFlow, server: encServer, keys: encKeys, limits: encLimits})[st.tab](body); };
    paint(); load();
    return h("div", {}, sheetHead("🔒 Shifrlash: nima sodir bo'layapti?"), tabs, body);
  }, false, true);
}
const mono = (t, cls) => h("div", {class: "enc-mono" + (cls ? " " + cls : ""), text: t});
const step = (n, title, ...kids) => h("div", {class: "enc-step"}, h("div", {class: "enc-n", text: String(n)}), h("div", {class: "enc-b"}, h("b", {text: title}), ...kids));
const shortId = s => s && s.length > 28 ? s.slice(0, 22) + "…" + s.slice(-6) : (s || "");

function encFlow(body) {
  const out = h("div", {});
  const inp2 = h("textarea", {class: "fld", rows: "2", maxlength: "200"}); inp2.value = "Salom! Bu sinov matni 🙂";
  const go = h("button", {class: "btn", type: "button", text: "Shifrlab ko'rish (yuborilmaydi)"});
  go.onclick = async () => {
    out.textContent = "";
    try {
      if (!S.active) throw new Error("Avval biror suhbatni oching (guruh yoki lichka) — kalit shu suhbatniki");
      const ctx = await keyForActive(), text = inp2.value.slice(0, 200);
      const env = await sealFor(ctx, {t: text}), t = E2E.trace[E2E.trace.length - 1];
      const dm = S.active.kind === "dm", p = dm ? await peer(S.active.uid) : null;
      const pkt = JSON.stringify(Object.assign({type: "send", e2e: env}, dm ? {to: S.active.uid} : {}));
      out.append(
        step(1, "Sizning matningiz (faqat qurilmangizda)", mono(t.plain), h("small", {text: "Uzunlik yashirilishi uchun " + t.plainBytes + " baytgacha to'ldiriladi."})),
        step(2, dm ? "Kalit: ikkingiz orasidagi ECDH kaliti" : "Kalit: guruh kaliti (avlod " + ctx.ep + ")",
          mono(dm ? "Sizning xavfsizlik raqamingiz: " + X.fp + "\n" + U(S.active.uid).nickname + ": " + p.fp : "Kalit ID: " + (X.keyIds.get(ctx.ep) || "?") + "  (kalitning o'zi emas, faqat belgisi)"),
          h("small", {text: dm ? "Bu kalit faqat sizning va suhbatdoshingizning maxfiy kalitlaridan hosil bo'ladi; server ikkalasini ham bilmaydi." : "Guruh kaliti serverda yo'q: har bir a'zo uchun uning ommaviy kaliti bilan o'ralgan nusxasi bor."})),
        step(3, "AES-256-GCM bilan shifrlash", mono("IV (tasodifiy): " + t.iv + "\nShifr: " + t.ctBytes + " bayt (shu jumladan 16 baytlik tekshiruv tegi)")),
        step(4, "ECDSA imzosi (yuboruvchi — siz)", mono(t.sigBytes + " bayt. Hech kim sizning nomingizdan soxta xabar yarata olmaydi.")),
        step(5, "Serverga ketadigan paket (ilova darajasida)", mono(shortId(pkt) === pkt ? pkt : pkt.slice(0, 90) + " … " + pkt.slice(-40), "net"),
          h("small", {text: "Mana shu — serverga boradigan hamma narsa: matn yo'q, faqat shifr. To'liq konvert:"}), mono(env, "net long")));
    } catch (err) { out.append(h("div", {class: "adm-empty", text: err.message})); }
  };
  const wire = h("div", {});
  const paintWire = () => {
    wire.textContent = "";
    const fr = SC.wire.slice(-4).reverse();
    if (!fr.length) wire.append(h("div", {class: "adm-empty", text: "Hozircha kadr yo'q"}));
    fr.forEach(f => wire.append(h("div", {class: "enc-frame"},
      h("b", {text: (f.dir === "→" ? "Siz → server" : "server → siz") + " • " + new Date(f.ts).toLocaleTimeString() + " • " + f.bytes + " belgi"}),
      h("small", {text: "Server (kanal ochilgach) ko'radigan ilova JSON'i:"}), mono(f.app, "net"),
      h("small", {text: "Tarmoqda (Chrome Network, Wireshark) ko'rinadigani:"}), mono(f.net + "…", "net"))));
  };
  paintWire();
  body.append(
    h("p", {class: "adm-note", text: "Xabaringiz brauzeringizda shifrlanadi va faqat shifr serverga boradi. Sinab ko'ring: matn kiriting — pastda shifrlash qadamlari haqiqiy kalitingiz bilan ko'rsatiladi (xabar yuborilmaydi)."}),
    inp2, go, out,
    h("h4", {class: "enc-h", text: "Tarmoqdagi oxirgi haqiqiy kadrlar"}),
    h("p", {class: "adm-note", text: "Ikki qatlam: tashqi — brauzer↔server kanali (Wireshark shuni ko'radi); ichki — xabar konverti, uni faqat suhbat a'zolari ocha oladi. Server kanalni ochadi, lekin konvertni ocha olmaydi."}),
    h("button", {class: "btn ghost sm", type: "button", text: "Yangilash", onclick: paintWire}), wire);
}

async function encServer(body) {
  body.append(h("div", {class: "adm-empty", text: "Serverdan so'ralmoqda…"}));
  let j;
  try { j = await api("/e2ee/server-view" + (S.active && S.active.kind === "dm" ? "?to=" + S.active.uid : "")); }
  catch (err) { body.textContent = ""; admErr(body, err); return; }
  body.textContent = "";
  const scope = j.scope === "group" ? "Umumiy chat" : "Lichka: " + (S.active ? U(S.active.uid).nickname : "");
  body.append(h("p", {class: "adm-note", text: scope + " — serverning o'z bazasidagi so'nggi qatorlar (server aynan shuni qaytardi). Chap tomonda — qurilmangizda ochilgan matn, o'ngda — server va admin ko'radigani."}));
  const mine = new Map(currentMsgs().map(m => [m.id, m]));
  if (!j.rows.length) body.append(h("div", {class: "adm-empty", text: "Bu suhbatda hali xabar yo'q"}));
  j.rows.forEach(r => {
    const local = mine.get(r.id);
    const you = local ? (local.locked ? "🔒 (kalit kutilmoqda)" : local.bad ? "⚠ (ochib bo'lmadi)" : (local.content || (local.image ? "📷 rasm" : local.file ? (local.file.voice ? "🎤 ovozli xabar" : local.file.vnote ? "📹 video xabar" : "📎 " + local.file.name) : ""))) : "(bu xabar yuklanmagan)";
    body.append(h("div", {class: "enc-row"},
      h("div", {class: "enc-rh"}, h("b", {text: "#" + r.id + " • @" + r.from}), h("span", {text: " • " + fmtDT(r.ts) + " • " + r.stored_bytes + " bayt" + (r.blob_bytes ? " • fayl " + fmtSize(r.blob_bytes) + " (shifrlangan)" : "") + (r.deleted ? " • o'chirilgan" : "") + (r.edited ? " • tahrirlangan" : "")}),
        r.e2e ? null : h("span", {class: "flag b", text: "ESKI: server o'qiy oladi"})),
      h("div", {class: "enc-cols"},
        h("div", {}, h("small", {text: "SIZ KO'RASIZ (qurilmada ochilgan)"}), h("div", {class: "enc-you", text: you})),
        h("div", {}, h("small", {text: "SERVER BAZASIDA"}), mono(r.stored, "net")),
        h("div", {}, h("small", {text: "ADMIN LOGIDA"}), mono(r.admin_sees, "net")))));
  });
  const li = arr => h("ul", {class: "enc-ul"}, ...arr.map(t => h("li", {text: t})));
  body.append(
    h("h4", {class: "enc-h", text: "Server biladi"}), li(j.knows.biladi),
    h("h4", {class: "enc-h", text: "Server bilmaydi"}), li(j.knows.bilmaydi),
    h("h4", {class: "enc-h", text: "Sizning yozuvingiz serverda"}),
    mono("Ommaviy kalit (ECDH): " + shortId(j.me.ecdh_pub) + "\nOmmaviy kalit (imzo): " + shortId(j.me.sign_pub) + "\nMaxfiy kalitlar zaxirasi: " + j.me.key_blob_bytes + " bayt, parolingiz kalitida shifrlangan — serverda ochib bo'lmaydi" +
      "\nGuruh kaliti (sizga o'ralgan nusxa): " + (j.room.my_wrap ? "avlod " + j.room.my_wrap.epoch + ", o'ragan: @" + (U(j.room.my_wrap.by).username || j.room.my_wrap.by) : "hali yo'q"), "net"),
    h("h4", {class: "enc-h", text: "Harakatlaringiz logi (adminga ko'rinadigan)"}),
    ...(j.activity.length ? j.activity.map(a => h("div", {class: "enc-act", text: fmtDT(a.ts) + " • " + a.ip + " • " + a.action + (a.detail ? " • " + a.detail : "")})) : [h("div", {class: "adm-empty", text: "Yozuv yo'q"})]),
    j.legacy_messages ? h("p", {class: "adm-note warn", text: "⚠ Bazada hali " + j.legacy_messages + " ta ESKI (E2EE'dan oldingi) xabar bor — ularni server o'qiy oladi. Ega ularni Moderatsiya bo'limidan o'chira oladi."}) : h("p", {class: "adm-note ok", text: "✅ Bazada server o'qiy oladigan xabar yo'q."}));
}

async function encKeys(body) {
  const cur = X.epoch;
  body.append(
    h("p", {class: "adm-note", text: "Barmoq izi — kalitingizning qisqa belgisi. Suhbatdoshingiz bilan uni boshqa kanalda (yuzma-yuz, telefon) solishtiring: mos kelsa, o'rtada hech kim yo'q."}),
    h("h4", {class: "enc-h", text: "Sizning barmoq izingiz"}), mono(X.fp || "—", "fp"),
    h("button", {class: "btn ghost sm", type: "button", text: "Nusxalash", onclick: () => copyText(X.fp)}),
    h("h4", {class: "enc-h", text: "Guruh kaliti"}),
    mono("Joriy avlod: " + (cur || "yo'q") + (X.rooms.has(cur) ? " • sizda bor • kalit ID: " + X.keyIds.get(cur) : " • sizda hali yo'q") + "\nSizda bor avlodlar: " + ([...X.rooms.keys()].join(", ") || "—")));
  const changed = [...X.changed.entries()];
  if (changed.length) {
    body.append(h("p", {class: "adm-note warn", text: "⚠ Quyidagi foydalanuvchilarning kaliti ilgari ko'rganingizdan FARQ QILADI. Bu server almashtirgan kalit bo'lishi mumkin. Barmoq izini tekshirmaguncha ularga yozmang."}));
    changed.forEach(([uid, c]) => body.append(h("div", {class: "enc-row"}, h("b", {text: "@" + U(uid).username}), mono("Avval: " + c.old + "\nHozir: " + c.now),
      h("button", {class: "btn danger sm", type: "button", text: "Yangi kalitni qabul qilish", onclick: () => { acceptKeyChange(uid); toast("Qabul qilindi", "ok"); renderHeader(); body.textContent = ""; encKeys(body); }}))));
  }
  body.append(h("h4", {class: "enc-h", text: "A'zolar barmoq izlari"}));
  const list = h("div", {}); body.append(list);
  const members = S.members.filter(m => m.ek && m.id !== S.me.id).slice(0, 80);
  for (const m of members) {
    try {
      const p = await peer(m.id);
      list.append(h("div", {class: "enc-mem"}, h("b", {text: m.nickname + " @" + m.username}), mono(p.fp + (p.changed ? "   ⚠ O'ZGARGAN" : ""), p.changed ? "bad" : "fp")));
    } catch (_) {}
  }
  if (!members.length) list.append(h("div", {class: "adm-empty", text: "Boshqa a'zo yo'q"}));
}

function encLimits(body) {
  const li = arr => h("ul", {class: "enc-ul"}, ...arr.map(t => h("li", {text: t})));
  body.append(
    h("p", {class: "adm-note", text: "Haqiqiy E2EE nimani kafolatlaydi va nimani kafolatlamaydi — halol ro'yxat:"}),
    h("h4", {class: "enc-h", text: "✅ Kafolat"}),
    li(["Server, hosting egasi va admin xabar matnini, fayl mazmunini va nomini o'qiy olmaydi: ular faqat shifrni ko'radi.",
        "Parolingiz serverga umuman bormaydi — faqat undan olingan qaytarib bo'lmaydigan kirish kaliti boradi. Maxfiy kalitlaringiz parol kalitida shifrlangan.",
        "Har bir xabar imzolangan: server yoki boshqa a'zo sizning nomingizdan soxta xabar yarata olmaydi.",
        "Ban qilingan a'zodan keyin guruh kaliti yangilanadi: u yangi xabarlarni o'qiy olmaydi."]),
    h("h4", {class: "enc-h", text: "⚠ Cheklovlar"}),
    li(["Guruhga qo'shilgan har kim (admin ham, agar a'zo bo'lsa) o'z qurilmasida xabarlarni ko'radi — bu ochiq guruh: ro'yxatdan o'tgan har kim kalit oladi.",
        "Server yashirincha SOXTA a'zo qo'shib, unga kalit o'ratishi mumkin. Himoya: «Kalitlar» bo'limida barmoq izlarini tekshiring; ilgari ko'rilgan kalit o'zgarsa, ogohlantirish chiqadi.",
        "Bu sahifaning kodini ham server beradi. Zararli server kodni almashtirishi mumkin: SRI faqat tashqi o'zgarishdan himoya qiladi. To'liq ishonch uchun kodni tekshiring yoki serverni o'zingiz yuriting.",
        "Metama'lumotlar ko'rinadi: kim, qachon, kimga (lichkada), xabar hajmi, IP. Profil (nickname, bio, rasm) ochiq.",
        "Parolni yo'qotsangiz, eski xabarlarni tiklab bo'lmaydi (kalit zaxirasi faqat parol bilan ochiladi).",
        "Lichkada «oldinga maxfiylik» yo'q (kalit doimiy). Shikoyat yuborganingizda faqat o'sha bitta xabar ixtiyoriy ochib beriladi."]));
}
$("encBtn").addEventListener("click", () => openInspector("flow"));

function openSettings() {
  openModal(() => {
    const me = S.me;
    const gal = h("div", {class: "gal"});
    const nick = h("input", {type: "text", class: "fld", maxlength: "24"}); nick.value = me.nickname;
    const bio = h("textarea", {class: "fld", rows: "3", maxlength: "140", placeholder: "O'zingiz haqingizda…"}); bio.value = me.bio || "";
    const old = h("input", {type: "password", class: "fld", autocomplete: "current-password", maxlength: "128"});
    const nw = h("input", {type: "password", class: "fld", autocomplete: "new-password", maxlength: "128"});

    const loadGallery = async () => {
      try {
        const j = await api("/avatars");
        gal.textContent = "";
        j.avatars.forEach(a => {
          const del = h("button", {type: "button", title: "O'chirish", "aria-label": "O'chirish"}, icon("close"));
          del.addEventListener("click", async e => { e.stopPropagation(); try { await api("/avatars/" + a.id, {method: "DELETE"}); loadGallery(); } catch (err) { toast(err.message, "error"); } });
          const g = h("div", {class: "gi" + (a.active ? " act" : ""), title: a.active ? "Faol rasm" : "Faollashtirish"}, h("img", {src: a.url, alt: ""}), del);
          g.addEventListener("click", async () => { if (a.active) return; try { await api("/avatars/" + a.id + "/use", {method: "POST"}); loadGallery(); } catch (err) { toast(err.message, "error"); } });
          gal.append(g);
        });
        if (j.avatars.length < j.max) gal.append(h("button", {class: "btn ghost sm", type: "button", onclick: () => $("file").click()}, icon("camera", "ic vb"), " Rasm qo'shish"));
        if (j.avatars.some(a => a.active)) gal.append(h("button", {class: "btn ghost sm", type: "button", onclick: async () => { try { await api("/avatar/clear", {method: "POST"}); loadGallery(); } catch (err) { toast(err.message, "error"); } }}, "Rasmni olib tashlash"));
      } catch (_) {}
    };
    S.reloadGallery = loadGallery;
    loadGallery();

    const saveProfile = async () => {
      try { await api("/profile", {method: "PATCH", body: {nickname: nick.value, bio: bio.value}}); toast("Profil saqlandi", "ok"); }
      catch (err) { toast(err.message, "error"); }
    };
    const savePass = async () => {
      try {                                                    // maxfiy kalitlar yangi parol bilan brauzerda QAYTA O'RALADI
        if (!old.value) throw new Error("Eski parolni kiriting");
        if (nw.value.length < 6) throw new Error("Yangi parol kamida 6 belgi bo'lishi kerak");
        const info = await api("/me"), e = info.e2ee, un = S.me.username;
        const ko = await E2E.deriveFromPassword(un, old.value, e.kdf_iter || E2E.KDF_DEFAULT);
        let ident; try { ident = await E2E.unwrapIdentity(e.key_blob, ko.kek, un); } catch (_) { throw new Error("Eski parol noto'g'ri"); }
        const kn = await E2E.deriveFromPassword(un, nw.value, E2E.KDF_DEFAULT);
        await api("/password", {method: "POST", body: {old: ko.auth, new: kn.auth, key_blob: await E2E.wrapIdentity(ident, kn.kek, un), kdf_iter: E2E.KDF_DEFAULT}});
        old.value = ""; nw.value = ""; toast("Parol almashtirildi, kalitlar qayta o'raldi (boshqa qurilmalardan chiqarildingiz)", "ok");
      } catch (err) { toast(err.message, "error"); }
    };
    const dark = document.documentElement.dataset.theme === "dark";
    return h("div", {},
      sheetHead("Profilni tahrirlash"),
      h("div", {class: "sh-body"},
        gal,
        isStaff(me) ? colorSection() : null,
        isStaff(me) ? badgeSection() : null,
        h("div", {class: "setsec"},
          h("label", {class: "fl"}, "Nickname", nick),
          h("label", {class: "fl"}, "Bio", bio),
          h("button", {class: "btn", type: "button", onclick: saveProfile}, "Saqlash")),
        h("div", {class: "setsec"}, h("h4", {text: "Parolni almashtirish"}),
          h("label", {class: "fl"}, "Eski parol", old),
          h("label", {class: "fl"}, "Yangi parol (kamida 6 belgi)", nw),
          h("button", {class: "btn ghost", type: "button", onclick: savePass}, "Parolni almashtirish")),
        h("div", {class: "setsec row-b"},
          h("button", {class: "btn ghost", type: "button", onclick: () => { toggleTheme(); closeModal(); }}, dark ? "Kunduzgi mavzu" : "Tungi mavzu"),
          h("button", {class: "btn danger", type: "button", onclick: () => { closeModal(); logout(); }}, "Chiqish")),
        me.role === "owner" ? null : h("div", {class: "setsec"}, h("h4", {text: "Xavfli hudud"}),
          h("button", {class: "btn ghost dangerline", type: "button", onclick: deleteMyAccount}, "Akkauntni o'chirish"))));
  }, false);
}
async function deleteMyAccount() {
  const ok = await confirmDlg("Akkauntingiz butunlay o'chiriladi: profil, rasmlar va parol yo'qoladi. Yozgan xabarlaringiz chatda \"Deleted account\" nomi bilan qoladi. Buni qaytarib bo'lmaydi.",
    {title: "Akkauntni o'chirish", okText: "Davom etish", danger: true});
  if (!ok) return;
  const pw = await promptDlg("Parolni tasdiqlang", "Akkauntni o'chirish uchun parolingizni kiriting:", "", {type: "password", okText: "O'chirish", danger: true});
  if (pw === null) return;
  try {
    const e = (await api("/me")).e2ee, kd = await E2E.deriveFromPassword(S.me.username, pw, e.kdf_iter || E2E.KDF_DEFAULT);
    await api("/account/delete", {method: "POST", body: {password: kd.auth}}); showAuth("Akkauntingiz o'chirildi");
  }
  catch (err) { toast(err.message, "error"); }
}
const PRESETS = ["#f7b733", "#7b61ff", "#ef4444", "#f97316", "#22c55e", "#14b8a6", "#3b82f6", "#ec4899"];
function colorSection() {
  const sec = h("div", {class: "setsec"}, h("h4", {text: "Profil rangi"}));
  const preview = h("div", {class: "pname", style: null}), sw = h("div", {class: "swatches"});
  preview.style.fontSize = "17px"; preview.style.margin = "0 0 10px";
  const save = async c => {
    try {
      const j = await api("/profile", {method: "PATCH", body: {color: c}});
      upsertUser(j.me); paint(); renderList(); renderHeader(); renderMessages(false);
      toast(c ? "Rang saqlandi" : "Standart rang tiklandi", "ok");
    } catch (err) { toast(err.message, "error"); }
  };
  const paint = () => {
    preview.textContent = ""; preview.append(nameEl(S.me, {big: true}));
    sw.textContent = "";
    const cur = (S.me.color || "").toLowerCase();
    PRESETS.forEach(c => {
      const b = h("button", {type: "button", class: "sw" + (cur === c ? " on" : ""), title: c, "aria-label": c});
      b.style.background = c; b.addEventListener("click", () => save(c)); sw.append(b);
    });
    const pick = h("input", {type: "color"}); pick.value = HEX.test(cur) ? cur : TONES[S.me.role];
    pick.addEventListener("change", () => save(pick.value));
    sw.append(h("label", {class: "sw-custom", title: "Boshqa rang tanlash"}, pick),
      h("button", {type: "button", class: "btn ghost sm", text: "Standart", onclick: () => save("")}));
  };
  paint(); sec.append(preview, sw);
  return sec;
}
$("file").addEventListener("change", async () => {
  const f = $("file").files[0]; $("file").value = ""; if (!f) return;
  if (f.size > 2 * 1024 * 1024) { toast("Rasm 2 MB dan oshmasligi kerak", "error"); return; }
  const fd = new FormData(); fd.append("file", f);
  try { await api("/avatar", {method: "POST", body: fd}); toast("Profil rasmi yangilandi", "ok"); if (S.reloadGallery) S.reloadGallery(); }
  catch (err) { toast(err.message, "error"); }
});

/* =====================================================================
   MOBIL (v5): orqaga tugmasi, klaviatura, uzoq bosish, chapga surish, varaqni pastga tortish
   ===================================================================== */
const haptic = ms => { try { if (navigator.vibrate) navigator.vibrate(ms); } catch (_) {} };
document.addEventListener("touchstart", () => {}, {passive: true});          // iOS: :active holati ishlashi uchun

/* ---- Orqaga tugmasi / jest: chat, oyna, rasm, menyu, dialog — har biri tarixda alohida qatlam ---- */
const NAV = {stack: [], ops: [], busy: false, timer: 0};
const NAV_CLOSE = {
  chat: () => closeChat(), modal: () => closeModal(), lb: () => closeLightbox(),
  ctx: () => closeCtx(), sel: () => exitSelect(), dlg: () => { if (S.dlgCancel) S.dlgCancel(); },
  cm: () => Channels.closeComments(true),                   // kanal posti izohlari paneli
};
function navKick() {                                  // tarix amallari ketma-ket bajariladi (back() tugamay turib push qilinmaydi)
  while (!NAV.busy && NAV.ops.length) {
    const op = NAV.ops.shift();
    if (op.t === "push") { try { history.pushState({tc: op.d}, ""); } catch (_) {} }
    else {
      NAV.busy = true; clearTimeout(NAV.timer);
      NAV.timer = setTimeout(() => { NAV.busy = false; navKick(); }, 450);
      try { history.back(); } catch (_) { NAV.busy = false; }
    }
  }
}
function navPush(name) {
  if (NAV.stack.includes(name)) return;
  NAV.stack.push(name); NAV.ops.push({t: "push", d: NAV.stack.length}); navKick();
}
function navPop(name) {
  const i = NAV.stack.lastIndexOf(name); if (i < 0) return;
  const top = i === NAV.stack.length - 1;
  NAV.stack.splice(i, 1);
  if (top) { NAV.ops.push({t: "back"}); navKick(); }
}
function navReset() {
  const n = NAV.stack.length; NAV.stack.length = 0; NAV.ops.length = 0;
  if (n) try { history.go(-n); } catch (_) {}
}
addEventListener("popstate", e => {
  if (NAV.busy) { NAV.busy = false; clearTimeout(NAV.timer); navKick(); return; }   // o'zimiz chaqirgan back()
  const target = (e.state && e.state.tc) | 0;
  while (NAV.stack.length > target) { const fn = NAV_CLOSE[NAV.stack.pop()]; if (fn) fn(); }
});
try { if (history.state && history.state.tc) history.replaceState(null, ""); } catch (_) {}

/* ---- Klaviatura: iOS/Android'da ilova ko'rinadigan oynaga sig'adi, yozish paneli klaviatura ustida qoladi ---- */
(() => {
  const vv = window.visualViewport;
  if (!vv || !COARSE) return;
  const root = document.documentElement;
  let raf = 0;
  const isField = el => !!el && (el.tagName === "TEXTAREA" || (el.tagName === "INPUT" && !/^(checkbox|radio|button|submit|reset|file|range|color|image)$/i.test(el.type)));
  const sync = () => {
    raf = 0;
    if (vv.scale > 1.02) { root.style.removeProperty("--vvh"); root.style.removeProperty("--vvt"); document.body.classList.remove("kb"); return; }   // foydalanuvchi yaqinlashtirgan
    const shrunk = innerHeight - vv.height;
    if (shrunk > 60 || vv.offsetTop > 1) { root.style.setProperty("--vvh", vv.height + "px"); root.style.setProperty("--vvt", vv.offsetTop + "px"); }
    else { root.style.removeProperty("--vvh"); root.style.removeProperty("--vvt"); }
    document.body.classList.toggle("kb", shrunk > 120 && isField(document.activeElement));
    if (scrollY) scrollTo(0, 0);
    const b = $("msgs"); if (b && b._stick) b.scrollTop = b.scrollHeight;
  };
  const queue = () => { if (!raf) raf = requestAnimationFrame(sync); };
  vv.addEventListener("resize", queue); vv.addEventListener("scroll", queue);
  addEventListener("orientationchange", () => setTimeout(queue, 350));
  document.addEventListener("focusin", () => setTimeout(queue, 60));
  document.addEventListener("focusout", () => setTimeout(queue, 120));
})();

/* ---- Uzoq bosish (ro'yxat elementlari uchun; iOS'da contextmenu hodisasi yo'q) ---- */
function longPress(el, fn) {
  let t = 0, sx = 0, sy = 0, quiet = 0;
  el.addEventListener("touchstart", e => {
    if (e.touches.length !== 1) return;
    sx = e.touches[0].clientX; sy = e.touches[0].clientY; clearTimeout(t);
    t = setTimeout(() => { quiet = Date.now() + 600; haptic(12); fn(sx, sy); }, 480);
  }, {passive: true});
  el.addEventListener("touchmove", e => { const p = e.touches[0]; if (Math.abs(p.clientX - sx) > 9 || Math.abs(p.clientY - sy) > 9) clearTimeout(t); }, {passive: true});
  ["touchend", "touchcancel"].forEach(ev => el.addEventListener(ev, () => clearTimeout(t), {passive: true}));
  el.addEventListener("click", e => { if (Date.now() < quiet) { e.preventDefault(); e.stopImmediatePropagation(); } }, true);
}

/* ---- Xabar pufagi: uzoq bosish = menyu; chapga surish = javob berish (Telegram kabi) ---- */
function canSwipeReply(m) {
  const c = $("chat");
  return !S.sel && !m.service && !m.locked && !m.bad && !m.legacy && !c.classList.contains("dead") && !c.classList.contains("locked");
}
function attachTouch(bubble, row, m) {
  const TH = 56;                                       // javob uchun yetarli surish (px)
  let tPress = 0, tCtx = 0, sx = 0, sy = 0, dx = 0, mode = "", ind = null, hit = false, quiet = 0;
  const stopTimers = () => { clearTimeout(tPress); clearTimeout(tCtx); tPress = tCtx = 0; row.classList.remove("pressing"); };
  bubble.addEventListener("click", e => { if (Date.now() < quiet) { e.preventDefault(); e.stopPropagation(); } }, true);   // uzoq bosishdan keyin rasm/fayl ochilmasin
  bubble.addEventListener("touchstart", e => {
    stopTimers(); dx = 0; hit = false;
    if (S.sel || e.touches.length !== 1) { mode = "x"; return; }
    mode = "";
    const t = e.touches[0]; sx = t.clientX; sy = t.clientY;
    tPress = setTimeout(() => row.classList.add("pressing"), 140);
    tCtx = setTimeout(() => { tCtx = 0; mode = "ctx"; row.classList.remove("pressing"); haptic(12); openCtx(sx, sy, m); }, 450);
  }, {passive: true});
  bubble.addEventListener("touchmove", e => {
    if (mode !== "" && mode !== "swipe") return;
    const t = e.touches[0], mx = t.clientX - sx, my = t.clientY - sy;
    if (mode === "") {
      if (Math.abs(mx) < 9 && Math.abs(my) < 9) return;            // barmoq titrashi uzoq bosishni bekor qilmaydi
      stopTimers();
      const skip = e.target.closest && e.target.closest(".vtrack,.vspd,.mplayer,.code-scroll,.term-scroll,.cbtn");
      if (Math.abs(mx) < Math.abs(my) * 1.5 || mx > 0 || skip || !canSwipeReply(m)) { mode = "scroll"; return; }
      mode = "swipe"; bubble.style.transition = "none";
      ind = h("span", {class: "swipe-ind", "aria-hidden": "true"}, icon("reply")); row.append(ind);
    }
    const raw = mx < 0 ? -mx : 0;                                  // barmoq yurgan masofa
    dx = -(raw <= TH ? raw : TH + (raw - TH) * 0.2);              // chegaradan keyin qarshilik (pufak chetdan chiqib ketmaydi)
    const k = Math.min(1, raw / TH);
    bubble.style.transform = "translateX(" + dx + "px)";
    ind.style.opacity = String(k); ind.style.transform = "scale(" + (0.6 + 0.4 * k) + ")";
    const nowHit = raw >= TH;
    if (nowHit !== hit) { hit = nowHit; row.classList.toggle("swipe-hit", hit); if (hit) haptic(8); }
  }, {passive: true});
  const end = cancelled => {
    stopTimers();
    if (mode === "ctx") quiet = Date.now() + 600;
    if (mode === "swipe") {
      const fire = !cancelled && hit;
      bubble.style.transition = ""; bubble.style.transform = "";
      if (ind) { const el = ind; el.style.opacity = "0"; setTimeout(() => el.remove(), 220); ind = null; }
      row.classList.remove("swipe-hit");
      quiet = Date.now() + 400;
      if (fire) startReply(m);
    }
    mode = ""; hit = false;
  };
  bubble.addEventListener("touchend", () => end(false), {passive: true});
  bubble.addEventListener("touchcancel", () => end(true), {passive: true});
}

/* ---- Pastdan chiqadigan oyna: sarlavhadan pastga tortib yopiladi ---- */
(() => {
  const sheet = $("sheet");
  let y0 = 0, dy = 0, drag = false;
  sheet.addEventListener("touchstart", e => {
    drag = false;
    if (!isMobile() || e.touches.length !== 1 || !e.target.closest(".sh-head, .pbanner")) return;
    y0 = e.touches[0].clientY; dy = 0; drag = true;
  }, {passive: true});
  sheet.addEventListener("touchmove", e => {
    if (!drag) return;
    dy = Math.max(0, e.touches[0].clientY - y0);
    if (dy > 6) { sheet.style.transition = "none"; sheet.style.transform = "translateY(" + dy + "px)"; }
  }, {passive: true});
  const end = () => {
    if (!drag) return; drag = false;
    const close = dy > 110; dy = 0;
    sheet.style.transition = "transform .2s ease";
    sheet.style.transform = close ? "translateY(100%)" : "";
    setTimeout(() => { if (close) closeModal(); sheet.style.transition = ""; sheet.style.transform = ""; }, 200);
  };
  sheet.addEventListener("touchend", end, {passive: true});
  sheet.addEventListener("touchcancel", end, {passive: true});
})();

/* ---------------- ishga tushirish ---------------- */
/* ---------------- kanallar (js/channels.js) ---------------- */
const chBridge = {api, h, icon, toast, confirmDlg, promptDlg, openModal, closeModal, sheetHead, navPush, navPop, hhmm, dayLabel, avatar, nameEl,
                  amAdmin: () => amAdmin(), me: () => S.me, openMenu, openProfile: id => openProfile(id), setChannelList, chanAvatar, patchPost,
                  openChat, closeChat, active: () => S.active, info: chInfo, hydrateComment, sealComment, renderList, renderHeader,
                  list: () => S.chList, isMobile, fmtDT: ts => fmtDT(ts)};
function openApp() {
  resetState();
  $("auth").classList.add("hidden"); $("app").classList.remove("hidden");
  document.querySelectorAll(".tabs button").forEach(x => x.classList.toggle("on", x.dataset.tab === "chats"));
  $("chat").classList.add("hidden"); $("empty").classList.remove("hidden");
  S.wantClose = false;
  loadEmojis();                                                                     // emoji katalogi: tayyor + admin yaratgan emojilar, ruxsatlar
  X.ready = (async () => { await loadMembers(); try { await loadRoom(); } catch (_) {} applyPendingOpen(); })();
  connect();
  Channels.init(chBridge); Channels.loadList().then(applyPendingChannel).catch(() => {});                // kanallar ro'yxati (ko'rinmagan postlar belgisi uchun)
  Push.sync(api).catch(() => {});                                                   // ruxsat berilgan bo'lsa, obuna serverda ekaniga ishonch hosil qilamiz
  setTimeout(askNotifications, 2500);                                               // birinchi marta: ruxsat so'raymiz
}
/* Har safar sahifa ochilganda login oynasi chiqadi (avtomatik kirish yo'q). Eski qurilmada qolgan kalitlar ham tozalanadi. */
(function boot() {
  let tok = ""; try { tok = localStorage.getItem(LS_STAY) || ""; } catch (_) {}
  if (tok) resumeStay(tok, 0);                                   // foydalanuvchi o'zi login so'rashni o'chirgan qurilma
  else { try { E2E.clearIdentity(); } catch (_) {} }             // aks holda har ochilganda login (eski qurilmada qolgan kalitlar ham tozalanadi)
})();
/* Kalitli xodim (Hevorix/admin) onlayn ekan, kaliti yo'q yangi a'zolarga guruh kalitini muntazam o'rab beradi */
setInterval(() => { if (S.token && S.me && isStaff(S.me) && X.rooms.size) serveWraps(); }, 30000);
})();


/* ---------------- Uzun nickname: "…" bilan qisqaradi, ustiga borilganda sekin siljiydi ---------------- */
(function () {
  let cur = null, raf = 0, timer = 0;
  const HOST = ".item, .pname, .hinfo, .bname, .rq";
  function stop() {
    cancelAnimationFrame(raf); clearTimeout(timer);
    if (cur) { cur.scrollLeft = 0; cur.style.textOverflow = ""; cur.classList.remove("scrolling"); }
    cur = null;
  }
  function start(nt) {
    const max = nt.scrollWidth - nt.clientWidth;
    if (max <= 2) return;
    cur = nt; nt.style.textOverflow = "clip"; nt.classList.add("scrolling");
    const SPEED = 45;                       // px/soniya
    const run = (dir, from) => {
      const t0 = performance.now();
      const step = now => {
        if (cur !== nt) return;
        const d = Math.min(1, (now - t0) / ((max / SPEED) * 1000));
        nt.scrollLeft = dir > 0 ? max * d : max * (1 - d);
        if (d < 1) raf = requestAnimationFrame(step);
        else timer = setTimeout(() => { if (cur === nt) run(-dir); }, 700);
      };
      raf = requestAnimationFrame(step);
    };
    timer = setTimeout(() => { if (cur === nt) run(1); }, 350);
  }
  document.addEventListener("mouseover", e => {
    const host = e.target.closest && e.target.closest(HOST);
    const nt = host && host.querySelector(".nm .nt");
    if (nt === cur) return;
    stop();
    if (nt) start(nt);
  });
  document.addEventListener("mouseleave", stop);
  document.addEventListener("scroll", stop, true);
})();
