"use strict";
(() => {
/* =====================================================================
   Anonim Chat by Hevorix — veb-mijoz
   Matn DOM'ga faqat textContent orqali chiqariladi (XSS yo'q, CSP qat'iy).
   ===================================================================== */
const NS = "http://www.w3.org/2000/svg";
const $ = id => document.getElementById(id);
const APP_NAME = "Anonim Chat by Hevorix";
const LS_THEME = "termchat_theme";
const LS_STAY = "termchat_stay";                // "bu qurilmada kirib qolish" yoqilgan bo'lsa — sessiya tokeni (foydalanuvchi o'zi tanlaydi)
const WS_UNAUTHORIZED = 4401, WS_FORBIDDEN = 4403, WS_IP_BLOCKED = 4410;
const IDLE_MS = 5 * 60 * 1000;                   // oyna/chat ochiq, lekin 5 daqiqa tegilmasa — qayta login talab qilinadi
const HB_MS = 15000, HB_DEAD_MS = 40000;         // yurak urishi: har 15 s ping; 40 s server javobi yo'q bo'lsa ulanish o'lik hisoblanadi
const delay = ms => new Promise(r => setTimeout(r, ms));
try { localStorage.removeItem("termchat_token"); } catch (_) {}      // eski versiyada saqlangan token endi ishlatilmaydi
const PALETTE = ["#e17076", "#e0954f", "#a695e7", "#7bc862", "#4fb6b9", "#65aadd", "#ee7aae"];
const MONTHS = ["yanvar", "fevral", "mart", "aprel", "may", "iyun", "iyul", "avgust", "sentabr", "oktabr", "noyabr", "dekabr"];
const COARSE = matchMedia("(pointer: coarse)").matches;
const isMobile = () => matchMedia("(max-width: 760px)").matches;

const S = {
  token: null, me: null, ws: null, retry: 0, wantClose: false, mode: "login",
  users: new Map(),            // id -> foydalanuvchi
  members: [],                 // a'zolar ro'yxati (serverdan)
  online: new Set(),
  group: {msgs: [], unread: 0, more: false},   // more: tepada yana eski xabarlar bor (tepaga chiqilganda yuklanadi)
  dms: new Map(),              // uid -> {msgs, loaded, buffer, unread, last}
  chn: new Map(),              // kanal id -> {msgs, loaded, buffer, unread, last, more} (kanal postlari, umumiy chat bilan bir xil xabar tizimi)
  chList: [],                  // kanallar ro'yxati (serverdan; js/channels.js yangilaydi)
  active: null,                // {kind:"group"} | {kind:"dm", uid} | {kind:"channel", id}
  tab: "chats", query: "", editing: null, away: 0, modal: null,
  replying: null,              // {id, nickname, text, image} — javob berilayotgan xabar
  pendingImg: null,            // {blob, url, name} — yuborishga tayyor rasm
  sending: false,
  rec: null, recBusy: false, recTimer: 0,   // ovoz/video yozilmoqda: Voice.record() yoki VNote.record() obyekti
  recKind: "voice", recMode: "voice", vfacing: "user", starting: false, startAbort: false, flipping: false, noClickUntil: 0,   // recMode: tugma rejimi (voice | video)
  imgs: new Map(),             // xabar id -> "loading" | "open" (rasm yuklash holati)
  sel: null,                   // Set<id> — belgilash rejimi yoqilgan bo'lsa
  played: new Map(),           // xabar id -> blob URL (ijro etilgan video/audio)
  previews: new Map(),         // xabar id -> {kind:"code"|"pcap", ...} — fayl ko'rinishi (faqat matn sifatida, hech narsa ishga tushmaydi)
  fx: new Map(),               // terminal animatsiyasi: kalit -> birinchi chizilgan vaqt (qayta-qayta animatsiya bo'lmasin)
  chat: {slowmode: 0, locked: false},   // umumiy chat moderatsiya holati (serverdan)
};

/* ---------------- yordamchilar ---------------- */
function h(tag, props, ...kids) {
  const e = document.createElement(tag);
  if (props) for (const [k, v] of Object.entries(props)) {
    if (v == null || v === false) continue;
    if (k === "class") e.className = v;
    else if (k === "text") e.textContent = v;
    else if (k.startsWith("on")) e.addEventListener(k.slice(2), v);
    else e.setAttribute(k, v === true ? "" : v);
  }
  for (const c of kids.flat()) {
    if (c == null || c === false) continue;
    e.append(c.nodeType ? c : document.createTextNode(String(c)));
  }
  return e;
}
function svgUse(href, cls) {
  const s = document.createElementNS(NS, "svg"); s.setAttribute("class", cls);
  const u = document.createElementNS(NS, "use"); u.setAttribute("href", href); s.append(u);
  return s;
}
const icon = (name, cls) => svgUse("#i-" + name, cls || "ic");
const pad2 = n => String(n).padStart(2, "0");
const hhmm = ts => { const d = new Date(ts * 1000); return pad2(d.getHours()) + ":" + pad2(d.getMinutes()); };
const dayKey = ts => { const d = new Date(ts * 1000); return d.getFullYear() + "-" + d.getMonth() + "-" + d.getDate(); };
function dayLabel(ts) {
  const d = new Date(ts * 1000), now = new Date();
  if (dayKey(ts) === dayKey(now / 1000)) return "Bugun";
  const y = new Date(now); y.setDate(now.getDate() - 1);
  if (dayKey(ts) === dayKey(y / 1000)) return "Kecha";
  return d.getDate() + "-" + MONTHS[d.getMonth()] + (d.getFullYear() !== now.getFullYear() ? ", " + d.getFullYear() : "");
}
function listTime(ts) {
  const d = new Date(ts * 1000), now = new Date();
  if (dayKey(ts) === dayKey(now / 1000)) return hhmm(ts);
  const y = new Date(now); y.setDate(now.getDate() - 1);
  if (dayKey(ts) === dayKey(y / 1000)) return "Kecha";
  return pad2(d.getDate()) + "." + pad2(d.getMonth() + 1) + "." + String(d.getFullYear()).slice(2);
}
const colorOf = id => PALETTE[Math.abs(id) % PALETTE.length];
const isStaff = u => !!u && (u.role === "owner" || u.role === "admin");
const HEX = /^#[0-9a-f]{6}$/i, TONES = {owner: "#f7b733", admin: "#7b61ff"};
const hexRgb = x => { const n = parseInt(x.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
const mixHex = (x, to, t) => "#" + hexRgb(x).map((v, i) => Math.round(v + (to[i] - v) * t).toString(16).padStart(2, "0")).join("");
function toneOf(u) {
  const base = HEX.test(u.color || "") ? u.color.toLowerCase() : TONES[u.role];
  const [r, g, b] = hexRgb(base);
  return {p2: base, p1: mixHex(base, [255, 255, 255], .55), p3: mixHex(base, [0, 0, 0], .4), pr: r + "," + g + "," + b,
    pt: (0.299 * r + 0.587 * g + 0.114 * b) / 255 > .6 ? "#2b2000" : "#fff"};
}
/** Ega/admin elementiga o'zi tanlagan rangni beradi (CSS o'zgaruvchilari; CSP uchun CSSOM orqali). */
function tint(el, u) {
  if (!isStaff(u)) return el;
  const t = toneOf(u);
  ["p1", "p2", "p3", "pr", "pt"].forEach(k => el.style.setProperty("--" + k, t[k]));
  return el;
}
const roleLabel = r => r === "owner" ? "Platforma egasi" : r === "admin" ? "Administrator" : "";
const U = id => S.users.get(id) || {id, nickname: "Noma'lum", username: "?", role: "user", bio: "", avatar: null};
const isOnline = id => S.me && (id === S.me.id || S.online.has(id));
const onlineCount = () => new Set([...S.online, S.me.id]).size;
const amAdmin = () => isStaff(S.me);
const dmOf = uid => {
  if (!S.dms.has(uid)) S.dms.set(uid, {msgs: [], loaded: false, buffer: [], unread: 0, last: null, more: false});
  return S.dms.get(uid);
};
const chOf = id => {
  if (!S.chn.has(id)) S.chn.set(id, {msgs: [], loaded: false, buffer: [], unread: 0, last: null, more: false});
  return S.chn.get(id);
};
const chInfo = id => S.chList.find(c => c.id === id) || null;
const isActiveChan = id => !!S.active && S.active.kind === "channel" && S.active.id === id;
function upsertUser(u) {
  if (!u || u.id == null) return;
  const merged = Object.assign({}, S.users.get(u.id), u);
  S.users.set(u.id, merged);
  if (S.me && u.id === S.me.id) S.me = Object.assign({}, S.me, u);
}

function toast(text, level) {
  const t = h("div", {class: "toast " + (level || "info"), text});
  $("toasts").append(t);
  while ($("toasts").children.length > 4) $("toasts").firstChild.remove();
  setTimeout(() => t.remove(), level === "error" ? 5000 : 3500);
}

async function api(path, opts = {}) {
  const headers = Object.assign({Authorization: "Bearer " + S.token}, opts.headers || {});
  let body = opts.body;
  if (body && !(body instanceof FormData)) { headers["Content-Type"] = "application/json"; body = JSON.stringify(body); }
  const r = await SC.fetch("/api" + path, {method: opts.method || "GET", headers, body});
  const j = await r.json().catch(() => ({}));
  if (r.status === 401) { showAuth("Sessiya tugagan, qayta kiring"); throw new Error("401"); }
  if (!r.ok) throw new Error(typeof j.detail === "string" ? j.detail : "Xato, qayta urinib ko'ring");
  return j;
}
function wsTry(obj) {                                  // jimjit yuborish: xato/toast yo'q; ulanish bo'lmasa false (xabar navbatda kutadi)
  if (S.offline || !S.ws || S.ws.readyState !== 1) return false;
  try { S.ws.send(JSON.stringify(obj)); return true; } catch (_) { return false; }
}
function wsSend(obj) {
  if (S.offline) { toast("Oflayn rejim: faqat o'qish mumkin", "error"); return false; }
  if (!S.ws || S.ws.readyState !== 1) { toast("Ulanish yo'q, biroz kuting…", "error"); return false; }
  S.ws.send(JSON.stringify(obj));
  return true;
}

/* ---------------- E2EE: kalitlar, guruh kaliti, xabarlarni shifrlash/ochish ----------------
   Serverga faqat shifrlangan konvert ketadi. Maxfiy kalitlar qurilmada (IndexedDB, eksport qilib bo'lmaydigan) va
   parol bilan o'ralgan zaxirada (serverda, ochib bo'lmaydigan) saqlanadi. Protokol: js/e2ee.js */
const LS_PINS = "termchat_pins";
const X = {id: 0, username: "", priv: null, ecdhPub: "", signPub: "", fp: "", iter: 0, self: null, rooms: new Map(), keyIds: new Map(),
           epoch: 0, state: null, peers: new Map(), peerReq: new Map(), pending: new Set(), changed: new Map(), ready: null, serving: false, rotating: false};
function xReset() {
  X.id = 0; X.priv = null; X.self = null; X.rooms = new Map(); X.keyIds = new Map(); X.epoch = 0; X.state = null; X.peers = new Map(); X.peerReq = new Map();
  X.pending = new Set(); X.changed = new Map(); X.ready = null; X.serving = false; X.rotating = false;
}
const pinStore = () => { try { return JSON.parse(localStorage.getItem(LS_PINS + "_" + X.id) || "{}"); } catch (_) { return {}; } };
const savePins = p => { try { localStorage.setItem(LS_PINS + "_" + X.id, JSON.stringify(p)); } catch (_) {} };

/* --- shaxsiy kalitlarni sessiyaga o'rnatish --- */
async function xInstall(me, username, ident, pubs, iter, remember) {
  const priv = await E2E.importPrivate(ident);
  X.id = me.id; X.username = username; X.priv = priv; X.ecdhPub = pubs.ecdh_pub; X.signPub = pubs.sign_pub; X.iter = iter;
  X.self = await E2E.importPeer({e: pubs.ecdh_pub, s: pubs.sign_pub}); X.fp = X.self.fp;
  /* Maxfiy kalitlar qurilmada SAQLANMAYDI: har kirishda username + parol so'raladi, kalitlar paroldan qayta hosil bo'ladi. */
}
async function xGenerate(username, password, iter) {
  const kd = await E2E.deriveFromPassword(username, password, iter);
  const ident = await E2E.generateIdentity();
  const keys = {ecdh_pub: ident.ecdhPub, sign_pub: ident.signPub, key_blob: await E2E.wrapIdentity(ident, kd.kek, username), kdf_iter: iter};
  return {kd, ident, keys};
}
/* --- tizimga kirgandan keyin: kalitlarni tayyorlash (yangi akkaunt, eski akkauntni yangilash yoki parol bilan ochish) --- */
async function xUnlock(info, me, username, password) {
  if (info.upgrade) {                                           // eski akkaunt: kalitlar brauzerda yaratiladi, parol hash'i almashadi
    const g = await xGenerate(username, password, E2E.KDF_DEFAULT);
    await api("/e2ee/setup", {method: "POST", body: {old: password, auth: g.kd.auth, keys: g.keys}});
    await xInstall(me, username, g.ident, g.keys, E2E.KDF_DEFAULT, true);
    return;
  }
  const e = info.e2ee, kd = await E2E.deriveFromPassword(username, password, e.kdf_iter || E2E.KDF_DEFAULT);
  let ident;
  try { ident = await E2E.unwrapIdentity(e.key_blob, kd.kek, username); } catch (_) { throw new Error("Parol noto'g'ri (kalitlarni ochib bo'lmadi)"); }
  await xInstall(me, username, ident, e, e.kdf_iter || E2E.KDF_DEFAULT, true);
}
/* --- sahifa yangilanganda: kalitlar qurilmada bo'lsa parolsiz, bo'lmasa parol so'rab --- */
async function xRestore(info, me) {
  if (!info.upgrade && info.e2ee.ecdh_pub) {
    const rec = await E2E.loadIdentity(me.id);
    if (rec && rec.ecdhPub === info.e2ee.ecdh_pub && rec.signPub === info.e2ee.sign_pub) {
      X.id = me.id; X.username = me.username; X.priv = {ecdhPriv: rec.ecdhPriv, signPriv: rec.signPriv};
      X.ecdhPub = rec.ecdhPub; X.signPub = rec.signPub; X.iter = rec.iter || info.e2ee.kdf_iter;
      X.self = await E2E.importPeer({e: rec.ecdhPub, s: rec.signPub}); X.fp = X.self.fp;
      return true;
    }
  }
  for (let tries = 0; tries < 5; tries++) {
    const pw = await promptDlg(info.upgrade ? "Shifrlashni yoqish" : "Kalitlarni ochish",
      info.upgrade ? "Xabarlaringiz endi uchdan-uchga shifrlanadi. Davom etish uchun parolingizni kiriting (kalitlar shu qurilmada yaratiladi)."
        : "Shifrlash kalitlari bu qurilmada yo'q. Ularni ochish uchun parolingizni kiriting.", "", {type: "password", okText: "Ochish"});
    if (pw === null) return false;
    try { await xUnlock(info, me, me.username, pw); return true; } catch (err) { toast(err.message, "error"); }
  }
  return false;
}

/* --- boshqa foydalanuvchilarning ommaviy kalitlari (+ barmoq izini qadash, TOFU) --- */
function peer(uid) {
  if (uid === X.id) return Promise.resolve(X.self);
  const p = X.peers.get(uid);
  if (p) return Promise.resolve(p);
  let req = X.peerReq.get(uid);                          // bir vaqtda bir xil kalit so'rovi takrorlanmaydi
  if (!req) { req = loadPeer(uid).finally(() => X.peerReq.delete(uid)); X.peerReq.set(uid, req); }
  return req;
}
async function loadPeer(uid) {
  let p;
  const m = S.members.find(x => x.id === uid);
  let keys = m && m.ek ? {e: m.ek, s: m.sk} : null;
  if (!keys) { const j = await api("/e2ee/keys?ids=" + uid); keys = j.keys[String(uid)]; }
  if (!keys) throw new Error("Bu foydalanuvchida E2EE kalitlari yo'q");
  p = await E2E.importPeer(keys);
  const pins = pinStore();
  if (pins[uid] && pins[uid] !== p.fp) { p.changed = true; X.changed.set(uid, {old: pins[uid], now: p.fp}); }
  else if (!pins[uid]) { pins[uid] = p.fp; savePins(pins); }
  X.peers.set(uid, p);
  return p;
}
function acceptKeyChange(uid) {
  const c = X.changed.get(uid); if (!c) return;
  const pins = pinStore(); pins[uid] = c.now; savePins(pins);
  X.changed.delete(uid); const p = X.peers.get(uid); if (p) p.changed = false;
}

/* --- guruh kaliti --- */
async function loadRoom() {
  const st = await api("/e2ee/room"); X.state = st; X.epoch = st.epoch;
  for (const w of st.mine) {
    if (X.rooms.has(w.epoch)) continue;
    const ep = st.epochs.find(e => e.epoch === w.epoch);
    try {
      const wp = await peer(w.by);
      const key = await E2E.unwrapRoomKey(w.wrapped, w.epoch, X.priv.ecdhPriv, X.id, wp.ecdh, w.by);
      if (!ep || !(await E2E.verifyEpochCheck(ep.check, key, w.epoch))) throw new Error("tekshiruv");
      X.rooms.set(w.epoch, key); X.keyIds.set(w.epoch, await E2E.keyId(key));
    } catch (_) {                                              // soxta/buzilgan o'ralgan kalit: o'chirib, boshqa a'zodan qayta so'raymiz
      try { await api("/e2ee/room/wrap/" + w.epoch, {method: "DELETE"}); } catch (__) {}
    }
  }
  if (st.epoch === 0) await initRoom();
  else if (X.rooms.has(st.epoch)) { rehydratePending(); serveWraps(); }
  if (!X.rooms.has(X.epoch) && X.epoch) renderHeader();
}
async function initRoom() {
  const key = await E2E.newRoomKey(), withKeys = S.members.filter(m => m.ek && !m.banned && !m.deleted);
  const list = withKeys.some(m => m.id === X.id) ? withKeys : withKeys.concat([{id: X.id, ek: X.ecdhPub}]);
  const wraps = [];
  for (const m of list) wraps.push({user_id: m.id, wrapped: await E2E.wrapRoomKey(key, 1, X.priv.ecdhPriv, X.id, (await peer(m.id)).ecdh, m.id)});
  try { await api("/e2ee/room/init", {method: "POST", body: {check: await E2E.epochCheck(key, 1), wraps}}); }
  catch (_) { /* boshqa a'zo oldinroq yaratdi */ }
  const st = await api("/e2ee/room"); if (st.epoch) { X.state = st; X.epoch = st.epoch; await loadRoomKeysOnly(); }
}
async function loadRoomKeysOnly() { if (X.epoch) await loadRoom(); }
async function serveWraps() {                                   // yangi a'zolarga (kaliti hali yo'qlarga) kalitni o'rab beramiz
  if (X.serving || !X.rooms.size) return;
  X.serving = true;
  try {
    const j = await api("/e2ee/room/missing"), byEp = new Map();
    j.missing.forEach(m => { if (X.rooms.has(m.epoch) && m.user_id !== X.id) (byEp.get(m.epoch) || byEp.set(m.epoch, []).get(m.epoch)).push(m); });
    for (const [ep, list] of byEp) {
      const wraps = [];
      for (const m of list.slice(0, 100)) {
        try {
          const pk = await E2E.importEcdhPub(m.ecdh_pub);
          wraps.push({user_id: m.user_id, wrapped: await E2E.wrapRoomKey(X.rooms.get(ep), ep, X.priv.ecdhPriv, X.id, pk, m.user_id)});
        } catch (_) {}
      }
      if (wraps.length) await api("/e2ee/room/wrap", {method: "POST", body: {epoch: ep, wraps}});
    }
  } catch (_) {}
  X.serving = false;
}
async function rotateRoom(reason) {                              // ban/chiqib ketishdan keyin: yangi kalit, faqat joriy a'zolarga
  if (X.rotating || !amAdmin() || !X.rooms.has(X.epoch)) return;
  X.rotating = true;
  try {
    await loadMembers();
    const key = await E2E.newRoomKey(), ep = X.epoch + 1, wraps = [];
    for (const m of S.members.filter(m => m.ek && !m.banned && !m.deleted))
      wraps.push({user_id: m.id, wrapped: await E2E.wrapRoomKey(key, ep, X.priv.ecdhPriv, X.id, (await peer(m.id)).ecdh, m.id)});
    await api("/e2ee/room/rotate", {method: "POST", body: {from_epoch: X.epoch, check: await E2E.epochCheck(key, ep), wraps, reason: (reason || "rotate").slice(0, 20)}});
    toast("Guruh kaliti yangilandi (yangi xabarlar eski a'zolar uchun yopiq)", "ok");
  } catch (_) {}
  X.rotating = false;
  try { await loadRoom(); } catch (_) {}
}

/* --- xabar konvertini ochish --- */
const fileIco = f => f.voice ? "🎤 " : f.vnote ? "📹 " : "📎 ";
const fileWhat = f => f.voice ? "Ovozli xabar" : f.vnote ? "Video xabar" : f.name;
const THUMB_RE = /^data:image\/jpeg;base64,[A-Za-z0-9+/]{16,4200}={0,2}$/;     // dumaloq video: xira kichik nusxa (begona ma'lumot — qat'iy tekshiriladi)
const replyInfo = m => ({id: m.id, uid: m.user.id, nickname: m.user.nickname, text: snippetOf(m.content), image: !!m.image, file: !!m.file, voice: !!(m.file && m.file.voice), vnote: !!(m.file && m.file.vnote), file_name: m.file ? fileWhat(m.file) : null});
async function hydrate(m) {
  if (!m || m.service || !m.e2e) { if (m && !m.service && !m.e2e) m.legacy = true; return m; }
  m.locked = false; m.bad = false; m.verified = false;
  try {
    const env = E2E.parseEnvelope(m.e2e), sender = m.user.id, me = X.id;
    let key;
    if (m.ch || m.to == null) {                                  // kanal posti ham guruh kaliti bilan shifrlanadi (xonasi AAD ichida)
      key = X.rooms.get(env.ep);
      if (!key) { m.locked = true; m.content = ""; X.pending.add(m); return m; }
    } else {
      const other = sender === me ? m.to : sender, op = await peer(other);
      if (op.changed) throw new Error("kalit o'zgargan");
      key = await E2E.dmKey(X.priv.ecdhPriv, op.ecdh, sender, m.to);
    }
    const sp = await peer(sender);
    const r = await E2E.openMessage(m.e2e, {sender, peer: m.to, key, signKey: sp.sign, room: m.ch ? "c:" + m.ch : undefined});
    const p = r.payload; m.verified = r.verified && !sp.changed;
    m.content = typeof p.t === "string" ? p.t : "";
    m.reply = p.r ? Object.assign({deleted: false}, p.r) : null;
    m._r = p.r || null; m._f = p.f || null;
    m._fw = p.fw && typeof p.fw === "object" && typeof p.fw.n === "string" ? {n: p.fw.n.slice(0, 40), id: Number.isInteger(p.fw.id) ? p.fw.id : 0} : null;
    m.fwd = m._fw;
    if (p.f) {
      m.mkey = p.f.k;
      if (p.f.img) { m.image = "e2e"; m.thumb = p.f.th || null; m.w = p.f.w || null; m.h = p.f.h || null; }
      else m.file = {url: m.blob ? m.blob.url : "", name: p.f.name || "fayl", size: p.f.size || 0, mime: p.f.mime || "application/octet-stream", e2e: true, key: p.f.k,
        voice: p.f.vo === 1 && p.f.mime === "audio/wav", dur: typeof p.f.d === "number" && p.f.d > 0 && p.f.d < 900 ? p.f.d : 0,
        vnote: p.f.rv === 1 && (p.f.mime === "video/webm" || p.f.mime === "video/mp4"), th: typeof p.f.th === "string" && THUMB_RE.test(p.f.th) ? p.f.th : null};
    }
    X.pending.delete(m);
  } catch (err) { m.bad = true; m.content = ""; X.pending.delete(m); }
  return m;
}
async function rehydratePending() {
  const list = [...X.pending]; if (!list.length) return;
  for (const m of list) await hydrate(m);
  renderMessages(false); renderList();
}
const hydrateAll = list => Promise.all(list.map(hydrate));
/* --- kanal posti ostidagi izohlar: guruh kaliti bilan, xonasi "k:<post id>" (boshqa post/kanalga ko'chirib bo'lmaydi) --- */
async function hydrateComment(c) {
  if (!c.e2e) { c.text = typeof c.content === "string" ? c.content : ""; c.verified = false; c.legacy = true; return c; }     // E2EE'dan oldingi izoh
  c.locked = false; c.bad = false; c.verified = false; c.text = "";
  try {
    const env = E2E.parseEnvelope(c.e2e), key = X.rooms.get(env.ep);
    if (!key) { c.locked = true; return c; }
    const sp = await peer(c.user.id);
    const r = await E2E.openMessage(c.e2e, {sender: c.user.id, peer: null, key, signKey: sp.sign, room: "k:" + c.post});
    c.verified = r.verified && !sp.changed;
    c.text = typeof r.payload.t === "string" ? r.payload.t : "";
  } catch (_) { c.bad = true; }
  return c;
}
async function sealComment(postId, text) {
  const key = X.rooms.get(X.epoch);
  if (!key) throw new Error(X.epoch ? "Guruh kaliti hali kelmagan. Biroz kuting…" : "Guruh kaliti yaratilmoqda, biroz kuting…");
  return E2E.sealMessage({sender: X.id, peer: null, ep: X.epoch, key, signKey: X.priv.signPriv, payload: {t: text}, room: "k:" + postId, kind: "c"});
}

/* --- shifrlangan fayllar --- */
async function e2eFetchBlob(m) {
  const url = m.blob ? m.blob.url : (m.file && m.file.url);
  if (m.expired || !url) { const ex = new Error("expired"); ex.expired = true; throw ex; }       // 24 soatdan keyin fayl serverdan o'chadi
  const r = await SC.fetch(url, {headers: {Authorization: "Bearer " + S.token}});
  if (!r.ok) throw new Error("fayl");
  return E2E.decryptFile(r.bytes, m.mkey || m.file.key);
}
const EXPIRED_MSG = "Fayl muddati tugagan (24 soatdan keyin o'chiriladi)";
const blobUrls = new Map();                                       // xabar id -> ochilgan rasm URL'i
function e2eImageUrl(m) {
  if (!blobUrls.has(m.id)) blobUrls.set(m.id, e2eFetchBlob(m).then(b => URL.createObjectURL(new Blob([b], {type: (m._f && m._f.mime) || "image/jpeg"}))).catch(e => { blobUrls.delete(m.id); throw e; }));
  return blobUrls.get(m.id);
}
const imgSrcOf = m => m.e2e ? e2eImageUrl(m) : Promise.resolve(m.image);

async function cleanImage(blob) {                                 // EXIF/GPS metama'lumot olib tashlanadi (qayta kodlash) + xira kichik nusxa
  const out = {blob, w: 0, h: 0, th: null};
  try {
    const bmp = await createImageBitmap(blob);
    out.w = bmp.width; out.h = bmp.height;
    if (blob.type !== "image/gif") {
      const c = document.createElement("canvas"); c.width = bmp.width; c.height = bmp.height;
      c.getContext("2d").drawImage(bmp, 0, 0);
      const png = blob.type === "image/png", re = await new Promise(r => c.toBlob(r, png ? "image/png" : "image/jpeg", 0.92));
      if (re) out.blob = re;
    }
    const k = 40 / Math.max(bmp.width, bmp.height), t = document.createElement("canvas");
    t.width = Math.max(1, Math.round(bmp.width * k)); t.height = Math.max(1, Math.round(bmp.height * k));
    t.getContext("2d").drawImage(bmp, 0, 0, t.width, t.height);
    out.th = t.toDataURL("image/jpeg", 0.5);
  } catch (_) {}
  return out;
}

/* --- yuborish: konvertni yasab, serverga FAQAT shifrni beramiz --- */
async function keyForActive() { return keyForTarget(S.active); }
async function keyForTarget(tg) {
  if (tg.kind === "channel") {
    if (!amAdmin()) throw new Error("Kanalga faqat adminlar post yoza oladi");
    const key = X.rooms.get(X.epoch);
    if (!key) throw new Error(X.epoch ? "Guruh kaliti hali kelmagan: kalitli a'zo onlayn bo'lishi kerak. Biroz kuting…" : "Guruh kaliti yaratilmoqda, biroz kuting…");
    return {key, peer: null, ep: X.epoch, room: "c:" + tg.id, kind: "c"};
  }
  if (tg.kind === "group") {
    const key = X.rooms.get(X.epoch);
    if (!key) throw new Error(X.epoch ? "Guruh kaliti hali kelmagan: kalitli a'zo onlayn bo'lishi kerak. Biroz kuting…" : "Guruh kaliti yaratilmoqda, biroz kuting…");
    return {key, peer: null, ep: X.epoch};
  }
  const uid = tg.uid, p = await peer(uid);
  if (p.changed) throw new Error("Bu foydalanuvchining shifrlash kaliti o'zgargan! 🔒 tugmasida tekshirib, qabul qiling");
  return {key: await E2E.dmKey(X.priv.ecdhPriv, p.ecdh, X.id, uid), peer: uid, ep: 0};
}
async function sealFor(ctx, payload) {
  return E2E.sealMessage({sender: X.id, peer: ctx.peer, ep: ctx.ep, key: ctx.key, signKey: X.priv.signPriv, payload, room: ctx.room, kind: ctx.kind});
}
function withTarget(msg, tg) {                                   // yuboriladigan paketga manzil: lichka -> to, kanal -> ch
  if (tg.kind === "dm") msg.to = tg.uid; else if (tg.kind === "channel") msg.ch = tg.id;
  return msg;
}

/* ---------------- ko'rinish bo'laklari: avatar, nom, galochka ---------------- */
function paintAv(el, u) {
  el.textContent = "";
  el.style.setProperty("--avc", colorOf(u.id));
  if (u.deleted) { el.classList.add("del"); el.append(icon("ghost")); return; }          // o'chirilgan akkaunt: arvoh belgisi
  if (u.avatar) el.append(h("img", {src: u.avatar, alt: "", draggable: "false", decoding: "async"}));     // dekodlash asosiy oqimni to'xtatmaydi
  else el.append(h("span", {text: (Array.from((u.nickname || "?").trim())[0] || "?").toUpperCase()}));
}
function avatar(u, size, withDot) {
  const el = h("div", {class: "av av-" + size + (isStaff(u) ? " ring " + u.role : "") + (!u.deleted && FRAME_KEYS.has(u.frame) ? " fr-" + u.frame : "")});
  tint(el, u); paintAv(el, u);
  if (withDot && !u.deleted && isOnline(u.id)) el.append(h("span", {class: "dot-on"}));
  return el;
}
function groupAvatar(size) { return h("div", {class: "av av-" + size + " grp"}, icon("group")); }
const hasEmoji = u => !!u && !!u.badge && u.badge !== "none" && u.badge !== "check";
const isVerified = u => !!u && !isStaff(u) && !u.deleted && u.badge === "check";      // admin bergan galochka (admin qilmasdan)
function badge(u, big) {
  if (hasEmoji(u) && Rich.isEmojiToken(u.badge)) {      // maxsus rasmli emoji (Kali, Linux, Anonymous, Ghost...) — admin beradi
    return Rich.emojiEl(u.badge, "eb ceb" + (u.badge_anim ? " a-" + u.badge_anim : "") + (big ? " big" : ""), isStaff(u) ? roleLabel(u.role) : null);
  }
  if (hasEmoji(u)) {                                   // ega/admin tanlagan yoki ular bergan emoji nishon (animatsiya bilan)
    return h("span", {class: "eb" + (u.badge_anim ? " a-" + u.badge_anim : "") + (big ? " big" : ""),
      title: isStaff(u) ? roleLabel(u.role) : "Maxsus nishon", "aria-label": "Nishon", text: u.badge});
  }
  if (!isStaff(u) && !isVerified(u)) return null;
  if (isStaff(u) && u.badge === "none") return null;
  const s = svgUse("#i-vb", "vb " + u.role + (big ? " big" : ""));
  const t = document.createElementNS(NS, "title");
  t.textContent = u.role === "owner" ? "Tasdiqlangan — platforma egasi" : u.role === "admin" ? "Tasdiqlangan administrator" : "Tasdiqlangan foydalanuvchi";
  s.prepend(t);
  return s;
}
function newTag(u, big) {                              // yangi akkaunt: hali ishonish qiyin
  return u && u.new && !u.deleted && !isStaff(u) ? h("span", {class: "newb" + (big ? " big" : ""), title: "Yangi foydalanuvchi — hali ishonch qozonmagan. Ehtiyot bo'ling", text: "⚠ Yangi"}) : null;
}
function nameEl(u, opts = {}) {
  const nt = h("span", {class: "nt", text: u.nickname});
  if (opts.colored && !isStaff(u) && !u.deleted) nt.style.color = colorOf(u.id);
  const nk = opts.nofx ? null : fxOf(u, "nick");
  if (nk) { fxText(nt, nk); if (nk === "wave") fxWave(nt, u.nickname); }
  return tint(h("span", {class: "nm" + (isStaff(u) ? " prem " + u.role : "") + (u.deleted ? " deleted" : "")}, nt, badge(u, opts.big), newTag(u, opts.big)), u);
}
const statusText = u => u.deleted ? "akkaunt o'chirilgan" : isOnline(u.id) ? "onlayn" : lastSeenText(u);

/* ---------------- 27-fx.js: profil DIZAYNI (animatsiyali uslublar, fon, ramka, unvon) bitta modulda ----------------
   Oldin 03-avatars-design.js va 22-admin-extras.js ichida edi. Endi dizaynga oid hamma narsa shu yerda:
   1) ro'yxatlar va yordamchilar (fxOf, fxText, fxBubble, ...), 2) admin uchun profil dizayni muharriri (openProfileEditor).
   Tartib: 03 dan keyin yuklanadi (uning funksiyalari faqat chaqirilganda ishlatiladi). */
/* ---------- Profil dizayni: element bo'yicha animatsiyali uslublar, fon (banner), avatar ramkasi, unvon (admin beradi) ----------
   Server faqat tayyor nomlarni qabul qiladi (app/services/fxstyle.py); mijoz ularni faqat o'z CSS klasslariga ulaydi. */
const BANNERS = [["aurora", "Aurora"], ["sunset", "Shafaq"], ["ocean", "Okean"], ["forest", "O'rmon"], ["midnight", "Yarim tun"],
  ["rose", "Atirgul"], ["gold", "Oltin"], ["fire", "Olov"], ["ice", "Muz"], ["violet", "Binafsha"]];
const FRAMES = [["gold", "Oltin"], ["rainbow", "Kamalak"], ["fire", "Olov"], ["ice", "Muz"], ["emerald", "Zumrad"], ["rose", "Atirgul"]];
const BANNER_KEYS = new Set(BANNERS.map(x => x[0])), FRAME_KEYS = new Set(FRAMES.map(x => x[0]));
const FX_TXT = [["shimmer", "Yaltirash"], ["aurora", "Aurora"], ["sunrise", "Shafaq"], ["ocean", "Okean"], ["gold", "Oltin"], ["candy", "Konfet"],
  ["glitch", "Glitch"], ["float", "Suzish"], ["pulse", "Puls"]];
const FX = {
  nick: {label: "Nickname", items: FX_TXT.concat([["wave", "To'lqin"]])},
  user: {label: "Username", items: FX_TXT},
  bio: {label: "Bio", items: FX_TXT.slice(0, 6).concat([["breathe", "Nafas"]])},
  page: {label: "Profil sahifasi", items: [["flow", "Oqma fon"], ["stars", "Yulduzlar"], ["float", "Suzuvchi avatar"]]},
  msg: {label: "Xabarlar", items: [["bounce", "Sakrash"], ["slide", "Sirpanish"], ["rise", "Ko'tarilish"], ["spin", "Aylanish"], ["drop", "Tushish"], ["focus", "Aniqlashish"], ["border", "Oqma hoshiya"]]},
  reply: {label: "Reply", items: [["line", "Oqma chiziq"], ["tint", "Rangli fon"], ["stripes", "Yo'l-yo'l"], ["slidein", "Sirpanib kirish"]]},
  link: {label: "Havola", items: [["run", "Chiziq yugurishi"], ["pill", "Kapsula"], ["flow", "Oqma rang"], ["arrow", "↗ Strelka"]]},
};
const FX_AREAS = Object.keys(FX);
const FX_KEYS = {}; FX_AREAS.forEach(k => { FX_KEYS[k] = new Set(FX[k].items.map(x => x[0])); });
const FX_GRAD = new Set(["shimmer", "aurora", "sunrise", "ocean", "gold", "candy"]);       // matn gradienti; qolganlari — harakat
const FX_MQ = typeof matchMedia === "function" ? matchMedia("(prefers-reduced-motion: reduce)") : null;       // "animatsiyani kamaytirish" yoqilgan bo'lsa hamma effekt o'chadi
const fxOf = (u, area) => !(FX_MQ && FX_MQ.matches) && u && !u.deleted && u.fx && typeof u.fx === "object" && typeof u.fx[area] === "string" && FX_KEYS[area].has(u.fx[area]) ? u.fx[area] : null;
const fxMap = u => { const o = {}; FX_AREAS.forEach(a => { o[a] = fxOf(u, a) || ""; }); return o; };
function fxText(el, key) {                              // nickname / username / bio elementiga matn effekti beradi
  if (!key) return el;
  if (FX_GRAD.has(key)) el.classList.add("fxt", "fxg-" + key); else el.classList.add("fxa-" + key);
  return el;
}
function fxWave(nt, text) {                             // "To'lqin": har bir harf alohida, birin-ketin ko'tariladi
  nt.textContent = ""; nt.setAttribute("aria-label", text);
  Array.from(text).forEach((ch, i) => { const sp = h("span", {class: "fxw", "aria-hidden": "true", text: ch}); sp.style.setProperty("--i", String(Math.min(i, 40))); nt.append(sp); });
  return nt;
}
function fxBubble(bubble, u) {                          // xabar pufagiga: xabar effekti (fxm-) va havola uslubi (fxl-)
  const m = fxOf(u, "msg"), l = fxOf(u, "link");
  if (m) bubble.classList.add("fxm-" + m);
  if (l) bubble.classList.add("fxl-" + l);
  return bubble;
}
function fxPlay(el, ms) {                               // xabar effekti faqat YANGI xabarda: `fxgo` klassi vaqtincha qo'yiladi (qayta chizilganda takrorlanmaydi)
  el.classList.remove("fxgo"); void el.offsetWidth; el.classList.add("fxgo");
  clearTimeout(el._fxT); el._fxT = setTimeout(() => el.classList.remove("fxgo"), ms || 3400);
}
const pageCls = u => { const k = fxOf(u, "page"); return k ? " fxp-" + k : ""; };
const bannerCls = u => u && !u.deleted && BANNER_KEYS.has(u.banner) ? " bn-" + u.banner : "";
const titleEl = u => u && !u.deleted && u.title ? h("div", {class: "ptitle", text: u.title}) : null;

/* ---------- Admin: profilga DIZAYN berish (o'ziga va foydalanuvchilarga): ishonch belgisi, galochka, nishon, element uslublari, fon, ramka, unvon.
   Nickname, username, rasm va bio'ni admin o'zgartirmaydi — bular faqat foydalanuvchining o'zinikidir. ---------- */
function openProfileEditor(uid) {
  openPage(() => {
    const t0 = U(uid), self = uid === S.me.id, staff = isStaff(t0);
    const trustOf = x => x.trust === 1 ? "new" : x.trust === 0 ? "trusted" : "auto";
    const base = {fx: fxMap(t0), banner: BANNER_KEYS.has(t0.banner) ? t0.banner : "",
      frame: FRAME_KEYS.has(t0.frame) ? t0.frame : "", title: t0.title || "", color: HEX.test(t0.color || "") ? t0.color.toLowerCase() : "", trust: trustOf(t0)};
    const d = Object.assign({}, base, {fx: Object.assign({}, base.fx)});
    const prev = h("div", {class: "pe-prev"});
    const paintPrev = play => {
      const cur = U(uid), autoNew = base.trust === "auto" ? !!cur.new : (Date.now() / 1000 - (cur.joined || 0)) < 7 * 86400;
      const pu = Object.assign({}, cur, {fx: d.fx, banner: d.banner || null, frame: d.frame || null,
        title: d.title.trim() || null, color: d.color || cur.color, new: d.trust === "new" ? true : d.trust === "trusted" ? false : autoNew});
      prev.textContent = "";
      const top = tint(h("div", {class: "tg-top" + (isStaff(pu) ? " prem " + pu.role : "") + bannerCls(pu) + pageCls(pu)}), pu);
      top.append(avatar(pu, "l"), h("div", {class: "pname"}, nameEl(pu, {big: true})), titleEl(pu), h("div", {class: "pstat on", text: "onlayn"}));
      top.append(fxText(h("div", {class: "pe-un", text: "@" + pu.username}), fxOf(pu, "user")));
      if (pu.new && !isStaff(pu)) top.append(h("div", {class: "chip warn", text: "⚠ Yangi foydalanuvchi — hali ishonish qiyin"}));
      top.append(fxText(h("div", {class: "pe-bio", text: pu.bio || "Bio shunday ko'rinadi ✨"}), fxOf(pu, "bio")));
      const mk = kind => {
        const b = fxBubble(h("div", {class: "bubble pe-bub"}), pu);
        b.append(h("div", {class: "bname"}, nameEl(pu, {colored: true})));
        if (kind === "reply") b.append(replyQuote({nickname: "Aziz", text: "Salom, qalaysan?"}, pu));
        b.append(btextEl("btext", kind === "reply" ? "Yaxshi, rahmat! Reply shunday ko'rinadi" : kind === "link" ? "Mana havola: https://example.com/dizayn" : "Salom! Xabarim shunday ko'rinadi ✨", true));
        b.append(h("span", {class: "meta", text: "12:00"}));
        return h("div", {class: "pe-msg"}, b);
      };
      const msgs = h("div", {class: "pe-msgs"}, mk("plain"), mk("reply"), mk("link"));
      msgs.addEventListener("click", e => { if (e.target.closest("a")) e.preventDefault(); }, true);       // namunadagi havola ochilmaydi
      const again = h("button", {class: "btn ghost sm pe-again", type: "button", text: "▶ Qayta ko'rsatish"});
      again.addEventListener("click", () => fxPlay(msgs, 3400));
      prev.append(top, msgs, h("div", {class: "pe-row pe-pad"}, again));
      if (play) fxPlay(msgs, 3400);
    };
    const set = (k, v) => { d[k] = v; paintPrev(); };
    const setFx = (area, k) => { d.fx[area] = k; paintPrev(area === "msg" || area === "reply"); };
    const field = (label, k, o = {}) => {
      const i = h("input", {class: "fld", maxlength: String(o.max), placeholder: o.ph || "", "aria-label": label});
      i.value = d[k]; i.addEventListener("input", () => set(k, i.value));
      return h("label", {class: "fl"}, label, i);
    };
    const seg = (items, cur, onPick) => {
      const box = h("div", {class: "pe-seg", role: "radiogroup"});
      const paint = () => { box.textContent = ""; items.forEach(([k, t]) => { const b = h("button", {type: "button", class: "pe-sg" + (k === cur() ? " on" : ""), role: "radio", "aria-checked": String(k === cur()), text: t}); b.addEventListener("click", () => { onPick(k); paint(); }); box.append(b); }); };
      paint(); return box;
    };
    const apply = j => { upsertUser(j.user); if (S.members.some(x => x.id === uid)) S.members = S.members.map(x => x.id === uid ? Object.assign({}, x, j.user, {trust: j.trust}) : x); S.users.set(uid, Object.assign({}, S.users.get(uid), {trust: j.trust})); renderList(); renderMessages(false); };
    // --- galochka (tasdiqlangan belgi) — darhol saqlanadi
    const checkRow = staff ? null : switchRow("check", "Tasdiqlangan galochka", () => U(uid).badge === "check", async () => {
      const on = U(uid).badge === "check";
      try { const j = await api("/admin/badge", {method: "POST", body: {user_id: uid, badge: on ? "" : "check", anim: ""}}); upsertUser(j.user); renderList(); renderMessages(false); paintPrev(); }
      catch (err) { toast(err.message, "error"); }
    }, "Ismi yonida ko'k galochka chiqadi. Emoji nishon uchun pastdagi tugmani bosing.");
    // --- fon va ramka
    const bnSw = h("div", {class: "pe-sws"}), frSw = h("div", {class: "pe-sws"});
    const paintBn = () => {
      bnSw.textContent = "";
      const none = h("button", {type: "button", class: "pe-bn pe-off" + (!d.banner ? " on" : ""), title: "Fonsiz", "aria-label": "Fonsiz", text: "∅"}); none.addEventListener("click", () => { set("banner", ""); paintBn(); }); bnSw.append(none);
      BANNERS.forEach(([k, n]) => { const b = h("button", {type: "button", class: "pe-bn bn-" + k + (d.banner === k ? " on" : ""), title: n, "aria-label": n}); b.addEventListener("click", () => { set("banner", k); paintBn(); }); bnSw.append(b); });
    };
    const paintFr = () => {
      frSw.textContent = "";
      const none = h("button", {type: "button", class: "pe-fr pe-off" + (!d.frame ? " on" : ""), title: "Ramkasiz", "aria-label": "Ramkasiz", text: "∅"}); none.addEventListener("click", () => { set("frame", ""); paintFr(); }); frSw.append(none);
      FRAMES.forEach(([k, n]) => { const b = h("button", {type: "button", class: "pe-fr" + (d.frame === k ? " on" : ""), title: n, "aria-label": n}, h("span", {class: "av av-s fr-" + k})); b.addEventListener("click", () => { set("frame", k); paintFr(); }); frSw.append(b); });
    };
    paintBn(); paintFr();
    // --- profil rangi (faqat ega/adminlar uchun ko'rinadi)
    const colSw = h("div", {class: "pe-sws"});
    const paintCol = () => {
      colSw.textContent = "";
      PRESETS.forEach(c => { const b = h("button", {type: "button", class: "sw" + (d.color === c ? " on" : ""), title: c, "aria-label": c}); b.style.background = c; b.addEventListener("click", () => { set("color", c); paintCol(); }); colSw.append(b); });
      const pick = h("input", {type: "color"}); pick.value = d.color || TONES[t0.role] || "#7b61ff"; pick.addEventListener("input", () => set("color", pick.value)); pick.addEventListener("change", paintCol);
      colSw.append(h("label", {class: "sw-custom", title: "Boshqa rang"}, pick), h("button", {type: "button", class: "btn ghost sm", text: "Standart", onclick: () => { set("color", ""); paintCol(); }}));
    };
    paintCol();
    // --- saqlash: faqat o'zgargan maydonlar yuboriladi
    const save = h("button", {class: "btn", type: "button", text: "Saqlash"});
    save.addEventListener("click", async () => {
      const body = {user_id: uid};
      ["banner", "frame", "title", "color", "trust"].forEach(k => { if (d[k] !== base[k]) body[k] = d[k]; });
      const fx = {}; FX_AREAS.forEach(a => { if ((d.fx[a] || "") !== (base.fx[a] || "")) fx[a] = d.fx[a] || ""; });
      if (Object.keys(fx).length) body.fx = fx;
      if (Object.keys(body).length === 1) { toast("O'zgarish yo'q", "info"); return; }
      save.disabled = true; save.textContent = "Saqlanmoqda…";
      try { apply(await api("/admin/user/profile", {method: "POST", body})); toast("Saqlandi", "ok"); closePage(); }
      catch (err) { toast(err.message, "error"); save.disabled = false; save.textContent = "Saqlash"; }
    });
    paintPrev();
    const hint = (t) => h("p", {class: "tg-hint", text: t});
    const fxSec = (area, note) => h("div", {}, secTitle(FX[area].label), seg([["", "Yo'q"]].concat(FX[area].items), () => d.fx[area] || "", k => setFx(area, k)), note ? hint(note) : null);
    const body = h("div", {class: "pg-body pe-body"}, prev,
      FX_MQ && FX_MQ.matches ? hint("Bu qurilmada «animatsiyani kamaytirish» yoqilgan, shuning uchun effektlar namunada ko'rinmaydi. Saqlansa, boshqalarda ishlaydi.") : null,
      staff ? null : h("div", {}, secTitle("Ishonch belgisi"),
        seg([["auto", "Avtomatik"], ["trusted", "Ishonchli"], ["new", "Yangi (ogohlantirish)"]], () => d.trust, k => set("trust", k)),
        hint("Avtomatik: akkaunt yoshi bo'yicha. «Ishonchli» — «⚠ Yangi» belgisi yashiriladi. «Yangi» — eski akkauntda ham belgi ko'rsatiladi.")),
      checkRow ? h("div", {}, secTitle("Galochka va nishon"), checkRow) : secTitle("Nishon"),
      h("div", {class: "pe-row pe-pad"}, h("button", {class: "btn ghost sm", type: "button", onclick: () => openBadgePicker(U(uid), () => openProfileEditor(uid))}, "Emoji nishon tanlash")),
      fxSec("nick"), fxSec("user"), fxSec("bio"),
      fxSec("page", "Profil sahifasining o'zi uchun. Fon rangi va avatar ramkasi pastda alohida tanlanadi."),
      fxSec("msg", "Xabar paydo bo'lganda bir marta ishlaydi. Eski tarix ochilganda takrorlanmaydi."),
      fxSec("reply", "Shu foydalanuvchi reply qilganda iqtibos qutisi shunday ko'rinadi."),
      fxSec("link", "Shu foydalanuvchi yuborgan havolalar shunday ko'rinadi."),
      secTitle("Profil foni"), bnSw,
      secTitle("Avatar ramkasi"), frSw,
      staff ? h("div", {}, secTitle("Profil rangi"), colSw) : null,
      secTitle("Unvon"),
      h("div", {class: "inf-form"}, field("Ism ostidagi qisqa yozuv", "title", {max: 24, ph: "Masalan: Moderator, VIP, Yordamchi"})),
      h("div", {class: "pe-save"}, save));
    return h("div", {}, pageHead(self ? "Profil dizayni" : "Dizayn: @" + t0.username), body);
  });
}

/* Mening akkauntim: faqat rasm, nickname, username (o'zgarmaydi) va bio */
/* ---------------- kirish / chiqish ---------------- */
function setMode(m) {
  S.mode = m;
  $("tabL").classList.toggle("on", m === "login");
  $("tabR").classList.toggle("on", m === "register");
  $("nickWrap").classList.toggle("hidden", m === "login");
  $("regHint").classList.toggle("hidden", m === "login");
  $("submitBtn").textContent = m === "login" ? "Kirish" : "Ro'yxatdan o'tish";
  $("f_pass").autocomplete = m === "login" ? "current-password" : "new-password";
  $("autherr").textContent = "";
  $("unameChk").classList.add("hidden");
  if (m === "register") $("f_user").dispatchEvent(new Event("input"));
}
let unameTimer = null, unameSeq = 0;
$("f_user").addEventListener("input", () => {            // katta-kichik harfga e'tiborsiz: server tekshiradi
  clearTimeout(unameTimer);
  const chk = $("unameChk"), v = $("f_user").value.trim().replace(/^@/, "");
  if (S.mode !== "register" || !v) { chk.classList.add("hidden"); return; }
  unameTimer = setTimeout(async () => {
    const seq = ++unameSeq;
    try {
      const r = await SC.fetch("/api/username/" + encodeURIComponent(v));
      if (!r.ok) return;
      const j = await r.json();
      if (seq !== unameSeq || S.mode !== "register") return;
      chk.className = "uchk " + (j.available ? "ok" : "bad");
      chk.textContent = j.available ? "✓ Username bo'sh" : "✗ " + j.reason;
    } catch (_) {}
  }, 300);
});
if (!SC.supported()) $("autherr").textContent = "Shifrlash uchun HTTPS (xavfsiz ulanish) kerak. Saytni https:// orqali oching.";
$("tabL").onclick = () => setMode("login");
$("tabR").onclick = () => setMode("register");

const JSON_H = {"Content-Type": "application/json"};
$("form").addEventListener("submit", async e => {
  e.preventDefault();
  const btn = $("submitBtn"); btn.disabled = true; $("autherr").textContent = "";
  const username = $("f_user").value.trim().replace(/^@/, ""), password = $("f_pass").value;
  try {
    if (!SC.supported()) throw new Error("Shifrlash uchun HTTPS (xavfsiz ulanish) kerak");
    $("autherr").textContent = "Shifrlash kalitlari tayyorlanmoqda…";
    await new Promise(r => setTimeout(r, 30));                // matn chiqishi uchun (PBKDF2 bir necha yuz ms)
    let r, gen = null;
    if (S.mode === "register") {
      gen = await xGenerate(username, password, E2E.KDF_DEFAULT);
      r = await SC.fetch("/api/register", {method: "POST", headers: JSON_H, body: JSON.stringify({username, nickname: $("f_nick").value.trim() || username, password: gen.kd.auth, e2ee: gen.keys, remember: $("f_stay").checked})});
    } else {
      const kr = await SC.fetch("/api/kdf", {method: "POST", headers: JSON_H, body: JSON.stringify({username})});
      const kp = await kr.json().catch(() => ({}));
      const secret = kp.auth_v === 0 ? password : (await E2E.deriveFromPassword(username, password, kp.kdf_iter || E2E.KDF_DEFAULT)).auth;
      r = await SC.fetch("/api/login", {method: "POST", headers: JSON_H, body: JSON.stringify({username, password: secret, remember: $("f_stay").checked})});
    }
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(typeof j.detail === "string" ? j.detail : "Xato, qayta urinib ko'ring");
    S.token = j.token; SC.setToken(S.token); S.lastAct = Date.now(); xReset();
    try {
      if (gen) await xInstall(j.me, j.me.username, gen.ident, gen.keys, E2E.KDF_DEFAULT, true);
      else await xUnlock({upgrade: j.upgrade, e2ee: j.e2ee}, j.me, j.me.username, password);
    } catch (err) { try { await SC.fetch("/api/logout", {method: "POST", headers: {Authorization: "Bearer " + S.token}}); } catch (_) {} S.token = null; SC.setToken(null); throw err; }
    $("f_pass").value = ""; $("autherr").textContent = "";
    if ($("f_stay").checked) await persistStay(); else await forgetStay();
    Off.arm({user: username, password, stay: $("f_stay").checked});       // oflayn xotira kaliti (fonda)
    openApp();
  } catch (err) { $("autherr").textContent = err.message; }
  btn.disabled = false;
});

function resetState() {
  S.offline = false; document.body.classList.remove("offline-mode");
  S.me = null; S.users = new Map(); S.members = []; S.online = new Set();
  S.group = {msgs: [], unread: 0, more: false}; S.dms = new Map(); S.chn = new Map(); S.chList = []; S.active = null; S.editing = null; S.query = ""; S.tab = "chats";
  S.replying = null; S.pendingImg = null; S.sending = false; S.sel = null; S.imgs = new Map();
  S.played.forEach(u => URL.revokeObjectURL(u)); S.played = new Map(); S.chat = {slowmode: 0, locked: false}; S.previews = new Map(); S.fx = new Map();
  cancelRecording(); voiceStop(); Pend.clear(); typingReset();
  ["replybar", "imgbar", "editbar"].forEach(id => $(id).classList.add("hidden"));
  $("search").value = ""; $("msgs").textContent = ""; $("inp").value = "";
  EM.data = null; EM.refresh = null; EM.tab = "std"; Rich.setEmojis([], true); $("emojiBtn").classList.add("hidden"); closeEmojiPanel();
}
function showAuth(msg) {
  $("f_user").value = ""; $("f_pass").value = "";            // har kirishda username va parol qaytadan kiritiladi
  S.wantClose = true;
  if (S.ws) try { S.ws.close(); } catch (_) {}
  SC.setToken(null); S.token = null; clearInterval(S.hb); S.hb = 0; clearTimeout(S.rt);
  try { localStorage.removeItem(LS_STAY); } catch (_) {} $("f_stay").checked = false;
  E2E.clearIdentity(); xReset(); blobUrls.forEach(p => p.then(u => URL.revokeObjectURL(u)).catch(() => {})); blobUrls.clear();
  closeModal(); closeCtx(); resetPages(); resetState(); Channels.reset();
  document.body.classList.remove("in-chat"); navReset();
  $("app").classList.add("hidden"); $("auth").classList.remove("hidden");
  $("autherr").textContent = msg || "";
  document.title = APP_NAME;
}
/* ---------------- bildirishnomalar (Web Push) ----------------
   Brauzer BUTUNLAY yopiq bo'lsa ham: umumiy chatga yozishsa — umumiy chat haqida, lichkaga yozishsa — lichka haqida bildirishnoma keladi.
   Onlayn bo'lsangiz xabarlar WebSocket orqali oddiy real vaqtda keladi (push yuborilmaydi). */
const notifLabel = () => {
  const st = Push.state();
  if (!st.ok) return st.why === "ios-install" ? "Bildirishnoma (ilovani o'rnating)" : "Bildirishnoma (qo'llab-quvvatlanmaydi)";
  if (st.permission === "denied") return "Bildirishnoma (bloklangan)";
  return st.on ? "Bildirishnomani o'chirish" : "Bildirishnomani yoqish";
};
async function toggleNotifications() {
  const st = Push.state();
  try {
    if (st.on) { await Push.disable(api); toast("Bu qurilmada bildirishnomalar o'chirildi", "info"); }
    else { await Push.enable(api); toast("Bildirishnomalar yoqildi: brauzer yopiq bo'lsa ham xabar keladi", "ok"); }
  } catch (err) { toast(err.message, "error"); }
}
async function askNotifications() {
  if (!S.token || !Push.shouldAsk()) return;
  Push.markAsked();
  const ok = await confirmDlg("Brauzer yopiq bo'lsa ham umumiy chatga yoki lichkangizga yozishsa, darhol xabar olasiz. Xabar matni bildirishnomada ko'rsatilmaydi.",
    {title: "Bildirishnomalarni yoqamizmi?", okText: "Yoqish"});
  if (!ok || !S.token) return;
  try { await Push.enable(api); toast("Bildirishnomalar yoqildi", "ok"); } catch (err) { toast(err.message, "error"); }
}
function applyPendingChannel() { const p = S.pendingOpen; if (p && p.k === "c") { S.pendingOpen = null; Channels.openById(p.u); } }
function openFromNotification(k, u) {                  // bildirishnoma bosildi: tegishli chatni ochamiz
  if (!S.token || !S.me) { S.pendingOpen = {k, u}; return; }
  if (k === "c") { Channels.openById(u); return; }
  if (k === "d" && u && u !== S.me.id) { if (S.users.has(u)) openChat({kind: "dm", uid: u}); else { S.pendingOpen = {k, u}; loadMembers().then(applyPendingOpen); } }
  else openChat({kind: "group"});
}
function applyPendingOpen() {
  const p = S.pendingOpen; if (!p) return;
  if (p.k === "d" && !S.users.has(p.u)) return;
  S.pendingOpen = null; openFromNotification(p.k, p.u);
}
window.addEventListener("ac-open-chat", e => openFromNotification(e.detail.k, e.detail.u));
try {                                                  // brauzer yopiq edi, bildirishnoma bosib ochildi: /?o=g yoki /?o=d12
  const o = new URLSearchParams(location.search).get("o");
  if (o) {
    if (o === "g") S.pendingOpen = {k: "g"};
    else if (/^d\d{1,9}$/.test(o)) S.pendingOpen = {k: "d", u: parseInt(o.slice(1), 10)};
    else if (/^c\d{1,9}$/.test(o)) S.pendingOpen = {k: "c", u: parseInt(o.slice(1), 10)};
    history.replaceState(null, "", "/");
  }
} catch (_) {}
async function logout() {
  try { await Promise.race([Push.onLogout(api), delay(3000)]); } catch (_) {}       // bu qurilmadagi bildirishnoma obunasi olib tashlanadi
  try { await SC.fetch("/api/logout", {method: "POST", headers: {Authorization: "Bearer " + S.token}}); } catch (_) {}
  await Off.wipe();                                                    // aniq "Chiqish": qurilmadagi oflayn xotira ham o'chadi
  showAuth("");
}

/* ---------------- mavzu ---------------- */
/* ---------------- xabar ovozi ("ting") ----------------
   Ilova ochiq bo'lganda (yoki orqa fonda tirik tursa) boshqa suhbatga/yashirin oynaga xabar kelsa qisqa ovoz chiqadi.
   Ilova yopiq bo'lsa ovozni telefonning o'zi (bildirishnoma ovozi) chaladi — veb-push maxsus ovoz faylini qo'llamaydi. */
const LS_SND = "ac_sound";
const LS_MUTED = "ac_muted_dm";                  // ovozi o'chirilgan shaxsiy suhbatlar (faqat shu qurilmada)
const mutedDm = (() => { try { return new Set(JSON.parse(localStorage.getItem(LS_MUTED) || "[]").filter(Number.isInteger)); } catch (_) { return new Set(); } })();
const isMuted = uid => mutedDm.has(uid);
function toggleMute(uid) {
  if (!mutedDm.delete(uid)) mutedDm.add(uid);
  try { localStorage.setItem(LS_MUTED, JSON.stringify([...mutedDm])); } catch (_) {}
  return mutedDm.has(uid);
}
const sndOn = () => { try { return localStorage.getItem(LS_SND) !== "off"; } catch (_) { return true; } };
let actx = null, lastTing = 0;
const audioCtx = () => { if (!actx) { const C = window.AudioContext || window.webkitAudioContext; if (C) { try { actx = new C(); } catch (_) {} } } return actx; };
["pointerdown", "keydown", "touchstart"].forEach(ev => addEventListener(ev, () => { const c = audioCtx(); if (c && c.state === "suspended") c.resume().catch(() => {}); }, {passive: true, capture: true}));
function ting(force) {
  if (!force && !sndOn()) return;
  const c = audioCtx(); if (!c || c.state !== "running") return;
  const t = c.currentTime;
  [[988, 0], [1480, 0.11]].forEach(([f, d]) => {
    const o = c.createOscillator(), g = c.createGain();
    o.type = "sine"; o.frequency.value = f;
    g.gain.setValueAtTime(0.0001, t + d); g.gain.exponentialRampToValueAtTime(0.28, t + d + 0.012); g.gain.exponentialRampToValueAtTime(0.0001, t + d + 0.42);
    o.connect(g); g.connect(c.destination); o.start(t + d); o.stop(t + d + 0.45);
  });
}
function pingSound(viewing) {                       // viewing: xabar kelgan suhbat hozir ochiq va ko'rinib turibdimi
  if (viewing && !document.hidden) return;
  const n = Date.now(); if (n - lastTing < 700) return; lastTing = n;
  ting();
}
function toggleSound() {
  const on = !sndOn();
  try { localStorage.setItem(LS_SND, on ? "on" : "off"); } catch (_) {}
  if (on) ting(true);
  toast(on ? "Xabar ovozi yoqildi" : "Xabar ovozi o'chirildi", "ok");
}
document.addEventListener("visibilitychange", () => { if (!document.hidden) { try { if (navigator.clearAppBadge) navigator.clearAppBadge(); } catch (_) {} } });

function toggleTheme() {
  const t = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
  document.documentElement.dataset.theme = t;
  const mc = document.querySelector('meta[name="theme-color"]'); if (mc) mc.setAttribute("content", t === "dark" ? "#17212b" : "#ffffff");
  try { localStorage.setItem(LS_THEME, t); } catch (_) {}
}

/* ---------------- WebSocket ---------------- */
function sendPresence() {                          // sahifa yashirilsa "away" (oflayn), qaytsa "back" (onlayn)
  const ws = S.ws; if (ws && ws.readyState === 1) ws.send(JSON.stringify({type: document.hidden && !isOwnerMe() ? "away" : "back"}));
}
function startHeartbeat(ws) {
  clearInterval(S.hb);
  S.hb = setInterval(() => {
    if (ws !== S.ws || ws.readyState !== 1) return;
    if (Date.now() - S.lastRx > HB_DEAD_MS) { try { ws.close(); } catch (_) {} return; }   // server javob bermayapti: ulanish o'lik -> qayta ulanamiz
    ws.send(JSON.stringify({type: "ping", i: Math.round((Date.now() - S.lastAct) / 1000)}));
  }, HB_MS);
}
function reconnectNow() {
  if (!S.token || S.wantClose) return;
  clearTimeout(S.rt); S.retry = 0;
  connect();
}
function connect() {
  S.wantClose = false;
  clearInterval(S.hb); clearTimeout(S.rt);
  if (S.ws) { const old = S.ws; S.ws = null; old.onclose = old.onmessage = old.onopen = null; try { old.close(); } catch (_) {} }   // eski ulanish chala qolmasin
  const ws = SC.socket(S.token);                     // shifrlangan WebSocket (token birinchi shifrlangan kadrda)
  S.ws = ws; S.q = Promise.resolve(); S.lastRx = Date.now();       // yangi ulanish — yangi navbat (eski qotib qolgan navbat bu yerga o'tmaydi)
  ws.onopen = () => { S.retry = 0; S.lastRx = Date.now(); $("connbar").classList.add("hidden"); startHeartbeat(ws); if (document.hidden) sendPresence(); Pend.flush(); };
  ws.onmessage = ev => {                              // tartib saqlanadi: har bir hodisa shifrdan ochilgach qayta ishlanadi
    if (ws !== S.ws) return;
    S.lastRx = Date.now();
    S.q = S.q.then(async () => {
      const m = JSON.parse(ev.data);
      if (m.type === "pong") return;
      await Promise.race([prepare(m), delay(12000)]);   // bitta xabar (kalit kutish, tarmoq) butun navbatni to'xtatib qo'ymasin
      if (ws === S.ws) onMessage(m);
    }).catch(err => console.error(err));
  };
  ws.onclose = ev => {
    if (S.wantClose || ws !== S.ws) return;
    clearInterval(S.hb); S.hb = 0; Pend.onClose();
    if (ev.code === WS_UNAUTHORIZED) return showAuth("Sessiya tugagan, qayta kiring");
    if (ev.code === WS_FORBIDDEN) return showAuth("Siz ban qilingansiz");
    if (ev.code === WS_IP_BLOCKED) return showAuth("IP manzilingiz bloklangan");
    $("connbar").classList.remove("hidden");
    S.retry++;
    S.rt = setTimeout(() => { if (S.token && !S.wantClose) connect(); }, Math.min(600 * S.retry, 6000));
  };
}

/* ---- faolsizlik: oyna/chat ochiq qolib 5 daqiqa tegilmasa — login so'raladi ---- */
S.lastAct = Date.now();
(function () {
  let t = 0;
  const hit = () => { S.lastAct = Date.now(); };
  const slow = () => { const n = Date.now(); if (n - t > 1500) { t = n; S.lastAct = n; } };
  ["pointerdown", "keydown", "touchstart", "click", "input"].forEach(e => addEventListener(e, hit, {passive: true, capture: true}));
  ["pointermove", "wheel", "touchmove", "scroll"].forEach(e => addEventListener(e, slow, {passive: true, capture: true}));
})();
/* "Har kirishda login so'rash" — foydalanuvchining o'z sozlamasi (standart: YOQILGAN). O'chirilsa token va kalitlar shu qurilmada saqlanadi.
   Hevorix (egasi) hech qachon faolsizlikdan chiqarilmaydi va "oflayn"ga o'tmaydi: u guruh kalitini tarqatadi. */
const stayOn = () => { try { return !!localStorage.getItem(LS_STAY); } catch (_) { return false; } };
const isOwnerMe = () => !!(S.me && S.me.role === "owner");
const idleOff = () => stayOn() || isOwnerMe();
const idleExpired = () => !idleOff() && Date.now() - S.lastAct > IDLE_MS;
async function persistStay() {
  try {
    localStorage.setItem(LS_STAY, S.token);
    await E2E.saveIdentity(X.id, {ecdhPriv: X.priv.ecdhPriv, signPriv: X.priv.signPriv, ecdhPub: X.ecdhPub, signPub: X.signPub, iter: X.iter});
  } catch (_) {}
  Off.armStay();
}
async function forgetStay() {
  try { localStorage.removeItem(LS_STAY); } catch (_) {}
  Off.disarmStay();
  try { await E2E.clearIdentity(); } catch (_) {}
}
async function toggleStay() {
  if (stayOn()) {                                                    // login so'rashni qaytadan yoqish
    try { await api("/session/persist", {method: "POST", body: {on: false}}); } catch (_) {}
    await forgetStay(); S.lastAct = Date.now();
    toast("Endi sahifa har safar ochilganda login so'raladi", "ok");
  } else {
    const ok = await confirmDlg("Bu qurilmada sahifani ochgan zahoti login so'ralmasdan kirasiz; sessiya va shifrlash kalitlari shu qurilmada saqlanadi. Qurilmani begonalarga bermang. Davom etamizmi?",
      {title: "Login so'rashni o'chirish", okText: "O'chirish"});
    if (!ok) return;
    try { await api("/session/persist", {method: "POST", body: {on: true}}); await persistStay(); toast("Bu qurilmada endi login so'ralmaydi", "ok"); }
    catch (err) { toast(err.message, "error"); }
  }
}
async function resumeStay(tok, tries) {
  $("autherr").textContent = "Kirilmoqda…";
  S.token = tok; SC.setToken(tok);
  let j;
  try { j = await api("/me"); }
  catch (err) {
    if (String(err.message) === "401") return;                      // api() sessiya tugaganini o'zi ko'rsatdi (showAuth)
    S.token = null; SC.setToken(null);
    $("autherr").textContent = "Ulanish yo'q, qayta urinilmoqda…";
    if (tries < 20) setTimeout(() => resumeStay(tok, tries + 1), 3000);
    return;
  }
  xReset(); S.lastAct = Date.now();
  let ok = false;
  try { ok = await xRestore({upgrade: j.upgrade, e2ee: j.e2ee}, j.me); } catch (_) {}
  if (!ok) { try { await SC.fetch("/api/logout", {method: "POST", headers: {Authorization: "Bearer " + tok}}); } catch (_) {} showAuth("Kalitlarni ochib bo'lmadi, qayta kiring"); return; }
  $("autherr").textContent = "";
  Off.armStay();
  openApp();
}
async function idleLogout() {
  if (!S.token) return;
  const t = S.token;
  showAuth("Uzoq vaqt faol bo'lmadingiz. Xavfsizlik uchun qayta kiring");
  try { await Promise.race([SC.fetch("/api/logout", {method: "POST", headers: {Authorization: "Bearer " + t}}), delay(4000)]); } catch (_) {}
}
function checkIdle() {
  if (!S.token) return;
  // video/audio ijro etilayotgan bo'lsa foydalanuvchi faol hisoblanadi (uzun video ko'rayotganda chiqarib yubormaymiz)
  if ([...document.querySelectorAll("video,audio")].some(m => !m.paused && !m.ended) || (VP.audio && !VP.audio.paused)) S.lastAct = Date.now();
  if (idleExpired()) idleLogout();
}
setInterval(checkIdle, 10000);

/* ---- onlayn/oflayn: boshqa sahifa, ilova, ekran o'chishi, tarmoq ---- */
document.addEventListener("visibilitychange", () => {
  if (!S.token) return;
  if (document.hidden) { S.hiddenAt = Date.now(); sendPresence(); return; }          // yashirildi -> server ozgina kutib (miltillamasin) oflayn qiladi
  if (idleExpired()) { idleLogout(); return; }
  if (!S.ws || S.ws.readyState !== 1) reconnectNow(); else sendPresence();     // qaytdi -> onlayn; ulanish o'lgan bo'lsa darhol qayta ulanadi
});
addEventListener("pagehide", () => { if (S.token && S.ws) { try { S.ws.close(); } catch (_) {} } });   // oyna/tab yopildi: darhol oflayn
addEventListener("pageshow", e => { if (e.persisted && S.token) { if (idleExpired()) idleLogout(); else reconnectNow(); } });
addEventListener("online", () => { if (S.token && (!S.ws || S.ws.readyState !== 1)) reconnectNow(); });
addEventListener("offline", () => { if (S.token) $("connbar").classList.remove("hidden"); });

async function prepare(m) {
  if (X.ready) await Promise.race([X.ready, delay(8000)]);
  if (m.type === "init") await hydrateAll(m.history);
  else if (m.type === "message") await hydrate(m);
  else if (m.type === "message_edited" && m.e2e) {
    const {list} = findMsg(m.id, m.to, m.from, m.ch), x = list.find(i => i.id === m.id);
    if (x) { m._h = Object.assign({}, x, {e2e: m.e2e}); await hydrate(m._h); }
  }
}
function eachMsg(fn) { S.group.msgs.forEach(fn); S.dms.forEach(d => { d.msgs.forEach(fn); d.buffer.forEach(fn); }); }
const snippetOf = t => (t || "").replace(/\s+/g, " ").slice(0, 100);
function partnerOf(m) { return m.user.id === S.me.id ? m.to : m.user.id; }
function findMsg(id, to, from, ch) {
  if (ch) return {list: chOf(ch).msgs, dm: null, ch};
  if (to == null) return {list: S.group.msgs, dm: null};
  const dm = dmOf(from === S.me.id ? to : from);
  return {list: dm.msgs, dm};
}
const atBottom = () => { const b = $("msgs"); return b.scrollHeight - b.scrollTop - b.clientHeight < 80; };
const isActiveGroup = () => S.active && S.active.kind === "group";
const isActiveDm = uid => S.active && S.active.kind === "dm" && S.active.uid === uid;

function onMessage(m) {
  switch (m.type) {
    case "init": {
      S.me = Object.assign({}, S.me, m.me); upsertUser(m.me);
      S.online = new Set(m.online_ids);
      m.history.forEach(x => upsertUser(x.user));
      mergeHistory(S.group, m.history, !!m.more);           // qayta ulanganda tepaga chiqib yuklangan eski xabarlar yo'qolmaydi
      S.chat = m.chat || {slowmode: 0, locked: false};
      loadMembers(); loadDialogs();
      if (S.active && S.active.kind === "dm") reloadActiveDm();
      if (S.active && S.active.kind === "channel") reloadActiveChannel();
      if (!S.active && !isMobile()) openChat({kind: "group"}); else { renderList(); renderHeader(); renderMessages(true); }
      if (S.pendingOpen) { if (S.pendingOpen.k !== "d") applyPendingOpen(); else if (X.ready) X.ready.then(applyPendingOpen); }
      break; }
    case "nack": Pend.nack(m); break;                  // server xabarni qabul qilmadi (cid bo'yicha)
    case "message": {
      upsertUser(m.user);
      if (m.ch) { onChannelPost(m); break; }
      const mine = m.user.id === S.me.id;
      if (mine && m.id != null) {                         // qayta yuborishdan serverning takror javobi: xabar allaqachon ro'yxatda bo'lsa — faqat pufak almashadi
        const arr = m.to == null ? S.group.msgs : (() => { const d = dmOf(partnerOf(m)); return d.loaded ? d.msgs : d.buffer; })();
        if (arr.slice(-80).some(x => x && x.id === m.id)) { const q = m.cid && Pend.list.find(x => x.cid === m.cid); if (q) Pend.drop(q); break; }
      }
      if (mine) Pend.settle(m); else typingClearFrom(m.user.id);          // o'zimizniki: vaqtincha pufak almashadi; boshqaniki: "yozmoqda" yo'qoladi
      const muted = !mine && m.to != null && isMuted(m.user.id);          // "Mute" bosilgan suhbat: ovoz va mahalliy bildirishnoma yo'q
      if (!mine && !muted) pingSound(m.to == null ? isActiveGroup() : isActiveDm(partnerOf(m)));
      if (!mine && !muted && document.hidden && Date.now() - (S.hiddenAt || 0) < 7000)     // yashirilganiga <7 s: server hali oflayn deb push yubormagan
        Push.local({k: m.to == null ? "g" : "d", u: m.user.id, i: m.id, n: m.user.nickname || m.user.username, t: Math.floor(Date.now() / 1000)});
      if (m.to == null) {
        const stick = atBottom();
        S.group.msgs.push(m);
        if (isActiveGroup()) {
          appendMessage(m, mine || stick);
          if (!mine && !stick) bumpAway();
        } else if (!mine) S.group.unread++;
      } else {
        const pid = partnerOf(m), dm = dmOf(pid);
        if (!S.users.has(pid)) loadMembers();
        dm.last = m;
        if (dm.loaded) dm.msgs.push(m); else dm.buffer.push(m);
        if (isActiveDm(pid)) {
          const stick = atBottom();
          appendMessage(m, mine || stick);
          if (!mine) {
            if (!document.hidden) { dm.unread = 0; wsSend({type: "read", with: pid}); }
            else dm.unread++;
            if (!stick) bumpAway();
          }
        } else if (!mine) dm.unread++;
      }
      renderList();
      break; }
    case "message_edited": {
      const {list, dm, ch} = findMsg(m.id, m.to, m.from, m.ch);
      const x = list.find(i => i.id === m.id);
      if (m._h) m.content = m._h.content;
      if (x) {
        if (m._h) Object.assign(x, {content: m._h.content, e2e: m.e2e, verified: m._h.verified, bad: m._h.bad, locked: m._h.locked, _r: m._h._r, reply: m._h.reply});
        else x.content = m.content;
        x.edited = true;
      }
      eachMsg(y => { if (y.reply && y.reply.id === m.id && !y.reply.deleted) y.reply.text = snippetOf(m.content); });
      if (dm && dm.last && dm.last.id === m.id) { dm.last.content = m.content; dm.last.edited = true; if (m._h) Object.assign(dm.last, {e2e: m.e2e, bad: m._h.bad, locked: m._h.locked}); }
      if (ch) { const st = chOf(ch); if (st.last && st.last.id === m.id && st.last !== x && m._h) Object.assign(st.last, {content: m._h.content, e2e: m.e2e, bad: m._h.bad, locked: m._h.locked}); }
      renderMessages(false); renderList();
      break; }
    case "message_reaction": {
      const {list, dm} = findMsg(m.id, m.to, m.from, m.ch);
      const x = list.find(i => i.id === m.id) || (dm && dm.buffer.find(i => i.id === m.id));
      if (x) { x.rx = m.rx || {}; patchReactions(x); }
      break; }
    case "message_deleted": {
      const {list, dm, ch} = findMsg(m.id, m.to, m.from, m.ch);
      const i = list.findIndex(x => x.id === m.id);
      if (i >= 0) list.splice(i, 1);
      eachMsg(y => { if (y.reply && y.reply.id === m.id) y.reply = {id: m.id, deleted: true}; });
      if (S.editing && S.editing.id === m.id) cancelEdit();
      if (S.replying && S.replying.id === m.id) cancelReply();
      if (VP.id === m.id) voiceStop();
      if (VN.id === m.id) vnStop();
      if (S.sel && S.sel.delete(m.id)) updateSelBar();
      if (ch) {
        const st = chOf(ch), info = chInfo(ch);
        st.buffer = st.buffer.filter(x => x.id !== m.id);
        if (st.last && st.last.id === m.id) st.last = st.msgs.length ? st.msgs[st.msgs.length - 1] : null;
        if (info && info.posts > 0) info.posts--;
        Channels.postGone(ch, m.id);
      }
      if (dm) {
        dm.buffer = dm.buffer.filter(x => x.id !== m.id);
        if (dm.last && dm.last.id === m.id) { dm.last = dm.msgs.length ? dm.msgs[dm.msgs.length - 1] : null; if (!dm.loaded || !dm.last) loadDialogs(); }
      }
      scheduleRender();
      break; }
    case "channels_changed": case "channel_post": case "channel_post_edited": case "channel_post_deleted":
    case "channel_views": case "channel_comment": case "channel_comment_deleted":
      Channels.onEvent(m); break;
    case "chat_settings":
      S.chat = {slowmode: m.slowmode || 0, locked: !!m.locked};
      renderHeader();
      if (isActiveGroup() && !amAdmin()) toast(S.chat.locked ? "Admin umumiy chatni qulfladi" : (S.chat.slowmode ? "Sekin rejim: " + S.chat.slowmode + " soniya" : "Umumiy chat ochildi"), "warn");
      break;
    case "media_removed": {                              // admin faylni o'chirdi (izoh matni qoladi)
      const x = S.group.msgs.find(i => i.id === m.id);
      if (x) { x.image = null; x.thumb = null; x.w = x.h = null; x.file = null; }
      S.imgs.delete(m.id); if (VP.id === m.id) voiceStop(); if (VN.id === m.id) vnStop();
      const u = S.played.get(m.id); if (u) { URL.revokeObjectURL(u); S.played.delete(m.id); }
      eachMsg(y => { if (y.reply && y.reply.id === m.id) { y.reply.image = false; y.reply.file = false; } });
      renderMessages(false); renderList();
      break; }
    case "e2ee_room": case "e2ee_wrap": loadRoom().catch(() => {}); break;
    case "e2ee_rotate_hint": if (amAdmin()) rotateRoom(m.reason); break;
    case "report_new": toast("Yangi shikoyat keldi (☰ → Admin sozlamalari → Shikoyatlar)", "warn"); break;
    case "chat_cleared": {
      const gone = new Set(S.group.msgs.map(x => x.id));
      eachMsg(y => { if (y.reply && gone.has(y.reply.id)) y.reply = {id: y.reply.id, deleted: true}; });
      S.group.msgs = [];
      if (isActiveGroup()) { cancelEdit(); cancelReply(); exitSelect(); }
      renderMessages(false); renderList();
      toast(m.by === S.me.id ? "Chat tozalandi" : "Admin umumiy chatni tozaladi", "ok");
      break; }
    case "read": {
      const dm = S.dms.get(m.by);
      if (dm) {
        dm.msgs.forEach(x => { if (x.user.id === S.me.id) x.read = true; });
        if (dm.last && dm.last.user.id === S.me.id) dm.last.read = true;
        if (isActiveDm(m.by)) renderMessages(false);
      }
      break; }
    case "typing": onTyping(m); break;
    case "presence":
      if (m.online) S.online.add(m.uid); else { S.online.delete(m.uid); const pu = S.users.get(m.uid); if (pu && m.ts) pu.last_seen = m.ts; typingClearFrom(m.uid); }
      if (!S.users.has(m.uid)) loadMembers();
      renderList(); renderHeader(); refreshModal();
      break;
    case "members_changed": loadMembers(); loadDialogs(); break;
    case "dm_cleared": {
      const other = m.a === S.me.id ? m.b : m.a;
      S.dms.delete(other);
      const wasActive = isActiveDm(other);
      if (wasActive) closeChat();
      renderList();
      toast(m.a === S.me.id ? "Suhbat o'chirildi" : "Suhbat o'chirildi (boshqa tomon o'chirdi)", "ok");
      break; }
    case "user_removed":
      upsertUser(m.user);
      S.members = S.members.filter(x => x.id !== m.user.id); S.online.delete(m.user.id);
      renderList(); renderHeader(); renderMessages(false); refreshModal();
      break;
    case "account_removed": showAuth("Akkauntingiz o'chirildi"); break;
    case "emoji_update": loadEmojis(); break;
    case "user_update":
      upsertUser(m.user);
      renderList(); renderHeader(); renderMessages(false); refreshModal();
      break;
    case "system":
      toast(m.lines.join("\n"), m.level);
      if (m.level === "warn") { S.group.msgs.push({service: true, text: m.lines.join(" "), ts: Date.now() / 1000}); if (isActiveGroup()) renderMessages(false); }
      break;
    case "banned": showAuth("Siz ban qilindingiz" + (m.reason ? ": " + m.reason : "")); break;
  }
}

function onChannelPost(m) {
  const mine = m.user.id === S.me.id, st = chOf(m.ch), info = chInfo(m.ch);
  if (!mine) pingSound(isActiveChan(m.ch));
  if (!mine && document.hidden && Date.now() - (S.hiddenAt || 0) < 7000)
    Push.local({k: "c", u: m.ch, i: m.id, n: info ? info.nickname : "Kanal", t: Math.floor(Date.now() / 1000)});
  if (info) { info.posts++; info.last_post = m.id; info.last_ts = m.ts; S.chList.sort((a, b) => (b.last_ts || b.created || 0) - (a.last_ts || a.created || 0)); }
  else Channels.loadList();
  st.last = m;
  if (st.loaded) { if (!st.msgs.some(x => x.id === m.id)) st.msgs.push(m); }
  else if (!st.buffer.some(x => x.id === m.id)) st.buffer.push(m);
  if (isActiveChan(m.ch)) {
    const stick = atBottom();
    appendMessage(m, mine || stick);
    if (!mine && !stick) bumpAway();
    renderHeader();
  } else if (!mine) st.unread++;
  renderList();
}
async function loadChannelPosts(id) {
  const st = chOf(id);
  const j = await api("/channels/" + id + "/posts?limit=10");
  if (X.ready) await Promise.race([X.ready, delay(8000)]);
  await hydrateAll(j.posts);
  j.posts.forEach(x => upsertUser(x.user));
  const ids = new Set(j.posts.map(x => x.id));
  const fresh = j.posts.concat(st.buffer.filter(x => !ids.has(x.id))).sort((a, b) => a.id - b.id);
  mergeHistory(st, fresh, !!j.more);
  st.buffer = []; st.loaded = true;
  if (st.msgs.length) st.last = st.msgs[st.msgs.length - 1];
}
async function reloadActiveChannel() {
  const id = S.active.id;
  try { await loadChannelPosts(id); if (isActiveChan(id)) renderMessages(true); } catch (_) {}
}
/** js/channels.js ro'yxatni yuklaganda chaqiradi: oxirgi postlar ham ochiladi (ro'yxatda ko'rinishi uchun). */
async function setChannelList(list) {
  S.chList = list;
  renderList(); renderHeader();
  if (X.ready) await Promise.race([X.ready, delay(8000)]);
  for (const c of list) {
    if (!c.last) continue;
    const st = chOf(c.id);
    if (st.last && st.last.id >= c.last.id) continue;
    upsertUser(c.last.user); await hydrate(c.last); st.last = c.last;
  }
  renderList();
}
function chanAvatar(c, size) {
  const el = h("div", {class: "av av-" + size + " chn"});
  el.style.setProperty("--avc", colorOf((c.id || 0) + 3));
  if (c.avatar) el.append(h("img", {src: c.avatar, alt: "", draggable: "false"}));
  else el.append(h("span", {text: (Array.from((c.nickname || "?").trim())[0] || "?").toUpperCase()}));
  return el;
}
/** Server hodisasi (ko'rishlar/izohlar soni) post kartasiga: xotira va ekran yangilanadi. */
function patchPost(ch, pid, fields) {
  const m = chOf(ch).msgs.find(x => x.id === pid);
  if (m) Object.assign(m, fields);
  if (!isActiveChan(ch)) return;
  const row = document.querySelector('#msgs .row[data-id="' + Number(pid) + '"]'); if (!row) return;
  const v = row.querySelector(".vws b"); if (v && fields.views != null) v.textContent = String(fields.views);
  const c = row.querySelector(".cmb-t"); if (c && fields.comments != null) c.textContent = fields.comments ? fields.comments + " ta izoh" : "Izoh qoldirish";
}

async function loadMembers() {
  try {
    const j = await api("/members");
    S.members = j.members; S.online = new Set(j.online_ids);
    j.members.forEach(upsertUser);
    renderList(); renderHeader(); refreshModal();
    serveWraps();
  } catch (_) {}
}
async function loadDialogs() {
  try {
    const j = await api("/dialogs");
    if (X.ready) await X.ready;
    await hydrateAll(j.dialogs.map(d => d.last).filter(Boolean));
    const seen = new Set();
    j.dialogs.forEach(d => {
      upsertUser(d.user); seen.add(d.user.id);
      const dm = dmOf(d.user.id); dm.last = d.last; dm.unread = isActiveDm(d.user.id) ? 0 : d.unread;
    });
    S.dms.forEach((dm, uid) => {                       // serverda yo'q suhbat (masalan, boshqa tomon o'chirgan)
      if (seen.has(uid)) return;
      if (isActiveDm(uid)) { dm.msgs = []; dm.buffer = []; dm.last = null; renderMessages(false); }
      else S.dms.delete(uid);
    });
    renderList();
  } catch (_) {}
}
async function loadDm(uid) {
  const dm = dmOf(uid);
  const j = await api("/dm/" + uid);
  if (X.ready) await Promise.race([X.ready, delay(8000)]);
  await hydrateAll(j.history);
  const ids = new Set(j.history.map(x => x.id));
  const fresh = j.history.concat(dm.buffer.filter(x => !ids.has(x.id))).sort((a, b) => a.id - b.id);
  mergeHistory(dm, fresh, !!j.more);
  dm.buffer = []; dm.loaded = true;
  if (dm.msgs.length) dm.last = dm.msgs[dm.msgs.length - 1];
}
/* Tarix: dastlab faqat oxirgi 10 ta xabar. Tepaga chiqilganda oldingilari sahifalab yuklanadi (loadOlder). */
function mergeHistory(st, fresh, more) {
  const old = st.msgs.filter(x => !x.service && x.id);
  if (!old.length || !fresh.length || old[old.length - 1].id < fresh[0].id) { st.msgs = fresh.slice(); st.more = more; return; }
  const keep = old.filter(x => x.id < fresh[0].id);            // yangi oynadan oldingi (tepaga chiqib yuklangan) xabarlar saqlanadi
  st.msgs = keep.concat(fresh);
  if (!keep.length) st.more = more;
}
async function loadOlder() {
  if (!S.active || S.olderBusy) return;
  const kind = S.active.kind, isG = kind === "group", isC = kind === "channel", uid = S.active.uid, cid = S.active.id;
  const st = isG ? S.group : isC ? chOf(cid) : dmOf(uid);
  if (st.msgs.length > (S.win || WIN0)) {                     // xotirada bor, lekin chizilmagan eski xabarlar: tarmoqsiz, darrov
    const bx = $("msgs"), ph = bx.scrollHeight, pt = bx.scrollTop;
    S.win = (S.win || WIN0) + 40; renderMessages(false); bx.scrollTop = pt + (bx.scrollHeight - ph); return;
  }
  if (!st.more) return;
  const first = st.msgs.find(x => !x.service && x.id); if (!first) return;
  S.olderBusy = true;
  const box = $("msgs"), btn = box.querySelector(".older"); if (btn) btn.textContent = "Yuklanmoqda…";
  try {
    const j = await api(isG ? "/group/history?before=" + first.id : isC ? "/channels/" + cid + "/posts?limit=20&before=" + first.id : "/dm/" + uid + "?before=" + first.id);
    const older = isC ? j.posts : j.history;
    if (X.ready) await Promise.race([X.ready, delay(8000)]);
    await hydrateAll(older);
    older.forEach(x => upsertUser(x.user));
    const have = new Set(st.msgs.map(x => x.id));
    st.msgs = older.filter(x => !have.has(x.id)).concat(st.msgs);
    S.win = (S.win || WIN0) + older.length;
    st.more = !!j.more;
    if (S.active && S.active.kind === kind && (isG || (isC ? S.active.id === cid : S.active.uid === uid))) {
      const prevH = box.scrollHeight, prevT = box.scrollTop;
      renderMessages(false);
      box.scrollTop = prevT + (box.scrollHeight - prevH);       // ko'rib turgan joyingiz joyida qoladi
    }
  } catch (err) { toast(err.message, "error"); if (btn) btn.textContent = "⬆ Oldingi xabarlar"; }
  S.olderBusy = false;
}
async function reloadActiveDm() {
  const uid = S.active.uid;
  try { await loadDm(uid); if (isActiveDm(uid)) { renderMessages(true); wsSend({type: "read", with: uid}); } } catch (_) {}
}

/* ---------------- chap panel: ro'yxat ---------------- */
function itemEl({av, title, sub, subOn, time, unread, active, onclick, onctx}) {
  const el = h("div", {class: "item" + (active ? " active" : ""), onclick, oncontextmenu: onctx ? e => { e.preventDefault(); e.stopPropagation(); onctx(e.clientX, e.clientY); } : null},
    av,
    h("div", {class: "i-mid"},
      h("div", {class: "i-top"}, h("div", {class: "i-title"}, title), time ? h("span", {class: "i-time", text: time}) : null),
      h("div", {class: "i-bot"}, h("div", {class: "i-sub" + (subOn ? " on" : "")}, sub),
        unread ? h("span", {class: "pill", text: unread > 99 ? "99+" : String(unread)}) : null)));
  if (onctx) longPress(el, (x, y) => onctx(x, y, true));
  return el;
}
const typingSub = key => { const t = typingLabel(key); return t ? h("span", {class: "typing"}, t) : null; };       // ro'yxatda oxirgi xabar o'rnida "yozmoqda…"
function previewOf(m, withAuthor, plain) {
  if (!m) return "";
  const mine = !plain && m.user.id === S.me.id;
  let body = m.locked ? "🔒 Shifrlangan xabar" : m.bad ? "⚠ Shifrni ochib bo'lmadi" : m.content;
  if (!m.locked && !m.bad && m.content) {                                // kod / buyruq xabarlari ro'yxatda qisqa belgi bilan ko'rinadi
    const rp = Rich.parse(m.content), rc = rp.find(x => x.k !== "text");
    if (rc) body = (rc.k === "term" ? "⌨ Linux buyruq: " + Rich.copyTextOf(rc).split("\n")[0] : "‹/› " + (rc.label || "Kod") + ": " + rc.code.split("\n")[0]);
  }
  const text = (m.image ? "📷 " : m.file ? fileIco(m.file) : "") + (body ? body.replace(/\s+/g, " ") : (m.image ? "Rasm" : m.file ? fileWhat(m.file) : ""));
  const shown = Rich.hasInlineEmoji(text) ? Rich.preview(text) : text;      // «:005:» kodi o'rniga emoji rasmi
  if (mine) return [h("b", {text: "Siz: "}), shown];
  return withAuthor ? [h("b", {text: m.user.nickname + ": "}), shown] : shown;
}
function groupItem() {
  const last = [...S.group.msgs].reverse().find(x => !x.service);
  return itemEl({
    av: groupAvatar("m"), title: h("span", {class: "nt", text: "Umumiy chat"}),
    sub: typingSub("g") || (last ? previewOf(last, true) : "Hozircha xabar yo'q"), subOn: !!typingLabel("g"), time: last ? listTime(last.ts) : "",
    unread: S.group.unread, active: isActiveGroup(), onclick: () => openChat({kind: "group"}),
  });
}
function dmItem(u, dm) {
  return itemEl({
    av: avatar(u, "m", true), title: nameEl(u), sub: typingSub("d" + u.id) || previewOf(dm.last, false), subOn: !!typingLabel("d" + u.id), time: listTime(dm.last.ts),
    unread: dm.unread, active: isActiveDm(u.id), onclick: () => openChat({kind: "dm", uid: u.id}),
    onctx: (x, y, touch) => dmMenu(x, y, u.id, touch),
  });
}
function chanItem(c) {
  const st = chOf(c.id), last = st.last;
  return itemEl({
    av: chanAvatar(c, "m"), title: [h("span", {class: "nt", text: c.nickname}), c.private ? icon("lock", "ic ch-lock") : null],
    sub: last ? previewOf(last, false, true) : c.posts ? c.posts + " post" : "Hozircha post yo'q",
    time: last ? listTime(last.ts) : "", unread: st.unread, active: isActiveChan(c.id), onclick: () => openChat({kind: "channel", id: c.id}),
  });
}
function memberItem(u) {
  const sub = (isStaff(u) ? roleLabel(u.role) + " • " : "") + statusText(u);
  return itemEl({
    av: avatar(u, "m", true), title: nameEl(u), sub, subOn: isOnline(u.id),
    active: isActiveDm(u.id), onclick: () => openChat({kind: "dm", uid: u.id}),
  });
}
function renderList() {
  if (!S.me) return;
  Off.dirty();                                        // oflayn xotira: o'zgarish bo'lsa keyinroq (fonda) shifrlab saqlanadi
  const list = $("list"), top = list.scrollTop;
  list.textContent = "";
  const q = S.query.trim().toLowerCase();
  const match = u => !q || u.nickname.toLowerCase().includes(q) || u.username.toLowerCase().includes(q);
  if (S.tab === "chats") {
    if (!q || "umumiy chat".includes(q)) list.append(groupItem());
    const dms = [...S.dms.entries()].filter(([, d]) => d.last).sort((a, b) => b[1].last.ts - a[1].last.ts);
    dms.forEach(([id, d]) => { const u = U(id); if (match(u)) list.append(dmItem(u, d)); });
    if (q) {
      const shown = new Set(dms.map(([id]) => id));
      const others = S.members.filter(m => m.id !== S.me.id && !shown.has(m.id) && match(m));
      if (others.length) { list.append(h("div", {class: "sect", text: "A'zolar"})); others.forEach(m => list.append(memberItem(U(m.id)))); }
    }
    if (!list.children.length) list.append(h("div", {class: "none", text: "Hech narsa topilmadi"}));
  } else if (S.tab === "channels") {
    list.append(h("div", {class: "chn-bar"},
      amAdmin() ? h("button", {class: "btn ghost sm", type: "button", onclick: () => Channels.create()}, icon("plus"), " Kanal yaratish") : null,
      h("button", {class: "btn ghost sm", type: "button", onclick: () => Channels.join()}, icon("lock"), " Shaxsiy kanalga qo'shilish")));
    const cs = S.chList.filter(c => !q || c.nickname.toLowerCase().includes(q) || c.username.toLowerCase().includes(q));
    cs.forEach(c => list.append(chanItem(c)));
    if (!cs.length) list.append(h("div", {class: "none", text: S.chList.length ? "Hech narsa topilmadi" : "Hozircha kanallar yo'q"}));
  } else {
    const all = S.members.filter(m => m.id !== S.me.id && match(m)).map(m => U(m.id));
    const on = all.filter(u => isOnline(u.id)), off = all.filter(u => !isOnline(u.id));
    if (on.length) { list.append(h("div", {class: "sect", text: "Onlayn — " + on.length})); on.forEach(u => list.append(memberItem(u))); }
    if (off.length) { list.append(h("div", {class: "sect", text: "Oflayn"})); off.forEach(u => list.append(memberItem(u))); }
    if (!all.length) list.append(h("div", {class: "none", text: S.members.length > 1 ? "Hech narsa topilmadi" : "Hozircha boshqa a'zolar yo'q"}));
  }
  list.scrollTop = top;
  updateBadges();
}
function updateBadges() {
  let total = S.group.unread, ctot = 0;
  S.dms.forEach(d => { total += d.unread; });
  S.chn.forEach(c => { ctot += c.unread; });
  const b = $("chatsBadge");
  b.classList.toggle("hidden", !total); b.textContent = total > 99 ? "99+" : String(total);
  const cb = $("chnBadge");
  cb.classList.toggle("hidden", !ctot); cb.textContent = ctot > 99 ? "99+" : String(ctot);
  document.title = (total + ctot ? "(" + (total + ctot) + ") " : "") + APP_NAME;
}
document.querySelectorAll(".tabs button[data-tab]").forEach(btn => btn.addEventListener("click", () => {
  S.tab = btn.dataset.tab;
  document.querySelectorAll(".tabs button").forEach(x => x.classList.toggle("on", x === btn));
  renderList();
  if (S.tab === "channels") Channels.loadList();
}));
$("search").addEventListener("input", e => { S.query = e.target.value; renderList(); });

/* ---------------- admin sozlamalari: chap menyu (3 chiziqcha) → Sozlamalar ostida ----------------
   Har bir bo'lim alohida sahifa bo'lib o'ngdan chapga suriladi (openPage tizimi). */
const ADM_SECTIONS = [
  ["ips", "shield", "IP lar va profillar"],
  ["users", "user", "Foydalanuvchilar, nishon va zaxira"],
  ["log", "list", "Harakatlar logi"],
  ["blocks", "ban", "Bloklangan IP lar"],
  ["media", "attach", "Media boshqaruvi"],
  ["reports", "flag", "Shikoyatlar"],
  ["mod", "shield", "Moderatsiya sozlamalari"],
];
const ADM_TITLES = {msgs: "Xabarlar", emoji: "Emoji boshqaruvi"};
ADM_SECTIONS.forEach(([k, , t]) => { ADM_TITLES[k] = t; });
function openAdminHome() {
  if (!amAdmin()) return;
  openPage(() => {
    const wrap = h("div", {}, pageHead("Admin sozlamalari"), gapEl());
    ADM_SECTIONS.forEach(([k, ic, t]) => wrap.append(setRow(ic, t, () => openAdmin(k))));
    wrap.append(gapEl(), setRow("chat", "Xabarlar", () => openAdmin("msgs")), setRow("emoji", "Emoji boshqaruvi", () => openAdmin("emoji")));
    wrap.append(gapEl(), setRow("trash", "Umumiy chatni tozalash", () => clearGroupChat(), null, true));
    return wrap;
  });
}

/* ---------------- chat oynasi ---------------- */
function currentMsgs() {
  if (!S.active) return [];
  if (S.active.kind === "channel") return chOf(S.active.id).msgs;
  return S.active.kind === "group" ? S.group.msgs : dmOf(S.active.uid).msgs;
}
/* Oyna almashganda eski suhbat bir lahzaga ko'rinib qolmasligi uchun: har suhbatning kaliti bor, DOM faqat o'sha suhbatga tegishli bo'ladi */
const chatKey = t => !t ? "" : t.kind === "dm" ? "d" + t.uid : t.kind === "channel" ? "c" + t.id : "g";
let _closeT = 0;
function wipeChatDom() {                            // chat oynasining eski mazmunini (xabarlar, sarlavha) tozalaydi
  const box = $("msgs"); box.textContent = ""; box._for = ""; box._n = 0;
  $("hav").textContent = ""; $("htitle").textContent = ""; $("hsub").textContent = "";
}
async function openChat(target) {
  clearTimeout(_closeT);
  if (chatKey(target) !== $("msgs")._for) wipeChatDom();     // boshqa suhbat: eski xabarlar va sarlavha yo'qoladi, keyin panel suriladi
  $("chat").classList.add("opening"); requestAnimationFrame(() => requestAnimationFrame(() => $("chat").classList.remove("opening")));
  if (S.sel) { S.sel = null; $("chat").classList.remove("selecting"); navPop("sel"); }
  Channels.closeComments(false);
  Typing.stop(); S.active = target; S.win = WIN0;
  cancelRecording(); cancelEdit(); cancelReply(); clearPendingImage(); $("inp").value = ""; autosize(); S.away = 0; bumpAway(true);
  $("empty").classList.add("hidden"); $("chat").classList.remove("hidden");
  document.body.classList.add("in-chat");
  if (isMobile()) navPush("chat");
  if (target.kind === "group") S.group.unread = 0;
  else if (target.kind === "channel") {
    const st = chOf(target.id); st.unread = 0;
    if (!st.loaded) {
      renderHeader(); $("msgs").textContent = "";
      try { await loadChannelPosts(target.id); } catch (err) { toast(err.message, "error"); }
      if (!isActiveChan(target.id)) return;
    }
  } else {
    const dm = dmOf(target.uid); dm.unread = 0;
    if (!dm.loaded) {
      renderHeader(); $("msgs").textContent = "";
      try { await loadDm(target.uid); } catch (err) { toast(err.message, "error"); }
      if (!isActiveDm(target.uid)) return;
    }
    if (!S.offline) wsSend({type: "read", with: target.uid});
  }
  renderHeader(); renderMessages(true); renderList();
  autosize();
  if (!isMobile()) $("inp").focus();
  Composer.guard(); requestAnimationFrame(Composer.guard); setTimeout(Composer.guard, 350); setTimeout(Composer.guard, 1200);
}
function closeChat() {
  Typing.stop();
  Channels.closeComments(false);
  if (S.sel) { S.sel = null; $("chat").classList.remove("selecting"); navPop("sel"); }
  S.active = null; cancelEdit(); cancelReply(); clearPendingImage();
  document.body.classList.remove("in-chat"); navPop("chat");
  if (!isMobile()) { $("chat").classList.add("hidden"); $("empty").classList.remove("hidden"); wipeChatDom(); }
  else {                                            // panel yopilish animatsiyasi tugagach (u paytda ko'rinmaydi) eski xabarlar DOM'dan olinadi
    clearTimeout(_closeT);
    _closeT = setTimeout(() => { if (!S.active) { wipeChatDom(); $("chat").classList.add("hidden"); } }, 520);
  }
  renderList();
}
function renderHeader() {
  if (!S.active || !S.me) return;
  const av = $("hav"), title = $("htitle"), sub = $("hsub");
  av.textContent = ""; title.textContent = ""; sub.className = "hsub";
  if (S.active.kind === "group") {
    av.append(groupAvatar("m")); title.append(h("span", {class: "nt", text: "Umumiy chat"}));
    sub.textContent = (S.members.length || 1) + " a'zo, " + onlineCount() + " onlayn" + (S.chat.locked ? " • 🔒 qulflangan" : S.chat.slowmode ? " • 🐢 " + S.chat.slowmode + " s" : "") + (X.epoch && !X.rooms.has(X.epoch) ? " • ⏳ kalit kutilmoqda" : "");
    const tg = typingLabel("g"); if (tg) { sub.textContent = tg; sub.classList.add("on", "typing"); }          // "Ali yozmoqda…"
  } else if (S.active.kind === "channel") {
    const c = chInfo(S.active.id);
    av.append(chanAvatar(c || {id: S.active.id, nickname: "?"}, "m"));
    title.append(h("span", {class: "nt", text: c ? c.nickname : "Kanal"})); if (c && c.private) title.append(icon("lock", "ic ch-lock"));
    sub.textContent = c ? "@" + c.username + " • " + c.posts + " post" + (c.private ? " • shaxsiy" : "") + (c.can_manage && c.private ? " • " + (c.members || 0) + " a'zo" : "") : "";
  } else {
    const u = U(S.active.uid);
    av.append(avatar(u, "m", true)); title.append(nameEl(u));
    sub.textContent = statusText(u) + (X.changed.has(u.id) ? " • ⚠ kalit o'zgargan" : ""); if (isOnline(u.id)) sub.classList.add("on");
    const td = typingLabel("d" + u.id); if (td) { sub.textContent = td; sub.classList.add("on", "typing"); }    // "yozmoqda…", "fayl yubormoqda…", "emoji tanlamoqda…"
  }
  $("chMore").classList.toggle("hidden", S.active.kind === "group");
  const g = syncChatGate();
  inp.placeholder = S.active.kind === "channel" ? "Kanalga post yozing…" : "Xabar yozing…";
  if (g.chanRO || g.locked || g.dead) { cancelEdit(); cancelReply(); clearPendingImage(); }
}
/* Yozish paneli holati (readonly / dead / locked) faqat HAQIQIY holatdan hisoblanadi — eskirgan klass qolib ketmaydi */
function syncChatGate() {
  const c = $("chat"), a = S.active;
  const chanRO = !!a && a.kind === "channel" && !amAdmin();           // oddiy a'zo kanalga yozolmaydi (faqat o'qiydi va izoh qoldiradi)
  const dead = !!a && a.kind === "dm" && !!(U(a.uid) || {}).deleted;
  const locked = !!a && a.kind === "group" && !!S.chat.locked && !amAdmin();
  c.classList.toggle("readonly", chanRO); c.classList.toggle("dead", dead); c.classList.toggle("locked", locked);
  return {chanRO, dead, locked};
}
$("hinfo").addEventListener("click", () => {
  if (!S.active) return;
  if (S.active.kind === "group") openGroupInfo(); else if (S.active.kind === "channel") Channels.info(S.active.id); else openProfile(S.active.uid);
});
$("backBtn").addEventListener("click", closeChat);

function bumpAway(reset) {
  if (reset) S.away = 0; else S.away++;
  const tb = $("tbBadge");
  tb.textContent = String(S.away); tb.classList.toggle("hidden", !S.away);
}
const WIN0 = 80;                                    // ekranda bir vaqtda ko'pi bilan shuncha xabar (eskilari tepaga chiqilganda qo'shiladi)
function msgFlags(list, k) {                        // xabar guruhining boshi/oxiri (avatar va masofa uchun)
  const c = list[k], p = list[k - 1], n = list[k + 1], d = dayKey(c.ts);
  return [!p || p.service || p.user.id !== c.user.id || dayKey(p.ts) !== d || c.ts - p.ts > 300,
          !n || n.service || n.user.id !== c.user.id || dayKey(n.ts) !== d || n.ts - c.ts > 300];
}
function renderMessages(stick) {
  if (!S.active || !S.me) return;
  const box = $("msgs"), prevTop = box.scrollTop;
  const all = currentMsgs(), isGroup = S.active.kind === "group", chan = S.active.kind === "channel";
  const hiddenN = Math.max(0, all.length - (S.win || WIN0)), list = hiddenN ? all.slice(hiddenN) : all;
  box.textContent = "";
  let prev = null, lastDay = "";
  const pg = isGroup ? S.group : chan ? chOf(S.active.id) : dmOf(S.active.uid);
  if (pg.more || hiddenN) box.append(h("button", {class: "older", type: "button", text: "⬆ Oldingi xabarlar", onclick: loadOlder}));
  if (!list.length) box.append(h("div", {class: "blank", text: chan ? "Kanalda hali post yo'q" : isGroup ? "Hozircha xabar yo'q. Birinchi bo'lib yozing 👋" : "Suhbatni boshlang — xabar yozing 👋"}));
  list.forEach((m, i) => {
    if (m.service) { box.append(h("div", {class: "svc", text: m.text})); prev = null; return; }
    const day = dayKey(m.ts);
    if (day !== lastDay) { box.append(h("div", {class: "day", text: dayLabel(m.ts)})); lastDay = day; prev = null; }
    const next = list[i + 1];
    const first = !prev || prev.user.id !== m.user.id || m.ts - prev.ts > 300;
    const last = !next || next.service || next.user.id !== m.user.id || dayKey(next.ts) !== day || next.ts - m.ts > 300;
    box.append(bubbleRow(m, isGroup, chan || first, chan || last, chan));
    prev = m;
  });
  box._stick = !!stick; box._n = list.length; box._for = chatKey(S.active);
  if (chan) Channels.track(box, S.active.id);
  if (stick) { box.scrollTop = box.scrollHeight; bumpAway(true); } else box.scrollTop = prevTop;
  Pend.mount(!!stick);                                // yuborilayotgan xabarlar pastda qoladi
  toggleToBottom();
  if ((pg.more || hiddenN) && !S.olderBusy && box.scrollHeight <= box.clientHeight + 60) setTimeout(loadOlder, 0);   // ekran to'lmasa tepaga chiqib bo'lmaydi: o'zi yuklaydi
}
function appendMessage(m, stick) {                 // tez yo'l: bitta qator qo'shiladi (rasmlar qayta yuklanmaydi, qotmaydi)
  const box = $("msgs"), list = currentMsgs(), i = list.length - 1;
  if (!S.active || !S.me || S.sel || list[i] !== m || box.querySelector(".blank")) return renderMessages(stick);
  if (stick && (box._n || 0) >= 220) { S.win = WIN0; return renderMessages(true); }      // DOM juda o'sib ketmasin
  const isG = S.active.kind === "group", chan = S.active.kind === "channel", prevM = list[i - 1];
  let prevRow = null;
  if (prevM && !prevM.service) {
    prevRow = box.querySelector('.row[data-id="' + Number(prevM.id) + '"]');
    if (!prevRow || prevRow !== box.lastElementChild) return renderMessages(stick);
  } else if (prevM && prevM.service && !(box.lastElementChild && box.lastElementChild.classList.contains("svc"))) return renderMessages(stick);
  else if (!prevM && box.lastElementChild && !box.lastElementChild.classList.contains("older")) return renderMessages(stick);
  if (m.service) box.append(h("div", {class: "svc", text: m.text}));
  else {
    let j = i - 1; while (j >= 0 && list[j].service) j--;
    if (j < 0 || dayKey(list[j].ts) !== dayKey(m.ts)) box.append(h("div", {class: "day", text: dayLabel(m.ts)}));
    if (prevRow && !chan) {                                          // oldingi qator endi «oxirgi» emas bo'lishi mumkin (avatar ko'chadi)
      const [pf, pl] = msgFlags(list, i - 1);
      if (pl !== prevRow.classList.contains("last")) prevRow.replaceWith(bubbleRow(prevM, isG, pf, pl));
    }
    const [f, l] = chan ? [true, true] : msgFlags(list, i), row = bubbleRow(m, isG, f, l, chan);
    row.classList.add("enter"); box.append(row);
    fxPlay(row);                                                     // xabar effekti: faqat yangi xabar paydo bo'lganda, bir marta
    setTimeout(() => row.classList.remove("enter"), 450);
  }
  box._n = (box._n || 0) + 1; box._stick = !!stick;
  if (chan) Channels.track(box, S.active.id);
  Pend.mount(!!stick);
  if (stick) { box.scrollTop = box.scrollHeight; bumpAway(true); }
  toggleToBottom();
}
function replyQuote(r, by) {                              // `by` — reply yozgan odam: iqtibos qutisi UNING tanlagan uslubida
  const gone = !!r.deleted, rk = by && !gone ? fxOf(by, "reply") : null;
  const q = h("div", {class: "rq" + (gone ? " gone" : "") + (rk ? " fxr-" + rk : ""), role: "button"},
    h("b", {text: gone ? "Xabar" : r.nickname}),
    h("span", {text: gone ? "O'chirilgan xabar" : (r.image ? "📷 " : r.file ? (r.voice ? "🎤 " : r.vnote ? "📹 " : "📎 ") : "") + (r.text || (r.image ? "Rasm" : r.file ? (r.file_name || "Fayl") : ""))}));
  q.addEventListener("click", e => { e.stopPropagation(); if (!gone) jumpTo(r.id); });
  return q;
}
function jumpTo(id) {
  const box = $("msgs"), row = box.querySelector('.row[data-id="' + Number(id) + '"]');
  if (!row) { toast("Bu xabar yuklangan tarixda yo'q (eski)", "warn"); return; }
  box._stick = false;
  row.scrollIntoView({block: "center", behavior: "smooth"});
  row.classList.remove("flash"); void row.offsetWidth; row.classList.add("flash");
  setTimeout(() => row.classList.remove("flash"), 1400);
}

/* ---------------- Rasm: avval xira, bosilganda yuklanadi va tiniq ochiladi ---------------- */
function imageBox(m, mine) {
  const ratio = Math.min(2.4, Math.max(0.8, m.w && m.h ? m.w / m.h : 4 / 3));
  // O'zim yuborgan rasm darrov ochiq; boshqalarniki bosilguncha yuklanmaydi.
  if (mine && !S.imgs.has(m.id)) S.imgs.set(m.id, "open");
  const st = S.imgs.get(m.id);
  const box = h("div", {class: "imgbox" + (st === "open" ? " open" : st === "loading" ? " loading" : ""), role: "button", tabindex: "0",
    "aria-label": st === "open" ? "Rasmni kattalashtirish" : "Rasmni yuklash"});
  box.style.aspectRatio = String(ratio);
  if (st !== "open") {
    const th = h("img", {class: "mthumb", alt: "", draggable: "false"});
    th.addEventListener("error", () => { th.remove(); box.classList.add("nothumb"); });
    if (m.thumb) th.src = m.thumb; else box.classList.add("nothumb");
    const dl = h("span", {class: "mdl", "aria-hidden": "true"}, icon("dl"), spinnerEl());
    box.append(th, dl);
  } else {
    box.append(fullImg(m));
  }
  const act = e => {
    e.stopPropagation();
    const cur = S.imgs.get(m.id);
    if (cur === "open") { imgSrcOf(m).then(openLightbox).catch(e => toast(e && e.expired ? EXPIRED_MSG : "Rasmni ochib bo'lmadi", "error")); return; }
    if (cur === "loading") return;
    startImageLoad(m, box);
  };
  box.addEventListener("click", act);
  box.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); act(e); } });
  return box;
}
/* ---------------- Fayl xabari: yuklab olish, video/audio ijro etish ---------------- */
const fmtSize = n => n < 1024 ? n + " B" : n < 1048576 ? Math.round(n / 1024) + " KB" : (n / 1048576).toFixed(1) + " MB";
const fileExt = name => { const i = (name || "").lastIndexOf("."); return i > 0 && i < name.length - 1 ? name.slice(i + 1, i + 5).toUpperCase() : "FAYL"; };
const PLAYABLE = /^(video\/(mp4|webm|ogg|quicktime)|audio\/(mpeg|mp3|ogg|wav|x-wav|webm|mp4|aac|flac|x-m4a))$/;
async function fetchFileBlob(m, type) {
  if (m.file.e2e) return new Blob([await e2eFetchBlob(m)], {type});          // shifrlangan fayl: qurilmada ochiladi
  const r = await SC.fetch(m.file.url, {headers: {Authorization: "Bearer " + S.token}});     // shifrlangan kanal orqali, tizim tokeni bilan
  if (!r.ok) throw new Error("fayl");
  return new Blob([r.bytes], {type});
}
async function downloadFile(m, box) {
  if (box.classList.contains("loading")) return;
  box.classList.add("loading");
  try {
    const blob = await fetchFileBlob(m, "application/octet-stream");                           // hech qachon sahifa sifatida ochilmaydi
    const url = URL.createObjectURL(blob), a = h("a", {href: url, download: m.file.name});
    document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  } catch (e) { toast(e && e.expired ? EXPIRED_MSG : "Faylni yuklab bo'lmadi", "error"); }
  box.classList.remove("loading");
}
async function playFile(m, box) {
  if (box.classList.contains("loading")) return;
  box.classList.add("loading");
  try {
    const blob = await fetchFileBlob(m, m.file.mime);
    S.played.set(m.id, URL.createObjectURL(blob));
    renderMessages(false);
  } catch (e) { toast(e && e.expired ? EXPIRED_MSG : "Faylni yuklab bo'lmadi", "error"); box.classList.remove("loading"); }
}
const fxNow = (key, ts) => {                                // terminal animatsiyasi: faqat yangi xabarda va faqat birinchi chizilganda
  const seen = S.fx.get(key);
  if (seen) return Date.now() - seen < 4000;
  S.fx.set(key, Date.now());
  return !ts || Date.now() / 1000 - ts < 90;
};
async function copyQuiet(t) {                                // kod/terminal blokidagi kichik «Nusxalash» tugmasi uchun (tugmaning o'zi holatni ko'rsatadi)
  try { await navigator.clipboard.writeText(t); return true; }
  catch (_) {
    const ta = h("textarea", {class: "offscreen"}); ta.value = t; document.body.append(ta); ta.select();
    let ok = false; try { ok = document.execCommand("copy"); } catch (_e) {}
    ta.remove(); return ok;
  }
}
async function togglePreview(m, box) {                      // .py/.cpp/.sh/... matn sifatida, .pcap tahlil sifatida ko'rsatiladi (hech narsa bajarilmaydi)
  if (S.previews.has(m.id)) { S.previews.delete(m.id); renderMessages(false); return; }
  if (box.classList.contains("loading")) return;
  const fk = Rich.fileKind(m.file.name); if (!fk) return;
  const limit = fk.kind === "pcap" ? MAX_MEDIA : 400 * 1024;
  if (m.file.size > limit) { toast("Fayl juda katta: ko'rish uchun yuklab oling (" + fmtSize(limit) + " gacha ko'rsatiladi)", "error"); return; }
  box.classList.add("loading");
  try {
    const blob = await fetchFileBlob(m, "application/octet-stream");
    const bytes = new Uint8Array(await blob.arrayBuffer());
    if (fk.kind === "pcap") S.previews.set(m.id, {kind: "pcap", info: Rich.parsePcap(bytes)});
    else {
      if (!Rich.isTextual(bytes)) { toast("Bu fayl matn emas: faqat yuklab olish mumkin", "error"); box.classList.remove("loading"); return; }
      let text = new TextDecoder("utf-8").decode(bytes).replace(/\r\n?/g, "\n"), cut = false;
      if (text.length > 120000) { text = text.slice(0, 120000); cut = true; }
      S.previews.set(m.id, {kind: "code", lang: fk.lang, label: fk.label, text, cut});
    }
    renderMessages(false);
  } catch (err) { toast(err && /pcap|qisqa/i.test(err.message || "") ? err.message : "Faylni ochib bo'lmadi", "error"); }
  box.classList.remove("loading");
}
function previewEl(m, pv) {
  const u = U(m.user.id);
  if (pv.kind === "pcap") {
    const info = pv.info;
    return Rich.terminal(Rich.pcapLines(info, m.file.name), {user: u.username, host: "kali", kali: true, tag: "PCAP", fx: fxNow("pv" + m.id), copy: copyQuiet,
      copyText: Rich.pcapText(info, m.file.name), info: info.count + " paket • " + info.linkName + " • faqat o'qiladi"});
  }
  const box = Rich.codeBlock(pv.text, pv.lang, {label: pv.label + " • " + m.file.name, copy: copyQuiet});
  if (pv.cut) box.append(h("div", {class: "cfoot-i cut", text: "Fayl katta: faqat boshi ko'rsatildi. To'liq nusxa uchun yuklab oling."}));
  return box;
}
function fileBox(m) {
  if (m.file.voice) return voiceBox(m);
  if (m.file.vnote) return vnoteBox(m);
  const f = m.file, playable = PLAYABLE.test(f.mime), fk = playable ? null : Rich.fileKind(f.name);
  if (playable && S.played.has(m.id)) {
    const el = h(f.mime.startsWith("video/") ? "video" : "audio", {controls: true, preload: "metadata", playsinline: true});
    el.src = S.played.get(m.id);
    return h("div", {class: "mplayer"}, el, h("div", {class: "mpn", text: f.name + " • " + fmtSize(f.size)}));
  }
  const box = h("div", {class: "filebox" + (fk ? " kind-" + fk.kind : ""), role: "button", tabindex: "0", "aria-label": "Faylni yuklab olish: " + f.name});
  if (fk) box.style.setProperty("--lc", fk.color);
  const act = h("span", {class: "fdl", "aria-hidden": "true"}, icon("dl"), spinnerEl());
  box.append(h("span", {class: "fico"}, h("b", {text: fk ? fk.ext.toUpperCase().slice(0, 6) : fileExt(f.name)})),
    h("span", {class: "fmeta"}, h("b", {class: "fname", text: f.name}),
      h("small", {text: fk ? (fk.kind === "pcap" ? "Linux • tcpdump/Wireshark • " : fk.label + " • faqat ko'rish • ") + fmtSize(f.size) : fmtSize(f.size)})));
  if (playable) {
    const pl = h("button", {class: "fplay", type: "button", title: "Ijro etish", "aria-label": "Ijro etish"}, icon("play"));
    pl.addEventListener("click", e => { e.stopPropagation(); playFile(m, box); });
    box.append(pl);
  }
  if (fk) {
    const open = S.previews.has(m.id), t = open ? "Yopish" : fk.kind === "pcap" ? "Tahlil qilish" : "Kodni ko'rish";
    const vw = h("button", {class: "fplay fview" + (open ? " on" : ""), type: "button", title: t, "aria-label": t}, icon(open ? "close" : "eye"));
    vw.addEventListener("click", e => { e.stopPropagation(); togglePreview(m, box); });
    for (const ev of ["pointerdown", "touchstart"]) vw.addEventListener(ev, e => e.stopPropagation(), {passive: true});
    box.append(vw);
  }
  box.append(act);
  const go = e => { e.stopPropagation(); downloadFile(m, box); };
  box.addEventListener("click", go);
  box.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); go(e); } });
  if (!fk) return box;
  const wrap = h("div", {class: "cfile kind-" + fk.kind}, box);
  const pv = S.previews.get(m.id);
  if (pv) wrap.append(previewEl(m, pv));
  return wrap;
}
function spinnerEl() {
  const NSV = "http://www.w3.org/2000/svg";
  const s = document.createElementNS(NSV, "svg"); s.setAttribute("class", "mspin"); s.setAttribute("viewBox", "0 0 50 50");
  const c = document.createElementNS(NSV, "circle");
  [["cx", 25], ["cy", 25], ["r", 22], ["fill", "none"], ["stroke-width", 3], ["stroke-linecap", "round"]].forEach(([k, v]) => c.setAttribute(k, v));
  s.append(c); return s;
}
/* ---------------- Ovozli xabar: ijro etish (bitta umumiy pleer, qayta chizishda holat saqlanadi) ---------------- */
const VP = {id: null, audio: null, url: null, rate: 1, loading: false};
const fmtDur = s => { s = Math.max(0, Math.round(s || 0)); return Math.floor(s / 60) + ":" + pad2(s % 60); };
function voiceStop() {
  if (VP.audio) { try { VP.audio.pause(); VP.audio.removeAttribute("src"); VP.audio.load(); } catch (_) {} }
  if (VP.url) URL.revokeObjectURL(VP.url);
  VP.id = VP.audio = VP.url = null; VP.loading = false;
  paintVoices();
  vnStop();                                                            // bir vaqtda faqat bitta ovoz/video xabar ijro etiladi
}
function paintVoice(box) {
  const id = +box.dataset.vid, cur = VP.id === id, a = cur ? VP.audio : null;
  const dur = a && isFinite(a.duration) && a.duration > 0 ? a.duration : +box.dataset.dur;
  box.classList.toggle("active", !!a);
  box.classList.toggle("playing", !!a && !a.paused);
  box.classList.toggle("loading", cur && VP.loading);
  box.querySelector(".vfill").style.width = (a && dur ? Math.min(100, a.currentTime / dur * 100) : 0) + "%";
  box.querySelector(".vtime").textContent = a && (a.currentTime > 0 || !a.paused) ? fmtDur(a.currentTime) + " / " + fmtDur(dur) : fmtDur(dur);
  box.querySelector(".vspd").textContent = VP.rate + "x";
}
function paintVoices() { document.querySelectorAll(".vbox").forEach(paintVoice); }
async function voiceToggle(m) {
  if (VP.id === m.id && VP.audio) { if (VP.audio.paused) VP.audio.play().catch(() => {}); else VP.audio.pause(); paintVoices(); return; }
  if (VP.loading) return;
  voiceStop();
  VP.id = m.id; VP.loading = true; paintVoices();
  try {
    const blob = await fetchFileBlob(m, "audio/wav");
    if (VP.id !== m.id) return;                                        // yuklanayotganda boshqa narsa bosildi
    const url = URL.createObjectURL(blob), a = new Audio();
    a.preload = "auto"; a.src = url; a.playbackRate = VP.rate;
    ["timeupdate", "play", "pause", "loadedmetadata", "durationchange"].forEach(ev => a.addEventListener(ev, paintVoices));
    a.addEventListener("ended", () => { a.currentTime = 0; paintVoices(); });
    a.addEventListener("error", () => { if (VP.audio === a) { toast("Ovozni ijro etib bo'lmadi", "error"); voiceStop(); } });
    VP.audio = a; VP.url = url; VP.loading = false; paintVoices();
    await a.play().catch(() => {});                                    // iOS: ruxsat bermasa, yana bir bosish ijro etadi
  } catch (_) { if (VP.id === m.id) { toast("Ovozni yuklab bo'lmadi", "error"); voiceStop(); } }
}
function voiceBox(m) {
  const f = m.file, dur = f.dur || Math.max(1, (f.size - 44) / 32000);
  const box = h("div", {class: "vbox"});
  box.dataset.vid = m.id; box.dataset.dur = dur;
  const play = h("button", {class: "vplay", type: "button", "aria-label": "Ovozli xabarni ijro etish"}, icon("play", "ic vi-play"), icon("pause", "ic vi-pause"), spinnerEl());
  play.addEventListener("click", e => { e.stopPropagation(); voiceToggle(m); });
  const fill = h("div", {class: "vfill"}), track = h("div", {class: "vtrack"}, h("div", {class: "vline"}, fill));
  track.addEventListener("click", e => {                               // bosilgan joyga o'tish (faqat yuklangan bo'lsa)
    e.stopPropagation();
    const a = VP.id === m.id ? VP.audio : null; if (!a || !isFinite(a.duration) || a.duration <= 0) return;
    const r = track.getBoundingClientRect(); a.currentTime = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)) * a.duration; paintVoices();
  });
  const spd = h("button", {class: "vspd", type: "button", title: "Tezlik", "aria-label": "Ijro tezligi"});
  spd.addEventListener("click", e => { e.stopPropagation(); VP.rate = VP.rate === 1 ? 1.5 : VP.rate === 1.5 ? 2 : 1; if (VP.audio) VP.audio.playbackRate = VP.rate; paintVoices(); });
  box.append(play, h("div", {class: "vmid"}, track, h("div", {class: "vmeta"}, h("span", {class: "vtime"}), spd)));
  paintVoice(box);
  return box;
}
/* ---------------- Dumaloq video xabar: ijro etish ----------------
   Video (ovozsiz) va o'zgartirilgan ovoz — ikkita alohida element; ovoz asosiy soat, video unga moslashtiriladi.
   Elementlar xabar ro'yxatiga qo'shilmaydi (yashirin joyda turadi), shu sabab xabarlar qayta chizilganda ijro uzilmaydi;
   kadrlar xabardagi dumaloq <canvas>'ga chiziladi. Fayl qurilmada ochiladi (E2EE), serverda ochiq holda hech qachon bo'lmaydi. */
const VN = {id: null, video: null, audio: null, vurl: null, aurl: null, loading: false, ended: false, raf: 0, seq: 0};
let vnHost = null;
function vnHostEl() { if (!vnHost) { vnHost = h("div", {class: "vn-host", "aria-hidden": "true"}); document.body.append(vnHost); } return vnHost; }
const vnMaster = () => VN.audio || VN.video;
function vnStop() {
  VN.seq++; if (VN.raf) cancelAnimationFrame(VN.raf);
  const {video: v, audio: a, vurl, aurl} = VN;
  if (a) { try { a.pause(); a.removeAttribute("src"); a.load(); } catch (_) {} }
  if (v) { try { v.pause(); v.removeAttribute("src"); v.load(); } catch (_) {} v.remove(); }
  [vurl, aurl].forEach(u => { if (u) URL.revokeObjectURL(u); });
  Object.assign(VN, {id: null, video: null, audio: null, vurl: null, aurl: null, loading: false, ended: false, raf: 0});
  paintVNs();
}
function drawCover(cv, v) {                                           // kvadratga markazdan kesib chizadi
  const w = v.videoWidth, hh = v.videoHeight; if (!w || !hh) return;
  const s = Math.min(w, hh), n = cv.width;
  cv.getContext("2d").drawImage(v, (w - s) / 2, (hh - s) / 2, s, s, 0, 0, n, n);
}
function paintVN(box) {
  const id = +box.dataset.vnid, cur = VN.id === id, v = cur ? VN.video : null, a = cur ? vnMaster() : null;
  const ready = !!(cur && v && !VN.loading), playing = ready && !!a && !a.paused && !VN.ended;
  const total = +box.dataset.dur || (a && isFinite(a.duration) ? a.duration : 0), t = ready && !VN.ended && a ? a.currentTime : 0;
  box.classList.toggle("ready", ready); box.classList.toggle("playing", playing); box.classList.toggle("loading", cur && VN.loading);
  box.querySelector(".vnr-fg").setAttribute("stroke-dashoffset", String(301.6 * (1 - (total ? Math.min(1, t / total) : 0))));
  box.querySelector(".vndur").textContent = ready && (playing || t > 0) ? fmtDur(t) + " / " + fmtDur(total) : fmtDur(total);
  if (ready && v.readyState >= 2) drawCover(box.querySelector("canvas"), v);
}
function paintVNs() { document.querySelectorAll(".vnbox").forEach(paintVN); }
function vnTick() {
  VN.raf = 0;
  const v = VN.video, a = VN.audio; if (!v) return;
  if (a && !a.paused && !v.seeking) {
    if (v.paused && !v.ended) v.play().catch(() => {});
    if (Math.abs(v.currentTime - a.currentTime) > 0.25) { try { v.currentTime = a.currentTime; } catch (_) {} }   // ovoz asosiy: video unga yetib oladi
  }
  paintVNs();
  const m = vnMaster();
  if (m && !m.paused && !VN.ended) VN.raf = requestAnimationFrame(vnTick);
}
const vnKick = () => { if (!VN.raf) VN.raf = requestAnimationFrame(vnTick); };
async function vnPlayBoth() {
  const v = VN.video, a = VN.audio; if (!v) return;
  try { await Promise.all([v.play(), a ? a.play() : null]); vnKick(); }
  catch (_) { try { v.pause(); if (a) a.pause(); } catch (__) {} toast("Ijro etib bo'lmadi. Yana bir bor bosing", "error"); }
  paintVNs();
}
async function vnToggle(m) {
  if (VN.id === m.id) {
    if (VN.loading || !VN.video) return;
    const v = VN.video, a = VN.audio;
    if (VN.ended) { VN.ended = false; try { v.currentTime = 0; if (a) a.currentTime = 0; } catch (_) {} await vnPlayBoth(); }
    else if (vnMaster().paused) await vnPlayBoth();
    else { v.pause(); if (a) a.pause(); }
    paintVNs(); return;
  }
  voiceStop();                                                         // boshqa ovoz/video to'xtaydi (vnStop ham shu yerda)
  const token = VN.seq; VN.id = m.id; VN.loading = true; paintVNs();
  const alive = () => VN.seq === token && VN.id === m.id;
  let v = null, a = null, vurl = null, aurl = null, adopted = false;
  try {
    const parts = VNote.unpack(await e2eFetchBlob(m));
    if (!alive()) return;
    v = document.createElement("video");
    if (!v.canPlayType(m.file.mime)) throw new Error("format");
    v.muted = true; v.playsInline = true; v.preload = "auto"; v.disablePictureInPicture = true;
    v.setAttribute("playsinline", ""); v.setAttribute("webkit-playsinline", "");
    vurl = URL.createObjectURL(new Blob([parts.video], {type: m.file.mime}));
    if (parts.audio) { aurl = URL.createObjectURL(new Blob([parts.audio], {type: "audio/wav"})); a = new Audio(); a.preload = "auto"; a.src = aurl; }
    vnHostEl().append(v); v.src = vurl;
    await new Promise((res, rej) => {
      if (v.readyState >= 2) return res();
      const t = setTimeout(() => rej(new Error("vaqt")), 15000);
      v.addEventListener("loadeddata", () => { clearTimeout(t); res(); }, {once: true});
      v.addEventListener("error", () => { clearTimeout(t); rej(new Error("video")); }, {once: true});
    });
    if (!alive()) return;
    adopted = true;
    Object.assign(VN, {video: v, audio: a, vurl, aurl, loading: false, ended: false});
    const mst = a || v;
    ["play", "pause", "seeked", "loadedmetadata"].forEach(ev => mst.addEventListener(ev, () => { paintVNs(); if (!mst.paused) vnKick(); }));
    v.addEventListener("seeked", paintVNs);
    mst.addEventListener("ended", () => {
      if (VN.video !== v) return;
      VN.ended = true; v.pause(); if (a) a.pause();
      try { v.currentTime = 0; } catch (_) {}
      paintVNs();
    });
    if (a) a.addEventListener("error", () => { if (VN.audio === a) { toast("Ovozni ijro etib bo'lmadi", "error"); vnStop(); } });
    v.addEventListener("error", () => { if (VN.video === v) { toast("Videoni ijro etib bo'lmadi", "error"); vnStop(); } });
    paintVNs();                                                        // 1-kadr ko'rinadi
    await vnPlayBoth();
  } catch (_) {
    if (!adopted) { if (v) v.remove(); [vurl, aurl].forEach(u => { if (u) URL.revokeObjectURL(u); }); }
    if (alive()) { toast("Video xabarni ochib bo'lmadi", "error"); vnStop(); }
  }
}
function vnoteBox(m) {
  const f = m.file, NSV = "http://www.w3.org/2000/svg";
  const box = h("div", {class: "vnbox", role: "button", tabindex: "0", "aria-label": "Video xabarni ijro etish"});
  box.dataset.vnid = m.id; box.dataset.dur = f.dur || 0;
  const c = h("div", {class: "vnc"});
  if (f.th) c.append(h("img", {class: "vnth", alt: "", draggable: "false", src: f.th}));
  c.append(h("canvas", {width: 360, height: 360}), h("span", {class: "vnplay", "aria-hidden": "true"}, icon("play", "ic"), spinnerEl()), h("span", {class: "vndur"}));
  const ring = document.createElementNS(NSV, "svg"); ring.setAttribute("class", "vnring"); ring.setAttribute("viewBox", "0 0 100 100"); ring.setAttribute("aria-hidden", "true");
  [["vnr-bg", false], ["vnr-fg", true]].forEach(([cls, fg]) => {
    const ci = document.createElementNS(NSV, "circle"); ci.setAttribute("class", cls); ci.setAttribute("cx", 50); ci.setAttribute("cy", 50); ci.setAttribute("r", 48);
    if (fg) ci.setAttribute("stroke-dashoffset", "301.6"); ring.append(ci);
  });
  box.append(c, ring);
  const go = e => { e.stopPropagation(); vnToggle(m); };
  box.addEventListener("click", go);
  box.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); go(e); } });
  paintVN(box);
  return box;
}
function fullImg(m) {
  const img = h("img", {class: "mimg", alt: "Rasm", draggable: "false"});
  img.addEventListener("load", () => { const b = $("msgs"); if (b._stick) b.scrollTop = b.scrollHeight; });
  imgSrcOf(m).then(u => { img.src = u; }).catch(() => {});
  return img;
}
function startImageLoad(m, box) {
  S.imgs.set(m.id, "loading"); box.classList.add("loading");
  const t0 = performance.now(), pre = new Image();
  const done = (ok, err) => {
    const wait = Math.max(0, 550 - (performance.now() - t0));      // animatsiya ko'rinib o'tishi uchun
    setTimeout(() => {
      if (!ok) {                                                    // xato: yana bosib ko'rish mumkin
        S.imgs.delete(m.id); toast(err && err.expired ? EXPIRED_MSG : "Rasmni yuklab bo'lmadi", "error");
        const b = document.querySelector('#msgs .row[data-id="' + m.id + '"] .imgbox'); if (b) b.classList.remove("loading");
        return;
      }
      S.imgs.set(m.id, "open");
      const cur = document.querySelector('#msgs .row[data-id="' + m.id + '"] .imgbox');   // qayta chizilgan bo'lishi mumkin
      if (!cur) return;
      const img = fullImg(m); img.classList.add("reveal");
      cur.classList.remove("loading"); cur.classList.add("open"); cur.setAttribute("aria-label", "Rasmni kattalashtirish");
      cur.append(img);
      void cur.offsetWidth;
      requestAnimationFrame(() => cur.classList.add("clear"));
      setTimeout(() => cur.querySelectorAll(".mthumb,.mdl").forEach(x => x.remove()), 450);
    }, wait);
  };
  pre.onload = () => done(true); pre.onerror = () => done(false);
  imgSrcOf(m).then(u => { pre.src = u; }).catch(e => done(false, e));
}
/* ---------------- Reaksiyalar (xabar va kanal postlariga; Telegramdagidek) ----------------
   Bir foydalanuvchi — bitta xabarga bitta reaksiya. Server ro'yxatni saqlaydi va hammaga tarqatadi (`rx: {emoji: [user_id]}`).
   Sozlamalar (ikki marta bosish yoqilgan/o'chirilgan va qaysi emoji) shu qurilmada saqlanadi. */
const RX_QUICK = ["❤️", "👍", "👎", "🔥", "😂", "😮", "😢"];          // menyudagi bir qatorli tezkor reaksiyalar; qolgani ↓ tugmasi ostida
function rxAll() {                                                    // barcha reaksiyalar: chatdagi standart emojilar + yaratilgan (maxsus) emojilar
  const out = STD_EMOJIS.map(e => ({e, custom: false}));
  if (EM.data && emojiPerms().use) EM.data.emojis.filter(x => emojiUsable(x) && Rich.hasInlineEmoji(x.token)).forEach(x => out.push({e: x.token, custom: true, label: x.label}));
  return out;
}
/* Reaksiyalar ham chatdagi emoji kabi to'plamlarga (pack) bo'lingan: standart emojilar mavzu bo'yicha, maxsus emojilar o'z to'plami bo'yicha */
function rxGroups() {
  const cut = (a, b) => STD_EMOJIS.slice(STD_EMOJIS.indexOf(a), STD_EMOJIS.indexOf(b) + 1);
  const g = [
    {k: "f", title: "Yuzlar va hissiyotlar", label: "😀", items: cut("😀", "🙊")},
    {k: "h", title: "Qo'l va tana", label: "👍", items: cut("👍", "🧠")},
    {k: "l", title: "Yuraklar", label: "❤️", items: cut("❤️", "💯")},
    {k: "o", title: "Belgilar va narsalar", label: "🎉", items: cut("✨", "🍺")}];
  if (EM.data && emojiPerms().use) {
    emojiTabs().filter(t => t.k !== "std").forEach(t => {
      const items = (t.items || []).filter(x => Rich.hasInlineEmoji(x.token)).map(x => x.token);
      if (items.length) g.push({k: t.k, title: t.label, label: "📦", icon: items[0], items});
    });
  }
  return g;
}
/* To'plamlar tabi + tanlangan to'plamdagi emojilar. `mk(e)` — har bir emoji uchun tugma; `st.k` — tanlangan to'plam */
function rxPackView(mk, st, gridCls) {
  const gs = rxGroups(), wrap = h("div", {class: "rx-pv"});
  if (!gs.some(g => g.k === st.k)) st.k = gs[0].k;
  const paint = () => {
    const keep = wrap.querySelector(".rx-tabs"), left = keep ? keep.scrollLeft : 0;
    wrap.textContent = "";
    const bar = h("div", {class: "rx-tabs", role: "tablist"});
    gs.forEach(g => {
      const b = h("button", {type: "button", class: "rx-tab" + (g.k === st.k ? " on" : ""), title: g.title, "aria-label": g.title, role: "tab"}, g.icon ? rxGlyph(g.icon) : h("span", {class: "rx-e", text: g.label}));
      b.addEventListener("click", ev => { ev.stopPropagation(); st.k = g.k; paint(); });
      bar.append(b);
    });
    hScroll(bar);
    const cur = gs.find(g => g.k === st.k), grid = h("div", {class: gridCls});
    cur.items.forEach(e => grid.append(mk(e)));
    wrap.append(bar, h("small", {class: "rx-cap", text: cur.title + " • " + cur.items.length + " ta"}), grid);
    bar.scrollLeft = left; keepTabVisible(bar);
  };
  paint();
  return wrap;
}
const rxValid = e => typeof e === "string" && (STD_EMOJIS.includes(e) || Rich.isEmojiToken(e));
function rxGlyph(e, cls) {                                            // oddiy emoji — matn, `:nom:` — rasm
  if (Rich.isEmojiToken(e) && Rich.hasInlineEmoji(e)) { const i = Rich.chatEmoji(e, false); i.classList.add("rxi"); return i; }
  return h("span", {class: cls || "rx-e", text: Rich.isEmojiToken(e) ? "◈" : e});
}
const RX_KEY = "tc_rx";
const rxPrefs = (() => {
  let p = {}; try { p = JSON.parse(localStorage.getItem(RX_KEY) || "{}") || {}; } catch (_) {}
  const ok = typeof p.emoji === "string" && p.emoji.length <= 20 && !/[A-Za-z0-9]/.test(p.emoji.replace(/^:[a-z0-9_]{2,32}:$/, ""));   // oddiy emoji yoki :nom: (STD_EMOJIS bu yerda hali e'lon qilinmagan)
  return {dbl: p.dbl !== false, emoji: ok ? p.emoji : "❤️"};
})();
const rxSave = () => { try { localStorage.setItem(RX_KEY, JSON.stringify(rxPrefs)); } catch (_) {} };
const canReact = m => !!m && !m.service && m.id != null && !$("chat").classList.contains("dead");
function rxMine(m) {
  for (const [e, ids] of Object.entries(m.rx || {})) if (ids.includes(S.me.id)) return e;
  return null;
}
function reactTo(m, emoji) { if (canReact(m)) wsSend({type: "react", id: m.id, emoji}); }       // bir xil emoji qayta — serverda olib tashlanadi
function rxChip(e) {
  const chip = h("button", {class: "rx", type: "button"}, rxGlyph(e), h("b", {class: "cnt"}));
  chip.dataset.e = e;
  chip.addEventListener("click", ev => {
    ev.stopPropagation();
    const m = chip._m; if (!m) return;
    if (rxMine(m) !== e) { const r = chip.getBoundingClientRect(); rxBurst(e, r.left + r.width / 2, r.top + r.height / 2, {mini: true}); haptic(8); }
    reactTo(m, e);                                   // bir xil emoji qayta bosilsa serverda olib tashlanadi
  });
  return chip;
}
function rxCount(chip, n, anim) {                    // son o'zgarganda raqam "yumalab" almashadi
  const b = chip.querySelector(".cnt"), old = b.firstElementChild;
  if (!old) { b.append(h("span", {text: String(n)})); b.dataset.n = String(n); return; }
  const prev = Number(b.dataset.n); if (prev === n) return;
  b.dataset.n = String(n);
  if (!anim) { old.textContent = String(n); return; }
  const up = n > prev;
  b.querySelectorAll("span").forEach(x => { x.classList.add(up ? "up-out" : "down-out"); setTimeout(() => x.remove(), 240); });
  b.append(h("span", {class: up ? "up-in" : "down-in", text: String(n)}));
}
function rxSync(box, m, anim) {                      // chiplarni qayta yaratmasdan yangilaydi: yangisi "pop" bilan chiqadi, yo'qolgani kichrayib ketadi
  const want = Object.entries(m.rx || {}).filter(([, ids]) => ids.length), keys = new Set(want.map(([e]) => e)), have = new Map();
  [...box.children].forEach(c => {
    if (c.classList.contains("out")) return;
    if (keys.has(c.dataset.e)) have.set(c.dataset.e, c);
    else if (anim) { c.classList.add("out"); setTimeout(() => c.remove(), 230); } else c.remove();
  });
  let prev = null;
  want.forEach(([e, ids]) => {
    let c = have.get(e); const fresh = !c;
    if (fresh) c = rxChip(e);
    c._m = m;
    const mine = ids.includes(S.me.id), was = c.classList.contains("mine"), before = Number((c.querySelector(".cnt") || {dataset: {}}).dataset.n || 0);
    c.classList.toggle("mine", mine);
    c.title = ids.slice(0, 12).map(id => U(id).nickname).join(", ") + (ids.length > 12 ? " va yana " + (ids.length - 12) + " kishi" : "");
    c.setAttribute("aria-label", e + " " + ids.length + (mine ? " (siz qo'ygansiz)" : ""));
    rxCount(c, ids.length, anim && !fresh);
    if (anim) {
      const once = cls => { c.classList.add(cls); c.addEventListener("animationend", () => c.classList.remove(cls), {once: true}); };
      if (fresh) once("in");
      else if (mine && !was) { const g = c.firstElementChild; g.classList.add("pop"); setTimeout(() => g.classList.remove("pop"), 520); }   // o'zingiz qo'ysangiz emoji "sakraydi"
      else if (!mine && ids.length > before) once("bump");                                                                                 // boshqa odam qo'shsa chip yengil to'lqin beradi
    }
    const nxt = prev ? prev.nextElementSibling : box.firstElementChild;
    if (c !== nxt) box.insertBefore(c, nxt);
    prev = c;
  });
}
function reactionsEl(m) {
  if (!Object.values(m.rx || {}).some(a => a.length)) return null;
  const box = h("div", {class: "rxs"}); rxSync(box, m, false); return box;
}
function patchReactions(m) {                          // faqat shu xabar qatoridagi chiplar yangilanadi (rasm/video qayta yuklanmaydi)
  const row = document.querySelector('#msgs .row[data-id="' + Number(m.id) + '"]'); if (!row) return;
  const has = Object.values(m.rx || {}).some(a => a.length);
  let box = row.querySelector(".rxs");
  if (!box) {
    if (!has) return;
    box = h("div", {class: "rxs"});
    if (row.classList.contains("chan")) { const meta = row.querySelector(".bubble > .bfoot, .bubble > .meta"); (meta ? meta.before(box) : row.querySelector(".bubble").append(box)); }
    else row.append(box);                             // oddiy xabarlarda chiplar pufak ostida (qatorning ikkinchi satri)
    if (!row.classList.contains("chan")) row.classList.add("has-rx");      // kanal postida chiplar pufak ichida: qator o'zgarmaydi
  }
  rxSync(box, m, true);
  if (!has) setTimeout(() => { if (!box.querySelector(".rx:not(.out)")) { box.remove(); row.classList.remove("has-rx"); } }, 260);
}
function rxBurst(emoji, x, y, o) {                    // ikki marta bosilganda: emoji "sakraydi" + atrofga mayda emojilar sochiladi
  o = o || {};
  const fx = h("span", {class: "rx-fx", "aria-hidden": "true"}); fx.style.left = x + "px"; fx.style.top = y + "px";
  if (!o.mini) fx.append(h("span", {class: "rx-burst"}, rxGlyph(emoji, "rx-bg")));
  const n = o.mini ? 5 : 8;
  for (let i = 0; i < n; i++) {
    const ang = (Math.PI * 2 * i) / n + Math.random() * .5 - .25, d = (o.mini ? 30 : 64) + Math.random() * 22;
    const sp = h("span", {class: "rx-sp"}, rxGlyph(emoji, "rx-sg"));
    sp.style.setProperty("--dx", (Math.cos(ang) * d).toFixed(1) + "px"); sp.style.setProperty("--dy", (Math.sin(ang) * d - (o.mini ? 6 : 16)).toFixed(1) + "px");
    sp.style.setProperty("--s", (0.55 + Math.random() * 0.45).toFixed(2)); sp.style.animationDelay = (Math.random() * 70 | 0) + "ms";
    fx.append(sp);
  }
  document.body.append(fx); setTimeout(() => fx.remove(), 1000);
  if (o.bubble) { const bb = o.bubble; bb.classList.remove("rx-bump"); void bb.offsetWidth; bb.classList.add("rx-bump"); setTimeout(() => bb.classList.remove("rx-bump"), 380); }
}
function rxPicker(m) {                                // menyu tepasida: bitta qator + ↓ (hamma emojilar)
  const mine = rxMine(m), box = h("div", {class: "rx-pick", role: "group", "aria-label": "Reaksiya"});
  const pick = (e, btn) => ev => {
    ev.stopPropagation(); const r = btn.getBoundingClientRect(); closeCtx();
    if (e !== mine) rxBurst(e, r.left + r.width / 2, r.top); reactTo(m, e);
  };
  const cell = e => { const b = h("button", {class: "rx-pk" + (e === mine ? " on" : ""), type: "button", "aria-label": e}, rxGlyph(e)); b.addEventListener("click", pick(e, b)); return b; };
  const row = h("div", {class: "rx-row"});
  RX_QUICK.forEach((e, i) => { const c = cell(e); c.style.setProperty("--i", String(i)); row.append(c); });
  const more = h("button", {class: "rx-pk rx-more", type: "button", "aria-label": "Barcha reaksiyalar", "aria-expanded": "false"}, icon("down"));
  const all = h("div", {class: "rx-all hidden"});
  let built = false;
  more.addEventListener("click", ev => {
    ev.stopPropagation();
    if (!built) {                                    // katta ro'yxat faqat kerak bo'lganda chiziladi: to'plamlar (tab) bo'yicha
      built = true;
      all.append(rxPackView(cell, {k: null}, "rx-grid-all"));
    }
    const open = all.classList.toggle("hidden") === false;
    more.classList.toggle("up", open); more.setAttribute("aria-expanded", String(open));
    const c = $("ctx"), r = c.getBoundingClientRect();            // menyu kengaysa ekrandan chiqib ketmasin
    if (!c.classList.contains("as-sheet") && r.bottom > innerHeight - 8) c.style.top = Math.max(8, innerHeight - 8 - r.height) + "px";
  });
  more.style.setProperty("--i", String(RX_QUICK.length)); row.append(more); box.append(row, all);
  return box;
}
const TAP_SKIP = "a,button,input,textarea,select,[role=button],.mplayer,.vtrack,.vspd,.cbtn,.code-scroll,.term-scroll,.rxs";   // o'zining bosish amali bor elementlar
function attachTap(bubble, m) {
  let last = 0, timer = 0, lx = 0, ly = 0;
  bubble.addEventListener("click", e => {
    if (e.defaultPrevented || S.sel) return;                                 // uzoq bosish/surishdan keyingi bosish yoki belgilash rejimi
    if (e.target.closest && e.target.closest(TAP_SKIP)) return;
    const can = canReact(m), now = Date.now();
    if (rxPrefs.dbl && can && timer && now - last < 320) {                   // ikki marta ketma-ket: reaksiya
      clearTimeout(timer); timer = 0; last = 0;
      try { getSelection().removeAllRanges(); } catch (_) {}
      const emo = rxPrefs.emoji;
      rxBurst(emo, e.clientX, e.clientY, {bubble}); haptic(10);
      if (rxMine(m) !== emo) reactTo(m, emo);
      return;
    }
    let picked = ""; try { picked = String(getSelection() || "").trim(); } catch (_) {}
    if (picked) return;                                                      // kompyuter: matn belgilanayotgan bo'lsa menyu chiqmasin
    last = now; lx = e.clientX; ly = e.clientY; clearTimeout(timer);
    const open = () => { timer = 0; openCtx(lx, ly, m); };
    if (rxPrefs.dbl && can) timer = setTimeout(open, 280); else open();     // ikki marta bosish yoqilgan bo'lsa, ikkinchi bosishni biroz kutamiz
  });
}
function bubbleRow(m, isGroup, first, last, chan) {
  const own = m.user.id === S.me.id, mine = chan ? false : own, u = U(m.user.id);     // kanal postlari hammaga chap tomondan (Telegramdagidek)
  const row = h("div", {class: "row" + (mine ? " mine" : "") + (first ? " first" : "") + (last ? " last" : "") + (isGroup ? "" : " dm") + (chan ? " chan" : "")});
  row.dataset.id = m.id;
  if (S.sel) {
    const can = canDelete(m);
    row.classList.add(can ? "selectable" : "locked");
    if (can) {
      if (S.sel.has(m.id)) row.classList.add("selected");
      row.append(h("span", {class: "chk", "aria-hidden": "true"}, icon("check")));
    }
    row.addEventListener("click", e => { e.preventDefault(); e.stopPropagation(); toggleSel(m, row); }, true);
  }
  const slot = h("div", {class: "slot"});
  // Telegramdagidek: bir odamning ketma-ket xabarlarida avatar faqat eng oxirgisining yonida ko'rinadi,
  // qolganlarida o'sha joy bo'sh qoladi (xabarlar bir tekis turadi).
  if (isGroup && !mine && last) { const a = avatar(u, "s"); a.style.cursor = "pointer"; a.addEventListener("click", () => openProfile(u.id)); slot.append(a); }
  const meta = h("span", {class: "meta"});
  if (m.edited) meta.append("tahrirlangan ");
  if (m.e2e) meta.append(h("span", {class: "lk" + (m.locked ? "" : (m.verified && !m.bad ? " ok" : " bad")),
    title: m.locked ? "Shifrlangan, kalit kutilmoqda" : m.verified && !m.bad ? "Uchdan-uchga shifrlangan, imzosi tasdiqlangan" : "Imzo yoki shifrni tekshirib bo'lmadi!",
    text: m.locked ? "🔒" : m.verified && !m.bad ? "🔒" : "⚠"}), " ");
  else if (m.legacy) meta.append(h("span", {class: "lk bad", title: "Eski xabar: E2EE'dan oldin yozilgan, server o'qiy oladi", text: "🔓"}), " ");
  if (chan) meta.append(h("span", {class: "vws", title: "Ko'rishlar soni"}, icon("eye"), h("b", {text: String(m.views || 0)})), " ");
  meta.append(hhmm(m.ts));
  if (mine) meta.append(icon(m.to != null && m.read ? "checks" : "check", m.to != null && m.read ? "ic rd" : "ic"));       // ✓ yuborildi, ✓✓ o'qildi (umumiy chatda — ✓)
  const bubble = tint(h("div", {class: "bubble" + (isStaff(u) ? " prem " + u.role : "") + (m.image ? " has-img" + (m.content ? "" : " img-only") : "") + (m.file ? " has-file" + (S.previews.has(m.id) ? " has-pv" : "") + (m.file.voice ? " has-voice" : "") + (m.file.vnote ? " has-vnote" + (m.content ? "" : " vn-only") : "") : "")}), u);
  if (!m.deleted) fxBubble(bubble, u);                   // admin bergan xabar effekti va havola uslubi
  if (isGroup && !mine && first) {
    const ne = nameEl(u, {colored: true});                 // faqat ism (nickname) bosiladi; qatorning bo'sh joyi — oddiy xabar bosishi
    ne.classList.add("lnk");
    ne.addEventListener("click", e => { e.stopPropagation(); openProfile(u.id); });
    bubble.append(h("div", {class: "bname"}, ne));
  }
  if (m.fwd) bubble.append(h("div", {class: "fwd", title: "Yuboruvchi ko'rsatgan asl muallif (tekshirib bo'lmaydi)"}, icon("forward"), h("span", {text: "Oldinga yuborilgan: "}), h("b", {text: m.fwd.n})));
  if (m.reply) bubble.append(replyQuote(m.reply, u));
  if (m.image) bubble.append(imageBox(m, mine || own));
  if (m.file) bubble.append(fileBox(m));
  if (!mine && m.content && !m.locked && !m.bad && Rich.mentionsOf(m.content, LINKCTX).includes(S.me.username)) bubble.classList.add("mentioned-me");   // meni @belgilashgan xabar
  const more = h("button", {class: "more", type: "button", "aria-label": "Amallar"}, icon("down"));
  more.addEventListener("click", e => { e.stopPropagation(); const r = more.getBoundingClientRect(); openCtx(r.left, r.bottom + 4, m); });
  const shown = m.locked ? "🔒 Xabar kaliti kutilmoqda…" : m.bad ? "⚠ Shifrni ochib bo'lmadi" : m.content;
  const parts = !m.locked && !m.bad && m.content ? Rich.parse(m.content) : null;
  if (parts && Rich.hasRich(parts)) {                  // kod / Linux buyruqlari: alohida dizayn + pastida kichik «Nusxalash» tugmasi
    bubble.classList.add("has-code");
    parts.forEach((p, i) => {
      if (p.k === "text") { if (p.t) bubble.append(btextEl("btext rich-t", p.t, true)); return; }
      bubble.append(Rich.render(p, {user: u.username, fx: p.k === "term" && fxNow(m.id + ":" + i, m.ts), copy: copyQuiet}));
    });
  } else if (shown || !(m.image || m.file)) bubble.append(btextEl("btext" + (m.locked || m.bad ? " dim" : ""), shown, !m.locked && !m.bad));
  const rxEl = reactionsEl(m);
  if (rxEl && chan) bubble.append(rxEl);             // kanal postida chiplar post ichida (izoh tugmasi tepasida); oddiy xabarda — pufak ostida
  if (bubble.querySelector(".bigemo")) {            // stiker kabi katta emoji: vaqt emoji ostida alohida qatorda
    bubble.classList.add("has-big");
    bubble.append(h("div", {class: "bfoot"}, meta), more);
  } else bubble.append(meta, more);
  if (chan) bubble.append(h("button", {class: "cmbtn", type: "button", onclick: e => { e.stopPropagation(); Channels.openComments(m); }},
    icon("chat"), h("span", {class: "cmb-t", text: m.comments ? m.comments + " ta izoh" : "Izoh qoldirish"}), h("span", {class: "cmb-go", text: "›"})));
  bubble.addEventListener("contextmenu", e => { e.preventDefault(); if (S.sel) return toggleSel(m, row); openCtx(e.clientX, e.clientY, m); });
  attachTouch(bubble, row, m);          // uzoq bosish = menyu, chapga surish = javob
  attachTap(bubble, m);                 // bir marta bosish = menyu (javob, nusxa, uzatish...), ikki marta = reaksiya
  row.append(slot, bubble);
  if (rxEl && !chan) { row.append(rxEl); row.classList.add("has-rx"); }
  return row;
}
const BIG_STD = /^(?:\p{Extended_Pictographic}(?:\uFE0F|[\u{1F3FB}-\u{1F3FF}]|\u200D\p{Extended_Pictographic}\uFE0F?)*\s*){1,3}$/u;   // faqat 1–3 ta oddiy emoji
/* Havola va @belgilash konteksti: faqat mavjud foydalanuvchi @username bo'lib ko'rinadi, bosilsa profili ochiladi */
function userIdByName(name) {
  for (const u of S.users.values()) if (u.username === name && !u.deleted) return u.id;
  return null;
}
const LINKCTX = {mention: userIdByName, onMention: name => { const id = userIdByName(name); if (id != null) openProfile(id); }};
function btextEl(cls, text, rich) {                 // matn; `:nom:` emojilar rasmga, havolalar va @username bosiladigan elementga aylanadi (innerHTML ishlatilmaydi)
  const d = h("div", {class: cls});
  if (rich && (Rich.hasInlineEmoji(text) || Rich.hasLinks(text, LINKCTX))) d.append(Rich.inline(text, LINKCTX)); else d.textContent = text == null ? "" : text;
  if (rich && (d.querySelector(".ce.big") || (typeof text === "string" && text.length <= 40 && BIG_STD.test(text.trim())))) d.classList.add("bigemo");   // faqat emojidan iborat xabar — stiker kabi katta
  return d;
}
function toggleToBottom() {
  const b = $("msgs");
  $("toBottom").classList.toggle("hidden", b.scrollHeight - b.scrollTop - b.clientHeight < 240);
}
let scrollTick = 0;                               // scroll hodisasi kadrda bir marta ishlanadi (layout o'qish kam)
$("msgs").addEventListener("scroll", () => {
  if (scrollTick) return;
  scrollTick = requestAnimationFrame(() => {
    scrollTick = 0;
    const b = $("msgs"), bot = atBottom(); b._stick = bot; toggleToBottom();
    if (bot && S.away) bumpAway(true);
    closeCtx(); if (b.scrollTop < 160) loadOlder();
  });
}, {passive: true});
$("msgs").addEventListener("wheel", e => { if (e.deltaY < 0 && $("msgs").scrollTop <= 0) loadOlder(); }, {passive: true});     // kompyuter: eng tepada g'ildirak
$("msgs").addEventListener("touchmove", () => { if ($("msgs").scrollTop <= 0) loadOlder(); }, {passive: true});               // telefon: eng tepada tortish
$("toBottom").addEventListener("click", () => { const b = $("msgs"); b.scrollTop = b.scrollHeight; bumpAway(true); });



/* ---------------- Shaxsiy suhbat menyusi / suhbatni o'chirish ---------------- */
function openMenu(x, y, items, sheet) {
  S.ctxAt = Date.now();
  const ctx = $("ctx"); ctx.textContent = "";
  items.forEach(it => {
    const b = h("button", {class: "dd-i", type: "button", onclick: () => { closeCtx(); it.fn(); }}, icon(it.ic), it.text);
    if (it.danger) b.style.color = "var(--err)";
    ctx.append(b);
  });
  showCtx(ctx, x, y, false);                       // telefonda ham pastdan chiqadigan qora varaq emas: bosilgan joy yonida oyna ustida chiqadigan menyu
}
function showCtx(ctx, x, y, asSheet) {              // telefonda: pastdan chiqadigan varaq; kompyuterda: kursor yonida
  ctx.classList.remove("hidden");
  ctx.classList.toggle("as-sheet", asSheet);
  $("ctxBack").classList.toggle("hidden", !asSheet);
  if (isMobile()) navPush("ctx");
  const w = ctx.offsetWidth, hgt = ctx.offsetHeight;
  ctx.style.left = Math.max(8, Math.min(x, innerWidth - w - 8)) + "px";
  ctx.style.top = Math.max(8, Math.min(y, innerHeight - hgt - 8)) + "px";
}
function dmMenu(x, y, uid, sheet) {
  openMenu(x, y, [
    {ic: "user", text: "Profilni ko'rish", fn: () => openProfile(uid)},
    {ic: "trash", text: "Suhbatni o'chirish", danger: true, fn: () => deleteDmChat(uid)},
  ], sheet);
}
$("chMore").addEventListener("click", e => {
  e.stopPropagation();
  if (!S.active || S.active.kind === "group") return;
  const r = $("chMore").getBoundingClientRect();
  if (S.active.kind === "channel") Channels.menu(r.right - 220, r.bottom + 4, S.active.id);
  else dmMenu(r.right - 200, r.bottom + 4, S.active.uid);
});
async function deleteDmChat(uid) {
  const u = U(uid);
  const ok = await confirmDlg("Bu suhbat (" + u.nickname + " bilan) ikkala tomon uchun ham butunlay o'chiriladi: xabarlar va rasmlar ikkalangizdan ham yo'qoladi. Buni qaytarib bo'lmaydi.",
    {title: "Suhbatni o'chirish", okText: "O'chirish", danger: true});
  if (ok) wsSend({type: "delete_dm", with: uid});
}

/* ---------------- Belgilash rejimi: ko'p xabarni birdaniga o'chirish ---------------- */
let renderQueued = false;
function scheduleRender() {                       // ketma-ket o'chirishlarda bir kadrda bir marta chizish
  if (renderQueued) return; renderQueued = true;
  requestAnimationFrame(() => { renderQueued = false; renderMessages(false); renderList(); });
}
function enterSelect(firstId) {
  if (!S.active) return;
  cancelEdit(); cancelReply();
  S.sel = new Set(); if (firstId != null) S.sel.add(firstId);
  $("chat").classList.add("selecting"); navPush("sel");
  renderMessages(false); updateSelBar();
}
function exitSelect() {
  if (!S.sel) return;
  S.sel = null; $("chat").classList.remove("selecting"); navPop("sel");
  renderMessages(false);
}
function toggleSel(m, row) {
  if (!S.sel || !canDelete(m)) return;
  if (S.sel.has(m.id)) S.sel.delete(m.id); else S.sel.add(m.id);
  if (row) row.classList.toggle("selected", S.sel.has(m.id));
  updateSelBar();
}
function updateSelBar() {
  if (!S.sel) return;
  $("selCount").textContent = String(S.sel.size);
  $("selDel").disabled = !S.sel.size;
  const all = currentMsgs().filter(x => !x.service && canDelete(x));
  $("selAll").textContent = all.length && all.every(x => S.sel.has(x.id)) ? "Bekor" : "Hammasi";
}
$("selCancel").addEventListener("click", exitSelect);
$("selAll").addEventListener("click", () => {
  if (!S.sel) return;
  const all = currentMsgs().filter(x => !x.service && canDelete(x));
  if (all.length && all.every(x => S.sel.has(x.id))) S.sel.clear(); else all.forEach(x => S.sel.add(x.id));
  document.querySelectorAll("#msgs .row[data-id]").forEach(r => r.classList.toggle("selected", S.sel.has(Number(r.dataset.id))));
  updateSelBar();
});
$("selDel").addEventListener("click", async () => {
  if (!S.sel || !S.sel.size) return;
  const ids = [...S.sel], n = ids.length;
  const ok = await confirmDlg(n + " ta xabar o'chirilsinmi?", {title: "Xabarlarni o'chirish", okText: "O'chirish", danger: true});
  if (!ok || !S.sel) return;
  for (let i = 0; i < ids.length; i += 200) wsSend({type: "delete_many", ids: ids.slice(i, i + 200)});
  exitSelect();
});
async function clearGroupChat() {
  if (!amAdmin()) return;
  const ok = await confirmDlg("Umumiy chatdagi BARCHA xabarlar hamma uchun o'chiriladi. Buni qaytarib bo'lmaydi.",
    {title: "Chatni tozalash", okText: "Tozalash", danger: true});
  if (ok) wsSend({type: "clear_chat"});
}

/* ---------------- kontekst menyu ---------------- */
function canDelete(m) {
  if (m.ch) return amAdmin();                         // kanal postini istalgan admin o'chira oladi
  if (m.user.id === S.me.id) return true;
  if (m.to != null || !amAdmin()) return false;
  const t = U(m.user.id);
  return t.role === "user" || (t.role === "admin" && S.me.role === "owner");
}
function openCtx(x, y, m) {
  S.ctxAt = Date.now();
  const ctx = $("ctx"); ctx.textContent = "";
  const add = (ic, text, fn, danger) => {
    const b = h("button", {class: "dd-i", type: "button", onclick: () => { closeCtx(); fn(); }}, icon(ic), text);
    if (danger) b.style.color = "var(--err)";
    ctx.append(b);
  };
  const usable = !m.locked && !m.bad;
  const chan = !!m.ch;
  if (canReact(m)) ctx.append(rxPicker(m));
  if (chan) add("chat", "Izohlar", () => Channels.openComments(m));
  if (usable && !m.legacy && !chan) add("reply", "Javob berish", () => startReply(m));
  if (m.content && usable) add("copy", "Nusxalash", () => copyText(m.content));
  if (usable && (m.image || m.file)) add("save", "Saqlash (Save as)", () => saveAs(m));
  if (usable && !m.legacy && !m.service && (m.content || m.image || m.file)) add("forward", "Oldinga yuborish", () => forwardMessage(m));
  if (m.user.id !== S.me.id && !chan) add("user", "Profilni ko'rish", () => openProfile(m.user.id));
  if (m.user.id !== S.me.id && m.to == null && !m.service && !chan) add("flag", "Shikoyat qilish", () => reportMessage(m));
  if (m.user.id === S.me.id && usable && !m.legacy) add("edit", "Tahrirlash", () => startEdit(m));
  if (canDelete(m)) add("select", "Belgilash", () => enterSelect(m.id));
  if (canDelete(m)) add("trash", "O'chirish", async () => { if (await confirmDlg("Bu xabar o'chirilsinmi?", {title: "Xabarni o'chirish", okText: "O'chirish", danger: true})) wsSend({type: "delete", id: m.id}); }, true);
  const row = document.querySelector('#msgs .row[data-id="' + Number(m.id) + '"]'); if (row) row.classList.add("ctx-on");
  showCtx(ctx, x, y, false);                       // bir marta bosish ham, uzoq bosish ham: pastdan varaq emas, xabar yonida oyna ustida chiqadigan menyu
}
function closeCtx() {
  const c = $("ctx"); if (c.classList.contains("hidden")) return;
  c.classList.add("hidden"); $("ctxBack").classList.add("hidden");
  document.querySelectorAll("#msgs .row.ctx-on").forEach(r => r.classList.remove("ctx-on"));
  navPop("ctx");
}

/* ---------------- Saqlash (Save as) va Oldinga yuborish: hammasi qurilmada, E2EE saqlanadi ----------------
   Saqlash: fayl shifrlangan holda yuklanadi va FAQAT shu qurilmada ochiladi (server ochiq faylni ko'rmaydi).
   Oldinga yuborish: xabar/fayl qurilmada ochiladi va tanlangan suhbat uchun QAYTA shifrlanadi (yangi fayl kaliti,
   yangi konvert, o'z imzom). Server faqat yangi shifrni ko'radi; asl xabarga bog'liq emas (asl o'chsa ham nusxa qoladi). */
const safeName = n => String(n || "fayl").replace(/[\\/:*?"<>|\u0000-\u001f]/g, "_").replace(/^\.+/, "").trim().slice(0, 120) || "fayl";
async function messageBytes(m) {
  if (m.e2e) return e2eFetchBlob(m);
  const url = m.image || (m.file && m.file.url);                            // eski (E2EE'dan oldingi) xabar
  const r = await SC.fetch(url, {headers: {Authorization: "Bearer " + S.token}});
  if (!r.ok) throw new Error("fayl");
  return r.bytes;
}
async function saveBytesAs(getBytes, name) {
  let handle = null;
  if (window.showSaveFilePicker) {                                           // kompyuter: "Save as" oynasi (joy va nom tanlanadi). Bosish faolligi tugamasin deb — avval oyna
    try { handle = await window.showSaveFilePicker({suggestedName: name}); }
    catch (err) { if (err && err.name === "AbortError") return false; handle = null; }
  }
  let bytes;
  try { bytes = await getBytes(); } catch (err) { if (handle && handle.remove) handle.remove().catch(() => {}); throw err; }
  if (handle) {
    const w = await handle.createWritable();
    try { await w.write(bytes); await w.close(); } catch (err) { try { await w.abort(); } catch (_) {} throw err; }
    return true;
  }
  const url = URL.createObjectURL(new Blob([bytes], {type: "application/octet-stream"}));      // telefon/boshqa brauzer: yuklab olishlar papkasiga
  const a = h("a", {href: url, download: name}); document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60000);
  return true;
}
async function saveAs(m) {
  const name = safeName((m._f && m._f.name) || (m.file && m.file.name) || (m.image ? "rasm.jpg" : "fayl"));
  try { if (await saveBytesAs(() => messageBytes(m), name)) toast("Saqlandi: " + name, "ok"); }
  catch (_) { toast("Faylni saqlab bo'lmadi", "error"); }
}
function forwardMessage(m) {
  const picked = new Map();                                                  // kalit -> {kind, uid}
  let filter = "", busy = false;
  const targets = () => [{key: "g", kind: "group"}].concat(S.members.filter(x => x.id !== S.me.id && !x.deleted && !x.banned).map(x => ({key: "u" + x.id, kind: "dm", uid: x.id})));
  const what = m.image ? "📷 Rasm" : m.file ? fileIco(m.file) + fileWhat(m.file) : "";
  openModal(() => {
    const list = h("div", {class: "fwl"}), send = h("button", {class: "btn", type: "button", disabled: true, text: "Yuborish"});
    const note = h("div", {class: "fw-note", text: (what ? what + (m.content ? " • " : "") : "") + (m.content ? m.content.replace(/\s+/g, " ").slice(0, 80) : "")});
    const upd = () => { send.disabled = busy || !picked.size; send.textContent = picked.size ? "Yuborish (" + picked.size + ")" : "Yuborish"; };
    const fill = () => {
      list.textContent = "";
      const q = filter.trim().toLowerCase().replace(/^@/, "");
      targets().forEach(t => {
        const u = t.kind === "dm" ? U(t.uid) : null;
        if (q && (!u || !(u.nickname.toLowerCase().includes(q) || u.username.toLowerCase().includes(q)))) { if (!(t.kind === "group" && "umumiy chat".includes(q))) return; }
        const ck = h("input", {type: "checkbox", class: "ck", tabindex: "-1", "aria-hidden": "true"}); ck.checked = picked.has(t.key);
        const row = h("button", {class: "frow" + (ck.checked ? " on" : ""), type: "button"},
          u ? avatar(u, "m", true) : groupAvatar("m"),
          h("div", {class: "utx"}, u ? nameEl(u) : h("span", {class: "nt", text: "Umumiy chat"}), h("span", {class: "fsub", text: u ? "@" + u.username : (S.members.length || 1) + " a'zo"})), ck);
        row.addEventListener("click", () => { if (busy) return; if (picked.has(t.key)) picked.delete(t.key); else picked.set(t.key, t); ck.checked = picked.has(t.key); row.classList.toggle("on", ck.checked); upd(); });
        list.append(row);
      });
      if (!list.children.length) list.append(h("div", {class: "none", text: "Hech narsa topilmadi"}));
    };
    const search = h("input", {type: "text", class: "gsearch", placeholder: "Qidirish", autocomplete: "off"});
    search.addEventListener("input", () => { filter = search.value; fill(); });
    send.addEventListener("click", async () => {
      if (busy || !picked.size) return;
      busy = true; upd(); send.textContent = "Shifrlanmoqda…"; search.disabled = true;
      const r = await doForward(m, [...picked.values()]);
      busy = false; closeModal();
      if (r.ok) toast("Oldinga yuborildi" + (r.ok > 1 ? " (" + r.ok + " ta suhbat)" : ""), "ok");
      if (r.errs.length) toast(r.errs[0] + (r.errs.length > 1 ? " (+" + (r.errs.length - 1) + " ta xato)" : ""), "error");
    });
    fill();
    return h("div", {}, sheetHead("Oldinga yuborish"), note, search, list, h("div", {class: "fw-bar"}, send));
  }, false);
}
async function doForward(m, targets) {
  const res = {ok: 0, errs: []};
  let enc = null;
  const fw = m._fw || (m.ch ? {n: (chInfo(m.ch) || {}).nickname || "Kanal", id: 0} : {n: m.user.nickname, id: m.user.id});                    // asl muallif saqlanadi (zanjirda ham)
  try { if (m._f) enc = await E2E.encryptFile(new Uint8Array(await messageBytes(m))); }   // fayl bir marta yangi kalit bilan qayta shifrlanadi
  catch (_) { res.errs.push("Faylni ochib bo'lmadi"); return res; }
  for (const t of targets) {
    const label = t.kind === "group" ? "Umumiy chat" : U(t.uid).nickname;
    try {
      if (t.kind === "group" && S.chat.locked && !amAdmin()) throw new Error("chat qulflangan");
      if (t.kind === "dm" && U(t.uid).deleted) throw new Error("akkaunt o'chirilgan");
      const ctx = await keyForTarget(t), payload = {t: m.content || "", fw};
      let blobName = null;
      if (enc) {
        const r = await SC.fetch("/api/e2ee/blob", {method: "POST", headers: {Authorization: "Bearer " + S.token, "Content-Type": "application/octet-stream"}, body: enc.blob});
        const j = await r.json().catch(() => ({}));
        if (!r.ok) throw new Error(typeof j.detail === "string" ? j.detail : "fayl yuklanmadi");
        blobName = j.blob; payload.f = Object.assign({}, m._f, {k: enc.key});
      }
      const msg = {type: "send", e2e: await sealFor(ctx, payload)};
      if (blobName) msg.blob = blobName;
      withTarget(msg, t);
      if (!wsSend(msg)) throw new Error("ulanish yo'q");
      res.ok++;
    } catch (err) { res.errs.push(label + ": " + err.message); }
  }
  return res;
}
async function reportMessage(m) {
  const reason = await promptDlg("Shikoyat qilish", m.e2e
    ? "Xabarlar shifrlangan, adminlar ularni o'qiy olmaydi. Shikoyat yuborsangiz, FAQAT shu bitta xabarning matni adminlarga ochib beriladi. Nima uchun shikoyat qilyapsiz? (ixtiyoriy)"
    : "Nima uchun shikoyat qilyapsiz? (ixtiyoriy)", "", {okText: "Yuborish", placeholder: "Sabab"});
  if (reason === null) return;
  try { await api("/report", {method: "POST", body: {message_id: m.id, reason, evidence: m.e2e ? (m.content || "") : ""}}); toast("Shikoyat adminlarga yuborildi", "ok"); }
  catch (err) { toast(err.message, "error"); }
}
document.addEventListener("click", e => {
  if (Date.now() - (S.ctxAt || 0) > 350) closeCtx();
});
async function copyText(t) {
  try { await navigator.clipboard.writeText(t); toast("Nusxalandi", "ok"); }
  catch (_) {
    const ta = h("textarea", {class: "offscreen"}); ta.value = t; document.body.append(ta); ta.select();
    try { document.execCommand("copy"); toast("Nusxalandi", "ok"); } catch (_e) {}
    ta.remove();
  }
}

/* ---------------- yozish, tahrirlash ---------------- */
const MEN = {el: null, items: [], sel: 0, start: -1};
const inp = $("inp");
function autosize() { inp.style.height = "auto"; inp.style.height = Math.min(inp.scrollHeight, 140) + "px"; syncSend(); updateMention(); }
function syncSend() {
  $("sendBtn").classList.toggle("on", !!inp.value.trim() || !!S.pendingImg);
  $("composer").classList.toggle("has-text", !!inp.value.trim() || !!S.pendingImg || !!S.editing);   // matn bor: yuborish tugmasi, yo'q: mikrofon
}
inp.addEventListener("input", autosize);
inp.addEventListener("focus", () => setTimeout(() => { const b = $("msgs"); if (b._stick) b.scrollTop = b.scrollHeight; }, 320));
inp.addEventListener("keydown", e => {
  if (mentionKey(e)) return;
  if (e.key === "Enter" && !e.shiftKey && !COARSE && !e.isComposing) { e.preventDefault(); submit(); }
  else if (e.key === "Escape") { if (S.editing) cancelEdit(); else if (S.pendingImg) clearPendingImage(); else if (S.replying) cancelReply(); }
  else if (e.key === "ArrowUp" && !inp.value && S.active) {       // oxirgi o'z xabarini tahrirlash
    const mine = [...currentMsgs()].reverse().find(x => !x.service && x.user.id === S.me.id && !x.legacy && !x.bad && !x.locked);
    if (mine) { e.preventDefault(); startEdit(mine); }
  }
});
inp.addEventListener("paste", e => {                              // Ctrl+V bilan rasm qo'yish; kod/buyruq qo'yilsa — avtomatik ``` blokiga o'raladi
  const f = (e.clipboardData && e.clipboardData.files || [])[0];
  if (f) { e.preventDefault(); setPendingImage(f); return; }
  const txt = e.clipboardData && e.clipboardData.getData("text/plain");
  const whole = !inp.value.trim() || (inp.selectionStart === 0 && inp.selectionEnd === inp.value.length);
  if (!txt || !whole || S.editing) return;
  const fz = Rich.fenceFor(txt.replace(/\r\n?/g, "\n"));
  if (!fz || fz.text.length > inp.maxLength) return;
  e.preventDefault();
  inp.value = fz.text; inp.setSelectionRange(fz.text.length, fz.text.length); autosize();
  toast("Aniqlandi: " + fz.label + ". Xavfsiz ko'rinishda yuboriladi", "ok");
});

/* @belgilash: yozish maydonida "@" dan keyin foydalanuvchilar ro'yxati chiqadi (tanlansa "@username " qo'yiladi) */
function mentionQuery() {
  const pos = inp.selectionStart;
  if (pos == null || pos !== inp.selectionEnd) return null;
  const m = /(?:^|[\s(])@([A-Za-z0-9_]{0,20})$/.exec(inp.value.slice(0, pos));
  return m ? {q: m[1].toLowerCase(), start: pos - m[1].length - 1, pos} : null;
}
function mentionCandidates(q) {
  const rank = u => { const un = u.username, nn = (u.nickname || "").toLowerCase(); return !q ? 1 : un.startsWith(q) ? 0 : nn.startsWith(q) ? 1 : un.includes(q) ? 2 : nn.includes(q) ? 3 : 9; };
  return S.members.map(m => U(m.id)).filter(u => u.id !== S.me.id && !u.deleted && !u.banned && u.username && rank(u) < 9)
    .sort((a, b) => rank(a) - rank(b) || (a.role === "owner" ? -1 : 0) - (b.role === "owner" ? -1 : 0) || a.username.localeCompare(b.username)).slice(0, 6);
}
function closeMention() { if (MEN.el) { MEN.el.remove(); MEN.el = null; } MEN.items = []; }
function pickMention(u) {
  const q = mentionQuery(); if (!q) { closeMention(); return; }
  const ins = "@" + u.username + " ";
  if (inp.value.length - (q.pos - q.start) + ins.length > inp.maxLength) { toast("Xabar juda uzun", "warn"); return; }
  inp.setRangeText(ins, q.start, q.pos, "end"); closeMention(); autosize();
  if (!COARSE) inp.focus({preventScroll: true});
}
function paintMention() {
  if (!MEN.el) { MEN.el = h("div", {class: "mention-panel", role: "listbox", "aria-label": "Foydalanuvchini belgilash"}); MEN.el.addEventListener("mousedown", e => e.preventDefault()); document.body.append(MEN.el); }
  MEN.el.textContent = "";
  MEN.items.forEach((u, i) => {
    const b = h("button", {class: "mn-i" + (i === MEN.sel ? " on" : ""), type: "button", role: "option", "aria-selected": String(i === MEN.sel)},
      avatar(u, "s"), h("div", {class: "mn-t"}, h("b", {}, nameEl(u)), h("small", {text: "@" + u.username})));
    b.addEventListener("click", () => pickMention(u));
    MEN.el.append(b);
  });
  const r = inp.getBoundingClientRect(), w = Math.min(320, innerWidth - 16);
  MEN.el.style.width = w + "px"; MEN.el.style.left = Math.max(8, Math.min(r.left, innerWidth - w - 8)) + "px"; MEN.el.style.bottom = Math.max(8, innerHeight - r.top + 8) + "px";
}
function updateMention() {
  const q = S.me && !S.editing ? mentionQuery() : null;
  const list = q ? mentionCandidates(q.q) : [];
  if (!list.length) { closeMention(); return; }
  const same = MEN.items.length === list.length && MEN.items.every((u, i) => u.id === list[i].id);
  MEN.items = list; if (!same) MEN.sel = 0;
  paintMention();
}
function mentionKey(e) {                              // ro'yxat ochiq bo'lsa: ↑ ↓ Tab Enter Esc
  if (!MEN.el || !MEN.items.length || e.isComposing) return false;
  const n = MEN.items.length;
  if (e.key === "ArrowDown" || e.key === "ArrowUp") { e.preventDefault(); MEN.sel = (MEN.sel + (e.key === "ArrowDown" ? 1 : n - 1)) % n; paintMention(); return true; }
  if (e.key === "Tab" || (e.key === "Enter" && !e.shiftKey && !COARSE)) { e.preventDefault(); pickMention(MEN.items[MEN.sel]); return true; }
  if (e.key === "Escape") { e.preventDefault(); closeMention(); return true; }
  return false;
}
inp.addEventListener("keyup", e => { if (e.key === "ArrowLeft" || e.key === "ArrowRight" || e.key === "Home" || e.key === "End") updateMention(); });
inp.addEventListener("click", updateMention);
inp.addEventListener("blur", () => setTimeout(closeMention, 150));
$("sendBtn").addEventListener("click", submit);

function startEdit(m) {
  cancelReply(); clearPendingImage();
  S.editing = m; inp.value = m.content; autosize(); inp.focus();
  $("ebText").textContent = m.content ? m.content.replace(/\s+/g, " ") : (m.file ? (m.file.voice ? "🎤 Ovozli xabar izohi" : m.file.vnote ? "📹 Video xabar izohi" : "📎 Fayl izohi") : "📷 Rasm izohi");
  $("editbar").classList.remove("hidden");
}
function cancelEdit() {
  if (!S.editing) return;
  S.editing = null; inp.value = ""; autosize(); $("editbar").classList.add("hidden");
}
$("ebCancel").addEventListener("click", cancelEdit);

function startReply(m) {
  if (m.ch) return;                                   // kanal postlariga javob yo'q: izoh qoldiriladi
  cancelEdit();
  S.replying = replyInfo(m);
  $("rbName").textContent = m.user.nickname;
  $("rbText").textContent = (m.image ? "📷 " : m.file ? fileIco(m.file) : "") + (m.content ? m.content.replace(/\s+/g, " ") : (m.file ? fileWhat(m.file) : "Rasm"));
  $("replybar").classList.remove("hidden");
  inp.focus();
}
function cancelReply() { S.replying = null; $("replybar").classList.add("hidden"); }
$("rbCancel").addEventListener("click", cancelReply);

/* ---- rasm yuborish (izoh bilan) ---- */
const IMG_TYPES = ["image/png", "image/jpeg", "image/webp", "image/gif"], MAX_MEDIA = 50 * 1024 * 1024;
async function shrinkImage(f) {              // katta fotolarni yuborishdan oldin kichraytiradi (GIF tegilmaydi)
  if (f.type === "image/gif" || f.size <= 1.5 * 1024 * 1024 || !self.createImageBitmap) return f;
  try {
    const bmp = await createImageBitmap(f), k = Math.min(1, 1920 / Math.max(bmp.width, bmp.height));
    const c = document.createElement("canvas"); c.width = Math.round(bmp.width * k); c.height = Math.round(bmp.height * k);
    const g = c.getContext("2d"); g.fillStyle = "#fff"; g.fillRect(0, 0, c.width, c.height); g.drawImage(bmp, 0, 0, c.width, c.height);
    const blob = await new Promise(r => c.toBlob(r, "image/jpeg", 0.85));
    return blob && blob.size < f.size ? blob : f;
  } catch (_) { return f; }
}
async function setPendingImage(file) {              // istalgan turdagi fayl (50 MB gacha)
  if (!S.active || !file) return;
  if (S.active.kind === "group" && S.chat.locked && !amAdmin()) { toast("Umumiy chat qulflangan", "error"); return; }
  const isImg = IMG_TYPES.includes(file.type);
  const blob = isImg ? await shrinkImage(file) : file;
  if (blob.size > MAX_MEDIA) { toast("Fayl 50 MB dan oshmasligi kerak", "error"); return; }
  if (!blob.size) { toast("Fayl bo'sh", "error"); return; }
  cancelEdit(); clearPendingImage();
  const ext = blob.type === "image/jpeg" ? "jpg" : (blob.type.split("/")[1] || "png");
  S.pendingImg = {blob, isImg, url: isImg ? URL.createObjectURL(blob) : null, name: isImg ? "rasm." + ext : (file.name || "fayl")};
  $("ibThumb").classList.toggle("hidden", !isImg); $("ibIcon").classList.toggle("hidden", isImg);
  if (isImg) $("ibThumb").src = S.pendingImg.url; else $("ibThumb").removeAttribute("src");
  $("ibTitle").textContent = isImg ? "Rasm" : S.pendingImg.name;
  $("ibInfo").textContent = "Izoh yozib yuboring (ixtiyoriy) • " + fmtSize(blob.size);
  $("imgbar").classList.remove("hidden");
  syncSend(); inp.focus();
}
function clearPendingImage() {
  if (S.pendingImg && S.pendingImg.url) URL.revokeObjectURL(S.pendingImg.url);
  S.pendingImg = null; $("ibThumb").removeAttribute("src"); $("imgbar").classList.add("hidden"); syncSend();
}
$("attachBtn").addEventListener("click", () => $("imgFile").click());
$("imgFile").addEventListener("change", () => { const f = $("imgFile").files[0]; $("imgFile").value = ""; if (f) setPendingImage(f); });
$("ibCancel").addEventListener("click", clearPendingImage);
["dragenter", "dragover"].forEach(ev => $("chat").addEventListener(ev, e => { if (e.dataTransfer && [...e.dataTransfer.types].includes("Files")) { e.preventDefault(); $("chat").classList.add("drop"); } }));
["dragleave", "drop"].forEach(ev => $("chat").addEventListener(ev, e => { if (ev === "dragleave" && $("chat").contains(e.relatedTarget)) return; $("chat").classList.remove("drop"); }));
$("chat").addEventListener("drop", e => { const f = e.dataTransfer && e.dataTransfer.files[0]; if (f) { e.preventDefault(); setPendingImage(f); } });

async function sendImage(caption) {
  if (S.sending) return;
  const img = S.pendingImg, reply = S.replying;
  const pend = Pend.add(S.active, {kind: "file", name: img.name, size: img.blob.size, isImg: img.isImg, text: caption, url: img.isImg ? URL.createObjectURL(img.blob) : null}), relTy = Typing.hold("file");
  inp.value = ""; clearPendingImage(); cancelReply(); autosize();       // xabar darhol pufak bo'ladi; yuborish fonda (internet past bo'lsa — navbatda kutadi)
  Pend.go(pend, async p => {
    if (!p.fileMeta) {                                                  // shifrlash bir marta; qayta urinishda qayta ishlanmaydi
      let blob = img.blob, f = {name: img.name, mime: blob.type || "application/octet-stream", size: blob.size, img: false};
      if (img.isImg) {
        let c; try { c = await cleanImage(blob); } catch (_) { throw Object.assign(new Error("Rasmni o'qib bo'lmadi"), {final: true}); }
        blob = c.blob; f = Object.assign(f, {mime: blob.type || f.mime, size: blob.size, img: true, w: c.w, h: c.h, th: c.th});
      }
      const e = await E2E.encryptFile(new Uint8Array(await blob.arrayBuffer()));
      f.k = e.key; p.fileMeta = f; p.encBlob = e.blob;
    }
    if (!p.blobName) p.blobName = await uploadEnc(p.encBlob, "Fayl yuklanmadi");
    const payload = {t: caption, f: p.fileMeta}; if (reply) payload.r = reply;
    return withTarget({type: "send", cid: p.cid, e2e: await sealFor(await keyForTarget(p.target), payload), blob: p.blobName}, p.target);
  }).finally(relTy);
}
async function submit() {
  const text = inp.value.trim();
  if (!S.active || S.sending) return;
  if (S.active.kind === "dm" && U(S.active.uid).deleted) { toast("Bu akkaunt o'chirilgan. Xabar yuborib bo'lmaydi", "error"); return; }
  if (S.pendingImg) { sendImage(text); return; }
  if (!S.editing && !text) return;
  if (S.editing && !text && !S.editing._f) return;
  if (S.editing && text === S.editing.content) { cancelEdit(); return; }
  S.sending = true;
  let pend = null;
  try {
    if (S.editing) {                                                // tahrir: javob va fayl ma'lumoti saqlanadi, matn almashadi
      const ctx = await keyForActive(), payload = {t: text};
      const m = S.editing;
      if (m._r) payload.r = m._r; if (m._f) payload.f = m._f; if (m._fw) payload.fw = m._fw;
      if (wsSend({type: "edit", id: m.id, e2e: await sealFor(ctx, payload)})) cancelEdit();
    } else {
      const payload = {t: text};
      if (S.replying) payload.r = S.replying;
      pend = Pend.add(S.active, {kind: "text", text});               // Telegramdagidek: matn darhol pufak bo'ladi, pastida holat
      inp.value = ""; cancelReply(); autosize(); inp.focus(); Typing.stop();
      Pend.go(pend, async p => withTarget({type: "send", cid: p.cid, e2e: await sealFor(await keyForTarget(p.target), payload)}, p.target));   // internet past bo'lsa «kutilmoqda…», xato chiqmaydi
    }
  } catch (err) {
    toast(err.message, "error");
    if (pend) Pend.wait(pend);
  }
  S.sending = false;
}
/* ---------------- 28-presence.js: onlayn / last seen va "yozmoqda..." holatlari ----------------
   Server faqat uzatadi (saqlamaydi): {"type":"typing","kind":"text|file|emoji|voice|vnote|stop","to":<id>?}.
   Qabul qiluvchi holatni 6 soniyadan keyin o'zi o'chiradi (signal to'xtasa, "yozmoqda" qotib qolmaydi). */
const TYPING_TXT = {text: "yozmoqda", file: "fayl yubormoqda", emoji: "emoji tanlamoqda", voice: "ovozli xabar yozmoqda", vnote: "dumaloq video yozmoqda"};
const TYPING_RANK = {emoji: 1, text: 2, file: 3, voice: 4, vnote: 5};           // bir vaqtda bir nechta bo'lsa, eng "og'ir"i ko'rsatiladi
const TYPING_TTL = 6000, TYPING_BEAT = 2500;
const TY = {seen: new Map(), cur: {kind: "", at: 0, key: ""}, tick: 0, paint: 0};   // seen: suhbat kaliti -> Map(uid -> {kind, until})

function lastSeenText(u) {                                // "last seen hozirgina / bugun 14:32 / kecha 09:10 / 03.11.26 18:20"
  const ts = u && u.last_seen;
  if (!ts) return "oflayn";
  const now = Date.now() / 1000;
  if (now - ts < 60) return "last seen hozirgina";
  if (dayKey(ts) === dayKey(now)) return "last seen bugun " + hhmm(ts);
  const y = new Date(); y.setDate(y.getDate() - 1);
  if (dayKey(ts) === dayKey(y / 1000)) return "last seen kecha " + hhmm(ts);
  const d = new Date(ts * 1000);
  return "last seen " + pad2(d.getDate()) + "." + pad2(d.getMonth() + 1) + "." + String(d.getFullYear()).slice(2) + " " + hhmm(ts);
}
function tyKeyOf(t) { return !t ? "" : t.kind === "group" ? "g" : t.kind === "dm" ? "d" + t.uid : ""; }   // kanalda yozish signali yo'q
function typingNow(key) {                                 // hozir yozayotganlar: [{uid, kind}]
  const mp = TY.seen.get(key); if (!mp) return [];
  const t = Date.now(), out = [];
  mp.forEach((v, uid) => { if (v.until > t) out.push({uid, kind: v.kind}); else mp.delete(uid); });
  return out;
}
function typingLabel(key) {                               // sarlavha / ro'yxat uchun matn ("" = hech kim yozmayapti)
  const list = typingNow(key); if (!list.length) return "";
  const top = list.reduce((a, b) => (TYPING_RANK[b.kind] || 0) > (TYPING_RANK[a.kind] || 0) ? b : a);
  if (key[0] === "d") return TYPING_TXT[top.kind] || "yozmoqda";
  const names = list.map(x => (U(x.uid).nickname || "Kimdir"));
  if (list.length === 1) return names[0] + " " + (TYPING_TXT[top.kind] || "yozmoqda");
  const same = list.every(x => x.kind === top.kind);
  return (list.length === 2 ? names[0] + " va " + names[1] : list.length + " kishi") + " " + (same ? (TYPING_TXT[top.kind] || "yozmoqda") : "yozmoqda");
}
function typingRepaint() {                                // keraksiz qayta chizishlar birlashtiriladi
  if (TY.paint) return;
  TY.paint = setTimeout(() => { TY.paint = 0; if (!S.me) return; try { renderHeader(); renderList(); } catch (_) {} }, 120);
}
function typingSchedule() {                               // eng yaqin muddat tugaganda qayta chizamiz
  clearTimeout(TY.tick);
  let next = Infinity; const t = Date.now();
  TY.seen.forEach(mp => mp.forEach(v => { if (v.until > t) next = Math.min(next, v.until); }));
  if (next < Infinity) TY.tick = setTimeout(() => { typingRepaint(); typingSchedule(); }, Math.max(50, next - t + 30));
}
function onTyping(m) {                                    // server -> mijoz
  if (!S.me || m.uid === S.me.id) return;
  const key = m.group ? "g" : "d" + m.uid;
  let mp = TY.seen.get(key); if (!mp) TY.seen.set(key, mp = new Map());
  if (m.kind === "stop") mp.delete(m.uid); else if (TYPING_TXT[m.kind]) mp.set(m.uid, {kind: m.kind, until: Date.now() + TYPING_TTL});
  typingRepaint(); typingSchedule();
}
function typingClearFrom(uid) {                           // odam xabar yuborganda "yozmoqda" darhol yo'qoladi
  let hit = false; TY.seen.forEach(mp => { if (mp.delete(uid)) hit = true; });
  if (hit) typingRepaint();
}
function typingReset() { TY.seen.clear(); clearTimeout(TY.tick); TY.cur = {kind: "", at: 0, key: ""}; }

const Typing = {
  send(kind) {                                            // mijoz -> server (throttle: bir xil holat ~2.5 s da bir marta)
    const key = tyKeyOf(S.active); if (!key || !S.ws || S.ws.readyState !== 1) return;
    const c = TY.cur, now = Date.now();
    if (c.key === key && c.kind && now - c.at < TYPING_BEAT + 500) {
      if ((TYPING_RANK[kind] || 0) < (TYPING_RANK[c.kind] || 0)) return;          // pastroq darajali holat yuqorisini bosib ketmaydi
      if (kind === c.kind && now - c.at < TYPING_BEAT) return;
    } else if (c.key && c.key !== key) this.stop();
    TY.cur = {kind, at: now, key};
    const msg = {type: "typing", kind}; if (S.active.kind === "dm") msg.to = S.active.uid;
    wsSend(msg);
  },
  stop() {
    const c = TY.cur; if (!c.kind) return;
    TY.cur = {kind: "", at: 0, key: ""};
    if (!S.ws || S.ws.readyState !== 1) return;
    const msg = {type: "typing", kind: "stop"}; if (c.key[0] === "d") msg.to = +c.key.slice(1);
    wsSend(msg);
  },
  hold(kind) {                                            // holat davom etayotganda har 2.5 s da yangilaydi; qaytgan funksiya to'xtatadi
    this.send(kind);
    const t = setInterval(() => this.send(kind), TYPING_BEAT);
    let off = false;
    return () => { if (off) return; off = true; clearInterval(t); this.stop(); };
  },
};
inp.addEventListener("input", () => { if (S.editing) return; if (inp.value.trim()) Typing.send("text"); else Typing.stop(); });
inp.addEventListener("blur", () => { if (!inp.value.trim()) Typing.stop(); });
/* ---------------- 29-sendstate.js: xabar yuborish bosqichlari (Telegramdagidek) ----------------
   Yuborilayotgan xabar darhol pufak bo'lib chiqadi, pastida vaqt va holat: «shifrlanmoqda…» → «yuborilmoqda…» → ✓.
   Server xabarni qaytargach (haqiqiy xabar) vaqtincha pufak olib tashlanadi va o'rniga haqiqiysi (✓ / ✓✓ bilan) chiqadi.
   Pufaklar faqat ekranda yashaydi (E2EE: ochiq matn xotirada ham, diskda ham saqlanmaydi). */
const Pend = {
  list: [],
  ACK_MS: 15000,                                          // server shuncha vaqt javob bermasa — xabar qayta yuboriladi (server takrorni o'tkazmaydi); xato HECH QACHON ko'rsatilmaydi
  MAKE_MS: 60000,                                         // fayl yuklash shuncha vaqtda tugamasa — keyingi urinishga o'tadi
  q: Promise.resolve(), tick: 0,
  add(target, info) {
    const p = {key: chatKey(target), target, info, stage: "enc", el: null, meta: null, timer: 0, sentAt: 0, t0: Date.now(), cid: Pend.rid(), gen: 0, busy: false, msg: null, make: null};
    p.el = Pend.build(p); Pend.list.push(p); Pend.mount(true); return p;
  },
  rid() { const a = new Uint8Array(12); crypto.getRandomValues(a); return Array.from(a, b => b.toString(16).padStart(2, "0")).join(""); },
  label(p) { return p.stage === "enc" ? "shifrlanmoqda…" : p.stage === "up" ? "yuborilmoqda…" : p.stage === "wait" ? "kutilmoqda…" : ""; },
  build(p) {
    const i = p.info, row = h("div", {class: "row mine last pending" + (p.target.kind === "group" ? "" : " dm")});
    const img = i.kind === "file" && i.isImg && i.url, cap = i.kind === "file" ? (i.text || "") : "";
    const bubble = h("div", {class: "bubble pending" + (img ? " has-img" + (cap ? "" : " img-only") : "") + (i.kind === "file" && !img ? " has-file" : "")
      + (i.kind === "voice" ? " has-file has-voice" : "") + (i.kind === "vnote" ? " has-file has-vnote vn-only" : "")});
    if (i.kind === "text") bubble.append(btextEl("btext", i.text, true));
    else if (img) {                                       // yakuniy xabardagi bilan BIR XIL quti (imgbox): o'lcham sakramaydi; holat faqat pastdagi kapsulada
      const pic = h("img", {alt: "", draggable: "false", decoding: "async"}), box = h("div", {class: "imgbox open pnd-imgbox"}, pic);
      box.style.aspectRatio = "1.333";
      pic.addEventListener("load", () => { if (pic.naturalWidth && pic.naturalHeight) box.style.aspectRatio = String(Math.min(2.4, Math.max(0.8, pic.naturalWidth / pic.naturalHeight))); });
      pic.src = i.url;
      bubble.append(box);
      if (cap) bubble.append(btextEl("btext", cap, true));
    } else if (i.kind === "file") {                       // fayl kartasi: belgi + nom + hajm
      bubble.append(h("div", {class: "pnd-filebox"}, h("span", {class: "pnd-fico"}, h("span", {class: "pnd-ring sm", "aria-hidden": "true"})),
        h("div", {class: "pnd-finfo"}, h("b", {text: i.name || "Fayl"}), h("small", {text: i.size ? fmtSize(i.size) : ""}))));
      if (cap) bubble.append(btextEl("btext", cap, true));
    } else if (i.kind === "voice") {                      // yakuniy ovozli karta bilan bir xil: play tugmasi (spinner bilan), chiziq, davomiylik
      const d = Math.max(0, Math.round(i.dur || 0));
      bubble.append(h("div", {class: "vbox loading pnd-vbox"},
        h("span", {class: "vplay", "aria-hidden": "true"}, icon("play", "ic vi-play"), spinnerEl()),
        h("div", {class: "vmid"}, h("div", {class: "vtrack"}, h("div", {class: "vline"}, h("div", {class: "vfill"}))),
          h("div", {class: "vmeta"}, h("span", {class: "vtime", text: fmtDur(d)})))));
    } else {                                              // dumaloq video: yakuniy xabardagi dumaloq quti (kadr bo'lsa o'sha ko'rinadi)
      const vc = h("div", {class: "vnc"});
      if (i.thumb) vc.append(h("img", {class: "vnth", src: i.thumb, alt: "", draggable: "false"}));
      bubble.append(h("div", {class: "vnbox pnd-vnbox"}, vc));
    }
    p.meta = h("span", {class: "meta pnd-meta"});
    bubble.append(p.meta);
    row.append(h("div", {class: "slot"}), bubble);
    p.el = row; Pend.paint(p);
    return row;
  },
  paint(p) {
    if (!p.meta) return;
    p.meta.textContent = "";
    p.meta.append(h("span", {class: "lk ok", text: "🔒"}), " ", hhmm(Math.floor((p.t0 || (p.t0 = Date.now())) / 1000)), " ");
    if (p.stage === "sent") p.meta.append(icon("check", "ic pnd-ok"));            // yuborildi, server tasdig'i kutilmoqda
    else p.meta.append(h("span", {class: "pnd-lbl"}, h("i", {class: "pnd-spin", "aria-hidden": "true"}), Pend.label(p)));
  },
  stage(p, st) { if (!p) return; p.stage = st; Pend.paint(p); },
  sent(p) {
    if (!p) return;
    clearTimeout(p.timer); p.stage = "sent"; p.sentAt = Date.now(); Pend.paint(p);
    p.timer = setTimeout(() => { if (Pend.list.includes(p) && p.stage === "sent") Pend.wait(p); }, Pend.ACK_MS);      // javob kelmadi: qayta yuboriladi (xato emas)
  },
  wait(p) {                                               // internet yo'q/past: xabar navbatda «kutilmoqda…», ulanish bo'lishi bilan o'zi ketadi
    if (!p || !Pend.list.includes(p)) return;
    clearTimeout(p.timer); p.stage = "wait"; Pend.paint(p); Pend.ticker();
  },
  fail(p) { Pend.wait(p); },                              // eski nom: endi hech qachon «yuborilmadi» chiqmaydi
  ticker() { if (!Pend.tick) Pend.tick = setInterval(() => { if (!Pend.list.length) { clearInterval(Pend.tick); Pend.tick = 0; } else Pend.flush(); }, 3000); },
  go(p, make) { p.make = make; Pend.ticker(); return Pend.enqueue(p); },
  enqueue(p) { Pend.q = Pend.q.then(() => Pend.pump(p)).catch(() => {}); return Pend.q; },
  async pump(p) {                                         // bitta xabarni yuboradi; shifrlangan paket (p.msg) saqlanadi — qayta urinish AYNAN shu paketni yuboradi
    if (!Pend.list.includes(p) || p.busy || (p.stage === "sent")) return;
    p.busy = true; const g = ++p.gen;
    try {
      if (!p.msg) {
        Pend.stage(p, "up");
        let tm = 0;
        const msg = await Promise.race([p.make(p), new Promise((_, rej) => { tm = setTimeout(() => rej(new Error("timeout")), Pend.MAKE_MS); })]).finally(() => clearTimeout(tm));
        if (g !== p.gen || !Pend.list.includes(p)) { p.busy = false; return; }
        p.msg = msg;
      }
      if (!wsTry(p.msg)) throw new Error("offline");
      Pend.sent(p);
    } catch (err) {
      if (err && err.final) { toast(err.message, "error"); Pend.drop(p); }      // faqat internetga bog'liq bo'lmagan holat (masalan, fayl juda katta)
      else Pend.wait(p);
    }
    p.busy = false;
  },
  async flush() {                                         // ulanish tiklanganda yoki har 3 soniyada: kutayotganlar TARTIB bilan yuboriladi
    if (S.offline || !S.ws || S.ws.readyState !== 1) return;
    for (const p of Pend.list.slice()) { if (p.stage === "wait" && !p.busy) await Pend.enqueue(p); if (p.stage === "wait") break; }
  },
  onClose() { Pend.list.forEach(p => { if (p.stage === "sent") Pend.wait(p); }); },     // ulanish uzildi: tasdiq kelmaganlar qayta yuboriladi
  nack(m) {                                               // server paketni rad etdi
    const p = Pend.list.find(x => x.cid === m.cid); if (!p) return;
    if (m.final) Pend.drop(p);                           // qoida bo'yicha (mute, qulf...): sababi serverdan alohida xabar bilan keladi
    else Pend.wait(p);                                   // vaqtinchalik server xatosi: keyinroq o'zi qayta urinadi
  },
  drop(p) {
    clearTimeout(p.timer); p.gen++;
    if (p.info && p.info.url) { try { URL.revokeObjectURL(p.info.url); } catch (_) {} }
    const i = Pend.list.indexOf(p); if (i >= 0) Pend.list.splice(i, 1);
    if (p.el) p.el.remove();
  },
  mount(stick) {                                          // chat qayta chizilganda ham pufaklar pastda, tartibda qoladi
    if (!S.active) return;
    const k = chatKey(S.active), mine = Pend.list.filter(p => p.key === k);
    if (!mine.length) return;
    const box = $("msgs"), blank = box.querySelector(".blank"); if (blank) blank.remove();
    mine.forEach(p => box.append(p.el));
    if (stick || box._stick) { box.scrollTop = box.scrollHeight; box._stick = true; }
  },
  settle(m) {                                             // o'z xabarimiz serverdan qaytdi: eng eski «yuborildi» pufagi almashadi
    if (m.ch) return;
    const k = m.to == null ? "g" : "d" + partnerOf(m);
    const isFile = !!(m.file || m.image), same = x => x.key === k && (x.info.kind === "text") === !isFile;      // fayl xabari — fayl pufagini, matn — matn pufagini almashtiradi
    const p = (m.cid && Pend.list.find(x => x.cid === m.cid)) || Pend.list.find(x => same(x) && x.stage === "sent") || Pend.list.find(x => same(x) && x.stage === "wait") || Pend.list.find(x => same(x)) || Pend.list.find(x => x.key === k && x.stage === "sent");
    if (p) Pend.drop(p);
  },
  clear() { Pend.list.slice().forEach(Pend.drop); clearInterval(Pend.tick); Pend.tick = 0; },
};
async function uploadEnc(blob, failText) {               // shifrlangan faylni yuklaydi; tarmoq xatosi — qayta uriniladi, 4xx (fayl katta va h.k.) — yakuniy
  const r = await SC.fetch("/api/e2ee/blob", {method: "POST", headers: {Authorization: "Bearer " + S.token, "Content-Type": "application/octet-stream"}, body: blob});
  const j = await r.json().catch(() => ({}));
  if (!r.ok) { const e = new Error(typeof j.detail === "string" ? j.detail : failText); e.final = r.status >= 400 && r.status < 500 && ![401, 408, 409, 423, 425, 429].includes(r.status); throw e; }
  return j.blob;
}
addEventListener("online", () => { if (Pend.list.length) { reconnectNow(); setTimeout(() => Pend.flush(), 400); } });
document.addEventListener("visibilitychange", () => { if (!document.hidden && Pend.list.length) { if (!S.ws || S.ws.readyState !== 1) reconnectNow(); Pend.flush(); } });
/* ---------------- 30-offline.js: OFLAYN REJIM ----------------
   Internet yo'q paytda oldin yuklangan xabarlar, profillar va "last seen" ni o'qish mumkin.
   Xavfsizlik (E2EE saqlanadi): xabarlar qurilmada FAQAT shifrlangan holda (AES-GCM, IndexedDB) turadi.
     - oddiy kirish:           kalit parol bilan PBKDF2 (200 000 iteratsiya) orqali hosil bo'ladi; oflayn ochishda parol so'raladi
     - "bu qurilmada kirib qolish" yoqilgan bo'lsa: qurilmaning o'zida chiqarib bo'lmaydigan (non-extractable) kalit, parol shart emas
   Oflayn rejim faqat o'qish uchun: yuborish/tahrirlash o'chirilgan, internet qaytganda qayta kirish (yoki avtomatik) bajariladi. */
const Off = (() => {
  const DB = "tc_offline", ST = "kv", LIM = {group: 150, dm: 100, dms: 60, ch: 60, chs: 30};
  const te = new TextEncoder(), td = new TextDecoder();
  let key = null, mode = "", timer = 0, saving = false, info = null;
  const idb = () => new Promise((res, rej) => {
    if (!window.indexedDB || !crypto || !crypto.subtle) return rej(new Error("IndexedDB yo'q"));
    const r = indexedDB.open(DB, 1);
    r.onupgradeneeded = () => r.result.createObjectStore(ST);
    r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
  });
  const run = (m, fn) => idb().then(db => new Promise((res, rej) => {
    const tx = db.transaction(ST, m), st = tx.objectStore(ST), rq = fn(st);
    tx.oncomplete = () => { db.close(); res(rq && rq.result); }; tx.onerror = tx.onabort = () => { db.close(); rej(tx.error); };
  }));
  const get = k => run("readonly", st => st.get(k)), set = (k, v) => run("readwrite", st => st.put(v, k)), del = k => run("readwrite", st => st.delete(k));
  async function pwKey(pass, salt) {
    const base = await crypto.subtle.importKey("raw", te.encode(pass), "PBKDF2", false, ["deriveKey"]);
    return crypto.subtle.deriveKey({name: "PBKDF2", hash: "SHA-256", salt, iterations: 200000}, base, {name: "AES-GCM", length: 256}, false, ["encrypt", "decrypt"]);
  }
  async function stayKey(create) {
    let k = null; try { k = await get("stayKey"); } catch (_) {}
    if (!k && create) { k = await crypto.subtle.generateKey({name: "AES-GCM", length: 256}, false, ["encrypt", "decrypt"]); await set("stayKey", k); }
    return k;
  }
  const tail = (a, n) => a.length > n ? a.slice(a.length - n) : a;
  const plain = (k, v) => (typeof v === "function" || (v && v.nodeType)) ? undefined : v;
  function slimMsgs(list) { return list.filter(m => m && !m.service && m.user).map(m => Object.assign({}, m, {user: m.user.id})); }
  function build() {
    const dms = [...S.dms.entries()].filter(([, d]) => d.msgs.length).sort((a, b) => (b[1].msgs.at(-1).ts || 0) - (a[1].msgs.at(-1).ts || 0)).slice(0, LIM.dms);
    const chs = [...S.chn.entries()].filter(([, c]) => c.msgs.length).slice(0, LIM.chs);
    return {
      v: 1, ts: Date.now(), me: S.me, chat: S.chat, chList: S.chList, members: S.members,
      users: [...S.users.values()].filter(u => u && u.id != null),
      group: {msgs: slimMsgs(tail(S.group.msgs, LIM.group)), more: !!S.group.more},
      dms: dms.map(([uid, d]) => [uid, slimMsgs(tail(d.msgs, LIM.dm)), !!d.more]),
      chn: chs.map(([id, c]) => [id, slimMsgs(tail(c.msgs, LIM.ch)), !!c.more]),
    };
  }
  async function save() {
    timer = 0;
    if (!key || !S.me || S.offline || saving || !S.token) return;
    saving = true;
    try {
      const iv = crypto.getRandomValues(new Uint8Array(12));
      const data = await crypto.subtle.encrypt({name: "AES-GCM", iv}, key, te.encode(JSON.stringify(build(), plain)));
      await set("snap", {v: 1, mode, user: String(S.me.username || "").toLowerCase(), nick: S.me.nickname, ts: Date.now(), iv, data});
      info = {mode, user: String(S.me.username || "").toLowerCase(), ts: Date.now()}; lastSig = sig(); lastAt = Date.now(); showBtn();
    } catch (_) {}
    saving = false;
  }
  let lastSig = "", lastAt = 0;
  const sig = () => {                                                 // arzon belgi: o'zgarmagan bo'lsa qayta saqlanmaydi (batareya va CPU tejaladi)
    let g = S.group.msgs.length + ":" + ((S.group.msgs[S.group.msgs.length - 1] || {}).id) + "|" + S.users.size + "|" + S.members.length;
    S.dms.forEach((d, k) => { g += "," + k + ":" + d.msgs.length + ":" + ((d.msgs[d.msgs.length - 1] || {}).id); });
    return g;
  };
  const dirty = () => {
    if (!key || S.offline || timer) return;
    const now = Date.now(); if (sig() === lastSig && now - lastAt < 300000) return;
    timer = setTimeout(save, Math.max(4000, 20000 - (now - lastAt)));
  };
  const flush = () => { if (!key || S.offline || !S.me) return; clearTimeout(timer); timer = 0; if (sig() !== lastSig || Date.now() - lastAt > 60000) save(); };
  async function arm({user, password, stay}) {                       // kirishdan keyin: kalitni tayyorlaydi (fonda, ishga xalaqit bermaydi)
    try {
      if (stay) { key = await stayKey(true); mode = "stay"; try { await del("meta"); } catch (_) {} }
      else {
        let meta = null; try { meta = await get("meta"); } catch (_) {}
        const same = meta && meta.user === String(user).toLowerCase() && meta.salt;
        const salt = same ? meta.salt : crypto.getRandomValues(new Uint8Array(16));
        if (!same) { try { await del("snap"); } catch (_) {} }          // boshqa akkaunt: eski nusxa o'chadi
        key = await pwKey(password, salt); mode = "pw";
        await set("meta", {user: String(user).toLowerCase(), salt});
        try { await del("stayKey"); } catch (_) {}
      }
      dirty();
    } catch (_) { key = null; }
  }
  async function armStay() {                                         // "kirib qolish": sessiya tiklanganda yoki yoqilganda
    try { key = await stayKey(true); mode = "stay"; try { await del("meta"); } catch (_) {} dirty(); } catch (_) { key = null; }
  }
  async function disarmStay() {
    if (mode === "stay") { key = null; mode = ""; }
    try { const r = await get("snap"); await del("stayKey"); if (r && r.mode === "stay") { await del("snap"); info = null; } } catch (_) {}      // parol bilan shifrlangan nusxaga tegilmaydi
    showBtn();
  }
  async function wipe() { key = null; mode = ""; info = null; clearTimeout(timer); timer = 0; try { await del("snap"); await del("meta"); await del("stayKey"); } catch (_) {} showBtn(); }
  async function probe() {
    try { const r = await get("snap"); info = r ? {mode: r.mode, user: r.user, ts: r.ts} : null; } catch (_) { info = null; }
    showBtn();
  }
  function showBtn() { const b = $("offBtn"); if (b) { b.classList.toggle("hidden", !info); b.querySelector("span").textContent = info && info.mode === "pw" ? "Oflayn ko'rish (parol kerak)" : "Oflayn ko'rish"; } }

  async function open() {                                            // auth ekranidagi "Oflayn ko'rish"
    const err = $("autherr"); err.textContent = "";
    let rec = null; try { rec = await get("snap"); } catch (_) {}
    if (!rec) { err.textContent = "Oflayn xotira yo'q: avval internet bilan bir marta kiring."; return; }
    let k = null;
    try {
      if (rec.mode === "stay") k = await stayKey(false);
      else {
        const user = $("f_user").value.trim().replace(/^@/, "").toLowerCase(), pass = $("f_pass").value;
        if (!pass) { err.textContent = "Oflayn ochish uchun parolni kiriting (xabarlar parol bilan shifrlangan)."; return; }
        if (user && user !== rec.user) { err.textContent = "Bu qurilmadagi oflayn xotira boshqa akkauntniki."; return; }
        const meta = await get("meta");
        if (!meta || !meta.salt) { err.textContent = "Oflayn xotira buzilgan. Internet bilan qayta kiring."; return; }
        err.textContent = "Ochilmoqda…"; await new Promise(r => setTimeout(r, 30));
        k = await pwKey(pass, meta.salt);
      }
      if (!k) throw new Error("kalit yo'q");
      const snap = JSON.parse(td.decode(await crypto.subtle.decrypt({name: "AES-GCM", iv: rec.iv}, k, rec.data)));
      apply(snap, rec);
    } catch (_) { err.textContent = rec.mode === "pw" ? "Parol noto'g'ri yoki oflayn xotira buzilgan." : "Oflayn xotirani ochib bo'lmadi. Internet bilan kiring."; }
  }
  function apply(snap, rec) {
    resetState(); S.offline = true; S.token = null;
    S.me = snap.me; snap.users.forEach(u => S.users.set(u.id, u)); upsertUser(snap.me);
    S.members = snap.members || []; S.chat = snap.chat || {slowmode: 0, locked: false};
    const back = list => list.map(m => Object.assign(m, {user: S.users.get(m.user) || U(m.user)}));
    S.group.msgs = back(snap.group.msgs); S.group.more = false; S.chList = [];            // kanallar oflayn ochilmaydi (ular serverga bog'liq)
    snap.dms.forEach(([uid, msgs]) => { const d = dmOf(uid); d.msgs = back(msgs); d.loaded = true; d.more = false; d.last = d.msgs[d.msgs.length - 1] || null; });
    $("auth").classList.add("hidden"); $("app").classList.remove("hidden");
    document.querySelectorAll(".tabs button").forEach(x => x.classList.toggle("on", x.dataset.tab === "chats"));
    $("chat").classList.add("hidden"); $("empty").classList.remove("hidden");
    document.body.classList.add("offline-mode");
    const cb = $("connbar"); cb.textContent = "📴 Oflayn rejim — faqat o'qish • oxirgi yangilanish: " + fmtDT(Math.floor((snap.ts || rec.ts) / 1000)); cb.classList.remove("hidden");
    $("f_pass").value = ""; renderList();
    if (!isMobile()) openChat({kind: "group"});
  }
  function leave() {                                                 // internet qaytdi
    if (!S.offline) return;
    S.offline = false; document.body.classList.remove("offline-mode"); $("connbar").textContent = "Ulanish uzildi, qayta ulanmoqda…";
    let tok = ""; try { tok = localStorage.getItem(LS_STAY) || ""; } catch (_) {}
    if (tok) { closeChat(); resumeStay(tok, 0); } else showAuth("Internet qaytdi. Yangilash uchun qayta kiring.");
  }
  addEventListener("online", () => { if (S.offline) setTimeout(leave, 600); });
  document.addEventListener("visibilitychange", () => { if (document.hidden) flush(); });
  addEventListener("pagehide", flush);
  $("offBtn").addEventListener("click", open);
  probe();
  return {arm, armStay, disarmStay, wipe, dirty, probe, open, leave, save, get info() { return info; }};
})();
/* ---------------- Ovozli xabar va dumaloq video: yozish -> (ovozni o'zgartirish) -> shifrlash -> yuborish ----------------
   Mikrofon tugmasi (Telegram kabi):
     bir marta bosish — rejim almashadi (🎤 ovoz <-> 📹 dumaloq video);
     bosib turish — yozish; qo'yib yuborish — yuborish; chapga surish — bekor qilish; yuqoriga surish — qulflash (qo'lsiz yozish).
   Qulflangan yozuvda tugma = yuborish, 🗑 = bekor qilish. Esc ham bekor qiladi. Videoda doirani bosish (yoki 🔄) — old/orqa kamera.
   Xom ovoz (ovozli xabarda ham, videodagi ovozda ham) faqat shu qurilma xotirasida, darhol o'zgartiriladi;
   serverga FAQAT o'zgargan va E2EE bilan shifrlangan fayl boradi. */
const HOLD_MS = 260, CANCEL_DX = 90, LOCK_DY = 70;
const micEl = $("micBtn");
const vibrate = ms => { try { if (navigator.vibrate) navigator.vibrate(ms); } catch (_) {} };
try { S.recMode = localStorage.getItem("tc_recmode") === "video" ? "video" : "voice"; } catch (_) {}
function applyRecMode() {
  const v = S.recMode === "video";
  $("composer").classList.toggle("mode-video", v);
  micEl.setAttribute("aria-label", v ? "Dumaloq video xabar" : "Ovozli xabar");
  micEl.title = v ? "Dumaloq video: bosib turing — yozish, qo'yib yuboring — yuborish. Bir marta bosing — ovozga qaytadi"
                  : "Ovozli xabar: bosib turing — yozish, qo'yib yuboring — yuborish. Bir marta bosing — videoga o'tadi";
}
function toggleRecMode() {
  S.recMode = S.recMode === "video" ? "voice" : "video";
  try { localStorage.setItem("tc_recmode", S.recMode); } catch (_) {}
  applyRecMode(); vibrate(10);
  toast(S.recMode === "video" ? "📹 Dumaloq video — yozish uchun tugmani bosib turing" : "🎤 Ovozli xabar — yozish uchun tugmani bosib turing", "info");
}
applyRecMode();

function resetDragUi() { $("recLock").style.transform = ""; $("recbar").style.transform = ""; $("composer").classList.remove("rec-near-cancel", "rec-near-lock"); }
function showVnUi(on, hint) {                                          // jonli dumaloq ko'rinish: xabarlar maydoni ustida
  const ov = $("vnov");
  if (!on) { ov.classList.add("hidden"); ov.setAttribute("aria-hidden", "true"); return; }
  const r = $("msgs").getBoundingClientRect();
  Object.assign(ov.style, {left: r.left + "px", top: r.top + "px", width: r.width + "px", height: r.height + "px"});
  ov.style.setProperty("--vnd", Math.round(Math.max(140, Math.min(340, r.width * 0.8, r.height - 96))) + "px");
  $("vnHint").textContent = hint || "";
  ov.classList.remove("hidden"); ov.setAttribute("aria-hidden", "false");
}
function setRecUi(mode) {                                              // "off" | "hold" (bosib turilgan) | "lock" (qulflangan) | "busy"
  const c = $("composer"), vid = S.recKind === "video", on = mode !== "off";
  c.classList.toggle("recording", on); c.classList.toggle("rec-hold", mode === "hold");
  c.classList.toggle("rec-lock", mode === "lock" || mode === "busy"); c.classList.toggle("rec-busy", mode === "busy");
  c.classList.toggle("rec-video", on && vid);
  micEl.classList.toggle("on", mode === "hold" || mode === "lock"); micEl.disabled = mode === "busy"; $("recCancel").disabled = mode === "busy";
  micEl.setAttribute("aria-label", mode === "lock" ? "Yuborish" : mode === "off" ? (S.recMode === "video" ? "Dumaloq video xabar" : "Ovozli xabar") : "Yozilmoqda");
  $("recLbl").textContent = mode === "hold" ? "‹ Bekor qilish uchun chapga suring" : mode === "busy" ? (vid ? "Video tayyorlanmoqda…" : "Ovoz tayyorlanmoqda…")
    : mode === "lock" ? (vid ? "Video shifrlanib yuboriladi" : "Ovoz o'zgartirilib shifrlanadi") : "";
  if (mode === "hold" || mode === "lock") { if (!S.recTyping) S.recTyping = Typing.hold(vid ? "vnote" : "voice"); }      // suhbatdoshga "ovozli xabar / dumaloq video yozmoqda…"
  else if (S.recTyping) { S.recTyping(); S.recTyping = null; }
  if (mode !== "hold") resetDragUi();
  if (mode === "off") { $("recTime").textContent = "0:00"; $("vnProg").setAttribute("stroke-dashoffset", "301.6"); }
  showVnUi(vid && (mode === "hold" || mode === "lock"), mode === "hold" ? "↑ qulflash   ← bekor qilish" : mode === "lock" && S.rec && S.rec.canFlip ? "Doirani bosing — old/orqa kamera" : "");
}
function cancelRecording() {
  if (S.starting) S.startAbort = true;                                 // kamera/mikrofon hali ochilmoqda: ochilgach bekor qilinadi
  if (!S.rec || S.recBusy) return;
  const r = S.rec; S.rec = null; clearInterval(S.recTimer);
  Promise.resolve(r.cancel()).catch(() => {}); setRecUi("off");
}
function tickRec() {
  const r = S.rec; if (!r) return;
  const t = r.elapsed(); $("recTime").textContent = fmtDur(t);
  if (S.recKind === "video") $("vnProg").setAttribute("stroke-dashoffset", String(301.6 * (1 - Math.min(1, t / VNote.MAX_SEC))));
}
async function startRecording(kind) {                                  // true: yozuv boshlandi (S.rec o'rnatildi; ko'rinishni chaqiruvchi o'rnatadi)
  if (S.rec || S.recBusy || S.sending || S.starting || !S.active) return false;
  if (S.editing || S.pendingImg || inp.value.trim()) return false;
  if (S.active.kind === "group" && S.chat.locked && !amAdmin()) { toast("Umumiy chat qulflangan", "error"); return false; }
  if (S.active.kind === "dm" && U(S.active.uid).deleted) { toast("Bu akkaunt o'chirilgan. Xabar yuborib bo'lmaydi", "error"); return false; }
  const at = S.active, video = kind === "video"; let rec = null;
  S.starting = true; S.startAbort = false; S.recKind = kind;
  if (video) { $("vnov").classList.add("front"); $("vnov").classList.remove("can-flip"); showVnUi(true, "Kamera ochilmoqda…"); }
  try {
    const cb = {
      onLimit: () => { toast(video ? "Video 1 daqiqaga yetdi, yuborilmoqda" : "Yozuv " + Math.round(Voice.MAX_SEC / 60) + " daqiqaga yetdi, yuborilmoqda", "warn"); finishRecording(); },
      onLost: () => { if (rec && S.rec === rec) { cancelRecording(); toast(video ? "Kamera yoki mikrofon uzildi, yozuv bekor qilindi" : "Mikrofon uzildi, yozuv bekor qilindi", "error"); } },
    };
    rec = video ? await VNote.record(Object.assign({facing: S.vfacing, preview: $("vnPrev")}, cb)) : await Voice.record(cb);
    if (S.startAbort || S.active !== at) { Promise.resolve(rec.cancel()).catch(() => {}); rec = null; showVnUi(false); return false; }   // ruxsat so'ralayotganda bekor qilindi / chat almashtirildi
    S.rec = rec;
    if (video) { $("vnov").classList.toggle("front", rec.facing() === "user"); $("vnov").classList.toggle("can-flip", !!rec.canFlip); }
    S.recTimer = setInterval(tickRec, video ? 100 : 250);
    vibrate(20);
    return true;
  } catch (err) { showVnUi(false); toast(err.message || (video ? "Kamerani ochib bo'lmadi" : "Mikrofonni ochib bo'lmadi"), "error"); return false; }
  finally { S.starting = false; }
}
async function flipCamera() {                                          // yozuv to'xtamasdan old <-> orqa kamera
  const r = S.rec;
  if (!r || S.recKind !== "video" || S.recBusy || S.flipping || !r.canFlip) return;
  S.flipping = true; const st = $("vnStage"); st.classList.add("flipping");
  try {
    const ok = await r.flip();
    if (S.rec !== r) return;
    $("vnov").classList.toggle("front", r.facing() === "user"); S.vfacing = r.facing() === "environment" ? "environment" : "user";
    if (!ok) toast("Kamerani almashtirib bo'lmadi", "warn");
  } finally { st.classList.remove("flipping"); S.flipping = false; }
}
$("vnStage").addEventListener("click", flipCamera);                    // 🔄 tugma ham shu yerga ko'tariladi

function sendEncryptedFile(target, e, f, failText, pend) {              // fayl allaqachon shifrlangan (e); yuklash va yuborish navbatda, internet past bo'lsa kutadi
  const reply = S.replying; cancelReply();
  Pend.go(pend, async p => {
    if (!p.blobName) p.blobName = await uploadEnc(e.blob, failText);
    const payload = {t: "", f}; if (reply) payload.r = reply;
    return withTarget({type: "send", cid: p.cid, e2e: await sealFor(await keyForTarget(p.target), payload), blob: p.blobName}, p.target);
  });
}
async function sendVoice(wav, dur) {
  const target = S.active, pend = Pend.add(target, {kind: "voice", size: wav.size, dur});
  try {
    const e = await E2E.encryptFile(new Uint8Array(await wav.arrayBuffer()));
    sendEncryptedFile(target, e, {name: "ovozli-xabar.wav", mime: "audio/wav", size: wav.size, img: false, k: e.key, vo: 1, d: Math.round(dur * 10) / 10}, "Ovoz yuklanmadi", pend);
  } catch (err) { Pend.drop(pend); throw err; }
}
async function sendVideoNote(out, wav, dur) {                          // paket: [ovozsiz video] + [o'zgartirilgan ovoz] -> BITTA E2EE fayl
  const target = S.active, pend = Pend.add(target, {kind: "vnote", thumb: out.thumb && THUMB_RE.test(out.thumb) ? out.thumb : null});
  try {
    const packed = VNote.pack(new Uint8Array(await out.video.arrayBuffer()), wav ? new Uint8Array(await wav.arrayBuffer()) : null);
    const e = await E2E.encryptFile(packed);
    const f = {name: "video-xabar.vn", mime: out.mime, size: packed.length, img: false, k: e.key, rv: 1, d: Math.round(dur * 10) / 10};
    if (out.thumb && THUMB_RE.test(out.thumb)) f.th = out.thumb;
    sendEncryptedFile(target, e, f, "Video yuklanmadi", pend);
  } catch (err) { Pend.drop(pend); throw err; }
}
async function finishRecording() {
  const rec = S.rec; if (!rec || S.recBusy) return;
  const kind = S.recKind;
  S.recBusy = true; S.sending = true; clearInterval(S.recTimer); setRecUi("busy");
  const at = S.active;
  try {
    if (kind === "video") {
      const out = await rec.stop();
      if (!out) throw new Error("Yozuv olinmadi");
      if (out.duration < VNote.MIN_SEC) { toast("Video juda qisqa — yuborilmadi", "warn"); return; }
      let wav = null, dur = out.duration;
      if (out.audio) {
        const d = await Voice.disguise(out.audio);                     // asl ovoz shu yerda o'zgaradi
        out.audio = null;
        if (!d) { toast("Video juda qisqa — yuborilmadi", "warn"); return; }
        wav = d.wav; dur = d.duration;
      }
      if (S.active !== at) { toast("Chat almashtirildi — video xabar yuborilmadi", "warn"); return; }
      await sendVideoNote(out, wav, dur);
    } else {
      const raw = await rec.stop();
      if (!raw) throw new Error("Yozuv olinmadi");
      const out = await Voice.disguise(raw);                           // asl ovoz shu yerda o'zgaradi
      if (!out) { toast("Ovoz juda qisqa — yuborilmadi", "warn"); return; }
      if (S.active !== at) { toast("Chat almashtirildi — ovozli xabar yuborilmadi", "warn"); return; }
      await sendVoice(out.wav, out.duration);
    }
  } catch (err) { toast(err.message || (kind === "video" ? "Video xabar yuborilmadi" : "Ovozli xabar yuborilmadi"), "error"); }
  finally { S.rec = null; S.recBusy = false; S.sending = false; setRecUi("off"); syncSend(); }
}

/* --- bosish ishorasi (pointer): tap = rejim, bosib turish = yozish, surish = bekor/qulf --- */
let G = null;
const noClick = () => { S.noClickUntil = Date.now() + 350; };          // bosib turgandan keyin brauzer yuboradigan "click" e'tiborsiz qoladi
async function beginHold(g) {
  if (G !== g || g.aborted) return;
  g.started = true;
  const t0 = performance.now();
  const ok = await startRecording(S.recMode);
  if (!ok) { if (G === g) G = null; return; }
  if (g.released || g.cancelled) {                                     // tugma kamera/mikrofon ruxsati so'ralayotganda qo'yib yuborilgan
    cancelRecording();
    if (performance.now() - t0 > 700) toast("Ruxsat berildi. Endi tugmani bosib turing", "ok");
    return;
  }
  setRecUi(g.locked || performance.now() - t0 > 700 ? "lock" : "hold");   // ruxsat oynasi chiqqan bo'lsa barmoq holati ishonchsiz: qo'lsiz (qulflangan) rejim
}
function endPress(e, cancel) {
  const g = G; if (!g || e.pointerId !== g.id) return;
  G = null; clearTimeout(g.timer); g.timer = 0;
  try { micEl.releasePointerCapture(g.id); } catch (_) {}
  noClick();
  if (!g.started) { if (!g.aborted && !cancel) toggleRecMode(); return; }
  g.released = true;
  if (g.cancelled || g.locked) return;
  if (S.rec && !S.recBusy) {
    if (cancel) cancelRecording();
    else if (S.rec.elapsed() < 0.5) { cancelRecording(); toast("Yozish uchun tugmani bosib turing", "warn"); }
    else finishRecording();
  }
}
micEl.addEventListener("pointerdown", e => {
  if (G && !S.starting && !S.rec) G = null;                            // yo'qolgan eski ishora (pointerup kelmagan) — yangisi boshlanadi
  if ((e.pointerType === "mouse" && e.button !== 0) || G || S.recBusy || S.rec || S.starting) return;   // qulflangan yozuvda tugma "yuborish" (click)
  const g = G = {id: e.pointerId, x0: e.clientX, y0: e.clientY, started: false, released: false, locked: false, cancelled: false, aborted: false, timer: 0};
  try { micEl.setPointerCapture(e.pointerId); } catch (_) {}
  g.timer = setTimeout(() => { g.timer = 0; beginHold(g); }, HOLD_MS);
});
micEl.addEventListener("pointermove", e => {
  const g = G; if (!g || e.pointerId !== g.id) return;
  const dx = e.clientX - g.x0, dy = e.clientY - g.y0;
  if (!g.started) { if (g.timer && Math.hypot(dx, dy) > 16) { clearTimeout(g.timer); g.timer = 0; g.aborted = true; } return; }
  if (!S.rec || S.recBusy || g.locked || g.cancelled) return;
  const c = $("composer");
  c.classList.toggle("rec-near-cancel", dx < -CANCEL_DX * 0.6); c.classList.toggle("rec-near-lock", dy < -LOCK_DY * 0.6);
  $("recbar").style.transform = "translateX(" + Math.max(-110, Math.min(0, dx * 0.7)) + "px)";
  $("recLock").style.transform = "translateY(" + Math.max(-30, Math.min(0, dy * 0.45)) + "px)";
  if (dx < -CANCEL_DX) { g.cancelled = true; vibrate(15); cancelRecording(); }
  else if (dy < -LOCK_DY) { g.locked = true; vibrate(20); setRecUi("lock"); }
});
micEl.addEventListener("pointerup", e => endPress(e, false));
micEl.addEventListener("pointercancel", e => endPress(e, true));
micEl.addEventListener("lostpointercapture", e => endPress(e, true));
micEl.addEventListener("contextmenu", e => e.preventDefault());        // telefonda uzoq bosganda menyu chiqmasin
micEl.addEventListener("click", e => {
  if (Date.now() < S.noClickUntil) return;
  if (S.rec) { if (!S.recBusy) finishRecording(); return; }            // qulflangan yozuv: tugma = yuborish
  if (e.detail === 0 && !S.starting) startRecording(S.recMode).then(ok => { if (ok) setRecUi("lock"); });   // klaviatura: qulflangan yozuv boshlanadi
});
micEl.addEventListener("keydown", e => { if (!S.rec && (e.key === "ArrowLeft" || e.key === "ArrowRight")) { e.preventDefault(); toggleRecMode(); } });   // klaviatura: rejim almashtirish
$("recCancel").addEventListener("click", cancelRecording);
document.addEventListener("keydown", e => { if (e.key === "Escape" && S.rec && !S.recBusy) { e.preventDefault(); e.stopPropagation(); cancelRecording(); } }, true);
document.addEventListener("visibilitychange", () => { if (document.hidden && S.rec && !S.recBusy) { cancelRecording(); toast("Ilovadan chiqilgani uchun yozuv bekor qilindi", "warn"); } });
addEventListener("pagehide", cancelRecording);
document.addEventListener("visibilitychange", () => {
  if (!document.hidden && S.active && S.active.kind === "dm") {
    const dm = dmOf(S.active.uid);
    if (dm.unread) { dm.unread = 0; wsSend({type: "read", with: S.active.uid}); renderList(); }
  }
});


/* ---------------- Telegram uslubidagi dialoglar ---------------- */
function askDialog({title, text, okText = "OK", cancelText = "Bekor qilish", danger = false, input = null, alertOnly = false}) {
  return new Promise(resolve => {
    const root = $("dlg"), prevFocus = document.activeElement;
    let field = null;
    const done = v => {
      if (done.d) return; done.d = true; S.dlgCancel = null; navPop("dlg");
      root.classList.add("hidden"); root.setAttribute("aria-hidden", "true"); root.textContent = "";
      document.removeEventListener("keydown", onKey, true);
      if (prevFocus && prevFocus.focus) try { prevFocus.focus(); } catch (_) {}
      resolve(v);
    };
    const ok = () => done(input ? field.value : true);
    const cancel = () => done(input ? null : false);
    const onKey = e => {
      if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); cancel(); }
      else if (e.key === "Enter" && !(e.target && e.target.tagName === "BUTTON")) { e.preventDefault(); e.stopPropagation(); ok(); }
    };
    const card = h("div", {class: "dlg-card", role: alertOnly ? "alertdialog" : "dialog", "aria-modal": "true"});
    if (title) card.append(h("h3", {class: "dlg-t", text: title}));
    if (text) card.append(h("p", {class: "dlg-m", text}));
    if (input) { field = h("input", {class: "dlg-in", type: input.type || "text", autocomplete: "off", spellcheck: "false", placeholder: input.placeholder || ""}); field.value = input.value || ""; card.append(field); }
    const btns = h("div", {class: "dlg-b"});
    if (!alertOnly) btns.append(h("button", {class: "dlg-btn", type: "button", text: cancelText, onclick: cancel}));
    const okBtn = h("button", {class: "dlg-btn" + (danger ? " danger" : ""), type: "button", text: okText, onclick: ok});
    btns.append(okBtn); card.append(btns);
    root.textContent = ""; root.append(card);
    root.onmousedown = root.onclick = e => { if (e.target === root) cancel(); };
    root.classList.remove("hidden"); root.setAttribute("aria-hidden", "false");
    S.dlgCancel = cancel; navPush("dlg");
    document.addEventListener("keydown", onKey, true);
    setTimeout(() => { (field || okBtn).focus(); if (field) field.select(); }, 30);
  });
}
const confirmDlg = (text, o = {}) => askDialog({title: o.title, text, okText: o.okText || "OK", danger: !!o.danger});
const promptDlg = (title, text, value = "", o = {}) => askDialog({title, text, input: {value, placeholder: o.placeholder, type: o.type}, okText: o.okText || "OK", danger: !!o.danger});

/* Brauzerning o'z o'ng-tugma menyusini yopish (matn kiritish maydonlaridan tashqari) */
document.addEventListener("contextmenu", e => {
  if (e.target.closest && e.target.closest("input, textarea")) return;   // nusxalash/qo'yish uchun qoladi
  e.preventDefault();
  if (!e.target.closest(".bubble")) closeCtx();
});

/* ---------------- modal ---------------- */
function showModal(node) {
  const sheet = $("sheet"), top = sheet.scrollTop;
  sheet.textContent = ""; sheet.append(node);
  $("modal").classList.remove("hidden");
  sheet.scrollTop = top;
}
function openModal(build, live, wide, fit) { if ($("modal").classList.contains("hidden")) navPush("modal"); S.modal = {build, live: !!live, at: performance.now()}; $("sheet").classList.toggle("wide", !!wide); $("sheet").classList.toggle("fit", !!fit); $("sheet").classList.remove("tgp"); showModal(build()); }
function closeModal() { const was = !$("modal").classList.contains("hidden"); S.modal = null; clearTimeout(_rmTimer); _rmTimer = 0; $("modal").classList.add("hidden"); $("sheet").classList.remove("wide", "fit", "tgp"); $("sheet").textContent = ""; if (was) navPop("modal"); }
/* Jonli oyna (profil va h.k.) har "presence"/yangilanishda QAYTA QURILARDI: ochilish animatsiyasi paytida DOM almashib, rasm qayta
   yuklanib/dekodlanib, kadrlar tushib ketardi. Endi: animatsiya tugaguncha (~450 ms) kutiladi va ketma-ket chaqiruvlar bitta qurishga birlashadi. */
let _rmTimer = 0;
function refreshModal() {
  refreshPages();
  if (!S.modal || !S.modal.live) return;
  if (_rmTimer) return;
  const wait = Math.max(150, 450 - (performance.now() - S.modal.at));
  _rmTimer = setTimeout(() => { _rmTimer = 0; if (S.modal && S.modal.live) requestAnimationFrame(() => { if (S.modal && S.modal.live) showModal(S.modal.build()); }); }, wait);
}
$("modal").addEventListener("mousedown", e => { if (e.target === $("modal")) closeModal(); });
$("modal").addEventListener("click", e => { if (e.target === $("modal")) closeModal(); });
function setPageZoom(on) {                           // oynalar zoom bo'lmaydi; faqat rasm ko'rish (lightbox) oynasida chimchilab kattalashtirish ishlaydi
  const v = document.querySelector('meta[name="viewport"]'); if (!v) return;
  v.setAttribute("content", "width=device-width, initial-scale=1, viewport-fit=cover, interactive-widget=resizes-content" + (on ? "" : ", maximum-scale=1, user-scalable=no"));
}
["gesturestart", "gesturechange", "gestureend"].forEach(t => document.addEventListener(t, e => { if (!e.target.closest || !e.target.closest("#lightbox")) e.preventDefault(); }, {passive: false}));   // iOS Safari: chimchilab zoom
document.addEventListener("dblclick", e => { if (e.target.closest && e.target.closest(".modal,.dlg,.sheet,.ctx")) e.preventDefault(); });
function openLightbox(url) { setPageZoom(true); $("lbImg").src = url; $("lightbox").classList.remove("hidden"); navPush("lb"); }
function closeLightbox() { setPageZoom(false); const was = !$("lightbox").classList.contains("hidden"); $("lightbox").classList.add("hidden"); $("lbImg").removeAttribute("src"); if (was) navPop("lb"); }
$("lightbox").addEventListener("click", closeLightbox);

/* ---------- Profil rasmini kattalashtirib ko'rish (Telegramdagidek): avatar joyidan o'sib chiqadi, tortib yoki bosib yopiladi ---------- */
const AVV = {el: null, closing: false, uid: null, g: null};
const AV_EASE = "cubic-bezier(.22,.9,.28,1)";
function zoomAvatar(el, u) {                          // profil sahifasidagi avatar: rasm bo'lsa bosiladigan bo'ladi
  if (!u.avatar) return el;
  el.classList.add("av-zoom"); el.dataset.uid = String(u.id);
  el.setAttribute("role", "button"); el.tabIndex = 0; el.setAttribute("aria-label", "Profil rasmini kattalashtirish");
  el.addEventListener("click", e => { e.stopPropagation(); openAvatarViewer(el, u); });
  el.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); openAvatarViewer(el, u); } });
  return el;
}
function avSource(uid) {                              // sahifa qayta chizilgan bo'lishi mumkin: joriy avatar elementini qayta topamiz
  const pg = PG.list[PG.list.length - 1];
  return (pg ? pg.el : document).querySelector('.av-zoom[data-uid="' + uid + '"]');
}
const avReduce = () => matchMedia("(prefers-reduced-motion: reduce)").matches;
function avFrom(g, sr) {                              // manba doira joyidan yakuniy joyga o'tish uchun transform
  return "translate(" + (sr.left - g.fx) + "px," + (sr.top - g.fy) + "px) scale(" + (sr.width / g.side) + ")";
}
function openAvatarViewer(src, u) {
  if (AVV.el || !u.avatar) return;
  const vv = window.visualViewport, vw = Math.round(vv ? vv.width : innerWidth), vh = Math.round(vv ? vv.height : innerHeight);
  const mobile = vw <= 600, side = Math.round(Math.min(vw, vh * (mobile ? 0.8 : 0.78), 560));
  const g = {side, fx: Math.round((vw - side) / 2), fy: Math.round((vh - side) / 2 - (mobile ? 0 : 10)), endR: mobile ? "0%" : "3%"};
  const sr = src.getBoundingClientRect(), reduce = avReduce();
  const back = h("div", {class: "avv-back"});
  const img = h("img", {src: u.avatar, alt: "", draggable: "false", decoding: "async"});
  const box = h("div", {class: "avv-box"}, img);
  box.style.left = g.fx + "px"; box.style.top = g.fy + "px"; box.style.width = side + "px"; box.style.height = side + "px"; box.style.borderRadius = g.endR; box.style.transformOrigin = "0 0";
  const xb = h("button", {class: "avv-x", type: "button", "aria-label": "Yopish"}, icon("close"));
  const top = h("div", {class: "avv-top"}, h("div", {class: "avv-cap"}, h("b", {text: u.nickname || "@" + u.username}), h("small", {text: "@" + u.username + " • " + statusText(u)})), xb);
  const root = h("div", {class: "avv", role: "dialog", "aria-label": "Profil rasmi"}, back, box, top);
  Object.assign(AVV, {el: root, closing: false, uid: u.id, g, box, back, top});
  document.body.append(root);
  src.classList.add("av-hide");
  navPush("avv");
  if (!reduce) {
    box.animate([{transform: avFrom(g, sr), borderRadius: "50%"}, {transform: "none", borderRadius: g.endR}], {duration: 360, easing: AV_EASE});
    back.animate([{opacity: 0}, {opacity: 1}], {duration: 260, easing: "ease-out"});
    top.animate([{opacity: 0}, {opacity: 0, offset: .45}, {opacity: 1}], {duration: 420, easing: "ease-out"});
  } else back.animate([{opacity: 0}, {opacity: 1}], {duration: 120});
  // bosish = yopish; vertikal tortish = rasm barmoq bilan birga suriladi, yetarlicha tortilsa yopiladi, aks holda joyiga qaytadi
  let d = null;
  const dragTo = dy => {
    const k = 1 - Math.min(Math.abs(dy) / 1100, 0.22);
    box.style.transform = "translateY(" + dy + "px) scale(" + k + ")"; box.style.transformOrigin = "50% 50%";
    const o = 1 - Math.min(Math.abs(dy) / 380, 0.75); back.style.opacity = String(o); top.style.opacity = String(Math.max(0, 1 - Math.abs(dy) / 120));
  };
  root.addEventListener("pointerdown", e => {
    if (AVV.closing || e.target.closest(".avv-x") || (e.pointerType === "mouse" && e.button !== 0)) return;
    d = {y: e.clientY, t: e.timeStamp, dy: 0, moved: false, v: 0, ly: e.clientY, lt: e.timeStamp};
    try { root.setPointerCapture(e.pointerId); } catch (_) {}
  });
  root.addEventListener("pointermove", e => {
    if (!d) return;
    d.dy = e.clientY - d.y;
    if (!d.moved && Math.abs(d.dy) > 8) d.moved = true;
    const dt = e.timeStamp - d.lt; if (dt > 0) { d.v = (e.clientY - d.ly) / dt; d.ly = e.clientY; d.lt = e.timeStamp; }
    if (d.moved) dragTo(d.dy);
  });
  const end = e => {
    if (!d) return; const x = d; d = null;
    if (e.type === "pointercancel") x.moved = x.moved && Math.abs(x.dy) > 8;
    if (!x.moved) { if (e.type === "pointerup") closeAvatarViewer(); return; }
    if (Math.abs(x.dy) > 110 || Math.abs(x.v) > 0.7) { closeAvatarViewer(false, true); return; }
    const cur = box.style.transform;                       // yetmadi: joyiga yumshoq qaytadi
    box.style.transform = ""; box.style.transformOrigin = "0 0";
    box.animate([{transform: cur, transformOrigin: "50% 50%"}, {transform: "none", transformOrigin: "50% 50%"}], {duration: 260, easing: "cubic-bezier(.3,1.35,.5,1)"});
    back.animate([{opacity: back.style.opacity || 1}, {opacity: 1}], {duration: 200}); back.style.opacity = ""; top.style.opacity = "";
  };
  root.addEventListener("pointerup", end); root.addEventListener("pointercancel", end);
  xb.addEventListener("click", e => { e.stopPropagation(); closeAvatarViewer(); });
  xb.focus({preventScroll: true});
}
function closeAvatarViewer(fromNav, dragged) {
  const root = AVV.el; if (!root || AVV.closing) return;
  AVV.closing = true;
  if (!fromNav) navPop("avv");
  const {box, back, top, g} = AVV, src = avSource(AVV.uid);
  const done = () => { root.remove(); if (AVV.el === root) { AVV.el = null; AVV.closing = false; } document.querySelectorAll(".av-hide").forEach(x => x.classList.remove("av-hide")); };
  const bo = parseFloat(back.style.opacity || "1");
  back.animate([{opacity: bo}, {opacity: 0}], {duration: 260, easing: "ease-in", fill: "forwards"});
  top.animate([{opacity: parseFloat(top.style.opacity || "1")}, {opacity: 0}], {duration: 140, fill: "forwards"});
  const sr = src ? src.getBoundingClientRect() : null, vh = innerHeight;
  const visible = sr && sr.width > 0 && sr.bottom > 0 && sr.top < vh;
  if (avReduce()) { setTimeout(done, 120); return; }
  const cur = getComputedStyle(box).transform, curT = cur && cur !== "none" ? cur : "none";
  box.style.transformOrigin = dragged ? "50% 50%" : "0 0";
  if (visible && !dragged) {
    const a = box.animate([{transform: curT, borderRadius: g.endR}, {transform: avFrom(g, sr), borderRadius: "50%"}], {duration: 300, easing: "cubic-bezier(.4,.1,.2,1)", fill: "forwards"});
    a.onfinish = done;
  } else if (visible) {                                  // tortib yopilganda: rasm manbaga qarab kichrayib qaytadi
    box.style.transformOrigin = "0 0";
    // hozirgi vizual joy (barmoq bilan surilgan) -> manba doira
    const bx = box.getBoundingClientRect();
    const k0 = bx.width / g.side, from = "translate(" + (bx.left - g.fx) + "px," + (bx.top - g.fy) + "px) scale(" + k0 + ")";
    box.style.transform = "none";
    const a = box.animate([{transform: from, borderRadius: g.endR}, {transform: avFrom(g, sr), borderRadius: "50%"}], {duration: 280, easing: "cubic-bezier(.4,.1,.2,1)", fill: "forwards"});
    a.onfinish = done;
  } else {                                               // manba ko'rinmasa: pastga siljib so'nadi
    const a = box.animate([{transform: curT, opacity: 1}, {transform: (curT === "none" ? "" : curT + " ") + "scale(.85)", opacity: 0}], {duration: 240, easing: "ease-in", fill: "forwards"});
    a.onfinish = done;
  }
}
document.addEventListener("keydown", e => {
  if (e.key !== "Escape") return;
  if (AVV.el) closeAvatarViewer();
  else if (!$("lightbox").classList.contains("hidden")) closeLightbox();
  else if (S.sel && !S.modal && $("ctx").classList.contains("hidden")) exitSelect();
  else if (!$("ctx").classList.contains("hidden")) closeCtx();
  else if (S.modal) closeModal();
  else if (PG.list.length) closePage();
  else if (drawerIsOpen()) closeDrawer();
});

function sheetHead(title, onBack) {
  return h("div", {class: "sh-head"},
    onBack ? h("button", {class: "icon-btn", type: "button", onclick: onBack, "aria-label": "Orqaga"}, icon("back")) : null,
    h("span", {text: title}),
    h("button", {class: "icon-btn", type: "button", onclick: closeModal, "aria-label": "Yopish"}, icon("close")));
}

/* ====================================================================
   SAHIFALAR: o'ngdan chapga (profil, sozlamalar, guruh/kanal ma'lumoti...) va CHAP MENYU: chapdan o'ngga.
   Hammasi bitta tizim: oyna ustida oyna (alert) EMAS — to'liq sahifa, orqaga tugmasi/jest bilan yopiladi.
   ==================================================================== */
const PG = {list: []};
const PG_MS = 320;
function pageHead(title, right) {
  return h("div", {class: "pg-head"},
    h("button", {class: "icon-btn", type: "button", onclick: () => closePage(), "aria-label": "Orqaga"}, icon("back")),
    h("span", {class: "pg-title", text: title}), right || null);
}
function paintPage(p) {
  const top = p.el.scrollTop;
  p.refresh = null;
  p.el.textContent = "";
  p.el.append(p.build(p));
  p.el.scrollTop = top;
}
function openPage(build, live) {
  const layer = $("pages");
  const p = {el: h("section", {class: "pg tgp"}), build, live: !!live, at: performance.now(), name: "pg" + PG.list.length, refresh: null, closing: false};
  paintPage(p);
  const prev = PG.list[PG.list.length - 1]; if (prev) prev.el.classList.add("under");
  PG.list.push(p);
  layer.classList.add("on"); layer.append(p.el);
  navPush(p.name);
  void p.el.offsetWidth;
  requestAnimationFrame(() => p.el.classList.add("in"));
  return p;
}
function closePage() {
  const p = PG.list.pop(); if (!p) return;
  const prev = PG.list[PG.list.length - 1]; if (prev) prev.el.classList.remove("under");
  p.closing = true; p.el.classList.remove("in");
  setTimeout(() => { p.el.remove(); if (!PG.list.length) $("pages").classList.remove("on"); }, PG_MS);
  navPop(p.name);
}
function closeAllPages() { while (PG.list.length) closePage(); }
function resetPages() { if (AVV.el) { AVV.el.remove(); AVV.el = null; AVV.closing = false; } PG.list.forEach(p => p.el.remove()); PG.list.length = 0; $("pages").classList.remove("on"); closeDrawerNow(); }
let _rpTimer = 0;
function refreshPages() {                          // jonli sahifalar (profil, ma'lumot) — animatsiya tugagach, ketma-ket chaqiruvlar bittaga birlashadi
  if (_rpTimer || !PG.list.some(p => p.live || p.refresh)) return;
  const at = Math.max(...PG.list.map(p => p.at));
  _rpTimer = setTimeout(() => {
    _rpTimer = 0;
    requestAnimationFrame(() => PG.list.slice().forEach(p => { if (p.closing) return; if (p.refresh) p.refresh(); else if (p.live) paintPage(p); }));
  }, Math.max(150, 450 - (performance.now() - at)));
}
function repaintTopPage() { const p = PG.list[PG.list.length - 1]; if (p) paintPage(p); }
$("pages").addEventListener("click", e => { if (e.target === $("pages")) closeAllPages(); });     // kompyuterda: panel tashqarisini bosish

/* ---------------- chap menyu (Telegram uslubi) ---------------- */
const drawerIsOpen = () => $("drawer").classList.contains("open");
function openDrawer() {
  if (drawerIsOpen()) return;
  renderDrawer();
  $("drawerBack").classList.add("show"); $("drawer").classList.add("open"); $("drawer").setAttribute("aria-hidden", "false");
  navPush("drawer");
}
function closeDrawerNow() { $("drawerBack").classList.remove("show"); $("drawer").classList.remove("open"); $("drawer").setAttribute("aria-hidden", "true"); }
function closeDrawer() { if (!drawerIsOpen()) return; closeDrawerNow(); navPop("drawer"); }
function renderDrawer() {
  const d = $("drawer"), me = S.me; d.textContent = "";
  const go = fn => () => {                              // sahifa ochilganda menyu animatsiyasiz yopiladi — sahifa ostida ko'rinib qolmasin
    const dr = $("drawer"), bk = $("drawerBack"); dr.classList.add("snap"); bk.classList.add("snap");
    closeDrawer();
    setTimeout(() => { fn(); setTimeout(() => { dr.classList.remove("snap"); bk.classList.remove("snap"); }, 80); }, 0);
  };
  const item = (ic, text, fn) => h("button", {class: "dw-i", type: "button", onclick: go(fn)}, icon(ic), h("span", {text}));
  const dark = document.documentElement.dataset.theme === "dark";
  const sw = h("span", {class: "sw-t", role: "switch", "aria-checked": String(dark)});
  const night = h("button", {class: "dw-i", type: "button", onclick: () => { toggleTheme(); sw.setAttribute("aria-checked", String(document.documentElement.dataset.theme === "dark")); }},
    icon("moon"), h("span", {text: "Tungi rejim"}), sw);
  d.append(
    h("div", {class: "dw-head"}, avatar(me, "l"), h("div", {class: "dw-name"}, nameEl(me, {big: true})), h("div", {class: "dw-user", text: "@" + me.username})),
    h("div", {class: "dw-list"},
      item("user", "Mening profilim", () => openProfile(me.id)),
      item("group", "Foydalanuvchilar", openUsersPage),
      item("gear", "Sozlamalar", openSettingsPage),
      ...(amAdmin() ? [item("shield", "Admin sozlamalari", openAdminHome)] : []),
      night,
      item("lock", "Shifrlash: server nimani ko'radi?", () => openInspector("server"))),
    h("div", {class: "dw-foot", text: APP_NAME}));
}
$("menuBtn").addEventListener("click", e => { e.stopPropagation(); openDrawer(); });
$("drawerBack").addEventListener("click", closeDrawer);
(() => {                                           // chapga surib yopish
  let x0 = null, y0 = 0;
  const d = $("drawer");
  d.addEventListener("touchstart", e => { const t = e.touches[0]; x0 = t.clientX; y0 = t.clientY; }, {passive: true});
  d.addEventListener("touchend", e => { if (x0 == null) return; const t = e.changedTouches[0], dx = t.clientX - x0, dy = Math.abs(t.clientY - y0); x0 = null; if (dx < -60 && dy < 60) closeDrawer(); }, {passive: true});
})();

/* ---------------- umumiy qismlar ---------------- */
function switchRow(ic, text, getOn, onSet, hint) {
  const sw = h("span", {class: "sw-t", role: "switch", "aria-checked": String(!!getOn())});
  const row = h("button", {class: "set-row", type: "button", "aria-label": text}, icon(ic), h("span", {text}), sw);
  const sync = () => sw.setAttribute("aria-checked", String(!!getOn()));
  row.addEventListener("click", async () => { try { await onSet(!getOn()); } catch (err) { toast(err.message, "error"); } sync(); });
  return hint ? h("div", {}, row, h("p", {class: "tg-hint", text: hint})) : row;
}
const setRow = (ic, text, fn, val, danger) => h("button", {class: "set-row" + (danger ? " danger" : ""), type: "button", onclick: fn}, icon(ic), h("span", {text}), val ? h("span", {class: "sv", text: val}) : null);
const gapEl = () => h("div", {class: "tg-gap"});
const secTitle = (text, n) => h("div", {class: "sec-t"}, h("span", {text}), n == null ? null : h("b", {text: String(n)}));
function fmtDay(ts) {
  const d = new Date(ts * 1000), n = new Date();
  const same = d.getFullYear() === n.getFullYear() && d.getMonth() === n.getMonth() && d.getDate() === n.getDate();
  return (same ? "Bugun" : d.getDate() + "-" + MONTHS[d.getMonth()] + (d.getFullYear() !== n.getFullYear() ? " " + d.getFullYear() : "")) + ", " + hhmm(ts);
}

/* Foydalanuvchilar: qidiruv + ro'yxat. Hevorix (ega) doim birinchi, so'ng adminlar, so'ng oddiy foydalanuvchilar. */
function usersBlock() {
  let filter = "";
  const el = h("div", {class: "ublock"});
  const title = h("div", {class: "sec-t"});
  const search = h("input", {type: "text", class: "gsearch", placeholder: "Foydalanuvchilarni qidirish", autocomplete: "off", autocapitalize: "none", spellcheck: "false", "aria-label": "Foydalanuvchilarni qidirish"});
  const list = h("div", {class: "mlist"});
  const rank = u => u.role === "owner" ? 0 : u.role === "admin" ? 1 : 2;
  const fill = () => {
    list.textContent = "";
    const q = filter.trim().toLowerCase();
    const all = S.members.map(m => U(m.id)).filter(u => !u.deleted);
    const shown = all.filter(u => !q || (u.nickname || "").toLowerCase().includes(q) || (u.username || "").toLowerCase().includes(q))
      .sort((a, b) => (rank(a) - rank(b)) || ((isOnline(b.id) ? 1 : 0) - (isOnline(a.id) ? 1 : 0)) || (a.nickname || "").localeCompare(b.nickname || ""));
    title.textContent = ""; title.append(h("span", {text: "Foydalanuvchilar"}), h("b", {text: String(all.length)}));
    shown.forEach(u => list.append(itemEl({
      av: avatar(u, "m", true), title: [nameEl(u), u.id === S.me.id ? h("span", {class: "i-time", text: "(siz)"}) : null],
      sub: (isStaff(u) ? roleLabel(u.role) + " • " : "") + statusText(u), subOn: isOnline(u.id),
      onclick: () => openProfile(u.id),
    })));
    if (!shown.length) list.append(h("div", {class: "none", text: "Hech narsa topilmadi"}));
  };
  search.addEventListener("input", () => { filter = search.value; fill(); });
  fill();
  el.append(title, search, list);
  return {el, fill};
}
function openUsersPage() { openPage(p => { const ub = usersBlock(); p.refresh = ub.fill; return h("div", {}, pageHead("Foydalanuvchilar"), ub.el); }); }

/* Media sonlari: faqat qurilmaga yuklangan xabarlar bo'yicha (xabarlar E2EE — server sanay olmaydi). */
function mediaCounts(list, more) {
  const st = {img: 0, video: 0, file: 0, audio: 0, voice: 0, more: !!more};
  (list || []).forEach(m => {
    if (m.deleted) return;
    if (m.image) { st.img++; return; }
    const f = m.file; if (!f) return;
    const mime = f.mime || "";
    if (f.voice) st.voice++;
    else if (f.vnote || /^video\//.test(mime)) st.video++;
    else if (/^audio\//.test(mime)) st.audio++;
    else if (/^image\//.test(mime)) st.img++;
    else st.file++;
  });
  return st;
}
function mediaRows(st) {
  const plus = st.more ? "+" : "";
  const row = (ic, n, label) => h("div", {class: "tg-row"}, icon(ic), h("span", {text: n + plus + " " + label}));
  return h("div", {class: "tg-media"}, row("attach", st.img, "ta rasm"), row("videocam", st.video, "ta video"), row("file", st.file, "ta fayl"),
    row("headphones", st.audio, "ta audio fayl"), row("mic", st.voice, "ta ovozli xabar"));
}
/* Guruh va kanal profili: avatar, nom, rasm/video/fayl/audio/ovozli xabar sonlari va (kerak bo'lsa) foydalanuvchilar ro'yxati. */
function infoPage(o) {
  return openPage(p => {
    const wrap = h("div", {});
    const subEl = h("div", {class: "pstat", text: o.sub()});
    const media = h("div", {});
    const paintMedia = () => { const m = o.msgs(); media.textContent = ""; media.append(mediaRows(mediaCounts(m.list, m.more))); };
    paintMedia();
    wrap.append(pageHead(o.title),
      h("div", {class: "tg-top"}, o.av(), h("div", {class: "pname"}, h("span", {text: o.name})), subEl));
    if (o.rows && o.rows.length) wrap.append(h("div", {class: "tg-info"}, ...o.rows));
    wrap.append(gapEl(), media,
      h("p", {class: "tg-hint", text: "Sonlar shu qurilmaga yuklangan xabarlar bo'yicha (xabarlar shifrlangan, server sanay olmaydi). \"+\" — tepada yana eski xabarlar bor."}));
    let ub = null;
    if (o.users) { ub = usersBlock(); wrap.append(gapEl(), ub.el); }
    if (o.foot && o.foot.length) wrap.append(gapEl(), h("div", {class: "tg-modwrap"}, ...o.foot));
    p.refresh = () => { subEl.textContent = o.sub(); paintMedia(); if (ub) ub.fill(); };
    return wrap;
  }, false);
}
function openGroupInfo() {
  infoPage({
    title: "Guruh ma'lumoti", name: "Umumiy chat", av: () => groupAvatar("l"),
    sub: () => (S.members.length || 1) + " a'zo, " + onlineCount() + " onlayn",
    msgs: () => ({list: S.group.msgs, more: S.group.more}), users: true,
    foot: amAdmin() ? [h("button", {class: "btn danger sm", type: "button", onclick: () => { closeAllPages(); clearGroupChat(); }}, "Chatni tozalash")] : [],
  });
}

/* ---------- profil ---------- */
function openProfile(uid) {
  if (!S.users.has(uid)) loadMembers();
  openPage(() => profileView(uid), true);
}

function mediaStats(uid) {                              // faqat yuklangan xabarlar bo'yicha (E2EE: server ko'ra olmaydi); tarixning davomi bo'lsa "+" qo'yiladi
  const dm = S.dms.get(uid);
  if (!dm || !dm.loaded) return null;
  const st = {img: 0, voice: 0, vnote: 0, file: 0, more: !!dm.more};
  dm.msgs.forEach(m => {
    if (m.deleted) return;
    if (m.image) st.img++;
    else if (m.file) { if (m.file.voice) st.voice++; else if (m.file.vnote) st.vnote++; else st.file++; }
  });
  return st;
}
function tgRow(ic, text) { return h("div", {class: "tg-row"}, icon(ic), h("span", {text})); }
function infoRow(label, value, wide) { return h("div", {class: "info-r" + (wide ? " wide" : "")}, h("small", {text: label}), h("div", {text: value})); }
function profileView(uid) {
  const u = U(uid), me = u.id === S.me.id;
  const wrap = h("div", {});
  if (u.deleted) {
    const bn = h("div", {class: "pbanner gone"});
    bn.append(h("button", {class: "pbtn l", type: "button", onclick: () => closePage(), "aria-label": "Orqaga"}, icon("back")));
    bn.append(h("button", {class: "pbtn r", type: "button", onclick: closeAllPages, "aria-label": "Yopish"}, icon("close")));
    wrap.append(bn, h("div", {class: "pbody"}, avatar(u, "l"),
      h("div", {class: "pname"}, nameEl(u, {big: true})),
      h("div", {class: "pstat", text: "Bu akkaunt o'chirilgan"}),
      h("div", {class: "gone-note", text: "Yozgan xabarlari chatda qoladi. Unga xabar yuborib bo'lmaydi."})));
    return wrap;
  }
  const top = tint(h("div", {class: "tg-top" + (isStaff(u) ? " prem " + u.role : "") + bannerCls(u) + pageCls(u)}), u);
  top.append(h("button", {class: "tg-back", type: "button", onclick: () => closePage(), "aria-label": "Orqaga"}, icon("back")),
    me ? h("button", {class: "tg-edit", type: "button", onclick: openInfoPage, "aria-label": "Profilni tahrirlash"}, icon("edit")) : "",
    zoomAvatar(avatar(u, "l"), u),
    h("div", {class: "pname"}, nameEl(u, {big: true})),
    titleEl(u),
    h("div", {class: "pstat" + (isOnline(u.id) ? " on" : ""), text: statusText(u)}));
  if (isStaff(u)) top.append(tint(h("div", {class: "chip prem " + u.role}, hasEmoji(u) ? badge(u) : (u.badge === "none" ? null : icon(u.role === "owner" ? "shield" : "check", "ic vb")), roleLabel(u.role)), u));
  else if (hasEmoji(u)) top.append(h("div", {class: "chip"}, badge(u), "Maxsus nishon"));
  else if (isVerified(u)) top.append(h("div", {class: "chip"}, badge(u), "Tasdiqlangan foydalanuvchi"));
  if (u.new && !isStaff(u)) top.append(h("div", {class: "chip warn", text: "⚠ Yangi foydalanuvchi — hali ishonish qiyin"}));
  wrap.append(top);

  const acts = h("div", {class: "tg-acts"});
  const act = (ic, label, fn, on) => h("button", {class: "tg-act" + (on ? " on" : ""), type: "button", onclick: fn, "aria-pressed": on == null ? null : String(!!on)}, icon(ic), h("span", {text: label}));
  if (!me) {
    acts.append(act("chat", "Xabar", () => { closeAllPages(); openChat({kind: "dm", uid: u.id}); }));
    const muted = isMuted(u.id);
    acts.append(act(muted ? "bell-off" : "bell", muted ? "Ovoz yoq" : "Mute", () => {
      const on = toggleMute(u.id);
      toast(on ? "Bu suhbat ovozi o'chirildi (shu qurilmada)" : "Suhbat ovozi yoqildi", "ok");
      repaintTopPage();
    }, muted));
  }
  if (!me) wrap.append(acts);
  wrap.append(h("div", {class: "tg-gap"}));

  const info = h("div", {class: "tg-info"});
  const copyRow = (val, label, copy) => h("div", {class: "tg-row copy", role: "button", tabindex: "0", title: "Nusxalash",
    onclick: () => copyText(copy), onkeydown: e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); copyText(copy); } }},
    h("div", {class: "tg-val", text: val}), h("div", {class: "tg-lab", text: label}));
  const unRow = copyRow("@" + u.username, "Username", "@" + u.username); fxText(unRow.firstChild, fxOf(u, "user"));
  info.append(unRow);
  if (u.bio) info.append(h("div", {class: "tg-row copy"}, fxText(h("div", {class: "tg-bio"}, Rich.inline(u.bio, LINKCTX)), fxOf(u, "bio")), h("div", {class: "tg-lab", text: "Bio"})));
  if (u.joined) { const d = new Date(u.joined * 1000); info.append(h("div", {class: "tg-row copy"}, h("div", {text: d.getDate() + "-" + MONTHS[d.getMonth()] + " " + d.getFullYear()}), h("div", {class: "tg-lab", text: "Qo'shilgan"}))); }
  wrap.append(info);

  const st = me ? null : mediaStats(u.id);
  if (st && (st.img || st.voice || st.vnote || st.file)) {
    const plus = st.more ? "+" : "";
    const rows = h("div", {class: "tg-media"});
    if (st.img) rows.append(tgRow("attach", st.img + plus + " ta rasm"));
    if (st.voice) rows.append(tgRow("mic", st.voice + plus + " ta ovozli xabar"));
    if (st.vnote) rows.append(tgRow("videocam", st.vnote + plus + " ta video xabar"));
    if (st.file) rows.append(tgRow("file", st.file + plus + " ta fayl"));
    wrap.append(h("div", {class: "tg-gap"}), rows);
  }
  if (!me && amAdmin() && u.role !== "owner" && (u.role !== "admin" || S.me.role === "owner")) wrap.append(h("div", {class: "tg-gap"}), h("div", {class: "tg-modwrap"}, modPanel(u)));
  return wrap;
}
function modPanel(u) {
  const cmd = text => wsSend({type: "cmd", text});
  const panel = h("div", {class: "mod"}, h("h4", {}, icon("shield"), "Moderatsiya"));
  const flags = h("div", {class: "mod-r"});
  if (u.banned) flags.append(h("span", {class: "flag", text: "Ban qilingan"}));
  if (u.muted) flags.append(h("span", {class: "flag w", text: "Mute qilingan"}));
  if (u.warns) flags.append(h("span", {class: "warnflag", text: "Ogohlantirish: " + u.warns + "/3"}));
  if (flags.children.length) panel.append(flags);
  const dur = h("select", {}, h("option", {value: "10", text: "10 daqiqa"}), h("option", {value: "60", text: "1 soat"}),
    h("option", {value: "1440", text: "1 kun"}), h("option", {value: "perm", text: "Doimiy"}));
  panel.append(h("div", {class: "mod-r"}, dur,
    h("button", {class: "btn ghost sm", type: "button", onclick: () => cmd("/mute " + u.username + " " + dur.value)}, "Mute"),
    u.muted ? h("button", {class: "btn ghost sm", type: "button", onclick: () => cmd("/unmute " + u.username)}, "Unmute") : null));
  panel.append(h("div", {class: "mod-r"},
    h("button", {class: "btn ghost sm", type: "button", onclick: async () => {
      const why = await promptDlg("Ogohlantirish", "@" + u.username + " ga ogohlantirish (3 tadan keyin 1 soat mute). Sabab:", "", {okText: "Ogohlantirish"});
      if (why !== null) cmd("/warn " + u.username + " " + why);
    }}, "Ogohlantirish"),
    u.warns ? h("button", {class: "btn ghost sm", type: "button", onclick: () => cmd("/unwarn " + u.username)}, "Olib tashlash") : null,
    h("button", {class: "btn ghost sm", type: "button", onclick: async () => {
      if (await confirmDlg("@" + u.username + " ning umumiy chatdagi oxirgi xabarlari (va fayllari) o'chiriladi.", {title: "Xabarlarini tozalash", okText: "Tozalash", danger: true})) cmd("/purge " + u.username);
    }}, "Xabarlarini tozalash"),
    h("button", {class: "btn ghost sm", type: "button", onclick: () => openBadgePicker(u)}, "Nishon / galochka"),
    h("button", {class: "btn ghost sm", type: "button", onclick: () => openProfileEditor(u.id)}, "Dizayn berish")));
  panel.append(h("div", {class: "mod-r"},
    u.banned
      ? h("button", {class: "btn ghost sm", type: "button", onclick: () => cmd("/unban " + u.username)}, "Bandan chiqarish")
      : h("button", {class: "btn danger sm", type: "button", onclick: async () => { if (await confirmDlg("@" + u.username + " ni ban qilasizmi?", {title: "Ban qilish", okText: "Ban qilish", danger: true})) cmd("/ban " + u.username); }}, "Ban qilish")));
  if (S.me.role === "owner") {
    panel.append(h("div", {class: "mod-r"}, u.role === "admin"
      ? h("button", {class: "btn ghost sm", type: "button", onclick: async () => { if (await confirmDlg("@" + u.username + " adminlikdan olinsinmi?", {title: "Adminlikdan olish", okText: "Olish", danger: true})) cmd("/rmadmin " + u.username); }}, "Adminlikdan olish")
      : h("button", {class: "btn ghost sm", type: "button", onclick: async () => { if (await confirmDlg("@" + u.username + " admin qilinsinmi?", {title: "Admin qilish", okText: "Admin qilish"})) cmd("/addadmin " + u.username); }}, "Admin qilish")));
  }
  const rows = panel.querySelectorAll(".mod-r");
  if (S.me.role === "owner" && rows.length >= 2) { const last = rows[rows.length - 1], prev = rows[rows.length - 2]; [...last.children].forEach(c => prev.append(c)); last.remove(); }
  panel.append(h("div", {class: "mod-r"}, h("button", {class: "btn danger sm", type: "button", onclick: async () => {
    if (await confirmDlg("@" + u.username + " akkaunti o'chiriladi va chatdan chiqarib tashlanadi. Yozgan xabarlari \"Deleted account\" nomi bilan qoladi. Buni qaytarib bo'lmaydi.",
      {title: "Akkauntni o'chirish", okText: "O'chirish", danger: true})) { cmd("/remove " + u.username); closePage(); }
  }}, "Akkauntni o'chirish")));
  return panel;
}



/* ---------- foydalanuvchilar zaxirasi (faqat ega): shifrlash/ochish brauzerda, js/backup.js ---------- */
function ago(ts) {
  if (!ts) return "?";
  const s = Math.max(0, Date.now() / 1000 - ts);
  if (s < 60) return "hozirgina";
  const m = s / 60; if (m < 60) return Math.floor(m) + " daqiqa oldin";
  const hr = m / 60; if (hr < 24) return Math.floor(hr) + " soat oldin";
  const d = hr / 24; if (d < 30) return Math.floor(d) + " kun oldin";
  if (d < 365) return Math.floor(d / 30) + " oy oldin";
  return Math.floor(d / 365) + " yil oldin";
}
async function backupDownload() {
  const p1 = await promptDlg("Zaxira paroli", "Zaxira faylini shifrlash uchun parol-ibora kiriting (kamida 8 belgi). Uni yo'qotsangiz, fayl ochilmaydi va tiklab bo'lmaydi.", "", {type: "password", okText: "Davom etish"});
  if (p1 === null) return;
  if (p1.length < 8) { toast("Parol-ibora kamida 8 belgi bo'lishi kerak", "error"); return; }
  const p2 = await promptDlg("Parol-iborani takrorlang", "Xato yozilmaganini tekshirish uchun yana kiriting:", "", {type: "password", okText: "Yuklab olish"});
  if (p2 === null) return;
  if (p1 !== p2) { toast("Parol-iboralar mos kelmadi", "error"); return; }
  toast("Shifrlanmoqda…");
  try {
    const data = await api("/admin/backup");
    const bytes = await Backup.seal(data, p1), d = new Date();
    const name = "anonim-chat-users-" + d.getFullYear() + pad2(d.getMonth() + 1) + pad2(d.getDate()) + ".acdb";
    const url = URL.createObjectURL(new Blob([bytes], {type: "application/octet-stream"}));
    const a = h("a", {href: url, download: name}); document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
    toast(data.users.length + " ta akkaunt shifrlangan zaxiraga yozildi" + (data.avatars_skipped ? " (" + data.avatars_skipped + " ta katta rasm kiritilmadi)" : ""), "ok");
  } catch (err) { toast(err.message, "error"); }
}
function backupRestore(done) {
  const f = h("input", {type: "file", accept: ".acdb", class: "offscreen"});
  f.addEventListener("cancel", () => f.remove());
  f.addEventListener("change", async () => {
    const file = f.files[0]; f.remove();
    if (!file) return;
    try {
      if (file.size > 40 * 1048576) throw new Error("Fayl juda katta");
      const bytes = new Uint8Array(await file.arrayBuffer());
      const pass = await promptDlg("Zaxira paroli", "Zaxirani ochish uchun parol-iborani kiriting:", "", {type: "password", okText: "Ochish"});
      if (pass === null) return;
      toast("Ochilmoqda…");
      const data = await Backup.open(bytes, pass);
      const list = Array.isArray(data.users) ? data.users : [], adm = list.filter(u => u && u.role === "admin").length;
      if (!await confirmDlg(list.length + " ta akkaunt topildi (" + adm + " ta admin). Mavjud username'larga tegilmaydi — faqat yo'qlari tiklanadi. Xabarlar tiklanmaydi. Davom etilsinmi?", {title: "Zaxiradan tiklash", okText: "Tiklash"})) return;
      const j = await api("/admin/backup/restore", {method: "POST", body: {data}});
      toast(j.created + " ta akkaunt tiklandi" + (j.skipped ? ", " + j.skipped + " tasi allaqachon bor" : "") + (j.invalid ? ", " + j.invalid + " tasi yaroqsiz" : ""), j.created ? "ok" : "warn");
      loadMembers(); if (done) done();
    } catch (err) { toast(err.message, "error"); }
  });
  document.body.append(f); f.click();
}

/* ---------- admin paneli: IP lar, harakatlar logi, bloklar ---------- */
const fmtDT = ts => { const d = new Date(ts * 1000); return pad2(d.getDate()) + "." + pad2(d.getMonth() + 1) + "." + String(d.getFullYear()).slice(2) + " " + hhmm(ts) + ":" + pad2(d.getSeconds()); };
function admErr(box, err) { box.textContent = ""; box.append(h("div", {class: "adm-empty", text: err.message})); }

function openAdmin(initial, preset) {
  preset = preset || {};
  const top = PG.list[PG.list.length - 1];
  if (top && top.adm === initial && !Object.keys(preset).length) { paintPage(top); return; }   // shu bo'lim ochiq bo'lsa — joyida yangilanadi
  const pg = openPage(() => {
    const st = {tab: initial, q: preset.q || "", ip: preset.ip || "", user: preset.user || "", action: ""};
    const body = h("div", {class: "adm-body"});
    const loaders = {ips: loadIps, users: loadUsers, log: loadLog, msgs: loadMsgs, blocks: loadBlocks, media: loadMedia, reports: loadReports, mod: loadMod, emoji: () => emojiManager(body, () => st.tab === "emoji")};
    const load = () => { body.textContent = ""; loaders[st.tab](); };

    /* --- Foydalanuvchilar: ro'yxat, nishon (emoji/galochka) va shifrlangan zaxira --- */
    function loadUsers() {
      const owner = S.me.role === "owner";
      const filter = h("input", {type: "text", class: "fld", placeholder: "Nickname yoki @username bo'yicha qidirish", autocomplete: "off"});
      const list = h("div", {}), box = h("div", {class: "bk-box"});
      let all = [];
      const roleName = r => r === "owner" ? "Ega" : r === "admin" ? "Admin" : "Oddiy";
      const paint = () => {
        const q = filter.value.trim().toLowerCase().replace(/^@/, "");
        list.textContent = "";
        const rows = all.filter(u => !q || u.nickname.toLowerCase().includes(q) || u.username.toLowerCase().includes(q));
        if (!rows.length) list.append(h("div", {class: "adm-empty", text: "Hech narsa topilmadi"}));
        rows.forEach(u => {
          const can = u.role !== "owner" && (u.role !== "admin" || owner);
          list.append(h("div", {class: "urow"}, avatar(u, "m", true),
            h("div", {class: "utx"}, nameEl(u),
              h("div", {class: "usub"}, h("span", {class: "ubadge " + u.role, text: roleName(u.role)}), "@" + u.username + " • " + ago(u.joined) + " qo'shilgan" + (u.banned ? " • ban" : ""))),
            can ? h("div", {class: "urow-act"},
              h("button", {class: "btn ghost sm", type: "button", text: "Dizayn", onclick: () => openProfileEditor(u.id)}),
              h("button", {class: "btn ghost sm", type: "button", text: "Nishon", onclick: () => openBadgePicker(u, () => openAdmin("users"))})) : h("span")));
        });
      };
      const fill = async () => {
        list.textContent = ""; list.append(h("div", {class: "adm-empty", text: "Yuklanmoqda…"}));
        try { const j = await api("/members"); j.members.forEach(upsertUser); all = j.members.map(x => U(x.id)); box.querySelector(".bk-n") && (box.querySelector(".bk-n").textContent = all.length + " ta akkaunt"); paint(); }
        catch (err) { admErr(list, err); }
      };
      if (owner) box.append(h("div", {}, h("b", {text: "Shifrlangan zaxira (.acdb). "}), "Username, nickname, rol, profil rasmi, qo'shilgan vaqt va kirish ma'lumoti sizning parol-iborangiz bilan BRAUZERDA shifrlanadi; parol-ibora serverga yuborilmaydi. Uni yo'qotsangiz fayl ochilmaydi. Xabarlar zaxiraga kirmaydi. ", h("span", {class: "bk-n"})),
        h("div", {class: "ep-row"}, h("button", {class: "btn sm", type: "button", text: "⬇ Bazani yuklab olish", onclick: backupDownload}),
          h("button", {class: "btn ghost sm", type: "button", text: "⬆ Zaxiradan tiklash", onclick: () => backupRestore(fill)})));
      else box.append("Bazani yuklab olish va zaxiradan tiklash faqat platforma egasiga ochiq: zaxira faylida kirish ma'lumotlari bor, ularni oddiy adminga berish E2EE'ni buzardi. Siz foydalanuvchilarga nishon/galochka bera olasiz.");
      filter.addEventListener("input", paint);
      body.append(box, h("div", {class: "adm-filters"}, filter), list);
      fill();
    }

    /* --- IP lar: har bir IP dan qaysi profil necha marta kirgan --- */
    function loadIps() {
      const filter = h("input", {type: "text", class: "fld", placeholder: "IP yoki @username bo'yicha qidirish", autocomplete: "off"});
      filter.value = st.q;
      const list = h("div", {});
      let timer = null;
      const fill = async () => {
        list.textContent = ""; list.append(h("div", {class: "adm-empty", text: "Yuklanmoqda…"}));
        try {
          const j = await api("/admin/ips?q=" + encodeURIComponent(st.q));
          list.textContent = "";
          if (!j.ips.length) list.append(h("div", {class: "adm-empty", text: "Hech narsa topilmadi"}));
          j.ips.forEach(e => list.append(ipCard(e, fill)));
        } catch (err) { admErr(list, err); }
      };
      filter.addEventListener("input", () => { clearTimeout(timer); timer = setTimeout(() => { st.q = filter.value.trim(); fill(); }, 300); });
      body.append(h("div", {class: "adm-filters"}, filter), list);
      fill();
    }
    function ipCard(e, refresh) {
      const head = h("div", {class: "ipc-h"}, h("span", {class: "ip", text: e.ip}), e.blocked ? h("span", {class: "flag b", text: "Bloklangan"}) : null);
      const sum = h("div", {class: "ipc-s", text: e.profiles.length + " ta profil • " + e.logins + " kirish • " + e.sessions + " sessiya • " + e.msgs + " xabar" +
        (e.failed ? " • " + e.failed + " xato urinish" : "") + " • oxirgi: " + fmtDT(e.last_seen)});
      const card = h("div", {class: "ipc" + (e.blocked ? " blk" : "")}, head, sum);
      e.profiles.forEach(p => card.append(h("div", {class: "ipc-p"},
        h("div", {class: "who"}, h("b", {text: "@" + p.username}), p.nickname ? " (" + p.nickname + ")" : "", p.known ? "" : " — ro'yxatdan o'tmagan nom"),
        h("div", {class: "num", text: p.logins + " kirish • " + p.sessions + " sessiya • " + p.msgs + " xabar" + (p.failed ? " • " + p.failed + " xato" : "")}))));
      const acts = h("div", {class: "ipc-a"}, h("button", {class: "btn ghost sm", type: "button", text: "Loglari", onclick: () => openAdmin("log", {ip: e.ip})}));
      if (e.blocked) acts.append(h("button", {class: "btn ghost sm", type: "button", text: "Blokdan ochish", onclick: async () => {
        if (!await confirmDlg(e.ip + " blokdan ochilsinmi?", {title: "Blokdan ochish", okText: "Ochish"})) return;
        try { await api("/admin/unblock", {method: "POST", body: {ip: e.ip}}); toast("Blokdan ochildi", "ok"); refresh(); } catch (err) { toast(err.message, "error"); }
      }}));
      else acts.append(h("button", {class: "btn danger sm", type: "button", text: "Bloklash", onclick: async () => {
        const reason = await promptDlg("IP bloklash", e.ip + " bloklanadi. Sabab (ixtiyoriy):", "spam", {okText: "Bloklash"});
        if (reason === null) return;
        try { const j = await api("/admin/blocks", {method: "POST", body: {ip: e.ip, reason}}); toast("Bloklandi" + (j.kicked ? " (" + j.kicked + " ta ulanish uzildi)" : ""), "ok"); refresh(); }
        catch (err) { toast(err.message, "error"); }
      }}));
      card.append(acts);
      return card;
    }

    /* --- Harakatlar logi: filtrlar bilan --- */
    function loadLog() {
      const ipI = h("input", {type: "text", class: "fld", placeholder: "IP", autocomplete: "off"}); ipI.value = st.ip;
      const userI = h("input", {type: "text", class: "fld", placeholder: "@username", autocomplete: "off"}); userI.value = st.user;
      const sel = h("select", {}, h("option", {value: "", text: "Barcha amallar"}));
      const list = h("div", {}), more = h("button", {class: "btn ghost sm adm-more hidden", type: "button", text: "Yana yuklash"});
      let before = 0, filled = false, timer = null;
      const picked = new Set();
      const delSel = h("button", {class: "btn danger sm", type: "button", text: "Tanlanganlarni o'chirish"});
      const delAll = h("button", {class: "btn ghost sm dangerline", type: "button", text: "Filtrdagi hammasini o'chirish"});
      const updDel = () => { delSel.disabled = !picked.size; delSel.textContent = picked.size ? "Tanlanganlarni o'chirish (" + picked.size + ")" : "Tanlanganlarni o'chirish"; };
      delSel.addEventListener("click", async () => {
        if (!await confirmDlg(picked.size + " ta log yozuvi butunlay o'chiriladi.", {title: "Loglarni o'chirish", okText: "O'chirish", danger: true})) return;
        try { const j = await api("/admin/activity/delete", {method: "POST", body: {ids: [...picked]}}); toast(j.deleted + " ta yozuv o'chirildi", "ok"); picked.clear(); updDel(); page(true); }
        catch (err) { toast(err.message, "error"); }
      });
      delAll.addEventListener("click", async () => {
        const f = ipI.value.trim() || userI.value.trim() || sel.value;
        if (!await confirmDlg(f ? "Joriy filtrga mos BARCHA yozuvlar o'chiriladi." : "Harakatlar logining BUTUN tarixi o'chiriladi.", {title: "Loglarni o'chirish", okText: "Hammasini o'chirish", danger: true})) return;
        try { const j = await api("/admin/activity/delete", {method: "POST", body: {all: true, ip: ipI.value.trim(), user: userI.value.trim(), action: sel.value}}); toast(j.deleted + " ta yozuv o'chirildi", "ok"); picked.clear(); updDel(); page(true); }
        catch (err) { toast(err.message, "error"); }
      });
      const row = it => {
        const bad = ["login_failed", "blocked", "ip_block"].includes(it.action);
        const ipl = it.ip ? h("span", {class: "ipl", text: it.ip, onclick: () => { ipI.value = it.ip; page(true); }}) : null;
        const ck = h("input", {type: "checkbox", class: "ck", "aria-label": "Tanlash"});
        ck.addEventListener("change", () => { if (ck.checked) picked.add(it.id); else picked.delete(it.id); updDel(); });
        return h("div", {class: "lg sel"}, ck, h("div", {class: "t", text: fmtDT(it.ts)},),
          h("div", {class: "w"}, h("span", {class: "a" + (bad ? " bad" : ""), text: it.label}), it.username ? "@" + it.username + " " : "", ipl),
          it.detail ? h("div", {class: "d", text: it.detail}) : null);
      };
      const page = async reset => {
        if (reset) { before = 0; list.textContent = ""; picked.clear(); updDel(); }
        const qs = new URLSearchParams({ip: ipI.value.trim(), user: userI.value.trim(), action: sel.value, limit: "100"});
        if (before) qs.set("before", before);
        try {
          const j = await api("/admin/activity?" + qs.toString());
          if (!filled) { j.actions.forEach(a => sel.append(h("option", {value: a.key, text: a.label}))); filled = true; }
          j.items.forEach(it => list.append(row(it)));
          if (j.items.length) before = j.items[j.items.length - 1].id;
          more.classList.toggle("hidden", j.items.length < 100);
          if (reset && !j.items.length) list.append(h("div", {class: "adm-empty", text: "Yozuv topilmadi"}));
        } catch (err) { admErr(list, err); }
      };
      const again = () => { clearTimeout(timer); timer = setTimeout(() => page(true), 300); };
      ipI.addEventListener("input", again); userI.addEventListener("input", again); sel.addEventListener("change", () => page(true));
      more.addEventListener("click", () => page(false));
      body.append(h("div", {class: "adm-filters"}, ipI, userI, sel), h("div", {class: "adm-bar"}, delSel, delAll), list, more);
      updDel(); page(true);
    }

    /* --- Bloklangan IP lar --- */
    function loadBlocks() {
      const ipI = h("input", {type: "text", class: "fld", placeholder: "Bloklash uchun IP (masalan 203.0.113.5)", autocomplete: "off"});
      const reasonI = h("input", {type: "text", class: "fld", placeholder: "Sabab (ixtiyoriy)", autocomplete: "off"});
      const list = h("div", {});
      const fill = async () => {
        list.textContent = "";
        try {
          const j = await api("/admin/blocks");
          if (!j.blocks.length) list.append(h("div", {class: "adm-empty", text: "Bloklangan IP yo'q"}));
          j.blocks.forEach(b => list.append(h("div", {class: "ipc blk"},
            h("div", {class: "ipc-h"}, h("span", {class: "ip", text: b.ip})),
            h("div", {class: "ipc-s", text: (b.reason ? b.reason + " • " : "") + "@" + b.by + " • " + fmtDT(b.ts)}),
            h("div", {class: "ipc-a"}, h("button", {class: "btn ghost sm", type: "button", text: "Blokdan ochish", onclick: async () => {
              try { await api("/admin/unblock", {method: "POST", body: {ip: b.ip}}); toast("Blokdan ochildi", "ok"); fill(); } catch (err) { toast(err.message, "error"); }
            }}),
            h("button", {class: "btn ghost sm", type: "button", text: "Loglari", onclick: () => openAdmin("log", {ip: b.ip})})))));
        } catch (err) { admErr(list, err); }
      };
      const add = h("button", {class: "btn danger sm", type: "button", text: "Bloklash", onclick: async () => {
        if (!ipI.value.trim()) return;
        try { await api("/admin/blocks", {method: "POST", body: {ip: ipI.value.trim(), reason: reasonI.value}}); ipI.value = ""; reasonI.value = ""; toast("Bloklandi", "ok"); fill(); }
        catch (err) { toast(err.message, "error"); }
      }});
      body.append(h("div", {class: "adm-filters"}, ipI, reasonI, add), list);
      fill();
    }

    /* --- Xabarlar logi: bazada shifrlangan, serverda ochilgan (o'chirilgan/tahrirlanganlar ham) --- */
    function loadMsgs() {
      const qI = h("input", {type: "text", class: "fld", placeholder: "@username bo'yicha qidirish", autocomplete: "off"});
      const sel = h("select", {}, h("option", {value: "", text: "Barcha xabarlar"}), h("option", {value: "deleted", text: "Faqat o'chirilganlar"}), h("option", {value: "edited", text: "Faqat tahrirlanganlar"}));
      const list = h("div", {}), more = h("button", {class: "btn ghost sm adm-more hidden", type: "button", text: "Yana yuklash"});
      let next = 0, timer = null;
      const row = it => {
        const cipher = h("div", {class: "mcipher", text: it.cipher || "(shifr yo'q)"});
        const metaTxt = it.meta ? (it.meta.kind + " • epoch " + it.meta.epoch + " • shifr " + it.meta.cipher_bytes + " bayt • imzo " + it.meta.sig_bytes + " bayt")
          : (it.legacy ? "eski xabar (E2EE'dan oldin)" : "");
        const lock = h("div", {class: "mmeta", text: "🔒 " + metaTxt});
        const flags = h("span", {class: "mflags"},
          it.deleted ? h("span", {class: "flag b", text: "O'chirilgan"}) : null,
          it.edited ? h("span", {class: "flag w", text: "Tahrirlangan"}) : null,
          it.file ? h("span", {class: "flag", text: "Fayl " + fmtSize(it.file_bytes) + " (shifrlangan)"}) : null,
          it.legacy ? h("span", {class: "flag w", text: "Eski"}) : null);
        const card = h("div", {class: "lg mlg" + (it.deleted ? " gone" : "")},
          h("div", {class: "t", text: fmtDT(it.ts) + " • #" + it.id}),
          h("div", {class: "w"}, h("span", {class: "a", text: "@" + it.username}), it.nickname ? " (" + it.nickname + ") " : " ", flags),
          cipher, lock);
        it.history.forEach(hh => card.append(h("div", {class: "mhist"},
          h("b", {text: (hh.type === "edit" ? "Tahrir" : hh.type === "delete" ? "O'chirish" : hh.type) + " • " + fmtDT(hh.ts) + (hh.by ? " • @" + hh.by : "")}),
          hh.type === "edit" ? h("div", {class: "mcipher", text: hh.old + "\n→\n" + hh.new}) : h("div", {class: "mcipher", text: hh.old}))));
        return card;
      };
      const page = async reset => {
        if (reset) { next = 0; list.textContent = ""; }
        const qs = new URLSearchParams({q: qI.value.trim(), state: sel.value, limit: "50"});
        if (next) qs.set("before", next);
        try {
          const j = await api("/admin/messages?" + qs.toString());
          j.items.forEach(it => list.append(row(it)));
          next = j.next; more.classList.toggle("hidden", !next);
          if (reset && !j.items.length) list.append(h("div", {class: "adm-empty", text: "Xabar topilmadi"}));
        } catch (err) { admErr(list, err); }
      };
      qI.addEventListener("input", () => { clearTimeout(timer); timer = setTimeout(() => page(true), 300); });
      sel.addEventListener("change", () => page(true)); more.addEventListener("click", () => page(false));
      body.append(h("div", {class: "adm-note", text: "Uchdan-uchga shifrlash (E2EE): server ham, admin ham xabar matnini o'qiy olmaydi — bu yerda faqat shifrlangan konvertlar ko'rinadi. Matnni faqat chat a'zolarining qurilmalari ochadi. Lichka xabarlar bu yerda ko'rinmaydi."}),
        h("div", {class: "adm-filters"}, qI, sel),
        h("div", {class: "adm-bar"}, h("button", {class: "btn ghost sm dangerline", type: "button", text: "Tarixni tozalash", onclick: async () => {
          if (!await confirmDlg("O'chirilgan umumiy chat xabarlari bazadan butunlay o'chadi va tahrir/moderatsiya tarixi tozalanadi.", {title: "Xabarlar tarixini tozalash", okText: "Tozalash", danger: true})) return;
          try { const j = await api("/admin/messages/clean", {method: "POST"}); toast(j.messages + " ta xabar, " + j.history + " ta tarix tozalandi", "ok"); page(true); }
          catch (err) { toast(err.message, "error"); }
        }})), list, more);
      page(true);
    }


    /* --- Media boshqaruvi: fayl nomi/mazmuni ko'rinmaydi, faqat tur/hajm/vaqt/yuboruvchi --- */
    function loadMedia() {
      const KL = {image: "Rasm", video: "Video", audio: "Audio", other: "Fayl"};
      const kind = h("select", {}, ...[["", "Barcha turlar"], ["image", "Rasmlar"], ["video", "Videolar"], ["audio", "Audio"], ["other", "Boshqa fayllar"]].map(([v, t]) => h("option", {value: v, text: t})));
      const size = h("select", {}, ...[["0", "Har qanday hajm"], ["1", "1 MB dan katta"], ["5", "5 MB dan katta"], ["20", "20 MB dan katta"]].map(([v, t]) => h("option", {value: v, text: t})));
      const who = h("input", {type: "text", class: "fld", placeholder: "@username", autocomplete: "off"});
      const info = h("div", {class: "mm-total"}), list = h("div", {}), more = h("button", {class: "btn ghost sm adm-more hidden", type: "button", text: "Yana yuklash"});
      const del = h("button", {class: "btn danger sm", type: "button", text: "Tanlanganlarni o'chirish", disabled: true});
      const all = h("button", {class: "btn ghost sm", type: "button", text: "Ko'ringanlarni belgilash"});
      const picked = new Set(), boxes = [];
      let next = 0, timer = null;
      const upd = () => { del.disabled = !picked.size; del.textContent = picked.size ? "O'chirish (" + picked.size + ")" : "Tanlanganlarni o'chirish"; };
      const row = it => {
        const ck = h("input", {type: "checkbox", class: "ck", "aria-label": "Tanlash"});
        const r = h("div", {class: "mrow"}, ck, h("div", {}, h("span", {class: "mk", text: it.kind === "e2e" ? "🔒 Shifrlangan" : (KL[it.kind] || "Fayl")}), "@" + it.username, h("div", {class: "ms", text: fmtDT(it.ts)})), h("span", {class: "sz", text: fmtSize(it.size)}));
        ck.addEventListener("change", () => { if (ck.checked) picked.add(it.id); else picked.delete(it.id); r.classList.toggle("on", ck.checked); upd(); });
        boxes.push([ck, it.id, r]); return r;
      };
      const page = async reset => {
        if (reset) { next = 0; list.textContent = ""; picked.clear(); boxes.length = 0; upd(); }
        const qs = new URLSearchParams({kind: kind.value, sender: who.value.trim(), min_mb: size.value, limit: "50"});
        if (next) qs.set("before", next);
        try {
          const j = await api("/admin/media?" + qs.toString());
          info.textContent = "Umumiy chatdagi media: " + j.totals.count + " ta, jami " + fmtSize(j.totals.size);
          j.items.forEach(it => list.append(row(it)));
          next = j.next; more.classList.toggle("hidden", !next);
          if (reset && !j.items.length) list.append(h("div", {class: "adm-empty", text: "Media topilmadi"}));
        } catch (err) { admErr(list, err); }
      };
      all.addEventListener("click", () => { boxes.forEach(([ck, id, r]) => { ck.checked = true; picked.add(id); r.classList.add("on"); }); upd(); });
      del.addEventListener("click", async () => {
        if (!picked.size) return;
        if (!await confirmDlg(picked.size + " ta media chatdan va serverdan butunlay o'chiriladi. Izohi bor xabarlarning matni qoladi.", {title: "Media o'chirish", okText: "O'chirish", danger: true})) return;
        try { const j = await api("/admin/media/delete", {method: "POST", body: {ids: [...picked]}}); toast(j.deleted + " ta media o'chirildi", "ok"); page(true); }
        catch (err) { toast(err.message, "error"); }
      });
      const again = () => { clearTimeout(timer); timer = setTimeout(() => page(true), 300); };
      kind.addEventListener("change", () => page(true)); size.addEventListener("change", () => page(true)); who.addEventListener("input", again);
      more.addEventListener("click", () => page(false));
      body.append(h("p", {class: "mm-note", text: "Fayllar diskda shifrlangan. Bu yerda fayl nomi va mazmuni ko'rsatilmaydi (adminga ham), lichka fayllari kirmaydi. Loglarga faqat o'chirilgan SON yoziladi."}),
        info, h("div", {class: "adm-filters"}, kind, size, who), h("div", {class: "adm-bar"}, all, del), list, more);
      page(true);
    }

    /* --- Shikoyatlar --- */
    function loadReports() {
      const status = h("select", {}, h("option", {value: "open", text: "Ochiq shikoyatlar"}), h("option", {value: "closed", text: "Ko'rib chiqilganlar"}));
      const list = h("div", {}), more = h("button", {class: "btn ghost sm adm-more hidden", type: "button", text: "Yana yuklash"});
      let next = 0;
      const close = async (it, action) => {
        try { await api("/admin/reports/close", {method: "POST", body: {id: it.id, action}}); page(true); }
        catch (err) { toast(err.message, "error"); }
      };
      const card = it => {
        const c = h("div", {class: "rcard" + (it.status === "closed" ? " closed" : "")},
          h("div", {class: "rh"}, h("span", {text: fmtDT(it.ts) + " • #" + it.message_id}), h("span", {text: "@" + it.reporter + " → @" + it.target}),
            it.status === "closed" ? h("span", {class: "flag w", text: (it.action || "Yopilgan") + (it.by ? " (@" + it.by + ")" : "")}) : null),
          h("div", {class: "rt", text: it.text || (it.disclosed ? "(shikoyatchi matnni ochib bermadi)" : "(matnsiz)")}),
          it.reason ? h("div", {class: "rr", text: "Sabab: " + it.reason}) : null);
        if (it.disclosed) {                                   // E2EE: shikoyatchi bergan matn asl shifrlangan xabarga mosligini O'Z qurilmamizda tekshiramiz
          const v = h("div", {class: "rv", text: "🔒 Xabar shifrlangan; matn — shikoyatchi ixtiyoriy ochib bergani. Tekshirilmoqda…"});
          c.append(v);
          (async () => {
            try {
              const env = E2E.parseEnvelope(it.cipher), key = env.k === "g" ? X.rooms.get(env.ep) : null;
              if (!key) { v.textContent = "🔒 Tekshirib bo'lmadi: bu xabar kaliti sizda yo'q (matn tasdiqlanmagan)."; return; }
              const senderPeer = await peer(it.target_id);
              const r = await E2E.openMessage(it.cipher, {sender: it.target_id, peer: null, key, signKey: senderPeer.sign});
              const ok = r.verified && typeof r.payload.t === "string" && r.payload.t === it.text;
              v.textContent = ok ? "✅ Matn asl shifrlangan xabarga mos (imzo tasdiqlandi)." : "⚠ Ochib berilgan matn asl xabarga MOS EMAS — soxta shikoyat bo'lishi mumkin!";
              v.classList.add(ok ? "ok" : "bad");
            } catch (_) { v.textContent = "⚠ Tekshirib bo'lmadi (shifrni ochishda xato)."; v.classList.add("bad"); }
          })();
        }
        if (it.status === "open") {
          const a = h("div", {class: "ra"});
          if (it.alive) a.append(h("button", {class: "btn danger sm", type: "button", text: "Xabarni o'chirish", onclick: () => close(it, "delete")}));
          a.append(h("button", {class: "btn ghost sm", type: "button", text: "Mute 10 daq", onclick: () => { if (wsSend({type: "cmd", text: "/mute " + it.target + " 10 shikoyat"})) close(it, "done"); }}),
            h("button", {class: "btn ghost sm", type: "button", text: "Ogohlantirish", onclick: () => { if (wsSend({type: "cmd", text: "/warn " + it.target + " shikoyat"})) close(it, "done"); }}),
            h("button", {class: "btn ghost sm", type: "button", text: "Rad etish", onclick: () => close(it, "dismiss")}));
          c.append(a);
        }
        return c;
      };
      const page = async reset => {
        if (reset) { next = 0; list.textContent = ""; }
        const qs = new URLSearchParams({status: status.value, limit: "30"}); if (next) qs.set("before", next);
        try {
          const j = await api("/admin/reports?" + qs.toString());
          j.items.forEach(it => list.append(card(it)));
          next = j.next; more.classList.toggle("hidden", !next);
          if (reset && !j.items.length) list.append(h("div", {class: "adm-empty", text: status.value === "open" ? "Ochiq shikoyat yo'q 🎉" : "Hech narsa yo'q"}));
        } catch (err) { admErr(list, err); }
      };
      status.addEventListener("change", () => page(true)); more.addEventListener("click", () => page(false));
      body.append(h("div", {class: "adm-filters"}, status), list, more); page(true);
    }

    /* --- Moderatsiya sozlamalari: sekin rejim, qulf --- */
    async function loadMod() {
      let cfg;
      try { cfg = await api("/admin/modsettings"); } catch (err) { admErr(body, err); return; }
      const save = async patch => {
        try { cfg = await api("/admin/modsettings", {method: "POST", body: patch}); toast("Saqlandi", "ok"); }
        catch (err) { toast(err.message, "error"); }
      };
      const slow = h("select", {}, ...[[0, "O'chiq"], [5, "5 soniya"], [10, "10 soniya"], [30, "30 soniya"], [60, "1 daqiqa"], [300, "5 daqiqa"]].map(([v, t]) => h("option", {value: String(v), text: t})));
      if (![0, 5, 10, 30, 60, 300].includes(cfg.slowmode)) slow.append(h("option", {value: String(cfg.slowmode), text: cfg.slowmode + " soniya"}));
      slow.value = String(cfg.slowmode);
      const lock = h("input", {type: "checkbox"}); lock.checked = cfg.locked;
      lock.addEventListener("change", () => save({locked: lock.checked}));
      const e2eSection = () => {
        const box = h("div", {class: "msec"}, h("h4", {text: "🔐 Uchdan-uchga shifrlash (E2EE)"}));
        const info = h("p", {text: "Yuklanmoqda…"}); box.append(info);
        api("/admin/e2ee").then(st => {
          info.textContent = "Guruh kaliti avlodi: " + st.epoch + " • kalitli foydalanuvchilar: " + st.keyed_users + " • server o'qiy oladigan eski xabarlar: " + st.legacy_messages +
            ". Ban qilinganda kalit avtomatik yangilanadi, qo'lda ham yangilash mumkin.";
          box.append(h("div", {class: "ep-row"}, h("button", {class: "btn sm", type: "button", text: "Guruh kalitini yangilash", onclick: async () => {
            if (!X.rooms.has(X.epoch)) { toast("Sizda joriy guruh kaliti yo'q", "error"); return; }
            await rotateRoom("manual"); load();
          }})));
          if (S.me.role === "owner" && st.legacy_messages) box.append(h("div", {class: "ep-row"}, h("button", {class: "btn danger sm", type: "button", text: "Eski xabarlarni o'chirish (" + st.legacy_messages + ")", onclick: async () => {
            if (!await confirmDlg("Server o'qiy oladigan barcha eski xabarlar va ularning fayllari butunlay o'chadi. Qaytarib bo'lmaydi. Yangi (E2EE) xabarlarga tegilmaydi.", {title: "Eski xabarlarni o'chirish", okText: "O'chirish", danger: true})) return;
            try { const j = await api("/admin/e2ee/purge-legacy", {method: "POST"}); toast(j.deleted + " ta eski xabar o'chirildi", "ok"); load(); } catch (err) { toast(err.message, "error"); }
          }})));
        }).catch(err => { info.textContent = err.message; });
        return box;
      };
      body.append(
        h("div", {class: "msec"}, h("h4", {text: "🐢 Sekin rejim"}), h("p", {text: "Oddiy foydalanuvchilar umumiy chatga shuncha vaqtda bir marta yoza oladi. Adminlarga va lichkaga qo'llanmaydi."}),
          h("div", {class: "ep-row"}, slow, h("button", {class: "btn sm", type: "button", text: "Saqlash", onclick: () => save({slowmode: Number(slow.value)})}))),
        h("div", {class: "msec"}, h("h4", {text: "🔒 Chatni qulflash"}), h("p", {text: "Qulflanganda umumiy chatga faqat adminlar yoza oladi (lichka ishlayveradi)."}),
          h("label", {class: "tgl"}, h("span", {text: "Umumiy chat qulflangan"}), lock)),
        e2eSection(),
        h("div", {class: "msec"}, h("h4", {text: "🛡️ Avtomatik himoya"}), h("p", {text: "3 ta ogohlantirishdan keyin foydalanuvchi 1 soatga mute qilinadi. Spam (1 daqiqada 3 marta tezlik limitiga urilish) — 5 daqiqa avtomatik mute. Foydalanuvchi profilidagi Moderatsiya panelidan: ogohlantirish, xabarlarini tozalash, mute/ban."})));
    }

    load();
    return h("div", {}, pageHead(ADM_TITLES[initial] || "Admin"), body);
  });
  pg.adm = initial;
}

/* ---------- emoji nishon: tanlash (o'zimga yoki foydalanuvchiga) ---------- */
const BADGE_EMOJIS = "👑 ✅ ⭐ 🌟 💎 🔥 ⚡ 🚀 🛡️ 🏆 🎖️ 💜 ❤️ 💙 💚 🧡 😎 🤩 😈 👻 🦄 🐉 🦁 🐺 🦅 🌈 🌙 ☀️ ❄️ 🍀 🎯 🎨 🎧 🎮 💫 ✨ 🔱 ⚜️ 🧿 🪐 🍒 🍉 👾 🤖 🥇 📢 🎉 🌹 🦋 🐱 🐼 🍕".split(" ");
const BADGE_ANIMS = [["", "Yo'q"], ["pulse", "Puls"], ["bounce", "Sakrash"], ["spin", "Aylanish"], ["shake", "Silkinish"], ["float", "Suzish"], ["glow", "Nur"], ["flip", "Aylanma"], ["wave", "Silkitish"], ["rainbow", "Kamalak"]];
/* ---- umumiy yordamchilar: gorizontal surish (g'ildirak, sichqoncha bilan tortish) va barmoq bilan chapga/o'ngga surish ---- */
function hScroll(el) {
  el.addEventListener("wheel", e => { if (Math.abs(e.deltaY) > Math.abs(e.deltaX) && el.scrollWidth > el.clientWidth) { el.scrollLeft += e.deltaY; e.preventDefault(); } }, {passive: false});
  let down = false, moved = false, x0 = 0, s0 = 0;
  el.addEventListener("pointerdown", e => { if (e.pointerType !== "mouse") return; down = true; moved = false; x0 = e.clientX; s0 = el.scrollLeft; });
  el.addEventListener("pointermove", e => { if (!down) return; const dx = e.clientX - x0; if (Math.abs(dx) > 4) moved = true; if (moved) el.scrollLeft = s0 - dx; });
  const up = () => { down = false; };
  el.addEventListener("pointerup", up); el.addEventListener("pointerleave", up); el.addEventListener("pointercancel", up);
  el.addEventListener("click", e => { if (moved) { e.stopPropagation(); e.preventDefault(); moved = false; } }, true);
}
function onSwipe(el, fn) {                                 // fn(+1): chapga surildi (keyingisi), fn(-1): o'ngga (oldingisi)
  let x0 = null, y0 = 0;
  el.addEventListener("touchstart", e => { const t = e.touches[0]; x0 = t.clientX; y0 = t.clientY; }, {passive: true});
  el.addEventListener("touchend", e => { if (x0 == null) return; const t = e.changedTouches[0], dx = t.clientX - x0, dy = Math.abs(t.clientY - y0); x0 = null; if (Math.abs(dx) > 50 && dy < 40) fn(dx < 0 ? 1 : -1); }, {passive: true});
}
function keepTabVisible(bar) {
  const on = bar.querySelector(".on"); if (!on || !bar.clientWidth) return;
  const l = on.offsetLeft, r = l + on.offsetWidth;
  if (l < bar.scrollLeft + 6) bar.scrollLeft = Math.max(0, l - 10);
  else if (r > bar.scrollLeft + bar.clientWidth - 6) bar.scrollLeft = r - bar.clientWidth + 10;
}

/* ---- nishon tanlagich: yuqorida jonli ko'rinish, har bir to'plamning 1-emojisi tab bo'lib turadi, tanlangan to'plam emojilari pastda ---- */
function badgeTabs() {
  const tabs = [{k: "std", label: "Emoji"}];
  if (EM.data) emojiTabs().filter(x => x.k !== "std").forEach(x => tabs.push(x));
  else { const l = Rich.emojiList(); if (l.length) tabs.push({k: "other", label: "Maxsus", items: l, icon: l[0]}); }
  return tabs;
}
function badgeEditor(t, onSaved, mid) {
  const base = () => t.id === S.me.id ? S.me : (U(t.id) || t);
  const cur = {badge: t.badge || "", anim: t.badge_anim || "", tab: "std"};
  const tabs = badgeTabs();
  const found = tabs.find(x => x.items && x.items.some(e => e.token === cur.badge)); if (found) cur.tab = found.k;
  const prev = h("div", {class: "bd-prev"}), bar = h("div", {class: "bd-tabs", role: "tablist"}), cap = h("div", {class: "ep-cap bd-cap"}),
    grid = h("div", {class: "bd-grid"}), anims = h("div", {class: "bd-anims"});
  const custom = h("input", {type: "text", class: "fld", maxlength: "16", placeholder: "Yoki o'z emojingizni yozing", autocomplete: "off", "aria-label": "O'z emojingiz"});
  hScroll(bar); hScroll(anims);
  const paintPrev = () => {
    const u = Object.assign({}, base(), {badge: cur.badge, badge_anim: cur.anim});
    prev.textContent = ""; prev.append(nameEl(u, {big: true}));
    if (!badge(u, true)) prev.append(h("small", {text: "  (nishon yo'q)"}));
  };
  const mark = () => {
    grid.querySelectorAll("button").forEach(x => x.classList.toggle("on", x.dataset.v === cur.badge));
    anims.querySelectorAll("button").forEach(x => x.classList.toggle("on", x.dataset.a === cur.anim));
    if (chk) chk.classList.toggle("on", cur.badge === "check");
  };
  const paint = () => { paintPrev(); mark(); };
  const pick = v => { cur.badge = v; custom.value = ""; paint(); };
  const paintGrid = dir => {
    grid.textContent = ""; grid.className = "bd-grid" + (dir ? " sl-" + dir : "");
    const c = tabs.find(x => x.k === cur.tab) || tabs[0];
    cap.textContent = c.k === "std" ? "Standart emojilar" : c.label + " • " + c.items.length + " ta";
    if (c.k === "std") BADGE_EMOJIS.forEach(e => { const b = h("button", {type: "button", text: e, "aria-label": e, onclick: () => pick(e)}); b.dataset.v = e; grid.append(b); });
    else if (!c.items.length) grid.append(h("div", {class: "ep-empty", text: "Bu to'plam hozircha bo'sh"}));
    else c.items.forEach(e => { const b = h("button", {type: "button", title: e.label || e.token, "aria-label": e.label || e.token, onclick: () => pick(e.token)}, Rich.chatEmoji(e.token, false)); b.dataset.v = e.token; grid.append(b); });
    mark();
  };
  const goTab = (k, dir) => {
    const i0 = tabs.findIndex(x => x.k === cur.tab), i1 = tabs.findIndex(x => x.k === k);
    cur.tab = k; bar.querySelectorAll("button").forEach(x => x.classList.toggle("on", x.dataset.k === k));
    keepTabVisible(bar); paintGrid(dir || (i1 > i0 ? "r" : "l"));
  };
  tabs.forEach(tb => {
    const b = h("button", {type: "button", role: "tab", class: tb.k === cur.tab ? "on" : "", title: tb.label, "aria-label": tb.label, onclick: () => goTab(tb.k)});
    if (tb.k === "std") b.textContent = "😀"; else if (tb.icon) b.append(Rich.chatEmoji(tb.icon.token, false)); else b.textContent = "📦";
    b.dataset.k = tb.k; bar.append(b);
  });
  onSwipe(grid, d => { const i = tabs.findIndex(x => x.k === cur.tab) + d; if (i >= 0 && i < tabs.length) goTab(tabs[i].k, d > 0 ? "r" : "l"); });
  BADGE_ANIMS.forEach(([k, n]) => { const b = h("button", {type: "button", text: n}); b.dataset.a = k; b.addEventListener("click", () => { cur.anim = k; paint(); }); anims.append(b); });
  custom.addEventListener("input", () => { const v = custom.value.trim(); if (v) { cur.badge = v; paint(); } });
  const chk = isStaff(t) ? null : h("button", {class: "bd-chip", type: "button", onclick: () => { cur.badge = "check"; cur.anim = ""; custom.value = ""; paint(); }}, "✔ Galochka");
  const clr = h("button", {class: "bd-chip", type: "button", onclick: () => { cur.badge = ""; cur.anim = ""; custom.value = ""; paint(); }}, isStaff(t) ? "Galochka (standart)" : "Olib tashlash");
  const hide = isStaff(t) ? h("button", {class: "bd-chip", type: "button", onclick: () => { cur.badge = "none"; cur.anim = ""; custom.value = ""; paint(); }}, "Yashirish") : null;
  const save = async () => {
    try {
      let u;
      if (t.id === S.me.id) u = (await api("/profile", {method: "PATCH", body: {badge: cur.badge, badge_anim: cur.anim}})).me;
      else u = (await api("/admin/badge", {method: "POST", body: {user_id: t.id, badge: cur.badge, anim: cur.anim}})).user;
      upsertUser(u); renderList(); renderHeader(); renderMessages(false);
      toast("Nishon saqlandi", "ok"); if (onSaved) onSaved(u);
      paintPrev();
    } catch (err) { toast(err.message, "error"); }
  };
  paintGrid(); paint();
  const root = h("div", {class: "bd"}, prev, mid || null, bar, cap, grid,
    h("div", {class: "bd-quick"}, chk, clr, hide),
    chk ? h("small", {class: "ep-cap", text: "Galochka foydalanuvchini admin qilmasdan beriladi."}) : null,
    h("div", {class: "bd-lab", text: "Animatsiya"}), anims, custom,
    h("div", {class: "bd-act"}, h("button", {class: "btn", type: "button", onclick: save}, "Saqlash")));
  root.repaint = paintPrev;
  requestAnimationFrame(() => keepTabVisible(bar));
  return root;
}
/* Mening akkauntim ichida: rang + nishon bitta ixcham bo'limda (yuqorida jonli ko'rinish) */
function lookSection() {
  let ed;
  const colors = colorSection(() => { if (ed) ed.repaint(); });
  ed = badgeEditor(S.me, null, colors);
  return h("div", {class: "setsec look"}, h("h4", {text: "Profil rangi va nishoni"}), ed);
}

/* =====================================================================
   Maxsus emojilar: tanlagich (yuborish tugmasi yonida), yaratish (rasm yuklab), boshqarish (admin)
   Xabarda emoji `:nom:` matni sifatida yuboriladi (E2EE ichida), ko'rsatishda rasmga aylanadi.
   ===================================================================== */
const EM = {data: null, tab: "std", refresh: null};
const STD_EMOJIS = "😀 😃 😄 😁 😆 😅 😂 🤣 🙂 😉 😊 😇 🥰 😍 🤩 😘 😋 😛 😜 🤪 😎 🤓 🥳 😏 😒 😞 😔 😟 😕 🙁 😣 😖 😫 😩 🥺 😢 😭 😤 😠 😡 🤬 🤯 😳 🥵 🥶 😱 😨 😰 😥 😓 🤗 🤔 🤭 🤫 😶 😐 😑 😬 🙄 😯 😲 🥱 😴 🤤 😪 😵 🤐 🥴 🤢 🤮 🤧 😷 🤒 🤕 😈 👿 👹 👺 💀 👻 👽 🤖 💩 🙈 🙉 🙊 👍 👎 👌 ✌️ 🤞 🤟 🤘 👏 🙌 🙏 💪 👀 🧠 ❤️ 🧡 💛 💚 💙 💜 🖤 💔 💯 ✨ 🔥 ⚡ 🌈 ⭐ 🎉 🎁 🏆 🚀 💻 🔒 🔑 🛡️ ☕ 🍕 🍔 🍺".split(" ");

function emojiPerms() { return (EM.data && EM.data.perms) || {use: false, create: false, manage: false}; }
function emojiUsable(e) {                                  // tanlagichda ko'rinadimi (admin hammasini ko'radi)
  const p = emojiPerms();
  if (p.manage) return true;
  const pk = e.pack != null ? EM.data.packs.find(x => x.id === e.pack) : null;
  return e.public !== false && (!pk || pk.public);
}
function syncEmojiBtn() { $("emojiBtn").classList.toggle("hidden", !emojiPerms().use); if (!emojiPerms().use) closeEmojiPanel(); }
async function loadEmojis() {
  try {
    const r = await api("/emojis");
    EM.data = r; Rich.setEmojis(r.emojis, true);
    syncEmojiBtn();
    if (S.active) renderMessages(false);                     // yangi/o'chirilgan emojilar xabarlarda darrov o'zgaradi
    renderList();                                            // chatlar ro'yxatidagi oxirgi xabarda ham
    if (!$("emojiPanel").classList.contains("hidden")) paintEmojiPanel();
    if (EM.refresh) EM.refresh();
  } catch (_) {}
}

function insertEmoji(text) {
  const s = inp.selectionStart == null ? inp.value.length : inp.selectionStart, e = inp.selectionEnd == null ? s : inp.selectionEnd;
  if (inp.value.length - (e - s) + text.length > inp.maxLength) { toast("Xabar juda uzun", "warn"); return; }
  inp.setRangeText(text, s, e, "end"); autosize();
  if (!COARSE) inp.focus({preventScroll: true});            // telefonda klaviatura o'zi chiqib ketmasin
}
function emojiPanelOpen() { return !$("emojiPanel").classList.contains("hidden"); }
function closeEmojiPanel() { $("emojiPanel").classList.add("hidden"); $("emojiBtn").classList.remove("on"); if (EM.typing) { EM.typing(); EM.typing = null; } }
function placeEmojiPanel() {
  const b = $("emojiBtn").getBoundingClientRect(), p = $("emojiPanel"), w = Math.min(344, innerWidth - 16);
  p.style.left = Math.max(8, Math.min(b.right - w, innerWidth - w - 8)) + "px";
  p.style.bottom = Math.max(8, innerHeight - b.top + 8) + "px";
}
function emojiTabs() {
  const d = EM.data, tabs = [{k: "std", label: "😀"}];
  const usable = d.emojis.filter(e => !e.builtin ? emojiUsable(e) : true);
  d.packs.forEach(pk => {
    const items = usable.filter(e => e.pack === pk.id);
    if (items.length || emojiPerms().manage) tabs.push({k: "p" + pk.id, label: pk.name, items, icon: items[0]});
  });
  const loose = usable.filter(e => e.pack == null || !d.packs.some(pk => pk.id === e.pack));
  if (loose.length) tabs.push({k: "other", label: tabs.length > 1 ? "Boshqa" : "Emojilar", items: loose, icon: loose[0]});
  return tabs;
}
function paintEmojiPanel(dir) {
  const panel = $("emojiPanel"), d = EM.data, perms = emojiPerms();
  if (!d) return;
  const tabs = emojiTabs();
  if (!tabs.some(t => t.k === EM.tab)) EM.tab = tabs.length > 1 ? tabs[1].k : "std";
  const oldBar = panel.querySelector(".ep-tabs"), keep = oldBar ? oldBar.scrollLeft : 0;   // tab almashganda ro'yxat boshiga sakramasin
  panel.textContent = "";
  const go = (k, dr) => {
    const i0 = tabs.findIndex(x => x.k === EM.tab), i1 = tabs.findIndex(x => x.k === k);
    EM.tab = k; paintEmojiPanel(dr || (i1 > i0 ? "r" : "l"));
  };
  const bar = h("div", {class: "ep-tabs", role: "tablist"});
  tabs.forEach(t => {                                       // har bir to'plam: faqat 1-emojisi; nomi — sarlavhada
    const b = h("button", {type: "button", class: t.k === EM.tab ? "on" : "", title: t.label, "aria-label": t.label, role: "tab"});
    if (t.k === "std") b.textContent = t.label; else if (t.icon) b.append(Rich.chatEmoji(t.icon.token, false)); else b.textContent = "📦";
    b.addEventListener("click", () => go(t.k));
    bar.append(b);
  });
  hScroll(bar);
  const cur = tabs.find(t => t.k === EM.tab) || tabs[0];
  const cap = h("div", {class: "ep-cap2", text: cur.k === "std" ? "Standart emojilar" : cur.label + " • " + cur.items.length + " ta"});
  const grid = h("div", {class: "ep-grid" + (dir ? " sl-" + dir : "")});
  if (cur.k === "std") STD_EMOJIS.forEach(c => grid.append(h("button", {type: "button", text: c, "aria-label": c, onclick: () => insertEmoji(c)})));
  else if (!cur.items.length) grid.append(h("div", {class: "ep-empty", text: "Bu to'plam hozircha bo'sh"}));
  else cur.items.forEach(e => {
    const b = h("button", {type: "button", title: e.token, "aria-label": e.label, onclick: () => insertEmoji(e.token)}, Rich.chatEmoji(e.token, false));
    grid.append(b);
  });
  onSwipe(grid, dd => { const i = tabs.findIndex(x => x.k === EM.tab) + dd; if (i >= 0 && i < tabs.length) go(tabs[i].k, dd > 0 ? "r" : "l"); });
  panel.append(bar, cap, grid);
  bar.scrollLeft = keep; keepTabVisible(bar);
  if (perms.create || perms.manage) {
    const foot = h("div", {class: "ep-foot"});
    if (perms.create) foot.append(h("button", {class: "btn ghost", type: "button", text: "＋ Emoji yaratish", onclick: () => { closeEmojiPanel(); openEmojiCreate(); }}));
    if (perms.manage) foot.append(h("button", {class: "btn ghost", type: "button", text: "📦 ZIP to'plam", onclick: () => { closeEmojiPanel(); openEmojiZip(); }}));
    if (perms.manage) foot.append(h("button", {class: "btn ghost", type: "button", text: "⚙ Boshqarish", onclick: () => { closeEmojiPanel(); openAdmin("emoji"); }}));
    panel.append(foot);
  }
}
function toggleEmojiPanel() {
  if (emojiPanelOpen()) { closeEmojiPanel(); return; }
  if (!EM.data || !emojiPerms().use) return;
  paintEmojiPanel(); placeEmojiPanel();
  $("emojiPanel").classList.remove("hidden"); $("emojiBtn").classList.add("on");
  if (!EM.typing) EM.typing = Typing.hold("emoji");                                 // "emoji tanlamoqda…"
  const eb = $("emojiPanel").querySelector(".ep-tabs"); if (eb) keepTabVisible(eb);
}
$("emojiBtn").addEventListener("mousedown", e => e.preventDefault());           // yozish maydonidan fokus ketmasin
$("emojiPanel").addEventListener("mousedown", e => { if (!e.target.closest("input,select,textarea")) e.preventDefault(); });
$("emojiBtn").addEventListener("click", toggleEmojiPanel);
document.addEventListener("click", e => {            // katalog (tab) almashganda panel qayta chiziladi: bosilgan tugma DOM'dan chiqib ketadi, shuning uchun yo'lni hodisa vaqtidagi holatdan olamiz
  if (!emojiPanelOpen()) return;
  const path = e.composedPath ? e.composedPath() : [];
  if (path.includes($("emojiPanel")) || path.includes($("emojiBtn"))) return;
  closeEmojiPanel();
});
document.addEventListener("keydown", e => { if (e.key === "Escape" && emojiPanelOpen()) { e.stopPropagation(); closeEmojiPanel(); } }, true);
addEventListener("resize", () => { if (emojiPanelOpen()) placeEmojiPanel(); });

/* ---------- emoji yaratish: rasm tanlash -> (kerak bo'lsa) orqa fonni olib tashlash -> animatsiya -> saqlash ---------- */
function openEmojiCreate(back) {
  const d = EM.data;
  if (!d || !d.perms.create) { toast("Emoji yaratishga ruxsatingiz yo'q", "error"); return; }
  const admin = d.perms.manage;
  const st = {file: null, seq: 0, timer: 0, touched: false};
  openModal(() => {
    const pvImg = h("img", {alt: "", draggable: "false", class: "hidden"});
    const hint = h("div", {class: "em-hint", text: "Rasm tanlang: .png (oddiy emoji) yoki .gif (animatsiyali emoji). JPG va WEBP ham mumkin, 20 MB gacha"});
    const pv = h("div", {class: "em-pv"}, pvImg, hint);
    const pick = h("input", {type: "file", accept: ".png,.gif,image/png,image/gif,image/jpeg,image/webp", class: "offscreen"});
    const pickBtn = h("button", {class: "btn ghost", type: "button", text: "🖼 Rasm tanlash", onclick: () => pick.click()});
    const name = h("input", {type: "text", class: "fld", maxlength: "32", placeholder: "masalan: kulgi_1", autocomplete: "off", autocapitalize: "off", spellcheck: "false"});
    const bg = h("input", {type: "checkbox"});
    const bgRow = h("label", {class: "em-chk"}, bg, h("span", {text: "Orqa fonni olib tashlash (remove background)"}));
    const bgNote = h("small", {text: "JPG yoki shaffof bo'lmagan rasm uchun. Bir xil rangli fonda yaxshi ishlaydi."});
    const tolVal = h("b", {text: "30"});
    const tol = h("input", {type: "range", min: "5", max: "80", value: "30"});
    const tolRow = h("div", {class: "em-row hidden"}, h("label", {text: "Fon sezgirligi (kattaroq = ko'proq o'chadi)"}), h("div", {class: "em-range"}, tol, tolVal));
    const anim = h("select", {class: "fld"}, ...BADGE_ANIMS.map(([v, t]) => h("option", {value: v, text: t})));
    const animRow = h("div", {class: "em-row"}, h("label", {text: "Animatsiya"}), anim);
    const packSel = h("select", {class: "fld"}), pub = h("select", {class: "fld"}, h("option", {value: "true", text: "Hamma ishlata oladi"}), h("option", {value: "false", text: "Faqat adminlar"}));
    const fillPacks = sel => {
      packSel.textContent = ""; packSel.append(h("option", {value: "", text: "To'plamsiz"}));
      EM.data.packs.forEach(p => packSel.append(h("option", {value: String(p.id), text: p.name + (p.public ? "" : " (yopiq)")})));
      packSel.value = sel == null ? "" : String(sel);
    };
    fillPacks(EM.tab.startsWith("p") ? Number(EM.tab.slice(1)) : null);
    const newPack = h("button", {class: "btn ghost sm", type: "button", text: "＋ Yangi to'plam", onclick: async () => {
      const nm = await promptDlg("Yangi emoji to'plami", "To'plam nomi (2–24 belgi):", "", {okText: "Yaratish", placeholder: "masalan: Mem emojilar"});
      if (!nm) return;
      try { const r = await api("/emoji-packs", {method: "POST", body: {name: nm, public: true}}); await loadEmojis(); fillPacks(r.id); toast("To'plam yaratildi", "ok"); }
      catch (err) { toast(err.message, "error"); }
    }});
    packSel.addEventListener("change", () => { const p = EM.data.packs.find(x => String(x.id) === packSel.value); if (p) pub.value = String(p.public); });
    const go = h("button", {class: "btn", type: "button", text: "Emoji yaratish", disabled: true});
    const showAnim = () => { BADGE_ANIMS.forEach(([v]) => { if (v) pvImg.classList.remove("a-" + v); }); if (anim.value) pvImg.classList.add("a-" + anim.value); };
    anim.addEventListener("change", showAnim);

    const setBgState = r => {
      const locked = r.source_alpha || r.animated;
      bg.disabled = locked; bgRow.classList.toggle("off", locked);
      if (locked) bg.checked = false;
      bgNote.textContent = r.animated ? "Animatsiyali fayl: orqa fon o'chirilmaydi, animatsiya saqlanadi."
        : r.source_alpha ? "Bu rasm shaffof (PNG): orqa fon yo'q, shundayligicha qoladi."
        : "JPG yoki shaffof bo'lmagan rasm uchun. Bir xil rangli fonda yaxshi ishlaydi.";
      tolRow.classList.toggle("hidden", !bg.checked || locked);
      animRow.classList.toggle("hidden", !!r.animated);
    };
    const preview = async () => {
      if (!st.file) return;
      const my = ++st.seq; pv.classList.add("busy"); go.disabled = true;
      const fd = new FormData(); fd.append("file", st.file); fd.append("remove_bg", bg.checked ? "true" : "false"); fd.append("tolerance", tol.value);
      try {
        const r = await api("/emoji/preview", {method: "POST", body: fd});
        if (my !== st.seq) return;
        pvImg.src = r.image; pvImg.classList.remove("hidden"); showAnim(); setBgState(r);
        hint.textContent = r.bg_removed ? "Orqa fon olib tashlandi" : r.transparent ? "Shaffof fon saqlandi" : "Orqa fon bilan (xohlasangiz, yuqoridan olib tashlang)";
        go.disabled = false;
      } catch (err) {
        if (my !== st.seq) return;
        hint.textContent = err.message; if (!bg.checked) pvImg.classList.add("hidden");
        go.disabled = !bg.checked;                           // fon xatosida sozlamani o'zgartirib qayta urinish mumkin
      } finally { if (my === st.seq) pv.classList.remove("busy"); }
    };
    const later = () => { clearTimeout(st.timer); st.timer = setTimeout(preview, 350); };
    pick.addEventListener("change", () => {
      const f = pick.files[0]; pick.value = ""; if (!f) return;
      if (f.size > 20 * 1024 * 1024) { toast("Rasm 20 MB dan oshmasligi kerak", "error"); return; }
      st.file = f; bg.checked = false; tolRow.classList.add("hidden");
      if (!st.touched) { const n = f.name.replace(/\.[^.]+$/, "").toLowerCase().replace(/[^a-z0-9_]+/g, "_").replace(/^_+|_+$/g, "").slice(0, 32); name.value = n.length >= 2 ? n : "emoji"; }
      preview();
    });
    name.addEventListener("input", () => { st.touched = true; });
    bg.addEventListener("change", () => { tolRow.classList.toggle("hidden", !bg.checked); preview(); });
    tol.addEventListener("input", () => { tolVal.textContent = tol.value; later(); });
    go.addEventListener("click", async () => {
      if (!st.file) { toast("Avval rasm tanlang", "error"); return; }
      go.disabled = true; go.textContent = "Yaratilmoqda…";
      const fd = new FormData();
      fd.append("file", st.file); fd.append("name", name.value); fd.append("anim", anim.value); fd.append("remove_bg", bg.checked ? "true" : "false");
      fd.append("tolerance", tol.value);
      if (admin) { fd.append("pack_id", packSel.value); fd.append("public", pub.value); }
      try {
        const r = await api("/emoji", {method: "POST", body: fd});
        toast("Emoji tayyor: :" + r.name + ":", "ok");
        await loadEmojis();
        if (back) back(); else closeModal();
      } catch (err) { toast(err.message, "error"); go.disabled = false; go.textContent = "Emoji yaratish"; }
    });
    return h("div", {}, sheetHead("Emoji yaratish", back || null),
      h("div", {class: "em-dlg"}, pv, pickBtn, pick,
        h("div", {class: "em-row"}, h("label", {text: "Emoji nomi (:nom: ko'rinishida yoziladi)"}), name),
        bgRow, bgNote, tolRow, animRow,
        admin ? h("div", {class: "em-two"}, h("div", {class: "em-row"}, h("label", {text: "To'plam"}), packSel, newPack), h("div", {class: "em-row"}, h("label", {text: "Kim ishlata oladi"}), pub)) : null,
        go));
  });
}

/* ---------- ZIP to'plam: ZIP tanlash -> ichidagi PNG/GIF ro'yxati -> har emojiga nom -> kim ishlata oladi -> yaratish ---------- */
function openEmojiZip(back) {
  const d = EM.data;
  if (!d || !d.perms.manage) { toast("ZIP to'plam yaratish faqat adminlar uchun", "error"); return; }
  const st = {file: null, items: []};
  openModal(() => {
    const pick = h("input", {type: "file", accept: ".zip,application/zip,application/x-zip-compressed", class: "offscreen"});
    const pickBtn = h("button", {class: "btn ghost", type: "button", text: "📦 ZIP fayl tanlash", onclick: () => pick.click()});
    const hint = h("div", {class: "em-hint", text: "ZIP ichida PNG (oddiy emoji) va GIF (animatsiyali emoji) fayllar bo'lsin. Soni cheklanmagan, ZIP 50 MB gacha."});
    const packName = h("input", {type: "text", class: "fld", maxlength: "24", placeholder: "masalan: Mem emojilar", autocomplete: "off"});
    const pub = h("select", {class: "fld"}, h("option", {value: "true", text: "Hamma ishlata oladi"}), h("option", {value: "false", text: "Faqat adminlar"}));
    const list = h("div", {class: "emz-list hidden"}), skipped = h("small", {class: "emz-skip"}), count = h("div", {class: "em-hint hidden"});
    const form = h("div", {class: "hidden"},
      h("div", {class: "em-two"}, h("div", {class: "em-row"}, h("label", {text: "To'plam nomi"}), packName), h("div", {class: "em-row"}, h("label", {text: "Kim ishlata oladi"}), pub)));
    const go = h("button", {class: "btn", type: "button", text: "To'plam yaratish", disabled: true});
    const NAME = /^[a-z0-9_]{2,32}$/;
    const check = () => {                                    // tanlangan emojilar nomi to'g'ri va takrorlanmaganmi
      const used = new Map(); let n = 0, bad = false;
      st.items.forEach(it => { if (!it.on) return; n++; used.set(it.name, (used.get(it.name) || 0) + 1); });
      st.items.forEach(it => {
        const e = it.on && (!NAME.test(it.name) || used.get(it.name) > 1 || EM.data.emojis.some(x => x.token === ":" + it.name + ":"));
        it.row.classList.toggle("bad", !!e); if (e) bad = true;
      });
      count.textContent = n + " ta emoji tanlandi" + (bad ? " — qizil nomlarni to'g'rilang (2–32 belgi, a–z, 0–9, _; takrorlanmasin)" : "");
      go.disabled = !n || bad || packName.value.trim().length < 2;
    };
    const paint = r => {
      list.textContent = ""; st.items = [];
      r.items.forEach(x => {
        const it = {file: x.file, name: x.name, on: true};
        const chk = h("input", {type: "checkbox", checked: true, "aria-label": "Qo'shish"});
        const nm = h("input", {type: "text", class: "fld", maxlength: "32", value: x.name, autocomplete: "off", autocapitalize: "off", spellcheck: "false", "aria-label": "Emoji nomi"});
        chk.addEventListener("change", () => { it.on = chk.checked; check(); });
        nm.addEventListener("input", () => { nm.value = nm.value.toLowerCase().replace(/[^a-z0-9_]/g, "_"); it.name = nm.value; check(); });
        it.row = h("div", {class: "emz-row"}, chk, h("img", {src: x.image, alt: "", draggable: "false"}), h("div", {class: "emz-n"}, nm, h("small", {text: x.animated ? "GIF • animatsiyali" : "PNG • oddiy"})));
        st.items.push(it); list.append(it.row);
      });
      skipped.textContent = r.skipped.length ? "O'tkazib yuborildi: " + r.skipped.map(k => k.file + " (" + k.error + ")").join(", ") : "";
      list.classList.remove("hidden"); form.classList.remove("hidden"); count.classList.remove("hidden"); check();
    };
    pick.addEventListener("change", async () => {
      const f = pick.files[0]; pick.value = ""; if (!f) return;
      if (f.size > 12 * 1024 * 1024) { toast("ZIP 12 MB dan oshmasligi kerak", "error"); return; }
      st.file = f; hint.textContent = "Ochilmoqda…"; go.disabled = true;
      const fd = new FormData(); fd.append("file", f);
      try {
        const r = await api("/emoji-pack/zip-preview", {method: "POST", body: fd});
        hint.textContent = f.name + " — " + r.items.length + " ta emoji topildi";
        if (!packName.value) packName.value = f.name.replace(/\.zip$/i, "").replace(/[_]+/g, " ").slice(0, 24);
        paint(r);
      } catch (err) { hint.textContent = err.message; list.classList.add("hidden"); form.classList.add("hidden"); count.classList.add("hidden"); st.items = []; }
    });
    packName.addEventListener("input", () => { if (st.items.length) check(); });
    go.addEventListener("click", async () => {
      const sel = st.items.filter(i => i.on);
      go.disabled = true; go.textContent = "Yaratilmoqda…";
      const fd = new FormData();
      fd.append("file", st.file); fd.append("pack_name", packName.value); fd.append("public", pub.value);
      fd.append("items", JSON.stringify(sel.map(i => ({file: i.file, name: i.name}))));
      try {
        const r = await api("/emoji-pack/zip", {method: "POST", body: fd});
        toast("«" + r.pack + "»: " + r.created.length + " ta emoji qo'shildi" + (r.failed.length ? ", " + r.failed.length + " tasi yaratilmadi" : ""), r.failed.length ? "warn" : "ok");
        await loadEmojis();
        if (back) back(); else closeModal();
      } catch (err) { toast(err.message, "error"); go.disabled = false; go.textContent = "To'plam yaratish"; }
    });
    return h("div", {}, sheetHead("Emoji to'plami (ZIP)", back || null),
      h("div", {class: "em-dlg"}, hint, pickBtn, pick, form, count, list, skipped, go));
  }, false, false, false);
}

/* ---------- emoji boshqaruvi (admin paneli, «Emoji» bo'limi) ---------- */
function emojiManager(body, alive) {
  const ANIM_OPTS = BADGE_ANIMS.map(([v, t]) => [v, t]);
  const act = async (fn, okText) => { try { await fn(); if (okText) toast(okText, "ok"); } catch (err) { toast(err.message, "error"); } await loadEmojis(); };
  let q = "";
  const paint = () => {
    const d = EM.data;
    body.textContent = "";
    if (!d || !d.perms.manage) { body.append(h("div", {class: "adm-empty", text: "Yuklanmoqda…"})); return; }

    const mode = h("select", {class: "fld"}, h("option", {value: "off", text: "Yopiq — faqat adminlar (va ruxsat berilganlar)"}), h("option", {value: "use", text: "Ochiq — hamma ochiq emojilarni ishlatadi"}));
    mode.value = d.global;
    mode.addEventListener("change", () => act(() => api("/emoji-settings", {method: "PUT", body: {mode: mode.value}}), "Saqlandi"));
    const top = h("div", {class: "em-sec"}, h("h4", {text: "😀 Oddiy foydalanuvchilar"}),
      h("p", {text: "Ochiq bo'lsa, hamma foydalanuvchida yuborish tugmasi yonida emoji tanlagich chiqadi (faqat «hamma ishlata oladi» deb belgilangan emojilar). Yaratish ruxsatini pastda alohida foydalanuvchiga berasiz."}), mode,
      h("div", {class: "ep-row"}, h("button", {class: "btn sm", type: "button", text: "＋ Emoji yaratish", onclick: () => openEmojiCreate(() => openAdmin("emoji"))}),
        h("button", {class: "btn sm", type: "button", text: "📦 ZIP to'plam", onclick: () => openEmojiZip(() => openAdmin("emoji"))})));

    const packs = h("div", {class: "em-sec"}, h("h4", {text: "📦 Emoji to'plamlari (pack)"}), h("p", {text: "To'plam emojilarni guruhlaydi. To'plamni yopsangiz, ichidagi emojilar faqat adminlarga ko'rinadi."}));
    d.packs.forEach(pk => {
      const nm = h("input", {type: "text", class: "fld", maxlength: "24", value: pk.name});
      const pb = h("select", {class: "fld"}, h("option", {value: "true", text: "Hamma uchun"}), h("option", {value: "false", text: "Faqat adminlar"})); pb.value = String(pk.public);
      packs.append(h("div", {class: "em-item"}, h("span", {text: "📦"}), nm, h("div", {class: "em-ctl"}, pb,
        h("button", {class: "btn ghost sm", type: "button", text: "Saqlash", onclick: () => act(() => api("/emoji-packs/" + pk.id, {method: "PATCH", body: {name: nm.value, public: pb.value === "true"}}), "Saqlandi")}),
        h("button", {class: "btn danger sm", type: "button", text: "O'chirish", onclick: async () => {
          if (!await confirmDlg("«" + pk.name + "» to'plami o'chadi. Ichidagi emojilar o'chmaydi, to'plamsiz bo'lib qoladi.", {title: "To'plamni o'chirish", okText: "O'chirish", danger: true})) return;
          act(() => api("/emoji-packs/" + pk.id, {method: "DELETE"}), "To'plam o'chirildi");
        }}))));
    });
    const newName = h("input", {type: "text", class: "fld", maxlength: "24", placeholder: "Yangi to'plam nomi", autocomplete: "off"});
    packs.append(h("div", {class: "ep-row"}, newName, h("button", {class: "btn sm", type: "button", text: "Yaratish", onclick: () => {
      if (!newName.value.trim()) return;
      act(() => api("/emoji-packs", {method: "POST", body: {name: newName.value, public: true}}), "To'plam yaratildi");
    }})));

    const list = h("div", {class: "em-sec"}, h("h4", {text: "🖼 Maxsus emojilar (" + d.emojis.filter(e => !e.builtin).length + ")"}));
    const mine = d.emojis.filter(e => !e.builtin);
    if (!mine.length) list.append(h("p", {text: "Hali emoji yo'q. «Emoji yaratish» tugmasi bilan rasm yuklab yarating."}));
    mine.forEach(e => {
      const pk = h("select", {class: "fld"}, h("option", {value: "", text: "To'plamsiz"}), ...d.packs.map(p => h("option", {value: String(p.id), text: p.name}))); pk.value = e.pack == null ? "" : String(e.pack);
      const pb = h("select", {class: "fld"}, h("option", {value: "true", text: "Hamma"}), h("option", {value: "false", text: "Faqat adminlar"})); pb.value = String(e.public);
      const an = h("select", {class: "fld", disabled: e.animated}, ...ANIM_OPTS.map(([v, t]) => h("option", {value: v, text: t}))); an.value = e.anim || "";
      const save = () => act(() => api("/emoji/" + e.id, {method: "PATCH", body: {anim: an.value, pack_id: pk.value ? Number(pk.value) : null, public: pb.value === "true"}}), "Saqlandi");
      [pk, pb, an].forEach(s => s.addEventListener("change", save));
      list.append(h("div", {class: "em-item"}, Rich.chatEmoji(e.token, false),
        h("div", {}, h("b", {text: e.token}), h("div", {class: "em-lbl", text: (e.author ? e.author : "—") + (e.animated ? " • animatsiyali fayl" : "")})),
        h("div", {class: "em-ctl"}, pk, pb, an, h("button", {class: "btn danger sm", type: "button", text: "O'chirish", onclick: async () => {
          if (!await confirmDlg(e.token + " emojisi o'chadi. Eski xabarlarda u oddiy matn bo'lib ko'rinadi.", {title: "Emojini o'chirish", okText: "O'chirish", danger: true})) return;
          act(() => api("/emoji/" + e.id, {method: "DELETE"}), "Emoji o'chirildi");
        }}))));
    });

    const users = h("div", {class: "em-sec"}, h("h4", {text: "👤 Foydalanuvchilar ruxsati"}),
      h("p", {text: "«Yaratadi» ruxsati olgan foydalanuvchi o'z emojisini yarata oladi (eng ko'pi bilan " + 30 + " ta, hamma ko'radi). Adminlarda hammasi doim bor."}));
    const search = h("input", {type: "text", class: "fld", placeholder: "Nickname yoki @username", autocomplete: "off", value: q});
    const ulist = h("div", {});
    const fillUsers = () => {
      ulist.textContent = "";
      const t = q.trim().toLowerCase().replace(/^@/, "");
      const ms = S.members.filter(m => m.role === "user" && !m.deleted && (!t || (m.nickname || "").toLowerCase().includes(t) || (m.username || "").toLowerCase().includes(t))).slice(0, 60);
      if (!ms.length) ulist.append(h("div", {class: "adm-empty", text: "Hech kim topilmadi"}));
      ms.forEach(m => {
        const sel = h("select", {class: "fld"}, h("option", {value: "0", text: "Umumiy sozlama"}), h("option", {value: "1", text: "Ishlatadi"}), h("option", {value: "2", text: "Ishlatadi + yaratadi"}));
        sel.value = String((d.user_perms || {})[String(m.id)] || 0);
        sel.addEventListener("change", () => act(() => api("/emoji-perm/" + m.id, {method: "PUT", body: {perm: Number(sel.value)}}), "Ruxsat saqlandi"));
        ulist.append(h("div", {class: "em-urow"}, h("span", {text: m.nickname + " @" + m.username}), sel));
      });
    };
    search.addEventListener("input", () => { q = search.value; fillUsers(); });
    fillUsers();
    users.append(search, ulist);
    body.append(top, packs, list, users);
  };
  const refresh = () => {                              // katalog o'zgarganda (WS) faqat «Emoji» bo'limi ochiq turganda qayta chiziladi
    if (!body.isConnected || (alive && !alive())) { if (EM.refresh === refresh) EM.refresh = null; return; }
    paint();
  };
  EM.refresh = refresh;
  paint();
  if (!EM.data) loadEmojis();
}
function openBadgePicker(u, back) {
  const go = back || (() => openProfile(u.id));
  openModal(() => h("div", {}, sheetHead("Nishon: @" + u.username, go), h("div", {class: "sh-body"}, badgeEditor(U(u.id), go))), false);
}

/* ---------- sozlamalar (o'z profilim) ---------- */
/* ---------------- Shifrlash inspektori: xabar qanday shifrlanadi va server nimani ko'radi ---------------- */
function openInspector(tab) {
  openPage(() => {
    const st = {tab: tab || "flow"};
    const tabs = h("div", {class: "adm-tabs"}), body = h("div", {class: "adm-body enc"});
    const defs = [["flow", "Xabar yo'li"], ["server", "Server ko'radi"], ["keys", "Kalitlar"], ["limits", "Halol chegaralar"]];
    const paint = () => { tabs.textContent = ""; defs.forEach(([k, t]) => tabs.append(h("button", {type: "button", class: st.tab === k ? "on" : "", text: t, onclick: () => { st.tab = k; paint(); load(); }}))); };
    const load = () => { body.textContent = ""; ({flow: encFlow, server: encServer, keys: encKeys, limits: encLimits})[st.tab](body); };
    paint(); load();
    return h("div", {}, pageHead("🔒 Shifrlash: nima sodir bo'layapti?"), tabs, body);
  });
}
const mono = (t, cls) => h("div", {class: "enc-mono" + (cls ? " " + cls : ""), text: t});
const step = (n, title, ...kids) => h("div", {class: "enc-step"}, h("div", {class: "enc-n", text: String(n)}), h("div", {class: "enc-b"}, h("b", {text: title}), ...kids));
const shortId = s => s && s.length > 28 ? s.slice(0, 22) + "…" + s.slice(-6) : (s || "");

function encFlow(body) {
  const out = h("div", {});
  const inp2 = h("textarea", {class: "fld", rows: "2", maxlength: "200"}); inp2.value = "Salom! Bu sinov matni 🙂";
  const go = h("button", {class: "btn", type: "button", text: "Shifrlab ko'rish (yuborilmaydi)"});
  go.onclick = async () => {
    out.textContent = "";
    try {
      if (!S.active) throw new Error("Avval biror suhbatni oching (guruh yoki lichka) — kalit shu suhbatniki");
      const ctx = await keyForActive(), text = inp2.value.slice(0, 200);
      const env = await sealFor(ctx, {t: text}), t = E2E.trace[E2E.trace.length - 1];
      const dm = S.active.kind === "dm", p = dm ? await peer(S.active.uid) : null;
      const pkt = JSON.stringify(Object.assign({type: "send", e2e: env}, dm ? {to: S.active.uid} : {}));
      out.append(
        step(1, "Sizning matningiz (faqat qurilmangizda)", mono(t.plain), h("small", {text: "Uzunlik yashirilishi uchun " + t.plainBytes + " baytgacha to'ldiriladi."})),
        step(2, dm ? "Kalit: ikkingiz orasidagi ECDH kaliti" : "Kalit: guruh kaliti (avlod " + ctx.ep + ")",
          mono(dm ? "Sizning xavfsizlik raqamingiz: " + X.fp + "\n" + U(S.active.uid).nickname + ": " + p.fp : "Kalit ID: " + (X.keyIds.get(ctx.ep) || "?") + "  (kalitning o'zi emas, faqat belgisi)"),
          h("small", {text: dm ? "Bu kalit faqat sizning va suhbatdoshingizning maxfiy kalitlaridan hosil bo'ladi; server ikkalasini ham bilmaydi." : "Guruh kaliti serverda yo'q: har bir a'zo uchun uning ommaviy kaliti bilan o'ralgan nusxasi bor."})),
        step(3, "AES-256-GCM bilan shifrlash", mono("IV (tasodifiy): " + t.iv + "\nShifr: " + t.ctBytes + " bayt (shu jumladan 16 baytlik tekshiruv tegi)")),
        step(4, "ECDSA imzosi (yuboruvchi — siz)", mono(t.sigBytes + " bayt. Hech kim sizning nomingizdan soxta xabar yarata olmaydi.")),
        step(5, "Serverga ketadigan paket (ilova darajasida)", mono(shortId(pkt) === pkt ? pkt : pkt.slice(0, 90) + " … " + pkt.slice(-40), "net"),
          h("small", {text: "Mana shu — serverga boradigan hamma narsa: matn yo'q, faqat shifr. To'liq konvert:"}), mono(env, "net long")));
    } catch (err) { out.append(h("div", {class: "adm-empty", text: err.message})); }
  };
  const wire = h("div", {});
  const paintWire = () => {
    wire.textContent = "";
    const fr = SC.wire.slice(-4).reverse();
    if (!fr.length) wire.append(h("div", {class: "adm-empty", text: "Hozircha kadr yo'q"}));
    fr.forEach(f => wire.append(h("div", {class: "enc-frame"},
      h("b", {text: (f.dir === "→" ? "Siz → server" : "server → siz") + " • " + new Date(f.ts).toLocaleTimeString() + " • " + f.bytes + " belgi"}),
      h("small", {text: "Server (kanal ochilgach) ko'radigan ilova JSON'i:"}), mono(f.app, "net"),
      h("small", {text: "Tarmoqda (Chrome Network, Wireshark) ko'rinadigani:"}), mono(f.net + "…", "net"))));
  };
  paintWire();
  body.append(
    h("p", {class: "adm-note", text: "Xabaringiz brauzeringizda shifrlanadi va faqat shifr serverga boradi. Sinab ko'ring: matn kiriting — pastda shifrlash qadamlari haqiqiy kalitingiz bilan ko'rsatiladi (xabar yuborilmaydi)."}),
    inp2, go, out,
    h("h4", {class: "enc-h", text: "Tarmoqdagi oxirgi haqiqiy kadrlar"}),
    h("p", {class: "adm-note", text: "Ikki qatlam: tashqi — brauzer↔server kanali (Wireshark shuni ko'radi); ichki — xabar konverti, uni faqat suhbat a'zolari ocha oladi. Server kanalni ochadi, lekin konvertni ocha olmaydi."}),
    h("button", {class: "btn ghost sm", type: "button", text: "Yangilash", onclick: paintWire}), wire);
}

async function encServer(body) {
  body.append(h("div", {class: "adm-empty", text: "Serverdan so'ralmoqda…"}));
  let j;
  try { j = await api("/e2ee/server-view" + (S.active && S.active.kind === "dm" ? "?to=" + S.active.uid : "")); }
  catch (err) { body.textContent = ""; admErr(body, err); return; }
  body.textContent = "";
  const scope = j.scope === "group" ? "Umumiy chat" : "Lichka: " + (S.active ? U(S.active.uid).nickname : "");
  body.append(h("p", {class: "adm-note", text: scope + " — serverning o'z bazasidagi so'nggi qatorlar (server aynan shuni qaytardi). Chap tomonda — qurilmangizda ochilgan matn, o'ngda — server va admin ko'radigani."}));
  const mine = new Map(currentMsgs().map(m => [m.id, m]));
  if (!j.rows.length) body.append(h("div", {class: "adm-empty", text: "Bu suhbatda hali xabar yo'q"}));
  j.rows.forEach(r => {
    const local = mine.get(r.id);
    const you = local ? (local.locked ? "🔒 (kalit kutilmoqda)" : local.bad ? "⚠ (ochib bo'lmadi)" : (local.content || (local.image ? "📷 rasm" : local.file ? (local.file.voice ? "🎤 ovozli xabar" : local.file.vnote ? "📹 video xabar" : "📎 " + local.file.name) : ""))) : "(bu xabar yuklanmagan)";
    body.append(h("div", {class: "enc-row"},
      h("div", {class: "enc-rh"}, h("b", {text: "#" + r.id + " • @" + r.from}), h("span", {text: " • " + fmtDT(r.ts) + " • " + r.stored_bytes + " bayt" + (r.blob_bytes ? " • fayl " + fmtSize(r.blob_bytes) + " (shifrlangan)" : "") + (r.deleted ? " • o'chirilgan" : "") + (r.edited ? " • tahrirlangan" : "")}),
        r.e2e ? null : h("span", {class: "flag b", text: "ESKI: server o'qiy oladi"})),
      h("div", {class: "enc-cols"},
        h("div", {}, h("small", {text: "SIZ KO'RASIZ (qurilmada ochilgan)"}), h("div", {class: "enc-you", text: you})),
        h("div", {}, h("small", {text: "SERVER BAZASIDA"}), mono(r.stored, "net")),
        h("div", {}, h("small", {text: "ADMIN LOGIDA"}), mono(r.admin_sees, "net")))));
  });
  const li = arr => h("ul", {class: "enc-ul"}, ...arr.map(t => h("li", {text: t})));
  body.append(
    h("h4", {class: "enc-h", text: "Server biladi"}), li(j.knows.biladi),
    h("h4", {class: "enc-h", text: "Server bilmaydi"}), li(j.knows.bilmaydi),
    h("h4", {class: "enc-h", text: "Sizning yozuvingiz serverda"}),
    mono("Ommaviy kalit (ECDH): " + shortId(j.me.ecdh_pub) + "\nOmmaviy kalit (imzo): " + shortId(j.me.sign_pub) + "\nMaxfiy kalitlar zaxirasi: " + j.me.key_blob_bytes + " bayt, parolingiz kalitida shifrlangan — serverda ochib bo'lmaydi" +
      "\nGuruh kaliti (sizga o'ralgan nusxa): " + (j.room.my_wrap ? "avlod " + j.room.my_wrap.epoch + ", o'ragan: @" + (U(j.room.my_wrap.by).username || j.room.my_wrap.by) : "hali yo'q"), "net"),
    h("h4", {class: "enc-h", text: "Harakatlaringiz logi (adminga ko'rinadigan)"}),
    ...(j.activity.length ? j.activity.map(a => h("div", {class: "enc-act", text: fmtDT(a.ts) + " • " + a.ip + " • " + a.action + (a.detail ? " • " + a.detail : "")})) : [h("div", {class: "adm-empty", text: "Yozuv yo'q"})]),
    j.legacy_messages ? h("p", {class: "adm-note warn", text: "⚠ Bazada hali " + j.legacy_messages + " ta ESKI (E2EE'dan oldingi) xabar bor — ularni server o'qiy oladi. Ega ularni Moderatsiya bo'limidan o'chira oladi."}) : h("p", {class: "adm-note ok", text: "✅ Bazada server o'qiy oladigan xabar yo'q."}));
}

async function encKeys(body) {
  const cur = X.epoch;
  body.append(
    h("p", {class: "adm-note", text: "Barmoq izi — kalitingizning qisqa belgisi. Suhbatdoshingiz bilan uni boshqa kanalda (yuzma-yuz, telefon) solishtiring: mos kelsa, o'rtada hech kim yo'q."}),
    h("h4", {class: "enc-h", text: "Sizning barmoq izingiz"}), mono(X.fp || "—", "fp"),
    h("button", {class: "btn ghost sm", type: "button", text: "Nusxalash", onclick: () => copyText(X.fp)}),
    h("h4", {class: "enc-h", text: "Guruh kaliti"}),
    mono("Joriy avlod: " + (cur || "yo'q") + (X.rooms.has(cur) ? " • sizda bor • kalit ID: " + X.keyIds.get(cur) : " • sizda hali yo'q") + "\nSizda bor avlodlar: " + ([...X.rooms.keys()].join(", ") || "—")));
  const changed = [...X.changed.entries()];
  if (changed.length) {
    body.append(h("p", {class: "adm-note warn", text: "⚠ Quyidagi foydalanuvchilarning kaliti ilgari ko'rganingizdan FARQ QILADI. Bu server almashtirgan kalit bo'lishi mumkin. Barmoq izini tekshirmaguncha ularga yozmang."}));
    changed.forEach(([uid, c]) => body.append(h("div", {class: "enc-row"}, h("b", {text: "@" + U(uid).username}), mono("Avval: " + c.old + "\nHozir: " + c.now),
      h("button", {class: "btn danger sm", type: "button", text: "Yangi kalitni qabul qilish", onclick: () => { acceptKeyChange(uid); toast("Qabul qilindi", "ok"); renderHeader(); body.textContent = ""; encKeys(body); }}))));
  }
  body.append(h("h4", {class: "enc-h", text: "A'zolar barmoq izlari"}));
  const list = h("div", {}); body.append(list);
  const members = S.members.filter(m => m.ek && m.id !== S.me.id).slice(0, 80);
  for (const m of members) {
    try {
      const p = await peer(m.id);
      list.append(h("div", {class: "enc-mem"}, h("b", {text: m.nickname + " @" + m.username}), mono(p.fp + (p.changed ? "   ⚠ O'ZGARGAN" : ""), p.changed ? "bad" : "fp")));
    } catch (_) {}
  }
  if (!members.length) list.append(h("div", {class: "adm-empty", text: "Boshqa a'zo yo'q"}));
}

function encLimits(body) {
  const li = arr => h("ul", {class: "enc-ul"}, ...arr.map(t => h("li", {text: t})));
  body.append(
    h("p", {class: "adm-note", text: "Haqiqiy E2EE nimani kafolatlaydi va nimani kafolatlamaydi — halol ro'yxat:"}),
    h("h4", {class: "enc-h", text: "✅ Kafolat"}),
    li(["Server, hosting egasi va admin xabar matnini, fayl mazmunini va nomini o'qiy olmaydi: ular faqat shifrni ko'radi.",
        "Parolingiz serverga umuman bormaydi — faqat undan olingan qaytarib bo'lmaydigan kirish kaliti boradi. Maxfiy kalitlaringiz parol kalitida shifrlangan.",
        "Har bir xabar imzolangan: server yoki boshqa a'zo sizning nomingizdan soxta xabar yarata olmaydi.",
        "Ban qilingan a'zodan keyin guruh kaliti yangilanadi: u yangi xabarlarni o'qiy olmaydi."]),
    h("h4", {class: "enc-h", text: "⚠ Cheklovlar"}),
    li(["Guruhga qo'shilgan har kim (admin ham, agar a'zo bo'lsa) o'z qurilmasida xabarlarni ko'radi — bu ochiq guruh: ro'yxatdan o'tgan har kim kalit oladi.",
        "Server yashirincha SOXTA a'zo qo'shib, unga kalit o'ratishi mumkin. Himoya: «Kalitlar» bo'limida barmoq izlarini tekshiring; ilgari ko'rilgan kalit o'zgarsa, ogohlantirish chiqadi.",
        "Bu sahifaning kodini ham server beradi. Zararli server kodni almashtirishi mumkin: SRI faqat tashqi o'zgarishdan himoya qiladi. To'liq ishonch uchun kodni tekshiring yoki serverni o'zingiz yuriting.",
        "Metama'lumotlar ko'rinadi: kim, qachon, kimga (lichkada), xabar hajmi, IP. Profil (nickname, bio, rasm) ochiq.",
        "Parolni yo'qotsangiz, eski xabarlarni tiklab bo'lmaydi (kalit zaxirasi faqat parol bilan ochiladi).",
        "Lichkada «oldinga maxfiylik» yo'q (kalit doimiy). Shikoyat yuborganingizda faqat o'sha bitta xabar ixtiyoriy ochib beriladi."]));
}
$("encBtn").addEventListener("click", () => openInspector("flow"));

/* ---------- sozlamalar (Telegram uslubida: har bo'lim alohida sahifa) ---------- */
function openSettingsPage() {
  openPage(() => {
    const me = S.me, dark = document.documentElement.dataset.theme === "dark";
    const wrap = h("div", {}, pageHead("Sozlamalar"));
    wrap.append(h("button", {class: "set-card", type: "button", onclick: () => openProfile(me.id)},
      avatar(me, "m"), h("div", {class: "sc-t"}, h("b", {}, nameEl(me)), h("small", {text: "@" + me.username}))));
    wrap.append(gapEl(),
      setRow("user", "Mening akkauntim", openInfoPage),
      setRow("bell", "Bildirishnomalar va ovozlar", openNotifPage),
      ...(amAdmin() ? [setRow("edit", "Profil dizayni", () => openProfileEditor(S.me.id)), setRow("gear", "Server holati", openServerStatus)] : []),
      setRow("lock", "Maxfiylik va xavfsizlik", openPrivacyPage),
      setRow("emoji", "Reaksiya sozlamalari", openReactionSettings),
      setRow("speaker", "Karnay va kamera", openMediaPermPage),
      gapEl(),
      switchRow("moon", "Tungi mavzu", () => document.documentElement.dataset.theme === "dark", () => { toggleTheme(); }));
    wrap.append(gapEl(), setRow("logout", "Chiqish", () => { closeAllPages(); logout(); }, null, true));
    if (me.role !== "owner") wrap.append(setRow("trash", "Akkauntni o'chirish", deleteMyAccount, null, true));
    return wrap;
  }, true);
}
/* ---------- Server holati (faqat adminlar): jonli ko'rsatkichlar, har 2 soniyada yangilanadi ---------- */
function openServerStatus() {
  openPage(p => {
    if (p._ss) { p._ss.stop(); }
    const fmtDur = sec => { sec = Math.max(0, Math.floor(sec)); const d = Math.floor(sec / 86400), hh = Math.floor(sec % 86400 / 3600), m = Math.floor(sec % 3600 / 60), ss = sec % 60;
      return (d ? d + " kun " : "") + (d || hh ? hh + " soat " : "") + (m || hh || d ? m + " daq " : "") + ss + " s"; };
    const pct = (a, b) => b ? Math.max(0, Math.min(100, a / b * 100)) : 0;
    const dash = "—";
    const mk = (title) => { const val = h("div", {class: "ss-v", text: dash}), sub = h("div", {class: "ss-s", text: ""}), bar = h("i"), track = h("div", {class: "ss-bar"}, bar);
      const el = h("div", {class: "ss-card"}, h("div", {class: "ss-t", text: title}), val, track, sub);
      return {el, val, sub, bar, track}; };
    const cards = {cpu: mk("Protsessor (CPU)"), mem: mk("Xotira (RAM)"), disk: mk("Disk"), ping: mk("Aloqa tezligi"), ws: mk("Jonli ulanishlar"), http: mk("So'rovlar"), db: mk("Baza (SQLite)"), up: mk("Ishlash vaqti")};
    ["ping", "ws", "http", "db", "up"].forEach(k => cards[k].track.classList.add("hidden"));
    const statePill = h("span", {class: "ss-pill", text: "Yuklanmoqda…"});
    const live = h("span", {class: "ss-live", text: "● jonli"});
    const spark = h("div", {class: "ss-spark"});
    const hist = [];
    const drawSpark = () => {
      if (hist.length < 2) return;
      const mx = Math.max(60, ...hist), pts = hist.map((v, i) => (i / (hist.length - 1) * 300).toFixed(1) + "," + (52 - v / mx * 48).toFixed(1)).join(" ");
      spark.innerHTML = '<svg viewBox="0 0 300 56" preserveAspectRatio="none"><polyline fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" vector-effect="non-scaling-stroke" points="' + pts + '"/></svg>';
    };
    const lvl = (el, v) => { el.classList.toggle("warn", v >= 70 && v < 90); el.classList.toggle("bad", v >= 90); };
    const note = h("p", {class: "adm-note", text: "Ko'rsatkichlar Render serverining o'zidan olinadi va har 2 soniyada yangilanadi. CPU — faqat shu ilova protsessi (1 yadro = 100%)."});
    const body = h("div", {class: "pg-body ss-body"},
      h("div", {class: "ss-top"}, statePill, live),
      h("div", {class: "ss-grid"}, cards.up.el, cards.ping.el, cards.cpu.el, cards.mem.el, cards.disk.el, cards.ws.el, cards.http.el, cards.db.el),
      h("div", {class: "ss-card ss-wide"}, h("div", {class: "ss-t", text: "Aloqa kechikishi (oxirgi 30 o'lchov, ms)"}), spark),
      note);
    const st = {on: true, busy: false, timer: 0, fails: 0, seen: false};
    const tick = async () => {
      if (!st.on) return;
      // openPage quruvchini sahifa DOM'ga qo'shilishidan OLDIN chaqiradi: avval ko'rinishini kutamiz, faqat keyin "yopilgan" deb hisoblaymiz
      if (p.el && p.el.isConnected) st.seen = true;
      if (p.closing || (st.seen && !p.el.isConnected)) { stop(); return; }
      if (!st.seen) return;
      if (st.busy || document.hidden) return;
      st.busy = true;
      const t0 = performance.now();
      try {
        const d = await api("/admin/server-status");
        const rtt = performance.now() - t0; st.fails = 0;
        statePill.textContent = d.ok ? "✅ Server ishlayapti" : "⚠ Bazada muammo"; statePill.className = "ss-pill " + (d.ok ? "ok" : "bad");
        live.classList.remove("off");
        cards.up.val.textContent = fmtDur(d.uptime); cards.up.sub.textContent = "Versiya " + d.version + " • PID " + d.pid + " • oqimlar: " + d.threads;
        cards.ping.val.textContent = Math.round(rtt) + " ms"; cards.ping.val.className = "ss-v" + (rtt > 800 ? " bad" : rtt > 300 ? " warn" : "");
        cards.ping.sub.textContent = rtt > 800 ? "Juda sekin" : rtt > 300 ? "Sekinroq" : "Yaxshi";
        hist.push(Math.round(rtt)); if (hist.length > 30) hist.shift(); drawSpark();
        const c = d.cpu, cp = c.process_pct;
        cards.cpu.val.textContent = cp == null ? dash : cp.toFixed(1) + "%";
        cards.cpu.bar.style.width = Math.min(100, cp || 0) + "%"; lvl(cards.cpu.el, cp || 0);
        cards.cpu.sub.textContent = (c.load ? "Yuklama: " + c.load.map(x => x.toFixed(2)).join(" / ") + " • " : "") + c.cores + " yadro";
        const m = d.mem;
        if (m && m.total) { const pc = pct(m.used, m.total); cards.mem.val.textContent = fmtSize(m.used) + " / " + fmtSize(m.total); cards.mem.bar.style.width = pc + "%"; lvl(cards.mem.el, pc);
          cards.mem.sub.textContent = pc.toFixed(0) + "% band" + (m.process ? " • ilova: " + fmtSize(m.process) : ""); }
        else { cards.mem.val.textContent = m && m.process ? fmtSize(m.process) : dash; cards.mem.sub.textContent = "Ilova protsessi"; }
        const k = d.disk, dt = d.data || {};
        if (k) { const pc = pct(k.used, k.total); cards.disk.val.textContent = fmtSize(k.free) + " bo'sh"; cards.disk.bar.style.width = pc + "%"; lvl(cards.disk.el, pc);
          cards.disk.sub.textContent = "Ma'lumotlar: " + fmtSize(dt.total || 0) + " (baza " + fmtSize(dt.db || 0) + ", media " + fmtSize((dt.media || 0) + (dt.uploads || 0)) + ", emoji " + fmtSize(dt.emoji || 0) + ")"; }
        const w = d.ws; cards.ws.val.textContent = w.connections + " ulanish"; cards.ws.sub.textContent = "Onlayn: " + w.online + " • yashirin (away): " + w.away + " • eng ko'pi: " + w.peak;
        const r = d.http; cards.http.val.textContent = r.rps.toFixed(1) + " /s"; cards.http.sub.textContent = "Jami: " + r.total + " • xatolar (5xx): " + r.errors;
        const b = d.db; cards.db.val.textContent = b.ok ? b.ping_ms.toFixed(1) + " ms" : "XATO"; cards.db.val.className = "ss-v" + (b.ok ? "" : " bad");
        cards.db.sub.textContent = b.users + " foydalanuvchi • " + b.messages + " xabar • " + b.sessions + " sessiya";
      } catch (err) {
        if (err.message === "401") { stop(); return; }
        st.fails++; statePill.textContent = "❌ Server javob bermayapti"; statePill.className = "ss-pill bad"; live.classList.add("off");
      } finally { st.busy = false; }
    };
    const onVis = () => { if (!document.hidden && st.on) tick(); };
    const stop = () => { st.on = false; clearInterval(st.timer); document.removeEventListener("visibilitychange", onVis); };
    p._ss = {stop};
    st.timer = setInterval(tick, 2000);
    requestAnimationFrame(() => requestAnimationFrame(tick));        // sahifa DOM'ga qo'shilgach darhol birinchi o'lchov
    document.addEventListener("visibilitychange", onVis);
    return h("div", {}, pageHead("Server holati"), body);
  });
}


function openInfoPage() {
  openPage(p => {
    const me = S.me;
    const avBox = h("div", {class: "tg-top inf-top"});
    const paintAvatar = () => {
      avBox.textContent = "";
      avBox.append(h("div", {class: "inf-av"}, avatar(S.me, "l"),
        h("button", {class: "inf-cam", type: "button", "aria-label": "Profil rasmini o'zgartirish", onclick: () => $("file").click()}, icon("camera"))));
    };
    paintAvatar();
    const gal = h("div", {class: "gal inf-gal"});
    const nick = h("input", {type: "text", class: "fld", maxlength: "24", "aria-label": "Nickname"}); nick.value = me.nickname;
    const bio = h("textarea", {class: "fld", rows: "3", maxlength: "140", placeholder: "O'zingiz haqingizda…", "aria-label": "Bio"}); bio.value = me.bio || "";
    const cnt = h("span", {class: "inf-cnt", text: String(140 - bio.value.length)});
    bio.addEventListener("input", () => { cnt.textContent = String(140 - bio.value.length); });
    const loadGallery = async () => {
      try {
        const j = await api("/avatars");
        gal.textContent = "";
        j.avatars.forEach(a => {
          const del = h("button", {type: "button", title: "O'chirish", "aria-label": "O'chirish"}, icon("close"));
          del.addEventListener("click", async e => { e.stopPropagation(); try { await api("/avatars/" + a.id, {method: "DELETE"}); loadGallery(); } catch (err) { toast(err.message, "error"); } });
          const g = h("div", {class: "gi" + (a.active ? " act" : ""), title: a.active ? "Faol rasm" : "Faollashtirish"}, h("img", {src: a.url, alt: ""}), del);
          g.addEventListener("click", async () => { if (a.active) return; try { await api("/avatars/" + a.id + "/use", {method: "POST"}); loadGallery(); } catch (err) { toast(err.message, "error"); } });
          gal.append(g);
        });
        if (j.avatars.some(a => a.active)) gal.append(h("button", {class: "btn ghost sm", type: "button", onclick: async () => { try { await api("/avatar/clear", {method: "POST"}); loadGallery(); } catch (err) { toast(err.message, "error"); } }}, "Rasmni olib tashlash"));
        setTimeout(paintAvatar, 500);
      } catch (_) {}
    };
    S.reloadGallery = loadGallery; loadGallery();
    const save = async btn => {
      btn.disabled = true;
      try {
        const j = await api("/profile", {method: "PATCH", body: {nickname: nick.value, bio: bio.value}});
        if (j && j.me) { upsertUser(j.me); renderList(); renderHeader(); renderMessages(false); }
        toast("Profil saqlandi", "ok");
      } catch (err) { toast(err.message, "error"); }
      btn.disabled = false;
    };
    p.refresh = paintAvatar;
    return h("div", {}, pageHead("Ma'lumot"), avBox, gal,
      h("div", {class: "inf-form"},
        h("label", {class: "fl"}, "Nickname", nick),
        h("div", {class: "fl"}, h("span", {class: "inf-lab"}, "Bio", cnt), bio, h("small", {class: "inf-hint", text: "Yosh, kasb yoki shahar kabi qisqa ma'lumot. Havola (https://…) va @username qo'ysangiz, profilingizda bosiladigan bo'ladi."})),
        h("div", {class: "tg-row copy", role: "button", tabindex: "0", title: "Nusxalash", onclick: () => copyText("@" + me.username)},
          h("div", {class: "tg-val", text: "@" + me.username}), h("div", {class: "tg-lab", text: "Username (o'zgarmaydi)"})),
        h("button", {class: "btn", type: "button", onclick: e => save(e.currentTarget)}, "Saqlash")),
      isStaff(me) ? h("div", {class: "inf-look"}, lookSection()) : null);
  });
}

function openNotifPage() {
  openPage(() => {
    const st = Push.state();
    const pushHint = !st.ok ? (st.why === "ios-install" ? "iPhone'da avval ilovani bosh ekranga o'rnating (Ulashish → Bosh ekranga qo'shish)." : "Bu brauzer bildirishnomalarni qo'llab-quvvatlamaydi.")
      : st.permission === "denied" ? "Bildirishnomalar brauzer sozlamalarida bloklangan. Sayt sozlamalaridan ruxsat bering."
      : "Yoqilsa, brauzer yopiq bo'lsa ham xabar keladi. Xabar matni bildirishnomada ko'rsatilmaydi.";
    return h("div", {}, pageHead("Bildirishnomalar va ovozlar"),
      switchRow("bell", "Bildirishnomalar", () => Push.state().on, async on => {
        if (on) { await Push.enable(api); toast("Bildirishnomalar yoqildi", "ok"); }
        else { await Push.disable(api); toast("Bu qurilmada bildirishnomalar o'chirildi", "info"); }
      }, pushHint),
      gapEl(),
      switchRow("speaker", "Xabar ovozi", sndOn, on => {
        try { localStorage.setItem(LS_SND, on ? "on" : "off"); } catch (_) {}
        if (on) ting(true);
      }, "Ilova ochiq bo'lganda boshqa suhbatga xabar kelsa qisqa ovoz chiqadi."));
  });
}

async function changePassword(oldPw, newPw) {          // maxfiy kalitlar yangi parol bilan brauzerda QAYTA O'RALADI
  if (!oldPw) throw new Error("Eski parolni kiriting");
  if (newPw.length < 6) throw new Error("Yangi parol kamida 6 belgi bo'lishi kerak");
  const info = await api("/me"), e = info.e2ee, un = S.me.username;
  const ko = await E2E.deriveFromPassword(un, oldPw, e.kdf_iter || E2E.KDF_DEFAULT);
  let ident; try { ident = await E2E.unwrapIdentity(e.key_blob, ko.kek, un); } catch (_) { throw new Error("Eski parol noto'g'ri"); }
  const kn = await E2E.deriveFromPassword(un, newPw, E2E.KDF_DEFAULT);
  await api("/password", {method: "POST", body: {old: ko.auth, new: kn.auth, key_blob: await E2E.wrapIdentity(ident, kn.kek, un), kdf_iter: E2E.KDF_DEFAULT}});
}
/* Vaqt oralig'i: "2 soat 5 daq" */
function fmtSpan(sec) {
  sec = Math.max(0, Math.floor(sec));
  const d = Math.floor(sec / 86400), hr = Math.floor(sec % 86400 / 3600), m = Math.floor(sec % 3600 / 60);
  if (d) return d + " kun " + hr + " soat";
  if (hr) return hr + " soat " + m + " daq";
  if (m) return m + " daqiqa";
  return "1 daqiqadan kam";
}

/* Maxfiylik va xavfsizlik: faqat 2 ta bo'lim — parolni almashtirish va ulangan qurilmalar */
function openPrivacyPage() {
  openPage(p => {
    p.refresh = null;
    return h("div", {}, pageHead("Maxfiylik va xavfsizlik"),
      secTitle("Kirish"),
      switchRow("lock", "Har kirishda login so'rash", () => !stayOn(), async () => { await toggleStay(); },
        "Yoqilsa, sahifa har safar ochilganda username va parol so'raladi. O'chirilsa, bu qurilmada login so'ralmasdan kirasiz — qurilmani begonalarga bermang."),
      gapEl(),
      secTitle("Xavfsizlik"),
      setRow("key", "Parolni almashtirish", openChangePasswordPage),
      setRow("devices", "Ulangan qurilmalar", openDevicesPage),
      h("p", {class: "tg-hint", text: "Akkauntingizga qaysi qurilmalardan kirilganini ko'ring va keraklisini o'zingiz chiqarib yuboring."}));
  });
}

/* 1-bo'lim: parolni almashtirish (eski parol, yangi parol, yangi parolni takrorlash) */
function openChangePasswordPage() {
  openPage(() => {
    const fld = (label, ac) => { const i = h("input", {type: "password", class: "fld", autocomplete: ac, maxlength: "128", "aria-label": label}); return {i, lab: h("label", {class: "fl"}, label, i)}; };
    const old = fld("Eski parol", "current-password"), nw = fld("Yangi parol (kamida 6 belgi)", "new-password"), rep = fld("Yangi parolni qayta kiriting", "new-password");
    const msg = h("p", {class: "tg-hint flat", role: "alert"});
    const btn = h("button", {class: "btn", type: "button", text: "Parolni almashtirish"});
    const submit = async () => {
      msg.textContent = ""; msg.style.color = "";
      const fail = t => { msg.textContent = t; msg.style.color = "var(--err)"; };
      if (!old.i.value) return fail("Eski parolni kiriting");
      if (nw.i.value.length < 6) return fail("Yangi parol kamida 6 belgi bo'lishi kerak");
      if (nw.i.value !== rep.i.value) return fail("Yangi parollar bir-biriga mos kelmadi");
      if (nw.i.value === old.i.value) return fail("Yangi parol eskisidan farq qilishi kerak");
      btn.disabled = true; btn.textContent = "Almashtirilmoqda…";
      try {
        await changePassword(old.i.value, nw.i.value);
        toast("Parol almashtirildi. Boshqa qurilmalardan chiqarildingiz", "ok");
        closePage();
      } catch (err) { fail(err.message); btn.disabled = false; btn.textContent = "Parolni almashtirish"; }
    };
    btn.addEventListener("click", submit);
    [old, nw, rep].forEach(f => f.i.addEventListener("keydown", e => { if (e.key === "Enter") submit(); }));
    return h("div", {}, pageHead("Parolni almashtirish"),
      h("div", {class: "inf-form"}, old.lab, nw.lab, rep.lab, msg, btn),
      h("p", {class: "tg-hint", text: "Parol almashtirilganda shifrlash kalitlaringiz yangi parol bilan brauzerda qayta o'raladi, boshqa barcha qurilmalar akkauntdan chiqariladi."}));
  });
}

/* 2-bo'lim: akkauntga ulangan qurilmalar (sessiyalar) — qachon kirgan, qancha vaqt onlayn, chiqarib yuborish */
function openDevicesPage() {
  openPage(p => {
    const box = h("div", {class: "dev-list"}, h("div", {class: "none", text: "Yuklanmoqda…"}));
    const load = async () => {
      try {
        const j = await api("/sessions");
        box.textContent = "";
        const cur = j.sessions.find(s => s.current), others = j.sessions.filter(s => !s.current);
        const item = s => h("div", {class: "dev-i"},
          icon(/iPhone|iPad|Android/.test(s.device) ? "phone" : "devices"),
          h("div", {class: "dev-t"},
            h("b", {text: s.device + (s.current ? " (shu qurilma)" : "")}),
            h("small", {text: "Kirgan: " + fmtDay(s.created)}),
            h("small", {text: s.online ? "Hozir onlayn" : "Oxirgi faollik: " + ago(s.last_active)}),
            h("small", {text: "Onlayn bo'lgan vaqt: " + fmtSpan(s.duration)})),
          s.current ? null : h("button", {class: "btn ghost sm", type: "button", onclick: async ev => {
            if (!await confirmDlg(s.device + " qurilmasi akkauntdan chiqariladi.", {title: "Qurilmani chiqarish", okText: "Chiqarish", danger: true})) return;
            ev.target.disabled = true;
            try { await api("/sessions/" + s.id, {method: "DELETE"}); toast("Qurilma chiqarildi", "ok"); } catch (err) { toast(err.message, "error"); }
            load();
          }}, "Chiqarish"));
        if (cur) box.append(secTitle("Hozirgi qurilma"), item(cur));
        box.append(secTitle("Boshqa qurilmalar", others.length));
        if (!others.length) box.append(h("div", {class: "none", text: "Boshqa qurilmalar ulanmagan"}));
        others.forEach(s => box.append(item(s)));
        if (others.length) box.append(h("div", {class: "tg-modwrap"}, h("button", {class: "btn danger sm", type: "button", onclick: async () => {
          if (!await confirmDlg("Hozirgisidan boshqa barcha qurilmalar akkauntdan chiqariladi.", {title: "Boshqa qurilmalardan chiqish", okText: "Hammasini chiqarish", danger: true})) return;
          try { await api("/sessions/revoke-others", {method: "POST"}); toast("Boshqa qurilmalar chiqarildi", "ok"); } catch (err) { toast(err.message, "error"); }
          load();
        }}, "Boshqa barcha qurilmalardan chiqish")));
      } catch (err) { box.textContent = ""; box.append(h("div", {class: "none", text: err.message})); }
    };
    p.refresh = null;
    load();
    const timer = setInterval(() => { if (!p.el.isConnected || p.closing) clearInterval(timer); else load(); }, 30000);     // vaqtlar jonli yangilanadi
    return h("div", {}, pageHead("Ulangan qurilmalar"), box);
  });
}

function openReactionSettings() {
  openPage(() => {
    const mk = e => {
      const b = h("button", {class: "rx-opt" + (e === rxPrefs.emoji ? " on" : ""), type: "button", "aria-label": e}, rxGlyph(e));
      b.addEventListener("click", () => {
        rxPrefs.emoji = e; rxSave();
        pv.querySelectorAll(".rx-opt").forEach(x => x.classList.toggle("on", x === b));
        const r = b.getBoundingClientRect(); rxBurst(e, r.left + r.width / 2, r.top);
      });
      return b;
    };
    const pv = rxPackView(mk, {k: null}, "rx-grid");
    const grid = h("div", {class: "rx-gwrap" + (rxPrefs.dbl ? "" : " off")}, pv);
    return h("div", {}, pageHead("Reaksiya sozlamalari"),
      switchRow("emoji", "Ikki marta bosganda reaksiya", () => rxPrefs.dbl, on => { rxPrefs.dbl = on; rxSave(); grid.classList.toggle("off", !on); },
        "Xabar yoki post ustiga ketma-ket 2 marta bosilsa, pastdagi reaksiya qo'yiladi. O'chirilsa, reaksiyani xabar menyusidan tanlaysiz."),
      gapEl(),
      h("div", {class: "inf-form"}, h("div", {class: "sec-t flat"}, h("span", {text: "Ikki marta bosganda qo'yiladigan reaksiya"})), grid,
        h("p", {class: "tg-hint flat", text: "Bir xabarga bitta reaksiya qo'yiladi. Reaksiya ustiga bosib uni olib tashlash yoki almashtirish mumkin."})));
  });
}

/* Karnay va kamera: qurilmalar haqida ma'lumot, ruxsat berish / ruxsatni o'chirish */
const PERM_TXT = {granted: "Ruxsat berilgan", denied: "Bloklangan", prompt: "Hali so'ralmagan", unknown: "Noma'lum"};
async function permState(name) { try { return (await navigator.permissions.query({name})).state; } catch (_) { return "unknown"; } }
async function requestPerm(kind) {
  if (kind === "notifications") {
    if (!("Notification" in window)) throw new Error("Bu brauzer bildirishnomalarni qo'llab-quvvatlamaydi");
    const r = await Notification.requestPermission();
    if (r !== "granted") throw new Error("Ruxsat berilmadi");
    return;
  }
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) throw new Error("Bu brauzer kamera/mikrofonni qo'llab-quvvatlamaydi (yoki sahifa HTTPS emas)");
  try {
    const s = await navigator.mediaDevices.getUserMedia(kind === "camera" ? {video: true} : {audio: true});
    s.getTracks().forEach(t => t.stop());
  } catch (err) { throw new Error(err && err.name === "NotFoundError" ? "Bunday qurilma topilmadi" : "Ruxsat berilmadi. Brauzerning sayt sozlamalaridan ruxsat bering"); }
}
function openMediaPermPage() {
  openPage(() => {
    const perms = h("div", {}), devs = h("div", {});
    const defs = [["camera", "videocam", "Kamera", "camera"], ["microphone", "mic", "Mikrofon", "microphone"], ["notifications", "bell", "Bildirishnomalar", "notifications"]];
    const load = async () => {
      const rows = [];
      for (const [name, ic, label, kind] of defs) {
        const stt = await permState(name === "notifications" ? "notifications" : name);
        const granted = stt === "granted";
        rows.push(h("div", {class: "perm-i"}, icon(ic), h("div", {class: "perm-t"}, h("b", {text: label}), h("small", {class: "st-" + stt, text: PERM_TXT[stt] || PERM_TXT.unknown})),
          granted
            ? h("button", {class: "btn ghost sm", type: "button", onclick: () => confirmDlg("Brauzer ruxsatni sahifaning o'zidan olib tashlashga yo'l qo'ymaydi. Brauzerda: manzil satridagi qulf (yoki sozlamalar) belgisi → Sayt sozlamalari → «" + label + "» ni «Bloklash» yoki «So'rash» ga o'zgartiring.", {title: label + ": ruxsatni o'chirish", okText: "Tushunarli"})}, "O'chirish")
            : stt === "denied"
              ? h("button", {class: "btn ghost sm", type: "button", onclick: () => confirmDlg("Ruxsat brauzerda bloklangan. Qulf belgisi → Sayt sozlamalari → «" + label + "» ni «Ruxsat berish» ga o'zgartiring, so'ng sahifani yangilang.", {title: label + ": bloklangan", okText: "Tushunarli"})}, "Qanday?")
              : h("button", {class: "btn sm", type: "button", onclick: async () => { try { await requestPerm(kind); toast(label + ": ruxsat berildi", "ok"); } catch (err) { toast(err.message, "error"); } load(); }}, "Ruxsat berish")));
      }
      perms.textContent = ""; perms.append(...rows);
      devs.textContent = "";
      let list = [];
      try { list = navigator.mediaDevices && navigator.mediaDevices.enumerateDevices ? await navigator.mediaDevices.enumerateDevices() : []; } catch (_) {}
      const group = (kindName, ic, title) => {
        const items = list.filter(d => d.kind === kindName);
        devs.append(secTitle(title, items.length));
        if (!items.length) devs.append(h("div", {class: "perm-none", text: kindName === "audiooutput" ? "Brauzer karnaylar ro'yxatini ko'rsatmaydi (standart karnay ishlatiladi)" : "Qurilma topilmadi"}));
        items.forEach((d, i) => devs.append(h("div", {class: "tg-row"}, icon(ic), h("span", {text: d.label || (title.replace(/lar$/, "") + " " + (i + 1) + " (nomi ruxsatdan keyin ko'rinadi)")}))));
      };
      group("audioinput", "mic", "Mikrofonlar"); group("videoinput", "videocam", "Kameralar"); group("audiooutput", "speaker", "Karnaylar");
    };
    load();
    return h("div", {}, pageHead("Karnay va kamera"), secTitle("Ruxsatlar"), perms,
      h("p", {class: "tg-hint", text: "Kamera va mikrofon faqat ovozli yoki video xabar yozganingizda ishlatiladi."}), gapEl(), devs);
  });
}

async function deleteMyAccount() {
  const ok = await confirmDlg("Akkauntingiz butunlay o'chiriladi: profil, rasmlar va parol yo'qoladi. Yozgan xabarlaringiz chatda \"Deleted account\" nomi bilan qoladi. Buni qaytarib bo'lmaydi.",
    {title: "Akkauntni o'chirish", okText: "Davom etish", danger: true});
  if (!ok) return;
  const pw = await promptDlg("Parolni tasdiqlang", "Akkauntni o'chirish uchun parolingizni kiriting:", "", {type: "password", okText: "O'chirish", danger: true});
  if (pw === null) return;
  try {
    const e = (await api("/me")).e2ee, kd = await E2E.deriveFromPassword(S.me.username, pw, e.kdf_iter || E2E.KDF_DEFAULT);
    await api("/account/delete", {method: "POST", body: {password: kd.auth}}); showAuth("Akkauntingiz o'chirildi");
  }
  catch (err) { toast(err.message, "error"); }
}
const PRESETS = ["#f7b733", "#7b61ff", "#ef4444", "#f97316", "#22c55e", "#14b8a6", "#3b82f6", "#ec4899"];
function colorSection(onChange) {
  const sec = h("div", {class: onChange ? "bd-colors" : "setsec"}, onChange ? h("div", {class: "bd-lab", text: "Ism rangi"}) : h("h4", {text: "Profil rangi"}));
  const preview = onChange ? null : h("div", {class: "pname"}), sw = h("div", {class: "swatches"});
  if (preview) { preview.style.fontSize = "17px"; preview.style.margin = "0 0 10px"; }
  hScroll(sw);
  const save = async c => {
    try {
      const j = await api("/profile", {method: "PATCH", body: {color: c}});
      upsertUser(j.me); paint(); renderList(); renderHeader(); renderMessages(false);
      if (onChange) onChange();
      toast(c ? "Rang saqlandi" : "Standart rang tiklandi", "ok");
    } catch (err) { toast(err.message, "error"); }
  };
  const paint = () => {
    if (preview) { preview.textContent = ""; preview.append(nameEl(S.me, {big: true})); }
    sw.textContent = "";
    const cur = (S.me.color || "").toLowerCase();
    PRESETS.forEach(c => {
      const b = h("button", {type: "button", class: "sw" + (cur === c ? " on" : ""), title: c, "aria-label": c});
      b.style.background = c; b.addEventListener("click", () => save(c)); sw.append(b);
    });
    const pick = h("input", {type: "color"}); pick.value = HEX.test(cur) ? cur : TONES[S.me.role];
    pick.addEventListener("change", () => save(pick.value));
    sw.append(h("label", {class: "sw-custom", title: "Boshqa rang tanlash"}, pick),
      h("button", {type: "button", class: "btn ghost sm", text: "Standart", onclick: () => save("")}));
  };
  paint(); sec.append(...(preview ? [preview] : []), sw);
  return sec;
}
$("file").addEventListener("change", async () => {
  const f = $("file").files[0]; $("file").value = ""; if (!f) return;
  if (f.size > 2 * 1024 * 1024) { toast("Rasm 2 MB dan oshmasligi kerak", "error"); return; }
  const fd = new FormData(); fd.append("file", f);
  try { await api("/avatar", {method: "POST", body: fd}); toast("Profil rasmi yangilandi", "ok"); if (S.reloadGallery) S.reloadGallery(); }
  catch (err) { toast(err.message, "error"); }
});

/* =====================================================================
   MOBIL (v5): orqaga tugmasi, klaviatura, uzoq bosish, chapga surish, varaqni pastga tortish
   ===================================================================== */
const haptic = ms => { try { if (navigator.vibrate) navigator.vibrate(ms); } catch (_) {} };
document.addEventListener("touchstart", () => {}, {passive: true});          // iOS: :active holati ishlashi uchun

/* ---- Orqaga tugmasi / jest: chat, oyna, rasm, menyu, dialog — har biri tarixda alohida qatlam ---- */
const NAV = {stack: [], ops: [], busy: false, timer: 0};
const NAV_CLOSE = {
  chat: () => closeChat(), modal: () => closeModal(), lb: () => closeLightbox(), avv: () => closeAvatarViewer(true),
  ctx: () => closeCtx(), sel: () => exitSelect(), dlg: () => { if (S.dlgCancel) S.dlgCancel(); },
  cm: () => Channels.closeComments(true),                   // kanal posti izohlari paneli
  drawer: () => closeDrawerNow(),                           // chap menyu
  ...Object.fromEntries(Array.from({length: 12}, (_, i) => ["pg" + i, () => closePage()])),   // sahifalar (o'ngdan chapga)
};
function navKick() {                                  // tarix amallari ketma-ket bajariladi (back() tugamay turib push qilinmaydi)
  while (!NAV.busy && NAV.ops.length) {
    const op = NAV.ops.shift();
    if (op.t === "push") { try { history.pushState({tc: op.d}, ""); } catch (_) {} }
    else {
      NAV.busy = true; clearTimeout(NAV.timer);
      NAV.timer = setTimeout(() => { NAV.busy = false; navKick(); }, 450);
      try { history.back(); } catch (_) { NAV.busy = false; }
    }
  }
}
function navPush(name) {
  if (NAV.stack.includes(name)) return;
  NAV.stack.push(name); NAV.ops.push({t: "push", d: NAV.stack.length}); navKick();
}
function navPop(name) {
  const i = NAV.stack.lastIndexOf(name); if (i < 0) return;
  const top = i === NAV.stack.length - 1;
  NAV.stack.splice(i, 1);
  if (top) { NAV.ops.push({t: "back"}); navKick(); }
}
function navReset() {
  const n = NAV.stack.length; NAV.stack.length = 0; NAV.ops.length = 0;
  if (n) try { history.go(-n); } catch (_) {}
}
addEventListener("popstate", e => {
  if (NAV.busy) { NAV.busy = false; clearTimeout(NAV.timer); navKick(); return; }   // o'zimiz chaqirgan back()
  const target = (e.state && e.state.tc) | 0;
  while (NAV.stack.length > target) { const fn = NAV_CLOSE[NAV.stack.pop()]; if (fn) fn(); }
});
try { if (history.state && history.state.tc) history.replaceState(null, ""); } catch (_) {}

/* ---- Ko'rinadigan oyna + yozish paneli qo'riqchisi ----
   Ilova HAR DOIM haqiqiy ko'rinadigan oynaga (visualViewport) sig'adi, yozish paneli esa klaviatura ustida qoladi.
   Ba'zi qurilmalarda (eski Android brauzerlari, WebView, Samsung/MIUI, iOS PWA) ilovadan chiqib-kirganda, chatdan chiqib-kirganda
   yoki klaviatura yopilganda oyna o'lchami yangilanmay qolardi va yozish paneli ekrandan tashqarida qolib ketardi.
   Qo'riqchi paneli har doim tekshiradi va o'zi tuzatadi. */
const Composer = (() => {
  const vv = window.visualViewport;
  const root = document.documentElement;
  const touchy = () => COARSE || matchMedia("(max-width:760px)").matches || (navigator.maxTouchPoints || 0) > 0;
  const isField = el => !!el && (el.tagName === "TEXTAREA" || (el.tagName === "INPUT" && !/^(checkbox|radio|button|submit|reset|file|range|color|image)$/i.test(el.type)));
  const viewH = () => Math.round(vv ? vv.height : innerHeight);
  const viewTop = () => Math.round(vv ? vv.offsetTop : 0);
  let raf = 0;

  const sync = () => {
    raf = 0;
    if (!touchy() || (vv && vv.scale > 1.02)) {          // kompyuter yoki foydalanuvchi yaqinlashtirgan: CSS o'zi hal qiladi
      root.style.removeProperty("--vvh"); root.style.removeProperty("--vvt"); document.body.classList.remove("kb"); return;
    }
    const hgt = viewH();
    if (hgt >= 120) { root.style.setProperty("--vvh", hgt + "px"); root.style.setProperty("--vvt", viewTop() + "px"); }   // 120 dan kichik = noto'g'ri o'lchov (fondan qaytishda bo'ladi), e'tibor berilmaydi
    document.body.classList.toggle("kb", innerHeight - hgt > 120 && isField(document.activeElement));
    if (scrollY || document.scrollingElement && document.scrollingElement.scrollTop) scrollTo(0, 0);
    const b = $("msgs"); if (b && b._stick) b.scrollTop = b.scrollHeight;
  };
  const queue = () => { if (!raf) raf = requestAnimationFrame(sync); };

  /* Chat ochiq bo'lsa: yozish paneli ko'rinadimi? Yo'q bo'lsa sabablarini bartaraf qiladi. */
  const guard = () => {
    const chat = $("chat"), c = $("composer"), ta = $("inp");
    if (!chat || !c || !ta) return;
    sync();
    if (!S.active || !S.me) return;
    if (chat.classList.contains("hidden")) { chat.classList.remove("hidden"); $("empty").classList.add("hidden"); }
    if (S.active && isMobile() && !document.body.classList.contains("in-chat") && !PG.list.length) document.body.classList.add("in-chat");
    const gate = syncChatGate();                                             // readonly/dead/locked — haqiqiy holatdan
    if (!S.sel) chat.classList.remove("selecting");                          // tanlash rejimi tugagan, lekin klass qolib ketgan
    if (c.classList.contains("recording") && !S.rec && !S.recBusy && !S.starting) setRecUi("off");   // yozuv yo'q, lekin panel \"yozilmoqda\" holatida qotib qolgan
    const gated = gate.chanRO || gate.dead || gate.locked || chat.classList.contains("selecting");
    if (gated) return;                                                       // panel ataylab yashirilgan
    c.hidden = false; c.removeAttribute("aria-hidden");
    let r = c.getBoundingClientRect();
    const limit = viewTop() + viewH() + 2;
    if (!r.height || r.bottom > limit || r.top < 0) {                        // ekrandan tashqarida yoki o'lchami 0
      root.style.setProperty("--vvh", viewH() + "px"); root.style.setProperty("--vvt", viewTop() + "px");
      [document.scrollingElement, document.body, $("main"), chat].forEach(e => { if (e && e.scrollTop) e.scrollTop = 0; });
      scrollTo(0, 0);
      void c.offsetHeight;
      r = c.getBoundingClientRect();
      if (!r.height) c.style.setProperty("display", "flex", "important");
    } else if (c.style.display) c.style.removeProperty("display");
    if (!c.classList.contains("recording") && ta.getBoundingClientRect().height < 20) { ta.style.height = ""; autosize(); }   // yozish maydoni qisilib ketgan
  };

  if (vv) { vv.addEventListener("resize", queue); vv.addEventListener("scroll", queue); }
  addEventListener("resize", queue);
  addEventListener("orientationchange", () => { setTimeout(queue, 350); setTimeout(guard, 600); });
  addEventListener("pageshow", () => { queue(); setTimeout(guard, 50); setTimeout(guard, 500); });
  addEventListener("focus", () => setTimeout(guard, 80));
  addEventListener("online", () => setTimeout(guard, 80));
  document.addEventListener("visibilitychange", () => { if (!document.hidden) { queue(); setTimeout(guard, 60); setTimeout(guard, 500); setTimeout(guard, 1500); } });
  document.addEventListener("focusin", () => setTimeout(queue, 60));
  document.addEventListener("focusout", () => { setTimeout(queue, 120); setTimeout(queue, 500); setTimeout(guard, 700); });   // klaviatura yopilgach oyna o'lchamini qayta o'qiymiz
  setInterval(() => { if (!document.hidden && S.active) guard(); }, 1500);        // so'nggi himoya: hech qanday hodisa kelmasa ham tuzatadi
  queue();
  return {guard, sync};
})();

/* ---- Uzoq bosish (ro'yxat elementlari uchun; iOS'da contextmenu hodisasi yo'q) ---- */
function longPress(el, fn) {
  let t = 0, sx = 0, sy = 0, quiet = 0;
  el.addEventListener("touchstart", e => {
    if (e.touches.length !== 1) return;
    sx = e.touches[0].clientX; sy = e.touches[0].clientY; clearTimeout(t);
    t = setTimeout(() => { quiet = Date.now() + 600; haptic(12); fn(sx, sy); }, 480);
  }, {passive: true});
  el.addEventListener("touchmove", e => { const p = e.touches[0]; if (Math.abs(p.clientX - sx) > 9 || Math.abs(p.clientY - sy) > 9) clearTimeout(t); }, {passive: true});
  ["touchend", "touchcancel"].forEach(ev => el.addEventListener(ev, () => clearTimeout(t), {passive: true}));
  el.addEventListener("click", e => { if (Date.now() < quiet) { e.preventDefault(); e.stopImmediatePropagation(); } }, true);
}

/* ---- Xabar pufagi: uzoq bosish = menyu; chapga surish = javob berish (Telegram kabi) ---- */
function canSwipeReply(m) {
  const c = $("chat");
  return !S.sel && !m.service && !m.locked && !m.bad && !m.legacy && !c.classList.contains("dead") && !c.classList.contains("locked");
}
function attachTouch(bubble, row, m) {
  const TH = 56;                                       // javob uchun yetarli surish (px)
  let tPress = 0, tCtx = 0, sx = 0, sy = 0, dx = 0, mode = "", ind = null, hit = false, quiet = 0;
  const stopTimers = () => { clearTimeout(tPress); clearTimeout(tCtx); tPress = tCtx = 0; row.classList.remove("pressing"); };
  bubble.addEventListener("click", e => { if (Date.now() < quiet) { e.preventDefault(); e.stopPropagation(); } }, true);   // uzoq bosishdan keyin rasm/fayl ochilmasin
  bubble.addEventListener("touchstart", e => {
    stopTimers(); dx = 0; hit = false;
    if (S.sel || e.touches.length !== 1) { mode = "x"; return; }
    mode = "";
    const t = e.touches[0]; sx = t.clientX; sy = t.clientY;
    tPress = setTimeout(() => row.classList.add("pressing"), 140);
    tCtx = setTimeout(() => { tCtx = 0; mode = "ctx"; row.classList.remove("pressing"); haptic(12); openCtx(sx, sy, m); }, 450);
  }, {passive: true});
  bubble.addEventListener("touchmove", e => {
    if (mode !== "" && mode !== "swipe") return;
    const t = e.touches[0], mx = t.clientX - sx, my = t.clientY - sy;
    if (mode === "") {
      if (Math.abs(mx) < 9 && Math.abs(my) < 9) return;            // barmoq titrashi uzoq bosishni bekor qilmaydi
      stopTimers();
      const skip = e.target.closest && e.target.closest(".vtrack,.vspd,.mplayer,.code-scroll,.term-scroll,.cbtn");
      if (Math.abs(mx) < Math.abs(my) * 1.5 || mx > 0 || skip || !canSwipeReply(m)) { mode = "scroll"; return; }
      mode = "swipe"; bubble.style.transition = "none";
      ind = h("span", {class: "swipe-ind", "aria-hidden": "true"}, icon("reply")); row.append(ind);
    }
    const raw = mx < 0 ? -mx : 0;                                  // barmoq yurgan masofa
    dx = -(raw <= TH ? raw : TH + (raw - TH) * 0.2);              // chegaradan keyin qarshilik (pufak chetdan chiqib ketmaydi)
    const k = Math.min(1, raw / TH);
    bubble.style.transform = "translateX(" + dx + "px)";
    ind.style.opacity = String(k); ind.style.transform = "scale(" + (0.6 + 0.4 * k) + ")";
    const nowHit = raw >= TH;
    if (nowHit !== hit) { hit = nowHit; row.classList.toggle("swipe-hit", hit); if (hit) haptic(8); }
  }, {passive: true});
  const end = cancelled => {
    stopTimers();
    if (mode === "ctx") quiet = Date.now() + 600;
    if (mode === "swipe") {
      const fire = !cancelled && hit;
      bubble.style.transition = ""; bubble.style.transform = "";
      if (ind) { const el = ind; el.style.opacity = "0"; setTimeout(() => el.remove(), 220); ind = null; }
      row.classList.remove("swipe-hit");
      quiet = Date.now() + 400;
      if (fire) startReply(m);
    }
    mode = ""; hit = false;
  };
  bubble.addEventListener("touchend", () => end(false), {passive: true});
  bubble.addEventListener("touchcancel", () => end(true), {passive: true});
}

/* ---- Pastdan chiqadigan oyna: sarlavhadan pastga tortib yopiladi ---- */
(() => {
  const sheet = $("sheet");
  let y0 = 0, dy = 0, drag = false;
  sheet.addEventListener("touchstart", e => {
    drag = false;
    if (!isMobile() || e.touches.length !== 1 || !e.target.closest(".sh-head, .pbanner")) return;
    y0 = e.touches[0].clientY; dy = 0; drag = true;
  }, {passive: true});
  sheet.addEventListener("touchmove", e => {
    if (!drag) return;
    dy = Math.max(0, e.touches[0].clientY - y0);
    if (dy > 6) { sheet.style.transition = "none"; sheet.style.transform = "translateY(" + dy + "px)"; }
  }, {passive: true});
  const end = () => {
    if (!drag) return; drag = false;
    const close = dy > 110; dy = 0;
    sheet.style.transition = "transform .2s ease";
    sheet.style.transform = close ? "translateY(100%)" : "";
    setTimeout(() => { if (close) closeModal(); sheet.style.transition = ""; sheet.style.transform = ""; }, 200);
  };
  sheet.addEventListener("touchend", end, {passive: true});
  sheet.addEventListener("touchcancel", end, {passive: true});
})();

/* ---------------- ishga tushirish ---------------- */
/* ---------------- kanallar (js/channels.js) ---------------- */
const chBridge = {api, h, icon, toast, confirmDlg, promptDlg, openModal, closeModal, sheetHead, navPush, navPop, hhmm, dayLabel, avatar, nameEl,
                  amAdmin: () => amAdmin(), me: () => S.me, openMenu, openProfile: id => openProfile(id), infoPage, closePage, closeAllPages, refreshPages, chanData: id => S.chn.get(id), setChannelList, chanAvatar, patchPost,
                  openChat, closeChat, active: () => S.active, info: chInfo, hydrateComment, sealComment, renderList, renderHeader,
                  list: () => S.chList, isMobile, fmtDT: ts => fmtDT(ts)};
function openApp() {
  resetState();
  $("auth").classList.add("hidden"); $("app").classList.remove("hidden");
  document.querySelectorAll(".tabs button").forEach(x => x.classList.toggle("on", x.dataset.tab === "chats"));
  $("chat").classList.add("hidden"); $("empty").classList.remove("hidden");
  S.wantClose = false;
  loadEmojis();                                                                     // emoji katalogi: tayyor + admin yaratgan emojilar, ruxsatlar
  X.ready = (async () => { await loadMembers(); try { await loadRoom(); } catch (_) {} applyPendingOpen(); })();
  connect();
  Channels.init(chBridge); Channels.loadList().then(applyPendingChannel).catch(() => {});                // kanallar ro'yxati (ko'rinmagan postlar belgisi uchun)
  Push.sync(api).catch(() => {});                                                   // ruxsat berilgan bo'lsa, obuna serverda ekaniga ishonch hosil qilamiz
  setTimeout(askNotifications, 2500);                                               // birinchi marta: ruxsat so'raymiz
}
/* Har safar sahifa ochilganda login oynasi chiqadi (avtomatik kirish yo'q). Eski qurilmada qolgan kalitlar ham tozalanadi. */
(function boot() {
  let tok = ""; try { tok = localStorage.getItem(LS_STAY) || ""; } catch (_) {}
  if (tok) resumeStay(tok, 0);                                   // foydalanuvchi o'zi login so'rashni o'chirgan qurilma
  else { try { E2E.clearIdentity(); } catch (_) {} }             // aks holda har ochilganda login (eski qurilmada qolgan kalitlar ham tozalanadi)
})();
/* Kalitli xodim (Hevorix/admin) onlayn ekan, kaliti yo'q yangi a'zolarga guruh kalitini muntazam o'rab beradi */
setInterval(() => { if (S.token && S.me && isStaff(S.me) && X.rooms.size) serveWraps(); }, 30000);
})();


/* ---------------- Uzun nickname: "…" bilan qisqaradi, ustiga borilganda sekin siljiydi ---------------- */
(function () {
  let cur = null, raf = 0, timer = 0;
  const HOST = ".item, .pname, .hinfo, .bname, .rq";
  function stop() {
    cancelAnimationFrame(raf); clearTimeout(timer);
    if (cur) { cur.scrollLeft = 0; cur.style.textOverflow = ""; cur.classList.remove("scrolling"); }
    cur = null;
  }
  function start(nt) {
    const max = nt.scrollWidth - nt.clientWidth;
    if (max <= 2) return;
    cur = nt; nt.style.textOverflow = "clip"; nt.classList.add("scrolling");
    const SPEED = 45;                       // px/soniya
    const run = (dir, from) => {
      const t0 = performance.now();
      const step = now => {
        if (cur !== nt) return;
        const d = Math.min(1, (now - t0) / ((max / SPEED) * 1000));
        nt.scrollLeft = dir > 0 ? max * d : max * (1 - d);
        if (d < 1) raf = requestAnimationFrame(step);
        else timer = setTimeout(() => { if (cur === nt) run(-dir); }, 700);
      };
      raf = requestAnimationFrame(step);
    };
    timer = setTimeout(() => { if (cur === nt) run(1); }, 350);
  }
  document.addEventListener("mouseover", e => {
    const host = e.target.closest && e.target.closest(HOST);
    const nt = host && host.querySelector(".nm .nt");
    if (nt === cur) return;
    stop();
    if (nt) start(nt);
  });
  document.addEventListener("mouseleave", stop);
  document.addEventListener("scroll", stop, true);
})();
