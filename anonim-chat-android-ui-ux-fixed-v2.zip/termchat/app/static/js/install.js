
(() => {
  "use strict";
  const WAIT_MS = 10000;
  const LS_SEEN = "ac_inst_seen";
  const LS_WAITED = "ac_inst_waited";
  const btns = document.querySelectorAll("[data-install]");
  const sheet = document.getElementById("installSheet");
  if (!btns.length || !sheet) return;

  const $ = s => sheet.querySelector(s);
  const ua = navigator.userAgent || "";
  const isIOS = /iPad|iPhone|iPod/.test(ua) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
  const isAndroid = /Android/i.test(ua);
  const isSafari = /Safari/.test(ua) && !/CriOS|FxiOS|EdgiOS|OPiOS|Chrome|Android/.test(ua);
  const standalone = () => window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone === true;
  const get = k => { try { return localStorage.getItem(k); } catch (_) { return null; } };
  const set = (k, v) => { try { localStorage.setItem(k, v); } catch (_) {} };

  const ring = $("#instProg"), count = $("#instCount"), title = $("#instTitle"), text = $("#instText");
  const go = $("#instGo"), later = $("[data-close]"), stepsEl = $("[data-steps]"), checks = $("#instChecks");
  const C = 2 * Math.PI * 44;
  ring.setAttribute("stroke-dasharray", C.toFixed(2));

  let deferred = null;
  let t0 = 0;
  let timer = 0;
  let phase = "wait";
  let swOk = false, filesOk = false;
  const waited = () => get(LS_WAITED) === "1";
  const minWait = () => (waited() ? 0 : WAIT_MS);

  const show = on => btns.forEach(b => b.classList.toggle("hidden", !on));
  const isOpen = () => !sheet.classList.contains("hidden");
  function close() { sheet.classList.add("hidden"); clearInterval(timer); timer = 0; }

  function steps() {
    stepsEl.textContent = "";
    let list;
    if (isIOS && !isSafari) {
      list = ["Bu brauzer iPhone'da o'rnatishga ruxsat bermaydi.", "Saytni Safari brauzerida oching (manzilni nusxalab Safari'ga qo'ying).", "Pastdagi «Ulashish» (⬆︎) tugmasini bosing → «Bosh ekranga qo'shish» → «Qo'shish»."];
    } else if (isIOS) {
      list = ["Pastdagi «Ulashish» (⬆︎) tugmasini bosing.", "Pastga suring va «Bosh ekranga qo'shish» (Add to Home Screen) ni tanlang.", "O'ngdagi yuqori burchakdagi «Qo'shish» ni bosing.", "Bildirishnomalar faqat shu usulda o'rnatilgan ilovada ishlaydi."];
    } else if (isAndroid) {
      list = ["Brauzerning ⋮ (uch nuqta) menyusini oching.", "«Ilovani o'rnatish» (Install app) yoki «Bosh ekranga qo'shish» (Add to Home screen) ni tanlang.", "Tasdiqlang — ikonka telefon ekraniga chiqadi."];
    } else {
      list = ["Manzil satrining o'ng chetidagi o'rnatish ikonkasini (⊕ yoki 🖥) bosing.", "Yoki brauzer menyusi → «Anonim Chat'ni o'rnatish» / «Ilovani o'rnatish».", "Ilova alohida oynada, ish stolida ikonka bilan ochiladi."];
    }
    list.forEach(s => { const li = document.createElement("li"); li.textContent = s; stepsEl.append(li); });
  }

  function mark(name, on) {
    const li = checks.querySelector('[data-step="' + name + '"]');
    if (li) li.classList.toggle("ok", !!on);
  }

  function setPhase(p) {
    phase = p;
    sheet.dataset.phase = p;
    ring.parentNode.parentNode.classList.toggle("done", p !== "wait");
    if (p === "ready") {
      title.textContent = "O'rnatishga tayyor";
      text.textContent = "Hammasi tayyor. «O'rnatish» tugmasini bosing — ikonka ekraningizga qo'shiladi.";
      go.disabled = false; go.textContent = "O'rnatish";
      later.textContent = "Keyinroq";
      stepsEl.classList.add("hidden");
      mark("ready", true);
    } else if (p === "manual") {
      title.textContent = isIOS ? "iPhone'ga o'rnatish" : "Qo'lda o'rnatish";
      text.textContent = "Brauzeringiz bir bosishda o'rnatishga ruxsat bermadi. Quyidagi qadamlarni bajaring:";
      steps(); stepsEl.classList.remove("hidden");
      go.disabled = false; go.textContent = "Tushundim";
      later.classList.add("hidden");
      mark("ready", true);
    } else if (p === "done") {
      title.textContent = "O'rnatildi ✓";
      text.textContent = "Ilova bosh ekraningizda. Uni shu yerdan oching.";
      go.classList.add("hidden"); later.classList.add("hidden"); stepsEl.classList.add("hidden");
      mark("ready", true);
      setTimeout(close, 2200);
    }
  }

  function tick() {
    if (phase !== "wait") return;
    const el = Date.now() - t0;
    const left = Math.max(0, Math.ceil((WAIT_MS - el) / 1000));
    ring.setAttribute("stroke-dashoffset", (C * (1 - Math.min(1, el / WAIT_MS))).toFixed(2));
    count.textContent = String(left);
    if (el < minWait()) {
      text.textContent = "Ilova tayyorlanmoqda. Iltimos, " + left + " soniya kuting…";
      go.textContent = "Kuting… " + left;
      return;
    }
    if (deferred) { set(LS_WAITED, "1"); setPhase("ready"); return; }
    if (el >= WAIT_MS) { set(LS_WAITED, "1"); setPhase("manual"); return; }
    text.textContent = "Brauzer tekshirilmoqda…";
    go.textContent = "Kuting… " + left;
  }

  function probe() {
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.ready.then(() => { swOk = true; mark("sw", true); return caches.match("/static/icons/icon-192.png"); })
        .then(hit => { filesOk = !!hit || swOk; mark("files", filesOk); }).catch(() => { mark("files", swOk); });
    }
    mark("push", !!(window.Push && window.Push.supported));
  }

  function open() {
    if (standalone()) return;
    if (!t0) t0 = Date.now();
    set(LS_SEEN, "1");
    go.classList.remove("hidden"); later.classList.remove("hidden");
    sheet.classList.remove("hidden");
    if (phase === "wait") { go.disabled = true; stepsEl.classList.add("hidden"); }
    else setPhase(phase);
    probe(); tick();
    if (!timer && phase === "wait") timer = setInterval(() => { tick(); probe(); if (phase !== "wait") { clearInterval(timer); timer = 0; } }, 250);
  }

  async function onGo() {
    if (phase === "ready" && deferred) {
      const p = deferred; deferred = null;
      try {
        await p.prompt();
        const r = await p.userChoice;
        if (r && r.outcome === "accepted") { setPhase("done"); return; }
      } catch (_) {}
      setPhase("manual"); text.textContent = "O'rnatish bekor qilindi. Xohlasangiz, qo'lda o'rnating:";
      return;
    }
    if (phase === "manual") close();
  }

  btns.forEach(b => b.addEventListener("click", open));
  go.addEventListener("click", onGo);
  sheet.addEventListener("click", e => { if (e.target === sheet || e.target.closest("[data-close]")) close(); });
  document.addEventListener("keydown", e => { if (e.key === "Escape" && isOpen()) close(); });

  window.addEventListener("beforeinstallprompt", e => { e.preventDefault(); deferred = e; if (!standalone()) show(true); if (isOpen()) tick(); });
  window.addEventListener("appinstalled", () => { deferred = null; show(false); if (isOpen()) setPhase("done"); else close(); });

  if (standalone()) { show(false); }
  else {
    show(true);

    if (get(LS_SEEN) !== "1") setTimeout(open, 700);
  }

  if ("serviceWorker" in navigator) {
    const reg = () => navigator.serviceWorker.register("/sw.js", {scope: "/"}).catch(() => {});
    if (document.readyState === "complete") reg(); else window.addEventListener("load", reg);
  }
})();
