/* "Ilovani o'rnatish" tugmasi: Android (Chrome/Samsung/Xiaomi/Honor/Vivo…), desktop (Chrome/Edge) — bir bosishda;
   iOS — brauzer o'zi ruxsat bermaydi, shuning uchun aniq yo'riqnoma ko'rsatiladi. */
(() => {
  "use strict";
  const btns = document.querySelectorAll("[data-install]");
  const sheet = document.getElementById("installSheet");
  if (!btns.length || !sheet) return;

  const ua = navigator.userAgent || "";
  const isIOS = /iPad|iPhone|iPod/.test(ua) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
  const isAndroid = /Android/i.test(ua);
  const isSafari = /Safari/.test(ua) && !/CriOS|FxiOS|EdgiOS|OPiOS|Chrome|Android/.test(ua);
  const standalone = () => window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone === true;

  let deferred = null;

  const show = on => btns.forEach(b => b.classList.toggle("hidden", !on));
  const hideSheet = () => sheet.classList.add("hidden");

  function steps() {
    const t = sheet.querySelector("[data-steps]");
    t.textContent = "";
    let list;
    if (isIOS && !isSafari) {
      list = ["Bu brauzer iPhone'da o'rnatishga ruxsat bermaydi.", "Saytni Safari brauzerida oching (manzilni nusxalab Safari'ga qo'ying).", "Pastdagi «Ulashish» (⬆︎) tugmasini bosing → «Bosh ekranga qo'shish» → «Qo'shish»."];
    } else if (isIOS) {
      list = ["Pastdagi «Ulashish» (⬆︎) tugmasini bosing.", "Pastga suring va «Bosh ekranga qo'shish» (Add to Home Screen) ni tanlang.", "O'ngdagi yuqori burchakdagi «Qo'shish» ni bosing."];
    } else if (isAndroid) {
      list = ["Brauzerning ⋮ (uch nuqta) menyusini oching.", "«Ilovani o'rnatish» (Install app) yoki «Bosh ekranga qo'shish» (Add to Home screen) ni tanlang.", "Tasdiqlang — ikonka telefon ekraniga chiqadi."];
    } else {
      list = ["Manzil satrining o'ng chetidagi o'rnatish ikonkasini (⊕ yoki 🖥) bosing.", "Yoki brauzer menyusi → «Anonim Chat'ni o'rnatish» / «Ilovani o'rnatish».", "Ilova alohida oynada, ish stolida ikonka bilan ochiladi."];
    }
    list.forEach(s => { const li = document.createElement("li"); li.textContent = s; t.append(li); });
  }

  async function onInstall() {
    if (deferred) {                         // Android / desktop Chromium: haqiqiy bir-bosishli o'rnatish
      const p = deferred; deferred = null;
      try { await p.prompt(); await p.userChoice; } catch (_) {}
      return;
    }
    steps();
    sheet.classList.remove("hidden");       // iOS / boshqa brauzerlar: yo'riqnoma
  }

  btns.forEach(b => b.addEventListener("click", onInstall));
  sheet.addEventListener("click", e => { if (e.target === sheet || e.target.closest("[data-close]")) hideSheet(); });

  window.addEventListener("beforeinstallprompt", e => { e.preventDefault(); deferred = e; if (!standalone()) show(true); });
  window.addEventListener("appinstalled", () => { deferred = null; show(false); hideSheet(); });

  if (standalone()) { show(false); }
  else { show(true); }                      // iOS'da beforeinstallprompt yo'q — tugma baribir ko'rinadi

  if ("serviceWorker" in navigator) {
    window.addEventListener("load", () => navigator.serviceWorker.register("/sw.js", {scope: "/"}).catch(() => {}));
  }
})();
