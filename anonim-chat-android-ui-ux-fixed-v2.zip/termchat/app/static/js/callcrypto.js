/* Anonim Chat by Hevorix — ovozli qo'ng'iroq: E2EE kalit kelishuvi va audio kadrlarni shifrlash (sof funksiyalar; Node'da testlanadi).

   Kalit kelishuvi (hammasi QURILMADA, server hech narsani ko'rmaydi):
     1. har tomon qo'ng'iroq uchun vaqtinchalik ECDH P-256 kalit juftligini yaratadi (ochiq qismi serverdan o'tadi);
     2. ECDH umumiy siri + PARTIYA (ikki tomon oldindan kelishgan parol, PBKDF2-SHA256 250 000 aylanish) birlashtirilib,
        HKDF-SHA256 bilan alohida kalitlar chiqariladi (har yo'nalish uchun alohida AES-256-GCM, tasdiq kaliti, soxta paketlar kaliti);
     3. har tomon HMAC "tasdiq" yuboradi: parol mos kelmasa tasdiq mos kelmaydi va qo'ng'iroq ULANMAYDI (media oqimi boshlanmaydi).
   Server/tarmoq vositachisi parolni bilmaguncha kalitni hosil qila olmaydi.

   Kadr shifrlash: har audio kadr [uzunlik u16][ma'lumot][tasodifiy to'ldirgich] ko'rinishida QAT'IY o'lchamgacha (160/320/640 bayt) to'ldiriladi,
   so'ng AES-GCM bilan shifrlanadi. Shu tufayli sukunat va nutq paketlari bir xil hajmda ko'rinadi (trafik tahlilidan himoya).
   Kadr formati: [hisoblagich 8 bayt][shifrmatn+teg]. IV = [4 bayt yo'nalish prefiksi][hisoblagich]. Qayta yuborilgan (replay) kadrlar tashlanadi. */
"use strict";
(root => {
const enc = new TextEncoder();
const subtle = () => root.crypto.subtle;
const BUCKETS = [160, 320, 640];
const PBKDF2_ITER = 250000, HDR = 8, REPLAY = 256;

const b64e = u8 => { let s = ""; for (let i = 0; i < u8.length; i++) s += String.fromCharCode(u8[i]); return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, ""); };
const b64d = s => { s = String(s).replace(/-/g, "+").replace(/_/g, "/"); while (s.length % 4) s += "="; const r = atob(s), u = new Uint8Array(r.length); for (let i = 0; i < r.length; i++) u[i] = r.charCodeAt(i); return u; };
const cat = (...a) => { const n = a.reduce((x, y) => x + y.length, 0), o = new Uint8Array(n); let p = 0; for (const u of a) { o.set(u, p); p += u.length; } return o; };
const sha = async u8 => new Uint8Array(await subtle().digest("SHA-256", u8));

async function newKex() {
  const kp = await subtle().generateKey({name: "ECDH", namedCurve: "P-256"}, false, ["deriveBits"]);
  const raw = new Uint8Array(await subtle().exportKey("raw", kp.publicKey));
  return {priv: kp.privateKey, pubRaw: raw, pub: b64e(raw)};
}

/* role: "caller" | "callee". Parol noto'g'ri bo'lsa ham kalit hosil bo'ladi, lekin tasdiq (confirm) mos kelmaydi. */
async function deriveSession({priv, myPubRaw, peerPub, password, callId, role}) {
  const peerRaw = b64d(peerPub);
  if (peerRaw.length !== 65 || peerRaw[0] !== 4) throw new Error("Noto'g'ri kalit");
  const callerPub = role === "caller" ? myPubRaw : peerRaw, calleePub = role === "caller" ? peerRaw : myPubRaw;
  const transcript = cat(enc.encode("anonim-call-v1|" + callId + "|"), callerPub, calleePub);
  const peerKey = await subtle().importKey("raw", peerRaw, {name: "ECDH", namedCurve: "P-256"}, false, []);
  const ecdh = new Uint8Array(await subtle().deriveBits({name: "ECDH", public: peerKey}, priv, 256));
  const pwKey = await subtle().importKey("raw", enc.encode(String(password).trim().normalize("NFKC")), "PBKDF2", false, ["deriveBits"]);
  const pw = new Uint8Array(await subtle().deriveBits({name: "PBKDF2", hash: "SHA-256", iterations: PBKDF2_ITER, salt: await sha(enc.encode("anonim-call-pw|" + callId))}, pwKey, 256));
  const hk = await subtle().importKey("raw", cat(ecdh, pw), "HKDF", false, ["deriveBits"]);
  const okm = new Uint8Array(await subtle().deriveBits({name: "HKDF", hash: "SHA-256", salt: await sha(transcript), info: enc.encode("anonim-call-keys")}, hk, 8 * 144));
  ecdh.fill(0); pw.fill(0);
  const aes = u => subtle().importKey("raw", u, {name: "AES-GCM"}, false, ["encrypt", "decrypt"]);
  const k = {c2e: okm.slice(0, 32), e2c: okm.slice(32, 64), conf: okm.slice(64, 96), cover: okm.slice(96, 128),
    p: [okm.slice(128, 132), okm.slice(132, 136), okm.slice(136, 140), okm.slice(140, 144)]};
  const confKey = await subtle().importKey("raw", k.conf, {name: "HMAC", hash: "SHA-256"}, false, ["sign", "verify"]);
  const mine = role === "caller" ? "c2e" : "e2c", theirs = role === "caller" ? "e2c" : "c2e";
  const aad = (tag, d) => enc.encode(tag + "|" + callId + "|" + d);
  const out = {
    send: {key: await aes(k[mine]), ivPrefix: role === "caller" ? k.p[0] : k.p[1], aad: aad("a", mine)},
    recv: {key: await aes(k[theirs]), ivPrefix: role === "caller" ? k.p[1] : k.p[0], aad: aad("a", theirs)},
    cover: {key: await aes(k.cover), ivPrefix: role === "caller" ? k.p[2] : k.p[3], aad: aad("x", mine)},
    _confKey: confKey, _transcript: transcript, role,
  };
  const sas = await sha(cat(okm.slice(64, 96), transcript));                  // 4 xonali qisqa kod (ikkala tomonda bir xil bo'lishi kerak)
  out.sas = String(((sas[0] << 8) | sas[1]) % 10000).padStart(4, "0");
  okm.fill(0); for (const key of ["c2e", "e2c", "conf", "cover"]) k[key].fill(0);
  return out;
}

const confData = (role, transcript) => cat(enc.encode("confirm|" + role + "|"), transcript);
async function makeConfirm(sess) { return b64e(new Uint8Array(await subtle().sign("HMAC", sess._confKey, confData(sess.role, sess._transcript)))); }
async function checkConfirm(sess, mac) {          // mac: SUHBATDOSHNING tasdig'i
  const peerRole = sess.role === "caller" ? "callee" : "caller";
  try { return await subtle().verify("HMAC", sess._confKey, b64d(mac), confData(peerRole, sess._transcript)); } catch (_) { return false; }
}

/* ---------------- kadr shifri ---------------- */
function makeCipher({key, ivPrefix, aad}) {
  let ctr = 0, max = -1; const seen = new Set();
  const iv = n => { const u = new Uint8Array(12); u.set(ivPrefix, 0); const dv = new DataView(u.buffer); dv.setUint32(4, Math.floor(n / 4294967296)); dv.setUint32(8, n >>> 0); return u; };
  const bucketFor = len => BUCKETS.find(b => b >= len + 2) || Math.ceil((len + 2) / 64) * 64;
  return {
    async seal(data, fixedSize) {
      const size = fixedSize || bucketFor(data.length), pt = new Uint8Array(size);
      new DataView(pt.buffer).setUint16(0, data.length); pt.set(data, 2);
      if (size > data.length + 2) root.crypto.getRandomValues(pt.subarray(data.length + 2));
      const n = ctr++, ct = new Uint8Array(await subtle().encrypt({name: "AES-GCM", iv: iv(n), additionalData: aad}, key, pt));
      const out = new Uint8Array(HDR + ct.length), dv = new DataView(out.buffer);
      dv.setUint32(0, Math.floor(n / 4294967296)); dv.setUint32(4, n >>> 0); out.set(ct, HDR);
      return out;
    },
    async open(frame) {                            // buzilgan / qayta yuborilgan / begona kadr -> null
      if (frame.length < HDR + 16 + 2) return null;
      const dv = new DataView(frame.buffer, frame.byteOffset, frame.byteLength), n = dv.getUint32(0) * 4294967296 + dv.getUint32(4);
      if (seen.has(n) || n < max - REPLAY) return null;
      let pt;
      try { pt = new Uint8Array(await subtle().decrypt({name: "AES-GCM", iv: iv(n), additionalData: aad}, key, frame.subarray(HDR))); } catch (_) { return null; }
      seen.add(n); if (n > max) max = n;
      if (seen.size > REPLAY * 2) for (const x of seen) if (x < max - REPLAY) seen.delete(x);
      const len = new DataView(pt.buffer).getUint16(0);
      return len + 2 <= pt.length ? pt.slice(2, 2 + len) : null;
    },
  };
}

/* Kodlangan audio kadrlar oqimi uchun TransformStream (RTCRtpScriptTransform ichida ham, eski createEncodedStreams'da ham) */
function makeTransform(getCipher, op) {
  return new TransformStream({
    async transform(frame, ctl) {
      const c = getCipher();
      if (!c) return;                              // kalit yo'q: HECH QACHON ochiq yuborilmaydi
      const input = new Uint8Array(frame.data);
      const out = op === "encrypt" ? await c.seal(input) : await c.open(input);
      if (!out) return;
      frame.data = out.buffer.slice(out.byteOffset, out.byteOffset + out.byteLength);
      ctl.enqueue(frame);
    },
  });
}

/* SDP: nutq faolligi oshkor bo'lmasligi uchun (DTX o'chiq, CBR, "audio level" sarlavhasi olib tashlanadi) */
function hardenSdp(sdp) {
  let s = sdp.replace(/^a=extmap:\d+ urn:ietf:params:rtp-hdrext:ssrc-audio-level.*\r?\n/gmi, "");
  const m = /^a=rtpmap:(\d+) opus\/48000/mi.exec(s);
  if (m) {
    const pt = m[1], re = new RegExp("^(a=fmtp:" + pt + " )(.*)$", "mi"), extra = {usedtx: 0, cbr: 1, maxaveragebitrate: 24000, stereo: 0, useinbandfec: 1};
    if (re.test(s)) s = s.replace(re, (_, a, params) => {
      const kv = params.split(";").map(x => x.trim()).filter(Boolean).filter(x => !(x.split("=")[0] in extra));
      return a + kv.concat(Object.entries(extra).map(([k, v]) => k + "=" + v)).join(";");
    });
    else s = s.replace(new RegExp("^(a=rtpmap:" + pt + " opus/48000.*)$", "mi"), "$1\r\na=fmtp:" + pt + " " + Object.entries(extra).map(([k, v]) => k + "=" + v).join(";"));
  }
  return s;
}

/* Soxta (decoy) paketlar jadvali: tasodifiy oraliq va hajm. */
function coverPlan(rnd) { return {delayMs: 30 + Math.floor(rnd() * 370), size: 48 + Math.floor(rnd() * 560)}; }

root.CallCrypto = {newKex, deriveSession, makeConfirm, checkConfirm, makeCipher, makeTransform, hardenSdp, coverPlan, b64e, b64d, BUCKETS, PBKDF2_ITER};
})(typeof globalThis !== "undefined" ? globalThis : self);
