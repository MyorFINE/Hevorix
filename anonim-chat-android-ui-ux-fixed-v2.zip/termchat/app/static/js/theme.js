"use strict";

(() => {
  let t = null;
  try { t = localStorage.getItem("termchat_theme"); } catch (_) {}
  if (t !== "dark" && t !== "light") t = matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  document.documentElement.dataset.theme = t;
  const m = document.querySelector('meta[name="theme-color"]');
  if (m) m.setAttribute("content", t === "dark" ? "#17212b" : "#ffffff");

  try {
    const c = navigator.connection, lowMem = (navigator.deviceMemory || 4) <= 2, lowCpu = (navigator.hardwareConcurrency || 8) <= 4;
    if (lowMem || lowCpu || (c && c.saveData)) document.documentElement.classList.add("lite");
  } catch (_) {}
})();

(() => {
  const KEYS = {stk: "termchat_anim_stk", emo: "termchat_anim_emo", ui: "termchat_anim_ui"};
  const CLS = {stk: "no-stk-anim", emo: "no-emo-anim", ui: "no-ui-anim"};
  const root = document.documentElement, frozen = new Map();
  const on = k => { try { return localStorage.getItem(KEYS[k]) !== "off"; } catch (_) { return true; } };
  const sync = () => { for (const k in CLS) root.classList.toggle(CLS[k], !on(k)); };
  const freezeUrl = url => {
    if (frozen.has(url)) return frozen.get(url);
    const p = new Promise(res => {
      const im = new Image();
      im.onload = () => {
        try {
          const w = im.naturalWidth || 64, h = im.naturalHeight || 64, c = document.createElement("canvas");
          c.width = w; c.height = h; c.getContext("2d").drawImage(im, 0, 0, w, h);
          res(c.toDataURL("image/png"));
        } catch (_) { res(null); }
      };
      im.onerror = () => res(null);
      im.src = url;
    });
    frozen.set(url, p);
    return p;
  };
  const paint = img => {
    const url = img.dataset.animUrl, k = img.dataset.animKind;
    if (!url || !KEYS[k]) return;
    if (on(k)) { if (img.dataset.animState !== "live") { img.dataset.animState = "live"; img.src = url; } return; }
    if (img.dataset.animState === "still") return;
    img.dataset.animState = "still";
    freezeUrl(url).then(d => { if (img.dataset.animState === "still") img.src = d || url; });
  };
  const set = (k, val) => {
    if (!KEYS[k]) return;
    try { localStorage.setItem(KEYS[k], val ? "on" : "off"); } catch (_) {}
    sync();
    if (k !== "ui") document.querySelectorAll('img[data-anim-url][data-anim-kind="' + k + '"]').forEach(paint);
  };
  sync();
  window.AnimPrefs = {on, set, paint, ui: () => on("ui")};
})();
