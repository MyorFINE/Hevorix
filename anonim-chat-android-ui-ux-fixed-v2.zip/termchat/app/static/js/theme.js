"use strict";
// Mavzuni sahifa chizilishidan oldin o'rnatadi (miltillashning oldini oladi) va brauzer/status-bar rangini moslaydi.
(() => {
  let t = null;
  try { t = localStorage.getItem("termchat_theme"); } catch (_) {}
  if (t !== "dark" && t !== "light") t = matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  document.documentElement.dataset.theme = t;
  const m = document.querySelector('meta[name="theme-color"]');
  if (m) m.setAttribute("content", t === "dark" ? "#17212b" : "#ffffff");
})();
