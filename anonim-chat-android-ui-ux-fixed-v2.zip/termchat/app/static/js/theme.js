"use strict";

(() => {
  let t = null;
  try { t = localStorage.getItem("termchat_theme"); } catch (_) {}
  if (t !== "dark" && t !== "light") t = matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  document.documentElement.dataset.theme = t;
  const m = document.querySelector('meta[name="theme-color"]');
  if (m) m.setAttribute("content", t === "dark" ? "#17212b" : "#ffffff");

  try {
    const c = navigator.connection, lowMem = (navigator.deviceMemory || 4) <= 2, lowCpu = (navigator.hardwareConcurrency || 8) <= 4;
    if (lowMem || lowCpu || (c && c.saveData)) document.documentElement.classList.add("lite");
  } catch (_) {}
})();

(() => {
  const KEYS = {stk: "termchat_anim_stk", emo: "termchat_anim_emo", ui: "termchat_anim_ui"};
  const CLS = {stk: "no-stk-anim", emo: "no-emo-anim", ui: "no-ui-anim"};
  const root = document.documentElement, frozen = new Map();
  const on = k => { try { return localStorage.getItem(KEYS[k]) !== "off"; } catch (_) { return true; } };
  const sync = () => { for (const k in CLS) root.classList.toggle(CLS[k], !on(k)); };
  const freezeUrl = url => {
    if (frozen.has(url)) return frozen.get(url);
    const p = new Promise(res => {
      const im = new Image();
      im.onload = () => {
        try {
          const w = im.naturalWidth || 64, h = im.naturalHeight || 64, c = document.createElement("canvas");
          c.width = w; c.height = h; c.getContext("2d").drawImage(im, 0, 0, w, h);
          res(c.toDataURL("image/png"));
        } catch (_) { res(null); }
      };
      im.onerror = () => res(null);
      im.src = url;
    });
    frozen.set(url, p);
    return p;
  };
  const paint = img => {
    const url = img.dataset.animUrl, k = img.dataset.animKind;
    if (!url || !KEYS[k]) return;
    if (on(k)) { if (img.dataset.animState !== "live") { img.dataset.animState = "live"; img.src = url; } return; }
    if (img.dataset.animState === "still") return;
    img.dataset.animState = "still";
    freezeUrl(url).then(d => { if (img.dataset.animState === "still") img.src = d || url; });
  };
  const set = (k, val) => {
    if (!KEYS[k]) return;
    try { localStorage.setItem(KEYS[k], val ? "on" : "off"); } catch (_) {}
    sync();
    if (k !== "ui") document.querySelectorAll('img[data-anim-url][data-anim-kind="' + k + '"]').forEach(paint);
  };
  sync();
  window.AnimPrefs = {on, set, paint, ui: () => on("ui")};
})();

// Chat sozlamalari: mavzu (klassik/kunduzgi/rangli/tungi), aksent rang va chat foni (oboi).
// Sahifa yuklanishidanoq qo'llanadi (miltillash bo'lmasligi uchun), faqat shu qurilmada saqlanadi.
(() => {
  const KEY = "termchat_cs", WKEY = "termchat_cs_wp", root = document.documentElement;
  const DARK = {classic: false, day: false, tinted: true, night: true};
  const WALLS = [
    {id: "none", t: "Standart"},
    {id: "dusk", t: "Shom", css: "linear-gradient(160deg,#2b1055,#7597de)"},
    {id: "ocean", t: "Okean", css: "linear-gradient(160deg,#0f2027,#2c5364)"},
    {id: "mint", t: "Yalpiz", css: "linear-gradient(160deg,#a8e063,#56ab2f)"},
    {id: "peach", t: "Shaftoli", css: "linear-gradient(160deg,#ffecd2,#fcb69f)"},
    {id: "sky", t: "Osmon", css: "linear-gradient(160deg,#a1c4fd,#c2e9fb)"},
    {id: "night", t: "Tun", css: "linear-gradient(160deg,#0f0c29,#302b63,#24243e)"},
    {id: "rose", t: "Atirgul", css: "linear-gradient(160deg,#ee9ca7,#ffdde1)"},
    {id: "graphite", t: "Grafit", css: "linear-gradient(160deg,#232526,#414345)"},
    {id: "dots", t: "Nuqtalar", css: "radial-gradient(rgba(255,255,255,.2) 1.5px,transparent 1.6px),linear-gradient(160deg,#3a7bd5,#00a8d6)", size: "22px 22px,cover", rep: "repeat,no-repeat"},
  ];
  let st = null;
  try { st = JSON.parse(localStorage.getItem(KEY) || "null"); } catch (_) {}
  if (!st || !(st.style in DARK)) st = {style: root.dataset.theme === "dark" ? "night" : "classic", accent: null, wp: "none"};
  if (!/^#[0-9a-f]{6}$/i.test(st.accent || "")) st.accent = null;
  if (st.wp !== "file" && !WALLS.some(w => w.id === st.wp)) st.wp = "none";

  const rgb = c => [1, 3, 5].map(i => parseInt(c.slice(i, i + 2), 16));
  const hex = a => "#" + a.map(v => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, "0")).join("");
  const mix = (a, b, t) => a.map((v, i) => v + (b[i] - v) * t);
  const lum = a => (0.2126 * a[0] + 0.7152 * a[1] + 0.0722 * a[2]) / 255;

  function apply() {
    const dark = DARK[st.style];
    root.dataset.theme = dark ? "dark" : "light";
    root.dataset.style = st.style;
    const mc = document.querySelector('meta[name="theme-color"]');
    if (mc) mc.setAttribute("content", dark ? "#17212b" : "#ffffff");
    const AK = ["--accent", "--accent-d", "--on-accent", "--accent-rgb"];
    if (st.accent) {
      let c = rgb(st.accent); if (dark) c = mix(c, [255, 255, 255], 0.22);
      root.dataset.accent = "1";
      root.style.setProperty("--accent", hex(c));
      root.style.setProperty("--accent-d", hex(mix(c, [0, 0, 0], 0.14)));
      root.style.setProperty("--on-accent", lum(c) > 0.62 ? "#0b1620" : "#ffffff");
      root.style.setProperty("--accent-rgb", c.map(Math.round).join(","));
    } else { delete root.dataset.accent; AK.forEach(k => root.style.removeProperty(k)); }

    let css = null, size = "cover", rep = "no-repeat";
    if (st.wp === "file") { try { const d = localStorage.getItem(WKEY); if (d) css = 'url("' + d + '")'; } catch (_) {} }
    else { const w = WALLS.find(x => x.id === st.wp); if (w && w.css) { css = w.css; size = w.size || size; rep = w.rep || rep; } }
    if (css) {
      root.dataset.wp = "1";
      root.style.setProperty("--wp", css); root.style.setProperty("--wps", size); root.style.setProperty("--wpr", rep);
    } else { delete root.dataset.wp; ["--wp", "--wps", "--wpr"].forEach(k => root.style.removeProperty(k)); }
    try { localStorage.setItem("termchat_theme", dark ? "dark" : "light"); } catch (_) {}
  }
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(st)); } catch (_) {} };
  window.ChatStyle = {
    WALLS, get: () => Object.assign({}, st),
    set(p) { Object.assign(st, p); save(); apply(); },
    // Fayldan oboi: dataURL localStorage'ga sig'masa xato tashlaydi
    setWallFile(dataUrl) { localStorage.setItem(WKEY, dataUrl); this.set({wp: "file"}); },
    wallFile() { try { return localStorage.getItem(WKEY) || ""; } catch (_) { return ""; } },
    reset() { st = {style: "classic", accent: null, wp: "none"}; save(); apply(); },
  };
  apply();
})();
