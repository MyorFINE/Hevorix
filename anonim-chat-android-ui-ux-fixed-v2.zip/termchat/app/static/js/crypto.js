
"use strict";
(() => {
const enc = new TextEncoder(), dec = new TextDecoder();
const AAD = {req: enc.encode("termchat/v1/http-req"), res: enc.encode("termchat/v1/http-res"),
             c2s: enc.encode("termchat/v1/ws-c2s"), s2c: enc.encode("termchat/v1/ws-s2c")};
const WS_REKEY = 4428;
let sess = null, pending = null, memToken = null;

async function tfetch(url, init, ms) {
  const ac = new AbortController(), t = setTimeout(() => ac.abort(), ms);
  try { return await fetch(url, Object.assign({}, init, {signal: ac.signal})); }
  catch (err) { throw err && err.name === "AbortError" ? new Error("Server javob bermadi, qayta urinib ko'ring") : err; }
  finally { clearTimeout(t); }
}
const wire = [];
const wnote = (dir, app, net) => { wire.push({ts: Date.now(), dir, app: String(app).replace(/"a":"[^"]*"/, '"a":"•••"').slice(0, 1800), net: net.slice(0, 160), bytes: net.length}); while (wire.length > 12) wire.shift(); };

const b64e = u8 => { let s = ""; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s); };
const b64d = s => Uint8Array.from(atob(s), c => c.charCodeAt(0));
const cat = (...parts) => { const out = new Uint8Array(parts.reduce((n, p) => n + p.length, 0)); let o = 0; for (const p of parts) { out.set(p, o); o += p.length; } return out; };

const supported = () => !!(window.crypto && crypto.subtle && window.isSecureContext !== false);

async function handshake() {
  if (!supported()) throw new Error("Xavfsiz ulanish (HTTPS) kerak — shifrlash bu brauzerda ishlamaydi");
  if (pending) return pending;
  pending = (async () => {
    const kp = await crypto.subtle.generateKey({name: "ECDH", namedCurve: "P-256"}, false, ["deriveBits"]);
    const pub = new Uint8Array(await crypto.subtle.exportKey("raw", kp.publicKey));
    const r = await tfetch("/api/handshake", {method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify({pub: b64e(pub)})}, 12000);
    if (!r.ok) throw new Error(r.status === 429 ? "Juda ko'p urinish, biroz kuting" : "Xavfsiz kanal ochilmadi");
    const j = await r.json();
    const srv = b64d(j.pub);
    const peer = await crypto.subtle.importKey("raw", srv, {name: "ECDH", namedCurve: "P-256"}, false, []);
    const bits = await crypto.subtle.deriveBits({name: "ECDH", public: peer}, kp.privateKey, 256);
    const hk = await crypto.subtle.importKey("raw", bits, "HKDF", false, ["deriveKey"]);
    const salt = cat(pub, srv);
    const mk = info => crypto.subtle.deriveKey({name: "HKDF", hash: "SHA-256", salt, info: enc.encode(info)}, hk,
      {name: "AES-GCM", length: 256}, false, ["encrypt", "decrypt"]);
    sess = {kid: j.kid, up: await mk("termchat/v1/c2s"), down: await mk("termchat/v1/s2c")};
  })().finally(() => { pending = null; });
  return pending;
}
const ready = async () => { if (!sess) await handshake(); return sess; };

async function seal(key, iv, plain, aad) { return new Uint8Array(await crypto.subtle.encrypt({name: "AES-GCM", iv, additionalData: aad}, key, plain)); }
async function open(key, iv, ct, aad) { return new Uint8Array(await crypto.subtle.decrypt({name: "AES-GCM", iv, additionalData: aad}, key, ct)); }

class SecRes {
  constructor(status, type, bytes) { this.status = status; this.ok = status >= 200 && status < 300; this.type = type; this.bytes = bytes; }
  async json() { return JSON.parse(dec.decode(this.bytes)); }
  async text() { return dec.decode(this.bytes); }
  blob() { return new Blob([this.bytes], {type: this.type}); }
}
async function sfetch(path, opts = {}) {
  const method = (opts.method || "GET").toUpperCase();
  const headers = Object.assign({}, opts.headers || {});
  let token = null, ctype = headers["Content-Type"] || headers["content-type"] || "";
  const auth = headers.Authorization || headers.authorization || "";
  if (/^bearer /i.test(auth)) token = auth.slice(7).trim();
  if (!token && /^\/(uploads|avatars)\//.test(path)) token = memToken;
  let body = new Uint8Array(0);
  if (opts.body instanceof FormData) {
    const rq = new Request(location.origin + "/", {method: "POST", body: opts.body});
    ctype = rq.headers.get("content-type") || ""; body = new Uint8Array(await rq.arrayBuffer());
  } else if (typeof opts.body === "string") body = enc.encode(opts.body);
  else if (opts.body instanceof Uint8Array) body = opts.body;
  for (let attempt = 0; attempt < 2; attempt++) {
    const s = await ready();
    const meta = JSON.stringify({t: Date.now(), m: method, p: path, a: token, c: ctype || null});
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const ct = await seal(s.up, iv, cat(enc.encode(meta + "\n"), body), AAD.req);
    const big = body.length > 256 * 1024;
    const r = await tfetch("/api/x", {method: "POST", headers: {"X-Kid": s.kid, "Content-Type": "application/octet-stream"}, body: cat(iv, ct)}, big ? 300000 : 25000);
    if (r.status === 428) { sess = null; continue; }
    const buf = new Uint8Array(await r.arrayBuffer());
    if (r.status !== 200) { let d = ""; try { d = JSON.parse(dec.decode(buf)).detail; } catch (_) {} return new SecRes(r.status, "application/json", enc.encode(JSON.stringify({detail: d || "Xato"}))); }
    const plain = await open(s.down, buf.subarray(0, 12), buf.subarray(12), AAD.res);
    const nl = plain.indexOf(10), m = JSON.parse(dec.decode(plain.subarray(0, nl)));
    return new SecRes(m.s, m.c || "", plain.subarray(nl + 1));
  }
  throw new Error("Xavfsiz kanal qayta o'rnatilmadi");
}

class SecSocket {
  constructor(token) {
    this.readyState = 0; this.onopen = this.onmessage = this.onclose = null;
    this._token = token; this._tx = 0; this._rx = -1; this._pre = crypto.getRandomValues(new Uint8Array(4)); this._q = Promise.resolve();
    this._out = Promise.resolve(); this._closed = false;
    this._start();
  }
  _fail(code) {
    if (this._closed) return;
    this._closed = true; this.readyState = 3;
    clearTimeout(this._ct);
    this.onclose && this.onclose({code});
  }
  async _start() {

    this._ct = setTimeout(() => { if (this.readyState === 0) { try { this._ws && this._ws.close(); } catch (_) {} this._fail(1006); } }, 12000);
    try {
      const s = await ready(); this._s = s;
      if (this._closed) return;
      const proto = location.protocol === "https:" ? "wss" : "ws";
      const ws = this._ws = new WebSocket(proto + "://" + location.host + "/ws?k=" + encodeURIComponent(s.kid));
      ws.onopen = async () => {
        try { await this._sendRaw(JSON.stringify({a: this._token})); } catch (_) { return this._fail(1006); }
        if (this._closed) return;
        clearTimeout(this._ct); this.readyState = 1; this.onopen && this.onopen({});
      };
      ws.onmessage = ev => { this._q = this._q.then(() => this._recv(ev.data)).catch(() => this.close()); };
      ws.onerror = () => {};
      ws.onclose = ev => { if (ev.code === WS_REKEY) sess = null; this._fail(ev.code); };
    } catch (_) { this._fail(1006); }
  }
  async _sendRaw(text) {
    if (!this._ws || this._ws.readyState !== 1) throw new Error("ws yopiq");
    const iv = new Uint8Array(12); iv.set(this._pre); const dv = new DataView(iv.buffer); const n = ++this._tx;
    dv.setUint32(4, Math.floor(n / 4294967296)); dv.setUint32(8, n >>> 0);
    const ct = await seal(this._s.up, iv, enc.encode(text), AAD.c2s);
    if (!this._ws || this._ws.readyState !== 1) throw new Error("ws yopiq");
    const net = b64e(cat(iv, ct)); wnote("→", text, net);
    this._ws.send(net);
  }

  send(text) { this._out = this._out.then(() => this._sendRaw(text)).catch(() => {}); }
  async _recv(data) {
    const blob = b64d(data), iv = blob.subarray(0, 12), dv = new DataView(blob.buffer, blob.byteOffset + 4, 8);
    const ctr = dv.getUint32(0) * 4294967296 + dv.getUint32(4);
    if (ctr <= this._rx) throw new Error("replay");
    const plain = await open(this._s.down, iv, blob.subarray(12), AAD.s2c);
    this._rx = ctr; wnote("←", dec.decode(plain), data);
    this.onmessage && this.onmessage({data: dec.decode(plain)});
  }
  close() { try { this._ws && this._ws.close(); } catch (_) {} if (!this._ws) this._fail(1000); }
}

const imgCache = new Map();
function blobUrl(path) {
  if (!imgCache.has(path)) {
    imgCache.set(path, sfetch(path).then(r => { if (!r.ok) throw new Error("img"); return URL.createObjectURL(r.blob()); })
      .catch(e => { imgCache.delete(path); throw e; }));
  }
  return imgCache.get(path);
}
const SECURE_IMG = /^\/(uploads|avatars)\//;
const srcDesc = Object.getOwnPropertyDescriptor(HTMLImageElement.prototype, "src");
Object.defineProperty(HTMLImageElement.prototype, "src", {
  configurable: true, enumerable: true,
  get() { return srcDesc.get.call(this); },
  set(v) {
    if (typeof v === "string" && SECURE_IMG.test(v)) {
      this.dataset.sec = v;
      blobUrl(v).then(u => { if (this.dataset.sec === v) srcDesc.set.call(this, u); }).catch(() => {});
    } else { delete this.dataset.sec; srcDesc.set.call(this, v); }
  },
});
const nativeSet = Element.prototype.setAttribute;
Element.prototype.setAttribute = function (name, value) {
  if (this instanceof HTMLImageElement && String(name).toLowerCase() === "src") { this.src = value; return; }
  return nativeSet.call(this, name, value);
};

window.SC = {wire, supported, handshake, fetch: sfetch, socket: token => new SecSocket(token), blobUrl, setToken: t => { memToken = t || null; }};
})();
