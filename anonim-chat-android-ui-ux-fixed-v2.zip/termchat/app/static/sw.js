/* Anonim Chat — service worker.
   1) Brauzer ilovani "o'rnatiladigan" deb tan oladi (Android/desktop).
   2) Web Push: brauzer/ilova BUTUNLAY yopiq bo'lsa ham bildirishnoma ko'rsatadi (umumiy chat va lichka).
   Xavfsizlik: shifrlangan trafik (API/WebSocket) HECH QACHON keshlanmaydi. Push ichida xabar MATNI yo'q (E2EE). */
const SHELL = "shell-v2";
const OFFLINE_URLS = ["/static/icons/icon-192.png", "/static/icons/icon-512.png"];
const ICON = "/static/icons/icon-192.png";

self.addEventListener("install", e => {
  e.waitUntil(caches.open(SHELL).then(c => c.addAll(OFFLINE_URLS)).catch(() => {}));
  self.skipWaiting();
});

self.addEventListener("activate", e => {
  e.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(k => k !== SHELL).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", e => {
  const req = e.request;
  if (req.method !== "GET") return;                 // POST (shifrlangan tunnel) va boshqalar: tegmaymiz
  const url = new URL(req.url);
  if (url.origin !== location.origin) return;
  if (!url.pathname.startsWith("/static/icons/")) return;   // faqat ikonkalar keshlanadi; qolgani doim tarmoqdan
  e.respondWith(caches.match(req).then(hit => hit || fetch(req)));
});

/* ---------------- Web Push ---------------- */
async function show(d) {
  const group = d.k === "g";
  const tag = group ? "g" : "d" + d.u;
  const old = (await self.registration.getNotifications({tag}))[0];
  const od = old && old.data ? old.data : null;
  if (od && d.i != null && od.i === d.i) return;               // xuddi shu xabar (sahifa ham, push ham ko'rsatgan) — takrorlanmaydi
  const n = od ? (od.n || 1) + 1 : 1;
  const name = String(d.n || "Anonim").slice(0, 40);
  const title = group ? "Umumiy chat" : name;
  const body = n > 1 ? n + " ta yangi xabar" : (group ? name + ": yangi xabar" : "Yangi shaxsiy xabar");
  await self.registration.showNotification(title, {
    body, tag, renotify: true, icon: ICON, badge: ICON, timestamp: (d.t || Math.floor(Date.now() / 1000)) * 1000,
    vibrate: [120, 60, 120], data: {k: d.k, u: d.u, i: d.i, n}, lang: "uz",
  });
}

self.addEventListener("push", e => {
  let d = {};
  try { d = e.data ? e.data.json() : {}; } catch (_) {}
  if (!d || (d.k !== "g" && d.k !== "d")) d = {k: "g", n: "Anonim"};
  e.waitUntil(show(d));       // har push uchun bildirishnoma ko'rsatiladi (iOS/Chrome talabi: "userVisibleOnly")
});

/* Sahifa yashirin bo'lganda o'zi ko'rsatadigan bildirishnoma (push kelishidan oldingi qisqa vaqt uchun) */
self.addEventListener("message", e => {
  const m = e.data;
  if (m && m.type === "local-notify" && m.d) e.waitUntil(show(m.d));
});

self.addEventListener("notificationclick", e => {
  const data = e.notification.data || {};
  e.notification.close();
  const target = data.k === "d" ? "d" + data.u : "g";
  e.waitUntil((async () => {
    const wins = await clients.matchAll({type: "window", includeUncontrolled: true});
    const w = wins.find(c => "focus" in c);
    if (w) {
      try { await w.focus(); } catch (_) {}
      w.postMessage({type: "open-chat", k: data.k, u: data.u});
      return;
    }
    await clients.openWindow("/?o=" + encodeURIComponent(target));   // brauzer yopiq edi: ochiladi, kirgandan keyin shu chat ochiladi
  })());
});

self.addEventListener("notificationclose", () => {});
