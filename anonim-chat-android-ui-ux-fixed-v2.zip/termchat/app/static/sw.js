/* Anonim Chat — service worker.
   1) Brauzer ilovani "o'rnatiladigan" deb tan oladi (Android/desktop).
   2) Web Push: brauzer/ilova BUTUNLAY yopiq bo'lsa ham bildirishnoma ko'rsatadi (umumiy chat va lichka).
   Xavfsizlik: shifrlangan trafik (API/WebSocket) HECH QACHON keshlanmaydi. Push ichida xabar MATNI yo'q (E2EE). */
const SHELL = "shell-v3";
const OFFLINE_URLS = ["/static/icons/icon-192.png", "/static/icons/icon-512.png", "/static/icons/badge-96.png"];
const ICON = "/static/icons/icon-192.png";

self.addEventListener("install", e => {
  e.waitUntil(caches.open(SHELL).then(c => c.addAll(OFFLINE_URLS)).catch(() => {}));
  self.skipWaiting();
});

self.addEventListener("activate", e => {
  e.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(k => k !== SHELL).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", e => {
  const req = e.request;
  if (req.method !== "GET") return;                 // POST (shifrlangan tunnel) va boshqalar: tegmaymiz
  const url = new URL(req.url);
  if (url.origin !== location.origin) return;
  if (!url.pathname.startsWith("/static/icons/")) return;   // faqat ikonkalar keshlanadi; qolgani doim tarmoqdan
  e.respondWith(caches.match(req).then(hit => hit || fetch(req)));
});

/* ---------------- Web Push ---------------- */
const BADGE = "/static/icons/badge-96.png";       // Android status-bar uchun bir rangli (oq siluet) belgi
async function setBadge() {                      // ilova ikonkasidagi raqam (o'rnatilgan PWA: Android, desktop, iOS 16.4+)
  try {
    const nav = self.navigator;
    if (!nav || !nav.setAppBadge) return;
    const list = await self.registration.getNotifications();
    const total = list.reduce((a, n) => a + ((n.data && n.data.n) || 1), 0);
    if (total > 0) await nav.setAppBadge(total); else await nav.clearAppBadge();
  } catch (_) {}
}
const nameList = (names, extra) => {
  const a = names.slice(0, 2).join(", ");
  return extra > 0 ? a + " va yana " + extra + " kishi" : names.length > 1 ? names.slice(0, -1).join(", ") + " va " + names[names.length - 1] : a;
};
async function show(d) {
  const group = d.k === "g", chan = d.k === "c", call = d.k === "p";
  const tag = group ? "g" : (chan ? "c" : call ? "p" : "d") + d.u;
  const old = (await self.registration.getNotifications({tag}))[0];
  const od = old && old.data ? old.data : null;
  if (od && d.i != null && od.i === d.i) return;               // xuddi shu xabar (sahifa ham, push ham ko'rsatgan) — takrorlanmaydi
  const n = od ? (od.n || 1) + 1 : 1;
  const name = String(d.n || "Anonim").slice(0, 40);
  const names = od && od.names ? od.names.slice() : [];
  if (group && !names.includes(name)) names.push(name);
  const extra = Math.max(0, names.length - 2);
  let title, body;
  if (group) {
    title = "💬 Umumiy chat";
    body = n > 1 ? "✉️ " + n + " ta yangi xabar\n👥 " + nameList(names.slice(0, 3), extra) : "✉️ " + name + " yozdi";
  } else if (call) {
    title = "📞 " + name;
    body = "Sizga ovozli qo'ng'iroq qilmoqda. Javob berish uchun ilovani oching";
  } else if (chan) {
    title = "📢 " + name;                                       // kanalda name — kanal nomi
    body = n > 1 ? n + " ta yangi post" : "Kanalda yangi post";
  } else {
    title = "🔒 " + name;
    body = n > 1 ? "✉️ " + n + " ta yangi xabar" : "Sizga shaxsiy xabar yubordi";
  }
  await self.registration.showNotification(title, {
    body, tag, renotify: true, silent: false, icon: ICON, badge: BADGE, timestamp: (d.t || Math.floor(Date.now() / 1000)) * 1000,
    vibrate: call ? [400, 200, 400, 200, 400, 200, 400] : [180, 80, 180, 80, 260], requireInteraction: call, lang: "uz", dir: "ltr",
    actions: [{action: "open", title: "Ochish"}, {action: "dismiss", title: "Yopish"}],
    data: {k: d.k, u: d.u, i: d.i, n, names},
  });
  setBadge();
}

self.addEventListener("push", e => {
  let d = {};
  try { d = e.data ? e.data.json() : {}; } catch (_) {}
  if (!d || (d.k !== "g" && d.k !== "d" && d.k !== "c" && d.k !== "p")) d = {k: "g", n: "Anonim"};
  e.waitUntil(show(d));       // har push uchun bildirishnoma ko'rsatiladi (iOS/Chrome talabi: "userVisibleOnly")
});

/* Sahifa yashirin bo'lganda o'zi ko'rsatadigan bildirishnoma (push kelishidan oldingi qisqa vaqt uchun) */
self.addEventListener("message", e => {
  const m = e.data;
  if (m && m.type === "local-notify" && m.d) e.waitUntil(show(m.d));
});

self.addEventListener("notificationclick", e => {
  const data = e.notification.data || {};
  e.notification.close();
  if (e.action === "dismiss") { e.waitUntil(setBadge()); return; }
  const target = data.k === "d" || data.k === "p" ? "d" + data.u : data.k === "c" ? "c" + data.u : "g";
  e.waitUntil((async () => {
    const wins = await clients.matchAll({type: "window", includeUncontrolled: true});
    const w = wins.find(c => "focus" in c);
    await setBadge();
    if (w) {
      try { await w.focus(); } catch (_) {}
      w.postMessage({type: "open-chat", k: data.k, u: data.u});
      return;
    }
    await clients.openWindow("/?o=" + encodeURIComponent(target));   // brauzer yopiq edi: ochiladi, kirgandan keyin shu chat ochiladi
  })());
});

self.addEventListener("notificationclose", () => { setBadge(); });
