/* Anonim Chat — minimal service worker.
   Maqsad: brauzer ilovani "o'rnatiladigan" deb tan olsin (Android/desktop).
   Xavfsizlik: shifrlangan trafik (API/WebSocket) HECH QACHON keshlanmaydi. */
const SHELL = "shell-v1";
const OFFLINE_URLS = ["/static/icons/icon-192.png"];

self.addEventListener("install", e => {
  e.waitUntil(caches.open(SHELL).then(c => c.addAll(OFFLINE_URLS)).catch(() => {}));
  self.skipWaiting();
});

self.addEventListener("activate", e => {
  e.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(k => k !== SHELL).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", e => {
  const req = e.request;
  if (req.method !== "GET") return;                 // POST (shifrlangan tunnel) va boshqalar: tegmaymiz
  const url = new URL(req.url);
  if (url.origin !== location.origin) return;
  if (!url.pathname.startsWith("/static/icons/")) return;   // faqat ikonkalar keshlanadi; qolgani doim tarmoqdan
  e.respondWith(caches.match(req).then(hit => hit || fetch(req)));
});
