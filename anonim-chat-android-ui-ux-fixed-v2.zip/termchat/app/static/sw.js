
const SHELL = "shell-v29";
const OFFLINE_URLS = ["/static/icons/icon-192.png", "/static/icons/icon-512.png", "/static/icons/badge-96.png"];
const ICON = "/static/icons/icon-192.png";

async function precache() {
  const c = await caches.open(SHELL);
  await c.addAll(OFFLINE_URLS).catch(() => {});
  try {
    const r = await fetch("/", {cache: "reload"});
    if (!r.ok) return;
    const html = await r.clone().text();
    await c.put("/", r);
    const urls = new Set(["/static/manifest.json"]);
    for (const m of html.matchAll(/(?:src|href)="(\/static\/[^"#]+)"/g)) urls.add(m[1]);
    await Promise.all([...urls].map(u => fetch(u, {cache: "reload"}).then(x => x.ok ? c.put(u, x) : null).catch(() => {})));
  } catch (_) {}
}
self.addEventListener("install", e => {
  e.waitUntil(precache());
  self.skipWaiting();
});

self.addEventListener("activate", e => {
  e.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(k => k !== SHELL).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

const SHELL_RE = /^\/(static\/|avatars\/|emoji-files\/)/;
const NET_WAIT = 3500;
async function netFirst(req, key) {
  const cache = await caches.open(SHELL);
  const net = fetch(req).then(res => { if (res && res.ok && res.type === "basic") cache.put(key, res.clone()).catch(() => {}); return res; });
  net.catch(() => {});
  try { return await Promise.race([net, new Promise((_, rej) => setTimeout(rej, NET_WAIT))]); }
  catch (_) { const hit = await cache.match(key); return hit || net; }
}
async function cacheFirst(req) {
  const cache = await caches.open(SHELL), hit = await cache.match(req);
  if (hit) return hit;
  const res = await fetch(req);
  if (res && res.ok && res.type === "basic") cache.put(req, res.clone()).catch(() => {});
  return res;
}
self.addEventListener("fetch", e => {
  const req = e.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (url.origin !== location.origin) return;
  if (url.pathname.startsWith("/static/icons/")) { e.respondWith(caches.match(req).then(hit => hit || netFirst(req, req))); return; }
  if (req.mode === "navigate" && url.pathname === "/") { e.respondWith(netFirst(req, "/")); return; }
  if (/^\/(emoji-files|avatars)\//.test(url.pathname)) { e.respondWith(cacheFirst(req)); return; }
  if (SHELL_RE.test(url.pathname)) e.respondWith(netFirst(req, req));
});

const BADGE = "/static/icons/badge-96.png";
async function setBadge() {
  try {
    const nav = self.navigator;
    if (!nav || !nav.setAppBadge) return;
    const list = await self.registration.getNotifications();
    const total = list.reduce((a, n) => a + ((n.data && n.data.n) || 1), 0);
    if (total > 0) await nav.setAppBadge(total); else await nav.clearAppBadge();
  } catch (_) {}
}
const nameList = (names, extra) => {
  const a = names.slice(0, 2).join(", ");
  return extra > 0 ? a + " va yana " + extra + " kishi" : names.length > 1 ? names.slice(0, -1).join(", ") + " va " + names[names.length - 1] : a;
};
async function show(d) {
  const group = d.k === "g", chan = d.k === "c", game = d.k === "x";
  const tag = group ? "g" : (chan ? "c" : game ? "x" : "d") + d.u;
  const old = (await self.registration.getNotifications({tag}))[0];
  const od = old && old.data ? old.data : null;
  if (od && d.i != null && od.i === d.i) return;
  const n = od ? (od.n || 1) + 1 : 1;
  const name = String(d.n || "Anonim").slice(0, 40);
  const names = od && od.names ? od.names.slice() : [];
  if (group && !names.includes(name)) names.push(name);
  const extra = Math.max(0, names.length - 2);
  let title, body;
  if (group) {
    title = "💬 Umumiy chat";
    body = n > 1 ? "✉️ " + n + " ta yangi xabar\n👥 " + nameList(names.slice(0, 3), extra) : "✉️ " + name + " yozdi";
  } else if (game) {
    const ck = d.gm === "ck", dk = d.gm === "dk";
    title = dk ? "🃏 Durak taklifi" : ck ? "⛀ Shashka taklifi" : "♟ Shaxmat taklifi";
    body = name + (dk ? " sizni durak o'yiniga taklif qildi — tezroq oching (60 soniya)" : ck ? " sizni shashkaga taklif qildi — tezroq oching (60 soniya)" : " sizni shaxmatga taklif qildi — tezroq oching (10 soniya)");
  } else if (chan) {
    title = "📢 " + name;
    body = n > 1 ? n + " ta yangi post" : "Kanalda yangi post";
  } else {
    title = "🔒 " + name;
    body = n > 1 ? "✉️ " + n + " ta yangi xabar" : "Sizga shaxsiy xabar yubordi";
  }
  await self.registration.showNotification(title, {
    body, tag, renotify: true, silent: false, icon: ICON, badge: BADGE, timestamp: (d.t || Math.floor(Date.now() / 1000)) * 1000,
    vibrate: [180, 80, 180, 80, 260], lang: "uz", dir: "ltr",
    actions: [{action: "open", title: "Ochish"}, {action: "dismiss", title: "Yopish"}],
    data: {k: d.k, u: d.u, i: d.i, n, names},
  });
  setBadge();
}

self.addEventListener("push", e => {
  let d = {};
  try { d = e.data ? e.data.json() : {}; } catch (_) {}
  if (!d || (d.k !== "g" && d.k !== "d" && d.k !== "c" && d.k !== "x")) d = {k: "g", n: "Anonim"};
  e.waitUntil(show(d));
});

self.addEventListener("message", e => {
  const m = e.data;
  if (m && m.type === "local-notify" && m.d) e.waitUntil(show(m.d));
});

self.addEventListener("notificationclick", e => {
  const data = e.notification.data || {};
  e.notification.close();
  if (e.action === "dismiss") { e.waitUntil(setBadge()); return; }
  const target = data.k === "d" ? "d" + data.u : data.k === "c" ? "c" + data.u : data.k === "x" ? (data.gm === "dk" ? "z" : data.gm === "ck" ? "y" : "x") : "g";
  e.waitUntil((async () => {
    const wins = await clients.matchAll({type: "window", includeUncontrolled: true});
    const w = wins.find(c => "focus" in c);
    await setBadge();
    if (w) {
      try { await w.focus(); } catch (_) {}
      w.postMessage({type: "open-chat", k: data.k === "x" && data.gm === "dk" ? "z" : data.k === "x" && data.gm === "ck" ? "y" : data.k, u: data.u});
      return;
    }
    await clients.openWindow("/?o=" + encodeURIComponent(target));
  })());
});

self.addEventListener("notificationclose", () => { setBadge(); });
