"""Ilova darajasidagi shifrlangan kanal (TLS ustiga qo'shimcha qatlam).

Qo'l siqish (POST /api/handshake): brauzer va server ECDH P-256 kalit almashadi, HKDF-SHA256 bilan ikkita
AES-256-GCM kalit hosil bo'ladi (c2s va s2c). Shundan so'ng:

  * HTTP: har bir so'rov BITTA manzilga (POST /api/x) ketadi, tanasi shifrlangan. Haqiqiy metod, yo'l,
    so'rov parametrlari, token va tana shifr ichida. Javob ham shifrlangan. Wireshark / DevTools faqat
    `iv|ciphertext` ni ko'radi.
  * WebSocket: har bir kadr shifrlangan (base64). Token URL'da emas, birinchi shifrlangan kadrda.
  * Rasmlar (/uploads, /avatars) ham shu kanal orqali olinadi.

Eslatma: bu faqat KANAL qatlami (server uni ochadi). Xabar mazmunini himoyalovchi uchdan-uchga shifrlash (E2EE) alohida,
xabar konverti ichida: app/e2ee.py va app/static/js/e2ee.js. Kanal tarmoq tinglovchisidan, E2EE esa serverdan ham himoya qiladi.
"""
from __future__ import annotations

import asyncio
import base64
import json
import logging
import secrets
import time
from collections import OrderedDict
from types import SimpleNamespace
from urllib.parse import unquote

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat

from app.config import settings
from app.netutil import real_ip
from app.security import limiter
from app.services import memguard

log = logging.getLogger("termchat.transport")

TUNNEL_PATH = "/api/x"
HANDSHAKE_PATH = "/api/handshake"
ALLOWED_PREFIXES = ("/api/", "/uploads/", "/avatars/")
STATIC_GET_PREFIXES = ("/uploads/", "/avatars/")
METHODS = {"GET", "POST", "PATCH", "PUT", "DELETE"}

AAD_REQ, AAD_RES = b"termchat/v1/http-req", b"termchat/v1/http-res"
AAD_WS_C2S, AAD_WS_S2C = b"termchat/v1/ws-c2s", b"termchat/v1/ws-s2c"

MAX_BODY = settings.max_media_bytes + 4 * 1024 * 1024     # shifrlangan so'rov tanasi chegarasi (fayl + multipart/shifr qo'shimchasi)
SESSION_TTL = 24 * 3600
MAX_SESSIONS = 5000
CLOCK_SKEW = 300                      # soniya
REPLAY_WINDOW = 2 * CLOCK_SKEW


# Shifrlangan kanal tanasini butunlay xotiraga o'qishni talab qiladi (AES-GCM bitta yaxlit teg). Shu sababli bir vaqtda
# xotirada turadigan katta so'rovlar/javoblar hajmi cheklanadi: ortig'i 503 oladi (mijoz keyinroq qayta urinadi).
BIG_BODY = 1024 * 1024
# Bir vaqtda xotirada turadigan KATTA so'rovlar hajmi: ~1 ta to'liq (50 MB) fayl. Avval 3 ta edi: har biri shifrlash/ochish
# paytida 3 nusxa bo'lgani uchun 512 MB li serverda xotira to'lib ketardi. Ortig'i 503 oladi; mijoz 3 soniyadan keyin o'zi qayta urinadi.
INFLIGHT_BUDGET = settings.max_media_bytes + 8 * 1024 * 1024
MAX_DOWNLOADS = 2
_inflight = 0
_downloads = asyncio.Semaphore(MAX_DOWNLOADS)


class CryptoSession:
    __slots__ = ("kid", "up", "down", "created", "last", "seen", "_http_ctr", "_streams")

    def __init__(self, kid: str, key_c2s: bytes, key_s2c: bytes):
        self.kid = kid
        self.up = AESGCM(key_c2s)       # mijoz -> server (ochish)
        self.down = AESGCM(key_s2c)     # server -> mijoz (yopish)
        self.created = self.last = time.time()
        self.seen: dict[bytes, float] = {}
        self._http_ctr = 0              # HTTP javoblari uchun hisoblagich
        self._streams = 0               # WebSocket oqimlari uchun noyob prefikslar

    # server -> mijoz kalitida (`down`) AES-GCM nonce HECH QACHON takrorlanmasligi kerak. Tasodifiy 96-bit nonce amalda
    # xavfsiz, lekin bu yerda takrorlanmasligi kafolatlanadi: nonce = <4 bayt oqim raqami> | <8 bayt hisoblagich>.
    # Oqim 0 — HTTP javoblari, 1, 2, ... — har bir WebSocket ulanishi.
    def next_http_iv(self) -> bytes:
        self._http_ctr += 1
        return (0).to_bytes(4, "big") + self._http_ctr.to_bytes(8, "big")

    def new_stream(self) -> bytes:
        self._streams += 1
        if self._streams >= 2 ** 32:
            raise ValueError("oqimlar soni tugadi")
        return self._streams.to_bytes(4, "big")

    def check_fresh(self, iv: bytes, ts_ms) -> None:
        """Eski yoki takrorlangan so'rovni rad etadi (replay himoyasi)."""
        now = time.time()
        if not isinstance(ts_ms, (int, float)) or abs(now - ts_ms / 1000.0) > CLOCK_SKEW:
            raise ValueError("vaqt mos emas")
        if len(self.seen) > 2000:
            self.seen = {k: v for k, v in self.seen.items() if v > now}
        if iv in self.seen:
            raise ValueError("takroriy so'rov")
        self.seen[iv] = now + REPLAY_WINDOW


class SessionStore:
    def __init__(self) -> None:
        self._s: OrderedDict[str, CryptoSession] = OrderedDict()

    def create(self, client_pub: bytes) -> tuple[CryptoSession, bytes]:
        peer = ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(), client_pub)   # ValueError: noto'g'ri nuqta
        priv = ec.generate_private_key(ec.SECP256R1())
        server_pub = priv.public_key().public_bytes(Encoding.X962, PublicFormat.UncompressedPoint)
        shared = priv.exchange(ec.ECDH(), peer)
        salt = client_pub + server_pub

        def derive(info: bytes) -> bytes:
            return HKDF(algorithm=hashes.SHA256(), length=32, salt=salt, info=info).derive(shared)

        sess = CryptoSession(secrets.token_urlsafe(18), derive(b"termchat/v1/c2s"), derive(b"termchat/v1/s2c"))
        self._s[sess.kid] = sess
        while len(self._s) > MAX_SESSIONS:
            self._s.popitem(last=False)
        return sess, server_pub

    def get(self, kid: str) -> CryptoSession | None:
        s = self._s.get(kid)
        if s is None:
            return None
        if time.time() - s.created > SESSION_TTL:
            self._s.pop(kid, None)
            return None
        s.last = time.time()
        self._s.move_to_end(kid)
        return s


store = SessionStore()


# ----------------------------------------------------------------------------------- paket formati
def _split(plain: bytes) -> tuple[dict, bytes]:
    i = plain.find(b"\n")
    if i < 0:
        raise ValueError("format")
    meta = json.loads(plain[:i].decode("utf-8"))
    if not isinstance(meta, dict):
        raise ValueError("format")
    return meta, plain[i + 1:]


def open_request(sess: CryptoSession, blob: bytes) -> tuple[dict, bytes]:
    if len(blob) < 12 + 16:
        raise ValueError("qisqa")
    mv = memoryview(blob)
    iv = bytes(mv[:12])
    plain = sess.up.decrypt(iv, mv[12:], AAD_REQ)        # memoryview: shifrlangan qismning ortiqcha nusxasi olinmaydi
    del mv
    meta, body = _split(plain)
    del plain
    sess.check_fresh(iv, meta.get("t"))
    return meta, body


def seal_response_parts(sess: CryptoSession, status: int, content_type: str, body: bytes) -> tuple[bytes, bytes]:
    """(iv, shifrlangan_qism). Ikkalasi alohida qaytadi: `iv + ct` birlashtirish katta faylning yana bir nusxasini olardi."""
    meta = json.dumps({"s": status, "c": content_type}, separators=(",", ":")).encode()
    iv = sess.next_http_iv()
    return iv, sess.down.encrypt(iv, b"".join((meta, b"\n", body)), AAD_RES)


def seal_response(sess: CryptoSession, status: int, content_type: str, body: bytes) -> bytes:
    iv, ct = seal_response_parts(sess, status, content_type, body)
    return iv + ct


# ----------------------------------------------------------------------------------- ASGI middleware
def _hdrs(scope) -> dict[str, str]:
    return {k.decode("latin-1").lower(): v.decode("latin-1") for k, v in scope.get("headers", [])}


def _client_ip(scope) -> str:
    c = scope.get("client")
    return real_ip(_hdrs(scope), SimpleNamespace(host=c[0]) if c else None)


async def _respond(send, status: int, body: bytes, ctype: str, head: bytes = b"") -> None:
    await send({"type": "http.response.start", "status": status, "headers": [
        (b"content-type", ctype.encode()), (b"content-length", str(len(head) + len(body)).encode()),
        (b"cache-control", b"no-store"), (b"x-content-type-options", b"nosniff")]})
    if head:                                          # boshlanish (iv) alohida bo'lak: katta tanani nusxalamaymiz
        await send({"type": "http.response.body", "body": head, "more_body": True})
    await send({"type": "http.response.body", "body": body})


async def _json(send, status: int, obj: dict) -> None:
    await _respond(send, status, json.dumps(obj).encode(), "application/json")


async def _read(receive, limit: int) -> bytes | None:
    chunks, size = [], 0
    while True:
        m = await receive()
        if m["type"] == "http.disconnect":
            return None
        chunk = m.get("body", b"")
        size += len(chunk)
        if size > limit:
            return None
        chunks.append(chunk)
        if not m.get("more_body"):
            return b"".join(chunks)


class TunnelMiddleware:
    """Eng tashqi ASGI qatlami: shifrlangan so'rovni ochib, ichki ilovaga oddiy so'rov sifatida beradi."""

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] == "http":
            path, method = scope["path"], scope["method"]
            if path == HANDSHAKE_PATH and method == "POST":
                return await self._handshake(scope, receive, send)
            if path == TUNNEL_PATH and method == "POST":
                return await self._tunnel(scope, receive, send)
            if settings.require_tunnel and path.startswith(ALLOWED_PREFIXES):
                return await _json(send, 403, {"detail": "Faqat shifrlangan kanal orqali"})
        await self.app(scope, receive, send)

    async def _handshake(self, scope, receive, send):
        if not limiter.allow(f"hs:{_client_ip(scope)}", 40, 60):
            return await _json(send, 429, {"detail": "Juda ko'p urinish"})
        body = await _read(receive, 1024)
        try:
            pub = base64.b64decode(json.loads(body or b"{}")["pub"], validate=True)
            if len(pub) != 65 or pub[0] != 4:
                raise ValueError
            sess, server_pub = store.create(pub)
        except Exception:
            return await _json(send, 400, {"detail": "Noto'g'ri qo'l siqish"})
        await _json(send, 200, {"kid": sess.kid, "pub": base64.b64encode(server_pub).decode(), "ttl": SESSION_TTL})

    async def _tunnel(self, scope, receive, send):
        sess = store.get(_hdrs(scope).get("x-kid", ""))
        if sess is None:
            return await _json(send, 428, {"detail": "rekey"})
        global _inflight
        try:
            declared = int(_hdrs(scope).get("content-length") or 0)
        except ValueError:
            declared = 0
        reserved = declared if declared > BIG_BODY else 0
        if reserved:
            if declared > MAX_BODY:
                return await _json(send, 413, {"detail": "So'rov juda katta"})
            if _inflight + reserved > INFLIGHT_BUDGET:
                return await _json(send, 503, {"detail": "Server band, birozdan keyin qayta urinib ko'ring"})
            _inflight += reserved
        try:
            await self._tunnel_inner(scope, receive, send, sess)
        finally:
            _inflight -= reserved

    async def _tunnel_inner(self, scope, receive, send, sess):
        blob = await _read(receive, MAX_BODY)
        if blob is None:
            return await _json(send, 413, {"detail": "So'rov juda katta"})
        try:
            meta, inner_body = open_request(sess, blob)
            blob = None                                   # shifrlangan nusxa endi kerak emas: xotira darhol bo'shaydi
            method = str(meta.get("m", "")).upper()
            target = str(meta.get("p", ""))
            path, _, query = target.partition("?")
            upath = unquote(path)
            if (method not in METHODS or not upath.startswith(ALLOWED_PREFIXES) or ".." in upath or "\x00" in upath
                    or upath in (TUNNEL_PATH, HANDSHAKE_PATH)
                    or (upath.startswith(STATIC_GET_PREFIXES) and method != "GET")):
                raise ValueError("yo'l")
            ctype, token = meta.get("c") or "", meta.get("a") or ""
            if not isinstance(ctype, str) or not isinstance(token, str) or any(c in ctype + token for c in "\r\n"):
                raise ValueError("sarlavha")
        except (InvalidTag, ValueError, KeyError, UnicodeDecodeError, TypeError):
            return await _json(send, 400, {"detail": "Shifrni ochib bo'lmadi"})

        headers = [(k, v) for k, v in scope["headers"]
                   if k not in (b"content-type", b"content-length", b"authorization", b"x-kid", b"cookie")]
        if ctype:
            headers.append((b"content-type", ctype.encode("latin-1", "ignore")))
        headers.append((b"content-length", str(len(inner_body)).encode()))
        if token:
            headers.append((b"authorization", b"Bearer " + token.encode("latin-1", "ignore")))
        inner = dict(scope)
        inner.update(method=method, path=upath, raw_path=path.encode("utf-8"),
                     query_string=query.encode("utf-8"), headers=headers, extensions={},
                     state={**(scope.get("state") or {}), "tunnel": True})

        sent_body = False
        never = asyncio.Event()

        async def inner_receive():
            nonlocal sent_body
            if not sent_body:
                sent_body = True
                return {"type": "http.request", "body": inner_body, "more_body": False}
            await never.wait()                # javob tugaguncha "uzilish" signali yubormaymiz

        status, rheaders, chunks = 500, [], []

        async def inner_send(msg):
            nonlocal status, rheaders
            if msg["type"] == "http.response.start":
                status, rheaders = msg["status"], msg.get("headers", [])
            elif msg["type"] == "http.response.body":
                chunks.append(msg.get("body", b""))

        heavy = upath.startswith("/uploads/")             # katta fayl javobi: bir vaqtda ko'pi bilan MAX_DOWNLOADS ta
        if heavy:
            try:
                await asyncio.wait_for(_downloads.acquire(), 20)
            except asyncio.TimeoutError:
                return await _json(send, 503, {"detail": "Server band, birozdan keyin qayta urinib ko'ring"})
        try:
            await self.app(inner, inner_receive, inner_send)
        except Exception:
            log.exception("Ichki so'rov xatosi: %s %s", method, upath)
            if not chunks:
                status, rheaders, chunks = 500, [(b"content-type", b"application/json")], [b'{"detail":"Server xatosi"}']
        finally:
            if heavy:
                _downloads.release()
        rtype = next((v.decode("latin-1") for k, v in rheaders if k.lower() == b"content-type"), "application/octet-stream")
        inner_body = None                                 # yuklangan fayl so'rovi tanasi: javob yig'ilishidan oldin bo'shatiladi
        rbody = chunks[0] if len(chunks) == 1 else b"".join(chunks)
        chunks.clear()
        iv, ct = seal_response_parts(sess, status, rtype, rbody)
        big = len(rbody)
        del rbody
        await _respond(send, 200, ct, "application/octet-stream", head=iv)
        del ct
        memguard.after_big(big)


# ----------------------------------------------------------------------------------- WebSocket
class FrameTooBig(ValueError):
    """Mijoz ruxsat etilganidan katta kadr yubordi (xotirani to'ldirish urinishi)."""


def max_ws_frame() -> int:
    """Shifrlangan (base64) kadrning eng katta uzunligi: E2EE konvert + JSON o'ramasi, base64 ga o'tkazilgan."""
    return max(65536, (settings.e2e_max_envelope + 8192) * 4 // 3 + 128)


class SecureWS:
    """Starlette WebSocket ustidan: har bir matn kadrini shifrlaydi/ochadi. Ulanishlar menejeri bilan mos
    (`send_text`, `close`)."""

    def __init__(self, ws, sess: CryptoSession):
        self.raw, self._sess = ws, sess
        self._prefix = sess.new_stream()          # bu sessiyada noyob: boshqa ulanish bilan nonce to'qnashmaydi
        self._tx = 0
        self._rx_prefix: bytes | None = None
        self._rx = -1
        self._lock = asyncio.Lock()

    async def send_text(self, text: str) -> None:
        async with self._lock:              # tartib va hisoblagich buzilmasligi uchun
            self._tx += 1
            iv = self._prefix + self._tx.to_bytes(8, "big")
            ct = self._sess.down.encrypt(iv, text.encode("utf-8"), AAD_WS_S2C)
            await self.raw.send_text(base64.b64encode(iv + ct).decode("ascii"))

    async def receive_text(self) -> str:
        frame = await self.raw.receive_text()
        if len(frame) > max_ws_frame():
            raise FrameTooBig("kadr juda katta")
        blob = base64.b64decode(frame, validate=True)
        if len(blob) < 12 + 16:
            raise ValueError("qisqa kadr")
        iv, ct = blob[:12], blob[12:]
        prefix, ctr = iv[:4], int.from_bytes(iv[4:], "big")
        if self._rx_prefix is None:
            self._rx_prefix = prefix
        if prefix != self._rx_prefix or ctr <= self._rx:
            raise ValueError("takroriy kadr")
        text = self._sess.up.decrypt(iv, ct, AAD_WS_C2S).decode("utf-8")
        self._rx = ctr
        return text

    async def close(self, code: int = 1000) -> None:
        await self.raw.close(code)
