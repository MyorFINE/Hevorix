from app.db import db


def create(token_hash: str, uid: int, now: float, persistent: bool = False, device: str | None = None,
           ip_enc: str | None = None, ua_hash: str | None = None) -> None:
    db.run("INSERT INTO sessions(token_hash,user_id,created_at,last_active,persistent,device,ip_enc,ua_hash) VALUES(?,?,?,?,?,?,?,?)",
           (token_hash, uid, now, now, 1 if persistent else 0, device, ip_enc, ua_hash))


def get_binding(token_hash: str) -> str | None:
    """Sessiya yaratilgan qurilmaning izi (brauzer • tizim hash'i). Eski sessiyalarda None."""
    r = db.one("SELECT ua_hash FROM sessions WHERE token_hash=?", (token_hash,))
    return r["ua_hash"] if r else None


def count_for_user(uid: int) -> int:
    r = db.one("SELECT COUNT(*) AS n FROM sessions WHERE user_id=?", (uid,))
    return int(r["n"]) if r else 0


def get_user(token_hash: str, active_since: float = 0.0, persist_since: float = 0.0):
    """Token bo'yicha foydalanuvchi. Oddiy sessiya `active_since` dan oldin oxirgi faol bo'lgan bo'lsa (faolsizlikdan tugagan)
    HISOBGA OLINMAYDI. \"Kirib qolish\" (persistent) sessiyasi esa `persist_since` gacha amal qiladi."""
    return db.one(
        "SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id "
        "WHERE s.token_hash=? AND COALESCE(s.last_active, s.created_at) >= "
        "CASE WHEN s.persistent=1 THEN ? ELSE ? END", (token_hash, persist_since, active_since))


def set_persistent(token_hash: str, on: bool) -> None:
    db.run("UPDATE sessions SET persistent=? WHERE token_hash=?", (1 if on else 0, token_hash))


def touch(token_hash: str, now: float) -> None:
    """Oxirgi faollikni yangilaydi va onlayn bo'lgan vaqtni yig'adi (bo'shliq 2 daqiqadan oshsa, faqat 2 daqiqa qo'shiladi)."""
    db.run("UPDATE sessions SET online_s=COALESCE(online_s,0)+MIN(MAX(?-COALESCE(last_active,created_at),0),120), last_active=? WHERE token_hash=?",
           (now, now, token_hash))


def purge_idle(active_since: float, persist_since: float = 0.0) -> int:
    """Faolsizlikdan tugagan sessiyalarni bazadan o'chiradi (qaytgan foydalanuvchi qayta login qiladi)."""
    with db._lock:
        cur = db._conn.execute(
            "DELETE FROM sessions WHERE COALESCE(last_active, created_at) < CASE WHEN persistent=1 THEN ? ELSE ? END",
            (persist_since, active_since))
        db._conn.commit()
        return cur.rowcount


def delete(token_hash: str) -> None:
    db.run("DELETE FROM sessions WHERE token_hash=?", (token_hash,))


def delete_for_user(uid: int, keep: str | None = None) -> None:
    if keep:
        db.run("DELETE FROM sessions WHERE user_id=? AND token_hash!=?", (uid, keep))
    else:
        db.run("DELETE FROM sessions WHERE user_id=?", (uid,))


SID_LEN = 16          # ochiq sessiya identifikatori = token hash'ining birinchi 16 belgisi (tokenning o'zini oshkor qilmaydi)


def list_for_user(uid: int, active_since: float, persist_since: float):
    """Foydalanuvchining hali amal qilayotgan sessiyalari (eng yangisi birinchi)."""
    return db.all(
        "SELECT substr(token_hash,1,?) AS sid, token_hash, created_at, COALESCE(last_active, created_at) AS last_active, persistent, "
        "device, ip_enc, COALESCE(online_s,0) AS online_s "
        "FROM sessions WHERE user_id=? AND COALESCE(last_active, created_at) >= CASE WHEN persistent=1 THEN ? ELSE ? END "
        "ORDER BY COALESCE(last_active, created_at) DESC", (SID_LEN, uid, persist_since, active_since))


def delete_by_sid(uid: int, sid: str) -> int:
    """Faqat shu foydalanuvchiga tegishli sessiyani o'chiradi (boshqa birovniki hech qachon)."""
    with db._lock:
        cur = db._conn.execute("DELETE FROM sessions WHERE user_id=? AND substr(token_hash,1,?)=?", (uid, SID_LEN, sid))
        db._conn.commit()
        return cur.rowcount
