from app.db import db


def create(token_hash: str, uid: int, now: float) -> None:
    db.run("INSERT INTO sessions(token_hash,user_id,created_at,last_active) VALUES(?,?,?,?)", (token_hash, uid, now, now))


def get_user(token_hash: str, active_since: float = 0.0):
    """Token bo'yicha foydalanuvchi. `active_since` > 0 bo'lsa, shu vaqtdan oldin oxirgi marta faol bo'lgan (faolsizlikdan
    tugagan) sessiya HISOBGA OLINMAYDI."""
    return db.one(
        "SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id "
        "WHERE s.token_hash=? AND COALESCE(s.last_active, s.created_at) >= ?", (token_hash, active_since))


def touch(token_hash: str, now: float) -> None:
    db.run("UPDATE sessions SET last_active=? WHERE token_hash=?", (now, token_hash))


def purge_idle(active_since: float) -> int:
    """Faolsizlikdan tugagan sessiyalarni bazadan o'chiradi (qaytgan foydalanuvchi qayta login qiladi)."""
    with db._lock:
        cur = db._conn.execute("DELETE FROM sessions WHERE COALESCE(last_active, created_at) < ?", (active_since,))
        db._conn.commit()
        return cur.rowcount


def delete(token_hash: str) -> None:
    db.run("DELETE FROM sessions WHERE token_hash=?", (token_hash,))


def delete_for_user(uid: int, keep: str | None = None) -> None:
    if keep:
        db.run("DELETE FROM sessions WHERE user_id=? AND token_hash!=?", (uid, keep))
    else:
        db.run("DELETE FROM sessions WHERE user_id=?", (uid,))
