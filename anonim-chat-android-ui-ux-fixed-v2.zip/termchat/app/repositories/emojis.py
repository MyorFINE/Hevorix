"""Maxsus emojilar va emoji to'plamlari (pack) jadvallari."""
from app.db import db


# ----------------------------------------------------------------------------------- emojilar
def all_emojis():
    return db.all(
        """SELECT e.id, e.name, e.file, e.anim, e.animated, e.pack_id, e.public, e.created_by, e.created_at,
                  u.nickname AS author
           FROM custom_emojis e LEFT JOIN users u ON u.id = e.created_by ORDER BY e.id"""
    )


def get(eid: int):
    return db.one("SELECT * FROM custom_emojis WHERE id=?", (eid,))


def get_by_name(name: str):
    return db.one("SELECT * FROM custom_emojis WHERE name=?", (name,))


def count_by(uid: int) -> int:
    return db.one("SELECT COUNT(*) AS n FROM custom_emojis WHERE created_by=?", (uid,))["n"]


def add(name, file, anim, animated, pack_id, public, created_by, now) -> int:
    return db.run(
        "INSERT INTO custom_emojis(name,file,anim,animated,pack_id,public,created_by,created_at) VALUES(?,?,?,?,?,?,?,?)",
        (name, file, anim or None, 1 if animated else 0, pack_id, 1 if public else 0, created_by, now),
    )


def update(eid: int, *, anim, pack_id, public) -> None:
    db.run("UPDATE custom_emojis SET anim=?, pack_id=?, public=? WHERE id=?", (anim or None, pack_id, 1 if public else 0, eid))


def remove(eid: int) -> None:
    db.run("DELETE FROM custom_emojis WHERE id=?", (eid,))


# ----------------------------------------------------------------------------------- to'plamlar
def all_packs():
    return db.all("SELECT id, name, public, kind, scale, created_by, created_at FROM emoji_packs ORDER BY id")


def get_pack(pid: int):
    return db.one("SELECT * FROM emoji_packs WHERE id=?", (pid,))


def pack_by_name(name: str):
    return db.one("SELECT * FROM emoji_packs WHERE name=?", (name,))


def add_pack(name: str, public: bool, created_by: int, now: float, kind: str = "emoji", scale: int = 100) -> int:
    return db.run("INSERT INTO emoji_packs(name,public,created_by,created_at,kind,scale) VALUES(?,?,?,?,?,?)",
                  (name, 1 if public else 0, created_by, now, kind, scale))


def update_pack(pid: int, name: str, public: bool, kind: str, scale: int) -> None:
    db.run("UPDATE emoji_packs SET name=?, public=?, kind=?, scale=? WHERE id=?", (name, 1 if public else 0, kind, scale, pid))


def set_pack_public(pid: int, public: bool) -> None:
    db.run("UPDATE custom_emojis SET public=? WHERE pack_id=?", (1 if public else 0, pid))


def remove_pack(pid: int) -> None:
    db.run("DELETE FROM emoji_packs WHERE id=?", (pid,))
