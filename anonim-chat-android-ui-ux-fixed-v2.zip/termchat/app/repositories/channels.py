from app.db import db

_CH = ("SELECT c.*, (SELECT COUNT(*) FROM channel_members m WHERE m.channel_id=c.id) AS members, "
       "(SELECT COUNT(*) FROM messages p WHERE p.channel_id=c.id AND p.deleted=0) AS posts, "
       "(SELECT MAX(id) FROM messages p WHERE p.channel_id=c.id AND p.deleted=0) AS last_post, "
       "(SELECT MAX(created_at) FROM messages p WHERE p.channel_id=c.id AND p.deleted=0) AS last_ts, "
       "EXISTS(SELECT 1 FROM channel_members m WHERE m.channel_id=c.id AND m.user_id=?) AS joined FROM channels c ")


def list_for(uid: int, staff: bool):
    where = "" if staff else "WHERE c.is_private=0 OR EXISTS(SELECT 1 FROM channel_members m WHERE m.channel_id=c.id AND m.user_id=?) "
    args = (uid,) if staff else (uid, uid)
    return db.all(_CH + where + "ORDER BY COALESCE((SELECT MAX(created_at) FROM messages p WHERE p.channel_id=c.id AND p.deleted=0), c.created_at) DESC", args)


def get(cid: int, uid: int = 0):
    return db.one(_CH + "WHERE c.id=?", (uid, cid))


def get_by_username(name: str):
    return db.one("SELECT * FROM channels WHERE username=?", (name.lower(),))


def create(username: str, nickname: str, is_private: bool, pw_hash: str | None, owner_id: int, now: float) -> int:
    return db.run("INSERT INTO channels(username,nickname,is_private,pw_hash,owner_id,created_at) VALUES(?,?,?,?,?,?)",
                  (username.lower(), nickname, 1 if is_private else 0, pw_hash, owner_id, now))


def update(cid: int, **fields) -> None:
    if not fields:
        return
    cols = ",".join(f"{k}=?" for k in fields)
    db.run(f"UPDATE channels SET {cols} WHERE id=?", (*fields.values(), cid))


def delete(cid: int) -> None:
    db.run("DELETE FROM channels WHERE id=?", (cid,))


def is_member(cid: int, uid: int) -> bool:
    return db.one("SELECT 1 FROM channel_members WHERE channel_id=? AND user_id=?", (cid, uid)) is not None


def add_member(cid: int, uid: int, now: float) -> None:
    db.run("INSERT OR IGNORE INTO channel_members(channel_id,user_id,joined_at) VALUES(?,?,?)", (cid, uid, now))


def remove_member(cid: int, uid: int) -> None:
    db.run("DELETE FROM channel_members WHERE channel_id=? AND user_id=?", (cid, uid))


def member_ids(cid: int) -> list[int]:
    return [r["user_id"] for r in db.all("SELECT user_id FROM channel_members WHERE channel_id=?", (cid,))]


def clear_members(cid: int) -> None:
    db.run("DELETE FROM channel_members WHERE channel_id=?", (cid,))


def post_counts(pid: int) -> tuple[int, int]:
    v = db.one("SELECT COUNT(*) AS c FROM post_views WHERE post_id=?", (pid,))["c"]
    c = db.one("SELECT COUNT(*) AS c FROM post_comments WHERE post_id=?", (pid,))["c"]
    return v, c


def view_posts(cid: int, uid: int, ids: list[int]) -> dict[int, int]:
    changed: dict[int, int] = {}
    with db._lock:
        for pid in ids:
            row = db._conn.execute("SELECT user_id FROM messages WHERE id=? AND channel_id=? AND deleted=0", (pid, cid)).fetchone()
            if not row or row["user_id"] == uid:
                continue
            cur = db._conn.execute("INSERT OR IGNORE INTO post_views(post_id,user_id) VALUES(?,?)", (pid, uid))
            if cur.rowcount:
                changed[pid] = db._conn.execute("SELECT COUNT(*) AS c FROM post_views WHERE post_id=?", (pid,)).fetchone()["c"]
        db._conn.commit()
    return changed


def drop_post_data(pid: int) -> None:
    with db._lock:
        db._conn.execute("DELETE FROM post_comments WHERE post_id=?", (pid,))
        db._conn.execute("DELETE FROM post_views WHERE post_id=?", (pid,))
        db._conn.commit()


def comments_page(pid: int, before: int, limit: int):
    if before:
        return db.all("SELECT * FROM post_comments WHERE post_id=? AND id<? ORDER BY id DESC LIMIT ?", (pid, before, limit))
    return db.all("SELECT * FROM post_comments WHERE post_id=? ORDER BY id DESC LIMIT ?", (pid, limit))


def comment(kid: int):
    return db.one("SELECT * FROM post_comments WHERE id=?", (kid,))


def add_comment(pid: int, uid: int, content: str, now: float, e2e: bool = True) -> int:
    return db.run("INSERT INTO post_comments(post_id,user_id,content,e2e,created_at) VALUES(?,?,?,?,?)", (pid, uid, content, int(e2e), now))


def delete_comment(kid: int) -> None:
    db.run("DELETE FROM post_comments WHERE id=?", (kid,))


def comment_count(pid: int) -> int:
    return db.one("SELECT COUNT(*) AS c FROM post_comments WHERE post_id=?", (pid,))["c"]


def migrate_legacy_posts() -> int:
    from app import crypto
    old = db.all("SELECT * FROM channel_posts ORDER BY id")
    moved = 0
    for r in old:
        text = crypto.open_(r["content"], "chpost")
        with db._lock:
            c = db._conn
            cur = c.execute("INSERT INTO messages(user_id,content,created_at,edited_at,channel_id,e2e) VALUES(?,?,?,?,?,0)",
                            (r["user_id"], crypto.seal(text, "msg"), r["created_at"], r["edited_at"], r["channel_id"]))
            nid = cur.lastrowid
            for k in c.execute("SELECT * FROM channel_comments WHERE post_id=? ORDER BY id", (r["id"],)).fetchall():
                c.execute("INSERT INTO post_comments(post_id,user_id,content,e2e,created_at) VALUES(?,?,?,0,?)",
                          (nid, k["user_id"], k["content"], k["created_at"]))
            c.execute("INSERT OR IGNORE INTO post_views(post_id,user_id) SELECT ?, user_id FROM channel_post_views WHERE post_id=?", (nid, r["id"]))
            c.execute("DELETE FROM channel_posts WHERE id=?", (r["id"],))
            c.commit()
        moved += 1
    return moved
