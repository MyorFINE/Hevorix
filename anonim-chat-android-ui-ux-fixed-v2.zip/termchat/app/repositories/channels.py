"""Kanallar, postlar, ko'rishlar va kommentlar (bazaga so'rovlar)."""
from app.db import db

_CH = ("SELECT c.*, (SELECT COUNT(*) FROM channel_members m WHERE m.channel_id=c.id) AS members, "
       "(SELECT COUNT(*) FROM channel_posts p WHERE p.channel_id=c.id) AS posts, "
       "(SELECT MAX(id) FROM channel_posts p WHERE p.channel_id=c.id) AS last_post, "
       "EXISTS(SELECT 1 FROM channel_members m WHERE m.channel_id=c.id AND m.user_id=?) AS joined FROM channels c ")


def list_for(uid: int, staff: bool):
    """Admin hammasini ko'radi; oddiy foydalanuvchi — ommaviy va o'zi parol bilan qo'shilgan shaxsiy kanallarni."""
    where = "" if staff else "WHERE c.is_private=0 OR EXISTS(SELECT 1 FROM channel_members m WHERE m.channel_id=c.id AND m.user_id=?) "
    args = (uid,) if staff else (uid, uid)
    return db.all(_CH + where + "ORDER BY COALESCE((SELECT MAX(created_at) FROM channel_posts p WHERE p.channel_id=c.id), c.created_at) DESC", args)


def get(cid: int, uid: int = 0):
    return db.one(_CH + "WHERE c.id=?", (uid, cid))


def get_by_username(name: str):
    return db.one("SELECT * FROM channels WHERE username=?", (name.lower(),))


def create(username: str, nickname: str, is_private: bool, pw_hash: str | None, owner_id: int, now: float) -> int:
    return db.run("INSERT INTO channels(username,nickname,is_private,pw_hash,owner_id,created_at) VALUES(?,?,?,?,?,?)",
                  (username.lower(), nickname, 1 if is_private else 0, pw_hash, owner_id, now))


def update(cid: int, **fields) -> None:
    if not fields:
        return
    cols = ",".join(f"{k}=?" for k in fields)
    db.run(f"UPDATE channels SET {cols} WHERE id=?", (*fields.values(), cid))


def delete(cid: int) -> None:
    db.run("DELETE FROM channels WHERE id=?", (cid,))


def is_member(cid: int, uid: int) -> bool:
    return db.one("SELECT 1 FROM channel_members WHERE channel_id=? AND user_id=?", (cid, uid)) is not None


def add_member(cid: int, uid: int, now: float) -> None:
    db.run("INSERT OR IGNORE INTO channel_members(channel_id,user_id,joined_at) VALUES(?,?,?)", (cid, uid, now))


def remove_member(cid: int, uid: int) -> None:
    db.run("DELETE FROM channel_members WHERE channel_id=? AND user_id=?", (cid, uid))


def member_ids(cid: int) -> list[int]:
    return [r["user_id"] for r in db.all("SELECT user_id FROM channel_members WHERE channel_id=?", (cid,))]


def clear_members(cid: int) -> None:
    db.run("DELETE FROM channel_members WHERE channel_id=?", (cid,))


# ---- postlar
_POST = ("SELECT p.*, (SELECT COUNT(*) FROM channel_post_views v WHERE v.post_id=p.id) AS views, "
         "(SELECT COUNT(*) FROM channel_comments c WHERE c.post_id=p.id) AS comments FROM channel_posts p ")


def posts_page(cid: int, before: int, limit: int):
    if before:
        return db.all(_POST + "WHERE p.channel_id=? AND p.id<? ORDER BY p.id DESC LIMIT ?", (cid, before, limit))
    return db.all(_POST + "WHERE p.channel_id=? ORDER BY p.id DESC LIMIT ?", (cid, limit))


def post(pid: int):
    return db.one(_POST + "WHERE p.id=?", (pid,))


def add_post(cid: int, uid: int, content: str, now: float) -> int:
    return db.run("INSERT INTO channel_posts(channel_id,user_id,content,created_at) VALUES(?,?,?,?)", (cid, uid, content, now))


def edit_post(pid: int, content: str, now: float) -> None:
    db.run("UPDATE channel_posts SET content=?, edited_at=? WHERE id=?", (content, now, pid))


def delete_post(pid: int) -> None:
    db.run("DELETE FROM channel_posts WHERE id=?", (pid,))


def view_posts(cid: int, uid: int, ids: list[int]) -> dict[int, int]:
    """Ko'rilgan postlarni belgilaydi (post muallifi sanalmaydi). Yangi sanalgan postlar uchun {id: yangi soni} qaytaradi."""
    changed: dict[int, int] = {}
    with db._lock:
        for pid in ids:
            row = db._conn.execute("SELECT user_id FROM channel_posts WHERE id=? AND channel_id=?", (pid, cid)).fetchone()
            if not row or row["user_id"] == uid:
                continue
            cur = db._conn.execute("INSERT OR IGNORE INTO channel_post_views(post_id,user_id) VALUES(?,?)", (pid, uid))
            if cur.rowcount:
                changed[pid] = db._conn.execute("SELECT COUNT(*) AS c FROM channel_post_views WHERE post_id=?", (pid,)).fetchone()["c"]
        db._conn.commit()
    return changed


# ---- kommentlar
def comments_page(pid: int, before: int, limit: int):
    if before:
        return db.all("SELECT * FROM channel_comments WHERE post_id=? AND id<? ORDER BY id DESC LIMIT ?", (pid, before, limit))
    return db.all("SELECT * FROM channel_comments WHERE post_id=? ORDER BY id DESC LIMIT ?", (pid, limit))


def comment(cid: int):
    return db.one("SELECT * FROM channel_comments WHERE id=?", (cid,))


def add_comment(pid: int, uid: int, content: str, now: float) -> int:
    return db.run("INSERT INTO channel_comments(post_id,user_id,content,created_at) VALUES(?,?,?,?)", (pid, uid, content, now))


def delete_comment(cid: int) -> None:
    db.run("DELETE FROM channel_comments WHERE id=?", (cid,))


def comment_count(pid: int) -> int:
    return db.one("SELECT COUNT(*) AS c FROM channel_comments WHERE post_id=?", (pid,))["c"]
