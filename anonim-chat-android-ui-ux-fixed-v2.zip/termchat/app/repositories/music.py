from app.db import db


def list_for_user(uid: int):
    return db.all("SELECT * FROM profile_music WHERE user_id=? ORDER BY pos, id", (uid,))


def count(uid: int) -> int:
    return db.one("SELECT COUNT(*) AS c FROM profile_music WHERE user_id=?", (uid,))["c"]


def get(track_id: int):
    return db.one("SELECT * FROM profile_music WHERE id=?", (track_id,))


def next_pos(uid: int) -> int:
    r = db.one("SELECT COALESCE(MAX(pos), 0) + 1 AS p FROM profile_music WHERE user_id=?", (uid,))
    return r["p"]


def add(uid: int, filename: str, title: str, artist: str, duration: int, size: int, mime: str, now: float) -> int:
    return db.run(
        "INSERT INTO profile_music(user_id,filename,title,artist,duration,size,mime,pos,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
        (uid, filename, title, artist, duration, size, mime, next_pos(uid), now),
    )


def rename(track_id: int, title: str, artist: str) -> None:
    db.run("UPDATE profile_music SET title=?, artist=? WHERE id=?", (title, artist, track_id))


def delete(track_id: int) -> None:
    db.run("DELETE FROM profile_music WHERE id=?", (track_id,))
