from app.db import db


def get_user(mid: int, uid: int) -> str | None:
    r = db.one("SELECT emoji FROM reactions WHERE message_id=? AND user_id=?", (mid, uid))
    return r["emoji"] if r else None


def put(mid: int, uid: int, emoji: str, now: float) -> None:
    db.run("INSERT INTO reactions(message_id,user_id,emoji,created_at) VALUES(?,?,?,?) "
           "ON CONFLICT(message_id,user_id) DO UPDATE SET emoji=excluded.emoji, created_at=excluded.created_at",
           (mid, uid, emoji, now))


def remove(mid: int, uid: int) -> None:
    db.run("DELETE FROM reactions WHERE message_id=? AND user_id=?", (mid, uid))


def grouped(mid: int) -> dict[str, list[int]]:
    rows = db.all("SELECT emoji, user_id FROM reactions WHERE message_id=? ORDER BY created_at, user_id", (mid,))
    out: dict[str, list[int]] = {}
    for r in rows:
        out.setdefault(r["emoji"], []).append(r["user_id"])
    return dict(sorted(out.items(), key=lambda kv: -len(kv[1])))
