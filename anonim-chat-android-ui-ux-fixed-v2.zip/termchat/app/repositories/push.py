import time

from app.db import db


def upsert(uid: int, endpoint: str, p256dh: str, auth: str, max_devices: int) -> None:
    now = time.time()
    with db._lock:
        db._conn.execute(
            "INSERT INTO push_subs(user_id,endpoint,p256dh,auth,created_at) VALUES(?,?,?,?,?) "
            "ON CONFLICT(endpoint) DO UPDATE SET user_id=excluded.user_id, p256dh=excluded.p256dh, auth=excluded.auth, created_at=excluded.created_at",
            (uid, endpoint, p256dh, auth, now))
        db._conn.execute(
            "DELETE FROM push_subs WHERE user_id=? AND id NOT IN "
            "(SELECT id FROM push_subs WHERE user_id=? ORDER BY created_at DESC LIMIT ?)", (uid, uid, max(1, max_devices)))
        db._conn.commit()


def remove(endpoint: str, uid: int | None = None) -> None:
    if uid is None:
        db.run("DELETE FROM push_subs WHERE endpoint=?", (endpoint,))
    else:
        db.run("DELETE FROM push_subs WHERE endpoint=? AND user_id=?", (endpoint, uid))


def has(uid: int, endpoint: str) -> bool:
    return db.one("SELECT 1 FROM push_subs WHERE user_id=? AND endpoint=?", (uid, endpoint)) is not None


def for_users(uids) -> list:
    uids = list(uids)
    if not uids:
        return []
    out = []
    for i in range(0, len(uids), 500):
        chunk = uids[i:i + 500]
        out += db.all("SELECT s.* FROM push_subs s JOIN users u ON u.id=s.user_id "
                      f"WHERE s.user_id IN ({','.join('?' * len(chunk))}) AND u.banned=0 AND u.deleted=0", chunk)
    return out


def for_everyone_except(uid: int) -> list:
    return db.all("SELECT s.* FROM push_subs s JOIN users u ON u.id=s.user_id WHERE s.user_id!=? AND u.banned=0 AND u.deleted=0", (uid,))


def mark_ok(sub_id: int) -> None:
    db.run("UPDATE push_subs SET last_ok=? WHERE id=?", (time.time(), sub_id))
