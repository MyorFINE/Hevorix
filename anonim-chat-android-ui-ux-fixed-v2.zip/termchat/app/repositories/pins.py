"""Mahkamlangan (pin) xabarlar. user_id=0 — umumiy chat uchun umumiy pin; aks holda lichkada shu foydalanuvchining shaxsiy pini."""
from app.db import db

GROUP = 0


def has(mid: int, uid: int) -> bool:
    return db.one("SELECT 1 FROM chat_msg_pins WHERE message_id=? AND user_id=?", (mid, uid)) is not None


def put(mid: int, uid: int, now: float) -> None:
    db.run("INSERT OR IGNORE INTO chat_msg_pins(message_id,user_id,created_at) VALUES(?,?,?)", (mid, uid, now))


def remove(mid: int, uid: int) -> None:
    db.run("DELETE FROM chat_msg_pins WHERE message_id=? AND user_id=?", (mid, uid))


def group_rows() -> list:
    """Umumiy chatdagi pinlar (o'chirilmagan xabarlar), eng yangi pinlangani oxirida."""
    return db.all(
        "SELECT m.* FROM chat_msg_pins p JOIN messages m ON m.id=p.message_id "
        "WHERE p.user_id=0 AND m.deleted=0 AND m.recipient_id IS NULL AND m.channel_id IS NULL ORDER BY p.created_at, m.id")


def dm_rows(uid: int, partner_id: int) -> list:
    """`uid` ning `partner_id` bilan lichkasidagi shaxsiy pinlari."""
    return db.all(
        "SELECT m.* FROM chat_msg_pins p JOIN messages m ON m.id=p.message_id "
        "WHERE p.user_id=? AND m.deleted=0 AND m.channel_id IS NULL AND m.recipient_id IS NOT NULL "
        "AND ((m.user_id=? AND m.recipient_id=?) OR (m.user_id=? AND m.recipient_id=?)) ORDER BY p.created_at, m.id",
        (uid, uid, partner_id, partner_id, uid))
