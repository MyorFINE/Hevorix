from app.db import db


def count() -> int:
    return db.one("SELECT COUNT(*) AS c FROM users")["c"]


def create(username: str, nickname: str, password_hash: str, role: str, now: float, e2ee: dict | None = None) -> int:
    if e2ee:
        return db.run(
            "INSERT INTO users(username,nickname,password_hash,role,created_at,ecdh_pub,sign_pub,key_blob,kdf_iter,auth_v) "
            "VALUES(?,?,?,?,?,?,?,?,?,1)",
            (username, nickname, password_hash, role, now, e2ee["ecdh_pub"], e2ee["sign_pub"], e2ee["key_blob"], e2ee["kdf_iter"]),
        )
    return db.run(
        "INSERT INTO users(username,nickname,password_hash,role,created_at) VALUES(?,?,?,?,?)",
        (username, nickname, password_hash, role, now),
    )


def set_e2ee(uid: int, password_hash: str, e2ee: dict) -> None:
    db.run("UPDATE users SET password_hash=?, ecdh_pub=?, sign_pub=?, key_blob=?, kdf_iter=?, auth_v=1 WHERE id=? AND auth_v=0",
           (password_hash, e2ee["ecdh_pub"], e2ee["sign_pub"], e2ee["key_blob"], e2ee["kdf_iter"], uid))


def set_key_blob(uid: int, password_hash: str, key_blob: str, kdf_iter: int) -> None:
    db.run("UPDATE users SET password_hash=?, key_blob=?, kdf_iter=? WHERE id=?", (password_hash, key_blob, kdf_iter, uid))


def key_rows(ids: list[int]):
    if not ids:
        return []
    marks = ",".join("?" * len(ids))
    return db.all(f"SELECT id, ecdh_pub, sign_pub FROM users WHERE id IN ({marks})", tuple(ids))


def keyed_active():
    return db.all("SELECT id, ecdh_pub, sign_pub FROM users WHERE deleted=0 AND banned=0 AND ecdh_pub IS NOT NULL ORDER BY id")


def get(uid: int):
    return db.one("SELECT * FROM users WHERE id=?", (uid,))


def get_by_username(name: str):
    return db.one("SELECT * FROM users WHERE username=?", (name.strip().lstrip("@").lower(),))


def get_view(uid: int):
    return db.one(
        """SELECT u.id, u.username, u.nickname, u.role, u.bio, u.color, u.created_at, u.deleted, u.badge, u.badge_anim,
                  u.trust, u.fx, u.banner, u.frame, u.title, u.last_seen, a.filename AS avatar
           FROM users u LEFT JOIN avatars a ON a.id = u.active_avatar_id WHERE u.id=?""",
        (uid,),
    )


def touch_seen(uid: int, ts: float) -> None:
    db.run("UPDATE users SET last_seen=? WHERE id=?", (ts, uid))


def list_staff():
    return db.all("SELECT * FROM users WHERE role IN ('owner','admin') ORDER BY role='owner' DESC, id")


def set_nickname(uid: int, nickname: str) -> None:
    db.run("UPDATE users SET nickname=? WHERE id=?", (nickname, uid))


def set_password(uid: int, password_hash: str) -> None:
    db.run("UPDATE users SET password_hash=? WHERE id=?", (password_hash, uid))


def set_role(uid: int, role: str) -> None:
    db.run("UPDATE users SET role=? WHERE id=?", (role, uid))


def set_ban(uid: int, banned: bool, reason: str | None = None) -> None:
    db.run("UPDATE users SET banned=?, ban_reason=? WHERE id=?", (int(banned), reason or None, uid))


def set_mute(uid: int, until: float, reason: str | None = None) -> None:
    db.run("UPDATE users SET muted_until=?, mute_reason=? WHERE id=?", (until, reason or None, uid))


def set_active_avatar(uid: int, avatar_id: int | None) -> None:
    db.run("UPDATE users SET active_avatar_id=? WHERE id=?", (avatar_id, uid))


def set_color(uid: int, color: str | None) -> None:
    db.run("UPDATE users SET color=? WHERE id=?", (color or None, uid))


def set_badge(uid: int, badge: str | None, anim: str | None) -> None:
    db.run("UPDATE users SET badge=?, badge_anim=? WHERE id=?", (badge or None, anim or None, uid))


def set_warns(uid: int, n: int) -> None:
    db.run("UPDATE users SET warns=? WHERE id=?", (max(0, n), uid))


def staff_ids() -> list[int]:
    return [r["id"] for r in db.all("SELECT id FROM users WHERE role IN ('owner','admin') AND deleted=0 AND banned=0")]


def set_bio(uid: int, bio: str) -> None:
    db.run("UPDATE users SET bio=? WHERE id=?", (bio, uid))


def list_members(include_banned: bool = False):
    where = "WHERE u.deleted=0" + ("" if include_banned else " AND u.banned=0")
    return db.all(
        f"""SELECT u.id, u.username, u.nickname, u.role, u.bio, u.color, u.created_at, u.banned, u.muted_until,
                   u.badge, u.badge_anim, u.warns, u.ecdh_pub, u.sign_pub,
                   u.trust, u.fx, u.banner, u.frame, u.title, u.last_seen, a.filename AS avatar
            FROM users u LEFT JOIN avatars a ON a.id = u.active_avatar_id {where}
            ORDER BY CASE u.role WHEN 'owner' THEN 0 WHEN 'admin' THEN 1 ELSE 2 END, u.nickname COLLATE NOCASE"""
    )


def mark_deleted(uid: int, now: float) -> None:
    db.run("DELETE FROM room_keys WHERE user_id=?", (uid,))
    db.run(
        "UPDATE users SET deleted=1, deleted_at=?, username=?, nickname='Deleted account', bio='', color=NULL, "
        "role='user', banned=0, ban_reason=NULL, muted_until=0, mute_reason=NULL, active_avatar_id=NULL, badge=NULL, badge_anim=NULL, warns=0, trust=NULL, neon=NULL, fx=NULL, banner=NULL, frame=NULL, title=NULL, "
        "password_hash='!', key_blob=NULL WHERE id=?",
        (now, f"deleted_{uid}", uid),
    )


def list_for_backup():
    return db.all(
        """SELECT u.id, u.username, u.nickname, u.role, u.bio, u.color, u.created_at, u.banned, u.badge, u.badge_anim,
                  u.password_hash, u.auth_v, u.kdf_iter, u.ecdh_pub, u.sign_pub, u.key_blob,
                  u.trust, u.banner, u.frame, u.title, u.fx, a.filename AS avatar
           FROM users u LEFT JOIN avatars a ON a.id = u.active_avatar_id
           WHERE u.deleted=0 ORDER BY u.id""")


def create_restored(rec: dict) -> int:
    return db.run(
        "INSERT INTO users(username,nickname,password_hash,role,created_at,bio,color,banned,badge,badge_anim,"
        "ecdh_pub,sign_pub,key_blob,kdf_iter,auth_v,trust,banner,frame,title,fx) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (rec["username"], rec["nickname"], rec["password_hash"], rec["role"], rec["created_at"], rec["bio"], rec["color"],
         int(rec["banned"]), rec["badge"], rec["badge_anim"], rec["ecdh_pub"], rec["sign_pub"], rec["key_blob"],
         rec["kdf_iter"], rec["auth_v"], rec["trust"], rec["banner"], rec["frame"], rec["title"], rec["fx"]))


def set_emoji_perm(uid: int, perm: int) -> None:
    db.run("UPDATE users SET emoji_perm=? WHERE id=?", (perm, uid))


def emoji_perms() -> dict[int, int]:
    return {r["id"]: r["emoji_perm"] for r in db.all("SELECT id, emoji_perm FROM users WHERE emoji_perm != 0 AND deleted=0")}


_STYLE_COLS = ("color", "trust", "fx", "banner", "frame", "title")


def set_style(uid: int, fields: dict) -> None:
    cols = [c for c in fields if c in _STYLE_COLS]
    if cols:
        db.run(f"UPDATE users SET {', '.join(c + '=?' for c in cols)} WHERE id=?", (*[fields[c] for c in cols], uid))
