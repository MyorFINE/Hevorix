from app.db import db


def stats(uid: int, game: str):
    return db.one("SELECT points, wins, losses, draws FROM game_stats WHERE user_id=? AND game=?", (uid, game))


def add_result(uid: int, game: str, delta: int, outcome: str, now: float) -> int:
    row = stats(uid, game)
    old = row["points"] if row else 0
    new = max(0, old + delta)
    w, l, d = (1 if outcome == "w" else 0), (1 if outcome == "l" else 0), (1 if outcome == "d" else 0)
    if row:
        db.run("UPDATE game_stats SET points=?, wins=wins+?, losses=losses+?, draws=draws+?, updated_at=? WHERE user_id=? AND game=?",
               (new, w, l, d, now, uid, game))
    else:
        db.run("INSERT INTO game_stats(user_id,game,points,wins,losses,draws,updated_at) VALUES(?,?,?,?,?,?,?)",
               (uid, game, new, w, l, d, now))
    return new


def top(game: str, limit: int = 30):
    return db.all("""SELECT s.user_id, s.points, s.wins, s.losses, s.draws FROM game_stats s JOIN users u ON u.id = s.user_id
                     WHERE s.game=? AND u.deleted=0 AND (s.wins+s.losses+s.draws) > 0
                     ORDER BY s.points DESC, s.wins DESC, s.updated_at ASC LIMIT ?""", (game, limit))


def rank_of(game: str, points: int) -> int:
    return db.one("""SELECT COUNT(*) AS n FROM game_stats s JOIN users u ON u.id = s.user_id
                     WHERE s.game=? AND u.deleted=0 AND (s.wins+s.losses+s.draws) > 0 AND s.points > ?""", (game, points))["n"] + 1


def log(game, white, black, result, reason, pts_w, pts_b, plies, rated, started, ended) -> int:
    return db.run("""INSERT INTO game_log(game,white_id,black_id,result,reason,pts_w,pts_b,plies,rated,started_at,ended_at)
                     VALUES(?,?,?,?,?,?,?,?,?,?,?)""", (game, white, black, result, reason, pts_w, pts_b, plies, 1 if rated else 0, started, ended))


def pair_rated_since(game: str, a: int, b: int, since: float) -> int:
    return db.one("""SELECT COUNT(*) AS n FROM game_log WHERE game=? AND rated=1 AND ended_at>=?
                     AND ((white_id=? AND black_id=?) OR (white_id=? AND black_id=?))""", (game, since, a, b, b, a))["n"]
