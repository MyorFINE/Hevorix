from __future__ import annotations

import json

from app.db import db


# ---------- paketlar ----------
def pack_add(name: str, emoji: str, descr: str, items: list[dict], by: int, now: float) -> int:
    return db.run("INSERT INTO design_packs(name,emoji,descr,items,created_by,created_at) VALUES(?,?,?,?,?,?)",
                  (name, emoji, descr, json.dumps(items, ensure_ascii=False, separators=(",", ":")), by, now))


def pack_update(pid: int, name: str, emoji: str, descr: str, items: list[dict]) -> None:
    db.run("UPDATE design_packs SET name=?, emoji=?, descr=?, items=? WHERE id=?",
           (name, emoji, descr, json.dumps(items, ensure_ascii=False, separators=(",", ":")), pid))


def pack_get(pid: int):
    return db.one("SELECT * FROM design_packs WHERE id=?", (pid,))


def pack_all():
    return db.all("SELECT * FROM design_packs ORDER BY id DESC")


def pack_delete(pid: int) -> None:
    db.run("DELETE FROM design_packs WHERE id=?", (pid,))


def pack_in_use(pid: int) -> int:
    return db.one("SELECT COUNT(*) AS n FROM mission_rewards WHERE pack_id=?", (pid,))["n"]


# ---------- ochko qoidalari ----------
def rules(game: str):
    return db.all("SELECT rule, points, daily_cap FROM mission_rules WHERE game=?", (game,))


def rule_get(game: str, rule: str):
    return db.one("SELECT rule, points, daily_cap FROM mission_rules WHERE game=? AND rule=?", (game, rule))


def rule_put(game: str, rule: str, points: int, cap: int) -> None:
    db.run("INSERT INTO mission_rules(game,rule,points,daily_cap) VALUES(?,?,?,?) "
           "ON CONFLICT(game,rule) DO UPDATE SET points=excluded.points, daily_cap=excluded.daily_cap", (game, rule, points, cap))


# ---------- ochkolar ----------
def points(uid: int, game: str) -> int:
    r = db.one("SELECT points FROM mission_points WHERE user_id=? AND game=?", (uid, game))
    return r["points"] if r else 0


def add_points(uid: int, game: str, delta: int, now: float) -> int:
    db.run("INSERT INTO mission_points(user_id,game,points,updated_at) VALUES(?,?,?,?) "
           "ON CONFLICT(user_id,game) DO UPDATE SET points=points+excluded.points, updated_at=excluded.updated_at",
           (uid, game, delta, now))
    return points(uid, game)


def wins_since(uid: int, game: str, rule: str, since: float) -> int:
    return db.one("SELECT COUNT(*) AS n FROM mission_wins WHERE user_id=? AND game=? AND rule=? AND created_at>=?",
                  (uid, game, rule, since))["n"]


def win_log(uid: int, game: str, rule: str, pts: int, plies: int, now: float) -> None:
    db.run("INSERT INTO mission_wins(user_id,game,rule,points,plies,created_at) VALUES(?,?,?,?,?,?)",
           (uid, game, rule, pts, plies, now))


# ---------- o'yin chiptalari ----------
def ticket_add(token: str, uid: int, game: str, level: int, side: str, now: float) -> None:
    db.run("INSERT INTO mission_games(token,user_id,game,level,side,started_at) VALUES(?,?,?,?,?,?)",
           (token, uid, game, level, side, now))


def ticket_get(token: str):
    return db.one("SELECT * FROM mission_games WHERE token=?", (token,))


def ticket_use(token: str) -> bool:
    """Atomik: chipta faqat bir marta ishlatiladi."""
    with db._lock:
        cur = db._conn.execute("UPDATE mission_games SET used=1 WHERE token=? AND used=0", (token,))
        db._conn.commit()
        return cur.rowcount == 1


def tickets_recent(uid: int, since: float) -> int:
    return db.one("SELECT COUNT(*) AS n FROM mission_games WHERE user_id=? AND started_at>=?", (uid, since))["n"]


def tickets_prune(before: float) -> None:
    db.run("DELETE FROM mission_games WHERE started_at<?", (before,))


# ---------- missiyalar (mukofotlar) ----------
def reward_add(game: str, title: str, need: int, pack_id: int, now: float) -> int:
    return db.run("INSERT INTO mission_rewards(game,title,need,pack_id,created_at) VALUES(?,?,?,?,?)",
                  (game, title, need, pack_id, now))


def reward_update(rid: int, title: str, need: int, pack_id: int, active: int) -> None:
    db.run("UPDATE mission_rewards SET title=?, need=?, pack_id=?, active=? WHERE id=?", (title, need, pack_id, active, rid))


def reward_get(rid: int):
    return db.one("SELECT * FROM mission_rewards WHERE id=?", (rid,))


def reward_all(game: str | None = None, only_active: bool = False):
    sql, args = "SELECT * FROM mission_rewards WHERE 1=1", []
    if game:
        sql += " AND game=?"
        args.append(game)
    if only_active:
        sql += " AND active=1"
    return db.all(sql + " ORDER BY game, need, id", tuple(args))


def reward_delete(rid: int) -> None:
    db.run("DELETE FROM mission_rewards WHERE id=?", (rid,))
    db.run("DELETE FROM mission_claims WHERE reward_id=?", (rid,))


def claimed_ids(uid: int) -> set[int]:
    return {r["reward_id"] for r in db.all("SELECT reward_id FROM mission_claims WHERE user_id=?", (uid,))}


def claim(uid: int, rid: int, now: float) -> bool:
    with db._lock:
        cur = db._conn.execute("INSERT OR IGNORE INTO mission_claims(user_id,reward_id,claimed_at) VALUES(?,?,?)", (uid, rid, now))
        db._conn.commit()
        return cur.rowcount == 1


def claim_count(rid: int) -> int:
    return db.one("SELECT COUNT(*) AS n FROM mission_claims WHERE reward_id=?", (rid,))["n"]


# ---------- inventar ----------
def inv_all(uid: int):
    return db.all("SELECT * FROM inv_items WHERE user_id=? ORDER BY got_at DESC, id DESC", (uid,))


def inv_get(uid: int, item_id: int):
    return db.one("SELECT * FROM inv_items WHERE id=? AND user_id=?", (item_id, uid))


def inv_add(uid: int, pack_id: int | None, pack_name: str, slot: str, value: str, anim: str, label: str, now: float) -> bool:
    with db._lock:
        cur = db._conn.execute(
            "INSERT OR IGNORE INTO inv_items(user_id,pack_id,pack_name,slot,value,anim,label,got_at) VALUES(?,?,?,?,?,?,?,?)",
            (uid, pack_id, pack_name, slot, value, anim or "", label, now))
        db._conn.commit()
        return cur.rowcount == 1


def inv_count(uid: int) -> int:
    return db.one("SELECT COUNT(*) AS n FROM inv_items WHERE user_id=?", (uid,))["n"]
