"""Admin imkoniyatlari: «Yangi foydalanuvchi» belgisi, profil bezaklari, guruh (umumiy chat) rasmi va bio'si."""
from __future__ import annotations

import json
import re
import secrets

from app.config import settings
from app.db import db
from app.errors import ChatError
from app.repositories import chat_settings, logs, users
from app.roles import Role, is_admin, role_of
from app.services import avatars as avatar_svc
from app.services import r2
from app.services import imgclean, views

MAX_NEW_TEXT = 120
MAX_GROUP_BIO = 500
_CTRL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


def _clean(raw, limit: int, what: str) -> str:
    s = _CTRL.sub("", raw or "").strip()
    if len(s) > limit:
        raise ChatError(f"{what} {limit} belgidan oshmasligi kerak")
    return s


def _target(actor, uid: int):
    t = users.get(int(uid))
    if not t or t["deleted"]:
        raise ChatError("Foydalanuvchi topilmadi", 404)
    if role_of(t) == Role.OWNER and role_of(actor) < Role.OWNER:
        raise ChatError("Egaga faqat ega o'zgartirish kiritadi", 403)
    return t


# ---------------------------------------------------------------- «Yangi» belgisi
def set_default_new_text(actor, text: str) -> str:
    t = _clean(text, MAX_NEW_TEXT, "Matn")
    chat_settings.put("newuser_text", t)
    logs.add("newuser_text", user_id=actor["id"], actor_id=actor["id"], new=t)
    return t or views.DEFAULT_NEW_TEXT


def set_user_new(actor, uid: int, mode: str, text: str = "") -> dict:
    """mode: auto (yoshiga qarab) | on (qo'lda yoqish) | off (qo'lda o'chirish). `text` — shu foydalanuvchi uchun alohida matn."""
    t = _target(actor, uid)
    if role_of(t) != Role.USER:
        raise ChatError("Belgi faqat oddiy foydalanuvchilarga qo'yiladi")
    flag = {"auto": -1, "on": 1, "off": 0}.get(mode)
    if flag is None:
        raise ChatError("Noto'g'ri holat")
    own = _clean(text, MAX_NEW_TEXT, "Matn") or None
    db.run("UPDATE users SET new_flag=?, new_text=? WHERE id=?", (flag, own, t["id"]))
    logs.add("newuser", user_id=t["id"], actor_id=actor["id"], new=f"{mode}: {own or ''}")
    return views.user_view(t["id"])


# ---------------------------------------------------------------- profil bezaklari
def set_style(actor, uid: int, style: dict) -> dict:
    t = _target(actor, uid)
    if not isinstance(style, dict):
        raise ChatError("Noto'g'ri qiymat")
    clean = {}
    for k, v in style.items():
        if k not in views.STYLE_OPTIONS:
            raise ChatError("Noma'lum bezak turi")
        if v in ("", None, "none"):
            continue
        if v not in views.STYLE_OPTIONS[k]:
            raise ChatError("Noma'lum bezak qiymati")
        clean[k] = v
    db.run("UPDATE users SET style=? WHERE id=?", (json.dumps(clean) if clean else None, t["id"]))
    logs.add("style", user_id=t["id"], actor_id=actor["id"], new=json.dumps(clean))
    return views.user_view(t["id"])


# ---------------------------------------------------------------- guruh (umumiy chat): rasm va bio
def group_info() -> dict:
    av = chat_settings.get("group_avatar", None)
    return {"bio": chat_settings.get("group_bio", "") or "", "avatar": f"/avatars/{av}" if av else None}


def set_group_bio(actor, bio: str) -> dict:
    chat_settings.put("group_bio", _clean(bio, MAX_GROUP_BIO, "Bio"))
    logs.add("group_bio", user_id=actor["id"], actor_id=actor["id"])
    return group_info()


def _drop(name) -> None:
    if name:
        try:
            (settings.avatars_dir / name).unlink()
        except OSError:
            pass
        r2.delete_file("avatars", name)


def set_group_avatar(actor, raw: bytes) -> dict:
    if not is_admin(actor):
        raise ChatError("Faqat adminlar", 403)
    if len(raw) > settings.max_avatar_bytes:
        raise ChatError(f"Rasm {settings.max_avatar_bytes // (1024 * 1024)} MB dan oshmasligi kerak")
    if not avatar_svc.sniff_image(raw):
        raise ChatError("Faqat PNG, JPG, WEBP yoki GIF rasmlar mumkin")
    img = imgclean.clean(raw)
    name = f"grp_{secrets.token_hex(12)}.{img.ext}"
    (settings.avatars_dir / name).write_bytes(img.data)
    r2.put_file("avatars", name, img.data)                     # Render'da disk vaqtinchalik: R2 ga ham saqlanadi
    _drop(chat_settings.get("group_avatar", None))
    chat_settings.put("group_avatar", name)
    logs.add("group_avatar", user_id=actor["id"], actor_id=actor["id"])
    return group_info()


def clear_group_avatar(actor) -> dict:
    _drop(chat_settings.get("group_avatar", None))
    chat_settings.put("group_avatar", None)
    return group_info()
