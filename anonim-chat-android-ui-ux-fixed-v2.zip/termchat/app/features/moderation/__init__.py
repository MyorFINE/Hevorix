"""Funksiya moduli: moderation. Mavjud kod app.services.modsettings, app.api.admin, app.services.ipblock, app.features.moderation.service da turadi (hech narsa ko'chirilmagan, ishlashi o'zgarmagan)."""
MODULES = ('app.services.modsettings', 'app.api.admin', 'app.services.ipblock', 'app.features.moderation.service')
