"""Admin endpointlari: rezerv usernamelar, «Yangi» belgisi, profil bezaklari, guruh rasmi va bio'si."""
from fastapi import APIRouter, Depends, File, UploadFile
from fastapi.concurrency import run_in_threadpool
from pydantic import BaseModel, Field

from app.api.deps import admin_user
from app.config import settings
from app.features.authentication import username as uname
from app.features.moderation import service as svc
from app.realtime.manager import manager
from app.services import modsettings, views

router = APIRouter(prefix="/api/admin", tags=["admin-extra"])


class NameIn(BaseModel):
    username: str = Field(max_length=40)


class NewDefaultIn(BaseModel):
    text: str = Field("", max_length=300)


class NewUserIn(BaseModel):
    user_id: int
    mode: str = Field(max_length=8)
    text: str = Field("", max_length=300)


class StyleIn(BaseModel):
    user_id: int
    style: dict = Field(default_factory=dict)


class BioIn(BaseModel):
    bio: str = Field("", max_length=1000)


async def _group_changed() -> None:
    await manager.broadcast({"type": "chat_settings", **modsettings.public()})


@router.get("/reserved")
def reserved(admin=Depends(admin_user)):
    return {"usernames": uname.reserved_list()}


@router.post("/reserved")
def reserve(data: NameIn, admin=Depends(admin_user)):
    return {"usernames": uname.reserve(admin, data.username)}


@router.post("/reserved/remove")
def release(data: NameIn, admin=Depends(admin_user)):
    return {"usernames": uname.release(admin, data.username)}


@router.post("/newuser/default")
async def new_default(data: NewDefaultIn, admin=Depends(admin_user)):
    text = await run_in_threadpool(svc.set_default_new_text, admin, data.text)
    await manager.broadcast({"type": "users_changed"})
    return {"text": text}


@router.post("/newuser")
async def new_user(data: NewUserIn, admin=Depends(admin_user)):
    view = await run_in_threadpool(svc.set_user_new, admin, data.user_id, data.mode, data.text)
    await manager.broadcast({"type": "user_update", "user": view})
    return {"user": view}


@router.post("/style")
async def style(data: StyleIn, admin=Depends(admin_user)):
    view = await run_in_threadpool(svc.set_style, admin, data.user_id, data.style)
    await manager.broadcast({"type": "user_update", "user": view})
    return {"user": view, "options": {k: list(v) for k, v in views.STYLE_OPTIONS.items()}}


@router.get("/style/options")
def style_options(admin=Depends(admin_user)):
    return {"options": {k: list(v) for k, v in views.STYLE_OPTIONS.items()}}


@router.post("/group")
async def group_bio(data: BioIn, admin=Depends(admin_user)):
    info = await run_in_threadpool(svc.set_group_bio, admin, data.bio)
    await _group_changed()
    return info


@router.post("/group/avatar")
async def group_avatar(file: UploadFile = File(...), admin=Depends(admin_user)):
    raw = await file.read(settings.max_avatar_bytes + 1)
    info = await run_in_threadpool(svc.set_group_avatar, admin, raw)
    await _group_changed()
    return info


@router.post("/group/avatar/clear")
async def group_avatar_clear(admin=Depends(admin_user)):
    info = await run_in_threadpool(svc.clear_group_avatar, admin)
    await _group_changed()
    return info
