"""Funksiya moduli: typing. Mavjud kod app.realtime.manager da turadi (hech narsa ko'chirilmagan, ishlashi o'zgarmagan)."""
MODULES = ('app.realtime.manager',)
