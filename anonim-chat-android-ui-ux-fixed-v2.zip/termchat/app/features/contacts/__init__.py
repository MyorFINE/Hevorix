"""Funksiya moduli: contacts. Mavjud kod app.services.avatars, app.api.social, app.repositories.users da turadi (hech narsa ko'chirilmagan, ishlashi o'zgarmagan)."""
MODULES = ('app.services.avatars', 'app.api.social', 'app.repositories.users')
