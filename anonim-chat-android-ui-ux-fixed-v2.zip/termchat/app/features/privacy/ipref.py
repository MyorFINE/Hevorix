"""IP manzillarni adminlardan yashirish.

Admin panelida IP manzillar HECH QACHON ochiq ko'rsatilmaydi: o'rniga barqaror yorliq (`IP-3FA91C0B2D`) chiqadi.
Yorliq — IP'ning kalitli HMAC'i (kalit serverning asosiy kalitidan olinadi), shuning uchun uni IP'ga qaytarib bo'lmaydi,
lekin server uni bilgan IP'larga moslashtira oladi. Shu tufayli admin IP bo'yicha filtrlash, bloklash va blokdan ochishni
davom ettira oladi — IP'ning o'zini ko'rmasdan. Har bir foydalanuvchi o'z qurilmalari IP'sini faqat o'zining
«Faol sessiyalar» oynasida ko'radi (`services.auth.list_sessions`).
"""
from __future__ import annotations

import hashlib
import hmac
import re
import time

from app import crypto
from app.db import db
from app.netutil import normalize_ip

_PREFIX = "IP-"
_REF_RE = re.compile(r"^IP-[0-9A-F]{10}$")
_IP4_RE = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
_IP6_RE = re.compile(r"(?<![\w:])(?:[0-9a-fA-F]{0,4}:){2,7}[0-9a-fA-F]{0,4}(?![\w:])")
_key: bytes | None = None
_cache: tuple[float, dict[str, str]] = (0.0, {})


def _k() -> bytes:
    global _key
    if _key is None:
        _key = crypto._derive(crypto._master_secret(), b"ip-ref/v1")
    return _key


def ref(ip: str | None) -> str:
    if not ip:
        return ""
    norm = normalize_ip(ip) or ip
    return _PREFIX + hmac.new(_k(), norm.encode(), hashlib.sha256).hexdigest()[:10].upper()


def is_ref(value: str | None) -> bool:
    return bool(value) and bool(_REF_RE.match(value.strip().upper()))


def _known() -> dict[str, str]:
    """yorliq -> IP (faoliyat logi va bloklar bo'yicha; 60 soniya keshlanadi)."""
    global _cache
    at, data = _cache
    if time.monotonic() - at < 60 and data:
        return data
    ips = {r["ip"] for r in db.all("SELECT DISTINCT ip FROM activity WHERE ip IS NOT NULL")}
    ips |= {r["ip"] for r in db.all("SELECT ip FROM ip_blocks")}
    data = {ref(i): i for i in ips if i}
    _cache = (time.monotonic(), data)
    return data


def forget() -> None:
    global _cache
    _cache = (0.0, {})


def resolve(value: str | None) -> str:
    """Yorliq bo'lsa — haqiqiy IP (topilmasa bo'sh qator); aks holda kiritilgan qiymat o'zgarishsiz."""
    v = (value or "").strip()
    if not v:
        return ""
    if is_ref(v):
        hit = _known().get(v.upper())
        if hit is None:
            forget()
            hit = _known().get(v.upper())
        return hit or ""
    return v


def mask_text(text: str | None) -> str:
    """Matn ichidagi IP manzillarni yorliqqa almashtiradi (logdagi tafsilotlar uchun)."""
    if not text:
        return text or ""
    text = _IP4_RE.sub(lambda m: ref(m.group(0)) if normalize_ip(m.group(0)) else m.group(0), text)
    return _IP6_RE.sub(lambda m: ref(m.group(0)) if normalize_ip(m.group(0)) else m.group(0), text)
