"""Funksiya moduli: privacy. Mavjud kod app.features.privacy.ipref, app.netutil da turadi (hech narsa ko'chirilmagan, ishlashi o'zgarmagan)."""
MODULES = ('app.features.privacy.ipref', 'app.netutil')
