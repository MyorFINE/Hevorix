"""Funksiya moduli: encryption. Mavjud kod app.crypto, app.services.e2ee, app.api.e2ee, app.transport da turadi (hech narsa ko'chirilmagan, ishlashi o'zgarmagan)."""
MODULES = ('app.crypto', 'app.services.e2ee', 'app.api.e2ee', 'app.transport')
