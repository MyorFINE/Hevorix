"""Funksiya moduli: channels. Mavjud kod app.services.channels, app.api.channels, app.repositories.channels da turadi (hech narsa ko'chirilmagan, ishlashi o'zgarmagan)."""
MODULES = ('app.services.channels', 'app.api.channels', 'app.repositories.channels')
