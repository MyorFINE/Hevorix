"""Username almashtirish va band qilingan (rezerv) usernamelar.

E2EE tufayli username kalitlarni o'rashda ishtirok etadi (KDF tuzi va AAD), shuning uchun username almashganda mijoz
parol bilan kirish kalitini va o'ralgan maxfiy kalitlarni YANGI username bilan qayta hosil qiladi (parol almashtirishga o'xshash).
Server eski username'ni bo'shatadi (qatorning o'zi yangilanadi) — kimdir olmaguncha u bo'sh turadi.
Xabarlar `user_id` bo'yicha bog'langani uchun chatdagi barcha eski ismlar avtomatik yangisiga almashadi.
"""
from __future__ import annotations

import sqlite3
import time

from app.constants import OWNER_USERNAME
from app.db import db
from app.errors import ChatError
from app.repositories import chat_settings, logs, users
from app.roles import Role, is_admin, role_of
from app.security import hash_password, limiter, verify_password
from app.services import auth
from app.services import e2ee as e2ee_svc

MAX_RESERVED = 300
CHANGE_LIMIT = (3, 24 * 3600)            # bir akkaunt sutkasiga 3 martagacha username almashtira oladi


# ---------------------------------------------------------------- rezerv usernamelar (faqat admin boshqaradi)
def reserved_list() -> list[str]:
    raw = chat_settings.get("reserved_usernames", []) or []
    return sorted({str(x).lower() for x in raw if isinstance(x, str)})


def is_reserved(name: str) -> bool:
    return name.strip().lstrip("@").lower() in set(reserved_list())


def reserve(actor, raw: str) -> list[str]:
    name = (raw or "").strip().lstrip("@").lower()
    if not auth.USERNAME_RE.match(name):
        raise ChatError("Username: 3-20 belgi, faqat a-z, 0-9 va _")
    if name in auth.RESERVED:
        raise ChatError("Bu username allaqachon tizim tomonidan band")
    cur = reserved_list()
    if len(cur) >= MAX_RESERVED and name not in cur:
        raise ChatError(f"Band qilingan usernamelar {MAX_RESERVED} tadan oshmasligi kerak")
    if name not in cur:
        cur.append(name)
        chat_settings.put("reserved_usernames", sorted(cur))
        logs.add("reserve_username", user_id=actor["id"], actor_id=actor["id"], new=name)
    return sorted(cur)


def release(actor, raw: str) -> list[str]:
    name = (raw or "").strip().lstrip("@").lower()
    cur = [x for x in reserved_list() if x != name]
    chat_settings.put("reserved_usernames", cur)
    logs.add("release_username", user_id=actor["id"], actor_id=actor["id"], old=name)
    return cur


# ---------------------------------------------------------------- username almashtirish
def _check_free(user, name: str) -> None:
    if not auth.USERNAME_RE.match(name):
        raise ChatError("Username: 3-20 belgi, faqat a-z, 0-9 va _")
    if name in auth.RESERVED or name.startswith("deleted_"):
        raise ChatError("Bu username band", 409)
    if is_reserved(name) and not is_admin(user):          # band qilingan usernamelarni faqat admin ola oladi
        raise ChatError("Bu username band", 409)
    other = users.get_by_username(name)
    if other and other["id"] != user["id"]:
        raise ChatError("Bu username band", 409)


def change_username(user, new_username: str, old: str, new: str | None, key_blob: str | None, kdf_iter: int | None) -> dict:
    """`old` — joriy kirish kaliti (eski username bilan); `new` — YANGI username bilan hosil qilingan kirish kaliti."""
    if role_of(user) == Role.OWNER or user["username"].lower() == OWNER_USERNAME.lower():
        raise ChatError("Platforma egasining usernamesi o'zgarmaydi", 403)
    name = (new_username or "").strip().lstrip("@").lower()
    if name == user["username"]:
        raise ChatError("Bu sizning hozirgi usernameingiz")
    limiter.check(f"uname-change:{user['id']}", *CHANGE_LIMIT, "Bugun username juda ko'p almashtirildi, ertaga qayta urinib ko'ring")
    _check_free(user, name)
    if not verify_password(old, user["password_hash"]):
        raise ChatError("Parol noto'g'ri")
    if int(user["auth_v"] or 0) == 1:
        if new is None or key_blob is None or kdf_iter is None:
            raise ChatError("E2EE akkauntda username faqat brauzer orqali almashtiriladi (kalitlar qayta o'raladi)")
        keys = e2ee_svc.validate_account_keys({"ecdh_pub": user["ecdh_pub"], "sign_pub": user["sign_pub"],
                                                "key_blob": key_blob, "kdf_iter": kdf_iter})
        pw_hash = hash_password(e2ee_svc.check_auth(new))
        sets = (name, pw_hash, keys["key_blob"], keys["kdf_iter"], user["id"])
        sql = "UPDATE users SET username=?, password_hash=?, key_blob=?, kdf_iter=? WHERE id=?"
    else:
        sets = (name, user["id"])
        sql = "UPDATE users SET username=? WHERE id=?"
    with auth._register_lock:                              # ikki kishi bir vaqtda bir xil nomni olmasin
        _check_free(user, name)
        try:
            db.run(sql, sets)
        except sqlite3.IntegrityError:
            raise ChatError("Bu username band", 409)
    logs.add("username", user_id=user["id"], actor_id=user["id"], old=user["username"], new=name)
    return {"old": user["username"], "username": name, "ts": time.time()}
