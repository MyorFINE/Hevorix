"""Username almashtirish endpointi."""
import asyncio

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel, Field

from app.api.deps import client_ip, current_user
from app.features.authentication import username as uname
from app.realtime.manager import manager
from app.services import activity, views

router = APIRouter(prefix="/api", tags=["username"])


class UsernameIn(BaseModel):
    username: str = Field(max_length=40)
    old: str = Field(max_length=128)                       # joriy kirish kaliti (eski username bilan)
    new: str | None = Field(None, max_length=128)          # yangi kirish kaliti (yangi username bilan) — E2EE
    key_blob: str | None = Field(None, max_length=4096)
    kdf_iter: int | None = None


@router.post("/username")
async def change_username(data: UsernameIn, request: Request, user=Depends(current_user)):
    res = await asyncio.to_thread(uname.change_username, user, data.username, data.old, data.new, data.key_blob, data.kdf_iter)
    activity.record("username", ip=client_ip(request), user=user, detail=f"@{res['old']} → @{res['username']}")
    await manager.broadcast({"type": "user_update", "user": views.user_view(user["id"])})
    return {"ok": True, "username": res["username"]}
