"""Funksiya moduli: authentication. Mavjud kod app.services.auth, app.api.auth, app.features.authentication.username, app.security da turadi (hech narsa ko'chirilmagan, ishlashi o'zgarmagan)."""
MODULES = ('app.services.auth', 'app.api.auth', 'app.features.authentication.username', 'app.security')
