"""Funksiya moduli: messaging. Mavjud kod app.services.chat, app.api.chat, app.commands, app.features.messaging.pins, app.repositories.messages da turadi (hech narsa ko'chirilmagan, ishlashi o'zgarmagan)."""
MODULES = ('app.services.chat', 'app.api.chat', 'app.commands', 'app.features.messaging.pins', 'app.repositories.messages')
