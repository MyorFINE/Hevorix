"""Xabarlarni mahkamlash (pin): har bir suhbatda ko'pi bilan 3 ta.

Ruxsat: umumiy chat va kanalda faqat adminlar; lichkada ikkala suhbatdosh ham. Faqat xabar raqami saqlanadi
(matn E2EE bo'lgani uchun server uni bilmaydi); mijoz xabarni o'zida ochadi va bosilganda unga o'tadi.
"""
from __future__ import annotations

import time

from app.db import db
from app.errors import ChatError
from app.repositories import channels as ch_repo
from app.repositories import messages, users
from app.roles import is_admin
from app.services import channels as ch_svc

MAX_PINS = 3


def scope_of(user, kind: str, target: int) -> tuple[str, list[int] | None]:
    """(scope, auditoriya). Auditoriya None bo'lsa — hamma onlayn foydalanuvchi."""
    if kind == "group":
        return "g", None
    if kind == "channel":
        ch = ch_svc.get_visible(int(target), user)
        return f"c{ch['id']}", ch_svc.audience(ch)
    if kind == "dm":
        other = users.get(int(target))
        if not other or other["deleted"] or other["id"] == user["id"]:
            raise ChatError("Suhbatdosh topilmadi", 404)
        a, b = sorted((user["id"], other["id"]))
        return f"d{a}_{b}", [a, b]
    raise ChatError("Noto'g'ri suhbat turi")


def can_pin(user, kind: str) -> bool:
    return kind == "dm" or is_admin(user)


def _belongs(msg, scope: str) -> bool:
    if not msg or msg["deleted"]:
        return False
    chan = msg["channel_id"] if "channel_id" in msg.keys() else None
    if scope == "g":
        return msg["recipient_id"] is None and not chan
    if scope.startswith("c"):
        return bool(chan) and f"c{chan}" == scope
    if scope.startswith("d"):
        a, b = scope[1:].split("_")
        return msg["recipient_id"] is not None and {msg["user_id"], msg["recipient_id"]} == {int(a), int(b)}
    return False


def ids(scope: str) -> list[int]:
    """Mahkamlangan xabar raqamlari (eskisi birinchi); o'chirilgan xabarlar chiqarib tashlanadi."""
    rows = db.all("SELECT p.message_id FROM pins p JOIN messages m ON m.id=p.message_id "
                  "WHERE p.scope=? AND m.deleted=0 ORDER BY p.created_at, p.message_id", (scope,))
    return [r["message_id"] for r in rows]


def pin(user, kind: str, target: int, message_id: int) -> tuple[str, list[int], list[int] | None]:
    scope, aud = scope_of(user, kind, target)
    if not can_pin(user, kind):
        raise ChatError("Mahkamlashni faqat adminlar bajara oladi", 403)
    msg = messages.get(int(message_id))
    if not _belongs(msg, scope):
        raise ChatError("Xabar topilmadi", 404)
    cur = ids(scope)
    if message_id in cur:
        return scope, cur, aud
    if len(cur) >= MAX_PINS:
        raise ChatError(f"Ko'pi bilan {MAX_PINS} ta xabarni mahkamlash mumkin. Avval birini olib tashlang")
    db.run("INSERT OR IGNORE INTO pins(scope,message_id,pinned_by,created_at) VALUES(?,?,?,?)", (scope, int(message_id), user["id"], time.time()))
    return scope, ids(scope), aud


def unpin(user, kind: str, target: int, message_id: int) -> tuple[str, list[int], list[int] | None]:
    scope, aud = scope_of(user, kind, target)
    if not can_pin(user, kind):
        raise ChatError("Mahkamlashni faqat adminlar bajara oladi", 403)
    db.run("DELETE FROM pins WHERE scope=? AND message_id=?", (scope, int(message_id)))
    return scope, ids(scope), aud


def listing(user, kind: str, target: int) -> dict:
    scope, _ = scope_of(user, kind, target)
    return {"scope": scope, "ids": ids(scope), "can_pin": can_pin(user, kind)}
