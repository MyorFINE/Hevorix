"""Mahkamlangan xabarlar API."""
from fastapi import APIRouter, Depends, Request
from fastapi.concurrency import run_in_threadpool
from pydantic import BaseModel, Field

from app.api.deps import client_ip, current_user
from app.features.messaging import pins
from app.realtime.manager import manager
from app.services import activity

router = APIRouter(prefix="/api/pins", tags=["pins"])


class PinIn(BaseModel):
    kind: str = Field(max_length=10)               # group | channel | dm
    target: int = 0                                # kanal id yoki suhbatdosh id
    message_id: int


async def _publish(scope: str, ids: list[int], audience, kind: str, target_for: dict[int, int] | None = None) -> None:
    payload = {"type": "pins", "scope": scope, "kind": kind, "ids": ids}
    if audience is None:
        await manager.broadcast(payload)
    else:
        await manager.send_many(audience, payload)


@router.get("")
async def get_pins(kind: str, target: int = 0, user=Depends(current_user)):
    return await run_in_threadpool(pins.listing, user, kind.strip()[:10], target)


@router.post("")
async def add_pin(data: PinIn, request: Request, user=Depends(current_user)):
    scope, ids, aud = await run_in_threadpool(pins.pin, user, data.kind.strip()[:10], data.target, data.message_id)
    activity.record("pin", ip=client_ip(request), user=user, detail=f"{scope} #{data.message_id}")
    await _publish(scope, ids, aud, data.kind)
    return {"ok": True, "scope": scope, "ids": ids}


@router.post("/remove")
async def remove_pin(data: PinIn, request: Request, user=Depends(current_user)):
    scope, ids, aud = await run_in_threadpool(pins.unpin, user, data.kind.strip()[:10], data.target, data.message_id)
    activity.record("unpin", ip=client_ip(request), user=user, detail=f"{scope} #{data.message_id}")
    await _publish(scope, ids, aud, data.kind)
    return {"ok": True, "scope": scope, "ids": ids}
