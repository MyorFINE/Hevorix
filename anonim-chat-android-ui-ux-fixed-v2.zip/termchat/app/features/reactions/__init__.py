"""Funksiya moduli: reactions. Mavjud kod app.services.reactions, app.repositories.reactions da turadi (hech narsa ko'chirilmagan, ishlashi o'zgarmagan)."""
MODULES = ('app.services.reactions', 'app.repositories.reactions')
