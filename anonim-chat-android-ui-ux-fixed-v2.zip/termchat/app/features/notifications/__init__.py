"""Funksiya moduli: notifications. Mavjud kod app.services.webpush, app.api.push da turadi (hech narsa ko'chirilmagan, ishlashi o'zgarmagan)."""
MODULES = ('app.services.webpush', 'app.api.push')
