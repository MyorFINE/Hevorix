"""Funksiya moduli: attachments. Mavjud kod app.services.media, app.api.media, app.services.imgclean da turadi (hech narsa ko'chirilmagan, ishlashi o'zgarmagan)."""
MODULES = ('app.services.media', 'app.api.media', 'app.services.imgclean')
