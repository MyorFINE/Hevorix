"""Funksiya moduli: backups. Mavjud kod app.services.dbsync, app.datasnap da turadi (hech narsa ko'chirilmagan, ishlashi o'zgarmagan)."""
MODULES = ('app.services.dbsync', 'app.datasnap')
