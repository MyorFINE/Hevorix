from pydantic import BaseModel, Field


class RegisterIn(BaseModel):
    username: str = Field(max_length=64)
    nickname: str = Field(max_length=64)
    password: str = Field(max_length=128)
    e2ee: dict | None = None
    remember: bool = False


class KdfIn(BaseModel):
    username: str = Field(max_length=64)


class LoginIn(BaseModel):
    username: str = Field(max_length=64)
    password: str = Field(max_length=128)
    remember: bool = False


class PersistIn(BaseModel):
    on: bool
