# core

Bu qatlam uchun hozirgi kod: app.errors, app.constants, app.roles, app.security
