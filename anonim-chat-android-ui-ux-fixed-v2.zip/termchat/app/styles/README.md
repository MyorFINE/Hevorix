# styles

Bu qatlam uchun hozirgi kod: app/static/css/style.css
