"""Anonim Chat by Hevorix."""
__version__ = "3.2.0"
