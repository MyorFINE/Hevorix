"""Anonim Chat by Hevorix."""
__version__ = "3.1.0"
