"""Anonim Chat by Hevorix."""
__version__ = "3.6.0"
