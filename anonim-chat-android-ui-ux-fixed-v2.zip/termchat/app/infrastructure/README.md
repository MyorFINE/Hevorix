# infrastructure

Bu qatlam uchun hozirgi kod: app.db, app.transport, app.realtime.manager, app.crypto
