# shared

Bu qatlam uchun hozirgi kod: app.netutil, app.sri
