"""To'liq ma'lumotlar zaxirasi (snapshot): baza + shifrlangan fayllar -> bitta `.tar.gz`.

Faqat standart kutubxona (sqlite3, tarfile, hashlib) — server ishlamayotgan bo'lsa ham (tools/datasnap.py) ishlaydi.

Arxiv ichida:
  chat.db            — SQLite backup API bilan olingan izchil nusxa (foydalanuvchilar, xabarlar, kanallar, reaksiyalar,
                       moderatsiya, sozlamalar, E2EE ommaviy kalitlari va parol bilan o'ralgan kalit zaxiralari)
  files/media/*      — diskdagi shifrlangan fayllar (`*.enc` server kaliti bilan, `*.e2e` mijoz kaliti bilan)
  files/avatars/*, files/emoji/*, files/uploads/*
  MANIFEST.json      — har bir fayl uchun SHA-256 va hajm (OXIRGI yoziladi; tiklashdan oldin tekshiriladi)

ARXIVGA HECH QACHON KIRMAYDI: `master.key`, `vapid.key` (maxfiy kalitlar), TERMCHAT_MASTER_KEY. Ularsiz bazadagi server-shifrlangan
(`enc1:`) qiymatlar va `*.enc` fayllar ochilmaydi — kalitni ALOHIDA, xavfsiz joyda saqlang. E2EE xabarlari (`e2e1:`, `*.e2e`)
server kalitiga bog'liq emas: ular faqat foydalanuvchilarning o'z kalitlari bilan ochiladi.

Tiklash mavjud ma'lumotlarni hech qachon jimgina o'chirmaydi: `force` bilan ham eski nusxa `pre-restore-<vaqt>/` papkasiga ko'chiriladi.
"""
from __future__ import annotations

import hashlib
import io
import json
import os
import shutil
import sqlite3
import tarfile
import tempfile
import time
from pathlib import Path

FORMAT = "termchat-snapshot/1"
DB_NAME = "chat.db"
MANIFEST = "MANIFEST.json"
FILE_DIRS = ("media", "avatars", "emoji", "uploads")
NEVER = {"master.key", "vapid.key"}
SKIP_SUFFIXES = (".tmp",)
CHUNK = 1024 * 1024


class SnapshotError(Exception):
    pass


class _Hasher(io.RawIOBase):

    def __init__(self, f):
        self._f, self.sha, self.n = f, hashlib.sha256(), 0

    def readable(self) -> bool:
        return True

    def readinto(self, b) -> int:
        data = self._f.read(len(b))
        b[:len(data)] = data
        self.sha.update(data)
        self.n += len(data)
        return len(data)


def _safe_member(name: str) -> bool:
    p = Path(name)
    return bool(name) and not p.is_absolute() and ".." not in p.parts and "\\" not in name and "\x00" not in name


def _db_report(db_file: Path) -> dict:
    try:
        conn = sqlite3.connect(f"file:{db_file}?mode=ro", uri=True)
    except sqlite3.Error as e:
        raise SnapshotError(f"Baza ochilmadi: {e}")
    try:
        res = [r[0] for r in conn.execute("PRAGMA integrity_check")]
        if res != ["ok"]:
            raise SnapshotError("Baza butunligi buzilgan: " + "; ".join(res[:3]))
        counts = {}
        for t in ("users", "messages", "channels", "reactions", "room_epochs"):
            try:
                counts[t] = conn.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
            except sqlite3.Error:
                counts[t] = None
        return counts
    except sqlite3.DatabaseError as e:
        raise SnapshotError(f"Baza buzilgan: {e}")
    finally:
        conn.close()


def create(data_dir: Path, dest: Path, include_files: bool = True, db_file: Path | None = None) -> dict:
    data_dir, dest = Path(data_dir), Path(dest)
    src_db = Path(db_file) if db_file else data_dir / DB_NAME
    if not src_db.is_file():
        raise SnapshotError(f"Baza topilmadi: {src_db}")
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp_out = dest.with_name(dest.name + ".part")
    with tempfile.TemporaryDirectory(prefix="snap-", dir=str(dest.parent)) as work:
        copy = Path(work) / DB_NAME
        src = sqlite3.connect(f"file:{src_db}?mode=ro", uri=True)
        out = sqlite3.connect(str(copy))
        try:
            src.backup(out)
        finally:
            out.close()
            src.close()
        counts = _db_report(copy)
        entries: list[dict] = []
        try:
            fd = os.open(tmp_out, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "wb") as raw, tarfile.open(fileobj=raw, mode="w:gz") as tar:
                def add(arcname: str, path: Path) -> bool:
                    try:
                        with open(path, "rb") as f:
                            info = tarfile.TarInfo(arcname)
                            st = os.fstat(f.fileno())
                            info.size, info.mtime, info.mode = st.st_size, int(st.st_mtime), 0o600
                            hasher = _Hasher(f)
                            tar.addfile(info, hasher)
                            if hasher.n != info.size:
                                raise OSError("fayl yozish vaqtida o'zgardi")
                            entries.append({"name": arcname, "size": info.size, "sha256": hasher.sha.hexdigest()})
                            return True
                    except OSError:
                        return False

                if not add(DB_NAME, copy):
                    raise SnapshotError("Baza nusxasini arxivga yozib bo'lmadi")
                skipped = 0
                if include_files:
                    for d in FILE_DIRS:
                        base = data_dir / d
                        if not base.is_dir():
                            continue
                        for p in sorted(base.rglob("*")):
                            if (not p.is_file() or p.is_symlink() or p.name in NEVER or p.name.endswith(SKIP_SUFFIXES)):
                                continue
                            rel = p.relative_to(base).as_posix()
                            if not add(f"files/{d}/{rel}", p):
                                skipped += 1
                manifest = {"format": FORMAT, "created": int(time.time()), "include_files": include_files,
                            "counts": counts, "files": entries, "skipped_files": skipped,
                            "note": "master.key va vapid.key arxivga kirmaydi; ularni alohida saqlang"}
                body = json.dumps(manifest, indent=1).encode()
                info = tarfile.TarInfo(MANIFEST)
                info.size, info.mtime, info.mode = len(body), int(time.time()), 0o600
                tar.addfile(info, io.BytesIO(body))
            os.replace(tmp_out, dest)
        finally:
            if tmp_out.exists():
                tmp_out.unlink()
    return manifest


def verify(archive: Path) -> dict:
    archive = Path(archive)
    if not archive.is_file():
        raise SnapshotError(f"Arxiv topilmadi: {archive}")
    seen: dict[str, tuple[str, int]] = {}
    manifest = None
    with tempfile.TemporaryDirectory(prefix="snapv-") as work:
        db_copy = Path(work) / DB_NAME
        try:
            with tarfile.open(archive, "r:gz") as tar:
                for m in tar:
                    if not _safe_member(m.name) or not m.isreg():
                        raise SnapshotError(f"Arxivda xavfli yoki noto'g'ri element: {m.name!r}")
                    f = tar.extractfile(m)
                    if m.name == MANIFEST:
                        if m.size > 50 * 1024 * 1024:
                            raise SnapshotError("MANIFEST juda katta")
                        manifest = json.loads(f.read().decode("utf-8"))
                        continue
                    h, n = hashlib.sha256(), 0
                    out = open(db_copy, "wb") if m.name == DB_NAME else None
                    try:
                        while chunk := f.read(CHUNK):
                            h.update(chunk)
                            n += len(chunk)
                            if out:
                                out.write(chunk)
                    finally:
                        if out:
                            out.close()
                    seen[m.name] = (h.hexdigest(), n)
        except (tarfile.TarError, OSError, EOFError, ValueError) as e:
            raise SnapshotError(f"Arxiv buzilgan: {e}")
        if not isinstance(manifest, dict) or manifest.get("format") != FORMAT:
            raise SnapshotError("MANIFEST yo'q yoki format mos emas")
        expect = {e["name"]: (e["sha256"], e["size"]) for e in manifest.get("files", [])}
        if set(expect) != set(seen):
            raise SnapshotError("Arxiv tarkibi MANIFEST bilan mos emas (fayl yetishmaydi yoki ortiqcha)")
        bad = [k for k in expect if expect[k] != seen[k]]
        if bad:
            raise SnapshotError(f"{len(bad)} ta fayl buzilgan (SHA-256 mos emas), masalan: {bad[0]}")
        if DB_NAME not in seen:
            raise SnapshotError("Arxivda baza yo'q")
        _db_report(db_copy)
    return manifest


def _has_data(data_dir: Path) -> bool:
    db = data_dir / DB_NAME
    if not db.is_file():
        return False
    try:
        c = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
        try:
            return (c.execute("SELECT COUNT(*) FROM users").fetchone()[0] or 0) > 0
        finally:
            c.close()
    except sqlite3.Error:
        return True


def restore(archive: Path, data_dir: Path, force: bool = False) -> dict:
    archive, data_dir = Path(archive), Path(data_dir)
    manifest = verify(archive)
    data_dir.mkdir(parents=True, exist_ok=True)
    if _has_data(data_dir) and not force:
        raise SnapshotError("Maqsadli papkada ma'lumotlar bor. Tiklash ularni almashtiradi: avval nusxa oling yoki --force ishlating")
    stamp = time.strftime("%Y%m%d-%H%M%S")
    stage = data_dir / f".restore-{stamp}"
    stage.mkdir()
    try:
        with tarfile.open(archive, "r:gz") as tar:
            for m in tar:
                if m.name == MANIFEST:
                    continue
                target = stage / m.name
                target.parent.mkdir(parents=True, exist_ok=True)
                with open(target, "wb") as out:
                    shutil.copyfileobj(tar.extractfile(m), out, CHUNK)
                os.chmod(target, 0o600)
        old = data_dir / f"pre-restore-{stamp}"
        moved = []
        for name in (DB_NAME, DB_NAME + "-wal", DB_NAME + "-shm", *FILE_DIRS):
            p = data_dir / name
            if p.exists():
                old.mkdir(exist_ok=True)
                shutil.move(str(p), str(old / name))
                moved.append(name)
        shutil.move(str(stage / DB_NAME), str(data_dir / DB_NAME))
        for d in FILE_DIRS:
            src = stage / "files" / d
            shutil.move(str(src), str(data_dir / d)) if src.is_dir() else (data_dir / d).mkdir(exist_ok=True)
    finally:
        shutil.rmtree(stage, ignore_errors=True)
    return {"restored": len(manifest["files"]), "previous_moved_to": (f"pre-restore-{stamp}" if moved else None),
            "counts": manifest.get("counts", {})}
