# bootstrap

Bu qatlam uchun hozirgi kod: app.main, app.config, app.db
