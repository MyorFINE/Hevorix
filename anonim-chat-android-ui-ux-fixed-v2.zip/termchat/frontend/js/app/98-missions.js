// ===== Missiyalar, inventar va admin "Missiya paneli" =====
// Alohida qatlam (z-index 135): o'yin oynasi (130) ustida ham, sozlamalar ichida ham bir xil ishlaydi.
const MS = {stack: []};
const MS_SLOT = {frame: "Avatar ramkasi", banner: "Profil foni", color: "Profil rangi", nick: "Nickname animatsiyasi", bio: "Bio animatsiyasi",
  msg: "Xabar animatsiyasi", avatar: "Profil rasmi animatsiyasi", badge: "Nishon"};
const MS_ORDER = ["frame", "avatar", "banner", "color", "nick", "bio", "msg", "badge"];

function msOpen(title, build) {
  const L = {name: "ms" + MS.stack.length, el: h("section", {class: "ms-layer", role: "dialog", "aria-label": title}), body: h("div", {class: "ms-body"})};
  L.el.append(h("div", {class: "pg-head"},
    h("button", {class: "icon-btn", type: "button", "aria-label": "Orqaga", onclick: () => msClose()}, icon("back")),
    h("span", {class: "pg-title", text: title})), L.body);
  L.body.append(build(L));
  MS.stack.push(L); document.body.append(L.el); navPush(L.name);
  requestAnimationFrame(() => L.el.classList.add("in"));
  return L;
}
function msClose() {
  const L = MS.stack.pop(); if (!L) return;
  L.el.classList.remove("in"); setTimeout(() => L.el.remove(), 260); navPop(L.name);
}
function msCloseAll() { while (MS.stack.length) msClose(); }

// Sovg'a elementining kichik ko'rinishi (slotga qarab)
function msThumb(it) {
  const v = it.value;
  if (it.slot === "frame") return h("span", {class: "av av-m fr-" + v}, h("span", {text: "A"}));
  if (it.slot === "avatar") return h("span", {class: "av av-m fxav-" + v}, h("span", {text: "A"}));
  if (it.slot === "banner") return h("span", {class: "ms-bn bn-" + v});
  if (it.slot === "color") { const s = h("span", {class: "ms-col"}); s.style.background = v; return s; }
  if (it.slot === "nick" || it.slot === "bio") return fxText(h("b", {class: "ms-tx", text: it.slot === "nick" ? "Nickname" : "Bio ✨"}), v);
  if (it.slot === "msg") return h("span", {class: "bubble ms-mb fxm-" + v, text: "Salom!"});
  if (it.slot === "badge") {
    const cls = "eb ceb" + (it.anim ? " a-" + it.anim : "");
    return typeof Rich !== "undefined" && Rich.isEmojiToken(v) ? Rich.emojiEl(v, cls, null) : h("span", {class: "eb" + (it.anim ? " a-" + it.anim : ""), text: v});
  }
  return h("span", {text: "?"});
}
const msItemsRow = items => h("div", {class: "ms-items"}, ...(items || []).map(it =>
  h("div", {class: "ms-it", title: (MS_SLOT[it.slot] || it.slot) + ": " + (it.label || it.value)}, h("div", {class: "ms-th"}, msThumb(it)), h("small", {text: it.label || it.value}))));

// ---------- yangi sovg'a oynasi ----------
function msReveal(granted) {
  if (!granted || !granted.length) return;
  const close = () => { ov.remove(); };
  const ov = h("div", {class: "ms-reveal", role: "dialog", "aria-label": "Yangi sovg'a", onclick: e => { if (e.target === ov) close(); }});
  const card = h("div", {class: "ms-rv-card"});
  granted.forEach(g => card.append(
    h("div", {class: "ms-rv-gift", text: g.pack.emoji || "🎁"}),
    h("div", {class: "ms-rv-t", text: "Yangi sovg'a!"}),
    h("div", {class: "ms-rv-n", text: g.pack.name}), h("div", {class: "ms-rv-s", text: g.title}),
    msItemsRow(g.items)));
  card.append(h("div", {class: "ms-rv-b"},
    h("button", {class: "btn", type: "button", text: "🎒 Inventarga o'tish", onclick: () => { close(); msOpenInventory(); }}),
    h("button", {class: "btn ghost", type: "button", text: "Yopish", onclick: close})));
  ov.append(card); document.body.append(ov);
  try { haptic([60, 40, 120]); } catch (_) {}
}

// ---------- foydalanuvchi: Missiyalar ----------
function msOpenMissions() {
  msOpen("Missiyalar", () => {
    const box = h("div", {class: "ms-wrap"}, h("p", {class: "tg-hint", text: "Yuklanmoqda…"}));
    api("/missions").then(j => {
      box.textContent = "";
      j.games.forEach(g => {
        box.append(h("div", {class: "ms-hero"}, h("div", {class: "ms-hero-ic", text: g.emoji}),
          h("div", {class: "ms-hero-t"}, h("b", {text: g.title}), h("small", {text: "Missiya ochkolari"})),
          h("div", {class: "ms-hero-n", text: String(g.points)})));
        if (g.rules.length) {
          box.append(h("h4", {class: "ms-h", text: "Ochko qanday olinadi"}),
            h("div", {class: "ms-rules"}, ...g.rules.map(r => h("div", {class: "ms-rl"}, h("span", {text: r.title + (r.daily_cap ? " (kuniga " + r.daily_cap + " tagacha)" : "")}), h("b", {text: "+" + r.points})))));
        }
        box.append(h("h4", {class: "ms-h", text: "Missiyalar"}));
        if (!g.missions.length) box.append(h("p", {class: "tg-hint", text: "Hozircha missiya yo'q. Admin yaqinda qo'shadi."}));
        g.missions.forEach(m => {
          const pct = Math.min(100, Math.round(g.points / m.need * 100));
          const bar = h("div", {class: "ms-bar"}, h("i", {}));
          bar.firstChild.style.width = (m.done ? 100 : pct) + "%";
          box.append(h("div", {class: "ms-card" + (m.done ? " done" : "")},
            h("div", {class: "ms-ct"}, h("span", {class: "ms-pe", text: m.pack.emoji}), h("div", {class: "ms-cn"}, h("b", {text: m.title}), h("small", {text: "Sovg'a: " + m.pack.name + (m.pack.descr ? " — " + m.pack.descr : "")})),
              h("span", {class: "ms-st", text: m.done ? "✓ Olingan" : Math.min(g.points, m.need) + " / " + m.need})),
            bar, msItemsRow(m.pack.items)));
        });
      });
      box.append(h("p", {class: "tg-hint", text: "Missiya ochkosi faqat internet orqali boshlangan o'yinda botni matt qilib yutganingizda beriladi — natijani server o'yin yozuvini qayta o'ynab tekshiradi."
        + (j.strict ? " Maslahat yoki «orqaga» ishlatilgan o'yin hisoblanmaydi." : "")}),
        setRow("box", "Inventar", () => msOpenInventory(), String(j.inventory)));
      if (j.granted && j.granted.length) msReveal(j.granted);
    }).catch(err => { box.textContent = ""; box.append(h("p", {class: "tg-hint", text: err.message})); });
    return box;
  });
}

// ---------- foydalanuvchi: Inventar ----------
function msOpenInventory() {
  msOpen("Inventar", () => {
    const box = h("div", {class: "ms-wrap"}, h("p", {class: "tg-hint", text: "Yuklanmoqda…"}));
    const refreshUi = () => { try { renderList(); renderMessages(false); } catch (_) {} };
    const act = async (it, on) => {
      try {
        const j = await api("/missions/inventory/" + (on ? "unequip" : "equip"), {method: "POST", body: {item_id: it.id}});
        upsertUser(j.user); refreshUi(); paint(j); toast(on ? "Inventarga qaytarildi" : "Kiyildi", "ok");
      } catch (err) { toast(err.message, "error"); }
    };
    const card = it => h("div", {class: "ms-inv" + (it.on ? " on" : "")}, h("div", {class: "ms-th"}, msThumb(it)),
      h("div", {class: "ms-cn"}, h("b", {text: it.label}), h("small", {text: MS_SLOT[it.slot] + (it.pack ? " • " + it.pack : "")})),
      h("button", {class: "btn sm" + (it.on ? " ghost" : ""), type: "button", text: it.on ? "Olib qo'yish" : "Kiyish", onclick: () => act(it, it.on)}));
    const paint = j => {
      const me = U(S.me.id);
      box.textContent = "";
      const top = tint(h("div", {class: "tg-top ms-prevtop" + bannerCls(me)}), me);
      top.append(avatar(me, "l"), h("div", {class: "pname"}, nameEl(me, {big: true})),
        fxText(h("div", {class: "pe-bio", text: me.bio || "Bio shunday ko'rinadi ✨"}), fxOf(me, "bio")));
      const b = fxBubble(h("div", {class: "bubble pe-bub"}), me);
      b.append(h("div", {class: "bname"}, nameEl(me, {colored: true})), btextEl("btext", "Salom! Xabarim shunday ko'rinadi ✨", true), h("span", {class: "meta", text: "12:00"}));
      box.append(h("div", {class: "pe-prev"}, top, h("div", {class: "pe-msgs"}, h("div", {class: "pe-msg"}, b))));
      const worn = j.items.filter(i => i.on), bag = j.items.filter(i => !i.on);
      if (!j.items.length) { box.append(h("p", {class: "tg-hint", text: "Inventar bo'sh. Missiyalarni bajaring — sovg'alar shu yerga tushadi."}), setRow("game", "Missiyalarga o'tish", () => { msClose(); msOpenMissions(); })); return; }
      box.append(h("h4", {class: "ms-h", text: "Kiyilgan (" + worn.length + ")"}));
      if (!worn.length) box.append(h("p", {class: "tg-hint", text: "Hozir hech narsa kiyilmagan."}));
      MS_ORDER.forEach(s => worn.filter(i => i.slot === s).forEach(i => box.append(card(i))));
      box.append(h("h4", {class: "ms-h", text: "Inventar (" + bag.length + ")"}));
      if (!bag.length) box.append(h("p", {class: "tg-hint", text: "Hammasi kiyilgan."}));
      MS_ORDER.forEach(s => bag.filter(i => i.slot === s).forEach(i => box.append(card(i))));
      box.append(h("p", {class: "tg-hint", text: "Har bir narsani alohida kiyish mumkin. Olib qo'ysangiz, u yo'qolmaydi — inventarga qaytadi."}));
    };
    api("/missions/inventory").then(paint).catch(err => { box.textContent = ""; box.append(h("p", {class: "tg-hint", text: err.message})); });
    return box;
  });
}

// ---------- shaxmat boti bilan integratsiya ----------
async function msBegin(level, side) {
  if (S.offline) return null;
  try { return (await api("/missions/start", {method: "POST", body: {game: "chess", level, side}})).token; } catch (_) { return null; }
}
async function msSubmit(g, box) {
  const m = g && g.mis; if (!m || m.sent || !box) return;
  const tok = m.tok || (m.p ? await m.p : null);
  if (!tok) { box.textContent = "🎯 Missiya ochkosi faqat internet orqali boshlangan o'yin uchun hisoblanadi"; return; }
  m.sent = true; box.textContent = "🎯 Missiya tekshirilmoqda…";
  try {
    const j = await api("/missions/submit", {method: "POST", body: {game: "chess", token: tok, moves: g.moves, hints: m.hints | 0, undos: m.undos | 0}});
    box.textContent = j.counted ? "🎯 +" + j.gained + " missiya ochkosi (jami " + j.total + ")" : "🎯 " + j.reason;
    if (j.counted) box.classList.add("ok");
    if (j.granted && j.granted.length) msReveal(j.granted);
  } catch (err) {
    if (err instanceof TypeError) m.sent = false;
    box.textContent = "🎯 " + (err.message || "Missiyani tekshirib bo'lmadi");
  }
}
const Missions = {open: msOpenMissions, inventory: msOpenInventory, admin: () => msOpenAdmin(), begin: msBegin, submit: msSubmit};

// ---------- admin: Missiya paneli ----------
function msOpenAdmin() {
  if (!amAdmin()) return;
  msOpen("Missiya paneli", () => {
    const box = h("div", {class: "ms-wrap"}, h("p", {class: "tg-hint", text: "Yuklanmoqda…"}));
    const load = () => api("/missions/admin").then(j => paint(j)).catch(err => { box.textContent = ""; box.append(h("p", {class: "tg-hint", text: err.message})); });
    const numIn = (v, mx) => { const i = h("input", {class: "fld ms-num", type: "number", min: "0", max: String(mx), inputmode: "numeric"}); i.value = String(v); return i; };
    const paint = j => {
      box.textContent = "";
      box.append(h("h4", {class: "ms-h", text: "Ochko qoidalari"}));
      j.games.forEach(g => {
        box.append(h("p", {class: "tg-hint", text: g.emoji + " " + g.title + " — har bir g'alaba necha missiya ochkosi bersin (0 = bermaydi). «Kuniga» — bir kunda nechta g'alaba hisoblansin (0 = cheklovsiz)."}));
        g.rules.forEach(r => {
          const p = numIn(r.points, 10000), c = numIn(r.daily_cap, 1000);
          const save = h("button", {class: "btn sm", type: "button", text: "Saqlash"});
          save.addEventListener("click", async () => {
            save.disabled = true;
            try { await api("/missions/admin/rule", {method: "POST", body: {game: g.game, rule: r.rule, points: parseInt(p.value || "0", 10), daily_cap: parseInt(c.value || "0", 10)}}); toast("Saqlandi", "ok"); }
            catch (err) { toast(err.message, "error"); }
            save.disabled = false;
          });
          box.append(h("div", {class: "ms-rule"}, h("span", {class: "ms-rt", text: r.title}),
            h("label", {class: "ms-lb"}, "Ochko", p), h("label", {class: "ms-lb"}, "Kuniga", c), save));
        });
      });
      box.append(switchRow("shield", "Maslahat / «orqaga» ishlatilsa ochko berilmasin", () => j.strict, async on => {
        await api("/missions/admin/strict", {method: "POST", body: {on}}); j.strict = on;
      }, "Yoqilgan bo'lsa, bot yutgan o'yinda maslahat yoki «orqaga» ishlatilgan bo'lsa missiya ochkosi berilmaydi."));

      box.append(h("h4", {class: "ms-h", text: "Dizayn paketlari (" + j.packs.length + ")"}));
      j.packs.forEach(p => box.append(h("div", {class: "ms-card"},
        h("div", {class: "ms-ct"}, h("span", {class: "ms-pe", text: p.emoji}), h("div", {class: "ms-cn"}, h("b", {text: p.name}), h("small", {text: p.items.length + " ta element" + (p.descr ? " • " + p.descr : "")})),
          h("button", {class: "btn sm ghost", type: "button", text: "Tahrirlash", onclick: () => msPackEditor(j, p, load)})),
        msItemsRow(p.items))));
      box.append(h("div", {class: "pe-save"}, h("button", {class: "btn", type: "button", text: "➕ Yangi paket", onclick: () => msPackEditor(j, null, load)})));

      box.append(h("h4", {class: "ms-h", text: "Missiyalar (" + j.rewards.length + ")"}));
      if (!j.packs.length) box.append(h("p", {class: "tg-hint", text: "Missiya yaratish uchun avval paket yarating."}));
      j.rewards.forEach(r => box.append(h("div", {class: "ms-card" + (r.active ? "" : " off")},
        h("div", {class: "ms-ct"}, h("span", {class: "ms-pe", text: r.pack ? r.pack.emoji : "❔"}),
          h("div", {class: "ms-cn"}, h("b", {text: r.title}), h("small", {text: (r.game === "chess" ? "Shaxmat" : r.game) + " • " + r.need + " ochko → " + (r.pack ? r.pack.name : "—") + " • olgan: " + r.claimed + (r.active ? "" : " • o'chirilgan")})),
          h("button", {class: "btn sm ghost", type: "button", text: "Tahrirlash", onclick: () => msRewardEditor(j, r, load)})))));
      if (j.packs.length) box.append(h("div", {class: "pe-save"}, h("button", {class: "btn", type: "button", text: "➕ Yangi missiya", onclick: () => msRewardEditor(j, null, load)})));
    };
    load();
    return box;
  });
}

function msRewardEditor(j, r, reload) {
  msOpen(r ? "Missiyani tahrirlash" : "Yangi missiya", () => {
    const d = {game: r ? r.game : j.games[0].game, title: r ? r.title : "", need: r ? r.need : 25, pack_id: r && r.pack ? r.pack.id : j.packs[0].id, active: r ? r.active : true};
    const title = h("input", {class: "fld", maxlength: "48", placeholder: "Masalan: Shaxmat ustasi"}); title.value = d.title;
    const need = h("input", {class: "fld", type: "number", min: "1", max: "1000000", inputmode: "numeric"}); need.value = String(d.need);
    const game = h("select", {class: "fld"}, ...j.games.map(g => h("option", {value: g.game, text: g.emoji + " " + g.title}))); game.value = d.game;
    const pack = h("select", {class: "fld"}, ...j.packs.map(p => h("option", {value: String(p.id), text: p.emoji + " " + p.name + " (" + p.items.length + ")"}))); pack.value = String(d.pack_id);
    const wrap = h("div", {class: "ms-wrap"},
      h("label", {class: "fl"}, "O'yin", game), h("label", {class: "fl"}, "Missiya nomi", title),
      h("label", {class: "fl"}, "Shuncha ochko to'plaganda sovg'a beriladi", need), h("label", {class: "fl"}, "Sovg'a (dizayn paketi)", pack),
      switchRow("check", "Faol (foydalanuvchilarga ko'rinadi)", () => d.active, async on => { d.active = on; }));
    const save = h("button", {class: "btn", type: "button", text: "Saqlash"});
    save.addEventListener("click", async () => {
      save.disabled = true;
      try {
        await api("/missions/admin/reward", {method: "POST", body: {id: r ? r.id : null, game: game.value, title: title.value, need: parseInt(need.value || "0", 10), pack_id: parseInt(pack.value, 10), active: d.active}});
        toast("Saqlandi", "ok"); msClose(); reload();
      } catch (err) { toast(err.message, "error"); save.disabled = false; }
    });
    wrap.append(h("div", {class: "pe-save"}, save));
    if (r) wrap.append(h("div", {class: "pe-save"}, h("button", {class: "btn ghost danger", type: "button", text: "O'chirish", onclick: async () => {
      if (!await confirmDlg("Missiya o'chiriladi. Foydalanuvchilarga ilgari berilgan sovg'alar inventarda qoladi.", {title: "Missiyani o'chirish", okText: "O'chirish", danger: true})) return;
      try { await api("/missions/admin/reward/delete", {method: "POST", body: {id: r.id}}); msClose(); reload(); } catch (err) { toast(err.message, "error"); }
    }})));
    return wrap;
  });
}

function msPackEditor(j, p, reload) {
  msOpen(p ? "Paketni tahrirlash" : "Yangi paket", () => {
    const cat = j.catalog;
    const items = p ? p.items.map(x => Object.assign({}, x)) : [];
    const has = (slot, value, anim) => items.findIndex(x => x.slot === slot && x.value === value && (x.anim || "") === (anim || ""));
    const name = h("input", {class: "fld", maxlength: "32", placeholder: "Masalan: Neon to'plami"}); name.value = p ? p.name : "";
    const emoji = h("input", {class: "fld", maxlength: "8", placeholder: "🎁"}); emoji.value = p ? p.emoji : "🎁";
    const descr = h("input", {class: "fld", maxlength: "120", placeholder: "Qisqa tavsif (ixtiyoriy)"}); descr.value = p ? p.descr : "";
    const sel = h("div", {class: "ms-sel"}), blocks = h("div", {});
    const paint = () => {
      sel.textContent = "";
      sel.append(h("h4", {class: "ms-h", text: "Paket tarkibi (" + items.length + " / " + cat.max_items + ")"}));
      if (!items.length) sel.append(h("p", {class: "tg-hint", text: "Pastdan kerakli dizaynlarni tanlang."}));
      sel.append(h("div", {class: "ms-items"}, ...items.map((it, i) => h("button", {class: "ms-it rm", type: "button", title: "Olib tashlash", onclick: () => { items.splice(i, 1); paint(); }},
        h("div", {class: "ms-th"}, msThumb(it)), h("small", {text: (MS_SLOT[it.slot] || it.slot).split(" ")[0] + ": " + (it.label || it.value) + " ✕"})))));
      blocks.textContent = "";
      cat.slots.forEach(s => {
        const b = h("div", {class: "ms-slot"}, h("h5", {text: s.label}));
        if (s.values) {
          b.append(h("div", {class: "ms-opts"}, ...s.values.map(v => {
            const it = {slot: s.slot, value: v.value, anim: "", label: v.label}, on = has(s.slot, v.value, "") >= 0;
            return h("button", {class: "ms-opt" + (on ? " on" : ""), type: "button", onclick: () => {
              const k = has(s.slot, v.value, "");
              if (k >= 0) items.splice(k, 1); else if (items.length >= cat.max_items) { toast("Paketda " + cat.max_items + " tadan ko'p element bo'lmasin", "warn"); return; } else items.push(it);
              paint();
            }}, h("div", {class: "ms-th"}, msThumb(it)), h("small", {text: v.label}));
          })));
        } else if (s.slot === "color") {
          const c = h("input", {type: "color"}); c.value = "#ff3df0";
          b.append(h("div", {class: "ms-add"}, c, h("button", {class: "btn sm", type: "button", text: "➕ Rang qo'shish", onclick: () => {
            if (items.length >= cat.max_items) { toast("Paket to'ldi", "warn"); return; }
            const v = c.value.toLowerCase(); if (has("color", v, "") < 0) items.push({slot: "color", value: v, anim: "", label: "Rang " + v}); paint();
          }})));
        } else if (s.slot === "badge") {
          const e = h("input", {class: "fld ms-emo", maxlength: "8", placeholder: "🏆"});
          const a = h("select", {class: "fld"}, h("option", {value: "", text: "Animatsiyasiz"}), ...cat.anims.map(x => h("option", {value: x, text: x})));
          b.append(h("div", {class: "ms-add"}, e, a, h("button", {class: "btn sm", type: "button", text: "➕ Qo'shish", onclick: () => {
            const v = e.value.trim(); if (!v) { toast("Nishon emojisini kiriting", "warn"); return; }
            if (items.length >= cat.max_items) { toast("Paket to'ldi", "warn"); return; }
            if (has("badge", v, a.value) < 0) items.push({slot: "badge", value: v, anim: a.value, label: "Nishon " + v}); e.value = ""; paint();
          }})));
        }
        blocks.append(b);
      });
    };
    paint();
    const save = h("button", {class: "btn", type: "button", text: "Saqlash"});
    save.addEventListener("click", async () => {
      save.disabled = true;
      try {
        await api("/missions/admin/pack", {method: "POST", body: {id: p ? p.id : null, name: name.value, emoji: emoji.value, descr: descr.value, items: items.map(x => ({slot: x.slot, value: x.value, anim: x.anim || ""}))}});
        toast("Paket saqlandi", "ok"); msClose(); reload();
      } catch (err) { toast(err.message, "error"); save.disabled = false; }
    });
    const wrap = h("div", {class: "ms-wrap"}, h("label", {class: "fl"}, "Paket nomi", name), h("label", {class: "fl"}, "Paket belgisi (emoji)", emoji), h("label", {class: "fl"}, "Tavsif", descr), sel, blocks,
      h("div", {class: "pe-save"}, save),
      h("p", {class: "tg-hint", text: "Paket ochilganda har bir element foydalanuvchi inventariga ALOHIDA tushadi va alohida kiyiladi. Paketni keyin o'zgartirsangiz, allaqachon berilgan elementlar o'zgarmaydi."}));
    if (p) wrap.append(h("div", {class: "pe-save"}, h("button", {class: "btn ghost danger", type: "button", text: "Paketni o'chirish", onclick: async () => {
      if (!await confirmDlg("Paket va unga bog'langan missiyalar o'chiriladi. Foydalanuvchilarga berilgan elementlar inventarda qoladi.", {title: "Paketni o'chirish", okText: "O'chirish", danger: true})) return;
      try { await api("/missions/admin/pack/delete", {method: "POST", body: {id: p.id}}); msClose(); reload(); } catch (err) { toast(err.message, "error"); }
    }})));
    return wrap;
  });
}
