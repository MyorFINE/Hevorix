/* ---------------- Saqlash (Save as) va Oldinga yuborish: hammasi qurilmada, E2EE saqlanadi ----------------
   Saqlash: fayl shifrlangan holda yuklanadi va FAQAT shu qurilmada ochiladi (server ochiq faylni ko'rmaydi).
   Oldinga yuborish: xabar/fayl qurilmada ochiladi va tanlangan suhbat uchun QAYTA shifrlanadi (yangi fayl kaliti,
   yangi konvert, o'z imzom). Server faqat yangi shifrni ko'radi; asl xabarga bog'liq emas (asl o'chsa ham nusxa qoladi). */
const safeName = n => String(n || "fayl").replace(/[\\/:*?"<>|\u0000-\u001f]/g, "_").replace(/^\.+/, "").trim().slice(0, 120) || "fayl";
async function messageBytes(m) {
  if (m.e2e) return e2eFetchBlob(m);
  const url = m.image || (m.file && m.file.url);                            // eski (E2EE'dan oldingi) xabar
  const r = await SC.fetch(url, {headers: {Authorization: "Bearer " + S.token}});
  if (!r.ok) throw new Error("fayl");
  return r.bytes;
}
async function saveBytesAs(getBytes, name) {
  let handle = null;
  if (window.showSaveFilePicker) {                                           // kompyuter: "Save as" oynasi (joy va nom tanlanadi). Bosish faolligi tugamasin deb — avval oyna
    try { handle = await window.showSaveFilePicker({suggestedName: name}); }
    catch (err) { if (err && err.name === "AbortError") return false; handle = null; }
  }
  let bytes;
  try { bytes = await getBytes(); } catch (err) { if (handle && handle.remove) handle.remove().catch(() => {}); throw err; }
  if (handle) {
    const w = await handle.createWritable();
    try { await w.write(bytes); await w.close(); } catch (err) { try { await w.abort(); } catch (_) {} throw err; }
    return true;
  }
  const url = URL.createObjectURL(new Blob([bytes], {type: "application/octet-stream"}));      // telefon/boshqa brauzer: yuklab olishlar papkasiga
  const a = h("a", {href: url, download: name}); document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60000);
  return true;
}
async function saveAs(m) {
  const name = safeName((m._f && m._f.name) || (m.file && m.file.name) || (m.image ? "rasm.jpg" : "fayl"));
  try { if (await saveBytesAs(() => messageBytes(m), name)) toast("Saqlandi: " + name, "ok"); }
  catch (_) { toast("Faylni saqlab bo'lmadi", "error"); }
}
function forwardMessage(m) {
  const picked = new Map();                                                  // kalit -> {kind, uid}
  let filter = "", busy = false;
  const targets = () => [{key: "g", kind: "group"}].concat(S.members.filter(x => x.id !== S.me.id && !x.deleted && !x.banned).map(x => ({key: "u" + x.id, kind: "dm", uid: x.id})));
  const what = m.image ? "📷 Rasm" : m.file ? fileIco(m.file) + fileWhat(m.file) : "";
  openModal(() => {
    const list = h("div", {class: "fwl"}), send = h("button", {class: "btn", type: "button", disabled: true, text: "Yuborish"});
    const note = h("div", {class: "fw-note", text: (what ? what + (m.content ? " • " : "") : "") + (m.content ? m.content.replace(/\s+/g, " ").slice(0, 80) : "")});
    const upd = () => { send.disabled = busy || !picked.size; send.textContent = picked.size ? "Yuborish (" + picked.size + ")" : "Yuborish"; };
    const fill = () => {
      list.textContent = "";
      const q = filter.trim().toLowerCase().replace(/^@/, "");
      targets().forEach(t => {
        const u = t.kind === "dm" ? U(t.uid) : null;
        if (q && (!u || !(u.nickname.toLowerCase().includes(q) || u.username.toLowerCase().includes(q)))) { if (!(t.kind === "group" && "umumiy chat".includes(q))) return; }
        const ck = h("input", {type: "checkbox", class: "ck", tabindex: "-1", "aria-hidden": "true"}); ck.checked = picked.has(t.key);
        const row = h("button", {class: "frow" + (ck.checked ? " on" : ""), type: "button"},
          u ? avatar(u, "m", true) : groupAvatar("m"),
          h("div", {class: "utx"}, u ? nameEl(u) : h("span", {class: "nt", text: "Umumiy chat"}), h("span", {class: "fsub", text: u ? "@" + u.username : (S.members.length || 1) + " a'zo"})), ck);
        row.addEventListener("click", () => { if (busy) return; if (picked.has(t.key)) picked.delete(t.key); else picked.set(t.key, t); ck.checked = picked.has(t.key); row.classList.toggle("on", ck.checked); upd(); });
        list.append(row);
      });
      if (!list.children.length) list.append(h("div", {class: "none", text: "Hech narsa topilmadi"}));
    };
    const search = h("input", {type: "text", class: "gsearch", placeholder: "Qidirish", autocomplete: "off"});
    search.addEventListener("input", () => { filter = search.value; fill(); });
    send.addEventListener("click", async () => {
      if (busy || !picked.size) return;
      busy = true; upd(); send.textContent = "Shifrlanmoqda…"; search.disabled = true;
      const r = await doForward(m, [...picked.values()]);
      busy = false; closeModal();
      if (r.ok) toast("Oldinga yuborildi" + (r.ok > 1 ? " (" + r.ok + " ta suhbat)" : ""), "ok");
      if (r.errs.length) toast(r.errs[0] + (r.errs.length > 1 ? " (+" + (r.errs.length - 1) + " ta xato)" : ""), "error");
    });
    fill();
    return h("div", {}, sheetHead("Oldinga yuborish"), note, search, list, h("div", {class: "fw-bar"}, send));
  }, false);
}
async function doForward(m, targets) {
  const res = {ok: 0, errs: []};
  let enc = null;
  const fw = m._fw || (m.ch ? {n: (chInfo(m.ch) || {}).nickname || "Kanal", id: 0} : {n: m.user.nickname, id: m.user.id});                    // asl muallif saqlanadi (zanjirda ham)
  try { if (m._f) enc = await E2E.encryptFile(new Uint8Array(await messageBytes(m))); }   // fayl bir marta yangi kalit bilan qayta shifrlanadi
  catch (_) { res.errs.push("Faylni ochib bo'lmadi"); return res; }
  for (const t of targets) {
    const label = t.kind === "group" ? "Umumiy chat" : U(t.uid).nickname;
    try {
      if (t.kind === "group" && S.chat.locked && !amAdmin()) throw new Error("chat qulflangan");
      if (t.kind === "dm" && U(t.uid).deleted) throw new Error("akkaunt o'chirilgan");
      const ctx = await keyForTarget(t), payload = {t: m.content || "", fw};
      let blobName = null;
      if (enc) {
        const r = await SC.fetch("/api/e2ee/blob", {method: "POST", headers: {Authorization: "Bearer " + S.token, "Content-Type": "application/octet-stream"}, body: enc.blob});
        const j = await r.json().catch(() => ({}));
        if (!r.ok) throw new Error(typeof j.detail === "string" ? j.detail : "fayl yuklanmadi");
        blobName = j.blob; payload.f = Object.assign({}, m._f, {k: enc.key});
      }
      const msg = {type: "send", e2e: await sealFor(ctx, payload)};
      if (blobName) msg.blob = blobName;
      withTarget(msg, t);
      if (!wsSend(msg)) throw new Error("ulanish yo'q");
      res.ok++;
    } catch (err) { res.errs.push(label + ": " + err.message); }
  }
  return res;
}
async function reportMessage(m) {
  const reason = await promptDlg("Shikoyat qilish", m.e2e
    ? "Xabarlar shifrlangan, adminlar ularni o'qiy olmaydi. Shikoyat yuborsangiz, FAQAT shu bitta xabarning matni adminlarga ochib beriladi. Nima uchun shikoyat qilyapsiz? (ixtiyoriy)"
    : "Nima uchun shikoyat qilyapsiz? (ixtiyoriy)", "", {okText: "Yuborish", placeholder: "Sabab"});
  if (reason === null) return;
  try { await api("/report", {method: "POST", body: {message_id: m.id, reason, evidence: m.e2e ? (m.content || "") : ""}}); toast("Shikoyat adminlarga yuborildi", "ok"); }
  catch (err) { toast(err.message, "error"); }
}
document.addEventListener("click", e => {
  if (Date.now() - (S.ctxAt || 0) > 350) closeCtx();
});
async function copyText(t) {
  try { await navigator.clipboard.writeText(t); toast("Nusxalandi", "ok"); }
  catch (_) {
    const ta = h("textarea", {class: "offscreen"}); ta.value = t; document.body.append(ta); ta.select();
    try { document.execCommand("copy"); toast("Nusxalandi", "ok"); } catch (_e) {}
    ta.remove();
  }
}

