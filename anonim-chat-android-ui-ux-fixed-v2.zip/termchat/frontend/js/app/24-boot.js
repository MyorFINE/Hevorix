/* ---------------- ishga tushirish ---------------- */
/* ---------------- kanallar (js/channels.js) ---------------- */
const chBridge = {api, h, icon, toast, confirmDlg, promptDlg, openModal, closeModal, sheetHead, navPush, navPop, hhmm, dayLabel, avatar, nameEl,
                  amAdmin: () => amAdmin(), me: () => S.me, openMenu, openProfile: id => openProfile(id), infoPage, closePage, closeAllPages, refreshPages, chanData: id => S.chn.get(id), setChannelList, chanAvatar, patchPost,
                  openChat, closeChat, active: () => S.active, info: chInfo, hydrateComment, sealComment, renderList, renderHeader,
                  list: () => S.chList, isMobile, fmtDT: ts => fmtDT(ts)};
function openApp() {
  resetState();
  $("auth").classList.add("hidden"); $("app").classList.remove("hidden");
  document.querySelectorAll(".tabs button").forEach(x => x.classList.toggle("on", x.dataset.tab === "chats"));
  $("chat").classList.add("hidden"); $("empty").classList.remove("hidden");
  S.wantClose = false;
  loadEmojis();                                                                     // emoji katalogi: tayyor + admin yaratgan emojilar, ruxsatlar
  X.ready = (async () => { await loadMembers(); try { await loadRoom(); } catch (_) {} applyPendingOpen(); })();
  connect();
  Channels.init(chBridge); Channels.loadList().then(applyPendingChannel).catch(() => {});                // kanallar ro'yxati (ko'rinmagan postlar belgisi uchun)
  Push.sync(api).catch(() => {});                                                   // ruxsat berilgan bo'lsa, obuna serverda ekaniga ishonch hosil qilamiz
  setTimeout(askNotifications, 2500);                                               // birinchi marta: ruxsat so'raymiz
}
/* Har safar sahifa ochilganda login oynasi chiqadi (avtomatik kirish yo'q). Eski qurilmada qolgan kalitlar ham tozalanadi. */
(function boot() {
  let tok = ""; try { tok = localStorage.getItem(LS_STAY) || ""; } catch (_) {}
  if (tok) resumeStay(tok, 0);                                   // foydalanuvchi o'zi login so'rashni o'chirgan qurilma
  else { try { E2E.clearIdentity(); } catch (_) {} }             // aks holda har ochilganda login (eski qurilmada qolgan kalitlar ham tozalanadi)
})();
/* Kalitli xodim (Hevorix/admin) onlayn ekan, kaliti yo'q yangi a'zolarga guruh kalitini muntazam o'rab beradi */
setInterval(() => { if (S.token && S.me && isStaff(S.me) && X.rooms.size) serveWraps(); }, 30000);
