/* ---------------- 12b-richinput.js: xabar yozish maydoni (emoji rasm bo'lib ko'rinadi) ----------------
   Maxsus emoji `:nom:` kodi yozish maydonida ham kod emas, emoji RASMI bo'lib turadi (Telegramdagidek).
   `#inp` — contenteditable (faqat matn). Unga textarea'ga xos `value`, `selectionStart/End`, `setRangeText`,
   `setSelectionRange`, `maxLength`, `placeholder` xossalari beriladi — qolgan kod o'zgarishsiz ishlaydi.
   Matn har doim ochiq «:nom:» ko'rinishida o'qiladi va E2EE konvert ichida yuboriladi (yuboriladigan narsa o'zgarmaydi). */
(() => {
  const el = $("inp");
  if (!el || el.tagName === "TEXTAREA") return;
  let plain = true;
  try { el.contentEditable = "plaintext-only"; plain = el.contentEditable === "plaintext-only"; } catch (_) { plain = false; }
  if (!plain) el.contentEditable = "true";                    // eski brauzerlar: oddiy contenteditable (kiritish baribir matnga aylantiriladi)
  let max = parseInt(el.getAttribute("data-maxlength") || "3000", 10) || 3000, composing = false, last = null;

  const ser = (node, top = true) => {                         // DOM -> matn (emoji rasmi -> «:nom:»)
    let out = "";
    for (let n = node.firstChild; n; n = n.nextSibling) {
      if (n.nodeType === 3) out += n.nodeValue.replace(/\u00a0/g, " ");
      else if (n.nodeType === 1) {
        if (n.nodeName === "IMG") out += n.dataset.t || n.alt || "";
        else if (n.nodeName === "BR") { if (n.nextSibling || !top) out += "\n"; }      // oxirgi <br> — brauzer qo'ygan o'rin to'ldiruvchi
        else {
          if (/^(DIV|P|LI)$/.test(n.nodeName) && out && !out.endsWith("\n")) out += "\n";
          out += ser(n, false);
        }
      }
    }
    return out;
  };
  const emojiImg = token => {
    const i = Rich.chatEmoji(token, false);
    i.className = "ce ci"; i.title = ""; i.dataset.t = token; i.contentEditable = "false"; i.draggable = false;
    return i;
  };
  const frag = text => {                                      // matn -> bo'laklar: ma'lum emoji kodlari rasmga aylanadi
    const f = document.createDocumentFragment(), ms = Rich.emojiMatches(text);
    let at = 0;
    for (const m of ms) {
      if (m.i > at) f.append(document.createTextNode(text.slice(at, m.i)));
      f.append(emojiImg(m.t)); at = m.i + m.t.length;
    }
    if (at < text.length) f.append(document.createTextNode(text.slice(at)));
    return f;
  };
  const selRange = () => {
    const s = getSelection();
    if (!s || !s.rangeCount) return null;
    const r = s.getRangeAt(0);
    return el.contains(r.startContainer) && el.contains(r.endContainer) ? r : null;
  };
  const lenBefore = (node, off) => { const r = document.createRange(); r.selectNodeContents(el); r.setEnd(node, off); return ser(r.cloneContents()).length; };
  const getSel = () => {
    const r = selRange();
    if (r) return (last = [lenBefore(r.startContainer, r.startOffset), lenBefore(r.endContainer, r.endOffset)]);
    const n = ser(el).length;
    return last ? [Math.min(last[0], n), Math.min(last[1], n)] : [n, n];
  };
  const locate = off => {                                     // matndagi o'rin -> DOM o'rni
    let acc = 0;
    const w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT);
    for (let n = w.nextNode(); n; n = w.nextNode()) {
      if (n.nodeType === 3) {
        const len = n.nodeValue.length;
        if (off <= acc + len) return [n, Math.max(0, off - acc)];
        acc += len;
      } else if (n.nodeName === "IMG") {
        const L = (n.dataset.t || "").length, p = n.parentNode, idx = Array.prototype.indexOf.call(p.childNodes, n);
        if (off <= acc) return [p, idx];
        if (off <= acc + L) return [p, idx + 1];                // emoji ichiga tushsa — undan keyin
        acc += L;
      }
    }
    return [el, el.childNodes.length];
  };
  const setSel = (a, b) => {
    const s = getSelection(), r = document.createRange(), p = locate(a), q = b === a ? p : locate(b);
    r.setStart(p[0], p[1]); r.setEnd(q[0], q[1]);
    s.removeAllRanges(); s.addRange(r); last = [a, b];
  };
  const fire = () => el.dispatchEvent(new Event("input", {bubbles: true}));

  Object.defineProperty(el, "value", {configurable: true,
    get() { return ser(el); },
    set(v) { v = v == null ? "" : String(v); el.textContent = ""; last = null; if (v) el.append(frag(v)); }});
  Object.defineProperty(el, "selectionStart", {configurable: true, get() { return getSel()[0]; }, set(v) { setSel(v, getSel()[1] < v ? v : getSel()[1]); }});
  Object.defineProperty(el, "selectionEnd", {configurable: true, get() { return getSel()[1]; }, set(v) { setSel(Math.min(getSel()[0], v), v); }});
  Object.defineProperty(el, "placeholder", {configurable: true, get() { return el.dataset.placeholder || ""; }, set(v) { el.dataset.placeholder = v; }});
  Object.defineProperty(el, "maxLength", {configurable: true, get() { return max; }, set(v) { max = (v | 0) || max; }});
  el.setSelectionRange = (a, b) => setSel(a, b == null ? a : b);
  el.setRangeText = (text, s, e, mode) => {
    if (s == null) { const c = getSel(); s = c[0]; e = c[1]; }
    const p = locate(s), q = locate(e), r = document.createRange();
    r.setStart(p[0], p[1]); r.setEnd(q[0], q[1]); r.deleteContents();
    r.insertNode(frag(String(text)));
    el.normalize();
    const end = s + String(text).length;
    if (mode === "select") setSel(s, end); else if (mode === "start") setSel(s, s); else if (mode !== "preserve") setSel(end, end);
  };
  const nativeFocus = el.focus.bind(el);
  el.focus = o => { const had = !!selRange(); nativeFocus(o); if (!had) { const n = last ? getSel()[1] : ser(el).length; setSel(n, n); } };
  const put = text => {                                       // kursor o'rniga matn (+ emoji rasmlari) qo'yadi
    const c = getSel(), room = max - (ser(el).length - (c[1] - c[0]));
    if (room <= 0) { try { toast("Xabar juda uzun", "warn"); } catch (_) {} return; }
    el.setRangeText(text.length > room ? text.slice(0, room) : text, c[0], c[1], "end"); fire();
  };

  document.addEventListener("selectionchange", () => { if (selRange()) getSel(); });
  el.addEventListener("compositionstart", () => { composing = true; });
  el.addEventListener("compositionend", () => { composing = false; });
  el.addEventListener("beforeinput", e => {
    const t = e.inputType;
    if (t === "insertParagraph" || t === "insertLineBreak") { e.preventDefault(); put("\n"); return; }   // yangi qator: har doim oddiy «\n»
    if (t === "insertFromPaste" || t === "insertFromDrop" || t === "insertFromPasteAsQuotation") {
      const txt = (e.dataTransfer && e.dataTransfer.getData("text/plain")) || e.data || "";
      e.preventDefault();
      if (txt) put(txt.replace(/\r\n?/g, "\n"));
      return;
    }
    if (t === "insertText" && e.data && !composing) {
      const c = getSel();
      if (ser(el).length - (c[1] - c[0]) + e.data.length > max) { e.preventDefault(); try { toast("Xabar juda uzun", "warn"); } catch (_) {} }
    }
  });
  el.addEventListener("input", () => {
    if (composing) return;
    const v = ser(el);
    if (!v && el.firstChild) { el.textContent = ""; return; }   // brauzer qoldirgan <br> va h.k.: placeholder ko'rinishi uchun
    if (v.length > max) { const c = getSel()[0]; el.value = v.slice(0, max); const n = Math.min(c, max); setSel(n, n); }
  });
  el.addEventListener("copy", e => {                          // nusxada emoji kodi (matn) chiqadi, rasm emas
    const r = selRange();
    if (!r || r.collapsed || !e.clipboardData) return;
    e.clipboardData.setData("text/plain", ser(r.cloneContents())); e.preventDefault();
  });
  el.addEventListener("cut", e => {
    const r = selRange();
    if (!r || r.collapsed || !e.clipboardData) return;
    e.clipboardData.setData("text/plain", ser(r.cloneContents())); e.preventDefault();
    r.deleteContents(); el.normalize(); fire();
  });
})();
