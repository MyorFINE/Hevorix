/* ====================================================================
   SAHIFALAR: o'ngdan chapga (profil, sozlamalar, guruh/kanal ma'lumoti...) va CHAP MENYU: chapdan o'ngga.
   Hammasi bitta tizim: oyna ustida oyna (alert) EMAS — to'liq sahifa, orqaga tugmasi/jest bilan yopiladi.
   ==================================================================== */
const PG = {list: []};
const PG_MS = 320;
function pageHead(title, right) {
  return h("div", {class: "pg-head"},
    h("button", {class: "icon-btn", type: "button", onclick: () => closePage(), "aria-label": "Orqaga"}, icon("back")),
    h("span", {class: "pg-title", text: title}), right || null);
}
function paintPage(p) {
  const top = p.el.scrollTop;
  p.refresh = null;
  p.el.textContent = "";
  p.el.append(p.build(p));
  p.el.scrollTop = top;
}
function openPage(build, live) {
  const layer = $("pages");
  const p = {el: h("section", {class: "pg tgp"}), build, live: !!live, at: performance.now(), name: "pg" + PG.list.length, refresh: null, closing: false};
  paintPage(p);
  const prev = PG.list[PG.list.length - 1]; if (prev) prev.el.classList.add("under");
  PG.list.push(p);
  layer.classList.add("on"); layer.append(p.el);
  navPush(p.name);
  void p.el.offsetWidth;
  requestAnimationFrame(() => p.el.classList.add("in"));
  return p;
}
function closePage() {
  const p = PG.list.pop(); if (!p) return;
  const prev = PG.list[PG.list.length - 1]; if (prev) prev.el.classList.remove("under");
  p.closing = true; p.el.classList.remove("in");
  setTimeout(() => { p.el.remove(); if (!PG.list.length) $("pages").classList.remove("on"); }, PG_MS);
  navPop(p.name);
}
function closeAllPages() { while (PG.list.length) closePage(); }
function resetPages() { if (AVV.el) { AVV.el.remove(); AVV.el = null; AVV.closing = false; } PG.list.forEach(p => p.el.remove()); PG.list.length = 0; $("pages").classList.remove("on"); closeDrawerNow(); }
let _rpTimer = 0;
function refreshPages() {                          // jonli sahifalar (profil, ma'lumot) — animatsiya tugagach, ketma-ket chaqiruvlar bittaga birlashadi
  if (_rpTimer || !PG.list.some(p => p.live || p.refresh)) return;
  const at = Math.max(...PG.list.map(p => p.at));
  _rpTimer = setTimeout(() => {
    _rpTimer = 0;
    requestAnimationFrame(() => PG.list.slice().forEach(p => { if (p.closing) return; if (p.refresh) p.refresh(); else if (p.live) paintPage(p); }));
  }, Math.max(150, 450 - (performance.now() - at)));
}
function repaintTopPage() { const p = PG.list[PG.list.length - 1]; if (p) paintPage(p); }
$("pages").addEventListener("click", e => { if (e.target === $("pages")) closeAllPages(); });     // kompyuterda: panel tashqarisini bosish

/* ---------------- chap menyu (Telegram uslubi) ---------------- */
const drawerIsOpen = () => $("drawer").classList.contains("open");
function openDrawer() {
  if (drawerIsOpen()) return;
  renderDrawer();
  $("drawerBack").classList.add("show"); $("drawer").classList.add("open"); $("drawer").setAttribute("aria-hidden", "false");
  navPush("drawer");
}
function closeDrawerNow() { $("drawerBack").classList.remove("show"); $("drawer").classList.remove("open"); $("drawer").setAttribute("aria-hidden", "true"); }
function closeDrawer() { if (!drawerIsOpen()) return; closeDrawerNow(); navPop("drawer"); }
function renderDrawer() {
  const d = $("drawer"), me = S.me; d.textContent = "";
  const go = fn => () => {                              // sahifa ochilganda menyu animatsiyasiz yopiladi — sahifa ostida ko'rinib qolmasin
    const dr = $("drawer"), bk = $("drawerBack"); dr.classList.add("snap"); bk.classList.add("snap");
    closeDrawer();
    setTimeout(() => { fn(); setTimeout(() => { dr.classList.remove("snap"); bk.classList.remove("snap"); }, 80); }, 0);
  };
  const item = (ic, text, fn) => h("button", {class: "dw-i", type: "button", onclick: go(fn)}, icon(ic), h("span", {text}));
  const dark = document.documentElement.dataset.theme === "dark";
  const sw = h("span", {class: "sw-t", role: "switch", "aria-checked": String(dark)});
  const night = h("button", {class: "dw-i", type: "button", onclick: () => { toggleTheme(); sw.setAttribute("aria-checked", String(document.documentElement.dataset.theme === "dark")); }},
    icon("moon"), h("span", {text: "Tungi rejim"}), sw);
  d.append(
    h("div", {class: "dw-head"}, avatar(me, "l"), h("div", {class: "dw-name"}, nameEl(me, {big: true})), h("div", {class: "dw-user", text: "@" + me.username})),
    h("div", {class: "dw-list"},
      item("user", "Mening profilim", () => openProfile(me.id)),
      item("group", "Foydalanuvchilar", openUsersPage),
      item("gear", "Sozlamalar", openSettingsPage),
      ...(amAdmin() ? [item("shield", "Admin sozlamalari", openAdminHome)] : []),
      night,
      item("lock", "Shifrlash: server nimani ko'radi?", () => openInspector("server"))),
    h("div", {class: "dw-foot", text: APP_NAME}));
}
$("menuBtn").addEventListener("click", e => { e.stopPropagation(); openDrawer(); });
$("drawerBack").addEventListener("click", closeDrawer);
(() => {                                           // chapga surib yopish
  let x0 = null, y0 = 0;
  const d = $("drawer");
  d.addEventListener("touchstart", e => { const t = e.touches[0]; x0 = t.clientX; y0 = t.clientY; }, {passive: true});
  d.addEventListener("touchend", e => { if (x0 == null) return; const t = e.changedTouches[0], dx = t.clientX - x0, dy = Math.abs(t.clientY - y0); x0 = null; if (dx < -60 && dy < 60) closeDrawer(); }, {passive: true});
})();

/* ---------------- umumiy qismlar ---------------- */
function switchRow(ic, text, getOn, onSet, hint) {
  const sw = h("span", {class: "sw-t", role: "switch", "aria-checked": String(!!getOn())});
  const row = h("button", {class: "set-row", type: "button", "aria-label": text}, icon(ic), h("span", {text}), sw);
  const sync = () => sw.setAttribute("aria-checked", String(!!getOn()));
  row.addEventListener("click", async () => { try { await onSet(!getOn()); } catch (err) { toast(err.message, "error"); } sync(); });
  return hint ? h("div", {}, row, h("p", {class: "tg-hint", text: hint})) : row;
}
const setRow = (ic, text, fn, val, danger) => h("button", {class: "set-row" + (danger ? " danger" : ""), type: "button", onclick: fn}, icon(ic), h("span", {text}), val ? h("span", {class: "sv", text: val}) : null);
const gapEl = () => h("div", {class: "tg-gap"});
const secTitle = (text, n) => h("div", {class: "sec-t"}, h("span", {text}), n == null ? null : h("b", {text: String(n)}));
function fmtDay(ts) {
  const d = new Date(ts * 1000), n = new Date();
  const same = d.getFullYear() === n.getFullYear() && d.getMonth() === n.getMonth() && d.getDate() === n.getDate();
  return (same ? "Bugun" : d.getDate() + "-" + MONTHS[d.getMonth()] + (d.getFullYear() !== n.getFullYear() ? " " + d.getFullYear() : "")) + ", " + hhmm(ts);
}

/* Foydalanuvchilar: qidiruv + ro'yxat. Hevorix (ega) doim birinchi, so'ng adminlar, so'ng oddiy foydalanuvchilar. */
function usersBlock() {
  let filter = "";
  const el = h("div", {class: "ublock"});
  const title = h("div", {class: "sec-t"});
  const search = h("input", {type: "text", class: "gsearch", placeholder: "Foydalanuvchilarni qidirish", autocomplete: "off", autocapitalize: "none", spellcheck: "false", "aria-label": "Foydalanuvchilarni qidirish"});
  const list = h("div", {class: "mlist"});
  const rank = u => u.role === "owner" ? 0 : u.role === "admin" ? 1 : 2;
  const fill = () => {
    list.textContent = "";
    const q = filter.trim().toLowerCase();
    const all = S.members.map(m => U(m.id)).filter(u => !u.deleted);
    const shown = all.filter(u => !q || (u.nickname || "").toLowerCase().includes(q) || (u.username || "").toLowerCase().includes(q))
      .sort((a, b) => (rank(a) - rank(b)) || ((isOnline(b.id) ? 1 : 0) - (isOnline(a.id) ? 1 : 0)) || (a.nickname || "").localeCompare(b.nickname || ""));
    title.textContent = ""; title.append(h("span", {text: "Foydalanuvchilar"}), h("b", {text: String(all.length)}));
    shown.forEach(u => list.append(itemEl({
      av: avatar(u, "m", true), title: [nameEl(u), u.id === S.me.id ? h("span", {class: "i-time", text: "(siz)"}) : null],
      sub: (isStaff(u) ? roleLabel(u.role) + " • " : "") + statusText(u), subOn: isOnline(u.id),
      onclick: () => openProfile(u.id),
    })));
    if (!shown.length) list.append(h("div", {class: "none", text: "Hech narsa topilmadi"}));
  };
  search.addEventListener("input", () => { filter = search.value; fill(); });
  fill();
  el.append(title, search, list);
  return {el, fill};
}
function openUsersPage() { openPage(p => { const ub = usersBlock(); p.refresh = ub.fill; return h("div", {}, pageHead("Foydalanuvchilar"), ub.el); }); }

/* Media sonlari: faqat qurilmaga yuklangan xabarlar bo'yicha (xabarlar E2EE — server sanay olmaydi). */
function mediaCounts(list, more) {
  const st = {img: 0, video: 0, file: 0, audio: 0, voice: 0, more: !!more};
  (list || []).forEach(m => {
    if (m.deleted) return;
    if (m.image) { st.img++; return; }
    const f = m.file; if (!f) return;
    const mime = f.mime || "";
    if (f.voice) st.voice++;
    else if (f.vnote || /^video\//.test(mime)) st.video++;
    else if (/^audio\//.test(mime)) st.audio++;
    else if (/^image\//.test(mime)) st.img++;
    else st.file++;
  });
  return st;
}
function mediaRows(st) {
  const plus = st.more ? "+" : "";
  const row = (ic, n, label) => h("div", {class: "tg-row"}, icon(ic), h("span", {text: n + plus + " " + label}));
  return h("div", {class: "tg-media"}, row("attach", st.img, "ta rasm"), row("videocam", st.video, "ta video"), row("file", st.file, "ta fayl"),
    row("headphones", st.audio, "ta audio fayl"), row("mic", st.voice, "ta ovozli xabar"));
}
/* Guruh va kanal profili: avatar, nom, rasm/video/fayl/audio/ovozli xabar sonlari va (kerak bo'lsa) foydalanuvchilar ro'yxati. */
function infoPage(o) {
  return openPage(p => {
    const wrap = h("div", {});
    const subEl = h("div", {class: "pstat", text: o.sub()});
    const media = h("div", {});
    const paintMedia = () => { const m = o.msgs(); media.textContent = ""; media.append(mediaRows(mediaCounts(m.list, m.more))); };
    paintMedia();
    wrap.append(pageHead(o.title),
      h("div", {class: "tg-top"}, o.av(), h("div", {class: "pname"}, h("span", {text: o.name})), subEl));
    if (o.rows && o.rows.length) wrap.append(h("div", {class: "tg-info"}, ...o.rows));
    wrap.append(gapEl(), media,
      h("p", {class: "tg-hint", text: "Sonlar shu qurilmaga yuklangan xabarlar bo'yicha (xabarlar shifrlangan, server sanay olmaydi). \"+\" — tepada yana eski xabarlar bor."}));
    let ub = null;
    if (o.users) { ub = usersBlock(); wrap.append(gapEl(), ub.el); }
    if (o.foot && o.foot.length) wrap.append(gapEl(), h("div", {class: "tg-modwrap"}, ...o.foot));
    p.refresh = () => { subEl.textContent = o.sub(); paintMedia(); if (ub) ub.fill(); };
    return wrap;
  }, false);
}
function openGroupInfo() {
  infoPage({
    title: "Guruh ma'lumoti", name: "Umumiy chat", av: () => groupAvatar("l"),
    sub: () => (S.members.length || 1) + " a'zo, " + onlineCount() + " onlayn",
    msgs: () => ({list: S.group.msgs, more: S.group.more}), users: true,
    foot: amAdmin() ? [h("button", {class: "btn danger sm", type: "button", onclick: () => { closeAllPages(); clearGroupChat(); }}, "Chatni tozalash")] : [],
  });
}

