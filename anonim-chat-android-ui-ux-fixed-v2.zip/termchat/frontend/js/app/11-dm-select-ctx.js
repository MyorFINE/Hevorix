/* ---------------- Shaxsiy suhbat menyusi / suhbatni o'chirish ---------------- */
function openMenu(x, y, items, sheet) {
  S.ctxAt = Date.now();
  const ctx = $("ctx"); ctx.textContent = "";
  items.forEach(it => {
    const b = h("button", {class: "dd-i", type: "button", onclick: () => { closeCtx(); it.fn(); }}, icon(it.ic), it.text);
    if (it.danger) b.style.color = "var(--err)";
    ctx.append(b);
  });
  showCtx(ctx, x, y, false);                       // telefonda ham pastdan chiqadigan qora varaq emas: bosilgan joy yonida oyna ustida chiqadigan menyu
}
function showCtx(ctx, x, y, asSheet) {              // telefonda: pastdan chiqadigan varaq; kompyuterda: kursor yonida
  ctx.classList.remove("hidden");
  ctx.classList.toggle("as-sheet", asSheet);
  $("ctxBack").classList.toggle("hidden", !asSheet);
  if (isMobile()) navPush("ctx");
  const w = ctx.offsetWidth, hgt = ctx.offsetHeight;
  ctx.style.left = Math.max(8, Math.min(x, innerWidth - w - 8)) + "px";
  ctx.style.top = Math.max(8, Math.min(y, innerHeight - hgt - 8)) + "px";
}
function dmMenu(x, y, uid, sheet) {
  openMenu(x, y, [
    {ic: "user", text: "Profilni ko'rish", fn: () => openProfile(uid)},
    {ic: "trash", text: "Suhbatni o'chirish", danger: true, fn: () => deleteDmChat(uid)},
  ], sheet);
}
$("chMore").addEventListener("click", e => {
  e.stopPropagation();
  if (!S.active || S.active.kind === "group") return;
  const r = $("chMore").getBoundingClientRect();
  if (S.active.kind === "channel") Channels.menu(r.right - 220, r.bottom + 4, S.active.id);
  else dmMenu(r.right - 200, r.bottom + 4, S.active.uid);
});
async function deleteDmChat(uid) {
  const u = U(uid);
  const ok = await confirmDlg("Bu suhbat (" + u.nickname + " bilan) ikkala tomon uchun ham butunlay o'chiriladi: xabarlar va rasmlar ikkalangizdan ham yo'qoladi. Buni qaytarib bo'lmaydi.",
    {title: "Suhbatni o'chirish", okText: "O'chirish", danger: true});
  if (ok) wsSend({type: "delete_dm", with: uid});
}

/* ---------------- Belgilash rejimi: ko'p xabarni birdaniga o'chirish ---------------- */
let renderQueued = false;
function scheduleRender() {                       // ketma-ket o'chirishlarda bir kadrda bir marta chizish
  if (renderQueued) return; renderQueued = true;
  requestAnimationFrame(() => { renderQueued = false; renderMessages(false); renderList(); });
}
function enterSelect(firstId) {
  if (!S.active) return;
  cancelEdit(); cancelReply();
  S.sel = new Set(); if (firstId != null) S.sel.add(firstId);
  $("chat").classList.add("selecting"); navPush("sel");
  renderMessages(false); updateSelBar();
}
function exitSelect() {
  if (!S.sel) return;
  S.sel = null; $("chat").classList.remove("selecting"); navPop("sel");
  renderMessages(false);
}
function toggleSel(m, row) {
  if (!S.sel || !canDelete(m)) return;
  if (S.sel.has(m.id)) S.sel.delete(m.id); else S.sel.add(m.id);
  if (row) row.classList.toggle("selected", S.sel.has(m.id));
  updateSelBar();
}
function updateSelBar() {
  if (!S.sel) return;
  $("selCount").textContent = String(S.sel.size);
  $("selDel").disabled = !S.sel.size;
  const all = currentMsgs().filter(x => !x.service && canDelete(x));
  $("selAll").textContent = all.length && all.every(x => S.sel.has(x.id)) ? "Bekor" : "Hammasi";
}
$("selCancel").addEventListener("click", exitSelect);
$("selAll").addEventListener("click", () => {
  if (!S.sel) return;
  const all = currentMsgs().filter(x => !x.service && canDelete(x));
  if (all.length && all.every(x => S.sel.has(x.id))) S.sel.clear(); else all.forEach(x => S.sel.add(x.id));
  document.querySelectorAll("#msgs .row[data-id]").forEach(r => r.classList.toggle("selected", S.sel.has(Number(r.dataset.id))));
  updateSelBar();
});
$("selDel").addEventListener("click", async () => {
  if (!S.sel || !S.sel.size) return;
  const ids = [...S.sel], n = ids.length;
  const ok = await confirmDlg(n + " ta xabar o'chirilsinmi?", {title: "Xabarlarni o'chirish", okText: "O'chirish", danger: true});
  if (!ok || !S.sel) return;
  for (let i = 0; i < ids.length; i += 200) wsSend({type: "delete_many", ids: ids.slice(i, i + 200)});
  exitSelect();
});
async function clearGroupChat() {
  if (!amAdmin()) return;
  const ok = await confirmDlg("Umumiy chatdagi BARCHA xabarlar hamma uchun o'chiriladi. Buni qaytarib bo'lmaydi.",
    {title: "Chatni tozalash", okText: "Tozalash", danger: true});
  if (ok) wsSend({type: "clear_chat"});
}

/* ---------------- kontekst menyu ---------------- */
function canDelete(m) {
  if (m.ch) return amAdmin();                         // kanal postini istalgan admin o'chira oladi
  if (m.user.id === S.me.id) return true;
  if (m.to != null || !amAdmin()) return false;
  const t = U(m.user.id);
  return t.role === "user" || (t.role === "admin" && S.me.role === "owner");
}
function openCtx(x, y, m) {
  S.ctxAt = Date.now();
  const ctx = $("ctx"); ctx.textContent = ""; ctx._anchorB = null; ctx.style.top = "";
  const add = (ic, text, fn, danger) => {
    const b = h("button", {class: "dd-i", type: "button", onclick: () => { closeCtx(); fn(); }}, icon(ic), text);
    if (danger) b.style.color = "var(--err)";
    ctx.append(b);
  };
  const usable = !m.locked && !m.bad;
  const chan = !!m.ch;
  if (canReact(m)) ctx.append(rxPicker(m));
  if (chan) add("chat", "Izohlar", () => Channels.openComments(m));
  if (usable && !m.legacy && !chan) add("reply", "Javob berish", () => startReply(m));
  if (m.content && usable) add("copy", "Nusxalash", () => copyText(m.content));
  if (usable && canPin(m)) { const pd = isPinned(m); add(pd ? "unpin" : "pin", pd ? "Unpin qilish" : "Pin qilish", () => togglePin(m)); }
  if (usable && (m.image || m.file)) add("save", "Saqlash (Save as)", () => saveAs(m));
  if (usable && !m.legacy && !m.service && (m.content || m.image || m.file)) add("forward", "Oldinga yuborish", () => forwardMessage(m));
  if (m.user.id !== S.me.id && !chan) add("user", "Profilni ko'rish", () => openProfile(m.user.id));
  if (m.user.id !== S.me.id && m.to == null && !m.service && !chan) add("flag", "Shikoyat qilish", () => reportMessage(m));
  if (m.user.id === S.me.id && usable && !m.legacy) add("edit", "Tahrirlash", () => startEdit(m));
  if (canDelete(m)) add("select", "Belgilash", () => enterSelect(m.id));
  if (canDelete(m)) add("trash", "O'chirish", async () => { if (await confirmDlg("Bu xabar o'chirilsinmi?", {title: "Xabarni o'chirish", okText: "O'chirish", danger: true})) wsSend({type: "delete", id: m.id}); }, true);
  const row = document.querySelector('#msgs .row[data-id="' + Number(m.id) + '"]'); if (row) row.classList.add("ctx-on");
  showCtx(ctx, x, y, false);                       // bir marta bosish ham, uzoq bosish ham: pastdan varaq emas, xabar yonida oyna ustida chiqadigan menyu
}
function closeCtx() {
  const c = $("ctx"); if (c.classList.contains("hidden")) return;
  c.classList.add("hidden"); $("ctxBack").classList.add("hidden");
  document.querySelectorAll("#msgs .row.ctx-on").forEach(r => r.classList.remove("ctx-on"));
  navPop("ctx");
}

