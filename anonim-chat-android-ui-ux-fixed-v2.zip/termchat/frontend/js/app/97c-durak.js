// Durak (Gaming bo'limi). Stol atrofida 2–4 o'yinchi. Rejimlar: "bot" (qurilmada, botlar bilan, internet shart emas) va "online" (haqiqiy o'yinchilar, server tekshiradi).
// Qoidalar va bot: js/durak.js (window.TCDurak) — server bilan bir xil qoidalar.
const Durak = (() => {
  const SYM = {S: "♠", H: "♥", D: "♦", C: "♣"}, RL = {T: "10"};
  const BOTNAMES = ["Anvar", "Dilnoza", "Sardor", "Madina", "Jasur", "Nigora", "Bobur", "Zilola"];
  const REASON = {timeout: "vaqtida yurmadi", left: "stoldan chiqib ketdi", abandon: "aloqasi uzildi"};
  const snd = (n, ...a) => { try { Gaming.snd[n](...a); } catch (_) {} };
  const eng = () => window.TCDurak;
  const ckIcon = () => h("span", {class: "dk-ico"}, h("i", {"data-s": "♠"}), h("i", {"data-s": "♥"}));
  const D = {
    el: null, main: null, mode: null, sheet: null, v: null, names: [], me: 0, sel: null, lock: false, tbl: null, g: null, botT: 0, lockT: 0,
    inc: null, incTimer: 0, tick: 0, left: 0, leftAt: 0, overKey: null, overCard: null, prev: new Set(), note: "", invSent: new Set(),
  };
  const send = o => { if (wsTry(o)) return true; toast("Ulanish yo'q, biroz kutib qayta urinib ko'ring", "error"); return false; };
  const online = () => D.mode === "online" && !!D.tbl;
  const botGame = () => D.mode === "bot" && !!D.g;
  const red = c => c[1] === "H" || c[1] === "D";
  const cardName = c => (RL[c[0]] || c[0]) + SYM[c[1]];

  function cardEl(c, cls = "") {
    if (!c) return h("div", {class: "dkc back " + cls});
    return h("div", {class: "dkc " + (red(c) ? "r " : "") + cls, "data-c": c},
      h("span", {class: "dk-rk"}, RL[c[0]] || c[0], h("i", {text: SYM[c[1]]})), h("b", {class: "dk-su", text: SYM[c[1]]}));
  }
  function sortHand(hand, trump) {
    const E = eng(), key = c => (c[1] === trump ? 1 : 0) * 100 + "SHDC".indexOf(c[1]) * 10 + E.rank(c) / 10;
    return hand.slice().sort((a, b) => key(a) - key(b));
  }
  function viewOf(st, seat) {
    return {n: st.n, trump: st.trump, trumpCard: st.deck.length ? st.trumpCard : null, deck: st.deck.length, counts: st.hands.map(x => x.length), hand: st.hands[seat].slice(),
      table: st.table.map(p => p.slice()), att: st.att, dfn: st.dfn, turn: st.turn, phase: st.phase, cap: st.cap, discard: st.discard, out: st.out.slice(), finish: st.finish.slice(), legal: st.legal(seat), over: st.over};
  }
  const nameOf = seat => { const n = D.names[seat]; if (!n) return "?"; return n.bot ? n.name : U(n.uid).nickname; };

  // ---------- ekran ----------
  function openScreen() {
    if (D.el) return;
    const root = h("div", {id: "dk", class: "gm dk"});
    D.main = h("div", {class: "gm-main"});
    root.append(
      h("div", {class: "gm-top"}, h("b", {class: "gm-ttl", text: "Durak"}), h("span", {class: "gm-sp"}),
        h("button", {class: "gm-x", type: "button", "aria-label": "Ovoz", onclick: ev => {
          const on = !Gaming.sndOn(); try { localStorage.setItem("tc_gsnd", on ? "on" : "off"); } catch (_) {}
          ev.currentTarget.textContent = on ? "🔊" : "🔇"; if (on) snd("start");
        }}, Gaming.sndOn() ? "🔊" : "🔇"),
        h("button", {class: "gm-x", type: "button", "aria-label": "Yopish", onclick: () => closeScreen()}, "✕")),
      D.main);
    document.body.append(root); D.el = root;
    navPush("dk");
    render();
    if (!D.tick) D.tick = setInterval(tickClocks, 500);
    if (botGame()) scheduleBot();
  }
  function closeScreen() {
    if (!D.el) return;
    clearTimeout(D.botT); closeSheet(); D.el.remove(); D.el = null; D.main = null; D.overCard = null;
    if (botGame() && D.g.st.over) { D.g = null; D.mode = null; D.v = null; }
    navPop("dk"); clearInterval(D.tick); D.tick = 0;
    if (S.tab === "games") renderList();
  }
  function render() {
    if (!D.el) return;
    D.sel = null;
    if (online()) { if (D.tbl.status === "lobby") renderLobby(); else renderGame(); }
    else if (botGame()) renderGame();
    else renderMenu();
  }
  function menuItem(ico, title, sub, fn) {
    return h("button", {class: "gm-mi", type: "button", onclick: fn},
      h("span", {class: "gm-mic", text: ico}), h("span", {class: "gm-mt"}, h("b", {text: title}), h("small", {text: sub})), h("span", {class: "gm-mgo", text: "›"}));
  }
  function renderMenu() {
    D.main.textContent = "";
    const off = !!S.offline;
    const head = h("div", {class: "gm-mh"}, h("div", {class: "gm-mart dk-art"}, ckIcon()), h("b", {text: "Durak"}), h("small", {text: off ? "Internet yo'q — faqat botlar bilan o'ynash mumkin" : "Stol atrofida 2–4 kishi • kozer • podkidnoy"}));
    D.main.append(h("div", {class: "gm-menu"}, head,
      off ? null : menuItem("🃏", "Stol ochish", "Do'stlarni taklif qiling (2–4 kishi) • ochko beriladi • har bir yurishga 60 soniya", () => { if (send({type: "dk_create"})) snd("tick"); }),
      menuItem("🤖", "Botlar bilan o'ynash", "1–3 bot • internet shart emas • ochko bermaydi", openBotSheet),
      off ? null : menuItem("🏆", "Score board", "Faqat haqiqiy o'yinchilar o'rtasidagi o'yinlar", openScore),
      h("button", {class: "gm-ml", type: "button", onclick: openRules}, "ℹ️ Qoidalar")));
    if (off) return;
    const stats = h("div", {class: "gm-mst"});
    api("/games/durak/scoreboard").then(j => {
      const me = j.me, k = me.wins + me.losses + me.draws;
      stats.append(h("span", {class: "gm-chip", text: k ? "🏆 " + me.points + " ochko" : "Hali o'ynalmagan — birinchi bo'ling!"}));
      if (k) stats.append(h("span", {class: "gm-chip", text: me.rank ? "# " + me.rank + " o'rin" : "— o'rin"}), h("span", {class: "gm-chip", text: me.wins + " / " + me.losses + " / " + me.draws}));
      if (head && head.isConnected) head.append(stats);
    }).catch(() => {});
  }

  // ---------- o'yin maydoni ----------
  function status() {
    const v = D.v;
    if (v.over) return "O'yin tugadi";
    if (v.out[D.me]) return "Siz o'yindan chiqdingiz ✓ — oxirigacha kuzating";
    const t = v.turn, empty = !v.table.length;
    if (t === D.me) return t === v.dfn ? "Sizning navbatingiz: uring yoki «Olaman» deng" : empty ? "Siz yuring — hujum kartasini tashlang" : v.phase === "take" ? "Raqib oladi — xohlasangiz qo'shib tashlang" : "Qo'shib tashlang yoki «Bito» deng";
    const nm = nameOf(t);
    return t === v.dfn ? nm + (v.phase === "take" ? " oladi…" : " himoyalanmoqda…") : empty ? nm + " yurmoqda…" : nm + " qo'shib tashlashi mumkin…";
  }
  function oppEl(seat) {
    const v = D.v, n = D.names[seat] || {}, cnt = v.counts[seat];
    const av = n.bot ? h("div", {class: "gm-botav", text: "🤖"}) : avatar(U(n.uid), "m", true);
    const fan = h("div", {class: "dk-fan"});
    for (let i = 0; i < Math.min(cnt, 6); i++) fan.append(cardEl(null));
    const el = h("div", {class: "dk-opp" + (v.turn === seat && !v.over ? " turn" : "") + (v.out[seat] ? " out" : "")},
      av, h("div", {class: "dk-on"}, n.bot ? n.name : nameEl(U(n.uid))), fan,
      h("div", {class: "dk-cnt", text: v.out[seat] ? "chiqdi ✓" : cnt + " karta"}),
      online() && D.tbl.base && D.tbl.base[n.uid] != null ? h("div", {class: "dk-cnt", title: "Jami ochko", text: "🏆 " + D.tbl.base[n.uid]}) : null);
    if (!v.over && !v.out[seat]) {
      if (seat === v.dfn) el.append(h("span", {class: "dk-role", title: "Himoyachi", text: "🛡"}));
      else if (seat === v.att) el.append(h("span", {class: "dk-role", title: "Hujumchi", text: "⚔"}));
    }
    if (online() && !v.over && v.turn === seat) el.append(h("span", {class: "dk-clk", "data-clk": "1", text: "…"}));
    if (online() && D.tbl.gone && D.tbl.gone.includes(n.uid)) el.append(h("div", {class: "dk-cnt", text: "(chiqib ketgan)"}));
    return el;
  }
  function renderGame() {
    const v = D.v; if (!v || !D.main) return;
    D.main.textContent = "";
    const myTurn = v.turn === D.me && !v.over, L = v.legal || {cards: [], def: {}};
    const opps = h("div", {class: "dk-opps"});
    for (let k = 1; k < v.n; k++) opps.append(oppEl((D.me + k) % v.n));
    const deck = h("div", {class: "dk-deck"});
    if (v.trumpCard) deck.append(cardEl(v.trumpCard, "trc"));
    if (v.deck > 0) deck.append(cardEl(null));
    const pile = h("div", {class: "dk-pile"}, deck,
      h("div", {class: "dk-dn", text: v.deck > 0 ? "Kolodada: " + v.deck : "Koloda tugadi"}),
      h("div", {class: "dk-ts" + (red(v.trump + v.trump) ? " r" : ""), title: "Kozer", text: SYM[v.trump]}),
      h("div", {class: "dk-ds", text: "Kozer • chiqqan: " + v.discard}));
    const tbl = h("div", {class: "dk-tbl"}), keys = new Set();
    if (!v.table.length) tbl.append(h("div", {class: "dk-none", text: "Stol bo'sh"}));
    const defTargets = myTurn && D.sel && L.def ? (L.def[D.sel] || []) : [];
    v.table.forEach((p, i) => {
      const ka = "a" + p[0], kd = p[1] ? "d" + p[1] : null; keys.add(ka); if (kd) keys.add(kd);
      const pair = h("div", {class: "dk-pair" + (defTargets.includes(i) ? " tg" : "")},
        cardEl(p[0], D.prev.has(ka) ? "" : "pop"), p[1] ? cardEl(p[1], "def" + (D.prev.has(kd) ? "" : " pop")) : null);
      if (defTargets.includes(i)) pair.addEventListener("click", () => { const c = D.sel; D.sel = null; doAct({t: "def", c, i}); });
      tbl.append(pair);
    });
    if (D.prev.size !== keys.size || [...keys].some(k => !D.prev.has(k))) { if (keys.size > D.prev.size) snd("move", false, false, {}); }
    D.prev = keys;
    const hand = h("div", {class: "dk-hand"});
    sortHand(v.hand, v.trump).forEach(c => {
      const ok = myTurn && L.cards.includes(c);
      const el = cardEl(c, (myTurn ? (ok ? "ok" : "no") : "") + (D.sel === c ? " sel" : ""));
      el.addEventListener("click", () => onCard(c, el));
      hand.append(el);
    });
    const act = h("div", {class: "dk-act"});
    if (myTurn && L.take) act.append(h("button", {class: "btn ghost", type: "button", text: "🙌 Olaman", onclick: () => doAct({t: "take"})}));
    if (myTurn && L.pass) act.append(h("button", {class: "btn", type: "button", text: v.phase === "take" ? "Pas" : "✔ Bito", onclick: () => doAct({t: "pass"})}));
    act.append(h("button", {class: "gm-resign", type: "button", onclick: leaveAsk}, online() ? "🏳 Taslim" : "☰ Chiqish"));
    const me = h("div", {class: "dk-me"},
      h("span", {class: "dk-role", style: "position:static", text: v.out[D.me] ? "✓" : D.me === v.dfn ? "🛡" : D.me === v.att ? "⚔" : "🃏"}),
      online() && myTurn ? h("span", {class: "dk-clk", "data-clk": "1", text: "…"}) : null);
    D.main.append(h("div", {class: "dk-wrap"}, opps, h("div", {class: "dk-mid"}, pile, tbl),
      h("div", {class: "dk-note"}, status(), D.note ? h("small", {text: D.note}) : null), me, hand, act));
    tickClocks();
  }
  function onCard(c, el) {
    const v = D.v; if (!v || v.over) return;
    const myTurn = v.turn === D.me, L = v.legal || {cards: [], def: {}};
    if (!myTurn || D.lock) { if (!myTurn) toast("Hozir navbat sizda emas", "info"); return; }
    if (!L.cards.includes(c)) {
      el.classList.remove("shake"); void el.offsetWidth; el.classList.add("shake");
      toast(D.me === v.dfn ? "Bu karta bilan urib bo'lmaydi" : v.table.length ? "Stoldagi darajalardan biriga teng karta tashlang" : "Bu kartani tashlab bo'lmaydi", "warn"); return;
    }
    if (D.me === v.dfn) {
      const idx = L.def[c] || [];
      if (idx.length === 1) { doAct({t: "def", c, i: idx[0]}); return; }
      D.sel = D.sel === c ? null : c; renderGame(); return;
    }
    doAct({t: "atk", c});
  }
  function doAct(a) {
    if (D.lock) return;
    if (online()) {
      if (!send({type: "dk_act", a})) return;
      D.lock = true; clearTimeout(D.lockT); D.lockT = setTimeout(() => { if (D.lock) { D.lock = false; wsTry({type: "dk_sync"}); } }, 2500);
      snd("move", true, false, {});
    } else if (botGame()) offAct(D.me, a);
  }
  function tickClocks() {
    if (!D.el || !online() || !D.tbl || D.tbl.status !== "playing") return;
    const ms = D.left - (performance.now() - D.leftAt), sec = Math.max(0, Math.ceil(ms / 1000));
    D.el.querySelectorAll("[data-clk]").forEach(e => { e.textContent = sec + " s"; e.classList.toggle("low", sec <= 10); });
  }

  // ---------- botlar bilan (oflayn) ----------
  function startBot(nBots) {
    if (!eng()) { toast("Durak dvigateli yuklanmadi. Sahifani yangilang (bir marta internet kerak).", "error"); return; }
    if (online()) { toast("Avval joriy stoldan chiqing", "warn"); return; }
    clearTimeout(D.botT); closeSheet(); removeOverCard();
    const st = new (eng().State)(nBots + 1), pool = BOTNAMES.slice().sort(() => Math.random() - 0.5);
    D.g = {st, nBots}; D.mode = "bot"; D.me = 0; D.note = ""; D.prev = new Set(); D.lock = false;
    D.names = [{uid: S.me.id}].concat(Array.from({length: nBots}, (_, i) => ({bot: true, name: pool[i]})));
    D.v = viewOf(st, 0);
    if (!D.el) openScreen(); else render();
    snd("start"); haptic([40, 40, 40]);
    scheduleBot();
  }
  function offAct(seat, a) {
    const st = D.g && D.g.st; if (!st) return;
    let info;
    try { info = st.act(seat, a); } catch (err) { toast(err.message || "Noqonuniy harakat", "error"); return; }
    const nm = seat === D.me ? "Siz" : nameOf(seat);
    D.note = info.t === "atk" ? nm + ": " + cardName(info.c) + " bilan yurdi" : info.t === "def" ? nm + ": " + cardName(info.c) + " bilan urdi" : info.t === "take" ? nm + " oladi" : nm + ": " + (st.phase === "take" ? "pas" : "bito");
    if (info.t === "take") snd("tick");
    D.v = viewOf(st, D.me);
    if (D.el) renderGame();
    if (st.over) { finishBot(); return; }
    scheduleBot();
  }
  function scheduleBot() {
    clearTimeout(D.botT);
    const st = D.g && D.g.st; if (!st || st.over || !D.el || st.turn === D.me) return;
    D.botT = setTimeout(() => {
      if (!D.g || D.g.st !== st || st.over || st.turn === D.me) return;
      offAct(st.turn, eng().botAct(st, st.turn));
    }, st.out[D.me] ? 250 : 650 + Math.random() * 650);
  }
  function finishBot() {
    const st = D.g.st, loser = st.over.loser;
    setTimeout(() => { if (D.g && D.g.st === st) showOverCard({loser, order: st.finish, bot: true, again: () => startBot(D.g ? D.g.nBots : 1), close: () => { D.g = null; D.mode = null; D.v = null; if (D.el) render(); }}); }, 600);
  }
  function leaveAsk() {
    if (botGame()) {
      const st = D.g.st;
      if (st.over) { D.g = null; D.mode = null; D.v = null; render(); return; }
      confirmDlg("O'yin tugatiladi va siz durak hisoblanasiz. Chiqasizmi?", {title: "Chiqish", okText: "Chiqish", danger: true}).then(ok => {
        if (!ok || !D.g || D.g.st !== st) return;
        clearTimeout(D.botT); D.g = null; D.mode = null; D.v = null; removeOverCard(); render();
      });
      return;
    }
    if (!online()) return;
    const playing = D.tbl.status === "playing";
    confirmDlg(playing ? "Chiqsangiz o'yin tugaydi va siz durak hisoblanasiz. Chiqasizmi?" : "Stoldan chiqasizmi?", {title: "Chiqish", okText: "Chiqish", danger: playing}).then(ok => { if (ok) send({type: "dk_leave"}); });
  }

  // ---------- natija ----------
  function removeOverCard() { if (D.overCard) { D.overCard.remove(); D.overCard = null; } }
  function showOverCard({loser, order, again, close, extra, pts, total, rated, bot}) {
    if (!D.el) return;
    removeOverCard();
    const lose = loser === D.me, draw = loser === null || loser === undefined;
    const names = (order || []).map((s, i) => (i + 1) + ". " + nameOf(s));
    const card = h("div", {class: "gm-over"}, h("div", {class: "go-card"},
      h("div", {class: "go-t", text: draw ? "🤝 Durang" : lose ? "🃏 Siz durak bo'ldingiz" : "🏆 Siz durak emassiz!"}),
      h("div", {class: "go-r", text: draw ? "Hamma kartalarini birdan tugatdi" : "Durak: " + (lose ? "siz" : nameOf(loser)) + (extra ? " — " + extra : "")}),
      names.length ? h("div", {class: "dk-res"}, names.map(t => h("div", {text: t}))) : null,
      pts == null ? (bot ? h("div", {class: "go-nr", text: "Bot bilan o'yin — ochko berilmaydi va Score boardga yozilmaydi."}) : null)
        : h("div", {class: "go-pts " + (pts > 0 ? "up" : pts < 0 ? "dn" : ""), text: (pts > 0 ? "+" : pts < 0 ? "−" : "") + Math.abs(pts) + " ochko"}),
      pts != null && !rated && !draw ? h("div", {class: "go-nr", text: "Ochko berilmadi: o'yin juda qisqa edi yoki bu o'yinchilar bilan bugun juda ko'p o'ynalgan."}) : null,
      pts != null ? h("div", {class: "go-tot", text: "Jami: " + total + " ochko"}) : null,
      h("div", {class: "go-b"},
        again ? h("button", {class: "btn", type: "button", text: "🔁 Yana o'ynash", onclick: () => { removeOverCard(); again(); }}) : null,
        h("button", {class: "btn ghost", type: "button", text: online() ? "Stoldan chiqish" : "Yopish", onclick: () => { removeOverCard(); close(); }}))));
    D.el.append(card); D.overCard = card;
    haptic(!lose && !draw ? [60, 40, 120] : 40);
    setTimeout(() => snd(draw ? "draw" : lose ? "lose" : "win"), 350);
  }

  // ---------- online stol ----------
  function onState(m) {
    const first = !D.tbl || D.tbl.tid !== m.tid;
    if (botGame()) { clearTimeout(D.botT); D.g = null; }
    D.mode = "online"; D.tbl = m; D.lock = false; clearTimeout(D.lockT); D.left = m.left || 0; D.leftAt = performance.now();
    if (first) { hideInvite(); closeSheet(); D.prev = new Set(); D.note = ""; D.overKey = null; }
    if (!D.el) openScreen();
    if (m.status === "lobby") { D.v = null; D.overKey = null; removeOverCard(); renderLobby(); }
    else {
      D.me = m.me; D.names = m.seats.map(uid => ({uid})); D.v = m.game;
      if (m.status === "playing" && D.overKey) { D.overKey = null; removeOverCard(); D.prev = new Set(); }
      D.sel = null; renderGame();
      if (m.status === "over") showOnlineOver(m);
    }
    if (D.sheet && D.sheet.kind === "invite") { if (m.status !== "lobby") closeSheet(); else if (D.sheet.redraw) D.sheet.redraw(); }
    if (first) { snd("start"); haptic([40, 40, 40]); }
    if (S.tab === "games") renderList();
  }
  function showOnlineOver(m) {
    const key = m.tid + ":" + (m.result ? m.result.reason + ":" + m.result.loser + ":" + m.result.order.join(",") : "");
    if (D.overKey === key || !D.el) return;
    D.overKey = key;
    const r = m.result || {}, seatOf = uid => m.seats.indexOf(uid);
    const loserSeat = r.loser == null ? null : seatOf(r.loser);
    const host = m.host === S.me.id, active = m.seats.filter(u => !(m.gone || []).includes(u)).length;
    const me = String(S.me.id);
    setTimeout(() => showOverCard({loser: loserSeat, order: (r.order || []).map(seatOf), extra: REASON[r.reason] || "", pts: r.pts ? r.pts[me] || 0 : 0, total: r.total ? r.total[me] || 0 : 0, rated: !!r.rated,
      again: host && active >= 2 ? () => send({type: "dk_start"}) : null, close: () => send({type: "dk_leave"})}), 700);
  }
  function renderLobby() {
    const t = D.tbl; D.main.textContent = "";
    const host = t.host === S.me.id, box = h("div", {class: "dk-lobby"});
    box.append(h("div", {class: "dk-cap", text: "🃏 Durak stoli • " + t.seats.length + " / " + t.max}));
    t.seats.forEach(uid => {
      const u = U(uid);
      box.append(h("div", {class: "dk-seat"}, avatar(u, "m", true), h("div", {class: "gm-un"}, nameEl(u), h("small", {text: uid === t.host ? "👑 stol egasi" : "o'tirdi ✓"}))));
    });
    t.pending.forEach(uid => {
      const u = U(uid);
      box.append(h("div", {class: "dk-seat"}, avatar(u, "m", true), h("div", {class: "gm-un"}, nameEl(u), h("small", {text: "taklif yuborildi — javob kutilmoqda…"})),
        host ? h("button", {class: "btn sm ghost", type: "button", text: "✕", "aria-label": "Taklifni bekor qilish", onclick: () => send({type: "dk_uninvite", to: uid})}) : null));
    });
    for (let i = t.seats.length + t.pending.length; i < t.max; i++) box.append(h("div", {class: "dk-seat free", text: "bo'sh o'rin"}));
    if (host) {
      if (t.seats.length + t.pending.length < t.max) box.append(h("button", {class: "btn ghost", type: "button", text: "➕ Do'st taklif qilish", onclick: openInvite}));
      box.append(h("button", {class: "btn", type: "button", disabled: t.seats.length < t.min, text: t.seats.length < t.min ? "Kamida 2 kishi kerak" : "▶ O'yinni boshlash", onclick: () => send({type: "dk_start"})}));
    } else box.append(h("p", {class: "gm-note", text: "Stol egasi o'yinni boshlashini kuting…"}));
    box.append(h("button", {class: "gm-ml", type: "button", onclick: leaveAsk}, "Stoldan chiqish"));
    D.main.append(box);
  }
  function openInvite() {
    const t = D.tbl; if (!t) return;
    const list = h("div", {class: "gm-list"});
    const q = h("input", {class: "gm-q", type: "search", placeholder: "Foydalanuvchini qidirish", autocomplete: "off", autocapitalize: "none", spellcheck: "false"});
    const draw = () => {
      list.textContent = "";
      const s = q.value.trim().toLowerCase(), cur = D.tbl || t;
      const all = S.members.filter(m => m.id !== S.me.id && !m.deleted && !cur.seats.includes(m.id)).map(m => U(m.id))
        .filter(u => !s || u.nickname.toLowerCase().includes(s) || u.username.toLowerCase().includes(s)).sort((a, b) => a.nickname.localeCompare(b.nickname));
      const on = all.filter(u => isOnline(u.id)), off = all.filter(u => !isOnline(u.id));
      const row = (u, isOn) => {
        const sent = cur.pending.includes(u.id);
        return h("div", {class: "gm-u"}, avatar(u, "m", true), h("div", {class: "gm-un"}, nameEl(u), h("small", {text: isOn ? "onlayn" : "oflayn • bildirishnoma yuboriladi"})),
          h("button", {class: "btn sm" + (isOn && !sent ? "" : " ghost"), type: "button", disabled: sent, text: sent ? "Yuborildi" : "Taklif", onclick: () => { if (send({type: "dk_invite", to: u.id})) setTimeout(draw, 300); }}));
      };
      if (on.length) { list.append(h("div", {class: "sect", text: "Onlayn — " + on.length})); on.forEach(u => list.append(row(u, true))); }
      if (off.length) { list.append(h("div", {class: "sect", text: "Oflayn"})); off.forEach(u => list.append(row(u, false))); }
      if (!all.length) list.append(h("div", {class: "none", text: "Hech kim topilmadi"}));
    };
    q.addEventListener("input", draw); draw();
    openSheet("➕ Durakka taklif", h("div", {}, q, list), {kind: "invite", redraw: draw});
  }
  function hideInvite() { clearTimeout(D.incTimer); if (D.inc) { D.inc.el.remove(); D.inc = null; } }
  function showInvite(m) {
    hideInvite();
    const u = U(m.frm), ttl = Math.max(1, m.ttl || 60) * 1000, bar = h("i"); bar.style.animationDuration = ttl + "ms";
    const answer = ok => { send({type: "dk_reply", id: m.id, accept: ok}); hideInvite(); };
    const el = h("div", {class: "gm-inv", role: "alertdialog", "aria-label": "Durak taklifi"}, avatar(u, "m"),
      h("div", {class: "gm-ivt"}, h("b", {text: "Durakka taklif"}), h("span", {}, nameEl(u), " sizni stolga taklif qildi")),
      h("div", {class: "gm-ivb"}, h("button", {class: "btn sm", type: "button", text: "Qabul qilish", onclick: () => answer(true)}), h("button", {class: "btn sm ghost", type: "button", text: "Rad etish", onclick: () => answer(false)})),
      h("div", {class: "gm-bar"}, bar));
    document.body.append(el); D.inc = {id: m.id, el}; haptic([70, 50, 70]);
    D.incTimer = setTimeout(hideInvite, ttl + 400);
  }
  function inviteEnd(m) {
    if (D.inc && D.inc.id === m.id) hideInvite();
    if (m.frm === S.me.id && D.tbl) {
      const nm = U(m.to).nickname, t = {declined: nm + " taklifni rad etdi", expired: nm + " javob bermadi", busy: nm + " hozir band"}[m.status];
      if (t) toast(t, "warn");
    }
  }
  function onClosed(m) {
    if (D.tbl && D.tbl.tid !== m.tid) return;
    D.tbl = null; D.v = null; D.overKey = null; if (D.mode === "online") D.mode = null; removeOverCard(); closeSheet(); D.lock = false;
    if (m.reason === "host_left") toast("Stol egasi chiqib ketdi — stol yopildi", "warn");
    else if (m.reason === "idle") toast("Stol uzoq vaqt bo'sh turgani uchun yopildi", "info");
    if (D.el) render();
    if (S.tab === "games") renderList();
  }

  // ---------- varaqlar ----------
  function closeSheet() { if (D.sheet) { D.sheet.el.remove(); D.sheet = null; } }
  function openSheet(title, body, opts = {}) {
    if (!D.el) openScreen();
    closeSheet();
    const back = h("div", {class: "gm-sheet", onclick: e => { if (e.target === back) closeSheet(); }});
    back.append(h("div", {class: "gm-panel"}, h("div", {class: "gm-ph"}, h("b", {text: title}), h("button", {class: "gm-x", type: "button", "aria-label": "Yopish", onclick: closeSheet}, "✕")), body));
    D.el.append(back); D.sheet = {el: back, kind: opts.kind || "", redraw: opts.redraw};
  }
  function openBotSheet() {
    if (online()) { toast("Avval joriy stoldan chiqing", "warn"); return; }
    let n = 1;
    const row = h("div", {class: "gm-sides"});
    const paint = () => {
      row.textContent = "";
      [[1, "👤", "1 bot", "ikkovlon (1×1)"], [2, "👥", "2 bot", "3 kishilik stol"], [3, "👨‍👩‍👦", "3 bot", "4 kishilik stol"]].forEach(([k, ic, nm, sub]) =>
        row.append(h("button", {type: "button", class: "gm-sd" + (k === n ? " on" : ""), "aria-pressed": String(k === n), onclick: () => { n = k; paint(); }}, h("span", {text: ic}), h("b", {text: nm}), h("small", {text: sub}))));
    };
    paint();
    openSheet("🤖 Botlar bilan durak", h("div", {class: "oc-menu"}, h("div", {class: "oc-sec", text: "Nechta bot bilan o'ynaysiz?"}), row,
      h("button", {class: "btn oc-go", type: "button", text: "▶ O'yinni boshlash", onclick: () => startBot(n)}),
      h("p", {class: "gm-note oc-foot", text: "Botlar kozerni saqlab turadi: faqat boshqa karta bilan ura olmasa yoki kolodada karta tugaganda ishlatadi. Bot bilan o'yin ochko bermaydi."})), {kind: "bot"});
  }
  async function openScore() {
    const body = h("div", {class: "gm-score"}, h("div", {class: "none", text: "Yuklanmoqda…"}));
    openSheet("🏆 Durak — Score board", body, {kind: "score"});
    try {
      const j = await api("/games/durak/scoreboard");
      if (!D.sheet || D.sheet.kind !== "score") return;
      body.textContent = "";
      const me = j.me;
      body.append(h("div", {class: "gs-me"},
        h("div", {}, h("b", {text: String(me.points)}), h("small", {text: "ochko"})),
        h("div", {}, h("b", {text: me.rank ? "#" + me.rank : "—"}), h("small", {text: "o'rin"})),
        h("div", {}, h("b", {text: me.wins + " / " + me.losses + " / " + me.draws}), h("small", {text: "yutuq / durak / durang"}))));
      if (!j.top.length) body.append(h("div", {class: "none", text: "Hali o'yin bo'lmagan. Birinchi bo'ling!"}));
      j.top.forEach((r, n) => {
        const u = U(r.uid), medal = ["🥇", "🥈", "🥉"][n] || String(n + 1);
        body.append(h("div", {class: "gs-row" + (r.uid === S.me.id ? " me" : "")},
          h("span", {class: "gs-n", text: medal}), avatar(u, "s"), h("div", {class: "gs-u"}, nameEl(u), h("small", {text: r.wins + " yutuq • " + r.losses + " durak • " + r.draws + " durang"})),
          h("b", {class: "gs-p", text: String(r.points)})));
      });
    } catch (err) { if (D.sheet && D.sheet.kind === "score") { body.textContent = ""; body.append(h("div", {class: "none", text: err.message})); } }
  }
  function openRules() {
    const li = (ico, t) => h("div", {class: "gm-rl"}, h("span", {text: ico}), h("div", {text: t}));
    openSheet("ℹ️ Durak qoidalari", h("div", {class: "gm-rules"},
      li("🃏", "36 ta karta (6 dan A gacha). Har kimga 6 tadan. Kolodaning ostki kartasi — kozer; uning mastidagi kartalar boshqa mastlarni uradi."),
      li("⚔", "Hujumchi karta tashlaydi. Himoyachi uni shu mastning kattaroq kartasi yoki kozer bilan uradi (kozerni faqat kattaroq kozer uradi). Urish uchun kartani bosing, bir nechta nishon bo'lsa — kerakli juftni bosing."),
      li("➕", "Hujumchilar (soat strelkasi bo'yicha) stoldagi darajalardan biriga teng kartalarni qo'shib tashlashi mumkin. Stolda ko'pi bilan 6 ta hujum kartasi va himoyachi qo'lidagidan ko'p emas."),
      li("🙌", "«Olaman» — urolmasangiz yoki xohlamasangiz: hujumchilar yana qo'shib tashlaydi, so'ng hamma karta sizga o'tadi va keyingi hujum sizdan keyingi o'yinchidan boshlanadi."),
      li("✔", "«Bito» — hamma uringan va hech kim qo'shmasa: kartalar chiqib ketadi, himoyachi navbatdagi hujumchi bo'ladi."),
      li("📥", "Har bir roundan keyin hujumchidan boshlab hamma 6 tagacha karta oladi."),
      li("🏁", "Kolodada karta qolmagach, kartasi tugagan o'yinchi chiqadi. Oxirgi kartasi qolgan — durak!"),
      li("⏱", "Online stolda 2–4 kishi; har bir yurishga 60 soniya, o'tkazib yuborgan yoki chiqib ketgan o'yinchi durak bo'ladi. Stolni ochgan kishi do'stlarini taklif qiladi."),
      li("🏆", "Online o'yinda durak bo'lgan −10 ochko oladi; birinchi chiqqan +10 (3 kishida 2-chiqqan +5, 4 kishida +6 va +3). Kimdir vaqtida yurmasa yoki chiqib ketsa, qolganlarga teng ochko (2 kishida +10, 3 kishida +5, 4 kishida +4) beriladi. Durangda o'zgarmaydi. Juda qisqa o'yinlar va bir xil o'yinchilar bilan kuniga 5 tadan ortiq o'yin ochko bermaydi."),
      li("🤖", "Botlar kozerni saqlab turadi va faqat boshqacha urib bo'lmasa ishlatadi. Bot bilan o'yin ochko bermaydi.")), {kind: "rules"});
  }

  // ---------- tashqi interfeys ----------
  function onWs(m) {
    switch (m.type) {
      case "dk_invite": showInvite(m); snd("invite"); break;
      case "dk_invite_end": inviteEnd(m); break;
      case "dk_state": onState(m); break;
      case "dk_closed": onClosed(m); break;
    }
  }
  function tabList(list) {
    const live = online() && D.tbl.status !== "lobby" ? D.tbl.status === "playing" : false, lobby = online() && D.tbl.status === "lobby", bot = botGame() && !D.g.st.over;
    const n = S.offline ? 0 : S.members.filter(m => m.id !== S.me.id && !m.deleted && isOnline(m.id)).length;
    const sub = live ? "● O'yin davom etmoqda — qaytish" : lobby ? "● Stolingiz ochiq — qaytish" : bot ? "● Botlar bilan o'yin davom etmoqda" : S.offline ? "Oflayn: faqat botlar bilan o'ynash" : "Stol atrofida 2–4 kishi yoki botlar bilan";
    list.append(h("button", {class: "gcard dk-card", type: "button", onclick: openScreen},
      h("div", {class: "gc-art"}, ckIcon()),
      h("div", {class: "gc-t"}, h("b", {text: "Durak"}), h("small", {class: live || lobby || bot ? "live" : "", text: sub})),
      h("span", {class: "gc-on", text: S.offline ? "oflayn" : n + " onlayn"})));
  }
  function openFromPush() {
    S.tab = "games";
    document.querySelectorAll(".tabs button").forEach(x => x.classList.toggle("on", x.dataset.tab === "games"));
    renderList(); openScreen();
  }
  function reset() {
    hideInvite(); closeScreen(); clearTimeout(D.botT);
    D.g = null; D.tbl = null; D.v = null; D.mode = null; D.overKey = null; D.prev = new Set();
  }
  NAV_CLOSE.dk = () => closeScreen();
  return {tabList, onWs, openFromPush, reset, sync: () => wsTry({type: "dk_sync"})};
})();
