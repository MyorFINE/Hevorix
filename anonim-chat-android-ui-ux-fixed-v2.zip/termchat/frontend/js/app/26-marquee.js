/* ---------------- Uzun nickname: "…" bilan qisqaradi, ustiga borilganda sekin siljiydi ---------------- */
(function () {
  let cur = null, raf = 0, timer = 0;
  const HOST = ".item, .pname, .hinfo, .bname, .rq";
  function stop() {
    cancelAnimationFrame(raf); clearTimeout(timer);
    if (cur) { cur.scrollLeft = 0; cur.style.textOverflow = ""; cur.classList.remove("scrolling"); }
    cur = null;
  }
  function start(nt) {
    const max = nt.scrollWidth - nt.clientWidth;
    if (max <= 2) return;
    cur = nt; nt.style.textOverflow = "clip"; nt.classList.add("scrolling");
    const SPEED = 45;                       // px/soniya
    const run = (dir, from) => {
      const t0 = performance.now();
      const step = now => {
        if (cur !== nt) return;
        const d = Math.min(1, (now - t0) / ((max / SPEED) * 1000));
        nt.scrollLeft = dir > 0 ? max * d : max * (1 - d);
        if (d < 1) raf = requestAnimationFrame(step);
        else timer = setTimeout(() => { if (cur === nt) run(-dir); }, 700);
      };
      raf = requestAnimationFrame(step);
    };
    timer = setTimeout(() => { if (cur === nt) run(1); }, 350);
  }
  document.addEventListener("mouseover", e => {
    const host = e.target.closest && e.target.closest(HOST);
    const nt = host && host.querySelector(".nm .nt");
    if (nt === cur) return;
    stop();
    if (nt) start(nt);
  });
  document.addEventListener("mouseleave", stop);
  document.addEventListener("scroll", stop, true);
})();
