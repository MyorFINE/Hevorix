/* ---------------- chat oynasi ---------------- */
function currentMsgs() {
  if (!S.active) return [];
  if (S.active.kind === "channel") return chOf(S.active.id).msgs;
  return S.active.kind === "group" ? S.group.msgs : dmOf(S.active.uid).msgs;
}
async function openChat(target) {
  if (S.sel) { S.sel = null; $("chat").classList.remove("selecting"); navPop("sel"); }
  Channels.closeComments(false);
  S.active = target; S.win = WIN0;
  cancelRecording(); cancelEdit(); cancelReply(); clearPendingImage(); $("inp").value = ""; autosize(); S.away = 0; bumpAway(true);
  $("empty").classList.add("hidden"); $("chat").classList.remove("hidden");
  document.body.classList.add("in-chat");
  if (isMobile()) navPush("chat");
  if (target.kind === "group") S.group.unread = 0;
  else if (target.kind === "channel") {
    const st = chOf(target.id); st.unread = 0;
    if (!st.loaded) {
      renderHeader(); $("msgs").textContent = "";
      try { await loadChannelPosts(target.id); } catch (err) { toast(err.message, "error"); }
      if (!isActiveChan(target.id)) return;
    }
  } else {
    const dm = dmOf(target.uid); dm.unread = 0;
    if (!dm.loaded) {
      renderHeader(); $("msgs").textContent = "";
      try { await loadDm(target.uid); } catch (err) { toast(err.message, "error"); }
      if (!isActiveDm(target.uid)) return;
    }
    wsSend({type: "read", with: target.uid});
  }
  renderHeader(); renderMessages(true); renderList();
  autosize();
  if (!isMobile()) $("inp").focus();
  Composer.guard(); requestAnimationFrame(Composer.guard); setTimeout(Composer.guard, 350); setTimeout(Composer.guard, 1200);
}
function closeChat() {
  Channels.closeComments(false);
  if (S.sel) { S.sel = null; $("chat").classList.remove("selecting"); navPop("sel"); }
  S.active = null; cancelEdit(); cancelReply(); clearPendingImage();
  document.body.classList.remove("in-chat"); navPop("chat");
  if (!isMobile()) { $("chat").classList.add("hidden"); $("empty").classList.remove("hidden"); }
  renderList();
}
function renderHeader() {
  if (!S.active || !S.me) return;
  const av = $("hav"), title = $("htitle"), sub = $("hsub");
  av.textContent = ""; title.textContent = ""; sub.className = "hsub";
  if (S.active.kind === "group") {
    av.append(groupAvatar("m")); title.append(h("span", {class: "nt", text: "Umumiy chat"}));
    sub.textContent = (S.members.length || 1) + " a'zo, " + onlineCount() + " onlayn" + (S.chat.locked ? " • 🔒 qulflangan" : S.chat.slowmode ? " • 🐢 " + S.chat.slowmode + " s" : "") + (X.epoch && !X.rooms.has(X.epoch) ? " • ⏳ kalit kutilmoqda" : "");
  } else if (S.active.kind === "channel") {
    const c = chInfo(S.active.id);
    av.append(chanAvatar(c || {id: S.active.id, nickname: "?"}, "m"));
    title.append(h("span", {class: "nt", text: c ? c.nickname : "Kanal"})); if (c && c.private) title.append(icon("lock", "ic ch-lock"));
    sub.textContent = c ? "@" + c.username + " • " + c.posts + " post" + (c.private ? " • shaxsiy" : "") + (c.can_manage && c.private ? " • " + (c.members || 0) + " a'zo" : "") : "";
  } else {
    const u = U(S.active.uid);
    av.append(avatar(u, "m", true)); title.append(nameEl(u));
    sub.textContent = statusText(u) + (X.changed.has(u.id) ? " • ⚠ kalit o'zgargan" : ""); if (isOnline(u.id)) sub.classList.add("on");
  }
  $("chMore").classList.toggle("hidden", S.active.kind === "group");
  const g = syncChatGate();
  inp.placeholder = S.active.kind === "channel" ? "Kanalga post yozing…" : "Xabar yozing…";
  if (g.chanRO || g.locked || g.dead) { cancelEdit(); cancelReply(); clearPendingImage(); }
}
/* Yozish paneli holati (readonly / dead / locked) faqat HAQIQIY holatdan hisoblanadi — eskirgan klass qolib ketmaydi */
function syncChatGate() {
  const c = $("chat"), a = S.active;
  const chanRO = !!a && a.kind === "channel" && !amAdmin();           // oddiy a'zo kanalga yozolmaydi (faqat o'qiydi va izoh qoldiradi)
  const dead = !!a && a.kind === "dm" && !!(U(a.uid) || {}).deleted;
  const locked = !!a && a.kind === "group" && !!S.chat.locked && !amAdmin();
  c.classList.toggle("readonly", chanRO); c.classList.toggle("dead", dead); c.classList.toggle("locked", locked);
  return {chanRO, dead, locked};
}
$("hinfo").addEventListener("click", () => {
  if (!S.active) return;
  if (S.active.kind === "group") openGroupInfo(); else if (S.active.kind === "channel") Channels.info(S.active.id); else openProfile(S.active.uid);
});
$("backBtn").addEventListener("click", closeChat);

function bumpAway(reset) {
  if (reset) S.away = 0; else S.away++;
  const tb = $("tbBadge");
  tb.textContent = String(S.away); tb.classList.toggle("hidden", !S.away);
}
const WIN0 = 80;                                    // ekranda bir vaqtda ko'pi bilan shuncha xabar (eskilari tepaga chiqilganda qo'shiladi)
function msgFlags(list, k) {                        // xabar guruhining boshi/oxiri (avatar va masofa uchun)
  const c = list[k], p = list[k - 1], n = list[k + 1], d = dayKey(c.ts);
  return [!p || p.service || p.user.id !== c.user.id || dayKey(p.ts) !== d || c.ts - p.ts > 300,
          !n || n.service || n.user.id !== c.user.id || dayKey(n.ts) !== d || n.ts - c.ts > 300];
}
function renderMessages(stick) {
  if (!S.active || !S.me) return;
  const box = $("msgs"), prevTop = box.scrollTop;
  const all = currentMsgs(), isGroup = S.active.kind === "group", chan = S.active.kind === "channel";
  const hiddenN = Math.max(0, all.length - (S.win || WIN0)), list = hiddenN ? all.slice(hiddenN) : all;
  box.textContent = "";
  let prev = null, lastDay = "";
  const pg = isGroup ? S.group : chan ? chOf(S.active.id) : dmOf(S.active.uid);
  if (pg.more || hiddenN) box.append(h("button", {class: "older", type: "button", text: "⬆ Oldingi xabarlar", onclick: loadOlder}));
  if (!list.length) box.append(h("div", {class: "blank", text: chan ? "Kanalda hali post yo'q" : isGroup ? "Hozircha xabar yo'q. Birinchi bo'lib yozing 👋" : "Suhbatni boshlang — xabar yozing 👋"}));
  list.forEach((m, i) => {
    if (m.service) { box.append(h("div", {class: "svc", text: m.text})); prev = null; return; }
    const day = dayKey(m.ts);
    if (day !== lastDay) { box.append(h("div", {class: "day", text: dayLabel(m.ts)})); lastDay = day; prev = null; }
    const next = list[i + 1];
    const first = !prev || prev.user.id !== m.user.id || m.ts - prev.ts > 300;
    const last = !next || next.service || next.user.id !== m.user.id || dayKey(next.ts) !== day || next.ts - m.ts > 300;
    box.append(bubbleRow(m, isGroup, chan || first, chan || last, chan));
    prev = m;
  });
  box._stick = !!stick; box._n = list.length;
  if (chan) Channels.track(box, S.active.id);
  if (stick) { box.scrollTop = box.scrollHeight; bumpAway(true); } else box.scrollTop = prevTop;
  toggleToBottom();
  if ((pg.more || hiddenN) && !S.olderBusy && box.scrollHeight <= box.clientHeight + 60) setTimeout(loadOlder, 0);   // ekran to'lmasa tepaga chiqib bo'lmaydi: o'zi yuklaydi
}
function appendMessage(m, stick) {                 // tez yo'l: bitta qator qo'shiladi (rasmlar qayta yuklanmaydi, qotmaydi)
  const box = $("msgs"), list = currentMsgs(), i = list.length - 1;
  if (!S.active || !S.me || S.sel || list[i] !== m || box.querySelector(".blank")) return renderMessages(stick);
  if (stick && (box._n || 0) >= 220) { S.win = WIN0; return renderMessages(true); }      // DOM juda o'sib ketmasin
  const isG = S.active.kind === "group", chan = S.active.kind === "channel", prevM = list[i - 1];
  let prevRow = null;
  if (prevM && !prevM.service) {
    prevRow = box.querySelector('.row[data-id="' + Number(prevM.id) + '"]');
    if (!prevRow || prevRow !== box.lastElementChild) return renderMessages(stick);
  } else if (prevM && prevM.service && !(box.lastElementChild && box.lastElementChild.classList.contains("svc"))) return renderMessages(stick);
  else if (!prevM && box.lastElementChild && !box.lastElementChild.classList.contains("older")) return renderMessages(stick);
  if (m.service) box.append(h("div", {class: "svc", text: m.text}));
  else {
    let j = i - 1; while (j >= 0 && list[j].service) j--;
    if (j < 0 || dayKey(list[j].ts) !== dayKey(m.ts)) box.append(h("div", {class: "day", text: dayLabel(m.ts)}));
    if (prevRow && !chan) {                                          // oldingi qator endi «oxirgi» emas bo'lishi mumkin (avatar ko'chadi)
      const [pf, pl] = msgFlags(list, i - 1);
      if (pl !== prevRow.classList.contains("last")) prevRow.replaceWith(bubbleRow(prevM, isG, pf, pl));
    }
    const [f, l] = chan ? [true, true] : msgFlags(list, i), row = bubbleRow(m, isG, f, l, chan);
    row.classList.add("enter"); box.append(row);
    fxPlay(row);                                                     // xabar effekti: faqat yangi xabar paydo bo'lganda, bir marta
    setTimeout(() => row.classList.remove("enter"), 450);
  }
  box._n = (box._n || 0) + 1; box._stick = !!stick;
  if (chan) Channels.track(box, S.active.id);
  if (stick) { box.scrollTop = box.scrollHeight; bumpAway(true); }
  toggleToBottom();
}
function replyQuote(r, by) {                              // `by` — reply yozgan odam: iqtibos qutisi UNING tanlagan uslubida
  const gone = !!r.deleted, rk = by && !gone ? fxOf(by, "reply") : null;
  const q = h("div", {class: "rq" + (gone ? " gone" : "") + (rk ? " fxr-" + rk : ""), role: "button"},
    h("b", {text: gone ? "Xabar" : r.nickname}),
    h("span", {text: gone ? "O'chirilgan xabar" : (r.image ? "📷 " : r.file ? (r.voice ? "🎤 " : r.vnote ? "📹 " : "📎 ") : "") + (r.text || (r.image ? "Rasm" : r.file ? (r.file_name || "Fayl") : ""))}));
  q.addEventListener("click", e => { e.stopPropagation(); if (!gone) jumpTo(r.id); });
  return q;
}
function jumpTo(id) {
  const box = $("msgs"), row = box.querySelector('.row[data-id="' + Number(id) + '"]');
  if (!row) { toast("Bu xabar yuklangan tarixda yo'q (eski)", "warn"); return; }
  box._stick = false;
  row.scrollIntoView({block: "center", behavior: "smooth"});
  row.classList.remove("flash"); void row.offsetWidth; row.classList.add("flash");
  setTimeout(() => row.classList.remove("flash"), 1400);
}

