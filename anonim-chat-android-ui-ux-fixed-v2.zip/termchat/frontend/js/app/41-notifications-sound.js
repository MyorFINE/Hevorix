async function askNotifications() {
  if (!S.token || !Push.shouldAsk()) return;
  Push.markAsked();
  const ok = await confirmDlg("Brauzer yopiq bo'lsa ham umumiy chatga yoki lichkangizga yozishsa, darhol xabar olasiz. Xabar matni bildirishnomada ko'rsatilmaydi.",
    {title: "Bildirishnomalarni yoqamizmi?", okText: "Yoqish"});
  if (!ok || !S.token) return;
  try { await Push.enable(api); toast("Bildirishnomalar yoqildi", "ok"); } catch (err) { toast(err.message, "error"); }
}
function applyPendingChannel() { const p = S.pendingOpen; if (p && p.k === "c") { S.pendingOpen = null; Channels.openById(p.u); } }
function openFromNotification(k, u) {
  if (!S.token || !S.me) { S.pendingOpen = {k, u}; return; }
  if (k === "c") { Channels.openById(u); return; }
  if (k === "x") { Gaming.openFromPush(); return; }
  if (k === "y") { Checkers.openFromPush(); return; }
  if (k === "d" && u && u !== S.me.id) { if (S.users.has(u)) openChat({kind: "dm", uid: u}); else { S.pendingOpen = {k, u}; loadMembers().then(applyPendingOpen); } }
  else openChat({kind: "group"});
}
function applyPendingOpen() {
  const p = S.pendingOpen; if (!p) return;
  if (p.k === "d" && !S.users.has(p.u)) return;
  S.pendingOpen = null; openFromNotification(p.k, p.u);
}
window.addEventListener("ac-open-chat", e => openFromNotification(e.detail.k, e.detail.u));
try {
  const o = new URLSearchParams(location.search).get("o");
  if (o) {
    if (o === "g") S.pendingOpen = {k: "g"};
    else if (/^d\d{1,9}$/.test(o)) S.pendingOpen = {k: "d", u: parseInt(o.slice(1), 10)};
    else if (/^c\d{1,9}$/.test(o)) S.pendingOpen = {k: "c", u: parseInt(o.slice(1), 10)};
    else if (o === "x") S.pendingOpen = {k: "x"};
    else if (o === "y") S.pendingOpen = {k: "y"};
    history.replaceState(null, "", "/");
  }
} catch (_) {}
async function logout() {
  try { await Promise.race([Push.onLogout(api), delay(3000)]); } catch (_) {}
  try { await SC.fetch("/api/logout", {method: "POST", headers: {Authorization: "Bearer " + S.token}}); } catch (_) {}
  await Off.wipe();
  showAuth("");
}

const LS_SND = "ac_sound";
const LS_MUTED = "ac_muted_dm";
const mutedDm = (() => { try { return new Set(JSON.parse(localStorage.getItem(LS_MUTED) || "[]").filter(Number.isInteger)); } catch (_) { return new Set(); } })();
const isMuted = uid => mutedDm.has(uid);
function toggleMute(uid) {
  if (!mutedDm.delete(uid)) mutedDm.add(uid);
  try { localStorage.setItem(LS_MUTED, JSON.stringify([...mutedDm])); } catch (_) {}
  return mutedDm.has(uid);
}
const sndOn = () => { try { return localStorage.getItem(LS_SND) !== "off"; } catch (_) { return true; } };
let actx = null, lastTing = 0;
const audioCtx = () => { if (!actx) { const C = window.AudioContext || window.webkitAudioContext; if (C) { try { actx = new C(); } catch (_) {} } } return actx; };
["pointerdown", "keydown", "touchstart"].forEach(ev => addEventListener(ev, () => { const c = audioCtx(); if (c && c.state === "suspended") c.resume().catch(() => {}); }, {passive: true, capture: true}));
function ting(force) {
  if (!force && !sndOn()) return;
  const c = audioCtx(); if (!c || c.state !== "running") return;
  const t = c.currentTime;
  [[988, 0], [1480, 0.11]].forEach(([f, d]) => {
    const o = c.createOscillator(), g = c.createGain();
    o.type = "sine"; o.frequency.value = f;
    g.gain.setValueAtTime(0.0001, t + d); g.gain.exponentialRampToValueAtTime(0.28, t + d + 0.012); g.gain.exponentialRampToValueAtTime(0.0001, t + d + 0.42);
    o.connect(g); g.connect(c.destination); o.start(t + d); o.stop(t + d + 0.45);
  });
}
function pingSound(viewing) {
  if (viewing && !document.hidden) return;
  const n = Date.now(); if (n - lastTing < 700) return; lastTing = n;
  ting();
}

document.addEventListener("visibilitychange", () => { if (!document.hidden) { try { if (navigator.clearAppBadge) navigator.clearAppBadge(); } catch (_) {} } });

function toggleTheme() {
  const t = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
  document.documentElement.dataset.theme = t;
  const mc = document.querySelector('meta[name="theme-color"]'); if (mc) mc.setAttribute("content", t === "dark" ? "#17212b" : "#ffffff");
  try { localStorage.setItem(LS_THEME, t); } catch (_) {}
}

function sendPresence() {
  const ws = S.ws; if (ws && ws.readyState === 1) ws.send(JSON.stringify({type: document.hidden && !isOwnerMe() ? "away" : "back"}));
}
