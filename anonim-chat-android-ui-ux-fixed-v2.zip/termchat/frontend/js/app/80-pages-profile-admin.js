const PG = {list: []};
const PG_MS = 320;
function pageHead(title, right) {
  return h("div", {class: "pg-head"},
    h("button", {class: "icon-btn", type: "button", onclick: () => closePage(), "aria-label": "Orqaga"}, icon("back")),
    h("span", {class: "pg-title", text: title}), right || null);
}
function paintPage(p) {
  const top = p.el.scrollTop;
  p.refresh = null;
  p.el.textContent = "";
  p.el.append(p.build(p));
  p.el.scrollTop = top;
}
function openPage(build, live) {
  const layer = $("pages");
  const p = {el: h("section", {class: "pg tgp"}), build, live: !!live, at: performance.now(), name: "pg" + PG.list.length, refresh: null, closing: false};
  paintPage(p);
  const prev = PG.list[PG.list.length - 1]; if (prev) prev.el.classList.add("under");
  PG.list.push(p);
  layer.classList.add("on"); layer.append(p.el);
  navPush(p.name);
  void p.el.offsetWidth;
  requestAnimationFrame(() => p.el.classList.add("in"));
  return p;
}
function closePage() {
  const p = PG.list.pop(); if (!p) return;
  const prev = PG.list[PG.list.length - 1]; if (prev) prev.el.classList.remove("under");
  p.closing = true; p.el.classList.remove("in");
  setTimeout(() => { p.el.remove(); if (!PG.list.length) $("pages").classList.remove("on"); }, PG_MS);
  navPop(p.name);
}
function closeAllPages() { while (PG.list.length) closePage(); }
function resetPages() { if (AVV.el) { AVV.el.remove(); AVV.el = null; AVV.closing = false; } PG.list.forEach(p => p.el.remove()); PG.list.length = 0; $("pages").classList.remove("on"); closeDrawerNow(); }
let _rpTimer = 0;
function refreshPages() {
  if (_rpTimer || !PG.list.some(p => p.live || p.refresh)) return;
  const at = Math.max(...PG.list.map(p => p.at));
  _rpTimer = setTimeout(() => {
    _rpTimer = 0;
    requestAnimationFrame(() => PG.list.slice().forEach(p => { if (p.closing) return; if (p.refresh) p.refresh(); else if (p.live) paintPage(p); }));
  }, Math.max(150, 450 - (performance.now() - at)));
}
function repaintTopPage() { const p = PG.list[PG.list.length - 1]; if (p) paintPage(p); }
$("pages").addEventListener("click", e => { if (e.target === $("pages")) closeAllPages(); });

const drawerIsOpen = () => $("drawer").classList.contains("open");
function openDrawer() {
  if (drawerIsOpen()) return;
  renderDrawer();
  $("drawerBack").classList.add("show"); $("drawer").classList.add("open"); $("drawer").setAttribute("aria-hidden", "false");
  navPush("drawer");
}
function closeDrawerNow() { $("drawerBack").classList.remove("show"); $("drawer").classList.remove("open"); $("drawer").setAttribute("aria-hidden", "true"); }
function closeDrawer() { if (!drawerIsOpen()) return; closeDrawerNow(); navPop("drawer"); }
function renderDrawer() {
  const d = $("drawer"), me = S.me; d.textContent = "";
  const go = fn => () => {
    const dr = $("drawer"), bk = $("drawerBack"); dr.classList.add("snap"); bk.classList.add("snap");
    closeDrawer();
    setTimeout(() => { fn(); setTimeout(() => { dr.classList.remove("snap"); bk.classList.remove("snap"); }, 80); }, 0);
  };
  const item = (ic, text, fn) => h("button", {class: "dw-i", type: "button", onclick: go(fn)}, icon(ic), h("span", {text}));
  const dark = document.documentElement.dataset.theme === "dark";
  const sw = h("span", {class: "sw-t", role: "switch", "aria-checked": String(dark)});
  const night = h("button", {class: "dw-i", type: "button", onclick: () => { toggleTheme(); sw.setAttribute("aria-checked", String(document.documentElement.dataset.theme === "dark")); }},
    icon("moon"), h("span", {text: "Tungi rejim"}), sw);
  d.append(
    h("div", {class: "dw-head"}, avatar(me, "l"), h("div", {class: "dw-name"}, nameEl(me, {big: true})), h("div", {class: "dw-user", text: "@" + me.username})),
    h("div", {class: "dw-list"},
      item("user", "Mening profilim", () => openProfile(me.id)),
      item("group", "Foydalanuvchilar", openUsersPage),
      item("gear", "Sozlamalar", openSettingsPage),
      ...(amAdmin() ? [item("shield", "Admin sozlamalari", openAdminHome)] : []),
      night,
      item("lock", "Shifrlash: server nimani ko'radi?", () => openInspector("server"))),
    h("div", {class: "dw-foot", text: APP_NAME}));
}
$("menuBtn").addEventListener("click", e => { e.stopPropagation(); openDrawer(); });
$("drawerBack").addEventListener("click", closeDrawer);
(() => {
  let x0 = null, y0 = 0;
  const d = $("drawer");
  d.addEventListener("touchstart", e => { const t = e.touches[0]; x0 = t.clientX; y0 = t.clientY; }, {passive: true});
  d.addEventListener("touchend", e => { if (x0 == null) return; const t = e.changedTouches[0], dx = t.clientX - x0, dy = Math.abs(t.clientY - y0); x0 = null; if (dx < -60 && dy < 60) closeDrawer(); }, {passive: true});
})();

function switchRow(ic, text, getOn, onSet, hint) {
  const sw = h("span", {class: "sw-t", role: "switch", "aria-checked": String(!!getOn())});
  const row = h("button", {class: "set-row", type: "button", "aria-label": text}, icon(ic), h("span", {text}), sw);
  const sync = () => sw.setAttribute("aria-checked", String(!!getOn()));
  row.addEventListener("click", async () => { try { await onSet(!getOn()); } catch (err) { toast(err.message, "error"); } sync(); });
  return hint ? h("div", {}, row, h("p", {class: "tg-hint", text: hint})) : row;
}
const setRow = (ic, text, fn, val, danger) => h("button", {class: "set-row" + (danger ? " danger" : ""), type: "button", onclick: fn}, icon(ic), h("span", {text}), val ? h("span", {class: "sv", text: val}) : null);
const gapEl = () => h("div", {class: "tg-gap"});
const secTitle = (text, n) => h("div", {class: "sec-t"}, h("span", {text}), n == null ? null : h("b", {text: String(n)}));
function fmtDay(ts) {
  const d = new Date(ts * 1000), n = new Date();
  const same = d.getFullYear() === n.getFullYear() && d.getMonth() === n.getMonth() && d.getDate() === n.getDate();
  return (same ? "Bugun" : d.getDate() + "-" + MONTHS[d.getMonth()] + (d.getFullYear() !== n.getFullYear() ? " " + d.getFullYear() : "")) + ", " + hhmm(ts);
}

function usersBlock() {
  let filter = "";
  const el = h("div", {class: "ublock"});
  const title = h("div", {class: "sec-t"});
  const search = h("input", {type: "text", class: "gsearch", placeholder: "Foydalanuvchilarni qidirish", autocomplete: "off", autocapitalize: "none", spellcheck: "false", "aria-label": "Foydalanuvchilarni qidirish"});
  const list = h("div", {class: "mlist"});
  const rank = u => u.role === "owner" ? 0 : u.role === "admin" ? 1 : 2;
  const fill = () => {
    list.textContent = "";
    const q = filter.trim().toLowerCase();
    const all = S.members.map(m => U(m.id)).filter(u => !u.deleted);
    const shown = all.filter(u => !q || (u.nickname || "").toLowerCase().includes(q) || (u.username || "").toLowerCase().includes(q))
      .sort((a, b) => (rank(a) - rank(b)) || ((isOnline(b.id) ? 1 : 0) - (isOnline(a.id) ? 1 : 0)) || (a.nickname || "").localeCompare(b.nickname || ""));
    title.textContent = ""; title.append(h("span", {text: "Foydalanuvchilar"}), h("b", {text: String(all.length)}));
    shown.forEach(u => list.append(itemEl({
      av: avatar(u, "m", true), title: [nameEl(u), u.id === S.me.id ? h("span", {class: "i-time", text: "(siz)"}) : null],
      sub: (isStaff(u) ? roleLabel(u.role) + " • " : "") + statusText(u), subOn: isOnline(u.id),
      onclick: () => openProfile(u.id),
    })));
    if (!shown.length) list.append(h("div", {class: "none", text: "Hech narsa topilmadi"}));
  };
  search.addEventListener("input", () => { filter = search.value; fill(); });
  fill();
  el.append(title, search, list);
  return {el, fill};
}
function openUsersPage() { openPage(p => { const ub = usersBlock(); p.refresh = ub.fill; return h("div", {}, pageHead("Foydalanuvchilar"), ub.el); }); }

function mediaCounts(list, more) {
  const st = {img: 0, video: 0, file: 0, audio: 0, voice: 0, more: !!more};
  (list || []).forEach(m => {
    if (m.deleted) return;
    if (m.image) { st.img++; return; }
    const f = m.file; if (!f) return;
    const mime = f.mime || "";
    if (f.voice) st.voice++;
    else if (f.vnote || /^video\//.test(mime)) st.video++;
    else if (/^audio\//.test(mime)) st.audio++;
    else if (/^image\//.test(mime)) st.img++;
    else st.file++;
  });
  return st;
}
function mediaRows(st) {
  const plus = st.more ? "+" : "";
  const row = (ic, n, label) => h("div", {class: "tg-row"}, icon(ic), h("span", {text: n + plus + " " + label}));
  return h("div", {class: "tg-media"}, row("attach", st.img, "ta rasm"), row("videocam", st.video, "ta video"), row("file", st.file, "ta fayl"),
    row("headphones", st.audio, "ta audio fayl"), row("mic", st.voice, "ta ovozli xabar"));
}

function infoPage(o) {
  return openPage(p => {
    const wrap = h("div", {});
    const subEl = h("div", {class: "pstat", text: o.sub()});
    const media = h("div", {});
    const paintMedia = () => { const m = o.msgs(); media.textContent = ""; media.append(mediaRows(mediaCounts(m.list, m.more))); };
    paintMedia();
    wrap.append(pageHead(o.title),
      h("div", {class: "tg-top"}, o.av(), h("div", {class: "pname"}, h("span", {text: o.name})), subEl));
    if (o.rows && o.rows.length) wrap.append(h("div", {class: "tg-info"}, ...o.rows));
    wrap.append(gapEl(), media,
      h("p", {class: "tg-hint", text: "Sonlar shu qurilmaga yuklangan xabarlar bo'yicha (xabarlar shifrlangan, server sanay olmaydi). \"+\" — tepada yana eski xabarlar bor."}));
    let ub = null;
    if (o.users) { ub = usersBlock(); wrap.append(gapEl(), ub.el); }
    if (o.foot && o.foot.length) wrap.append(gapEl(), h("div", {class: "tg-modwrap"}, ...o.foot));
    p.refresh = () => { subEl.textContent = o.sub(); paintMedia(); if (ub) ub.fill(); };
    return wrap;
  }, false);
}
function openGroupInfo() {
  infoPage({
    title: "Guruh ma'lumoti", name: "Umumiy chat", av: () => groupAvatar("l"),
    sub: () => (S.members.length || 1) + " a'zo" + (S.offline ? "" : ", " + onlineCount() + " onlayn"),
    msgs: () => ({list: S.group.msgs, more: S.group.more}), users: true,
    foot: amAdmin() ? [h("button", {class: "btn danger sm", type: "button", onclick: () => { closeAllPages(); clearGroupChat(); }}, "Chatni tozalash")] : [],
  });
}

function openProfile(uid) {
  if (!S.users.has(uid)) loadMembers();
  openPage(() => profileView(uid), true);
}

function mediaStats(uid) {
  const dm = S.dms.get(uid);
  if (!dm || !dm.loaded) return null;
  const st = {img: 0, voice: 0, vnote: 0, file: 0, more: !!dm.more};
  dm.msgs.forEach(m => {
    if (m.deleted) return;
    if (m.image) st.img++;
    else if (m.file) { if (m.file.voice) st.voice++; else if (m.file.vnote) st.vnote++; else st.file++; }
  });
  return st;
}
function tgRow(ic, text) { return h("div", {class: "tg-row"}, icon(ic), h("span", {text})); }

function profileView(uid) {
  const u = U(uid), me = u.id === S.me.id;
  const wrap = h("div", {});
  if (u.deleted) {
    const bn = h("div", {class: "pbanner gone"});
    bn.append(h("button", {class: "pbtn l", type: "button", onclick: () => closePage(), "aria-label": "Orqaga"}, icon("back")));
    bn.append(h("button", {class: "pbtn r", type: "button", onclick: closeAllPages, "aria-label": "Yopish"}, icon("close")));
    wrap.append(bn, h("div", {class: "pbody"}, avatar(u, "l"),
      h("div", {class: "pname"}, nameEl(u, {big: true})),
      h("div", {class: "pstat", text: "Bu akkaunt o'chirilgan"}),
      h("div", {class: "gone-note", text: "Yozgan xabarlari chatda qoladi. Unga xabar yuborib bo'lmaydi."})));
    return wrap;
  }
  const top = tint(h("div", {class: "tg-top" + (isStaff(u) ? " prem " + u.role : "") + bannerCls(u) + pageCls(u)}), u);
  top.append(h("button", {class: "tg-back", type: "button", onclick: () => closePage(), "aria-label": "Orqaga"}, icon("back")),
    me ? h("button", {class: "tg-edit", type: "button", onclick: openInfoPage, "aria-label": "Profilni tahrirlash"}, icon("edit")) : "",
    zoomAvatar(avatar(u, "l"), u),
    h("div", {class: "pname"}, nameEl(u, {big: true})),
    titleEl(u),
    h("div", {class: "pstat" + (isOnline(u.id) ? " on" : ""), text: statusText(u)}));
  if (isStaff(u)) top.append(tint(h("div", {class: "chip prem " + u.role}, hasEmoji(u) ? badge(u) : (u.badge === "none" ? null : icon(u.role === "owner" ? "shield" : "check", "ic vb")), roleLabel(u.role)), u));
  else if (hasEmoji(u)) top.append(h("div", {class: "chip"}, badge(u), "Maxsus nishon"));
  else if (isVerified(u)) top.append(h("div", {class: "chip"}, badge(u), "Tasdiqlangan foydalanuvchi"));
  if (u.new && !isStaff(u)) top.append(h("div", {class: "chip warn", text: "⚠ Yangi foydalanuvchi — hali ishonish qiyin"}));
  wrap.append(top);

  const acts = h("div", {class: "tg-acts"});
  const act = (ic, label, fn, on) => h("button", {class: "tg-act" + (on ? " on" : ""), type: "button", onclick: fn, "aria-pressed": on == null ? null : String(!!on)}, icon(ic), h("span", {text: label}));
  if (!me) {
    acts.append(act("chat", "Xabar", () => { closeAllPages(); openChat({kind: "dm", uid: u.id}); }));
    const muted = isMuted(u.id);
    acts.append(act(muted ? "bell-off" : "bell", muted ? "Ovoz yoq" : "Mute", () => {
      const on = toggleMute(u.id);
      toast(on ? "Bu suhbat ovozi o'chirildi (shu qurilmada)" : "Suhbat ovozi yoqildi", "ok");
      repaintTopPage();
    }, muted));
  }
  if (!me) wrap.append(acts);
  wrap.append(h("div", {class: "tg-gap"}));

  const info = h("div", {class: "tg-info"});
  const copyRow = (val, label, copy) => h("div", {class: "tg-row copy", role: "button", tabindex: "0", title: "Nusxalash",
    onclick: () => copyText(copy), onkeydown: e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); copyText(copy); } }},
    h("div", {class: "tg-val", text: val}), h("div", {class: "tg-lab", text: label}));
  const unRow = copyRow("@" + u.username, "Username", "@" + u.username); fxText(unRow.firstChild, fxOf(u, "user"));
  info.append(unRow);
  if (u.bio) info.append(h("div", {class: "tg-row copy"}, fxText(h("div", {class: "tg-bio"}, Rich.inline(u.bio, LINKCTX)), fxOf(u, "bio")), h("div", {class: "tg-lab", text: "Bio"})));
  if (u.joined) { const d = new Date(u.joined * 1000); info.append(h("div", {class: "tg-row copy"}, h("div", {text: d.getDate() + "-" + MONTHS[d.getMonth()] + " " + d.getFullYear()}), h("div", {class: "tg-lab", text: "Qo'shilgan"}))); }
  wrap.append(info);

  const st = me ? null : mediaStats(u.id);
  if (st && (st.img || st.voice || st.vnote || st.file)) {
    const plus = st.more ? "+" : "";
    const rows = h("div", {class: "tg-media"});
    if (st.img) rows.append(tgRow("attach", st.img + plus + " ta rasm"));
    if (st.voice) rows.append(tgRow("mic", st.voice + plus + " ta ovozli xabar"));
    if (st.vnote) rows.append(tgRow("videocam", st.vnote + plus + " ta video xabar"));
    if (st.file) rows.append(tgRow("file", st.file + plus + " ta fayl"));
    wrap.append(h("div", {class: "tg-gap"}), rows);
  }
  if (!me && amAdmin() && u.role !== "owner" && (u.role !== "admin" || S.me.role === "owner")) wrap.append(h("div", {class: "tg-gap"}), h("div", {class: "tg-modwrap"}, modPanel(u)));
  return wrap;
}
function modPanel(u) {
  const cmd = text => wsSend({type: "cmd", text});
  const panel = h("div", {class: "mod"}, h("h4", {}, icon("shield"), "Moderatsiya"));
  const flags = h("div", {class: "mod-r"});
  if (u.banned) flags.append(h("span", {class: "flag", text: "Ban qilingan"}));
  if (u.muted) flags.append(h("span", {class: "flag w", text: "Mute qilingan"}));
  if (u.warns) flags.append(h("span", {class: "warnflag", text: "Ogohlantirish: " + u.warns + "/3"}));
  if (flags.children.length) panel.append(flags);
  const dur = h("select", {}, h("option", {value: "10", text: "10 daqiqa"}), h("option", {value: "60", text: "1 soat"}),
    h("option", {value: "1440", text: "1 kun"}), h("option", {value: "perm", text: "Doimiy"}));
  panel.append(h("div", {class: "mod-r"}, dur,
    h("button", {class: "btn ghost sm", type: "button", onclick: () => cmd("/mute " + u.username + " " + dur.value)}, "Mute"),
    u.muted ? h("button", {class: "btn ghost sm", type: "button", onclick: () => cmd("/unmute " + u.username)}, "Unmute") : null));
  panel.append(h("div", {class: "mod-r"},
    h("button", {class: "btn ghost sm", type: "button", onclick: async () => {
      const why = await promptDlg("Ogohlantirish", "@" + u.username + " ga ogohlantirish (3 tadan keyin 1 soat mute). Sabab:", "", {okText: "Ogohlantirish"});
      if (why !== null) cmd("/warn " + u.username + " " + why);
    }}, "Ogohlantirish"),
    u.warns ? h("button", {class: "btn ghost sm", type: "button", onclick: () => cmd("/unwarn " + u.username)}, "Olib tashlash") : null,
    h("button", {class: "btn ghost sm", type: "button", onclick: async () => {
      if (await confirmDlg("@" + u.username + " ning umumiy chatdagi oxirgi xabarlari (va fayllari) o'chiriladi.", {title: "Xabarlarini tozalash", okText: "Tozalash", danger: true})) cmd("/purge " + u.username);
    }}, "Xabarlarini tozalash"),
    h("button", {class: "btn ghost sm", type: "button", onclick: () => openBadgePicker(u)}, "Nishon / galochka"),
    h("button", {class: "btn ghost sm", type: "button", onclick: () => openProfileEditor(u.id)}, "Unvon / ishonch")));
  panel.append(h("div", {class: "mod-r"},
    u.banned
      ? h("button", {class: "btn ghost sm", type: "button", onclick: () => cmd("/unban " + u.username)}, "Bandan chiqarish")
      : h("button", {class: "btn danger sm", type: "button", onclick: async () => { if (await confirmDlg("@" + u.username + " ni ban qilasizmi?", {title: "Ban qilish", okText: "Ban qilish", danger: true})) cmd("/ban " + u.username); }}, "Ban qilish")));
  if (S.me.role === "owner") {
    panel.append(h("div", {class: "mod-r"}, u.role === "admin"
      ? h("button", {class: "btn ghost sm", type: "button", onclick: async () => { if (await confirmDlg("@" + u.username + " adminlikdan olinsinmi?", {title: "Adminlikdan olish", okText: "Olish", danger: true})) cmd("/rmadmin " + u.username); }}, "Adminlikdan olish")
      : h("button", {class: "btn ghost sm", type: "button", onclick: async () => { if (await confirmDlg("@" + u.username + " admin qilinsinmi?", {title: "Admin qilish", okText: "Admin qilish"})) cmd("/addadmin " + u.username); }}, "Admin qilish")));
  }
  const rows = panel.querySelectorAll(".mod-r");
  if (S.me.role === "owner" && rows.length >= 2) { const last = rows[rows.length - 1], prev = rows[rows.length - 2]; [...last.children].forEach(c => prev.append(c)); last.remove(); }
  panel.append(h("div", {class: "mod-r"}, h("button", {class: "btn danger sm", type: "button", onclick: async () => {
    if (await confirmDlg("@" + u.username + " akkaunti o'chiriladi va chatdan chiqarib tashlanadi. Yozgan xabarlari \"Deleted account\" nomi bilan qoladi. Buni qaytarib bo'lmaydi.",
      {title: "Akkauntni o'chirish", okText: "O'chirish", danger: true})) { cmd("/remove " + u.username); closePage(); }
  }}, "Akkauntni o'chirish")));
  return panel;
}

function ago(ts) {
  if (!ts) return "?";
  const s = Math.max(0, Date.now() / 1000 - ts);
  if (s < 60) return "hozirgina";
  const m = s / 60; if (m < 60) return Math.floor(m) + " daqiqa oldin";
  const hr = m / 60; if (hr < 24) return Math.floor(hr) + " soat oldin";
  const d = hr / 24; if (d < 30) return Math.floor(d) + " kun oldin";
  if (d < 365) return Math.floor(d / 30) + " oy oldin";
  return Math.floor(d / 365) + " yil oldin";
}
async function backupDownload() {
  const p1 = await promptDlg("Zaxira paroli", "Zaxira faylini shifrlash uchun parol-ibora kiriting (kamida 8 belgi). Uni yo'qotsangiz, fayl ochilmaydi va tiklab bo'lmaydi.", "", {type: "password", okText: "Davom etish"});
  if (p1 === null) return;
  if (p1.length < 8) { toast("Parol-ibora kamida 8 belgi bo'lishi kerak", "error"); return; }
  const p2 = await promptDlg("Parol-iborani takrorlang", "Xato yozilmaganini tekshirish uchun yana kiriting:", "", {type: "password", okText: "Yuklab olish"});
  if (p2 === null) return;
  if (p1 !== p2) { toast("Parol-iboralar mos kelmadi", "error"); return; }
  toast("Shifrlanmoqda…");
  try {
    const data = await api("/admin/backup");
    const bytes = await Backup.seal(data, p1), d = new Date();
    const name = "anonim-chat-users-" + d.getFullYear() + pad2(d.getMonth() + 1) + pad2(d.getDate()) + ".acdb";
    const url = URL.createObjectURL(new Blob([bytes], {type: "application/octet-stream"}));
    const a = h("a", {href: url, download: name}); document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
    toast(data.users.length + " ta akkaunt shifrlangan zaxiraga yozildi" + (data.avatars_skipped ? " (" + data.avatars_skipped + " ta katta rasm kiritilmadi)" : ""), "ok");
  } catch (err) { toast(err.message, "error"); }
}
function backupRestore(done) {
  const f = h("input", {type: "file", accept: ".acdb", class: "offscreen"});
  f.addEventListener("cancel", () => f.remove());
  f.addEventListener("change", async () => {
    const file = f.files[0]; f.remove();
    if (!file) return;
    try {
      if (file.size > 40 * 1048576) throw new Error("Fayl juda katta");
      const bytes = new Uint8Array(await file.arrayBuffer());
      const pass = await promptDlg("Zaxira paroli", "Zaxirani ochish uchun parol-iborani kiriting:", "", {type: "password", okText: "Ochish"});
      if (pass === null) return;
      toast("Ochilmoqda…");
      const data = await Backup.open(bytes, pass);
      const list = Array.isArray(data.users) ? data.users : [], adm = list.filter(u => u && u.role === "admin").length;
      if (!await confirmDlg(list.length + " ta akkaunt topildi (" + adm + " ta admin). Mavjud username'larga tegilmaydi — faqat yo'qlari tiklanadi. Xabarlar tiklanmaydi. Davom etilsinmi?", {title: "Zaxiradan tiklash", okText: "Tiklash"})) return;
      const j = await api("/admin/backup/restore", {method: "POST", body: {data}});
      toast(j.created + " ta akkaunt tiklandi" + (j.skipped ? ", " + j.skipped + " tasi allaqachon bor" : "") + (j.invalid ? ", " + j.invalid + " tasi yaroqsiz" : ""), j.created ? "ok" : "warn");
      loadMembers(); if (done) done();
    } catch (err) { toast(err.message, "error"); }
  });
  document.body.append(f); f.click();
}

const fmtDT = ts => { const d = new Date(ts * 1000); return pad2(d.getDate()) + "." + pad2(d.getMonth() + 1) + "." + String(d.getFullYear()).slice(2) + " " + hhmm(ts) + ":" + pad2(d.getSeconds()); };
function admErr(box, err) { box.textContent = ""; box.append(h("div", {class: "adm-empty", text: err.message})); }

function openAdmin(initial, preset) {
  preset = preset || {};
  const top = PG.list[PG.list.length - 1];
  if (top && top.adm === initial && !Object.keys(preset).length) { paintPage(top); return; }
  const pg = openPage(() => {
    const st = {tab: initial, q: preset.q || "", ip: preset.ip || "", user: preset.user || "", action: ""};
    const body = h("div", {class: "adm-body"});
    const loaders = {ips: loadIps, users: loadUsers, log: loadLog, msgs: loadMsgs, blocks: loadBlocks, media: loadMedia, reports: loadReports, mod: loadMod, emoji: () => emojiManager(body, () => st.tab === "emoji")};
    const load = () => { body.textContent = ""; loaders[st.tab](); };

    function loadUsers() {
      const owner = S.me.role === "owner";
      const filter = h("input", {type: "text", class: "fld", placeholder: "Nickname yoki @username bo'yicha qidirish", autocomplete: "off"});
      const list = h("div", {}), box = h("div", {class: "bk-box"});
      let all = [];
      const roleName = r => r === "owner" ? "Ega" : r === "admin" ? "Admin" : "Oddiy";
      const paint = () => {
        const q = filter.value.trim().toLowerCase().replace(/^@/, "");
        list.textContent = "";
        const rows = all.filter(u => !q || u.nickname.toLowerCase().includes(q) || u.username.toLowerCase().includes(q));
        if (!rows.length) list.append(h("div", {class: "adm-empty", text: "Hech narsa topilmadi"}));
        rows.forEach(u => {
          const can = u.role !== "owner" && (u.role !== "admin" || owner);
          list.append(h("div", {class: "urow"}, avatar(u, "m", true),
            h("div", {class: "utx"}, nameEl(u),
              h("div", {class: "usub"}, h("span", {class: "ubadge " + u.role, text: roleName(u.role)}), "@" + u.username + " • " + ago(u.joined) + " qo'shilgan" + (u.banned ? " • ban" : ""))),
            can ? h("div", {class: "urow-act"},
              h("button", {class: "btn ghost sm", type: "button", text: "Unvon", onclick: () => openProfileEditor(u.id)}),
              h("button", {class: "btn ghost sm", type: "button", text: "Nishon", onclick: () => openBadgePicker(u, () => openAdmin("users"))})) : h("span")));
        });
      };
      const fill = async () => {
        list.textContent = ""; list.append(h("div", {class: "adm-empty", text: "Yuklanmoqda…"}));
        try { const j = await api("/members"); j.members.forEach(upsertUser); all = j.members.map(x => U(x.id)); box.querySelector(".bk-n") && (box.querySelector(".bk-n").textContent = all.length + " ta akkaunt"); paint(); }
        catch (err) { admErr(list, err); }
      };
      if (owner) box.append(h("div", {}, h("b", {text: "Shifrlangan zaxira (.acdb). "}), "Username, nickname, rol, profil rasmi, qo'shilgan vaqt va kirish ma'lumoti sizning parol-iborangiz bilan BRAUZERDA shifrlanadi; parol-ibora serverga yuborilmaydi. Uni yo'qotsangiz fayl ochilmaydi. Xabarlar zaxiraga kirmaydi. ", h("span", {class: "bk-n"})),
        h("div", {class: "ep-row"}, h("button", {class: "btn sm", type: "button", text: "⬇ Bazani yuklab olish", onclick: backupDownload}),
          h("button", {class: "btn ghost sm", type: "button", text: "⬆ Zaxiradan tiklash", onclick: () => backupRestore(fill)})));
      else box.append("Bazani yuklab olish va zaxiradan tiklash faqat platforma egasiga ochiq: zaxira faylida kirish ma'lumotlari bor, ularni oddiy adminga berish E2EE'ni buzardi. Siz foydalanuvchilarga nishon/galochka bera olasiz.");
      filter.addEventListener("input", paint);
      body.append(box, h("div", {class: "adm-filters"}, filter), list);
      fill();
    }

    function loadIps() {
      const filter = h("input", {type: "text", class: "fld", placeholder: "IP yoki @username bo'yicha qidirish", autocomplete: "off"});
      filter.value = st.q;
      const list = h("div", {});
      let timer = null;
      const fill = async () => {
        list.textContent = ""; list.append(h("div", {class: "adm-empty", text: "Yuklanmoqda…"}));
        try {
          const j = await api("/admin/ips?q=" + encodeURIComponent(st.q));
          list.textContent = "";
          if (!j.ips.length) list.append(h("div", {class: "adm-empty", text: "Hech narsa topilmadi"}));
          j.ips.forEach(e => list.append(ipCard(e, fill)));
        } catch (err) { admErr(list, err); }
      };
      filter.addEventListener("input", () => { clearTimeout(timer); timer = setTimeout(() => { st.q = filter.value.trim(); fill(); }, 300); });
      body.append(h("div", {class: "adm-filters"}, filter), list);
      fill();
    }
    function ipCard(e, refresh) {
      const head = h("div", {class: "ipc-h"}, h("span", {class: "ip", text: e.ip}), e.blocked ? h("span", {class: "flag b", text: "Bloklangan"}) : null);
      const sum = h("div", {class: "ipc-s", text: e.profiles.length + " ta profil • " + e.logins + " kirish • " + e.sessions + " sessiya • " + e.msgs + " xabar" +
        (e.failed ? " • " + e.failed + " xato urinish" : "") + " • oxirgi: " + fmtDT(e.last_seen)});
      const card = h("div", {class: "ipc" + (e.blocked ? " blk" : "")}, head, sum);
      e.profiles.forEach(p => card.append(h("div", {class: "ipc-p"},
        h("div", {class: "who"}, h("b", {text: "@" + p.username}), p.nickname ? " (" + p.nickname + ")" : "", p.known ? "" : " — ro'yxatdan o'tmagan nom"),
        h("div", {class: "num", text: p.logins + " kirish • " + p.sessions + " sessiya • " + p.msgs + " xabar" + (p.failed ? " • " + p.failed + " xato" : "")}))));
      const acts = h("div", {class: "ipc-a"}, h("button", {class: "btn ghost sm", type: "button", text: "Loglari", onclick: () => openAdmin("log", {ip: e.ip})}));
      if (e.blocked) acts.append(h("button", {class: "btn ghost sm", type: "button", text: "Blokdan ochish", onclick: async () => {
        if (!await confirmDlg(e.ip + " blokdan ochilsinmi?", {title: "Blokdan ochish", okText: "Ochish"})) return;
        try { await api("/admin/unblock", {method: "POST", body: {ip: e.ip}}); toast("Blokdan ochildi", "ok"); refresh(); } catch (err) { toast(err.message, "error"); }
      }}));
      else acts.append(h("button", {class: "btn danger sm", type: "button", text: "Bloklash", onclick: async () => {
        const reason = await promptDlg("IP bloklash", e.ip + " bloklanadi. Sabab (ixtiyoriy):", "spam", {okText: "Bloklash"});
        if (reason === null) return;
        try { const j = await api("/admin/blocks", {method: "POST", body: {ip: e.ip, reason}}); toast("Bloklandi" + (j.kicked ? " (" + j.kicked + " ta ulanish uzildi)" : ""), "ok"); refresh(); }
        catch (err) { toast(err.message, "error"); }
      }}));
      card.append(acts);
      return card;
    }

    function loadLog() {
      const ipI = h("input", {type: "text", class: "fld", placeholder: "IP", autocomplete: "off"}); ipI.value = st.ip;
      const userI = h("input", {type: "text", class: "fld", placeholder: "@username", autocomplete: "off"}); userI.value = st.user;
      const sel = h("select", {}, h("option", {value: "", text: "Barcha amallar"}));
      const list = h("div", {}), more = h("button", {class: "btn ghost sm adm-more hidden", type: "button", text: "Yana yuklash"});
      let before = 0, filled = false, timer = null;
      const picked = new Set();
      const delSel = h("button", {class: "btn danger sm", type: "button", text: "Tanlanganlarni o'chirish"});
      const delAll = h("button", {class: "btn ghost sm dangerline", type: "button", text: "Filtrdagi hammasini o'chirish"});
      const updDel = () => { delSel.disabled = !picked.size; delSel.textContent = picked.size ? "Tanlanganlarni o'chirish (" + picked.size + ")" : "Tanlanganlarni o'chirish"; };
      delSel.addEventListener("click", async () => {
        if (!await confirmDlg(picked.size + " ta log yozuvi butunlay o'chiriladi.", {title: "Loglarni o'chirish", okText: "O'chirish", danger: true})) return;
        try { const j = await api("/admin/activity/delete", {method: "POST", body: {ids: [...picked]}}); toast(j.deleted + " ta yozuv o'chirildi", "ok"); picked.clear(); updDel(); page(true); }
        catch (err) { toast(err.message, "error"); }
      });
      delAll.addEventListener("click", async () => {
        const f = ipI.value.trim() || userI.value.trim() || sel.value;
        if (!await confirmDlg(f ? "Joriy filtrga mos BARCHA yozuvlar o'chiriladi." : "Harakatlar logining BUTUN tarixi o'chiriladi.", {title: "Loglarni o'chirish", okText: "Hammasini o'chirish", danger: true})) return;
        try { const j = await api("/admin/activity/delete", {method: "POST", body: {all: true, ip: ipI.value.trim(), user: userI.value.trim(), action: sel.value}}); toast(j.deleted + " ta yozuv o'chirildi", "ok"); picked.clear(); updDel(); page(true); }
        catch (err) { toast(err.message, "error"); }
      });
      const row = it => {
        const bad = ["login_failed", "blocked", "ip_block"].includes(it.action);
        const ipl = it.ip ? h("span", {class: "ipl", text: it.ip, onclick: () => { ipI.value = it.ip; page(true); }}) : null;
        const ck = h("input", {type: "checkbox", class: "ck", "aria-label": "Tanlash"});
        ck.addEventListener("change", () => { if (ck.checked) picked.add(it.id); else picked.delete(it.id); updDel(); });
        return h("div", {class: "lg sel"}, ck, h("div", {class: "t", text: fmtDT(it.ts)},),
          h("div", {class: "w"}, h("span", {class: "a" + (bad ? " bad" : ""), text: it.label}), it.username ? "@" + it.username + " " : "", ipl),
          it.detail ? h("div", {class: "d", text: it.detail}) : null);
      };
      const page = async reset => {
        if (reset) { before = 0; list.textContent = ""; picked.clear(); updDel(); }
        const qs = new URLSearchParams({ip: ipI.value.trim(), user: userI.value.trim(), action: sel.value, limit: "100"});
        if (before) qs.set("before", before);
        try {
          const j = await api("/admin/activity?" + qs.toString());
          if (!filled) { j.actions.forEach(a => sel.append(h("option", {value: a.key, text: a.label}))); filled = true; }
          j.items.forEach(it => list.append(row(it)));
          if (j.items.length) before = j.items[j.items.length - 1].id;
          more.classList.toggle("hidden", j.items.length < 100);
          if (reset && !j.items.length) list.append(h("div", {class: "adm-empty", text: "Yozuv topilmadi"}));
        } catch (err) { admErr(list, err); }
      };
      const again = () => { clearTimeout(timer); timer = setTimeout(() => page(true), 300); };
      ipI.addEventListener("input", again); userI.addEventListener("input", again); sel.addEventListener("change", () => page(true));
      more.addEventListener("click", () => page(false));
      body.append(h("div", {class: "adm-filters"}, ipI, userI, sel), h("div", {class: "adm-bar"}, delSel, delAll), list, more);
      updDel(); page(true);
    }

    function loadBlocks() {
      const ipI = h("input", {type: "text", class: "fld", placeholder: "Bloklash uchun IP (masalan 203.0.113.5)", autocomplete: "off"});
      const reasonI = h("input", {type: "text", class: "fld", placeholder: "Sabab (ixtiyoriy)", autocomplete: "off"});
      const list = h("div", {});
      const fill = async () => {
        list.textContent = "";
        try {
          const j = await api("/admin/blocks");
          if (!j.blocks.length) list.append(h("div", {class: "adm-empty", text: "Bloklangan IP yo'q"}));
          j.blocks.forEach(b => list.append(h("div", {class: "ipc blk"},
            h("div", {class: "ipc-h"}, h("span", {class: "ip", text: b.ip})),
            h("div", {class: "ipc-s", text: (b.reason ? b.reason + " • " : "") + "@" + b.by + " • " + fmtDT(b.ts)}),
            h("div", {class: "ipc-a"}, h("button", {class: "btn ghost sm", type: "button", text: "Blokdan ochish", onclick: async () => {
              try { await api("/admin/unblock", {method: "POST", body: {ip: b.ip}}); toast("Blokdan ochildi", "ok"); fill(); } catch (err) { toast(err.message, "error"); }
            }}),
            h("button", {class: "btn ghost sm", type: "button", text: "Loglari", onclick: () => openAdmin("log", {ip: b.ip})})))));
        } catch (err) { admErr(list, err); }
      };
      const add = h("button", {class: "btn danger sm", type: "button", text: "Bloklash", onclick: async () => {
        if (!ipI.value.trim()) return;
        try { await api("/admin/blocks", {method: "POST", body: {ip: ipI.value.trim(), reason: reasonI.value}}); ipI.value = ""; reasonI.value = ""; toast("Bloklandi", "ok"); fill(); }
        catch (err) { toast(err.message, "error"); }
      }});
      body.append(h("div", {class: "adm-filters"}, ipI, reasonI, add), list);
      fill();
    }

    function loadMsgs() {
      const qI = h("input", {type: "text", class: "fld", placeholder: "@username bo'yicha qidirish", autocomplete: "off"});
      const sel = h("select", {}, h("option", {value: "", text: "Barcha xabarlar"}), h("option", {value: "deleted", text: "Faqat o'chirilganlar"}), h("option", {value: "edited", text: "Faqat tahrirlanganlar"}));
      const list = h("div", {}), more = h("button", {class: "btn ghost sm adm-more hidden", type: "button", text: "Yana yuklash"});
      let next = 0, timer = null;
      const row = it => {
        const cipher = h("div", {class: "mcipher", text: it.cipher || "(shifr yo'q)"});
        const metaTxt = it.meta ? (it.meta.kind + " • epoch " + it.meta.epoch + " • shifr " + it.meta.cipher_bytes + " bayt • imzo " + it.meta.sig_bytes + " bayt")
          : (it.legacy ? "eski xabar (E2EE'dan oldin)" : "");
        const lock = h("div", {class: "mmeta", text: "🔒 " + metaTxt});
        const flags = h("span", {class: "mflags"},
          it.deleted ? h("span", {class: "flag b", text: "O'chirilgan"}) : null,
          it.edited ? h("span", {class: "flag w", text: "Tahrirlangan"}) : null,
          it.file ? h("span", {class: "flag", text: "Fayl " + fmtSize(it.file_bytes) + " (shifrlangan)"}) : null,
          it.legacy ? h("span", {class: "flag w", text: "Eski"}) : null);
        const card = h("div", {class: "lg mlg" + (it.deleted ? " gone" : "")},
          h("div", {class: "t", text: fmtDT(it.ts) + " • #" + it.id}),
          h("div", {class: "w"}, h("span", {class: "a", text: "@" + it.username}), it.nickname ? " (" + it.nickname + ") " : " ", flags),
          cipher, lock);
        it.history.forEach(hh => card.append(h("div", {class: "mhist"},
          h("b", {text: (hh.type === "edit" ? "Tahrir" : hh.type === "delete" ? "O'chirish" : hh.type) + " • " + fmtDT(hh.ts) + (hh.by ? " • @" + hh.by : "")}),
          hh.type === "edit" ? h("div", {class: "mcipher", text: hh.old + "\n→\n" + hh.new}) : h("div", {class: "mcipher", text: hh.old}))));
        return card;
      };
      const page = async reset => {
        if (reset) { next = 0; list.textContent = ""; }
        const qs = new URLSearchParams({q: qI.value.trim(), state: sel.value, limit: "50"});
        if (next) qs.set("before", next);
        try {
          const j = await api("/admin/messages?" + qs.toString());
          j.items.forEach(it => list.append(row(it)));
          next = j.next; more.classList.toggle("hidden", !next);
          if (reset && !j.items.length) list.append(h("div", {class: "adm-empty", text: "Xabar topilmadi"}));
        } catch (err) { admErr(list, err); }
      };
      qI.addEventListener("input", () => { clearTimeout(timer); timer = setTimeout(() => page(true), 300); });
      sel.addEventListener("change", () => page(true)); more.addEventListener("click", () => page(false));
      body.append(h("div", {class: "adm-note", text: "Uchdan-uchga shifrlash (E2EE): server ham, admin ham xabar matnini o'qiy olmaydi — bu yerda faqat shifrlangan konvertlar ko'rinadi. Matnni faqat chat a'zolarining qurilmalari ochadi. Lichka xabarlar bu yerda ko'rinmaydi."}),
        h("div", {class: "adm-filters"}, qI, sel),
        h("div", {class: "adm-bar"}, h("button", {class: "btn ghost sm dangerline", type: "button", text: "Tarixni tozalash", onclick: async () => {
          if (!await confirmDlg("O'chirilgan umumiy chat xabarlari bazadan butunlay o'chadi va tahrir/moderatsiya tarixi tozalanadi.", {title: "Xabarlar tarixini tozalash", okText: "Tozalash", danger: true})) return;
          try { const j = await api("/admin/messages/clean", {method: "POST"}); toast(j.messages + " ta xabar, " + j.history + " ta tarix tozalandi", "ok"); page(true); }
          catch (err) { toast(err.message, "error"); }
        }})), list, more);
      page(true);
    }

    function loadMedia() {
      const KL = {image: "Rasm", video: "Video", audio: "Audio", other: "Fayl"};
      const kind = h("select", {}, ...[["", "Barcha turlar"], ["image", "Rasmlar"], ["video", "Videolar"], ["audio", "Audio"], ["other", "Boshqa fayllar"]].map(([v, t]) => h("option", {value: v, text: t})));
      const size = h("select", {}, ...[["0", "Har qanday hajm"], ["1", "1 MB dan katta"], ["5", "5 MB dan katta"], ["20", "20 MB dan katta"]].map(([v, t]) => h("option", {value: v, text: t})));
      const who = h("input", {type: "text", class: "fld", placeholder: "@username", autocomplete: "off"});
      const info = h("div", {class: "mm-total"}), list = h("div", {}), more = h("button", {class: "btn ghost sm adm-more hidden", type: "button", text: "Yana yuklash"});
      const del = h("button", {class: "btn danger sm", type: "button", text: "Tanlanganlarni o'chirish", disabled: true});
      const all = h("button", {class: "btn ghost sm", type: "button", text: "Ko'ringanlarni belgilash"});
      const picked = new Set(), boxes = [];
      let next = 0, timer = null;
      const upd = () => { del.disabled = !picked.size; del.textContent = picked.size ? "O'chirish (" + picked.size + ")" : "Tanlanganlarni o'chirish"; };
      const row = it => {
        const ck = h("input", {type: "checkbox", class: "ck", "aria-label": "Tanlash"});
        const r = h("div", {class: "mrow"}, ck, h("div", {}, h("span", {class: "mk", text: it.kind === "e2e" ? "🔒 Shifrlangan" : (KL[it.kind] || "Fayl")}), "@" + it.username, h("div", {class: "ms", text: fmtDT(it.ts)})), h("span", {class: "sz", text: fmtSize(it.size)}));
        ck.addEventListener("change", () => { if (ck.checked) picked.add(it.id); else picked.delete(it.id); r.classList.toggle("on", ck.checked); upd(); });
        boxes.push([ck, it.id, r]); return r;
      };
      const page = async reset => {
        if (reset) { next = 0; list.textContent = ""; picked.clear(); boxes.length = 0; upd(); }
        const qs = new URLSearchParams({kind: kind.value, sender: who.value.trim(), min_mb: size.value, limit: "50"});
        if (next) qs.set("before", next);
        try {
          const j = await api("/admin/media?" + qs.toString());
          info.textContent = "Umumiy chatdagi media: " + j.totals.count + " ta, jami " + fmtSize(j.totals.size);
          j.items.forEach(it => list.append(row(it)));
          next = j.next; more.classList.toggle("hidden", !next);
          if (reset && !j.items.length) list.append(h("div", {class: "adm-empty", text: "Media topilmadi"}));
        } catch (err) { admErr(list, err); }
      };
      all.addEventListener("click", () => { boxes.forEach(([ck, id, r]) => { ck.checked = true; picked.add(id); r.classList.add("on"); }); upd(); });
      del.addEventListener("click", async () => {
        if (!picked.size) return;
        if (!await confirmDlg(picked.size + " ta media chatdan va serverdan butunlay o'chiriladi. Izohi bor xabarlarning matni qoladi.", {title: "Media o'chirish", okText: "O'chirish", danger: true})) return;
        try { const j = await api("/admin/media/delete", {method: "POST", body: {ids: [...picked]}}); toast(j.deleted + " ta media o'chirildi", "ok"); page(true); }
        catch (err) { toast(err.message, "error"); }
      });
      const again = () => { clearTimeout(timer); timer = setTimeout(() => page(true), 300); };
      kind.addEventListener("change", () => page(true)); size.addEventListener("change", () => page(true)); who.addEventListener("input", again);
      more.addEventListener("click", () => page(false));
      body.append(h("p", {class: "mm-note", text: "Fayllar diskda shifrlangan. Bu yerda fayl nomi va mazmuni ko'rsatilmaydi (adminga ham), lichka fayllari kirmaydi. Loglarga faqat o'chirilgan SON yoziladi."}),
        info, h("div", {class: "adm-filters"}, kind, size, who), h("div", {class: "adm-bar"}, all, del), list, more);
      page(true);
    }

    function loadReports() {
      const status = h("select", {}, h("option", {value: "open", text: "Ochiq shikoyatlar"}), h("option", {value: "closed", text: "Ko'rib chiqilganlar"}));
      const list = h("div", {}), more = h("button", {class: "btn ghost sm adm-more hidden", type: "button", text: "Yana yuklash"});
      let next = 0;
      const close = async (it, action) => {
        try { await api("/admin/reports/close", {method: "POST", body: {id: it.id, action}}); page(true); }
        catch (err) { toast(err.message, "error"); }
      };
      const card = it => {
        const c = h("div", {class: "rcard" + (it.status === "closed" ? " closed" : "")},
          h("div", {class: "rh"}, h("span", {text: fmtDT(it.ts) + " • #" + it.message_id}), h("span", {text: "@" + it.reporter + " → @" + it.target}),
            it.status === "closed" ? h("span", {class: "flag w", text: (it.action || "Yopilgan") + (it.by ? " (@" + it.by + ")" : "")}) : null),
          h("div", {class: "rt", text: it.text || (it.disclosed ? "(shikoyatchi matnni ochib bermadi)" : "(matnsiz)")}),
          it.reason ? h("div", {class: "rr", text: "Sabab: " + it.reason}) : null);
        if (it.disclosed) {
          const v = h("div", {class: "rv", text: "🔒 Xabar shifrlangan; matn — shikoyatchi ixtiyoriy ochib bergani. Tekshirilmoqda…"});
          c.append(v);
          (async () => {
            try {
              const env = E2E.parseEnvelope(it.cipher), key = env.k === "g" ? X.rooms.get(env.ep) : null;
              if (!key) { v.textContent = "🔒 Tekshirib bo'lmadi: bu xabar kaliti sizda yo'q (matn tasdiqlanmagan)."; return; }
              const senderPeer = await peer(it.target_id);
              const r = await E2E.openMessage(it.cipher, {sender: it.target_id, peer: null, key, signKey: senderPeer.sign});
              const ok = r.verified && typeof r.payload.t === "string" && r.payload.t === it.text;
              v.textContent = ok ? "✅ Matn asl shifrlangan xabarga mos (imzo tasdiqlandi)." : "⚠ Ochib berilgan matn asl xabarga MOS EMAS — soxta shikoyat bo'lishi mumkin!";
              v.classList.add(ok ? "ok" : "bad");
            } catch (_) { v.textContent = "⚠ Tekshirib bo'lmadi (shifrni ochishda xato)."; v.classList.add("bad"); }
          })();
        }
        if (it.status === "open") {
          const a = h("div", {class: "ra"});
          if (it.alive) a.append(h("button", {class: "btn danger sm", type: "button", text: "Xabarni o'chirish", onclick: () => close(it, "delete")}));
          a.append(h("button", {class: "btn ghost sm", type: "button", text: "Mute 10 daq", onclick: () => { if (wsSend({type: "cmd", text: "/mute " + it.target + " 10 shikoyat"})) close(it, "done"); }}),
            h("button", {class: "btn ghost sm", type: "button", text: "Ogohlantirish", onclick: () => { if (wsSend({type: "cmd", text: "/warn " + it.target + " shikoyat"})) close(it, "done"); }}),
            h("button", {class: "btn ghost sm", type: "button", text: "Rad etish", onclick: () => close(it, "dismiss")}));
          c.append(a);
        }
        return c;
      };
      const page = async reset => {
        if (reset) { next = 0; list.textContent = ""; }
        const qs = new URLSearchParams({status: status.value, limit: "30"}); if (next) qs.set("before", next);
        try {
          const j = await api("/admin/reports?" + qs.toString());
          j.items.forEach(it => list.append(card(it)));
          next = j.next; more.classList.toggle("hidden", !next);
          if (reset && !j.items.length) list.append(h("div", {class: "adm-empty", text: status.value === "open" ? "Ochiq shikoyat yo'q 🎉" : "Hech narsa yo'q"}));
        } catch (err) { admErr(list, err); }
      };
      status.addEventListener("change", () => page(true)); more.addEventListener("click", () => page(false));
      body.append(h("div", {class: "adm-filters"}, status), list, more); page(true);
    }

    async function loadMod() {
      let cfg;
      try { cfg = await api("/admin/modsettings"); } catch (err) { admErr(body, err); return; }
      const save = async patch => {
        try { cfg = await api("/admin/modsettings", {method: "POST", body: patch}); toast("Saqlandi", "ok"); }
        catch (err) { toast(err.message, "error"); }
      };
      const slow = h("select", {}, ...[[0, "O'chiq"], [5, "5 soniya"], [10, "10 soniya"], [30, "30 soniya"], [60, "1 daqiqa"], [300, "5 daqiqa"]].map(([v, t]) => h("option", {value: String(v), text: t})));
      if (![0, 5, 10, 30, 60, 300].includes(cfg.slowmode)) slow.append(h("option", {value: String(cfg.slowmode), text: cfg.slowmode + " soniya"}));
      slow.value = String(cfg.slowmode);
      const lock = h("input", {type: "checkbox"}); lock.checked = cfg.locked;
      lock.addEventListener("change", () => save({locked: lock.checked}));
      const e2eSection = () => {
        const box = h("div", {class: "msec"}, h("h4", {text: "🔐 Uchdan-uchga shifrlash (E2EE)"}));
        const info = h("p", {text: "Yuklanmoqda…"}); box.append(info);
        api("/admin/e2ee").then(st => {
          info.textContent = "Guruh kaliti avlodi: " + st.epoch + " • kalitli foydalanuvchilar: " + st.keyed_users + " • server o'qiy oladigan eski xabarlar: " + st.legacy_messages +
            ". Ban qilinganda kalit avtomatik yangilanadi, qo'lda ham yangilash mumkin.";
          box.append(h("div", {class: "ep-row"}, h("button", {class: "btn sm", type: "button", text: "Guruh kalitini yangilash", onclick: async () => {
            if (!X.rooms.has(X.epoch)) { toast("Sizda joriy guruh kaliti yo'q", "error"); return; }
            await rotateRoom("manual"); load();
          }})));
          if (S.me.role === "owner" && st.legacy_messages) box.append(h("div", {class: "ep-row"}, h("button", {class: "btn danger sm", type: "button", text: "Eski xabarlarni o'chirish (" + st.legacy_messages + ")", onclick: async () => {
            if (!await confirmDlg("Server o'qiy oladigan barcha eski xabarlar va ularning fayllari butunlay o'chadi. Qaytarib bo'lmaydi. Yangi (E2EE) xabarlarga tegilmaydi.", {title: "Eski xabarlarni o'chirish", okText: "O'chirish", danger: true})) return;
            try { const j = await api("/admin/e2ee/purge-legacy", {method: "POST"}); toast(j.deleted + " ta eski xabar o'chirildi", "ok"); load(); } catch (err) { toast(err.message, "error"); }
          }})));
        }).catch(err => { info.textContent = err.message; });
        return box;
      };
      body.append(
        h("div", {class: "msec"}, h("h4", {text: "🐢 Sekin rejim"}), h("p", {text: "Oddiy foydalanuvchilar umumiy chatga shuncha vaqtda bir marta yoza oladi. Adminlarga va lichkaga qo'llanmaydi."}),
          h("div", {class: "ep-row"}, slow, h("button", {class: "btn sm", type: "button", text: "Saqlash", onclick: () => save({slowmode: Number(slow.value)})}))),
        h("div", {class: "msec"}, h("h4", {text: "🔒 Chatni qulflash"}), h("p", {text: "Qulflanganda umumiy chatga faqat adminlar yoza oladi (lichka ishlayveradi)."}),
          h("label", {class: "tgl"}, h("span", {text: "Umumiy chat qulflangan"}), lock)),
        e2eSection(),
        h("div", {class: "msec"}, h("h4", {text: "🛡️ Avtomatik himoya"}), h("p", {text: "3 ta ogohlantirishdan keyin foydalanuvchi 1 soatga mute qilinadi. Spam (1 daqiqada 3 marta tezlik limitiga urilish) — 5 daqiqa avtomatik mute. Foydalanuvchi profilidagi Moderatsiya panelidan: ogohlantirish, xabarlarini tozalash, mute/ban."})));
    }

    load();
    return h("div", {}, pageHead(ADM_TITLES[initial] || "Admin"), body);
  });
  pg.adm = initial;
}

const BADGE_EMOJIS = "👑 ✅ ⭐ 🌟 💎 🔥 ⚡ 🚀 🛡️ 🏆 🎖️ 💜 ❤️ 💙 💚 🧡 😎 🤩 😈 👻 🦄 🐉 🦁 🐺 🦅 🌈 🌙 ☀️ ❄️ 🍀 🎯 🎨 🎧 🎮 💫 ✨ 🔱 ⚜️ 🧿 🪐 🍒 🍉 👾 🤖 🥇 📢 🎉 🌹 🦋 🐱 🐼 🍕".split(" ");
const BADGE_ANIMS = [["", "Yo'q"], ["pulse", "Puls"], ["bounce", "Sakrash"], ["spin", "Aylanish"], ["shake", "Silkinish"], ["float", "Suzish"], ["glow", "Nur"], ["flip", "Aylanma"], ["wave", "Silkitish"], ["rainbow", "Kamalak"]];

function hScroll(el) {
  el.addEventListener("wheel", e => { if (Math.abs(e.deltaY) > Math.abs(e.deltaX) && el.scrollWidth > el.clientWidth) { el.scrollLeft += e.deltaY; e.preventDefault(); } }, {passive: false});
  let down = false, moved = false, x0 = 0, s0 = 0;
  el.addEventListener("pointerdown", e => { if (e.pointerType !== "mouse") return; down = true; moved = false; x0 = e.clientX; s0 = el.scrollLeft; });
  el.addEventListener("pointermove", e => { if (!down) return; const dx = e.clientX - x0; if (Math.abs(dx) > 4) moved = true; if (moved) el.scrollLeft = s0 - dx; });
  const up = () => { down = false; };
  el.addEventListener("pointerup", up); el.addEventListener("pointerleave", up); el.addEventListener("pointercancel", up);
  el.addEventListener("click", e => { if (moved) { e.stopPropagation(); e.preventDefault(); moved = false; } }, true);
}
function onSwipe(el, fn) {
  let x0 = null, y0 = 0;
  el.addEventListener("touchstart", e => { const t = e.touches[0]; x0 = t.clientX; y0 = t.clientY; }, {passive: true});
  el.addEventListener("touchend", e => { if (x0 == null) return; const t = e.changedTouches[0], dx = t.clientX - x0, dy = Math.abs(t.clientY - y0); x0 = null; if (Math.abs(dx) > 50 && dy < 40) fn(dx < 0 ? 1 : -1); }, {passive: true});
}
function keepTabVisible(bar) {
  const on = bar.querySelector(".on"); if (!on || !bar.clientWidth) return;
  const l = on.offsetLeft, r = l + on.offsetWidth;
  if (l < bar.scrollLeft + 6) bar.scrollLeft = Math.max(0, l - 10);
  else if (r > bar.scrollLeft + bar.clientWidth - 6) bar.scrollLeft = r - bar.clientWidth + 10;
}

function badgeTabs() {
  const tabs = [{k: "std", label: "Emoji"}];
  if (EM.data) emojiTabs().filter(x => x.k !== "std").forEach(x => tabs.push(x));
  else { const l = Rich.emojiList(); if (l.length) tabs.push({k: "other", label: "Maxsus", items: l, icon: l[0]}); }
  return tabs;
}
function badgeEditor(t, onSaved, mid) {
  const base = () => t.id === S.me.id ? S.me : (U(t.id) || t);
  const cur = {badge: t.badge || "", anim: t.badge_anim || "", tab: "std"};
  const tabs = badgeTabs();
  const found = tabs.find(x => x.items && x.items.some(e => e.token === cur.badge)); if (found) cur.tab = found.k;
  const prev = h("div", {class: "bd-prev"}), bar = h("div", {class: "bd-tabs", role: "tablist"}), cap = h("div", {class: "ep-cap bd-cap"}),
    grid = h("div", {class: "bd-grid"}), anims = h("div", {class: "bd-anims"});
  const custom = h("input", {type: "text", class: "fld", maxlength: "16", placeholder: "Yoki o'z emojingizni yozing", autocomplete: "off", "aria-label": "O'z emojingiz"});
  hScroll(bar); hScroll(anims);
  const paintPrev = () => {
    const u = Object.assign({}, base(), {badge: cur.badge, badge_anim: cur.anim});
    prev.textContent = ""; prev.append(nameEl(u, {big: true}));
    if (!badge(u, true)) prev.append(h("small", {text: "  (nishon yo'q)"}));
  };
  const mark = () => {
    grid.querySelectorAll("button").forEach(x => x.classList.toggle("on", x.dataset.v === cur.badge));
    anims.querySelectorAll("button").forEach(x => x.classList.toggle("on", x.dataset.a === cur.anim));
    if (chk) chk.classList.toggle("on", cur.badge === "check");
  };
  const paint = () => { paintPrev(); mark(); };
  const pick = v => { cur.badge = v; custom.value = ""; paint(); };
  const paintGrid = dir => {
    grid.textContent = ""; grid.className = "bd-grid" + (dir ? " sl-" + dir : "");
    const c = tabs.find(x => x.k === cur.tab) || tabs[0];
    cap.textContent = c.k === "std" ? "Standart emojilar" : c.label + " • " + c.items.length + " ta";
    if (c.k === "std") BADGE_EMOJIS.forEach(e => { const b = h("button", {type: "button", text: e, "aria-label": e, onclick: () => pick(e)}); b.dataset.v = e; grid.append(b); });
    else if (!c.items.length) grid.append(h("div", {class: "ep-empty", text: "Bu to'plam hozircha bo'sh"}));
    else c.items.forEach(e => { const b = h("button", {type: "button", title: e.label || e.token, "aria-label": e.label || e.token, onclick: () => pick(e.token)}, Rich.chatEmoji(e.token, false)); b.dataset.v = e.token; grid.append(b); });
    mark();
  };
  const goTab = (k, dir) => {
    const i0 = tabs.findIndex(x => x.k === cur.tab), i1 = tabs.findIndex(x => x.k === k);
    cur.tab = k; bar.querySelectorAll("button").forEach(x => x.classList.toggle("on", x.dataset.k === k));
    keepTabVisible(bar); paintGrid(dir || (i1 > i0 ? "r" : "l"));
  };
  tabs.forEach(tb => {
    const b = h("button", {type: "button", role: "tab", class: tb.k === cur.tab ? "on" : "", title: tb.label, "aria-label": tb.label, onclick: () => goTab(tb.k)});
    if (tb.k === "std") b.textContent = "😀"; else if (tb.icon) b.append(Rich.chatEmoji(tb.icon.token, false)); else b.textContent = "📦";
    b.dataset.k = tb.k; bar.append(b);
  });
  onSwipe(grid, d => { const i = tabs.findIndex(x => x.k === cur.tab) + d; if (i >= 0 && i < tabs.length) goTab(tabs[i].k, d > 0 ? "r" : "l"); });
  BADGE_ANIMS.forEach(([k, n]) => { const b = h("button", {type: "button", text: n}); b.dataset.a = k; b.addEventListener("click", () => { cur.anim = k; paint(); }); anims.append(b); });
  custom.addEventListener("input", () => { const v = custom.value.trim(); if (v) { cur.badge = v; paint(); } });
  const chk = isStaff(t) ? null : h("button", {class: "bd-chip", type: "button", onclick: () => { cur.badge = "check"; cur.anim = ""; custom.value = ""; paint(); }}, "✔ Galochka");
  const clr = h("button", {class: "bd-chip", type: "button", onclick: () => { cur.badge = ""; cur.anim = ""; custom.value = ""; paint(); }}, isStaff(t) ? "Galochka (standart)" : "Olib tashlash");
  const hide = isStaff(t) ? h("button", {class: "bd-chip", type: "button", onclick: () => { cur.badge = "none"; cur.anim = ""; custom.value = ""; paint(); }}, "Yashirish") : null;
  const save = async () => {
    try {
      let u;
      if (t.id === S.me.id) u = (await api("/profile", {method: "PATCH", body: {badge: cur.badge, badge_anim: cur.anim}})).me;
      else u = (await api("/admin/badge", {method: "POST", body: {user_id: t.id, badge: cur.badge, anim: cur.anim}})).user;
      upsertUser(u); renderList(); renderHeader(); renderMessages(false);
      toast("Nishon saqlandi", "ok"); if (onSaved) onSaved(u);
      paintPrev();
    } catch (err) { toast(err.message, "error"); }
  };
  paintGrid(); paint();
  const root = h("div", {class: "bd"}, prev, mid || null, bar, cap, grid,
    h("div", {class: "bd-quick"}, chk, clr, hide),
    chk ? h("small", {class: "ep-cap", text: "Galochka foydalanuvchini admin qilmasdan beriladi."}) : null,
    h("div", {class: "bd-lab", text: "Animatsiya"}), anims, custom,
    h("div", {class: "bd-act"}, h("button", {class: "btn", type: "button", onclick: save}, "Saqlash")));
  root.repaint = paintPrev;
  requestAnimationFrame(() => keepTabVisible(bar));
  return root;
}

function lookSection() {
  let ed;
  const colors = colorSection(() => { if (ed) ed.repaint(); });
  ed = badgeEditor(S.me, null, colors);
  return h("div", {class: "setsec look"}, h("h4", {text: "Profil rangi va nishoni"}), ed);
}

