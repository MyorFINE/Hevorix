/* ---------------- Reaksiyalar (xabar va kanal postlariga; Telegramdagidek) ----------------
   Bir foydalanuvchi — bitta xabarga bitta reaksiya. Server ro'yxatni saqlaydi va hammaga tarqatadi (`rx: {emoji: [user_id]}`).
   Sozlamalar (ikki marta bosish yoqilgan/o'chirilgan va qaysi emoji) shu qurilmada saqlanadi. */
const RX_QUICK = ["❤️", "👍", "👎", "🔥", "😂", "😮", "😢"];          // menyudagi bir qatorli tezkor reaksiyalar; qolgani ↓ tugmasi ostida
function rxAll() {                                                    // barcha reaksiyalar: chatdagi standart emojilar + yaratilgan (maxsus) emojilar
  const out = STD_EMOJIS.map(e => ({e, custom: false}));
  if (EM.data && emojiPerms().use) EM.data.emojis.filter(x => emojiUsable(x) && Rich.hasInlineEmoji(x.token)).forEach(x => out.push({e: x.token, custom: true, label: x.label}));
  return out;
}
/* Reaksiyalar ham chatdagi emoji kabi to'plamlarga (pack) bo'lingan: standart emojilar mavzu bo'yicha, maxsus emojilar o'z to'plami bo'yicha */
function rxGroups() {
  const cut = (a, b) => STD_EMOJIS.slice(STD_EMOJIS.indexOf(a), STD_EMOJIS.indexOf(b) + 1);
  const g = [
    {k: "f", title: "Yuzlar va hissiyotlar", label: "😀", items: cut("😀", "🙊")},
    {k: "h", title: "Qo'l va tana", label: "👍", items: cut("👍", "🧠")},
    {k: "l", title: "Yuraklar", label: "❤️", items: cut("❤️", "💯")},
    {k: "o", title: "Belgilar va narsalar", label: "🎉", items: cut("✨", "🍺")}];
  if (EM.data && emojiPerms().use) {
    emojiTabs().filter(t => t.k !== "std").forEach(t => {
      const items = (t.items || []).filter(x => Rich.hasInlineEmoji(x.token)).map(x => x.token);
      if (items.length) g.push({k: t.k, title: t.label, label: "📦", icon: items[0], items});
    });
  }
  return g;
}
/* To'plamlar tabi + tanlangan to'plamdagi emojilar. `mk(e)` — har bir emoji uchun tugma; `st.k` — tanlangan to'plam */
function rxPackView(mk, st, gridCls) {
  const gs = rxGroups(), wrap = h("div", {class: "rx-pv"});
  if (!gs.some(g => g.k === st.k)) st.k = gs[0].k;
  const paint = () => {
    const keep = wrap.querySelector(".rx-tabs"), left = keep ? keep.scrollLeft : 0;
    wrap.textContent = "";
    const bar = h("div", {class: "rx-tabs", role: "tablist"});
    gs.forEach(g => {
      const b = h("button", {type: "button", class: "rx-tab" + (g.k === st.k ? " on" : ""), title: g.title, "aria-label": g.title, role: "tab"}, g.icon ? rxGlyph(g.icon) : h("span", {class: "rx-e", text: g.label}));
      b.addEventListener("click", ev => { ev.stopPropagation(); st.k = g.k; paint(); });
      bar.append(b);
    });
    hScroll(bar);
    const cur = gs.find(g => g.k === st.k), grid = h("div", {class: gridCls});
    cur.items.forEach(e => grid.append(mk(e)));
    wrap.append(bar, h("small", {class: "rx-cap", text: cur.title + " • " + cur.items.length + " ta"}), grid);
    bar.scrollLeft = left; keepTabVisible(bar);
  };
  paint();
  return wrap;
}
const rxValid = e => typeof e === "string" && (STD_EMOJIS.includes(e) || Rich.isEmojiToken(e));
function rxGlyph(e, cls) {                                            // oddiy emoji — matn, `:nom:` — rasm
  if (Rich.isEmojiToken(e) && Rich.hasInlineEmoji(e)) { const i = Rich.chatEmoji(e, false); i.classList.add("rxi"); return i; }
  return h("span", {class: cls || "rx-e", text: Rich.isEmojiToken(e) ? "◈" : e});
}
const RX_KEY = "tc_rx";
const rxPrefs = (() => {
  let p = {}; try { p = JSON.parse(localStorage.getItem(RX_KEY) || "{}") || {}; } catch (_) {}
  const ok = typeof p.emoji === "string" && p.emoji.length <= 20 && !/[A-Za-z0-9]/.test(p.emoji.replace(/^:[a-z0-9_]{2,32}:$/, ""));   // oddiy emoji yoki :nom: (STD_EMOJIS bu yerda hali e'lon qilinmagan)
  return {dbl: p.dbl !== false, emoji: ok ? p.emoji : "❤️"};
})();
const rxSave = () => { try { localStorage.setItem(RX_KEY, JSON.stringify(rxPrefs)); } catch (_) {} };
const canReact = m => !!m && !m.service && m.id != null && !$("chat").classList.contains("dead");
function rxMine(m) {
  for (const [e, ids] of Object.entries(m.rx || {})) if (ids.includes(S.me.id)) return e;
  return null;
}
function reactTo(m, emoji) { if (canReact(m)) wsSend({type: "react", id: m.id, emoji}); }       // bir xil emoji qayta — serverda olib tashlanadi
function rxChip(e) {
  const chip = h("button", {class: "rx", type: "button"}, rxGlyph(e), h("b", {class: "cnt"}));
  chip.dataset.e = e;
  chip.addEventListener("click", ev => {
    ev.stopPropagation();
    const m = chip._m; if (!m) return;
    if (rxMine(m) !== e) { const r = chip.getBoundingClientRect(); rxBurst(e, r.left + r.width / 2, r.top + r.height / 2, {mini: true}); haptic(8); }
    reactTo(m, e);                                   // bir xil emoji qayta bosilsa serverda olib tashlanadi
  });
  return chip;
}
function rxCount(chip, n, anim) {                    // son o'zgarganda raqam "yumalab" almashadi
  const b = chip.querySelector(".cnt"), old = b.firstElementChild;
  if (!old) { b.append(h("span", {text: String(n)})); b.dataset.n = String(n); return; }
  const prev = Number(b.dataset.n); if (prev === n) return;
  b.dataset.n = String(n);
  if (!anim) { old.textContent = String(n); return; }
  const up = n > prev;
  b.querySelectorAll("span").forEach(x => { x.classList.add(up ? "up-out" : "down-out"); setTimeout(() => x.remove(), 240); });
  b.append(h("span", {class: up ? "up-in" : "down-in", text: String(n)}));
}
function rxSync(box, m, anim) {                      // chiplarni qayta yaratmasdan yangilaydi: yangisi "pop" bilan chiqadi, yo'qolgani kichrayib ketadi
  const want = Object.entries(m.rx || {}).filter(([, ids]) => ids.length), keys = new Set(want.map(([e]) => e)), have = new Map();
  [...box.children].forEach(c => {
    if (c.classList.contains("out")) return;
    if (keys.has(c.dataset.e)) have.set(c.dataset.e, c);
    else if (anim) { c.classList.add("out"); setTimeout(() => c.remove(), 230); } else c.remove();
  });
  let prev = null;
  want.forEach(([e, ids]) => {
    let c = have.get(e); const fresh = !c;
    if (fresh) c = rxChip(e);
    c._m = m;
    const mine = ids.includes(S.me.id), was = c.classList.contains("mine"), before = Number((c.querySelector(".cnt") || {dataset: {}}).dataset.n || 0);
    c.classList.toggle("mine", mine);
    c.title = ids.slice(0, 12).map(id => U(id).nickname).join(", ") + (ids.length > 12 ? " va yana " + (ids.length - 12) + " kishi" : "");
    c.setAttribute("aria-label", e + " " + ids.length + (mine ? " (siz qo'ygansiz)" : ""));
    rxCount(c, ids.length, anim && !fresh);
    if (anim) {
      const once = cls => { c.classList.add(cls); c.addEventListener("animationend", () => c.classList.remove(cls), {once: true}); };
      if (fresh) once("in");
      else if (mine && !was) { const g = c.firstElementChild; g.classList.add("pop"); setTimeout(() => g.classList.remove("pop"), 520); }   // o'zingiz qo'ysangiz emoji "sakraydi"
      else if (!mine && ids.length > before) once("bump");                                                                                 // boshqa odam qo'shsa chip yengil to'lqin beradi
    }
    const nxt = prev ? prev.nextElementSibling : box.firstElementChild;
    if (c !== nxt) box.insertBefore(c, nxt);
    prev = c;
  });
}
function reactionsEl(m) {
  if (!Object.values(m.rx || {}).some(a => a.length)) return null;
  const box = h("div", {class: "rxs"}); rxSync(box, m, false); return box;
}
function patchReactions(m) {                          // faqat shu xabar qatoridagi chiplar yangilanadi (rasm/video qayta yuklanmaydi)
  const row = document.querySelector('#msgs .row[data-id="' + Number(m.id) + '"]'); if (!row) return;
  const has = Object.values(m.rx || {}).some(a => a.length);
  let box = row.querySelector(".rxs");
  if (!box) {
    if (!has) return;
    box = h("div", {class: "rxs"});
    if (row.classList.contains("chan")) { const meta = row.querySelector(".bubble > .bfoot, .bubble > .meta"); (meta ? meta.before(box) : row.querySelector(".bubble").append(box)); }
    else row.append(box);                             // oddiy xabarlarda chiplar pufak ostida (qatorning ikkinchi satri)
    if (!row.classList.contains("chan")) row.classList.add("has-rx");      // kanal postida chiplar pufak ichida: qator o'zgarmaydi
  }
  rxSync(box, m, true);
  if (!has) setTimeout(() => { if (!box.querySelector(".rx:not(.out)")) { box.remove(); row.classList.remove("has-rx"); } }, 260);
}
function rxBurst(emoji, x, y, o) {                    // ikki marta bosilganda: emoji "sakraydi" + atrofga mayda emojilar sochiladi
  o = o || {};
  const fx = h("span", {class: "rx-fx", "aria-hidden": "true"}); fx.style.left = x + "px"; fx.style.top = y + "px";
  if (!o.mini) fx.append(h("span", {class: "rx-burst"}, rxGlyph(emoji, "rx-bg")));
  const n = o.mini ? 5 : 8;
  for (let i = 0; i < n; i++) {
    const ang = (Math.PI * 2 * i) / n + Math.random() * .5 - .25, d = (o.mini ? 30 : 64) + Math.random() * 22;
    const sp = h("span", {class: "rx-sp"}, rxGlyph(emoji, "rx-sg"));
    sp.style.setProperty("--dx", (Math.cos(ang) * d).toFixed(1) + "px"); sp.style.setProperty("--dy", (Math.sin(ang) * d - (o.mini ? 6 : 16)).toFixed(1) + "px");
    sp.style.setProperty("--s", (0.55 + Math.random() * 0.45).toFixed(2)); sp.style.animationDelay = (Math.random() * 70 | 0) + "ms";
    fx.append(sp);
  }
  document.body.append(fx); setTimeout(() => fx.remove(), 1000);
  if (o.bubble) { const bb = o.bubble; bb.classList.remove("rx-bump"); void bb.offsetWidth; bb.classList.add("rx-bump"); setTimeout(() => bb.classList.remove("rx-bump"), 380); }
}
function rxPicker(m) {                                // menyu tepasida: bitta qator + ↓ (hamma emojilar)
  const mine = rxMine(m), box = h("div", {class: "rx-pick", role: "group", "aria-label": "Reaksiya"});
  const pick = (e, btn) => ev => {
    ev.stopPropagation(); const r = btn.getBoundingClientRect(); closeCtx();
    if (e !== mine) rxBurst(e, r.left + r.width / 2, r.top); reactTo(m, e);
  };
  const cell = e => { const b = h("button", {class: "rx-pk" + (e === mine ? " on" : ""), type: "button", "aria-label": e}, rxGlyph(e)); b.addEventListener("click", pick(e, b)); return b; };
  const row = h("div", {class: "rx-row"});
  RX_QUICK.forEach((e, i) => { const c = cell(e); c.style.setProperty("--i", String(i)); row.append(c); });
  const more = h("button", {class: "rx-pk rx-more", type: "button", "aria-label": "Barcha reaksiyalar", "aria-expanded": "false"}, icon("down"));
  const all = h("div", {class: "rx-all hidden"});
  let built = false;
  more.addEventListener("click", ev => {
    ev.stopPropagation();
    if (!built) {                                    // katta ro'yxat faqat kerak bo'lganda chiziladi: to'plamlar (tab) bo'yicha
      built = true;
      all.append(rxPackView(cell, {k: null}, "rx-grid-all"));
    }
    const open = all.classList.toggle("hidden") === false;
    more.classList.toggle("up", open); more.setAttribute("aria-expanded", String(open));
    const c = $("ctx"), r = c.getBoundingClientRect();            // menyu kengaysa ekrandan chiqib ketmasin
    if (!c.classList.contains("as-sheet") && r.bottom > innerHeight - 8) c.style.top = Math.max(8, innerHeight - 8 - r.height) + "px";
  });
  more.style.setProperty("--i", String(RX_QUICK.length)); row.append(more); box.append(row, all);
  return box;
}
const TAP_SKIP = "a,button,input,textarea,select,[role=button],.mplayer,.vtrack,.vspd,.cbtn,.code-scroll,.term-scroll,.rxs";   // o'zining bosish amali bor elementlar
function attachTap(bubble, m) {
  let last = 0, timer = 0, lx = 0, ly = 0;
  bubble.addEventListener("click", e => {
    if (e.defaultPrevented || S.sel) return;                                 // uzoq bosish/surishdan keyingi bosish yoki belgilash rejimi
    if (e.target.closest && e.target.closest(TAP_SKIP)) return;
    const can = canReact(m), now = Date.now();
    if (rxPrefs.dbl && can && timer && now - last < 320) {                   // ikki marta ketma-ket: reaksiya
      clearTimeout(timer); timer = 0; last = 0;
      try { getSelection().removeAllRanges(); } catch (_) {}
      const emo = rxPrefs.emoji;
      rxBurst(emo, e.clientX, e.clientY, {bubble}); haptic(10);
      if (rxMine(m) !== emo) reactTo(m, emo);
      return;
    }
    let picked = ""; try { picked = String(getSelection() || "").trim(); } catch (_) {}
    if (picked) return;                                                      // kompyuter: matn belgilanayotgan bo'lsa menyu chiqmasin
    last = now; lx = e.clientX; ly = e.clientY; clearTimeout(timer);
    const open = () => { timer = 0; openCtx(lx, ly, m); };
    if (rxPrefs.dbl && can) timer = setTimeout(open, 280); else open();     // ikki marta bosish yoqilgan bo'lsa, ikkinchi bosishni biroz kutamiz
  });
}
function bubbleRow(m, isGroup, first, last, chan) {
  const own = m.user.id === S.me.id, mine = chan ? false : own, u = U(m.user.id);     // kanal postlari hammaga chap tomondan (Telegramdagidek)
  const row = h("div", {class: "row" + (mine ? " mine" : "") + (first ? " first" : "") + (last ? " last" : "") + (isGroup ? "" : " dm") + (chan ? " chan" : "")});
  row.dataset.id = m.id;
  if (S.sel) {
    const can = canDelete(m);
    row.classList.add(can ? "selectable" : "locked");
    if (can) {
      if (S.sel.has(m.id)) row.classList.add("selected");
      row.append(h("span", {class: "chk", "aria-hidden": "true"}, icon("check")));
    }
    row.addEventListener("click", e => { e.preventDefault(); e.stopPropagation(); toggleSel(m, row); }, true);
  }
  const slot = h("div", {class: "slot"});
  // Telegramdagidek: bir odamning ketma-ket xabarlarida avatar faqat eng oxirgisining yonida ko'rinadi,
  // qolganlarida o'sha joy bo'sh qoladi (xabarlar bir tekis turadi).
  if (isGroup && !mine && last) { const a = avatar(u, "s"); a.style.cursor = "pointer"; a.addEventListener("click", () => openProfile(u.id)); slot.append(a); }
  const meta = h("span", {class: "meta"});
  if (m.edited) meta.append("tahrirlangan ");
  if (m.e2e) meta.append(h("span", {class: "lk" + (m.locked ? "" : (m.verified && !m.bad ? " ok" : " bad")),
    title: m.locked ? "Shifrlangan, kalit kutilmoqda" : m.verified && !m.bad ? "Uchdan-uchga shifrlangan, imzosi tasdiqlangan" : "Imzo yoki shifrni tekshirib bo'lmadi!",
    text: m.locked ? "🔒" : m.verified && !m.bad ? "🔒" : "⚠"}), " ");
  else if (m.legacy) meta.append(h("span", {class: "lk bad", title: "Eski xabar: E2EE'dan oldin yozilgan, server o'qiy oladi", text: "🔓"}), " ");
  if (chan) meta.append(h("span", {class: "vws", title: "Ko'rishlar soni"}, icon("eye"), h("b", {text: String(m.views || 0)})), " ");
  meta.append(hhmm(m.ts));
  if (mine && m.to != null) meta.append(icon(m.read ? "checks" : "check", m.read ? "ic rd" : "ic"));
  const bubble = tint(h("div", {class: "bubble" + (isStaff(u) ? " prem " + u.role : "") + (m.image ? " has-img" + (m.content ? "" : " img-only") : "") + (m.file ? " has-file" + (S.previews.has(m.id) ? " has-pv" : "") + (m.file.voice ? " has-voice" : "") + (m.file.vnote ? " has-vnote" + (m.content ? "" : " vn-only") : "") : "")}), u);
  if (!m.deleted) fxBubble(bubble, u);                   // admin bergan xabar effekti va havola uslubi
  if (isGroup && !mine && first) {
    const ne = nameEl(u, {colored: true});                 // faqat ism (nickname) bosiladi; qatorning bo'sh joyi — oddiy xabar bosishi
    ne.classList.add("lnk");
    ne.addEventListener("click", e => { e.stopPropagation(); openProfile(u.id); });
    bubble.append(h("div", {class: "bname"}, ne));
  }
  if (m.fwd) bubble.append(h("div", {class: "fwd", title: "Yuboruvchi ko'rsatgan asl muallif (tekshirib bo'lmaydi)"}, icon("forward"), h("span", {text: "Oldinga yuborilgan: "}), h("b", {text: m.fwd.n})));
  if (m.reply) bubble.append(replyQuote(m.reply, u));
  if (m.image) bubble.append(imageBox(m, mine || own));
  if (m.file) bubble.append(fileBox(m));
  if (!mine && m.content && !m.locked && !m.bad && Rich.mentionsOf(m.content, LINKCTX).includes(S.me.username)) bubble.classList.add("mentioned-me");   // meni @belgilashgan xabar
  const more = h("button", {class: "more", type: "button", "aria-label": "Amallar"}, icon("down"));
  more.addEventListener("click", e => { e.stopPropagation(); const r = more.getBoundingClientRect(); openCtx(r.left, r.bottom + 4, m); });
  const shown = m.locked ? "🔒 Xabar kaliti kutilmoqda…" : m.bad ? "⚠ Shifrni ochib bo'lmadi" : m.content;
  const parts = !m.locked && !m.bad && m.content ? Rich.parse(m.content) : null;
  if (parts && Rich.hasRich(parts)) {                  // kod / Linux buyruqlari: alohida dizayn + pastida kichik «Nusxalash» tugmasi
    bubble.classList.add("has-code");
    parts.forEach((p, i) => {
      if (p.k === "text") { if (p.t) bubble.append(btextEl("btext rich-t", p.t, true)); return; }
      bubble.append(Rich.render(p, {user: u.username, fx: p.k === "term" && fxNow(m.id + ":" + i, m.ts), copy: copyQuiet}));
    });
  } else if (shown || !(m.image || m.file)) bubble.append(btextEl("btext" + (m.locked || m.bad ? " dim" : ""), shown, !m.locked && !m.bad));
  const rxEl = reactionsEl(m);
  if (rxEl && chan) bubble.append(rxEl);             // kanal postida chiplar post ichida (izoh tugmasi tepasida); oddiy xabarda — pufak ostida
  if (bubble.querySelector(".bigemo")) {            // stiker kabi katta emoji: vaqt emoji ostida alohida qatorda
    bubble.classList.add("has-big");
    bubble.append(h("div", {class: "bfoot"}, meta), more);
  } else bubble.append(meta, more);
  if (chan) bubble.append(h("button", {class: "cmbtn", type: "button", onclick: e => { e.stopPropagation(); Channels.openComments(m); }},
    icon("chat"), h("span", {class: "cmb-t", text: m.comments ? m.comments + " ta izoh" : "Izoh qoldirish"}), h("span", {class: "cmb-go", text: "›"})));
  bubble.addEventListener("contextmenu", e => { e.preventDefault(); if (S.sel) return toggleSel(m, row); openCtx(e.clientX, e.clientY, m); });
  attachTouch(bubble, row, m);          // uzoq bosish = menyu, chapga surish = javob
  attachTap(bubble, m);                 // bir marta bosish = menyu (javob, nusxa, uzatish...), ikki marta = reaksiya
  row.append(slot, bubble);
  if (rxEl && !chan) { row.append(rxEl); row.classList.add("has-rx"); }
  return row;
}
const BIG_STD = /^(?:\p{Extended_Pictographic}(?:\uFE0F|[\u{1F3FB}-\u{1F3FF}]|\u200D\p{Extended_Pictographic}\uFE0F?)*\s*){1,3}$/u;   // faqat 1–3 ta oddiy emoji
/* Havola va @belgilash konteksti: faqat mavjud foydalanuvchi @username bo'lib ko'rinadi, bosilsa profili ochiladi */
function userIdByName(name) {
  for (const u of S.users.values()) if (u.username === name && !u.deleted) return u.id;
  return null;
}
const LINKCTX = {mention: userIdByName, onMention: name => { const id = userIdByName(name); if (id != null) openProfile(id); }};
function btextEl(cls, text, rich) {                 // matn; `:nom:` emojilar rasmga, havolalar va @username bosiladigan elementga aylanadi (innerHTML ishlatilmaydi)
  const d = h("div", {class: cls});
  if (rich && (Rich.hasInlineEmoji(text) || Rich.hasLinks(text, LINKCTX))) d.append(Rich.inline(text, LINKCTX)); else d.textContent = text == null ? "" : text;
  if (rich && (d.querySelector(".ce.big") || (typeof text === "string" && text.length <= 40 && BIG_STD.test(text.trim())))) d.classList.add("bigemo");   // faqat emojidan iborat xabar — stiker kabi katta
  return d;
}
function toggleToBottom() {
  const b = $("msgs");
  $("toBottom").classList.toggle("hidden", b.scrollHeight - b.scrollTop - b.clientHeight < 240);
}
let scrollTick = 0;                               // scroll hodisasi kadrda bir marta ishlanadi (layout o'qish kam)
$("msgs").addEventListener("scroll", () => {
  if (scrollTick) return;
  scrollTick = requestAnimationFrame(() => {
    scrollTick = 0;
    const b = $("msgs"), bot = atBottom(); b._stick = bot; toggleToBottom();
    if (bot && S.away) bumpAway(true);
    closeCtx(); if (b.scrollTop < 160) loadOlder();
  });
}, {passive: true});
$("msgs").addEventListener("wheel", e => { if (e.deltaY < 0 && $("msgs").scrollTop <= 0) loadOlder(); }, {passive: true});     // kompyuter: eng tepada g'ildirak
$("msgs").addEventListener("touchmove", () => { if ($("msgs").scrollTop <= 0) loadOlder(); }, {passive: true});               // telefon: eng tepada tortish
$("toBottom").addEventListener("click", () => { const b = $("msgs"); b.scrollTop = b.scrollHeight; bumpAway(true); });



