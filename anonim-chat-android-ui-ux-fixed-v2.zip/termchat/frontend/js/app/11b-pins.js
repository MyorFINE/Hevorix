/* ---------------- Pin (mahkamlash) ----------------
   Umumiy chat: faqat adminlar pin qiladi, hamma ko'radi. Lichka: ikkala tomon faqat o'zi uchun pin qiladi (suhbatdosh ko'rmaydi).
   Holat serverda saqlanadi (GET /pins/group, /pins/dm/<id>); pin ro'yxati st.pins = [xabar, ...] (eskisi birinchi). */
const pinSt = () => !S.active ? null : S.active.kind === "group" ? S.group : S.active.kind === "dm" ? dmOf(S.active.uid) : null;
const pinStOf = m => m.to == null ? S.group : dmOf(partnerOf(m));
function canPin(m) { return !!m && !m.ch && !m.service && m.id != null && !m.pending && (m.to != null || amAdmin()); }
function isPinned(m) { const st = pinStOf(m); return !!(st.pins && st.pins.some(p => p.id === m.id)); }
function togglePin(m) { wsSend({type: "pin", id: m.id, on: !isPinned(m)}); }
const pinRow = id => $("msgs").querySelector('.row[data-id="' + Number(id) + '"]');
function markPins() {                                  // pin qilingan xabar pufagida kichik belgi
  const st = pinSt(), box = $("msgs"); if (!st) return;
  const ids = new Set((st.pins || []).map(p => p.id));
  box.querySelectorAll(".row[data-id]").forEach(r => {
    const on = ids.has(Number(r.dataset.id)), meta = r.querySelector(".bubble .meta"), mk = meta && meta.querySelector(".pinmark");
    if (on && meta && !mk) meta.prepend(icon("pin", "ic pinmark"));
    else if (!on && mk) mk.remove();
  });
}
function renderPinBar() {
  const bar = $("pinBar"), st = pinSt(), list = (st && st.pins) || [];
  if (!st || !list.length) { bar.classList.add("hidden"); return; }
  if (st.pinIdx == null || st.pinIdx >= list.length || st.pinIdx < 0) st.pinIdx = list.length - 1;
  const m = list[st.pinIdx];
  $("pinTitle").textContent = "Pin qilingan xabar" + (list.length > 1 ? " #" + (st.pinIdx + 1) + "/" + list.length : "");
  const t = $("pinText"); t.textContent = ""; t.append(...[].concat(previewOf(m, true, false)));
  $("pinX").classList.toggle("hidden", !canPin(m));
  bar.classList.remove("hidden");
}
async function pinGoTo(id) {                           // xabarga o'tadi; chizilmagan/yuklanmagan bo'lsa avval oldingilarini yuklaydi
  const st = pinSt(); if (!st) return;
  if (!pinRow(id)) {
    let i = st.msgs.findIndex(x => x.id === id);
    for (let n = 0; i < 0 && st.more && n < 30; n++) { await loadOlder(); i = st.msgs.findIndex(x => x.id === id); }
    if (i >= 0) { S.win = Math.max(S.win || WIN0, st.msgs.length - i + 6); renderMessages(false); }
  }
  if (pinRow(id)) jumpTo(id); else toast("Xabar topilmadi (eski yoki o'chirilgan)", "warn");
}
function pinBarClick() {
  const st = pinSt(); if (!st || !st.pins || !st.pins.length) return;
  const m = st.pins[st.pinIdx != null ? st.pinIdx : st.pins.length - 1];
  st.pinIdx = (st.pins.indexOf(m) - 1 + st.pins.length) % st.pins.length;      // keyingi bosishda oldingi (eskiroq) pin
  renderPinBar(); pinGoTo(m.id);
}
async function pinsRefresh(kind, uid) {
  kind = kind || (S.active && S.active.kind); if (kind !== "group" && kind !== "dm") return;
  uid = uid != null ? uid : (S.active && S.active.uid);
  const st = kind === "group" ? S.group : dmOf(uid);
  try {
    const j = await api(kind === "group" ? "/pins/group" : "/pins/dm/" + uid);
    if (X.ready) await Promise.race([X.ready, delay(8000)]);
    await hydrateAll(j.pins); j.pins.forEach(x => upsertUser(x.user));
    st.pins = j.pins; st.pinIdx = null;
  } catch (_) { return; }
  if (pinSt() === st) { renderPinBar(); markPins(); }
}
function pinsOnEvent(m) { if (m.scope === "g") pinsRefresh("group"); else pinsRefresh("dm", m.with); }
function pinDrop(id) {                                 // xabar o'chirilsa pin ham ketadi
  const all = [S.group].concat([...S.dms.values()]);
  all.forEach(st => { if (st.pins && st.pins.some(p => p.id === id)) st.pins = st.pins.filter(p => p.id !== id); });
  if (S.active) renderPinBar();
}
$("pinBarMain").addEventListener("click", pinBarClick);
$("pinX").addEventListener("click", e => { e.stopPropagation(); const st = pinSt(); if (!st || !st.pins) return; const m = st.pins[st.pinIdx != null ? st.pinIdx : st.pins.length - 1]; if (m && canPin(m)) togglePin(m); });
