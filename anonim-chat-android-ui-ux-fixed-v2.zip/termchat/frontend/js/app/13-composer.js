/* ---------------- yozish, tahrirlash ---------------- */
const MEN = {el: null, items: [], sel: 0, start: -1};
const inp = $("inp");
function autosize() { inp.style.height = "auto"; inp.style.height = Math.min(inp.scrollHeight, 140) + "px"; syncSend(); updateMention(); }
function syncSend() {
  $("sendBtn").classList.toggle("on", !!inp.value.trim() || !!S.pendingImg);
  $("composer").classList.toggle("has-text", !!inp.value.trim() || !!S.pendingImg || !!S.editing);   // matn bor: yuborish tugmasi, yo'q: mikrofon
}
inp.addEventListener("input", autosize);
inp.addEventListener("focus", () => setTimeout(() => { const b = $("msgs"); if (b._stick) b.scrollTop = b.scrollHeight; }, 320));
inp.addEventListener("keydown", e => {
  if (mentionKey(e)) return;
  if (e.key === "Enter" && !e.shiftKey && !COARSE && !e.isComposing) { e.preventDefault(); submit(); }
  else if (e.key === "Escape") { if (S.editing) cancelEdit(); else if (S.pendingImg) clearPendingImage(); else if (S.replying) cancelReply(); }
  else if (e.key === "ArrowUp" && !inp.value && S.active) {       // oxirgi o'z xabarini tahrirlash
    const mine = [...currentMsgs()].reverse().find(x => !x.service && x.user.id === S.me.id && !x.legacy && !x.bad && !x.locked);
    if (mine) { e.preventDefault(); startEdit(mine); }
  }
});
inp.addEventListener("paste", e => {                              // Ctrl+V bilan rasm qo'yish; kod/buyruq qo'yilsa — avtomatik ``` blokiga o'raladi
  const f = (e.clipboardData && e.clipboardData.files || [])[0];
  if (f) { e.preventDefault(); setPendingImage(f); return; }
  const txt = e.clipboardData && e.clipboardData.getData("text/plain");
  const whole = !inp.value.trim() || (inp.selectionStart === 0 && inp.selectionEnd === inp.value.length);
  if (!txt || !whole || S.editing) return;
  const fz = Rich.fenceFor(txt.replace(/\r\n?/g, "\n"));
  if (!fz || fz.text.length > inp.maxLength) return;
  e.preventDefault();
  inp.value = fz.text; inp.setSelectionRange(fz.text.length, fz.text.length); autosize();
  toast("Aniqlandi: " + fz.label + ". Xavfsiz ko'rinishda yuboriladi", "ok");
});

/* @belgilash: yozish maydonida "@" dan keyin foydalanuvchilar ro'yxati chiqadi (tanlansa "@username " qo'yiladi) */
function mentionQuery() {
  const pos = inp.selectionStart;
  if (pos == null || pos !== inp.selectionEnd) return null;
  const m = /(?:^|[\s(])@([A-Za-z0-9_]{0,20})$/.exec(inp.value.slice(0, pos));
  return m ? {q: m[1].toLowerCase(), start: pos - m[1].length - 1, pos} : null;
}
function mentionCandidates(q) {
  const rank = u => { const un = u.username, nn = (u.nickname || "").toLowerCase(); return !q ? 1 : un.startsWith(q) ? 0 : nn.startsWith(q) ? 1 : un.includes(q) ? 2 : nn.includes(q) ? 3 : 9; };
  return S.members.map(m => U(m.id)).filter(u => u.id !== S.me.id && !u.deleted && !u.banned && u.username && rank(u) < 9)
    .sort((a, b) => rank(a) - rank(b) || (a.role === "owner" ? -1 : 0) - (b.role === "owner" ? -1 : 0) || a.username.localeCompare(b.username)).slice(0, 6);
}
function closeMention() { if (MEN.el) { MEN.el.remove(); MEN.el = null; } MEN.items = []; }
function pickMention(u) {
  const q = mentionQuery(); if (!q) { closeMention(); return; }
  const ins = "@" + u.username + " ";
  if (inp.value.length - (q.pos - q.start) + ins.length > inp.maxLength) { toast("Xabar juda uzun", "warn"); return; }
  inp.setRangeText(ins, q.start, q.pos, "end"); closeMention(); autosize();
  if (!COARSE) inp.focus({preventScroll: true});
}
function paintMention() {
  if (!MEN.el) { MEN.el = h("div", {class: "mention-panel", role: "listbox", "aria-label": "Foydalanuvchini belgilash"}); MEN.el.addEventListener("mousedown", e => e.preventDefault()); document.body.append(MEN.el); }
  MEN.el.textContent = "";
  MEN.items.forEach((u, i) => {
    const b = h("button", {class: "mn-i" + (i === MEN.sel ? " on" : ""), type: "button", role: "option", "aria-selected": String(i === MEN.sel)},
      avatar(u, "s"), h("div", {class: "mn-t"}, h("b", {}, nameEl(u)), h("small", {text: "@" + u.username})));
    b.addEventListener("click", () => pickMention(u));
    MEN.el.append(b);
  });
  const r = inp.getBoundingClientRect(), w = Math.min(320, innerWidth - 16);
  MEN.el.style.width = w + "px"; MEN.el.style.left = Math.max(8, Math.min(r.left, innerWidth - w - 8)) + "px"; MEN.el.style.bottom = Math.max(8, innerHeight - r.top + 8) + "px";
}
function updateMention() {
  const q = S.me && !S.editing ? mentionQuery() : null;
  const list = q ? mentionCandidates(q.q) : [];
  if (!list.length) { closeMention(); return; }
  const same = MEN.items.length === list.length && MEN.items.every((u, i) => u.id === list[i].id);
  MEN.items = list; if (!same) MEN.sel = 0;
  paintMention();
}
function mentionKey(e) {                              // ro'yxat ochiq bo'lsa: ↑ ↓ Tab Enter Esc
  if (!MEN.el || !MEN.items.length || e.isComposing) return false;
  const n = MEN.items.length;
  if (e.key === "ArrowDown" || e.key === "ArrowUp") { e.preventDefault(); MEN.sel = (MEN.sel + (e.key === "ArrowDown" ? 1 : n - 1)) % n; paintMention(); return true; }
  if (e.key === "Tab" || (e.key === "Enter" && !e.shiftKey && !COARSE)) { e.preventDefault(); pickMention(MEN.items[MEN.sel]); return true; }
  if (e.key === "Escape") { e.preventDefault(); closeMention(); return true; }
  return false;
}
inp.addEventListener("keyup", e => { if (e.key === "ArrowLeft" || e.key === "ArrowRight" || e.key === "Home" || e.key === "End") updateMention(); });
inp.addEventListener("click", updateMention);
inp.addEventListener("blur", () => setTimeout(closeMention, 150));
$("sendBtn").addEventListener("click", submit);

function startEdit(m) {
  cancelReply(); clearPendingImage();
  S.editing = m; inp.value = m.content; autosize(); inp.focus();
  $("ebText").textContent = m.content ? m.content.replace(/\s+/g, " ") : (m.file ? (m.file.voice ? "🎤 Ovozli xabar izohi" : m.file.vnote ? "📹 Video xabar izohi" : "📎 Fayl izohi") : "📷 Rasm izohi");
  $("editbar").classList.remove("hidden");
}
function cancelEdit() {
  if (!S.editing) return;
  S.editing = null; inp.value = ""; autosize(); $("editbar").classList.add("hidden");
}
$("ebCancel").addEventListener("click", cancelEdit);

function startReply(m) {
  if (m.ch) return;                                   // kanal postlariga javob yo'q: izoh qoldiriladi
  cancelEdit();
  S.replying = replyInfo(m);
  $("rbName").textContent = m.user.nickname;
  $("rbText").textContent = (m.image ? "📷 " : m.file ? fileIco(m.file) : "") + (m.content ? m.content.replace(/\s+/g, " ") : (m.file ? fileWhat(m.file) : "Rasm"));
  $("replybar").classList.remove("hidden");
  inp.focus();
}
function cancelReply() { S.replying = null; $("replybar").classList.add("hidden"); }
$("rbCancel").addEventListener("click", cancelReply);

/* ---- rasm yuborish (izoh bilan) ---- */
const IMG_TYPES = ["image/png", "image/jpeg", "image/webp", "image/gif"], MAX_MEDIA = 50 * 1024 * 1024;
async function shrinkImage(f) {              // katta fotolarni yuborishdan oldin kichraytiradi (GIF tegilmaydi)
  if (f.type === "image/gif" || f.size <= 1.5 * 1024 * 1024 || !self.createImageBitmap) return f;
  try {
    const bmp = await createImageBitmap(f), k = Math.min(1, 1920 / Math.max(bmp.width, bmp.height));
    const c = document.createElement("canvas"); c.width = Math.round(bmp.width * k); c.height = Math.round(bmp.height * k);
    const g = c.getContext("2d"); g.fillStyle = "#fff"; g.fillRect(0, 0, c.width, c.height); g.drawImage(bmp, 0, 0, c.width, c.height);
    const blob = await new Promise(r => c.toBlob(r, "image/jpeg", 0.85));
    return blob && blob.size < f.size ? blob : f;
  } catch (_) { return f; }
}
async function setPendingImage(file) {              // istalgan turdagi fayl (50 MB gacha)
  if (!S.active || !file) return;
  if (S.active.kind === "group" && S.chat.locked && !amAdmin()) { toast("Umumiy chat qulflangan", "error"); return; }
  const isImg = IMG_TYPES.includes(file.type);
  const blob = isImg ? await shrinkImage(file) : file;
  if (blob.size > MAX_MEDIA) { toast("Fayl 50 MB dan oshmasligi kerak", "error"); return; }
  if (!blob.size) { toast("Fayl bo'sh", "error"); return; }
  cancelEdit(); clearPendingImage();
  const ext = blob.type === "image/jpeg" ? "jpg" : (blob.type.split("/")[1] || "png");
  S.pendingImg = {blob, isImg, url: isImg ? URL.createObjectURL(blob) : null, name: isImg ? "rasm." + ext : (file.name || "fayl")};
  $("ibThumb").classList.toggle("hidden", !isImg); $("ibIcon").classList.toggle("hidden", isImg);
  if (isImg) $("ibThumb").src = S.pendingImg.url; else $("ibThumb").removeAttribute("src");
  $("ibTitle").textContent = isImg ? "Rasm" : S.pendingImg.name;
  $("ibInfo").textContent = "Izoh yozib yuboring (ixtiyoriy) • " + fmtSize(blob.size);
  $("imgbar").classList.remove("hidden");
  syncSend(); inp.focus();
}
function clearPendingImage() {
  if (S.pendingImg && S.pendingImg.url) URL.revokeObjectURL(S.pendingImg.url);
  S.pendingImg = null; $("ibThumb").removeAttribute("src"); $("imgbar").classList.add("hidden"); syncSend();
}
$("attachBtn").addEventListener("click", () => $("imgFile").click());
$("imgFile").addEventListener("change", () => { const f = $("imgFile").files[0]; $("imgFile").value = ""; if (f) setPendingImage(f); });
$("ibCancel").addEventListener("click", clearPendingImage);
["dragenter", "dragover"].forEach(ev => $("chat").addEventListener(ev, e => { if (e.dataTransfer && [...e.dataTransfer.types].includes("Files")) { e.preventDefault(); $("chat").classList.add("drop"); } }));
["dragleave", "drop"].forEach(ev => $("chat").addEventListener(ev, e => { if (ev === "dragleave" && $("chat").contains(e.relatedTarget)) return; $("chat").classList.remove("drop"); }));
$("chat").addEventListener("drop", e => { const f = e.dataTransfer && e.dataTransfer.files[0]; if (f) { e.preventDefault(); setPendingImage(f); } });

async function sendImage(caption) {
  if (S.sending) return;
  S.sending = true; $("sendBtn").disabled = true;
  const img = S.pendingImg, keep = $("ibInfo").textContent;
  try {
    const ctx = await keyForActive();
    $("ibInfo").textContent = "Shifrlanmoqda…";
    let blob = img.blob, f = {name: img.name, mime: blob.type || "application/octet-stream", size: blob.size, img: false};
    if (img.isImg) { const c = await cleanImage(blob); blob = c.blob; f = Object.assign(f, {mime: blob.type || f.mime, size: blob.size, img: true, w: c.w, h: c.h, th: c.th}); }
    const e = await E2E.encryptFile(new Uint8Array(await blob.arrayBuffer()));
    f.k = e.key;
    $("ibInfo").textContent = "Yuborilmoqda… (" + fmtSize(e.blob.length) + ")";
    const r = await SC.fetch("/api/e2ee/blob", {method: "POST", headers: {Authorization: "Bearer " + S.token, "Content-Type": "application/octet-stream"}, body: e.blob});
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(typeof j.detail === "string" ? j.detail : "Fayl yuklanmadi");
    const payload = {t: caption, f}; if (S.replying) payload.r = S.replying;
    const msg = {type: "send", e2e: await sealFor(ctx, payload), blob: j.blob};
    withTarget(msg, S.active);
    if (!wsSend(msg)) throw new Error("Ulanish yo'q");
    inp.value = ""; clearPendingImage(); cancelReply(); autosize();
  } catch (err) { toast(err.message, "error"); if (S.pendingImg) $("ibInfo").textContent = keep; }
  S.sending = false; $("sendBtn").disabled = false;
}
async function submit() {
  const text = inp.value.trim();
  if (!S.active || S.sending) return;
  if (S.active.kind === "dm" && U(S.active.uid).deleted) { toast("Bu akkaunt o'chirilgan. Xabar yuborib bo'lmaydi", "error"); return; }
  if (S.pendingImg) { sendImage(text); return; }
  if (!S.editing && !text) return;
  if (S.editing && !text && !S.editing._f) return;
  if (S.editing && text === S.editing.content) { cancelEdit(); return; }
  S.sending = true;
  try {
    const ctx = await keyForActive(), payload = {t: text};
    if (S.editing) {                                                // tahrir: javob va fayl ma'lumoti saqlanadi, matn almashadi
      const m = S.editing;
      if (m._r) payload.r = m._r; if (m._f) payload.f = m._f; if (m._fw) payload.fw = m._fw;
      if (wsSend({type: "edit", id: m.id, e2e: await sealFor(ctx, payload)})) cancelEdit();
    } else {
      if (S.replying) payload.r = S.replying;
      const msg = {type: "send", e2e: await sealFor(ctx, payload)};
      withTarget(msg, S.active);
      if (wsSend(msg)) { inp.value = ""; cancelReply(); autosize(); inp.focus(); }
    }
  } catch (err) { toast(err.message, "error"); }
  S.sending = false;
}
