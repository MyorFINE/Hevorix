function askDialog({title, text, okText = "OK", cancelText = "Bekor qilish", danger = false, input = null, alertOnly = false, check = null}) {
  return new Promise(resolve => {
    const root = $("dlg"), prevFocus = document.activeElement;
    let field = null, cb = null;
    const done = v => {
      if (done.d) return; done.d = true; S.dlgCancel = null; navPop("dlg");
      root.classList.add("hidden"); root.setAttribute("aria-hidden", "true"); root.textContent = "";
      document.removeEventListener("keydown", onKey, true);
      if (prevFocus && prevFocus.focus) try { prevFocus.focus(); } catch (_) {}
      resolve(v);
    };
    const ok = () => done(input ? field.value : check ? {checked: !!(cb && cb.checked)} : true);
    const cancel = () => done(input ? null : false);
    const onKey = e => {
      if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); cancel(); }
      else if (e.key === "Enter" && !(e.target && e.target.tagName === "BUTTON")) { e.preventDefault(); e.stopPropagation(); ok(); }
    };
    const card = h("div", {class: "dlg-card", role: alertOnly ? "alertdialog" : "dialog", "aria-modal": "true"});
    if (title) card.append(h("h3", {class: "dlg-t", text: title}));
    if (text) card.append(h("p", {class: "dlg-m", text}));
    if (input) { field = h("input", {class: "dlg-in", type: input.type || "text", autocomplete: "off", spellcheck: "false", placeholder: input.placeholder || ""}); field.value = input.value || ""; card.append(field); }
    if (check) { cb = h("input", {type: "checkbox", class: "dlg-cb-i"}); cb.checked = !!check.checked; card.append(h("label", {class: "dlg-cb"}, cb, h("span", {text: check.label}))); }
    const btns = h("div", {class: "dlg-b"});
    if (!alertOnly) btns.append(h("button", {class: "dlg-btn", type: "button", text: cancelText, onclick: cancel}));
    const okBtn = h("button", {class: "dlg-btn" + (danger ? " danger" : ""), type: "button", text: okText, onclick: ok});
    btns.append(okBtn); card.append(btns);
    root.textContent = ""; root.append(card);
    root.onmousedown = root.onclick = e => { if (e.target === root) cancel(); };
    root.classList.remove("hidden"); root.setAttribute("aria-hidden", "false");
    S.dlgCancel = cancel; navPush("dlg");
    document.addEventListener("keydown", onKey, true);
    setTimeout(() => { (field || okBtn).focus(); if (field) field.select(); }, 30);
  });
}
const confirmDlg = (text, o = {}) => askDialog({title: o.title, text, okText: o.okText || "OK", danger: !!o.danger});
const promptDlg = (title, text, value = "", o = {}) => askDialog({title, text, input: {value, placeholder: o.placeholder, type: o.type}, okText: o.okText || "OK", danger: !!o.danger});

document.addEventListener("contextmenu", e => {
  if (e.target.closest && e.target.closest("input, textarea")) return;
  e.preventDefault();
  if (!e.target.closest(".bubble")) closeCtx();
});

function showModal(node) {
  const sheet = $("sheet"), top = sheet.scrollTop;
  sheet.textContent = ""; sheet.append(node);
  $("modal").classList.remove("hidden");
  sheet.scrollTop = top;
}
function openModal(build, live, wide, fit) { if ($("modal").classList.contains("hidden")) navPush("modal"); S.modal = {build, live: !!live, at: performance.now()}; $("sheet").classList.toggle("wide", !!wide); $("sheet").classList.toggle("fit", !!fit); $("sheet").classList.remove("tgp"); showModal(build()); }
function closeModal() { const was = !$("modal").classList.contains("hidden"); S.modal = null; clearTimeout(_rmTimer); _rmTimer = 0; $("modal").classList.add("hidden"); $("sheet").classList.remove("wide", "fit", "tgp"); $("sheet").textContent = ""; if (was) navPop("modal"); }

let _rmTimer = 0;
function refreshModal() {
  refreshPages();
  if (!S.modal || !S.modal.live) return;
  if (_rmTimer) return;
  const wait = Math.max(150, 450 - (performance.now() - S.modal.at));
  _rmTimer = setTimeout(() => { _rmTimer = 0; if (S.modal && S.modal.live) requestAnimationFrame(() => { if (S.modal && S.modal.live) showModal(S.modal.build()); }); }, wait);
}
$("modal").addEventListener("mousedown", e => { if (e.target === $("modal")) closeModal(); });
$("modal").addEventListener("click", e => { if (e.target === $("modal")) closeModal(); });
function setPageZoom(on) {
  const v = document.querySelector('meta[name="viewport"]'); if (!v) return;
  v.setAttribute("content", "width=device-width, initial-scale=1, viewport-fit=cover, interactive-widget=resizes-content" + (on ? "" : ", maximum-scale=1, user-scalable=no"));
}
["gesturestart", "gesturechange", "gestureend"].forEach(t => document.addEventListener(t, e => { if (!e.target.closest || !e.target.closest("#lightbox")) e.preventDefault(); }, {passive: false}));
document.addEventListener("dblclick", e => { if (e.target.closest && e.target.closest(".modal,.dlg,.sheet,.ctx")) e.preventDefault(); });
function openLightbox(url) { setPageZoom(true); $("lbImg").src = url; $("lightbox").classList.remove("hidden"); navPush("lb"); }
function closeLightbox() { setPageZoom(false); const was = !$("lightbox").classList.contains("hidden"); $("lightbox").classList.add("hidden"); $("lbImg").removeAttribute("src"); if (was) navPop("lb"); }
$("lightbox").addEventListener("click", closeLightbox);

const AVV = {el: null, closing: false, uid: null, g: null};
const AV_EASE = "cubic-bezier(.22,.9,.28,1)";
function zoomAvatar(el, u) {
  if (!u.avatar) return el;
  el.classList.add("av-zoom"); el.dataset.uid = String(u.id);
  el.setAttribute("role", "button"); el.tabIndex = 0; el.setAttribute("aria-label", "Profil rasmini kattalashtirish");
  el.addEventListener("click", e => { e.stopPropagation(); openAvatarViewer(el, u); });
  el.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); openAvatarViewer(el, u); } });
  return el;
}
function avSource(uid) {
  const pg = PG.list[PG.list.length - 1];
  return (pg ? pg.el : document).querySelector('.av-zoom[data-uid="' + uid + '"]');
}
const avReduce = () => matchMedia("(prefers-reduced-motion: reduce)").matches || document.documentElement.classList.contains("no-ui-anim");
function avFrom(g, sr) {
  return "translate(" + (sr.left - g.fx) + "px," + (sr.top - g.fy) + "px) scale(" + (sr.width / g.side) + ")";
}
function openAvatarViewer(src, u) {
  if (AVV.el || !u.avatar) return;
  const vv = window.visualViewport, vw = Math.round(vv ? vv.width : innerWidth), vh = Math.round(vv ? vv.height : innerHeight);
  const mobile = vw <= 600, side = Math.round(Math.min(vw, vh * (mobile ? 0.8 : 0.78), 560));
  const g = {side, fx: Math.round((vw - side) / 2), fy: Math.round((vh - side) / 2 - (mobile ? 0 : 10)), endR: mobile ? "0%" : "3%"};
  const sr = src.getBoundingClientRect(), reduce = avReduce();
  const back = h("div", {class: "avv-back"});
  const img = h("img", {src: u.avatar, alt: "", draggable: "false", decoding: "async"});
  const box = h("div", {class: "avv-box"}, img);
  box.style.left = g.fx + "px"; box.style.top = g.fy + "px"; box.style.width = side + "px"; box.style.height = side + "px"; box.style.borderRadius = g.endR; box.style.transformOrigin = "0 0";
  const xb = h("button", {class: "avv-x", type: "button", "aria-label": "Yopish"}, icon("close"));
  const top = h("div", {class: "avv-top"}, h("div", {class: "avv-cap"}, h("b", {text: u.nickname || "@" + u.username}), h("small", {text: "@" + u.username + " • " + statusText(u)})), xb);
  const root = h("div", {class: "avv", role: "dialog", "aria-label": "Profil rasmi"}, back, box, top);
  Object.assign(AVV, {el: root, closing: false, uid: u.id, g, box, back, top});
  document.body.append(root);
  src.classList.add("av-hide");
  navPush("avv");
  if (!reduce) {
    box.animate([{transform: avFrom(g, sr), borderRadius: "50%"}, {transform: "none", borderRadius: g.endR}], {duration: 360, easing: AV_EASE});
    back.animate([{opacity: 0}, {opacity: 1}], {duration: 260, easing: "ease-out"});
    top.animate([{opacity: 0}, {opacity: 0, offset: .45}, {opacity: 1}], {duration: 420, easing: "ease-out"});
  } else back.animate([{opacity: 0}, {opacity: 1}], {duration: 120});

  let d = null;
  const dragTo = dy => {
    const k = 1 - Math.min(Math.abs(dy) / 1100, 0.22);
    box.style.transform = "translateY(" + dy + "px) scale(" + k + ")"; box.style.transformOrigin = "50% 50%";
    const o = 1 - Math.min(Math.abs(dy) / 380, 0.75); back.style.opacity = String(o); top.style.opacity = String(Math.max(0, 1 - Math.abs(dy) / 120));
  };
  root.addEventListener("pointerdown", e => {
    if (AVV.closing || e.target.closest(".avv-x") || (e.pointerType === "mouse" && e.button !== 0)) return;
    d = {y: e.clientY, t: e.timeStamp, dy: 0, moved: false, v: 0, ly: e.clientY, lt: e.timeStamp};
    try { root.setPointerCapture(e.pointerId); } catch (_) {}
  });
  root.addEventListener("pointermove", e => {
    if (!d) return;
    d.dy = e.clientY - d.y;
    if (!d.moved && Math.abs(d.dy) > 8) d.moved = true;
    const dt = e.timeStamp - d.lt; if (dt > 0) { d.v = (e.clientY - d.ly) / dt; d.ly = e.clientY; d.lt = e.timeStamp; }
    if (d.moved) dragTo(d.dy);
  });
  const end = e => {
    if (!d) return; const x = d; d = null;
    if (e.type === "pointercancel") x.moved = x.moved && Math.abs(x.dy) > 8;
    if (!x.moved) { if (e.type === "pointerup") closeAvatarViewer(); return; }
    if (Math.abs(x.dy) > 110 || Math.abs(x.v) > 0.7) { closeAvatarViewer(false, true); return; }
    const cur = box.style.transform;
    box.style.transform = ""; box.style.transformOrigin = "0 0";
    box.animate([{transform: cur, transformOrigin: "50% 50%"}, {transform: "none", transformOrigin: "50% 50%"}], {duration: 260, easing: "cubic-bezier(.3,1.35,.5,1)"});
    back.animate([{opacity: back.style.opacity || 1}, {opacity: 1}], {duration: 200}); back.style.opacity = ""; top.style.opacity = "";
  };
  root.addEventListener("pointerup", end); root.addEventListener("pointercancel", end);
  xb.addEventListener("click", e => { e.stopPropagation(); closeAvatarViewer(); });
  xb.focus({preventScroll: true});
}
function closeAvatarViewer(fromNav, dragged) {
  const root = AVV.el; if (!root || AVV.closing) return;
  AVV.closing = true;
  if (!fromNav) navPop("avv");
  const {box, back, top, g} = AVV, src = avSource(AVV.uid);
  const done = () => { root.remove(); if (AVV.el === root) { AVV.el = null; AVV.closing = false; } document.querySelectorAll(".av-hide").forEach(x => x.classList.remove("av-hide")); };
  const bo = parseFloat(back.style.opacity || "1");
  back.animate([{opacity: bo}, {opacity: 0}], {duration: 260, easing: "ease-in", fill: "forwards"});
  top.animate([{opacity: parseFloat(top.style.opacity || "1")}, {opacity: 0}], {duration: 140, fill: "forwards"});
  const sr = src ? src.getBoundingClientRect() : null, vh = innerHeight;
  const visible = sr && sr.width > 0 && sr.bottom > 0 && sr.top < vh;
  if (avReduce()) { setTimeout(done, 120); return; }
  const cur = getComputedStyle(box).transform, curT = cur && cur !== "none" ? cur : "none";
  box.style.transformOrigin = dragged ? "50% 50%" : "0 0";
  if (visible && !dragged) {
    const a = box.animate([{transform: curT, borderRadius: g.endR}, {transform: avFrom(g, sr), borderRadius: "50%"}], {duration: 300, easing: "cubic-bezier(.4,.1,.2,1)", fill: "forwards"});
    a.onfinish = done;
  } else if (visible) {
    box.style.transformOrigin = "0 0";

    const bx = box.getBoundingClientRect();
    const k0 = bx.width / g.side, from = "translate(" + (bx.left - g.fx) + "px," + (bx.top - g.fy) + "px) scale(" + k0 + ")";
    box.style.transform = "none";
    const a = box.animate([{transform: from, borderRadius: g.endR}, {transform: avFrom(g, sr), borderRadius: "50%"}], {duration: 280, easing: "cubic-bezier(.4,.1,.2,1)", fill: "forwards"});
    a.onfinish = done;
  } else {
    const a = box.animate([{transform: curT, opacity: 1}, {transform: (curT === "none" ? "" : curT + " ") + "scale(.85)", opacity: 0}], {duration: 240, easing: "ease-in", fill: "forwards"});
    a.onfinish = done;
  }
}
document.addEventListener("keydown", e => {
  if (e.key !== "Escape") return;
  if (AVV.el) closeAvatarViewer();
  else if (!$("lightbox").classList.contains("hidden")) closeLightbox();
  else if (S.sel && !S.modal && $("ctx").classList.contains("hidden")) exitSelect();
  else if (!$("ctx").classList.contains("hidden")) closeCtx();
  else if (S.modal) closeModal();
  else if (PG.list.length) closePage();
  else if (drawerIsOpen()) closeDrawer();
});

function sheetHead(title, onBack) {
  return h("div", {class: "sh-head"},
    onBack ? h("button", {class: "icon-btn", type: "button", onclick: onBack, "aria-label": "Orqaga"}, icon("back")) : null,
    h("span", {text: title}),
    h("button", {class: "icon-btn", type: "button", onclick: closeModal, "aria-label": "Yopish"}, icon("close")));
}

