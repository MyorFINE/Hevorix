/* ---------------- 30-offline.js: OFLAYN REJIM ----------------
   Internet yo'q paytda oldin yuklangan xabarlar, profillar va "last seen" ni o'qish mumkin.
   Xavfsizlik (E2EE saqlanadi): xabarlar qurilmada FAQAT shifrlangan holda (AES-GCM, IndexedDB) turadi.
     - oddiy kirish:           kalit parol bilan PBKDF2 (200 000 iteratsiya) orqali hosil bo'ladi; oflayn ochishda parol so'raladi
     - "bu qurilmada kirib qolish" yoqilgan bo'lsa: qurilmaning o'zida chiqarib bo'lmaydigan (non-extractable) kalit, parol shart emas
   Oflayn rejim faqat o'qish uchun: yuborish/tahrirlash o'chirilgan, internet qaytganda qayta kirish (yoki avtomatik) bajariladi. */
const Off = (() => {
  const DB = "tc_offline", ST = "kv", LIM = {group: 150, dm: 100, dms: 60, ch: 60, chs: 30};
  const te = new TextEncoder(), td = new TextDecoder();
  let key = null, mode = "", timer = 0, saving = false, info = null;
  const idb = () => new Promise((res, rej) => {
    if (!window.indexedDB || !crypto || !crypto.subtle) return rej(new Error("IndexedDB yo'q"));
    const r = indexedDB.open(DB, 1);
    r.onupgradeneeded = () => r.result.createObjectStore(ST);
    r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
  });
  const run = (m, fn) => idb().then(db => new Promise((res, rej) => {
    const tx = db.transaction(ST, m), st = tx.objectStore(ST), rq = fn(st);
    tx.oncomplete = () => { db.close(); res(rq && rq.result); }; tx.onerror = tx.onabort = () => { db.close(); rej(tx.error); };
  }));
  const get = k => run("readonly", st => st.get(k)), set = (k, v) => run("readwrite", st => st.put(v, k)), del = k => run("readwrite", st => st.delete(k));
  async function pwKey(pass, salt) {
    const base = await crypto.subtle.importKey("raw", te.encode(pass), "PBKDF2", false, ["deriveKey"]);
    return crypto.subtle.deriveKey({name: "PBKDF2", hash: "SHA-256", salt, iterations: 200000}, base, {name: "AES-GCM", length: 256}, false, ["encrypt", "decrypt"]);
  }
  async function stayKey(create) {
    let k = null; try { k = await get("stayKey"); } catch (_) {}
    if (!k && create) { k = await crypto.subtle.generateKey({name: "AES-GCM", length: 256}, false, ["encrypt", "decrypt"]); await set("stayKey", k); }
    return k;
  }
  const tail = (a, n) => a.length > n ? a.slice(a.length - n) : a;
  const plain = (k, v) => (typeof v === "function" || (v && v.nodeType)) ? undefined : v;
  function slimMsgs(list) { return list.filter(m => m && !m.service && m.user).map(m => Object.assign({}, m, {user: m.user.id})); }
  function build() {
    const dms = [...S.dms.entries()].filter(([, d]) => d.msgs.length).sort((a, b) => (b[1].msgs.at(-1).ts || 0) - (a[1].msgs.at(-1).ts || 0)).slice(0, LIM.dms);
    const chs = [...S.chn.entries()].filter(([, c]) => c.msgs.length).slice(0, LIM.chs);
    return {
      v: 1, ts: Date.now(), me: S.me, chat: S.chat, chList: S.chList, members: S.members,
      users: [...S.users.values()].filter(u => u && u.id != null),
      group: {msgs: slimMsgs(tail(S.group.msgs, LIM.group)), more: !!S.group.more},
      dms: dms.map(([uid, d]) => [uid, slimMsgs(tail(d.msgs, LIM.dm)), !!d.more]),
      chn: chs.map(([id, c]) => [id, slimMsgs(tail(c.msgs, LIM.ch)), !!c.more]),
    };
  }
  async function save() {
    timer = 0;
    if (!key || !S.me || S.offline || saving || !S.token) return;
    saving = true;
    try {
      const iv = crypto.getRandomValues(new Uint8Array(12));
      const data = await crypto.subtle.encrypt({name: "AES-GCM", iv}, key, te.encode(JSON.stringify(build(), plain)));
      await set("snap", {v: 1, mode, user: String(S.me.username || "").toLowerCase(), nick: S.me.nickname, ts: Date.now(), iv, data});
      info = {mode, user: String(S.me.username || "").toLowerCase(), ts: Date.now()}; lastSig = sig(); lastAt = Date.now();
    } catch (_) {}
    saving = false;
  }
  let lastSig = "", lastAt = 0;
  const sig = () => {                                                 // arzon belgi: o'zgarmagan bo'lsa qayta saqlanmaydi (batareya va CPU tejaladi)
    let g = S.group.msgs.length + ":" + ((S.group.msgs[S.group.msgs.length - 1] || {}).id) + "|" + S.users.size + "|" + S.members.length;
    S.dms.forEach((d, k) => { g += "," + k + ":" + d.msgs.length + ":" + ((d.msgs[d.msgs.length - 1] || {}).id); });
    return g;
  };
  const dirty = () => {
    if (!key || S.offline || timer) return;
    const now = Date.now(); if (sig() === lastSig && now - lastAt < 300000) return;
    timer = setTimeout(save, Math.max(4000, 20000 - (now - lastAt)));
  };
  const flush = () => { if (!key || S.offline || !S.me) return; clearTimeout(timer); timer = 0; if (sig() !== lastSig || Date.now() - lastAt > 60000) save(); };
  async function arm({user, password, stay}) {                       // kirishdan keyin: kalitni tayyorlaydi (fonda, ishga xalaqit bermaydi)
    try {
      if (stay) { key = await stayKey(true); mode = "stay"; try { await del("meta"); } catch (_) {} }
      else {
        let meta = null; try { meta = await get("meta"); } catch (_) {}
        const same = meta && meta.user === String(user).toLowerCase() && meta.salt;
        const salt = same ? meta.salt : crypto.getRandomValues(new Uint8Array(16));
        if (!same) { try { await del("snap"); } catch (_) {} }          // boshqa akkaunt: eski nusxa o'chadi
        key = await pwKey(password, salt); mode = "pw";
        await set("meta", {user: String(user).toLowerCase(), salt});
        try { await del("stayKey"); } catch (_) {}
      }
      dirty();
    } catch (_) { key = null; }
  }
  async function armStay() {                                         // "kirib qolish": sessiya tiklanganda yoki yoqilganda
    try { key = await stayKey(true); mode = "stay"; try { await del("meta"); } catch (_) {} dirty(); } catch (_) { key = null; }
  }
  async function disarmStay() {
    if (mode === "stay") { key = null; mode = ""; }
    try { const r = await get("snap"); await del("stayKey"); if (r && r.mode === "stay") { await del("snap"); info = null; } } catch (_) {}      // parol bilan shifrlangan nusxaga tegilmaydi
    showBtn();
  }
  async function wipe() { key = null; mode = ""; info = null; clearTimeout(timer); timer = 0; try { await del("snap"); await del("meta"); await del("stayKey"); } catch (_) {} showBtn(); }
  async function probe() {
    try { const r = await get("snap"); info = r ? {mode: r.mode, user: r.user, ts: r.ts} : null; } catch (_) { info = null; }
    showBtn();
  }
  function showBtn() { const b = $("offBtn"); if (b) { b.classList.toggle("hidden", !info); b.querySelector("span").textContent = info && info.mode === "pw" ? "Oflayn ko'rish (parol kerak)" : "Oflayn ko'rish"; } }

  async function open() {                                            // auth ekranidagi "Oflayn ko'rish"
    const err = $("autherr"); err.textContent = "";
    let rec = null; try { rec = await get("snap"); } catch (_) {}
    if (!rec) { err.textContent = "Oflayn xotira yo'q: avval internet bilan bir marta kiring."; return; }
    let k = null;
    try {
      if (rec.mode === "stay") k = await stayKey(false);
      else {
        const user = $("f_user").value.trim().replace(/^@/, "").toLowerCase(), pass = $("f_pass").value;
        if (!pass) { err.textContent = "Oflayn ochish uchun parolni kiriting (xabarlar parol bilan shifrlangan)."; return; }
        if (user && user !== rec.user) { err.textContent = "Bu qurilmadagi oflayn xotira boshqa akkauntniki."; return; }
        const meta = await get("meta");
        if (!meta || !meta.salt) { err.textContent = "Oflayn xotira buzilgan. Internet bilan qayta kiring."; return; }
        err.textContent = "Ochilmoqda…"; await new Promise(r => setTimeout(r, 30));
        k = await pwKey(pass, meta.salt);
      }
      if (!k) throw new Error("kalit yo'q");
      const snap = JSON.parse(td.decode(await crypto.subtle.decrypt({name: "AES-GCM", iv: rec.iv}, k, rec.data)));
      apply(snap, rec);
    } catch (_) { err.textContent = rec.mode === "pw" ? "Parol noto'g'ri yoki oflayn xotira buzilgan." : "Oflayn xotirani ochib bo'lmadi. Internet bilan kiring."; }
  }
  function apply(snap, rec) {
    resetState(); S.offline = true; S.token = null;
    S.me = snap.me; snap.users.forEach(u => S.users.set(u.id, u)); upsertUser(snap.me);
    S.members = snap.members || []; S.chat = snap.chat || {slowmode: 0, locked: false};
    const back = list => list.map(m => Object.assign(m, {user: S.users.get(m.user) || U(m.user)}));
    S.group.msgs = back(snap.group.msgs); S.group.more = false; S.chList = [];            // kanallar oflayn ochilmaydi (ular serverga bog'liq)
    snap.dms.forEach(([uid, msgs]) => { const d = dmOf(uid); d.msgs = back(msgs); d.loaded = true; d.more = false; d.last = d.msgs[d.msgs.length - 1] || null; });
    $("auth").classList.add("hidden"); $("app").classList.remove("hidden");
    document.querySelectorAll(".tabs button").forEach(x => x.classList.toggle("on", x.dataset.tab === "chats"));
    $("chat").classList.add("hidden"); $("empty").classList.remove("hidden");
    document.body.classList.add("offline-mode");
    const cb = $("connbar"); cb.textContent = "📴 Oflayn rejim — faqat o'qish • oxirgi yangilanish: " + fmtDT(Math.floor((snap.ts || rec.ts) / 1000)); cb.classList.remove("hidden");
    $("f_pass").value = ""; renderList();
    if (!isMobile()) openChat({kind: "group"});
  }
  function leave() {                                                 // internet qaytdi
    if (!S.offline) return;
    S.offline = false; document.body.classList.remove("offline-mode"); $("connbar").textContent = "Ulanish uzildi, qayta ulanmoqda…";
    let tok = ""; try { tok = localStorage.getItem(LS_STAY) || ""; } catch (_) {}
    if (tok) { closeChat(); resumeStay(tok, 0); } else showAuth("Internet qaytdi. Yangilash uchun qayta kiring.");
  }
  addEventListener("online", () => { if (S.offline) setTimeout(leave, 600); });
  document.addEventListener("visibilitychange", () => { if (document.hidden) flush(); });
  addEventListener("pagehide", flush);
  $("offBtn").addEventListener("click", open);
  probe();
  return {arm, armStay, disarmStay, wipe, dirty, probe, open, leave, save, get info() { return info; }};
})();
