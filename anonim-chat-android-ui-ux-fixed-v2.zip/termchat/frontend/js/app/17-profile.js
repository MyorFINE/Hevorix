/* ---------- profil ---------- */
function openProfile(uid) {
  if (!S.users.has(uid)) loadMembers();
  openPage(() => profileView(uid), true);
}

function mediaStats(uid) {                              // faqat yuklangan xabarlar bo'yicha (E2EE: server ko'ra olmaydi); tarixning davomi bo'lsa "+" qo'yiladi
  const dm = S.dms.get(uid);
  if (!dm || !dm.loaded) return null;
  const st = {img: 0, voice: 0, vnote: 0, file: 0, more: !!dm.more};
  dm.msgs.forEach(m => {
    if (m.deleted) return;
    if (m.image) st.img++;
    else if (m.file) { if (m.file.voice) st.voice++; else if (m.file.vnote) st.vnote++; else st.file++; }
  });
  return st;
}
function tgRow(ic, text) { return h("div", {class: "tg-row"}, icon(ic), h("span", {text})); }
function infoRow(label, value, wide) { return h("div", {class: "info-r" + (wide ? " wide" : "")}, h("small", {text: label}), h("div", {text: value})); }
function profileView(uid) {
  const u = U(uid), me = u.id === S.me.id;
  const wrap = h("div", {});
  if (u.deleted) {
    const bn = h("div", {class: "pbanner gone"});
    bn.append(h("button", {class: "pbtn l", type: "button", onclick: () => closePage(), "aria-label": "Orqaga"}, icon("back")));
    bn.append(h("button", {class: "pbtn r", type: "button", onclick: closeAllPages, "aria-label": "Yopish"}, icon("close")));
    wrap.append(bn, h("div", {class: "pbody"}, avatar(u, "l"),
      h("div", {class: "pname"}, nameEl(u, {big: true})),
      h("div", {class: "pstat", text: "Bu akkaunt o'chirilgan"}),
      h("div", {class: "gone-note", text: "Yozgan xabarlari chatda qoladi. Unga xabar yuborib bo'lmaydi."})));
    return wrap;
  }
  const top = tint(h("div", {class: "tg-top" + (isStaff(u) ? " prem " + u.role : "") + bannerCls(u)}), u);
  top.append(h("button", {class: "tg-back", type: "button", onclick: () => closePage(), "aria-label": "Orqaga"}, icon("back")),
    me ? h("button", {class: "tg-edit", type: "button", onclick: openInfoPage, "aria-label": "Profilni tahrirlash"}, icon("edit")) : "",
    zoomAvatar(avatar(u, "l"), u),
    h("div", {class: "pname"}, nameEl(u, {big: true})),
    titleEl(u),
    h("div", {class: "pstat" + (isOnline(u.id) ? " on" : ""), text: statusText(u)}));
  if (isStaff(u)) top.append(tint(h("div", {class: "chip prem " + u.role}, hasEmoji(u) ? badge(u) : (u.badge === "none" ? null : icon(u.role === "owner" ? "shield" : "check", "ic vb")), roleLabel(u.role)), u));
  else if (hasEmoji(u)) top.append(h("div", {class: "chip"}, badge(u), "Maxsus nishon"));
  else if (isVerified(u)) top.append(h("div", {class: "chip"}, badge(u), "Tasdiqlangan foydalanuvchi"));
  if (u.new && !isStaff(u)) top.append(h("div", {class: "chip warn", text: "⚠ Yangi foydalanuvchi — hali ishonish qiyin"}));
  wrap.append(top);

  const acts = h("div", {class: "tg-acts"});
  const act = (ic, label, fn, on) => h("button", {class: "tg-act" + (on ? " on" : ""), type: "button", onclick: fn, "aria-pressed": on == null ? null : String(!!on)}, icon(ic), h("span", {text: label}));
  if (!me) {
    acts.append(act("chat", "Xabar", () => { closeAllPages(); openChat({kind: "dm", uid: u.id}); }));
    const muted = isMuted(u.id);
    acts.append(act(muted ? "bell-off" : "bell", muted ? "Ovoz yoq" : "Mute", () => {
      const on = toggleMute(u.id);
      toast(on ? "Bu suhbat ovozi o'chirildi (shu qurilmada)" : "Suhbat ovozi yoqildi", "ok");
      repaintTopPage();
    }, muted));
  }
  if (!me) wrap.append(acts);
  wrap.append(h("div", {class: "tg-gap"}));

  const info = h("div", {class: "tg-info"});
  const copyRow = (val, label, copy) => h("div", {class: "tg-row copy", role: "button", tabindex: "0", title: "Nusxalash",
    onclick: () => copyText(copy), onkeydown: e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); copyText(copy); } }},
    h("div", {class: "tg-val", text: val}), h("div", {class: "tg-lab", text: label}));
  const pnc = neonOf(u), glow = el => { if (pnc) { el.classList.add("neon-tx"); el.style.setProperty("--neon", pnc); } return el; };       // admin bergan neon: username va bio ham yonadi
  const unRow = copyRow("@" + u.username, "Username", "@" + u.username); glow(unRow.firstChild);
  info.append(unRow);
  if (u.bio) info.append(h("div", {class: "tg-row copy"}, glow(h("div", {class: "tg-bio"}, Rich.inline(u.bio, LINKCTX))), h("div", {class: "tg-lab", text: "Bio"})));
  if (u.joined) { const d = new Date(u.joined * 1000); info.append(h("div", {class: "tg-row copy"}, h("div", {text: d.getDate() + "-" + MONTHS[d.getMonth()] + " " + d.getFullYear()}), h("div", {class: "tg-lab", text: "Qo'shilgan"}))); }
  wrap.append(info);

  const st = me ? null : mediaStats(u.id);
  if (st && (st.img || st.voice || st.vnote || st.file)) {
    const plus = st.more ? "+" : "";
    const rows = h("div", {class: "tg-media"});
    if (st.img) rows.append(tgRow("attach", st.img + plus + " ta rasm"));
    if (st.voice) rows.append(tgRow("mic", st.voice + plus + " ta ovozli xabar"));
    if (st.vnote) rows.append(tgRow("videocam", st.vnote + plus + " ta video xabar"));
    if (st.file) rows.append(tgRow("file", st.file + plus + " ta fayl"));
    wrap.append(h("div", {class: "tg-gap"}), rows);
  }
  if (!me && amAdmin() && u.role !== "owner" && (u.role !== "admin" || S.me.role === "owner")) wrap.append(h("div", {class: "tg-gap"}), h("div", {class: "tg-modwrap"}, modPanel(u)));
  return wrap;
}
function modPanel(u) {
  const cmd = text => wsSend({type: "cmd", text});
  const panel = h("div", {class: "mod"}, h("h4", {}, icon("shield"), "Moderatsiya"));
  const flags = h("div", {class: "mod-r"});
  if (u.banned) flags.append(h("span", {class: "flag", text: "Ban qilingan"}));
  if (u.muted) flags.append(h("span", {class: "flag w", text: "Mute qilingan"}));
  if (u.warns) flags.append(h("span", {class: "warnflag", text: "Ogohlantirish: " + u.warns + "/3"}));
  if (flags.children.length) panel.append(flags);
  const dur = h("select", {}, h("option", {value: "10", text: "10 daqiqa"}), h("option", {value: "60", text: "1 soat"}),
    h("option", {value: "1440", text: "1 kun"}), h("option", {value: "perm", text: "Doimiy"}));
  panel.append(h("div", {class: "mod-r"}, dur,
    h("button", {class: "btn ghost sm", type: "button", onclick: () => cmd("/mute " + u.username + " " + dur.value)}, "Mute"),
    u.muted ? h("button", {class: "btn ghost sm", type: "button", onclick: () => cmd("/unmute " + u.username)}, "Unmute") : null));
  panel.append(h("div", {class: "mod-r"},
    h("button", {class: "btn ghost sm", type: "button", onclick: async () => {
      const why = await promptDlg("Ogohlantirish", "@" + u.username + " ga ogohlantirish (3 tadan keyin 1 soat mute). Sabab:", "", {okText: "Ogohlantirish"});
      if (why !== null) cmd("/warn " + u.username + " " + why);
    }}, "Ogohlantirish"),
    u.warns ? h("button", {class: "btn ghost sm", type: "button", onclick: () => cmd("/unwarn " + u.username)}, "Olib tashlash") : null,
    h("button", {class: "btn ghost sm", type: "button", onclick: async () => {
      if (await confirmDlg("@" + u.username + " ning umumiy chatdagi oxirgi xabarlari (va fayllari) o'chiriladi.", {title: "Xabarlarini tozalash", okText: "Tozalash", danger: true})) cmd("/purge " + u.username);
    }}, "Xabarlarini tozalash"),
    h("button", {class: "btn ghost sm", type: "button", onclick: () => openBadgePicker(u)}, "Nishon / galochka"),
    h("button", {class: "btn ghost sm", type: "button", onclick: () => openProfileEditor(u.id)}, "Dizayn berish")));
  panel.append(h("div", {class: "mod-r"},
    u.banned
      ? h("button", {class: "btn ghost sm", type: "button", onclick: () => cmd("/unban " + u.username)}, "Bandan chiqarish")
      : h("button", {class: "btn danger sm", type: "button", onclick: async () => { if (await confirmDlg("@" + u.username + " ni ban qilasizmi?", {title: "Ban qilish", okText: "Ban qilish", danger: true})) cmd("/ban " + u.username); }}, "Ban qilish")));
  if (S.me.role === "owner") {
    panel.append(h("div", {class: "mod-r"}, u.role === "admin"
      ? h("button", {class: "btn ghost sm", type: "button", onclick: async () => { if (await confirmDlg("@" + u.username + " adminlikdan olinsinmi?", {title: "Adminlikdan olish", okText: "Olish", danger: true})) cmd("/rmadmin " + u.username); }}, "Adminlikdan olish")
      : h("button", {class: "btn ghost sm", type: "button", onclick: async () => { if (await confirmDlg("@" + u.username + " admin qilinsinmi?", {title: "Admin qilish", okText: "Admin qilish"})) cmd("/addadmin " + u.username); }}, "Admin qilish")));
  }
  const rows = panel.querySelectorAll(".mod-r");
  if (S.me.role === "owner" && rows.length >= 2) { const last = rows[rows.length - 1], prev = rows[rows.length - 2]; [...last.children].forEach(c => prev.append(c)); last.remove(); }
  panel.append(h("div", {class: "mod-r"}, h("button", {class: "btn danger sm", type: "button", onclick: async () => {
    if (await confirmDlg("@" + u.username + " akkaunti o'chiriladi va chatdan chiqarib tashlanadi. Yozgan xabarlari \"Deleted account\" nomi bilan qoladi. Buni qaytarib bo'lmaydi.",
      {title: "Akkauntni o'chirish", okText: "O'chirish", danger: true})) { cmd("/remove " + u.username); closePage(); }
  }}, "Akkauntni o'chirish")));
  return panel;
}



