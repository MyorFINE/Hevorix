/* ---------------- 28-presence.js: onlayn / last seen va "yozmoqda..." holatlari ----------------
   Server faqat uzatadi (saqlamaydi): {"type":"typing","kind":"text|file|emoji|voice|vnote|stop","to":<id>?}.
   Qabul qiluvchi holatni 6 soniyadan keyin o'zi o'chiradi (signal to'xtasa, "yozmoqda" qotib qolmaydi). */
const TYPING_TXT = {text: "yozmoqda", file: "fayl yubormoqda", emoji: "emoji tanlamoqda", voice: "ovozli xabar yozmoqda", vnote: "dumaloq video yozmoqda"};
const TYPING_RANK = {emoji: 1, text: 2, file: 3, voice: 4, vnote: 5};           // bir vaqtda bir nechta bo'lsa, eng "og'ir"i ko'rsatiladi
const TYPING_TTL = 6000, TYPING_BEAT = 2500;
const TY = {seen: new Map(), cur: {kind: "", at: 0, key: ""}, tick: 0, paint: 0};   // seen: suhbat kaliti -> Map(uid -> {kind, until})

function lastSeenText(u) {                                // "last seen hozirgina / bugun 14:32 / kecha 09:10 / 03.11.26 18:20"
  const ts = u && u.last_seen;
  if (!ts) return "oflayn";
  const now = Date.now() / 1000;
  if (now - ts < 60) return "last seen hozirgina";
  if (dayKey(ts) === dayKey(now)) return "last seen bugun " + hhmm(ts);
  const y = new Date(); y.setDate(y.getDate() - 1);
  if (dayKey(ts) === dayKey(y / 1000)) return "last seen kecha " + hhmm(ts);
  const d = new Date(ts * 1000);
  return "last seen " + pad2(d.getDate()) + "." + pad2(d.getMonth() + 1) + "." + String(d.getFullYear()).slice(2) + " " + hhmm(ts);
}
function tyKeyOf(t) { return !t ? "" : t.kind === "group" ? "g" : t.kind === "dm" ? "d" + t.uid : ""; }   // kanalda yozish signali yo'q
function typingNow(key) {                                 // hozir yozayotganlar: [{uid, kind}]
  const mp = TY.seen.get(key); if (!mp) return [];
  const t = Date.now(), out = [];
  mp.forEach((v, uid) => { if (v.until > t) out.push({uid, kind: v.kind}); else mp.delete(uid); });
  return out;
}
function typingLabel(key) {                               // sarlavha / ro'yxat uchun matn ("" = hech kim yozmayapti)
  const list = typingNow(key); if (!list.length) return "";
  const top = list.reduce((a, b) => (TYPING_RANK[b.kind] || 0) > (TYPING_RANK[a.kind] || 0) ? b : a);
  if (key[0] === "d") return TYPING_TXT[top.kind] || "yozmoqda";
  const names = list.map(x => (U(x.uid).nickname || "Kimdir"));
  if (list.length === 1) return names[0] + " " + (TYPING_TXT[top.kind] || "yozmoqda");
  const same = list.every(x => x.kind === top.kind);
  return (list.length === 2 ? names[0] + " va " + names[1] : list.length + " kishi") + " " + (same ? (TYPING_TXT[top.kind] || "yozmoqda") : "yozmoqda");
}
function typingRepaint() {                                // keraksiz qayta chizishlar birlashtiriladi
  if (TY.paint) return;
  TY.paint = setTimeout(() => { TY.paint = 0; if (!S.me) return; try { renderHeader(); renderList(); } catch (_) {} }, 120);
}
function typingSchedule() {                               // eng yaqin muddat tugaganda qayta chizamiz
  clearTimeout(TY.tick);
  let next = Infinity; const t = Date.now();
  TY.seen.forEach(mp => mp.forEach(v => { if (v.until > t) next = Math.min(next, v.until); }));
  if (next < Infinity) TY.tick = setTimeout(() => { typingRepaint(); typingSchedule(); }, Math.max(50, next - t + 30));
}
function onTyping(m) {                                    // server -> mijoz
  if (!S.me || m.uid === S.me.id) return;
  const key = m.group ? "g" : "d" + m.uid;
  let mp = TY.seen.get(key); if (!mp) TY.seen.set(key, mp = new Map());
  if (m.kind === "stop") mp.delete(m.uid); else if (TYPING_TXT[m.kind]) mp.set(m.uid, {kind: m.kind, until: Date.now() + TYPING_TTL});
  typingRepaint(); typingSchedule();
}
function typingClearFrom(uid) {                           // odam xabar yuborganda "yozmoqda" darhol yo'qoladi
  let hit = false; TY.seen.forEach(mp => { if (mp.delete(uid)) hit = true; });
  if (hit) typingRepaint();
}
function typingReset() { TY.seen.clear(); clearTimeout(TY.tick); TY.cur = {kind: "", at: 0, key: ""}; }

const Typing = {
  send(kind) {                                            // mijoz -> server (throttle: bir xil holat ~2.5 s da bir marta)
    const key = tyKeyOf(S.active); if (!key || !S.ws || S.ws.readyState !== 1) return;
    const c = TY.cur, now = Date.now();
    if (c.key === key && c.kind && now - c.at < TYPING_BEAT + 500) {
      if ((TYPING_RANK[kind] || 0) < (TYPING_RANK[c.kind] || 0)) return;          // pastroq darajali holat yuqorisini bosib ketmaydi
      if (kind === c.kind && now - c.at < TYPING_BEAT) return;
    } else if (c.key && c.key !== key) this.stop();
    TY.cur = {kind, at: now, key};
    const msg = {type: "typing", kind}; if (S.active.kind === "dm") msg.to = S.active.uid;
    wsSend(msg);
  },
  stop() {
    const c = TY.cur; if (!c.kind) return;
    TY.cur = {kind: "", at: 0, key: ""};
    if (!S.ws || S.ws.readyState !== 1) return;
    const msg = {type: "typing", kind: "stop"}; if (c.key[0] === "d") msg.to = +c.key.slice(1);
    wsSend(msg);
  },
  hold(kind) {                                            // holat davom etayotganda har 2.5 s da yangilaydi; qaytgan funksiya to'xtatadi
    this.send(kind);
    const t = setInterval(() => this.send(kind), TYPING_BEAT);
    let off = false;
    return () => { if (off) return; off = true; clearInterval(t); this.stop(); };
  },
};
inp.addEventListener("input", () => { if (S.editing) return; if (inp.value.trim()) Typing.send("text"); else Typing.stop(); });
inp.addEventListener("blur", () => { if (!inp.value.trim()) Typing.stop(); });
