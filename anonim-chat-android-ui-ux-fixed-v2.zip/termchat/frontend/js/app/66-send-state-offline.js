const TYPING_TXT = {text: "yozmoqda", file: "fayl yubormoqda", emoji: "emoji tanlamoqda", voice: "ovozli xabar yozmoqda", vnote: "dumaloq video yozmoqda"};
const TYPING_RANK = {emoji: 1, text: 2, file: 3, voice: 4, vnote: 5};
const TYPING_TTL = 6000, TYPING_BEAT = 2500;
const TY = {seen: new Map(), cur: {kind: "", at: 0, key: ""}, tick: 0, paint: 0};

function lastSeenText(u) {
  const ts = u && u.last_seen;
  if (u && u.seen_hidden && !(S.me && u.id === S.me.id)) return "yaqinda onlayn bo'lgan";
  if (!ts) return "oflayn";
  const now = Date.now() / 1000;
  if (now - ts < 60) return "last seen hozirgina";
  if (dayKey(ts) === dayKey(now)) return "last seen bugun " + hhmm(ts);
  const y = new Date(); y.setDate(y.getDate() - 1);
  if (dayKey(ts) === dayKey(y / 1000)) return "last seen kecha " + hhmm(ts);
  const d = new Date(ts * 1000);
  return "last seen " + pad2(d.getDate()) + "." + pad2(d.getMonth() + 1) + "." + String(d.getFullYear()).slice(2) + " " + hhmm(ts);
}
function tyKeyOf(t) { return !t ? "" : t.kind === "group" ? "g" : t.kind === "dm" ? "d" + t.uid : ""; }
function typingNow(key) {
  const mp = TY.seen.get(key); if (!mp) return [];
  const t = Date.now(), out = [];
  mp.forEach((v, uid) => { if (v.until > t) out.push({uid, kind: v.kind}); else mp.delete(uid); });
  return out;
}
function typingLabel(key) {
  const list = typingNow(key); if (!list.length) return "";
  const top = list.reduce((a, b) => (TYPING_RANK[b.kind] || 0) > (TYPING_RANK[a.kind] || 0) ? b : a);
  if (key[0] === "d") return TYPING_TXT[top.kind] || "yozmoqda";
  const names = list.map(x => (U(x.uid).nickname || "Kimdir"));
  if (list.length === 1) return names[0] + " " + (TYPING_TXT[top.kind] || "yozmoqda");
  const same = list.every(x => x.kind === top.kind);
  return (list.length === 2 ? names[0] + " va " + names[1] : list.length + " kishi") + " " + (same ? (TYPING_TXT[top.kind] || "yozmoqda") : "yozmoqda");
}
function typingRepaint() {
  if (TY.paint) return;
  TY.paint = setTimeout(() => { TY.paint = 0; if (!S.me) return; try { renderHeader(); renderList(); } catch (_) {} }, 120);
}
function typingSchedule() {
  clearTimeout(TY.tick);
  let next = Infinity; const t = Date.now();
  TY.seen.forEach(mp => mp.forEach(v => { if (v.until > t) next = Math.min(next, v.until); }));
  if (next < Infinity) TY.tick = setTimeout(() => { typingRepaint(); typingSchedule(); }, Math.max(50, next - t + 30));
}
function onTyping(m) {
  if (!S.me || m.uid === S.me.id) return;
  const key = m.group ? "g" : "d" + m.uid;
  let mp = TY.seen.get(key); if (!mp) TY.seen.set(key, mp = new Map());
  if (m.kind === "stop") mp.delete(m.uid); else if (TYPING_TXT[m.kind]) mp.set(m.uid, {kind: m.kind, until: Date.now() + TYPING_TTL});
  typingRepaint(); typingSchedule();
}
function typingClearFrom(uid) {
  let hit = false; TY.seen.forEach(mp => { if (mp.delete(uid)) hit = true; });
  if (hit) typingRepaint();
}
function typingReset() { TY.seen.clear(); clearTimeout(TY.tick); TY.cur = {kind: "", at: 0, key: ""}; }

const Typing = {
  send(kind) {
    const key = tyKeyOf(S.active); if (!key || !S.ws || S.ws.readyState !== 1) return;
    const c = TY.cur, now = Date.now();
    if (c.key === key && c.kind && now - c.at < TYPING_BEAT + 500) {
      if ((TYPING_RANK[kind] || 0) < (TYPING_RANK[c.kind] || 0)) return;
      if (kind === c.kind && now - c.at < TYPING_BEAT) return;
    } else if (c.key && c.key !== key) this.stop();
    TY.cur = {kind, at: now, key};
    const msg = {type: "typing", kind}; if (S.active.kind === "dm") msg.to = S.active.uid;
    wsSend(msg);
  },
  stop() {
    const c = TY.cur; if (!c.kind) return;
    TY.cur = {kind: "", at: 0, key: ""};
    if (!S.ws || S.ws.readyState !== 1) return;
    const msg = {type: "typing", kind: "stop"}; if (c.key[0] === "d") msg.to = +c.key.slice(1);
    wsSend(msg);
  },
  hold(kind) {
    this.send(kind);
    const t = setInterval(() => this.send(kind), TYPING_BEAT);
    let off = false;
    return () => { if (off) return; off = true; clearInterval(t); this.stop(); };
  },
};
inp.addEventListener("input", () => { if (S.editing) return; if (inp.value.trim()) Typing.send("text"); else Typing.stop(); });
inp.addEventListener("blur", () => { if (!inp.value.trim()) Typing.stop(); });

const Pend = {
  list: [],
  ACK_MS: 15000,
  MAKE_MS: 60000,
  q: Promise.resolve(), tick: 0,
  makeMs(p) { const sz = (p.info && p.info.size) || 0; return Math.min(330000, Pend.MAKE_MS + Math.round(sz / 20)); },
  add(target, info) {
    const p = {key: chatKey(target), target, info, stage: "enc", el: null, meta: null, timer: 0, sentAt: 0, t0: Date.now(), cid: Pend.rid(), gen: 0, busy: false, msg: null, make: null};
    p.el = Pend.build(p); Pend.list.push(p); Pend.mount(true); return p;
  },
  rid() { const a = new Uint8Array(12); crypto.getRandomValues(a); return Array.from(a, b => b.toString(16).padStart(2, "0")).join(""); },
  label(p) { return p.stage === "enc" ? "shifrlanmoqda…" : p.stage === "up" ? "yuborilmoqda…" : p.stage === "wait" ? "kutilmoqda…" : ""; },
  build(p) {
    const i = p.info, row = h("div", {class: "row mine last pending" + (p.target.kind === "group" ? "" : " dm")});
    const img = i.kind === "file" && i.isImg && i.url, cap = i.kind === "file" ? (i.text || "") : "";
    const bubble = h("div", {class: "bubble pending" + (img ? " has-img" + (cap ? "" : " img-only") : "") + (i.kind === "file" && !img ? " has-file" : "")
      + (i.kind === "voice" ? " has-file has-voice" : "") + (i.kind === "vnote" ? " has-file has-vnote vn-only" : "")});
    if (i.kind === "text") bubble.append(btextEl("btext", i.text, true));
    else if (img) {
      const pic = h("img", {alt: "", draggable: "false", decoding: "async"}), box = h("div", {class: "imgbox open pnd-imgbox"}, pic);
      box.style.aspectRatio = "1.333";
      pic.addEventListener("load", () => { if (pic.naturalWidth && pic.naturalHeight) box.style.aspectRatio = String(Math.min(2.4, Math.max(0.8, pic.naturalWidth / pic.naturalHeight))); });
      pic.src = i.url;
      bubble.append(box);
      if (cap) bubble.append(btextEl("btext", cap, true));
    } else if (i.kind === "file") {
      bubble.append(h("div", {class: "pnd-filebox"}, h("span", {class: "pnd-fico"}, icon("file", "ic pnd-fi"), h("span", {class: "pnd-ring sm", "aria-hidden": "true"})),
        h("div", {class: "pnd-finfo"}, h("b", {text: i.name || "Fayl"}), h("small", {text: i.size ? fmtSize(i.size) : ""}))));
      if (cap) bubble.append(btextEl("btext", cap, true));
    } else if (i.kind === "voice") {
      const d = Math.max(0, Math.round(i.dur || 0));
      bubble.append(h("div", {class: "vbox loading pnd-vbox"},
        h("span", {class: "vplay", "aria-hidden": "true"}, icon("play", "ic vi-play"), spinnerEl()),
        h("div", {class: "vmid"}, h("div", {class: "vtrack"}, h("div", {class: "vline"}, h("div", {class: "vfill"}))),
          h("div", {class: "vmeta"}, h("span", {class: "vtime", text: fmtDur(d)})))));
    } else {
      const vc = h("div", {class: "vnc"});
      if (i.thumb) vc.append(h("img", {class: "vnth", src: i.thumb, alt: "", draggable: "false"}));
      bubble.append(h("div", {class: "vnbox pnd-vnbox"}, vc));
    }
    p.meta = h("span", {class: "meta pnd-meta"});
    if (i.kind === "text" && bubble.querySelector(".bigemo")) {
      bubble.classList.add("has-big");
      if (bubble.querySelector(".bigemo-1")) bubble.classList.add("has-big-1");
      bubble.append(h("div", {class: "bfoot"}, p.meta));
    } else bubble.append(p.meta);
    row.append(h("div", {class: "slot"}), bubble);
    p.el = row; Pend.paint(p);
    return row;
  },
  paint(p) {
    if (!p.meta) return;
    p.meta.textContent = "";
    p.meta.append(h("span", {class: "lk ok", text: "🔒"}), " ", hhmm(Math.floor((p.t0 || (p.t0 = Date.now())) / 1000)), " ");
    if (p.stage === "sent") p.meta.append(icon("check", "ic pnd-ok"));
    else {
      p.meta.append(h("span", {class: "pnd-lbl"}, h("i", {class: "pnd-spin", "aria-hidden": "true"}), Pend.label(p)));
      if (p.info && (p.info.kind === "file" || p.stage === "wait")) p.meta.append(h("button", {class: "pnd-x", type: "button", title: "Bekor qilish", "aria-label": "Yuborishni bekor qilish",
        onclick: e => { e.stopPropagation(); Pend.cancel(p); }}, icon("close", "ic")));
    }
  },
  cancel(p) { if (!p) return; if (p.ac) { try { p.ac.abort(); } catch (_) {} } Pend.drop(p); toast("Yuborish bekor qilindi", "info"); },
  stage(p, st) { if (!p) return; p.stage = st; Pend.paint(p); },
  sent(p) {
    if (!p) return;
    clearTimeout(p.timer); p.stage = "sent"; p.sentAt = Date.now(); Pend.paint(p);
    p.timer = setTimeout(() => { if (Pend.list.includes(p) && p.stage === "sent") Pend.wait(p); }, Pend.ACK_MS);
  },
  wait(p) {
    if (!p || !Pend.list.includes(p)) return;
    clearTimeout(p.timer); p.stage = "wait"; Pend.paint(p); Pend.ticker();
  },
  fail(p) { Pend.wait(p); },
  ticker() { if (!Pend.tick) Pend.tick = setInterval(() => { if (!Pend.list.length) { clearInterval(Pend.tick); Pend.tick = 0; } else Pend.flush(); }, 3000); },
  go(p, make) { p.make = make; Pend.ticker(); return Pend.enqueue(p); },
  enqueue(p) { Pend.q = Pend.q.then(() => Pend.pump(p)).catch(() => {}); return Pend.q; },
  async pump(p) {
    if (!Pend.list.includes(p) || p.busy || (p.stage === "sent")) return;
    p.busy = true; const g = ++p.gen;
    try {
      if (!p.msg) {
        Pend.stage(p, "up");
        let tm = 0;
        const msg = await Promise.race([p.make(p), new Promise((_, rej) => { tm = setTimeout(() => rej(new Error("timeout")), Pend.makeMs(p)); })]).finally(() => clearTimeout(tm));
        if (g !== p.gen || !Pend.list.includes(p)) { p.busy = false; return; }
        p.msg = msg;
      }
      if (!wsTry(p.msg)) throw new Error("offline");
      Pend.sent(p);
    } catch (err) {
      if (err && err.final) { toast(err.message, "error"); Pend.drop(p); }
      else Pend.wait(p);
    }
    p.busy = false;
  },
  async flush() {
    if (S.offline || !S.ws || S.ws.readyState !== 1) return;
    for (const p of Pend.list.slice()) { if (p.stage === "wait" && !p.busy) await Pend.enqueue(p); if (p.stage === "wait") break; }
  },
  onClose() { Pend.list.forEach(p => { if (p.stage === "sent") Pend.wait(p); }); },
  nack(m) {
    const p = Pend.list.find(x => x.cid === m.cid); if (!p) return;
    if (m.final) Pend.drop(p);
    else Pend.wait(p);
  },
  drop(p) {
    clearTimeout(p.timer); p.gen++;
    if (p.info && p.info.url) { try { URL.revokeObjectURL(p.info.url); } catch (_) {} }
    const i = Pend.list.indexOf(p); if (i >= 0) Pend.list.splice(i, 1);
    if (p.el) p.el.remove();
  },
  mount(stick) {
    if (!S.active) return;
    const k = chatKey(S.active), mine = Pend.list.filter(p => p.key === k);
    if (!mine.length) return;
    const box = $("msgs"), blank = box.querySelector(".blank"); if (blank) blank.remove();
    mine.forEach(p => box.append(p.el));
    if (stick || box._stick) { box.scrollTop = box.scrollHeight; box._stick = true; }
  },
  settle(m) {
    const k = m.ch ? "c" + m.ch : m.to == null ? "g" : "d" + partnerOf(m);
    const isFile = !!(m.file || m.image), same = x => x.key === k && (x.info.kind === "text") === !isFile;
    const p = (m.cid && Pend.list.find(x => x.cid === m.cid)) || Pend.list.find(x => same(x) && x.stage === "sent") || Pend.list.find(x => same(x) && x.stage === "wait") || Pend.list.find(x => same(x)) || Pend.list.find(x => x.key === k && x.stage === "sent");
    if (p) Pend.drop(p);
  },
  clear() { Pend.list.slice().forEach(Pend.drop); clearInterval(Pend.tick); Pend.tick = 0; },
};
async function uploadEnc(blob, failText, signal) {
  const r = await SC.fetch("/api/e2ee/blob", {method: "POST", headers: {Authorization: "Bearer " + S.token, "Content-Type": "application/octet-stream"}, body: blob});
  const j = await r.json().catch(() => ({}));
  if (!r.ok) { const e = new Error(typeof j.detail === "string" ? j.detail : failText); e.final = r.status >= 400 && r.status < 500 && ![401, 408, 409, 423, 425, 429].includes(r.status); throw e; }
  return j.blob;
}
addEventListener("online", () => { if (Pend.list.length) { reconnectNow(); setTimeout(() => Pend.flush(), 400); } });
document.addEventListener("visibilitychange", () => { if (!document.hidden && Pend.list.length) { if (!S.ws || S.ws.readyState !== 1) reconnectNow(); Pend.flush(); } });
(function () {
  const f = SC.fetch;
  SC.fetch = function () { if (S.offline) { const e = new Error("Oflayn rejim: bu amal uchun internet kerak"); e.offline = true; return Promise.reject(e); } return f.apply(SC, arguments); };
})();

const Off = (() => {
  const DB = "tc_offline", ST = "kv", LIM = {group: 150, dm: 100, dms: 60, ch: 60, chs: 30};
  const te = new TextEncoder(), td = new TextDecoder();
  let key = null, mode = "", timer = 0, saving = false, info = null, probing = null;
  const idb = () => new Promise((res, rej) => {
    if (!window.indexedDB || !crypto || !crypto.subtle) return rej(new Error("IndexedDB yo'q"));
    const r = indexedDB.open(DB, 1);
    r.onupgradeneeded = () => r.result.createObjectStore(ST);
    r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
  });
  const run = (m, fn) => idb().then(db => new Promise((res, rej) => {
    const tx = db.transaction(ST, m), st = tx.objectStore(ST), rq = fn(st);
    tx.oncomplete = () => { db.close(); res(rq && rq.result); }; tx.onerror = tx.onabort = () => { db.close(); rej(tx.error); };
  }));
  const get = k => run("readonly", st => st.get(k)), set = (k, v) => run("readwrite", st => st.put(v, k)), del = k => run("readwrite", st => st.delete(k));
  async function pwKey(pass, salt) {
    const base = await crypto.subtle.importKey("raw", te.encode(pass), "PBKDF2", false, ["deriveKey"]);
    return crypto.subtle.deriveKey({name: "PBKDF2", hash: "SHA-256", salt, iterations: 200000}, base, {name: "AES-GCM", length: 256}, false, ["encrypt", "decrypt"]);
  }
  async function stayKey(create) {
    let k = null; try { k = await get("stayKey"); } catch (_) {}
    if (!k && create) { k = await crypto.subtle.generateKey({name: "AES-GCM", length: 256}, false, ["encrypt", "decrypt"]); await set("stayKey", k); }
    return k;
  }
  const tail = (a, n) => a.length > n ? a.slice(a.length - n) : a;
  const plain = (k, v) => (typeof v === "function" || (v && v.nodeType)) ? undefined : v;
  function slimMsgs(list) { return list.filter(m => m && !m.service && m.user).map(m => Object.assign({}, m, {user: m.user.id})); }
  function build() {
    const dms = [...S.dms.entries()].filter(([, d]) => d.msgs.length).sort((a, b) => (b[1].msgs.at(-1).ts || 0) - (a[1].msgs.at(-1).ts || 0)).slice(0, LIM.dms);
    const chs = [...S.chn.entries()].filter(([, c]) => c.msgs.length).slice(0, LIM.chs);
    return {
      v: 1, ts: Date.now(), me: S.me, chat: S.chat, chList: S.chList, members: S.members,
      users: [...S.users.values()].filter(u => u && u.id != null),
      group: {msgs: slimMsgs(tail(S.group.msgs, LIM.group)), more: !!S.group.more},
      dms: dms.map(([uid, d]) => [uid, slimMsgs(tail(d.msgs, LIM.dm)), !!d.more]),
      chn: chs.map(([id, c]) => [id, slimMsgs(tail(c.msgs, LIM.ch)), !!c.more]),
    };
  }
  async function save() {
    timer = 0;
    if (!key || !S.me || S.offline || saving || !S.token) return;
    saving = true;
    try {
      const iv = crypto.getRandomValues(new Uint8Array(12));
      const data = await crypto.subtle.encrypt({name: "AES-GCM", iv}, key, te.encode(JSON.stringify(build(), plain)));
      await set("snap", {v: 1, mode, user: String(S.me.username || "").toLowerCase(), nick: S.me.nickname, ts: Date.now(), iv, data});
      info = {mode, user: String(S.me.username || "").toLowerCase(), ts: Date.now()}; lastSig = sig(); lastAt = Date.now(); showBtn();
    } catch (_) {}
    saving = false;
  }
  let lastSig = "", lastAt = 0;
  const sig = () => {
    let g = S.group.msgs.length + ":" + ((S.group.msgs[S.group.msgs.length - 1] || {}).id) + "|" + S.users.size + "|" + S.members.length;
    S.dms.forEach((d, k) => { g += "," + k + ":" + d.msgs.length + ":" + ((d.msgs[d.msgs.length - 1] || {}).id); });
    return g;
  };
  const dirty = () => {
    if (!key || S.offline || timer) return;
    const now = Date.now(); if (sig() === lastSig && now - lastAt < 300000) return;
    timer = setTimeout(save, Math.max(4000, 20000 - (now - lastAt)));
  };
  const flush = () => { if (!key || S.offline || !S.me) return; clearTimeout(timer); timer = 0; if (sig() !== lastSig || Date.now() - lastAt > 60000) save(); };
  async function arm({user, password, stay}) {
    try {
      if (stay) { key = await stayKey(true); mode = "stay"; try { await del("meta"); } catch (_) {} }
      else {
        let meta = null; try { meta = await get("meta"); } catch (_) {}
        const same = meta && meta.user === String(user).toLowerCase() && meta.salt;
        const salt = same ? meta.salt : crypto.getRandomValues(new Uint8Array(16));
        if (!same) { try { await del("snap"); } catch (_) {} }
        key = await pwKey(password, salt); mode = "pw";
        await set("meta", {user: String(user).toLowerCase(), salt});
        try { await del("stayKey"); } catch (_) {}
      }
      dirty();
    } catch (_) { key = null; }
  }
  async function armStay() {
    try { key = await stayKey(true); mode = "stay"; try { await del("meta"); } catch (_) {} dirty(); } catch (_) { key = null; }
  }
  async function disarmStay() {
    if (mode === "stay") { key = null; mode = ""; }
    try { const r = await get("snap"); await del("stayKey"); if (r && r.mode === "stay") { await del("snap"); info = null; } } catch (_) {}
    showBtn();
  }
  async function wipe() { key = null; mode = ""; info = null; clearTimeout(timer); timer = 0; try { await del("snap"); await del("meta"); await del("stayKey"); } catch (_) {} showBtn(); }
  async function probe() {
    try { const r = await get("snap"); info = r ? {mode: r.mode, user: r.user, ts: r.ts} : null; } catch (_) { info = null; }
    showBtn();
  }
  const ago = ts => { const m = Math.max(0, Math.round((Date.now() - ts) / 60000)); return m < 1 ? "hozirgina" : m < 60 ? m + " daqiqa oldin" : m < 1440 ? Math.round(m / 60) + " soat oldin" : Math.round(m / 1440) + " kun oldin"; };
  function showBtn() { const b = $("offBtn"); if (b) { b.classList.toggle("hidden", !info); b.querySelector("span").textContent = info && info.mode === "pw" ? "Oflayn ko'rish (parol kerak)" : "Oflayn ko'rish"; } }

  async function open() {
    const err = $("autherr"); err.textContent = "";
    let rec = null; try { rec = await get("snap"); } catch (_) {}
    if (!rec) { err.textContent = "Oflayn xotira yo'q: avval internet bilan bir marta kiring."; return; }
    let k = null;
    try {
      if (rec.mode === "stay") k = await stayKey(false);
      else {
        const user = $("f_user").value.trim().replace(/^@/, "").toLowerCase(), pass = $("f_pass").value;
        if (!pass) { err.textContent = "Oflayn ochish uchun parolni kiriting (xabarlar parol bilan shifrlangan)."; return; }
        if (user && user !== rec.user) { err.textContent = "Bu qurilmadagi oflayn xotira boshqa akkauntniki."; return; }
        const meta = await get("meta");
        if (!meta || !meta.salt) { err.textContent = "Oflayn xotira buzilgan. Internet bilan qayta kiring."; return; }
        err.textContent = "Ochilmoqda…"; await new Promise(r => setTimeout(r, 30));
        k = await pwKey(pass, meta.salt);
      }
      if (!k) throw new Error("kalit yo'q");
      const snap = JSON.parse(td.decode(await crypto.subtle.decrypt({name: "AES-GCM", iv: rec.iv}, k, rec.data)));
      apply(snap, rec);
    } catch (_) { err.textContent = rec.mode === "pw" ? "Parol noto'g'ri yoki oflayn xotira buzilgan." : "Oflayn xotirani ochib bo'lmadi. Internet bilan kiring."; }
  }
  function apply(snap, rec) {
    resetState(); S.offline = true; S.token = null;
    S.me = snap.me; snap.users.forEach(u => S.users.set(u.id, u)); upsertUser(snap.me);
    S.members = snap.members || []; S.chat = snap.chat || {slowmode: 0, locked: false};
    const back = list => list.map(m => Object.assign(m, {user: S.users.get(m.user) || U(m.user)}));
    S.group.msgs = back(snap.group.msgs); S.group.more = false; S.chList = [];
    snap.dms.forEach(([uid, msgs]) => { const d = dmOf(uid); d.msgs = back(msgs); d.loaded = true; d.more = false; d.last = d.msgs[d.msgs.length - 1] || null; });
    $("auth").classList.add("hidden"); $("app").classList.remove("hidden");
    document.querySelectorAll(".tabs button").forEach(x => x.classList.toggle("on", x.dataset.tab === "chats"));
    $("chat").classList.add("hidden"); $("empty").classList.remove("hidden");
    document.body.classList.add("offline-mode");
    const cb = $("connbar"); cb.textContent = "📴 Oflayn rejim — faqat o'qish • oxirgi yangilanish: " + fmtDT(Math.floor((snap.ts || rec.ts) / 1000)); cb.classList.remove("hidden");
    const sub = $("obSub"); if (sub) sub.textContent = "Xabar yozish uchun internet kerak • nusxa " + ago(snap.ts || rec.ts);
    $("f_pass").value = ""; renderList();
    if (!isMobile()) openChat({kind: "group"});
  }
  function leave() {
    if (!S.offline) return;
    S.offline = false; document.body.classList.remove("offline-mode"); $("chat").classList.remove("offline"); $("connbar").textContent = "Ulanmoqda…";
    let tok = ""; try { tok = localStorage.getItem(LS_STAY) || ""; } catch (_) {}
    if (tok) { closeChat(); resumeStay(tok, 0); } else showAuth("Internet qaytdi. Yangilash uchun qayta kiring.");
  }
  addEventListener("online", () => { if (S.offline) setTimeout(leave, 600); });
  document.addEventListener("visibilitychange", () => { if (document.hidden) flush(); });
  addEventListener("pagehide", flush);
  $("offBtn").addEventListener("click", open);
  const retryBtn = $("obRetry");
  if (retryBtn) retryBtn.addEventListener("click", () => {
    if (!S.offline) return;
    if (navigator.onLine === false) { toast("Internet hali yo'q", "warn"); return; }
    toast("Ulanmoqda…", "info"); leave();
  });
  const chessBtn = $("obChess"); if (chessBtn) chessBtn.addEventListener("click", () => { S.tab = "games"; document.querySelectorAll(".tabs button").forEach(x => x.classList.toggle("on", x.dataset.tab === "games")); try { renderList(); } catch (_) {} });
  probing = probe();
  return {arm, armStay, disarmStay, wipe, dirty, probe, open, leave, save, ready: () => probing, get info() { return info; }};
})();

