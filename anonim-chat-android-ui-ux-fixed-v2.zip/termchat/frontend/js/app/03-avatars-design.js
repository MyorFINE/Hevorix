/* ---------------- ko'rinish bo'laklari: avatar, nom, galochka ---------------- */
function paintAv(el, u) {
  el.textContent = "";
  el.style.setProperty("--avc", colorOf(u.id));
  if (u.deleted) { el.classList.add("del"); el.append(icon("ghost")); return; }          // o'chirilgan akkaunt: arvoh belgisi
  if (u.avatar) el.append(h("img", {src: u.avatar, alt: "", draggable: "false", decoding: "async"}));     // dekodlash asosiy oqimni to'xtatmaydi
  else el.append(h("span", {text: (Array.from((u.nickname || "?").trim())[0] || "?").toUpperCase()}));
}
function avatar(u, size, withDot) {
  const el = h("div", {class: "av av-" + size + (isStaff(u) ? " ring " + u.role : "") + (!u.deleted && FRAME_KEYS.has(u.frame) ? " fr-" + u.frame : "")});
  tint(el, u); paintAv(el, u);
  if (withDot && !u.deleted && isOnline(u.id)) el.append(h("span", {class: "dot-on"}));
  return el;
}
function groupAvatar(size) { return h("div", {class: "av av-" + size + " grp"}, icon("group")); }
const hasEmoji = u => !!u && !!u.badge && u.badge !== "none" && u.badge !== "check";
const isVerified = u => !!u && !isStaff(u) && !u.deleted && u.badge === "check";      // admin bergan galochka (admin qilmasdan)
function badge(u, big) {
  if (hasEmoji(u) && Rich.isEmojiToken(u.badge)) {      // maxsus rasmli emoji (Kali, Linux, Anonymous, Ghost...) — admin beradi
    return Rich.emojiEl(u.badge, "eb ceb" + (u.badge_anim ? " a-" + u.badge_anim : "") + (big ? " big" : ""), isStaff(u) ? roleLabel(u.role) : null);
  }
  if (hasEmoji(u)) {                                   // ega/admin tanlagan yoki ular bergan emoji nishon (animatsiya bilan)
    return h("span", {class: "eb" + (u.badge_anim ? " a-" + u.badge_anim : "") + (big ? " big" : ""),
      title: isStaff(u) ? roleLabel(u.role) : "Maxsus nishon", "aria-label": "Nishon", text: u.badge});
  }
  if (!isStaff(u) && !isVerified(u)) return null;
  if (isStaff(u) && u.badge === "none") return null;
  const s = svgUse("#i-vb", "vb " + u.role + (big ? " big" : ""));
  const t = document.createElementNS(NS, "title");
  t.textContent = u.role === "owner" ? "Tasdiqlangan — platforma egasi" : u.role === "admin" ? "Tasdiqlangan administrator" : "Tasdiqlangan foydalanuvchi";
  s.prepend(t);
  return s;
}
/* ---------- Profil dizayni: neon, fon (banner), avatar ramkasi, unvon (admin beradi) ---------- */
const NEON_RE = /^#[0-9a-f]{6}$/i;
const NEON_PRESETS = ["#00f0ff", "#ff2d95", "#39ff14", "#b967ff", "#ffd300", "#ff3b3b", "#2d9bff", "#ffffff"];
const BANNERS = [["aurora", "Aurora"], ["sunset", "Shafaq"], ["ocean", "Okean"], ["forest", "O'rmon"], ["midnight", "Yarim tun"],
  ["rose", "Atirgul"], ["gold", "Oltin"], ["fire", "Olov"], ["ice", "Muz"], ["violet", "Binafsha"]];
const FRAMES = [["gold", "Oltin"], ["neon", "Neon"], ["rainbow", "Kamalak"], ["fire", "Olov"], ["ice", "Muz"], ["emerald", "Zumrad"], ["rose", "Atirgul"]];
const BANNER_KEYS = new Set(BANNERS.map(x => x[0])), FRAME_KEYS = new Set(FRAMES.map(x => x[0]));
const neonOf = u => u && !u.deleted && typeof u.neon === "string" && NEON_RE.test(u.neon) ? u.neon : null;
const bannerCls = u => u && !u.deleted && BANNER_KEYS.has(u.banner) ? " bn-" + u.banner : "";
const titleEl = u => u && !u.deleted && u.title ? h("div", {class: "ptitle", text: u.title}) : null;

function newTag(u, big) {                              // yangi akkaunt: hali ishonish qiyin
  return u && u.new && !u.deleted && !isStaff(u) ? h("span", {class: "newb" + (big ? " big" : ""), title: "Yangi foydalanuvchi — hali ishonch qozonmagan. Ehtiyot bo'ling", text: "⚠ Yangi"}) : null;
}
function nameEl(u, opts = {}) {
  const nt = h("span", {class: "nt", text: u.nickname});
  if (opts.colored && !isStaff(u) && !u.deleted) nt.style.color = colorOf(u.id);
  const nm = tint(h("span", {class: "nm" + (isStaff(u) ? " prem " + u.role : "") + (u.deleted ? " deleted" : "")}, nt, badge(u, opts.big), newTag(u, opts.big)), u);
  const nc = neonOf(u);
  if (nc) { nm.classList.add("neon"); nm.style.setProperty("--neon", nc); }
  return nm;
}
const statusText = u => u.deleted ? "akkaunt o'chirilgan" : isOnline(u.id) ? "onlayn" : "oflayn";

