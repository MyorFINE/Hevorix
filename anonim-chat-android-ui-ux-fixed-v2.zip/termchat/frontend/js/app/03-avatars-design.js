/* ---------------- ko'rinish bo'laklari: avatar, nom, galochka ---------------- */
function paintAv(el, u) {
  el.textContent = "";
  el.style.setProperty("--avc", colorOf(u.id));
  if (u.deleted) { el.classList.add("del"); el.append(icon("ghost")); return; }          // o'chirilgan akkaunt: arvoh belgisi
  if (u.avatar) el.append(h("img", {src: u.avatar, alt: "", draggable: "false", decoding: "async"}));     // dekodlash asosiy oqimni to'xtatmaydi
  else el.append(h("span", {text: (Array.from((u.nickname || "?").trim())[0] || "?").toUpperCase()}));
}
function avatar(u, size, withDot) {
  const el = h("div", {class: "av av-" + size + (isStaff(u) ? " ring " + u.role : "") + (!u.deleted && FRAME_KEYS.has(u.frame) ? " fr-" + u.frame : "")});
  tint(el, u); paintAv(el, u);
  if (withDot && !u.deleted && isOnline(u.id)) el.append(h("span", {class: "dot-on"}));
  return el;
}
function groupAvatar(size) { return h("div", {class: "av av-" + size + " grp"}, icon("group")); }
const hasEmoji = u => !!u && !!u.badge && u.badge !== "none" && u.badge !== "check";
const isVerified = u => !!u && !isStaff(u) && !u.deleted && u.badge === "check";      // admin bergan galochka (admin qilmasdan)
function badge(u, big) {
  if (hasEmoji(u) && Rich.isEmojiToken(u.badge)) {      // maxsus rasmli emoji (Kali, Linux, Anonymous, Ghost...) — admin beradi
    return Rich.emojiEl(u.badge, "eb ceb" + (u.badge_anim ? " a-" + u.badge_anim : "") + (big ? " big" : ""), isStaff(u) ? roleLabel(u.role) : null);
  }
  if (hasEmoji(u)) {                                   // ega/admin tanlagan yoki ular bergan emoji nishon (animatsiya bilan)
    return h("span", {class: "eb" + (u.badge_anim ? " a-" + u.badge_anim : "") + (big ? " big" : ""),
      title: isStaff(u) ? roleLabel(u.role) : "Maxsus nishon", "aria-label": "Nishon", text: u.badge});
  }
  if (!isStaff(u) && !isVerified(u)) return null;
  if (isStaff(u) && u.badge === "none") return null;
  const s = svgUse("#i-vb", "vb " + u.role + (big ? " big" : ""));
  const t = document.createElementNS(NS, "title");
  t.textContent = u.role === "owner" ? "Tasdiqlangan — platforma egasi" : u.role === "admin" ? "Tasdiqlangan administrator" : "Tasdiqlangan foydalanuvchi";
  s.prepend(t);
  return s;
}
/* ---------- Profil dizayni: element bo'yicha animatsiyali uslublar, fon (banner), avatar ramkasi, unvon (admin beradi) ----------
   Server faqat tayyor nomlarni qabul qiladi (app/services/fxstyle.py); mijoz ularni faqat o'z CSS klasslariga ulaydi. */
const BANNERS = [["aurora", "Aurora"], ["sunset", "Shafaq"], ["ocean", "Okean"], ["forest", "O'rmon"], ["midnight", "Yarim tun"],
  ["rose", "Atirgul"], ["gold", "Oltin"], ["fire", "Olov"], ["ice", "Muz"], ["violet", "Binafsha"]];
const FRAMES = [["gold", "Oltin"], ["rainbow", "Kamalak"], ["fire", "Olov"], ["ice", "Muz"], ["emerald", "Zumrad"], ["rose", "Atirgul"]];
const BANNER_KEYS = new Set(BANNERS.map(x => x[0])), FRAME_KEYS = new Set(FRAMES.map(x => x[0]));
const FX_TXT = [["shimmer", "Yaltirash"], ["aurora", "Aurora"], ["sunrise", "Shafaq"], ["ocean", "Okean"], ["gold", "Oltin"], ["candy", "Konfet"],
  ["glitch", "Glitch"], ["float", "Suzish"], ["pulse", "Puls"]];
const FX = {
  nick: {label: "Nickname", items: FX_TXT.concat([["wave", "To'lqin"]])},
  user: {label: "Username", items: FX_TXT},
  bio: {label: "Bio", items: FX_TXT.slice(0, 6).concat([["breathe", "Nafas"]])},
  page: {label: "Profil sahifasi", items: [["flow", "Oqma fon"], ["stars", "Yulduzlar"], ["float", "Suzuvchi avatar"]]},
  msg: {label: "Xabarlar", items: [["bounce", "Sakrash"], ["slide", "Sirpanish"], ["rise", "Ko'tarilish"], ["spin", "Aylanish"], ["drop", "Tushish"], ["focus", "Aniqlashish"], ["border", "Oqma hoshiya"]]},
  reply: {label: "Reply", items: [["line", "Oqma chiziq"], ["tint", "Rangli fon"], ["stripes", "Yo'l-yo'l"], ["slidein", "Sirpanib kirish"]]},
  link: {label: "Havola", items: [["run", "Chiziq yugurishi"], ["pill", "Kapsula"], ["flow", "Oqma rang"], ["arrow", "↗ Strelka"]]},
};
const FX_AREAS = Object.keys(FX);
const FX_KEYS = {}; FX_AREAS.forEach(k => { FX_KEYS[k] = new Set(FX[k].items.map(x => x[0])); });
const FX_GRAD = new Set(["shimmer", "aurora", "sunrise", "ocean", "gold", "candy"]);       // matn gradienti; qolganlari — harakat
const FX_MQ = typeof matchMedia === "function" ? matchMedia("(prefers-reduced-motion: reduce)") : null;       // "animatsiyani kamaytirish" yoqilgan bo'lsa hamma effekt o'chadi
const fxOf = (u, area) => !(FX_MQ && FX_MQ.matches) && u && !u.deleted && u.fx && typeof u.fx === "object" && typeof u.fx[area] === "string" && FX_KEYS[area].has(u.fx[area]) ? u.fx[area] : null;
const fxMap = u => { const o = {}; FX_AREAS.forEach(a => { o[a] = fxOf(u, a) || ""; }); return o; };
function fxText(el, key) {                              // nickname / username / bio elementiga matn effekti beradi
  if (!key) return el;
  if (FX_GRAD.has(key)) el.classList.add("fxt", "fxg-" + key); else el.classList.add("fxa-" + key);
  return el;
}
function fxWave(nt, text) {                             // "To'lqin": har bir harf alohida, birin-ketin ko'tariladi
  nt.textContent = ""; nt.setAttribute("aria-label", text);
  Array.from(text).forEach((ch, i) => { const sp = h("span", {class: "fxw", "aria-hidden": "true", text: ch}); sp.style.setProperty("--i", String(Math.min(i, 40))); nt.append(sp); });
  return nt;
}
function fxBubble(bubble, u) {                          // xabar pufagiga: xabar effekti (fxm-) va havola uslubi (fxl-)
  const m = fxOf(u, "msg"), l = fxOf(u, "link");
  if (m) bubble.classList.add("fxm-" + m);
  if (l) bubble.classList.add("fxl-" + l);
  return bubble;
}
function fxPlay(el, ms) {                               // xabar effekti faqat YANGI xabarda: `fxgo` klassi vaqtincha qo'yiladi (qayta chizilganda takrorlanmaydi)
  el.classList.remove("fxgo"); void el.offsetWidth; el.classList.add("fxgo");
  clearTimeout(el._fxT); el._fxT = setTimeout(() => el.classList.remove("fxgo"), ms || 3400);
}
const pageCls = u => { const k = fxOf(u, "page"); return k ? " fxp-" + k : ""; };
const bannerCls = u => u && !u.deleted && BANNER_KEYS.has(u.banner) ? " bn-" + u.banner : "";
const titleEl = u => u && !u.deleted && u.title ? h("div", {class: "ptitle", text: u.title}) : null;

function newTag(u, big) {                              // yangi akkaunt: hali ishonish qiyin
  return u && u.new && !u.deleted && !isStaff(u) ? h("span", {class: "newb" + (big ? " big" : ""), title: "Yangi foydalanuvchi — hali ishonch qozonmagan. Ehtiyot bo'ling", text: "⚠ Yangi"}) : null;
}
function nameEl(u, opts = {}) {
  const nt = h("span", {class: "nt", text: u.nickname});
  if (opts.colored && !isStaff(u) && !u.deleted) nt.style.color = colorOf(u.id);
  const nk = opts.nofx ? null : fxOf(u, "nick");
  if (nk) { fxText(nt, nk); if (nk === "wave") fxWave(nt, u.nickname); }
  return tint(h("span", {class: "nm" + (isStaff(u) ? " prem " + u.role : "") + (u.deleted ? " deleted" : "")}, nt, badge(u, opts.big), newTag(u, opts.big)), u);
}
const statusText = u => u.deleted ? "akkaunt o'chirilgan" : isOnline(u.id) ? "onlayn" : "oflayn";

