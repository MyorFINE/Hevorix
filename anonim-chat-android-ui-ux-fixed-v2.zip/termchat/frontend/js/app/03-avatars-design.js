/* ---------------- ko'rinish bo'laklari: avatar, nom, galochka ---------------- */
function paintAv(el, u) {
  el.textContent = "";
  el.style.setProperty("--avc", colorOf(u.id));
  if (u.deleted) { el.classList.add("del"); el.append(icon("ghost")); return; }          // o'chirilgan akkaunt: arvoh belgisi
  if (u.avatar) el.append(h("img", {src: u.avatar, alt: "", draggable: "false", decoding: "async"}));     // dekodlash asosiy oqimni to'xtatmaydi
  else el.append(h("span", {text: (Array.from((u.nickname || "?").trim())[0] || "?").toUpperCase()}));
}
function avatar(u, size, withDot) {
  const el = h("div", {class: "av av-" + size + (isStaff(u) ? " ring " + u.role : "") + (!u.deleted && FRAME_KEYS.has(u.frame) ? " fr-" + u.frame : "")});
  tint(el, u); paintAv(el, u);
  if (withDot && !u.deleted && isOnline(u.id)) el.append(h("span", {class: "dot-on"}));
  return el;
}
function groupAvatar(size) { return h("div", {class: "av av-" + size + " grp"}, icon("group")); }
const hasEmoji = u => !!u && !!u.badge && u.badge !== "none" && u.badge !== "check";
const isVerified = u => !!u && !isStaff(u) && !u.deleted && u.badge === "check";      // admin bergan galochka (admin qilmasdan)
function badge(u, big) {
  if (hasEmoji(u) && Rich.isEmojiToken(u.badge)) {      // maxsus rasmli emoji (Kali, Linux, Anonymous, Ghost...) — admin beradi
    return Rich.emojiEl(u.badge, "eb ceb" + (u.badge_anim ? " a-" + u.badge_anim : "") + (big ? " big" : ""), isStaff(u) ? roleLabel(u.role) : null);
  }
  if (hasEmoji(u)) {                                   // ega/admin tanlagan yoki ular bergan emoji nishon (animatsiya bilan)
    return h("span", {class: "eb" + (u.badge_anim ? " a-" + u.badge_anim : "") + (big ? " big" : ""),
      title: isStaff(u) ? roleLabel(u.role) : "Maxsus nishon", "aria-label": "Nishon", text: u.badge});
  }
  if (!isStaff(u) && !isVerified(u)) return null;
  if (isStaff(u) && u.badge === "none") return null;
  const s = svgUse("#i-vb", "vb " + u.role + (big ? " big" : ""));
  const t = document.createElementNS(NS, "title");
  t.textContent = u.role === "owner" ? "Tasdiqlangan — platforma egasi" : u.role === "admin" ? "Tasdiqlangan administrator" : "Tasdiqlangan foydalanuvchi";
  s.prepend(t);
  return s;
}
function newTag(u, big) {                              // yangi akkaunt: hali ishonish qiyin
  return u && u.new && !u.deleted && !isStaff(u) ? h("span", {class: "newb" + (big ? " big" : ""), title: "Yangi foydalanuvchi — hali ishonch qozonmagan. Ehtiyot bo'ling", text: "⚠ Yangi"}) : null;
}
function nameEl(u, opts = {}) {
  const nt = h("span", {class: "nt", text: u.nickname});
  if (opts.colored && !isStaff(u) && !u.deleted) nt.style.color = colorOf(u.id);
  const nk = opts.nofx ? null : fxOf(u, "nick");
  if (nk) { fxText(nt, nk); if (nk === "wave") fxWave(nt, u.nickname); }
  return tint(h("span", {class: "nm" + (isStaff(u) ? " prem " + u.role : "") + (u.deleted ? " deleted" : "")}, nt, badge(u, opts.big), newTag(u, opts.big)), u);
}
const statusText = u => u.deleted ? "akkaunt o'chirilgan" : isOnline(u.id) ? "onlayn" : lastSeenText(u);

