const chBridge = {api, h, icon, toast, confirmDlg, promptDlg, openModal, closeModal, sheetHead, navPush, navPop, hhmm, dayLabel, avatar, nameEl,
                  amAdmin: () => amAdmin(), me: () => S.me, openMenu, openProfile: id => openProfile(id), infoPage, closePage, closeAllPages, refreshPages, chanData: id => S.chn.get(id), setChannelList, chanAvatar, patchPost,
                  openChat, closeChat, active: () => S.active, info: chInfo, hydrateComment, sealComment, renderList, renderHeader,
                  list: () => S.chList, isMobile, fmtDT: ts => fmtDT(ts)};
function openApp() {
  resetState();
  $("auth").classList.add("hidden"); $("app").classList.remove("hidden");
  document.querySelectorAll(".tabs button").forEach(x => x.classList.toggle("on", x.dataset.tab === "chats"));
  $("chat").classList.add("hidden"); $("empty").classList.remove("hidden");
  S.wantClose = false;
  loadEmojis();
  X.ready = (async () => { await loadMembers(); try { await loadRoom(); } catch (_) {} applyPendingOpen(); })();
  connect();
  Channels.init(chBridge); Channels.loadList().then(applyPendingChannel).catch(() => {});
  Push.sync(api).catch(() => {});
  setTimeout(askNotifications, 2500);
}

(function boot() {
  let tok = ""; try { tok = localStorage.getItem(LS_STAY) || ""; } catch (_) {}
  if (tok) resumeStay(tok, 0);
  else { try { E2E.clearIdentity(); } catch (_) {} }
})();

setInterval(() => { if (S.token && S.me && isStaff(S.me) && X.rooms.size) serveWraps(); }, 30000);

