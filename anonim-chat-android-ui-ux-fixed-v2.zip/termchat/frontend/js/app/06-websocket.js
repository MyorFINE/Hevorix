/* ---------------- WebSocket ---------------- */
function sendPresence() {                          // sahifa yashirilsa "away" (oflayn), qaytsa "back" (onlayn)
  const ws = S.ws; if (ws && ws.readyState === 1) ws.send(JSON.stringify({type: document.hidden && !isOwnerMe() ? "away" : "back"}));
}
function startHeartbeat(ws) {
  clearInterval(S.hb);
  S.hb = setInterval(() => {
    if (ws !== S.ws || ws.readyState !== 1) return;
    if (Date.now() - S.lastRx > HB_DEAD_MS) { try { ws.close(); } catch (_) {} return; }   // server javob bermayapti: ulanish o'lik -> qayta ulanamiz
    ws.send(JSON.stringify({type: "ping", i: Math.round((Date.now() - S.lastAct) / 1000)}));
  }, HB_MS);
}
function reconnectNow() {
  if (!S.token || S.wantClose) return;
  clearTimeout(S.rt); S.retry = 0;
  connect();
}
function connect() {
  S.wantClose = false;
  clearInterval(S.hb); clearTimeout(S.rt);
  if (S.ws) { const old = S.ws; S.ws = null; old.onclose = old.onmessage = old.onopen = null; try { old.close(); } catch (_) {} }   // eski ulanish chala qolmasin
  const ws = SC.socket(S.token);                     // shifrlangan WebSocket (token birinchi shifrlangan kadrda)
  S.ws = ws; S.q = Promise.resolve(); S.lastRx = Date.now();       // yangi ulanish — yangi navbat (eski qotib qolgan navbat bu yerga o'tmaydi)
  ws.onopen = () => { S.retry = 0; S.lastRx = Date.now(); $("connbar").classList.add("hidden"); startHeartbeat(ws); if (document.hidden) sendPresence(); };
  ws.onmessage = ev => {                              // tartib saqlanadi: har bir hodisa shifrdan ochilgach qayta ishlanadi
    if (ws !== S.ws) return;
    S.lastRx = Date.now();
    S.q = S.q.then(async () => {
      const m = JSON.parse(ev.data);
      if (m.type === "pong") return;
      await Promise.race([prepare(m), delay(12000)]);   // bitta xabar (kalit kutish, tarmoq) butun navbatni to'xtatib qo'ymasin
      if (ws === S.ws) onMessage(m);
    }).catch(err => console.error(err));
  };
  ws.onclose = ev => {
    if (S.wantClose || ws !== S.ws) return;
    clearInterval(S.hb); S.hb = 0;
    if (ev.code === WS_UNAUTHORIZED) return showAuth("Sessiya tugagan, qayta kiring");
    if (ev.code === WS_FORBIDDEN) return showAuth("Siz ban qilingansiz");
    if (ev.code === WS_IP_BLOCKED) return showAuth("IP manzilingiz bloklangan");
    $("connbar").classList.remove("hidden");
    S.retry++;
    S.rt = setTimeout(() => { if (S.token && !S.wantClose) connect(); }, Math.min(600 * S.retry, 6000));
  };
}

/* ---- faolsizlik: oyna/chat ochiq qolib 5 daqiqa tegilmasa — login so'raladi ---- */
S.lastAct = Date.now();
(function () {
  let t = 0;
  const hit = () => { S.lastAct = Date.now(); };
  const slow = () => { const n = Date.now(); if (n - t > 1500) { t = n; S.lastAct = n; } };
  ["pointerdown", "keydown", "touchstart", "click", "input"].forEach(e => addEventListener(e, hit, {passive: true, capture: true}));
  ["pointermove", "wheel", "touchmove", "scroll"].forEach(e => addEventListener(e, slow, {passive: true, capture: true}));
})();
/* "Har kirishda login so'rash" — foydalanuvchining o'z sozlamasi (standart: YOQILGAN). O'chirilsa token va kalitlar shu qurilmada saqlanadi.
   Hevorix (egasi) hech qachon faolsizlikdan chiqarilmaydi va "oflayn"ga o'tmaydi: u guruh kalitini tarqatadi. */
const stayOn = () => { try { return !!localStorage.getItem(LS_STAY); } catch (_) { return false; } };
const isOwnerMe = () => !!(S.me && S.me.role === "owner");
const idleOff = () => stayOn() || isOwnerMe();
const idleExpired = () => !idleOff() && Date.now() - S.lastAct > IDLE_MS;
async function persistStay() {
  try {
    localStorage.setItem(LS_STAY, S.token);
    await E2E.saveIdentity(X.id, {ecdhPriv: X.priv.ecdhPriv, signPriv: X.priv.signPriv, ecdhPub: X.ecdhPub, signPub: X.signPub, iter: X.iter});
  } catch (_) {}
}
async function forgetStay() {
  try { localStorage.removeItem(LS_STAY); } catch (_) {}
  try { await E2E.clearIdentity(); } catch (_) {}
}
async function toggleStay() {
  if (stayOn()) {                                                    // login so'rashni qaytadan yoqish
    try { await api("/session/persist", {method: "POST", body: {on: false}}); } catch (_) {}
    await forgetStay(); S.lastAct = Date.now();
    toast("Endi sahifa har safar ochilganda login so'raladi", "ok");
  } else {
    const ok = await confirmDlg("Bu qurilmada sahifani ochgan zahoti login so'ralmasdan kirasiz; sessiya va shifrlash kalitlari shu qurilmada saqlanadi. Qurilmani begonalarga bermang. Davom etamizmi?",
      {title: "Login so'rashni o'chirish", okText: "O'chirish"});
    if (!ok) return;
    try { await api("/session/persist", {method: "POST", body: {on: true}}); await persistStay(); toast("Bu qurilmada endi login so'ralmaydi", "ok"); }
    catch (err) { toast(err.message, "error"); }
  }
}
async function resumeStay(tok, tries) {
  $("autherr").textContent = "Kirilmoqda…";
  S.token = tok; SC.setToken(tok);
  let j;
  try { j = await api("/me"); }
  catch (err) {
    if (String(err.message) === "401") return;                      // api() sessiya tugaganini o'zi ko'rsatdi (showAuth)
    S.token = null; SC.setToken(null);
    $("autherr").textContent = "Ulanish yo'q, qayta urinilmoqda…";
    if (tries < 20) setTimeout(() => resumeStay(tok, tries + 1), 3000);
    return;
  }
  xReset(); S.lastAct = Date.now();
  let ok = false;
  try { ok = await xRestore({upgrade: j.upgrade, e2ee: j.e2ee}, j.me); } catch (_) {}
  if (!ok) { try { await SC.fetch("/api/logout", {method: "POST", headers: {Authorization: "Bearer " + tok}}); } catch (_) {} showAuth("Kalitlarni ochib bo'lmadi, qayta kiring"); return; }
  $("autherr").textContent = "";
  openApp();
}
async function idleLogout() {
  if (!S.token) return;
  const t = S.token;
  showAuth("Uzoq vaqt faol bo'lmadingiz. Xavfsizlik uchun qayta kiring");
  try { await Promise.race([SC.fetch("/api/logout", {method: "POST", headers: {Authorization: "Bearer " + t}}), delay(4000)]); } catch (_) {}
}
function checkIdle() {
  if (!S.token) return;
  // video/audio ijro etilayotgan bo'lsa foydalanuvchi faol hisoblanadi (uzun video ko'rayotganda chiqarib yubormaymiz)
  if ([...document.querySelectorAll("video,audio")].some(m => !m.paused && !m.ended) || (VP.audio && !VP.audio.paused)) S.lastAct = Date.now();
  if (idleExpired()) idleLogout();
}
setInterval(checkIdle, 10000);

/* ---- onlayn/oflayn: boshqa sahifa, ilova, ekran o'chishi, tarmoq ---- */
document.addEventListener("visibilitychange", () => {
  if (!S.token) return;
  if (document.hidden) { S.hiddenAt = Date.now(); sendPresence(); return; }          // yashirildi -> server ozgina kutib (miltillamasin) oflayn qiladi
  if (idleExpired()) { idleLogout(); return; }
  if (!S.ws || S.ws.readyState !== 1) reconnectNow(); else sendPresence();     // qaytdi -> onlayn; ulanish o'lgan bo'lsa darhol qayta ulanadi
});
addEventListener("pagehide", () => { if (S.token && S.ws) { try { S.ws.close(); } catch (_) {} } });   // oyna/tab yopildi: darhol oflayn
addEventListener("pageshow", e => { if (e.persisted && S.token) { if (idleExpired()) idleLogout(); else reconnectNow(); } });
addEventListener("online", () => { if (S.token && (!S.ws || S.ws.readyState !== 1)) reconnectNow(); });
addEventListener("offline", () => { if (S.token) $("connbar").classList.remove("hidden"); });

async function prepare(m) {
  if (X.ready) await Promise.race([X.ready, delay(8000)]);
  if (m.type === "init") await hydrateAll(m.history);
  else if (m.type === "message") await hydrate(m);
  else if (m.type === "message_edited" && m.e2e) {
    const {list} = findMsg(m.id, m.to, m.from, m.ch), x = list.find(i => i.id === m.id);
    if (x) { m._h = Object.assign({}, x, {e2e: m.e2e}); await hydrate(m._h); }
  }
}
function eachMsg(fn) { S.group.msgs.forEach(fn); S.dms.forEach(d => { d.msgs.forEach(fn); d.buffer.forEach(fn); }); }
const snippetOf = t => (t || "").replace(/\s+/g, " ").slice(0, 100);
function partnerOf(m) { return m.user.id === S.me.id ? m.to : m.user.id; }
function findMsg(id, to, from, ch) {
  if (ch) return {list: chOf(ch).msgs, dm: null, ch};
  if (to == null) return {list: S.group.msgs, dm: null};
  const dm = dmOf(from === S.me.id ? to : from);
  return {list: dm.msgs, dm};
}
const atBottom = () => { const b = $("msgs"); return b.scrollHeight - b.scrollTop - b.clientHeight < 80; };
const isActiveGroup = () => S.active && S.active.kind === "group";
const isActiveDm = uid => S.active && S.active.kind === "dm" && S.active.uid === uid;

function onMessage(m) {
  switch (m.type) {
    case "init": {
      S.me = Object.assign({}, S.me, m.me); upsertUser(m.me);
      S.online = new Set(m.online_ids);
      m.history.forEach(x => upsertUser(x.user));
      mergeHistory(S.group, m.history, !!m.more);           // qayta ulanganda tepaga chiqib yuklangan eski xabarlar yo'qolmaydi
      S.chat = m.chat || {slowmode: 0, locked: false};
      loadMembers(); loadDialogs();
      if (S.active && S.active.kind === "dm") reloadActiveDm();
      if (S.active && S.active.kind === "channel") reloadActiveChannel();
      if (!S.active && !isMobile()) openChat({kind: "group"}); else { renderList(); renderHeader(); renderMessages(true); }
      if (S.pendingOpen) { if (S.pendingOpen.k !== "d") applyPendingOpen(); else if (X.ready) X.ready.then(applyPendingOpen); }
      break; }
    case "message": {
      upsertUser(m.user);
      if (m.ch) { onChannelPost(m); break; }
      const mine = m.user.id === S.me.id;
      const muted = !mine && m.to != null && isMuted(m.user.id);          // "Mute" bosilgan suhbat: ovoz va mahalliy bildirishnoma yo'q
      if (!mine && !muted) pingSound(m.to == null ? isActiveGroup() : isActiveDm(partnerOf(m)));
      if (!mine && !muted && document.hidden && Date.now() - (S.hiddenAt || 0) < 7000)     // yashirilganiga <7 s: server hali oflayn deb push yubormagan
        Push.local({k: m.to == null ? "g" : "d", u: m.user.id, i: m.id, n: m.user.nickname || m.user.username, t: Math.floor(Date.now() / 1000)});
      if (m.to == null) {
        const stick = atBottom();
        S.group.msgs.push(m);
        if (isActiveGroup()) {
          appendMessage(m, mine || stick);
          if (!mine && !stick) bumpAway();
        } else if (!mine) S.group.unread++;
      } else {
        const pid = partnerOf(m), dm = dmOf(pid);
        if (!S.users.has(pid)) loadMembers();
        dm.last = m;
        if (dm.loaded) dm.msgs.push(m); else dm.buffer.push(m);
        if (isActiveDm(pid)) {
          const stick = atBottom();
          appendMessage(m, mine || stick);
          if (!mine) {
            if (!document.hidden) { dm.unread = 0; wsSend({type: "read", with: pid}); }
            else dm.unread++;
            if (!stick) bumpAway();
          }
        } else if (!mine) dm.unread++;
      }
      renderList();
      break; }
    case "message_edited": {
      const {list, dm, ch} = findMsg(m.id, m.to, m.from, m.ch);
      const x = list.find(i => i.id === m.id);
      if (m._h) m.content = m._h.content;
      if (x) {
        if (m._h) Object.assign(x, {content: m._h.content, e2e: m.e2e, verified: m._h.verified, bad: m._h.bad, locked: m._h.locked, _r: m._h._r, reply: m._h.reply});
        else x.content = m.content;
        x.edited = true;
      }
      eachMsg(y => { if (y.reply && y.reply.id === m.id && !y.reply.deleted) y.reply.text = snippetOf(m.content); });
      if (dm && dm.last && dm.last.id === m.id) { dm.last.content = m.content; dm.last.edited = true; if (m._h) Object.assign(dm.last, {e2e: m.e2e, bad: m._h.bad, locked: m._h.locked}); }
      if (ch) { const st = chOf(ch); if (st.last && st.last.id === m.id && st.last !== x && m._h) Object.assign(st.last, {content: m._h.content, e2e: m.e2e, bad: m._h.bad, locked: m._h.locked}); }
      renderMessages(false); renderList();
      break; }
    case "message_reaction": {
      const {list, dm} = findMsg(m.id, m.to, m.from, m.ch);
      const x = list.find(i => i.id === m.id) || (dm && dm.buffer.find(i => i.id === m.id));
      if (x) { x.rx = m.rx || {}; patchReactions(x); }
      break; }
    case "message_deleted": {
      const {list, dm, ch} = findMsg(m.id, m.to, m.from, m.ch);
      const i = list.findIndex(x => x.id === m.id);
      if (i >= 0) list.splice(i, 1);
      eachMsg(y => { if (y.reply && y.reply.id === m.id) y.reply = {id: m.id, deleted: true}; });
      if (S.editing && S.editing.id === m.id) cancelEdit();
      if (S.replying && S.replying.id === m.id) cancelReply();
      if (VP.id === m.id) voiceStop();
      if (VN.id === m.id) vnStop();
      if (S.sel && S.sel.delete(m.id)) updateSelBar();
      if (ch) {
        const st = chOf(ch), info = chInfo(ch);
        st.buffer = st.buffer.filter(x => x.id !== m.id);
        if (st.last && st.last.id === m.id) st.last = st.msgs.length ? st.msgs[st.msgs.length - 1] : null;
        if (info && info.posts > 0) info.posts--;
        Channels.postGone(ch, m.id);
      }
      if (dm) {
        dm.buffer = dm.buffer.filter(x => x.id !== m.id);
        if (dm.last && dm.last.id === m.id) { dm.last = dm.msgs.length ? dm.msgs[dm.msgs.length - 1] : null; if (!dm.loaded || !dm.last) loadDialogs(); }
      }
      scheduleRender();
      break; }
    case "channels_changed": case "channel_post": case "channel_post_edited": case "channel_post_deleted":
    case "channel_views": case "channel_comment": case "channel_comment_deleted":
      Channels.onEvent(m); break;
    case "chat_settings":
      S.chat = {slowmode: m.slowmode || 0, locked: !!m.locked};
      renderHeader();
      if (isActiveGroup() && !amAdmin()) toast(S.chat.locked ? "Admin umumiy chatni qulfladi" : (S.chat.slowmode ? "Sekin rejim: " + S.chat.slowmode + " soniya" : "Umumiy chat ochildi"), "warn");
      break;
    case "media_removed": {                              // admin faylni o'chirdi (izoh matni qoladi)
      const x = S.group.msgs.find(i => i.id === m.id);
      if (x) { x.image = null; x.thumb = null; x.w = x.h = null; x.file = null; }
      S.imgs.delete(m.id); if (VP.id === m.id) voiceStop(); if (VN.id === m.id) vnStop();
      const u = S.played.get(m.id); if (u) { URL.revokeObjectURL(u); S.played.delete(m.id); }
      eachMsg(y => { if (y.reply && y.reply.id === m.id) { y.reply.image = false; y.reply.file = false; } });
      renderMessages(false); renderList();
      break; }
    case "e2ee_room": case "e2ee_wrap": loadRoom().catch(() => {}); break;
    case "e2ee_rotate_hint": if (amAdmin()) rotateRoom(m.reason); break;
    case "report_new": toast("Yangi shikoyat keldi (☰ → Admin sozlamalari → Shikoyatlar)", "warn"); break;
    case "chat_cleared": {
      const gone = new Set(S.group.msgs.map(x => x.id));
      eachMsg(y => { if (y.reply && gone.has(y.reply.id)) y.reply = {id: y.reply.id, deleted: true}; });
      S.group.msgs = [];
      if (isActiveGroup()) { cancelEdit(); cancelReply(); exitSelect(); }
      renderMessages(false); renderList();
      toast(m.by === S.me.id ? "Chat tozalandi" : "Admin umumiy chatni tozaladi", "ok");
      break; }
    case "read": {
      const dm = S.dms.get(m.by);
      if (dm) {
        dm.msgs.forEach(x => { if (x.user.id === S.me.id) x.read = true; });
        if (dm.last && dm.last.user.id === S.me.id) dm.last.read = true;
        if (isActiveDm(m.by)) renderMessages(false);
      }
      break; }
    case "presence":
      if (m.online) S.online.add(m.uid); else S.online.delete(m.uid);
      if (!S.users.has(m.uid)) loadMembers();
      renderList(); renderHeader(); refreshModal();
      break;
    case "members_changed": loadMembers(); loadDialogs(); break;
    case "dm_cleared": {
      const other = m.a === S.me.id ? m.b : m.a;
      S.dms.delete(other);
      const wasActive = isActiveDm(other);
      if (wasActive) closeChat();
      renderList();
      toast(m.a === S.me.id ? "Suhbat o'chirildi" : "Suhbat o'chirildi (boshqa tomon o'chirdi)", "ok");
      break; }
    case "user_removed":
      upsertUser(m.user);
      S.members = S.members.filter(x => x.id !== m.user.id); S.online.delete(m.user.id);
      renderList(); renderHeader(); renderMessages(false); refreshModal();
      break;
    case "account_removed": showAuth("Akkauntingiz o'chirildi"); break;
    case "emoji_update": loadEmojis(); break;
    case "user_update":
      upsertUser(m.user);
      renderList(); renderHeader(); renderMessages(false); refreshModal();
      break;
    case "system":
      toast(m.lines.join("\n"), m.level);
      if (m.level === "warn") { S.group.msgs.push({service: true, text: m.lines.join(" "), ts: Date.now() / 1000}); if (isActiveGroup()) renderMessages(false); }
      break;
    case "banned": showAuth("Siz ban qilindingiz" + (m.reason ? ": " + m.reason : "")); break;
  }
}

function onChannelPost(m) {
  const mine = m.user.id === S.me.id, st = chOf(m.ch), info = chInfo(m.ch);
  if (!mine) pingSound(isActiveChan(m.ch));
  if (!mine && document.hidden && Date.now() - (S.hiddenAt || 0) < 7000)
    Push.local({k: "c", u: m.ch, i: m.id, n: info ? info.nickname : "Kanal", t: Math.floor(Date.now() / 1000)});
  if (info) { info.posts++; info.last_post = m.id; info.last_ts = m.ts; S.chList.sort((a, b) => (b.last_ts || b.created || 0) - (a.last_ts || a.created || 0)); }
  else Channels.loadList();
  st.last = m;
  if (st.loaded) { if (!st.msgs.some(x => x.id === m.id)) st.msgs.push(m); }
  else if (!st.buffer.some(x => x.id === m.id)) st.buffer.push(m);
  if (isActiveChan(m.ch)) {
    const stick = atBottom();
    appendMessage(m, mine || stick);
    if (!mine && !stick) bumpAway();
    renderHeader();
  } else if (!mine) st.unread++;
  renderList();
}
async function loadChannelPosts(id) {
  const st = chOf(id);
  const j = await api("/channels/" + id + "/posts?limit=10");
  if (X.ready) await Promise.race([X.ready, delay(8000)]);
  await hydrateAll(j.posts);
  j.posts.forEach(x => upsertUser(x.user));
  const ids = new Set(j.posts.map(x => x.id));
  const fresh = j.posts.concat(st.buffer.filter(x => !ids.has(x.id))).sort((a, b) => a.id - b.id);
  mergeHistory(st, fresh, !!j.more);
  st.buffer = []; st.loaded = true;
  if (st.msgs.length) st.last = st.msgs[st.msgs.length - 1];
}
async function reloadActiveChannel() {
  const id = S.active.id;
  try { await loadChannelPosts(id); if (isActiveChan(id)) renderMessages(true); } catch (_) {}
}
/** js/channels.js ro'yxatni yuklaganda chaqiradi: oxirgi postlar ham ochiladi (ro'yxatda ko'rinishi uchun). */
async function setChannelList(list) {
  S.chList = list;
  renderList(); renderHeader();
  if (X.ready) await Promise.race([X.ready, delay(8000)]);
  for (const c of list) {
    if (!c.last) continue;
    const st = chOf(c.id);
    if (st.last && st.last.id >= c.last.id) continue;
    upsertUser(c.last.user); await hydrate(c.last); st.last = c.last;
  }
  renderList();
}
function chanAvatar(c, size) {
  const el = h("div", {class: "av av-" + size + " chn"});
  el.style.setProperty("--avc", colorOf((c.id || 0) + 3));
  if (c.avatar) el.append(h("img", {src: c.avatar, alt: "", draggable: "false"}));
  else el.append(h("span", {text: (Array.from((c.nickname || "?").trim())[0] || "?").toUpperCase()}));
  return el;
}
/** Server hodisasi (ko'rishlar/izohlar soni) post kartasiga: xotira va ekran yangilanadi. */
function patchPost(ch, pid, fields) {
  const m = chOf(ch).msgs.find(x => x.id === pid);
  if (m) Object.assign(m, fields);
  if (!isActiveChan(ch)) return;
  const row = document.querySelector('#msgs .row[data-id="' + Number(pid) + '"]'); if (!row) return;
  const v = row.querySelector(".vws b"); if (v && fields.views != null) v.textContent = String(fields.views);
  const c = row.querySelector(".cmb-t"); if (c && fields.comments != null) c.textContent = fields.comments ? fields.comments + " ta izoh" : "Izoh qoldirish";
}

async function loadMembers() {
  try {
    const j = await api("/members");
    S.members = j.members; S.online = new Set(j.online_ids);
    j.members.forEach(upsertUser);
    renderList(); renderHeader(); refreshModal();
    serveWraps();
  } catch (_) {}
}
async function loadDialogs() {
  try {
    const j = await api("/dialogs");
    if (X.ready) await X.ready;
    await hydrateAll(j.dialogs.map(d => d.last).filter(Boolean));
    const seen = new Set();
    j.dialogs.forEach(d => {
      upsertUser(d.user); seen.add(d.user.id);
      const dm = dmOf(d.user.id); dm.last = d.last; dm.unread = isActiveDm(d.user.id) ? 0 : d.unread;
    });
    S.dms.forEach((dm, uid) => {                       // serverda yo'q suhbat (masalan, boshqa tomon o'chirgan)
      if (seen.has(uid)) return;
      if (isActiveDm(uid)) { dm.msgs = []; dm.buffer = []; dm.last = null; renderMessages(false); }
      else S.dms.delete(uid);
    });
    renderList();
  } catch (_) {}
}
async function loadDm(uid) {
  const dm = dmOf(uid);
  const j = await api("/dm/" + uid);
  if (X.ready) await Promise.race([X.ready, delay(8000)]);
  await hydrateAll(j.history);
  const ids = new Set(j.history.map(x => x.id));
  const fresh = j.history.concat(dm.buffer.filter(x => !ids.has(x.id))).sort((a, b) => a.id - b.id);
  mergeHistory(dm, fresh, !!j.more);
  dm.buffer = []; dm.loaded = true;
  if (dm.msgs.length) dm.last = dm.msgs[dm.msgs.length - 1];
}
/* Tarix: dastlab faqat oxirgi 10 ta xabar. Tepaga chiqilganda oldingilari sahifalab yuklanadi (loadOlder). */
function mergeHistory(st, fresh, more) {
  const old = st.msgs.filter(x => !x.service && x.id);
  if (!old.length || !fresh.length || old[old.length - 1].id < fresh[0].id) { st.msgs = fresh.slice(); st.more = more; return; }
  const keep = old.filter(x => x.id < fresh[0].id);            // yangi oynadan oldingi (tepaga chiqib yuklangan) xabarlar saqlanadi
  st.msgs = keep.concat(fresh);
  if (!keep.length) st.more = more;
}
async function loadOlder() {
  if (!S.active || S.olderBusy) return;
  const kind = S.active.kind, isG = kind === "group", isC = kind === "channel", uid = S.active.uid, cid = S.active.id;
  const st = isG ? S.group : isC ? chOf(cid) : dmOf(uid);
  if (st.msgs.length > (S.win || WIN0)) {                     // xotirada bor, lekin chizilmagan eski xabarlar: tarmoqsiz, darrov
    const bx = $("msgs"), ph = bx.scrollHeight, pt = bx.scrollTop;
    S.win = (S.win || WIN0) + 40; renderMessages(false); bx.scrollTop = pt + (bx.scrollHeight - ph); return;
  }
  if (!st.more) return;
  const first = st.msgs.find(x => !x.service && x.id); if (!first) return;
  S.olderBusy = true;
  const box = $("msgs"), btn = box.querySelector(".older"); if (btn) btn.textContent = "Yuklanmoqda…";
  try {
    const j = await api(isG ? "/group/history?before=" + first.id : isC ? "/channels/" + cid + "/posts?limit=20&before=" + first.id : "/dm/" + uid + "?before=" + first.id);
    const older = isC ? j.posts : j.history;
    if (X.ready) await Promise.race([X.ready, delay(8000)]);
    await hydrateAll(older);
    older.forEach(x => upsertUser(x.user));
    const have = new Set(st.msgs.map(x => x.id));
    st.msgs = older.filter(x => !have.has(x.id)).concat(st.msgs);
    S.win = (S.win || WIN0) + older.length;
    st.more = !!j.more;
    if (S.active && S.active.kind === kind && (isG || (isC ? S.active.id === cid : S.active.uid === uid))) {
      const prevH = box.scrollHeight, prevT = box.scrollTop;
      renderMessages(false);
      box.scrollTop = prevT + (box.scrollHeight - prevH);       // ko'rib turgan joyingiz joyida qoladi
    }
  } catch (err) { toast(err.message, "error"); if (btn) btn.textContent = "⬆ Oldingi xabarlar"; }
  S.olderBusy = false;
}
async function reloadActiveDm() {
  const uid = S.active.uid;
  try { await loadDm(uid); if (isActiveDm(uid)) { renderMessages(true); wsSend({type: "read", with: uid}); } } catch (_) {}
}

