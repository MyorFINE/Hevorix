const Gaming = (() => {
  const GLYPH = {k: "♚", q: "♛", r: "♜", b: "♝", n: "♞", p: "♟\uFE0E"};
  const VAL = {p: 1, n: 3, b: 3, r: 5, q: 9, k: 0};
  const REACTS = ["😂", "😡", "😮", "👏", "😭", "🔥", "🤝", "😎", "👍", "❤️"];
  const START = "RNBQKBNRPPPPPPPP" + ".".repeat(32) + "pppppppprnbqkbnr";
  const REASON = {
    checkmate: "Mat", stalemate: "Pat — yurish qolmadi", insufficient: "Material yetarli emas", fifty: "50 yurish qoidasi",
    repetition: "Bir xil holat uch marta takrorlandi", timeout: "Vaqt tugadi", timeout_draw: "Vaqt tugadi, lekin mat qilish uchun material yetarli emas",
    abandon: "Aloqa uzilib qoldi", abort: "O'yin boshlanmadi — bekor qilindi",
  };
  const sqName = i => "abcdefgh"[i & 7] + ((i >> 3) + 1);
  const sqIdx = s => (s.charCodeAt(1) - 49) * 8 + s.charCodeAt(0) - 97;
  const G = {el: null, main: null, rxl: null, st: null, me: "w", bd: START.split(""), dom: new Array(64).fill(null), sqs: [], layer: null, boardEl: null,
    sel: null, drag: null, pend: false, waiting: false, wt: 0, inc: null, out: null, sheet: null, tick: 0, clock: null, overFor: null, rxAt: 0, incTimer: 0, top: null, bot: null, hist: [], boards: [START], mv: [], histKey: "", view: null, hs: null, undoBtn: null, tickSec: 0};
  const send = o => { if (wsTry(o)) return true; toast("Ulanish yo'q, biroz kutib qayta urinib ko'ring", "error"); return false; };

  const xy = i => { const f = i & 7, r = i >> 3; return G.me === "b" ? [7 - f, r] : [f, 7 - r]; };
  function place(el, i) { const [x, y] = xy(i); el.dataset.x = x; el.dataset.y = y; el.style.transform = "translate(" + x * 100 + "%," + y * 100 + "%)"; }
  function mkPiece(ch, i) {
    const t = ch.toLowerCase(), el = h("div", {class: "gp " + (ch === t ? "pb" : "pw")}, h("span", {text: GLYPH[t]}));
    place(el, i); return el;
  }
  function rebuildPieces() {
    G.layer.textContent = ""; G.dom.fill(null);
    for (let i = 0; i < 64; i++) if (G.bd[i] !== ".") { const el = mkPiece(G.bd[i], i); G.layer.append(el); G.dom[i] = el; }
  }
  function boardBlock(interactive) {
    const b = h("div", {class: "gm-board"});
    const grid = h("div", {class: "gm-sqs"});
    G.sqs = new Array(64);
    for (let y = 0; y < 8; y++) for (let x = 0; x < 8; x++) {
      const i = G.me === "b" ? y * 8 + (7 - x) : (7 - y) * 8 + x;
      const dark = ((i & 7) + (i >> 3)) % 2 === 0;
      const s = h("div", {class: "sq " + (dark ? "dk" : "lt")});
      if (x === 0) s.append(h("i", {class: "rk", text: String((i >> 3) + 1)}));
      if (y === 7) s.append(h("i", {class: "fl", text: "abcdefgh"[i & 7]}));
      G.sqs[i] = s; grid.append(s);
    }
    G.layer = h("div", {class: "gm-pcs"});
    b.append(grid, G.layer);
    G.boardEl = b;
    rebuildPieces();
    if (interactive) {
      b.addEventListener("pointerdown", onDown); b.addEventListener("pointermove", onMove);
      b.addEventListener("pointerup", onUp); b.addEventListener("pointercancel", onUp);
    }
    return b;
  }
  function fadeOut(el) { el.classList.add("cap"); setTimeout(() => el.remove(), 280); }
  function applyMove(f, t, promo) {
    const el = G.dom[f]; if (!el) return false;
    const ch = G.bd[f], pt = ch.toLowerCase();
    let capEl = G.dom[t], capped = G.bd[t] !== ".";
    if (pt === "p" && (f & 7) !== (t & 7) && G.bd[t] === ".") {
      const c = ch === "P" ? t - 8 : t + 8; capEl = G.dom[c]; capped = true; G.dom[c] = null; G.bd[c] = ".";
    }
    if (capEl) fadeOut(capEl);
    G.dom[t] = el; G.dom[f] = null; G.bd[t] = ch; G.bd[f] = ".";
    el.classList.add("mv"); setTimeout(() => el.classList.remove("mv"), 300);
    place(el, t);
    if (pt === "p" && ((t >> 3) === 0 || (t >> 3) === 7)) {
      const np = promo || "q"; G.bd[t] = ch === "P" ? np.toUpperCase() : np;
      el.firstChild.textContent = GLYPH[np]; el.classList.add("promo");
    }
    if (pt === "k" && Math.abs(t - f) === 2) {
      const rf = t > f ? f + 3 : f - 4, rt = t > f ? f + 1 : f - 1, rel = G.dom[rf];
      if (rel) { G.dom[rt] = rel; G.dom[rf] = null; G.bd[rt] = G.bd[rf]; G.bd[rf] = "."; rel.classList.add("mv"); setTimeout(() => rel.classList.remove("mv"), 300); place(rel, rt); }
    }
    return capped;
  }
  function reconcile(board) {
    if (G.bd.join("") === board) return;
    G.bd = board.split(""); rebuildPieces();
  }

  function stepBoard(bd, f, t, promo) {
    const ch = bd[f], pt = ch.toLowerCase();
    if (pt === "p" && (f & 7) !== (t & 7) && bd[t] === ".") bd[ch === "P" ? t - 8 : t + 8] = ".";
    bd[t] = ch; bd[f] = ".";
    if (pt === "p" && ((t >> 3) === 0 || (t >> 3) === 7)) { const np = promo || "q"; bd[t] = ch === "P" ? np.toUpperCase() : np; }
    if (pt === "k" && Math.abs(t - f) === 2) { const rf = t > f ? f + 3 : f - 4, rt = t > f ? f + 1 : f - 1; bd[rt] = bd[rf]; bd[rf] = "."; }
  }
  function refreshHist() {
    const hist = (G.st && G.st.hist) || [], key = hist.join(",");
    if (key === G.histKey) return;
    G.histKey = key; G.hist = hist; G.boards = [START]; G.mv = [];
    const bd = START.split("");
    hist.forEach(s => {
      const f = sqIdx(s.slice(0, 2)), t = sqIdx(s.slice(2, 4)), ch = bd[f];
      G.mv.push({ch, f, t, cap: bd[t] !== "." || (ch.toLowerCase() === "p" && (f & 7) !== (t & 7) && bd[t] === "."), promo: s[4] || ""});
      stepBoard(bd, f, t, s[4] || ""); G.boards.push(bd.join(""));
    });
  }
  function setView(k) {
    const n = G.hist.length;
    G.view = k == null || k >= n ? null : Math.max(0, k);
    G.sel = null; G.drag = null;
    if (G.layer) {
      G.bd = (G.view == null ? (G.st ? G.st.board : START) : G.boards[G.view]).split("");
      rebuildPieces();
    }
    if (G.boardEl) G.boardEl.classList.toggle("rev", G.view != null);
    paintMarks(); paintHist();
  }
  function buildHist() {
    const mkb = (txt, label, fn) => { const b = h("button", {class: "gm-hb", type: "button", "aria-label": label, text: txt}); b.addEventListener("click", fn); return b; };
    G.hPrev = mkb("◀", "Oldingi yurish", () => setView((G.view == null ? G.hist.length : G.view) - 1));
    G.hNext = mkb("▶", "Keyingi yurish", () => { if (G.view != null) setView(G.view + 1); });
    G.hLive = mkb("⏭", "Hozirgi holat", () => setView(null));
    G.hList = h("div", {class: "gm-hl"});
    G.hs = h("div", {class: "gm-hist"}, G.hPrev, G.hList, G.hNext, G.hLive);
    paintHist(); return G.hs;
  }
  function paintHist() {
    if (!G.hs || !G.hList) return;
    const n = G.hist.length, cur = G.view == null ? n : G.view;
    G.hList.textContent = "";
    if (!n) G.hList.append(h("span", {class: "gm-hn", text: "Yurishlar tarixi bu yerda ko'rinadi"}));
    let act = null;
    G.mv.forEach((m, i) => {
      if (i % 2 === 0) G.hList.append(h("span", {class: "gm-hn", text: (i / 2 + 1) + "."}));
      const white = m.ch === m.ch.toUpperCase(), pt = m.ch.toLowerCase();
      const b = h("button", {type: "button", class: "gm-hm " + (white ? "w" : "k") + (i + 1 === cur ? " on" : ""), title: (i + 1) + "-yurish"},
        h("i", {text: GLYPH[pt]}), h("span", {text: sqName(m.f) + (m.cap ? "×" : "–") + sqName(m.t) + (m.promo ? "=" + GLYPH[m.promo] : "")}));
      b.addEventListener("click", () => setView(i + 1));
      if (i + 1 === cur) act = b;
      G.hList.append(b);
    });
    G.hPrev.disabled = cur <= 0; G.hNext.disabled = G.view == null; G.hLive.disabled = G.view == null;
    G.hs.classList.toggle("rev", G.view != null);
    if (act) G.hList.scrollLeft = act.offsetLeft - G.hList.clientWidth / 2 + act.offsetWidth / 2; else G.hList.scrollLeft = 0;
  }
  function paintMarks() {
    if (!G.sqs.length || !G.sqs[0]) return;
    const st = G.st, rv = G.view != null, mvv = rv && G.view > 0 ? G.mv[G.view - 1] : null;
    const last = rv ? (mvv ? [mvv.f, mvv.t] : []) : st && st.last ? [sqIdx(st.last.from), sqIdx(st.last.to)] : [];
    const chk = !rv && st && st.check ? sqIdx(st.check) : -1;
    const tg = !rv && G.sel != null && st ? (st.legal[sqName(G.sel)] || []).map(sqIdx) : [];
    for (let i = 0; i < 64; i++) {
      const c = G.sqs[i].classList, t = tg.includes(i);
      c.toggle("last", last.includes(i)); c.toggle("chk", i === chk); c.toggle("sel", i === G.sel);
      c.toggle("tg", t && G.bd[i] === "."); c.toggle("tgc", t && G.bd[i] !== ".");
    }
  }
  let ac = null;

  const GSND_KEY = "tc_gsnd";
  const gSndOn = () => { try { return localStorage.getItem(GSND_KEY) !== "off"; } catch (_) { return true; } };
  const SND = (() => {
    let nb = null;
    const ctx = () => { if (!gSndOn()) return null; const c = audioCtx(); if (!c) return null; if (c.state === "suspended") c.resume().catch(() => {}); return c.state === "running" ? c : null; };
    const noise = c => nb && nb.sampleRate === c.sampleRate ? nb : (nb = (() => { const b = c.createBuffer(1, Math.floor(c.sampleRate * 0.25), c.sampleRate), d = b.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1; return b; })());
    function tone(c, t, f, dur, type, vol, f2) {
      const o = c.createOscillator(), g = c.createGain();
      o.type = type; o.frequency.setValueAtTime(f, t); if (f2) o.frequency.exponentialRampToValueAtTime(f2, t + dur);
      g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + 0.008); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      o.connect(g); g.connect(c.destination); o.start(t); o.stop(t + dur + 0.03);
    }
    function knock(c, t, body, bright, vol, dur) {
      tone(c, t, body, dur, "sine", vol, body * 0.55);
      const s = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
      s.buffer = noise(c); f.type = "bandpass"; f.frequency.value = bright; f.Q.value = 1.1;
      g.gain.setValueAtTime(vol * 1.4, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur * 0.55);
      s.connect(f); f.connect(g); g.connect(c.destination); s.start(t); s.stop(t + dur);
    }
    const seq = (notes, type, vol, dur, gap) => { const c = ctx(); if (!c) return; const t = c.currentTime; notes.forEach((f, i) => tone(c, t + i * gap, f, dur, type, vol)); };
    return {
      move(mine, cap, i) {
        const c = ctx(); if (!c) return; const t = c.currentTime, body = mine ? 150 : 225, bright = mine ? 950 : 1600, v = mine ? 0.24 : 0.17;
        knock(c, t, body, bright, v, 0.12);
        if (i && i.castle) knock(c, t + 0.11, body * 1.12, bright, v * 0.9, 0.12);
        if (cap) knock(c, t + 0.07, body * 0.7, bright * 0.6, v * 1.3, 0.2);
        if (i && i.promo) [880, 1175, 1568].forEach((f, n) => tone(c, t + 0.16 + n * 0.07, f, 0.22, "sine", 0.1));
      },
      check() { const c = ctx(); if (!c) return; const t = c.currentTime + 0.1; tone(c, t, 740, 0.14, "triangle", 0.13); tone(c, t + 0.13, 988, 0.22, "triangle", 0.13); },
      start() { seq([523, 659, 784], "sine", 0.13, 0.35, 0.09); },
      win() { seq([523, 659, 784, 1047], "triangle", 0.16, 0.42, 0.11); },
      lose() { seq([392, 311, 262], "sine", 0.15, 0.5, 0.17); },
      draw() { seq([494, 392], "sine", 0.14, 0.4, 0.15); },
      tick() { const c = ctx(); if (c) tone(c, c.currentTime, 1200, 0.05, "square", 0.045); },
      invite() { seq([784, 988, 1175], "sine", 0.14, 0.3, 0.1); },
      react(mine) { const c = ctx(); if (!c) return; const t = c.currentTime; tone(c, t, mine ? 620 : 480, 0.13, "sine", 0.13, mine ? 1000 : 760); tone(c, t + 0.07, mine ? 1250 : 960, 0.12, "sine", 0.07); },
    };
  })();

  function sqAt(e) {
    const r = G.boardEl.getBoundingClientRect();
    const x = Math.floor((e.clientX - r.left) / r.width * 8), y = Math.floor((e.clientY - r.top) / r.height * 8);
    if (x < 0 || x > 7 || y < 0 || y > 7) return -1;
    return G.me === "b" ? y * 8 + (7 - x) : (7 - y) * 8 + x;
  }
  const targets = i => (G.st && G.st.legal[sqName(i)] || []).map(sqIdx);
  function onDown(e) {
    if (!G.st || G.st.over || G.waiting || G.pend || G.view != null || e.button > 0) return;
    const i = sqAt(e); if (i < 0) return;
    if (G.sel != null && targets(G.sel).includes(i)) { doMove(G.sel, i); e.preventDefault(); return; }
    const ch = G.bd[i], own = ch !== "." && (ch === ch.toUpperCase()) === (G.me === "w");
    if (own && G.st.turn === G.me && G.st.legal[sqName(i)] && G.dom[i]) {
      G.sel = i; G.drag = {i, el: G.dom[i], x: e.clientX, y: e.clientY, moved: false, id: e.pointerId};
      try { G.boardEl.setPointerCapture(e.pointerId); } catch (_) {}
    } else G.sel = null;
    paintMarks(); e.preventDefault();
  }
  function onMove(e) {
    const d = G.drag; if (!d || e.pointerId !== d.id) return;
    const dx = e.clientX - d.x, dy = e.clientY - d.y;
    if (!d.moved && Math.hypot(dx, dy) > 7) { d.moved = true; d.el.classList.add("drag"); }
    if (d.moved) d.el.style.transform = "translate(calc(" + d.el.dataset.x * 100 + "% + " + dx + "px), calc(" + d.el.dataset.y * 100 + "% + " + dy + "px)) scale(1.18)";
  }
  function onUp(e) {
    const d = G.drag; if (!d || e.pointerId !== d.id) return;
    G.drag = null; d.el.classList.remove("drag");
    if (!d.moved) return;
    const to = sqAt(e);
    if (to >= 0 && targets(d.i).includes(to)) doMove(d.i, to); else place(d.el, d.i);
  }
  function askPromo(white) {
    return new Promise(res => {
      G.pend = true;
      const done = v => { G.pend = false; ov.remove(); res(v); };
      const ov = h("div", {class: "gm-promo", onclick: e => { if (e.target === ov) done(null); }},
        h("div", {class: "gm-pbox"}, ["q", "r", "b", "n"].map(p => h("button", {type: "button", class: "gm-pp " + (white ? "pw" : "pb"), "aria-label": p, onclick: () => done(p)}, GLYPH[p]))));
      G.boardEl.append(ov);
    });
  }
  async function doMove(f, t) {
    const ch = G.bd[f];
    if (ch.toLowerCase() === "p" && ((t >> 3) === 7 || (t >> 3) === 0)) {
      const p = await askPromo(ch === "P");
      if (!p) { if (G.dom[f]) place(G.dom[f], f); return; }
      return commit(f, t, p);
    }
    commit(f, t, "");
  }
  function commit(f, t, promo) {
    G.sel = null; G.waiting = true; clearTimeout(G.wt);
    G.wt = setTimeout(() => { if (G.waiting) { G.waiting = false; wsTry({type: "game_sync"}); } }, 2500);
    const mover = G.bd[f].toLowerCase(), cast = mover === "k" && Math.abs(t - f) === 2;
    const cap = applyMove(f, t, promo);
    SND.move(true, cap, {castle: cast, promo}); paintMarks();
    send({type: "game_move", gid: G.st.gid, from: sqName(f), to: sqName(t), promo: promo || undefined});
  }

  function openScreen() {
    if (G.el) return;
    if (G.st && G.st.over) { G.st = null; G.clock = null; G.waiting = false; G.overFor = null; }
    const root = h("div", {id: "gm", class: "gm"});
    G.main = h("div", {class: "gm-main"});
    G.rxl = h("div", {class: "gm-rxl", "aria-hidden": "true"});
    root.append(
      h("div", {class: "gm-top"},
        h("b", {class: "gm-ttl", text: "♟ Online Shaxmat"}),
        h("span", {class: "gm-sp"}),
        h("button", {class: "gm-x", type: "button", "aria-label": "Ovoz", onclick: ev => {
          const on = !gSndOn(); try { localStorage.setItem(GSND_KEY, on ? "on" : "off"); } catch (_) {}
          ev.currentTarget.textContent = on ? "🔊" : "🔇"; if (on) SND.start();
        }}, gSndOn() ? "🔊" : "🔇"),
        h("button", {class: "gm-x", type: "button", "aria-label": "Yopish", onclick: () => closeScreen()}, "✕")),
      G.main, G.rxl);
    document.body.append(root); G.el = root;
    navPush("game");
    render(); startTick();
  }
  function closeScreen() {
    if (!G.el) return;
    if (G.st && G.st.over) { G.st = null; G.clock = null; G.waiting = false; G.overFor = null; }
    closeSheet(); G.el.remove(); G.el = null; G.main = null; G.rxl = null; G.sqs = []; G.boardEl = null;
    navPop("game"); stopTick();
    if (S.tab === "games") renderList();
  }
  function render() {
    if (!G.el) return;
    G.main.textContent = ""; G.top = G.bot = G.hs = G.undoBtn = null; G.sel = null; G.drag = null; G.view = null;
    if (G.st) buildGame(); else buildLobby();
  }
  function menuItem(ico, title, sub, fn) {
    return h("button", {class: "gm-mi", type: "button", onclick: fn},
      h("span", {class: "gm-mic", text: ico}), h("span", {class: "gm-mt"}, h("b", {text: title}), h("small", {text: sub})), h("span", {class: "gm-mgo", text: "›"}));
  }
  function openBotSheet() {
    if (G.st && !G.st.over) { toast("Avval joriy o'yinni tugating", "warn"); return; }
    OffChess.open();
  }
  function openRules() {
    const li = (ico, t) => h("div", {class: "gm-rl"}, h("span", {text: ico}), h("div", {text: t}));
    openSheet("ℹ️ Qoidalar va ochkolar", h("div", {class: "gm-rules"},
      li("⏱", "Har bir o'yinchiga 10 daqiqa. Oxirgi 10 soniyada soat «tik» qiladi."),
      li("➕", "Taklif 60 soniya kutiladi. Oflayn foydalanuvchiga bildirishnoma boradi."),
      li("🏆", "Yutsangiz +10 ochko va tezlik, olingan toshlar, mat va pyonni ferzga chiqarish uchun bonus (jami +25 gacha). Yutqazsangiz −10."),
      li("🤝", "Durang — ochko o'zgarmaydi."),
      li("⚠️", "8 yarim yurishdan qisqa o'yinlar va bir juftlik bilan kuniga 5 tadan ortiq o'yin ochko bermaydi."),
      li("🤖", "Bot bilan o'yin ochko bermaydi va Score boardga yozilmaydi."),
      li("🔊", "Yurish ovozi: sizniki past va yumshoq, raqibniki balandroq. Yuqoridagi 🔊 tugmasi bilan o'chirasiz.")), {kind: "rules"});
  }
  async function openReactEditor() {
    const body = h("div", {class: "gm-rxe"}, h("div", {class: "none", text: "Yuklanmoqda…"}));
    openSheet("⚙ Shaxmat reaksiyalari", body, {kind: "rxedit"});
    let cfg;
    try { cfg = await api("/games/chess/reactions"); } catch (err) { if (G.sheet && G.sheet.kind === "rxedit") { body.textContent = ""; body.append(h("div", {class: "none", text: err.message})); } return; }
    if (!G.sheet || G.sheet.kind !== "rxedit") return;
    let items = cfg.items.slice();
    const cur = h("div", {class: "gm-rxcur"}), cnt = h("small", {class: "gm-rxcnt"}), pickEl = h("div", {class: "gm-rxpick"});
    const sync = () => {
      cur.textContent = "";
      items.forEach(e => cur.append(h("button", {type: "button", class: "gm-rxc", title: "Olib tashlash", onclick: () => { toggle(e); }}, rxGlyph(e, "gm-re-e"))));
      cnt.textContent = items.length + " / " + cfg.max + " (kamida " + cfg.min + ")";
      pickEl.querySelectorAll(".rx-opt").forEach(x => x.classList.toggle("on", items.includes(x._e)));
    };
    const toggle = e => {
      if (items.includes(e)) { if (items.length <= cfg.min) { toast("Kamida " + cfg.min + " ta reaksiya bo'lishi kerak", "warn"); return; } items = items.filter(x => x !== e); }
      else { if (items.length >= cfg.max) { toast("Ko'pi bilan " + cfg.max + " ta reaksiya", "warn"); return; } items.push(e); }
      sync();
    };
    const mk = e => { const b = h("button", {type: "button", class: "rx-opt", title: e}, rxGlyph(e)); b._e = e; b.addEventListener("click", ev => { ev.stopPropagation(); toggle(e); }); return b; };
    pickEl.append(rxPackView(mk, {k: null}, "rx-grid"));
    const save = async body2 => {
      try { const j = await api("/games/chess/reactions", {method: "PUT", body: body2}); toast("Saqlandi", "ok"); if (G.st) G.st.reacts = j.items; closeSheet("rxedit"); }
      catch (err) { toast(err.message, "error"); }
    };
    body.textContent = "";
    body.append(
      h("p", {class: "gm-note", text: "Shaxmat o'yinida hamma ko'radigan reaksiyalar. Bosib qo'shing yoki olib tashlang. Maxsus emojilar ham mumkin (hamma uchun ko'rinadi)."}),
      h("div", {class: "gm-rxh"}, h("b", {text: "Tanlanganlar"}), cnt), cur, pickEl,
      h("div", {class: "gm-rxb"},
        h("button", {class: "btn ghost", type: "button", text: "Standartga qaytarish", onclick: () => save({items: null})}),
        h("button", {class: "btn", type: "button", text: "Saqlash", onclick: () => save({items})})));
    sync();
  }
  function buildLobby() {
    G.me = "w"; G.bd = START.split("");
    const off = !!S.offline;
    const online = off ? 0 : S.members.filter(m => m.id !== S.me.id && !m.deleted && isOnline(m.id)).length;
    const stats = h("div", {class: "gm-mst"}), extra = h("div", {class: "gm-mx"});
    const saved = OffChess.hasSaved();
    const root = h("div", {class: "gm-menu"},
      h("div", {class: "gm-mh"}, h("div", {class: "gm-mart", text: "♞"}), h("b", {text: "Online Shaxmat"}), h("small", {text: off ? "Internet yo'q — faqat bot bilan o'ynash mumkin" : "Har bir o'yinchiga 10 daqiqa"}), stats),
      off ? null : menuItem("➕", "Taklif qilish", (online ? online + " ta onlayn • " : "") + "javob uchun 60 soniya", openInvite),
      menuItem("🤖", "Bot bilan o'ynash", saved ? "● To'xtatilgan o'yin bor — davom eting" : "5 daraja • maslahat • orqaga • reytingga ta'sir qilmaydi", openBotSheet),
      off ? null : menuItem("🎯", "Missiyalar", "3-5 daraja botni yuting — ochko va sovg'alar oling", () => Missions.open()),
      off ? null : menuItem("🎒", "Inventar", "Sovg'a dizaynlarini profilga kiying", () => Missions.inventory()),
      off ? null : menuItem("🏆", "Score board", "Faqat haqiqiy o'yinchilar o'rtasidagi o'yinlar", openScore),
      extra);
    extra.append(h("button", {class: "gm-ml", type: "button", onclick: openRules}, "ℹ️ Qoidalar"));
    if (off) { G.main.append(root); return; }
    G.main.append(root);
    api("/games/chess/scoreboard").then(j => {
      if (!root.isConnected) return; const me = j.me, n = me.wins + me.losses + me.draws;
      stats.textContent = "";
      if (!n) { stats.append(h("span", {class: "gm-chip", text: "Hali o'ynalmagan — birinchi bo'ling!"})); return; }
      stats.append(h("span", {class: "gm-chip", text: "🏆 " + me.points + " ochko"}), h("span", {class: "gm-chip", text: me.rank ? "# " + me.rank + " o'rin" : "— o'rin"}), h("span", {class: "gm-chip", text: me.wins + " / " + me.losses + " / " + me.draws}));
    }).catch(() => {});
    api("/games/chess/reactions").then(c => {
      if (root.isConnected && c.manage) extra.append(h("button", {class: "gm-ml", type: "button", onclick: openReactEditor}, "⚙ Reaksiyalar (admin)"));
    }).catch(() => {});
  }
  const BOT_NAME = "Bot";
    function playerRow(side) {
    const uid = side === "w" ? G.st.white : G.st.black, isBot = G.st.bot && uid === 0, u = isBot ? null : U(uid);
    const cap = h("span", {class: "gm-cap"}), pts = h("span", {class: "gm-pp2"}), clk = h("div", {class: "gm-clk", text: "10:00"});
    const el = h("div", {class: "gm-pl"}, isBot ? h("div", {class: "gm-botav", text: "🤖"}) : avatar(u, "m", true), h("div", {class: "gm-pi"}, h("div", {class: "gm-pn"}, isBot ? BOT_NAME : nameEl(u)), cap, pts), clk);
    return {el, side, cap, pts, clk};
  }
  function buildGame() {
    const st = G.st, opp = G.me === "w" ? "b" : "w";
    G.bd = st.board.split("");
    G.top = playerRow(opp); G.bot = playerRow(G.me);
    const reacts = h("div", {class: "gm-reacts"}, (st.reacts && st.reacts.length ? st.reacts : REACTS).map(e => {
      const b = h("button", {type: "button", class: "gm-re", title: e.startsWith(":") ? e.slice(1, -1) : e}, rxGlyph(e, "gm-re-e"));
      b.addEventListener("click", () => sendReact(e, b)); return b;
    }));
    G.undoBtn = st.bot ? h("button", {class: "gm-undo", type: "button", disabled: !st.canUndo, onclick: undoMove}, "↩ Qaytarish") : null;
    const act = h("div", {class: "gm-act"},
      h("button", {class: "gm-resign", type: "button", onclick: resign}, "🏳 Taslim"), G.undoBtn, st.bot ? h("span", {class: "gm-botnote", text: "Ochko berilmaydi"}) : reacts);
    G.main.append(h("div", {class: "gm-wrap"}, G.top.el, boardBlock(true), G.bot.el, buildHist(), act));
    paintMarks(); paintPlayers(); tickClocks();
  }
  function paintPlayers() {
    const st = G.st; if (!st || !G.top) return;
    [G.top, G.bot].forEach(r => {
      const mine = st.captured[r.side] || [], other = st.captured[r.side === "w" ? "b" : "w"] || [];
      const sum = a => a.reduce((n, c) => n + VAL[c.toLowerCase()], 0), diff = sum(mine) - sum(other);
      r.cap.textContent = "";
      [...mine].sort((a, b) => VAL[b.toLowerCase()] - VAL[a.toLowerCase()]).forEach(c => r.cap.append(h("span", {class: "gc " + (c === c.toLowerCase() ? "pb" : "pw"), text: GLYPH[c.toLowerCase()]})));
      if (diff > 0) r.cap.append(h("span", {class: "gm-diff", text: "+" + diff}));
      r.pts.textContent = "";
      if (st.bot) { r.pts.append(h("span", {class: "gm-tot", text: (r.side === (st.white === 0 ? "w" : "b")) ? "O'rtacha daraja" : "Ochkosiz o'yin"})); r.el.classList.toggle("turn", !st.over && st.turn === r.side); return; }
      r.pts.append(h("span", {class: "gm-tot", title: "Jami ochko", text: "🏆 " + st.base[r.side]}),
        h("span", {class: "gm-up", title: "Yutsa olinadigan ochko (tezlik va olingan toshlarga qarab o'sib boradi)", text: "+" + st.preview[r.side]}),
        h("span", {class: "gm-dn", title: "Yutqazsa", text: "−10"}));
      r.el.classList.toggle("turn", !st.over && st.turn === r.side);
    });
  }
  function fmt(ms) { const s = Math.ceil(Math.max(0, ms) / 1000); return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0"); }
  function tickClocks() {
    if (!G.el || !G.st || !G.clock) return;
    const c = G.clock, el = performance.now() - c.at;
    [G.top, G.bot].forEach(r => {
      if (!r) return;
      let ms = c[r.side]; if (c.running && c.turn === r.side) ms -= el;
      r.clk.textContent = fmt(ms); r.clk.classList.toggle("low", ms < 20000);
      if (r === G.bot && c.running && c.turn === r.side && ms > 0 && ms < 10000) { const sec = Math.ceil(ms / 1000); if (G.tickSec !== sec) { G.tickSec = sec; SND.tick(); } }
    });
  }
  function startTick() { if (!G.tick) G.tick = setInterval(tickClocks, 250); }
  function stopTick() { clearInterval(G.tick); G.tick = 0; }
  function undoMove() {
    if (!G.st || G.st.over || !G.st.bot || !G.st.canUndo || G.waiting) return;
    send({type: "game_undo", gid: G.st.gid});
  }
  async function resign() {
    if (!G.st || G.st.over) return;
    if (await confirmDlg(G.st.bot ? "Taslim bo'lsangiz o'yin tugaydi (bot bilan o'yinda ochko ayrilmaydi). Taslim bo'lasizmi?" : "Taslim bo'lsangiz o'yin tugaydi va 10 ochko ayriladi. Taslim bo'lasizmi?", {title: "Taslim bo'lish", okText: "Taslim bo'lish", danger: true})) send({type: "game_resign", gid: G.st.gid});
  }

  function onState(st) {
    const prev = G.st, first = !prev || prev.gid !== st.gid;
    G.st = st; G.waiting = false; clearTimeout(G.wt); G.me = st.white === S.me.id ? "w" : "b"; G.sel = null;
    refreshHist();
    if (first) {
      G.overFor = null; closeSheet(); hideInvite(); G.out = null;
      if (!G.el) openScreen(); else render();
      haptic([40, 40, 40]); SND.start();
      if (S.tab === "games") renderList();
    } else {
      const l = st.last, adv = !!l && st.plies === prev.plies + 1;
      if (st.plies < prev.plies) G.view = null;
      if (G.view == null) {
        if (adv && G.bd.join("") !== st.board) {
          const cap = applyMove(sqIdx(l.from), sqIdx(l.to), l.promo); SND.move(false, cap, l); haptic(12);
        }
        reconcile(st.board);
        if (G.boardEl) G.boardEl.classList.remove("rev");
      } else if (adv) SND.move(false, false, l);
      if (adv && st.check && !st.over) SND.check();
    }
    G.clock = Object.assign({}, st.clock, {at: performance.now()});
    paintMarks(); paintPlayers(); tickClocks(); paintHist();
    if (G.undoBtn) G.undoBtn.disabled = !st.canUndo || !!st.over;
    if (st.over) showOver(st);
  }
  function showOver(st) {
    if (G.overFor === st.gid || !G.el) return;
    G.overFor = st.gid;
    const o = st.over, me = G.me, res = o.result === "d" ? "d" : o.result === me ? "w" : "l", pts = o.pts[me];
    let why = REASON[o.reason] || "";
    if (o.reason === "resign") why = res === "w" ? "Raqib taslim bo'ldi" : "Siz taslim bo'ldingiz";
    const isBot = !!st.bot, num = h("div", {class: "go-pts " + (pts > 0 ? "up" : pts < 0 ? "dn" : "")}, "0");
    const lines = [];
    if (o.bonus && res === "w") lines.push(h("div", {class: "go-bd"}, "Asosiy +10", " • Tezlik +" + o.bonus.speed, " • Olingan toshlar +" + o.bonus.material, " • Taktika +" + o.bonus.tactic));
    if (!isBot && !o.rated && res !== "d") lines.push(h("div", {class: "go-nr", text: "Ochko berilmadi: o'yin juda qisqa edi yoki bu raqib bilan bugun juda ko'p o'ynalgan."}));
    const opp = me === "w" ? st.black : st.white;
    const card = h("div", {class: "gm-over"}, h("div", {class: "go-card"},
      h("div", {class: "go-t", text: res === "w" ? "🏆 Siz yutdingiz!" : res === "l" ? "Yutqazdingiz" : "🤝 Durang"}),
      h("div", {class: "go-r", text: why}), isBot ? h("div", {class: "go-nr", text: "Bot bilan o'yin — ochko berilmaydi va Score boardga yozilmaydi."}) : num, ...(isBot ? [] : lines),
      isBot ? null : h("div", {class: "go-tot", text: "Jami: " + o.total[me] + " ochko"}),
      h("div", {class: "go-b"},
        h("button", {class: "btn", type: "button", text: "🔁 Qayta o'ynash", onclick: () => { card.remove(); leaveGame(); if (isBot) send({type: "game_bot", side: "r"}); else send({type: "game_invite", to: opp}); }}),
        h("button", {class: "btn ghost", type: "button", text: "Yopish", onclick: () => { card.remove(); leaveGame(); }}))));
    G.el.append(card);
    const t0 = performance.now(), dur = 700;
    if (isBot) num.textContent = "";
    const step = now => { const k = Math.min(1, (now - t0) / dur); num.textContent = (pts > 0 ? "+" : pts < 0 ? "−" : "") + Math.round(Math.abs(pts) * k); if (k < 1 && num.isConnected) requestAnimationFrame(step); };
    requestAnimationFrame(step);
    haptic(res === "w" ? [60, 40, 120] : 40);
    setTimeout(() => (res === "w" ? SND.win : res === "l" ? SND.lose : SND.draw)(), 350);
    if (S.tab === "games") renderList();
  }
  function leaveGame() { G.st = null; G.clock = null; G.waiting = false; if (G.el) render(); if (S.tab === "games") renderList(); }

  function sendReact(e, btn) {
    if (!G.st || G.st.over) return;
    const n = Date.now(); if (n - G.rxAt < 900) return; G.rxAt = n;
    if (btn) { btn.classList.add("pop"); setTimeout(() => btn.classList.remove("pop"), 280); }
    send({type: "game_react", gid: G.st.gid, emoji: e});
  }
  function onReact(m) {
    if (!G.el || !G.st || G.st.gid !== m.gid || !G.rxl) return;
    const mine = m.uid === S.me.id;
    while (G.rxl.children.length > 4) G.rxl.firstChild.remove();
    const main = rxGlyph(m.emoji, "gmrx-e"); main.classList.add("gmrx-e");
    const stage = h("div", {class: "gmrx-st"}, main);
    for (let i = 0; i < 7; i++) {
      const a = (-90 + (i - 3) * 27 + Math.random() * 12 - 6) * Math.PI / 180, d = 70 + Math.random() * 70;
      const p = rxGlyph(m.emoji, "gmrx-p"); p.classList.add("gmrx-p");
      p.style.setProperty("--dx", Math.round(Math.cos(a) * d * 1.25) + "px"); p.style.setProperty("--dy", Math.round(Math.sin(a) * d) + "px");
      p.style.setProperty("--s", (0.3 + Math.random() * 0.3).toFixed(2)); p.style.animationDelay = i * 30 + "ms";
      stage.append(p);
    }
    const fx = h("div", {class: "gmrx " + (mine ? "me" : "op")}, stage, h("small", {text: mine ? "Siz" : U(m.uid).nickname}));
    G.rxl.append(fx); setTimeout(() => fx.remove(), 2400);
    SND.react(mine); if (!mine) haptic(25);
  }

  function closeSheet(kind) {
    if (!G.sheet || (kind && G.sheet.kind !== kind)) return;
    G.sheet.el.remove(); G.sheet = null;
  }
  function openSheet(title, body, opts = {}) {
    if (!G.el) openScreen();
    closeSheet();
    const back = h("div", {class: "gm-sheet", onclick: e => { if (e.target === back) dismiss(); }});
    const dismiss = () => { const s = G.sheet; closeSheet(); if (s && s.onClose) s.onClose(); };
    back.append(h("div", {class: "gm-panel"}, h("div", {class: "gm-ph"}, h("b", {text: title}), h("button", {class: "gm-x", type: "button", "aria-label": "Yopish", onclick: dismiss}, "✕")), body));
    G.el.append(back); G.sheet = {el: back, kind: opts.kind || "", onClose: opts.onClose};
  }
  async function openScore() {
    const body = h("div", {class: "gm-score"}, h("div", {class: "none", text: "Yuklanmoqda…"}));
    openSheet("🏆 Score board", body, {kind: "score"});
    try {
      const j = await api("/games/chess/scoreboard");
      if (!G.sheet || G.sheet.kind !== "score") return;
      body.textContent = "";
      const me = j.me;
      body.append(h("div", {class: "gs-me"},
        h("div", {}, h("b", {text: String(me.points)}), h("small", {text: "ochko"})),
        h("div", {}, h("b", {text: me.rank ? "#" + me.rank : "—"}), h("small", {text: "o'rin"})),
        h("div", {}, h("b", {text: me.wins + " / " + me.losses + " / " + me.draws}), h("small", {text: "yutuq / mag'lubiyat / durang"}))));
      if (!j.top.length) body.append(h("div", {class: "none", text: "Hali o'yin bo'lmagan. Birinchi bo'ling!"}));
      j.top.forEach((r, n) => {
        const u = U(r.uid), medal = ["🥇", "🥈", "🥉"][n] || String(n + 1);
        body.append(h("div", {class: "gs-row" + (r.uid === S.me.id ? " me" : "")},
          h("span", {class: "gs-n", text: medal}), avatar(u, "s"), h("div", {class: "gs-u"}, nameEl(u), h("small", {text: r.wins + " yutuq • " + r.losses + " mag'lub. • " + r.draws + " durang"})),
          h("b", {class: "gs-p", text: String(r.points)})));
      });
    } catch (err) { if (G.sheet && G.sheet.kind === "score") { body.textContent = ""; body.append(h("div", {class: "none", text: err.message})); } }
  }
  function openInvite() {
    if (G.st && !G.st.over) { toast("Avval joriy o'yinni tugating", "warn"); return; }
    if (G.out) { toast("Avvalgi taklifga javob kutilmoqda", "warn"); return; }
    const list = h("div", {class: "gm-list"});
    const q = h("input", {class: "gm-q", type: "search", placeholder: "Foydalanuvchini qidirish", autocomplete: "off", autocapitalize: "none", spellcheck: "false"});
    const draw = () => {
      list.textContent = "";
      const t = q.value.trim().toLowerCase();
      const all = S.members.filter(m => m.id !== S.me.id && !m.deleted).map(m => U(m.id))
        .filter(u => !t || u.nickname.toLowerCase().includes(t) || u.username.toLowerCase().includes(t))
        .sort((a, b) => a.nickname.localeCompare(b.nickname));
      const on = all.filter(u => isOnline(u.id)), off = all.filter(u => !isOnline(u.id));
      const row = (u, online) => h("div", {class: "gm-u"}, avatar(u, "m", true),
        h("div", {class: "gm-un"}, nameEl(u), h("small", {text: online ? "onlayn" : "oflayn • bildirishnoma yuboriladi"})),
        h("button", {class: "btn sm" + (online ? "" : " ghost"), type: "button", text: "Taklif", onclick: () => send({type: "game_invite", to: u.id})}));
      if (on.length) { list.append(h("div", {class: "sect", text: "Onlayn — " + on.length})); on.forEach(u => list.append(row(u, true))); }
      if (off.length) { list.append(h("div", {class: "sect", text: "Oflayn"})); off.forEach(u => list.append(row(u, false))); }
      if (!all.length) list.append(h("div", {class: "none", text: "Hech kim topilmadi"}));
    };
    q.addEventListener("input", draw); draw();
    openSheet("➕ O'yinga taklif", h("div", {}, q, list), {kind: "invite"});
  }
  function showWaiting(m) {
    if (!G.el) openScreen();
    const u = U(m.to), ttl = Math.max(1, (m.ttl || 60)) * 1000;
    const bar = h("i"); bar.style.animationDuration = ttl + "ms";
    const cancel = () => { if (G.out) send({type: "game_cancel", id: G.out.id}); };
    openSheet("Taklif yuborildi", h("div", {class: "gm-wait"},
      avatar(u, "l"), h("div", {class: "gw-n"}, nameEl(u)),
      h("div", {class: "gw-s", text: isOnline(m.to) ? "Javob kutilmoqda…" : "Foydalanuvchi oflayn — bildirishnoma yuborildi. Javob kutilmoqda…"}),
      h("div", {class: "gm-bar big"}, bar),
      h("button", {class: "btn ghost", type: "button", text: "Bekor qilish", onclick: cancel})), {kind: "wait", onClose: cancel});
  }

  function hideInvite() { clearTimeout(G.incTimer); if (G.inc) { G.inc.el.remove(); G.inc = null; } }
  function showInvite(m) {
    hideInvite();
    const u = U(m.frm), ttl = Math.max(1, (m.ttl || 60)) * 1000, bar = h("i"); bar.style.animationDuration = ttl + "ms";
    const answer = ok => { send({type: "game_reply", id: m.id, accept: ok}); hideInvite(); };
    const el = h("div", {class: "gm-inv", role: "alertdialog", "aria-label": "Shaxmat taklifi"},
      avatar(u, "m"),
      h("div", {class: "gm-ivt"}, h("b", {text: "♟ Shaxmatga taklif"}), h("span", {}, nameEl(u), " sizni o'yinga taklif qildi")),
      h("div", {class: "gm-ivb"}, h("button", {class: "btn sm", type: "button", text: "Qabul qilish", onclick: () => answer(true)}), h("button", {class: "btn sm ghost", type: "button", text: "Rad etish", onclick: () => answer(false)})),
      h("div", {class: "gm-bar"}, bar));
    document.body.append(el); G.inc = {id: m.id, el};
    haptic([70, 50, 70]);
    G.incTimer = setTimeout(hideInvite, ttl + 400);
  }
  function inviteEnd(m) {
    if (G.inc && G.inc.id === m.id) hideInvite();
    if (G.out && G.out.id === m.id) {
      G.out = null; closeSheet("wait");
      const nm = U(m.to).nickname;
      const t = {declined: nm + " taklifni rad etdi", expired: nm + " javob bermadi — taklif rad etildi", busy: nm + " hozir band", cancelled: "Taklif bekor qilindi"}[m.status];
      if (t) toast(t, m.status === "cancelled" ? "info" : "warn");
    }
  }

  function onWs(m) {
    switch (m.type) {
      case "game_invite": showInvite(m); SND.invite(); break;
      case "game_invite_sent": G.out = {id: m.id, to: m.to}; showWaiting(m); break;
      case "game_invite_end": inviteEnd(m); break;
      case "game_state": onState(m); break;
      case "game_react": onReact(m); break;
    }
  }
  function tabList(list) {
    if (S.offline) {
      list.append(h("button", {class: "gcard", type: "button", onclick: openScreen},
        h("div", {class: "gc-art", text: "♞"}),
        h("div", {class: "gc-t"}, h("b", {text: "Online Shaxmat"}), h("small", {class: OffChess.hasSaved() ? "live" : "", text: OffChess.hasSaved() ? "● To'xtatilgan bot o'yini bor" : "Oflayn: faqat bot bilan o'ynash"})),
        h("span", {class: "gc-on", text: "oflayn"})));
      return;
    }
    const online = S.members.filter(m => m.id !== S.me.id && !m.deleted && isOnline(m.id)).length, live = !!G.st && !G.st.over;
    list.append(h("button", {class: "gcard", type: "button", onclick: openScreen},
      h("div", {class: "gc-art", text: "♞"}),
      h("div", {class: "gc-t"}, h("b", {text: "Online Shaxmat"}), h("small", {class: live ? "live" : "", text: live ? "● O'yin davom etmoqda — qaytish" : "Do'stlar bilan real vaqtda • 10 daqiqa"})),
      h("span", {class: "gc-on", text: online + " onlayn"})));
  }
  function openFromPush() {
    S.tab = "games";
    document.querySelectorAll(".tabs button").forEach(x => x.classList.toggle("on", x.dataset.tab === "games"));
    renderList(); openScreen();
  }
  function reset() { hideInvite(); closeScreen(); G.st = null; G.out = null; G.clock = null; G.overFor = null; G.bd = START.split(""); }
  NAV_CLOSE.game = () => closeScreen();
  return {tabList, onWs, openFromPush, reset, sync: () => wsTry({type: "game_sync"}), snd: SND, sndOn: gSndOn};
})();