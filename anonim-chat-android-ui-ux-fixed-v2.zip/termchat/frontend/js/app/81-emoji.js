const EM = {data: null, tab: "std", refresh: null};
const STD_EMOJIS = "😀 😃 😄 😁 😆 😅 😂 🤣 🙂 😉 😊 😇 🥰 😍 🤩 😘 😋 😛 😜 🤪 😎 🤓 🥳 😏 😒 😞 😔 😟 😕 🙁 😣 😖 😫 😩 🥺 😢 😭 😤 😠 😡 🤬 🤯 😳 🥵 🥶 😱 😨 😰 😥 😓 🤗 🤔 🤭 🤫 😶 😐 😑 😬 🙄 😯 😲 🥱 😴 🤤 😪 😵 🤐 🥴 🤢 🤮 🤧 😷 🤒 🤕 😈 👿 👹 👺 💀 👻 👽 🤖 💩 🙈 🙉 🙊 👍 👎 👌 ✌️ 🤞 🤟 🤘 👏 🙌 🙏 💪 👀 🧠 ❤️ 🧡 💛 💚 💙 💜 🖤 💔 💯 ✨ 🔥 ⚡ 🌈 ⭐ 🎉 🎁 🏆 🚀 💻 🔒 🔑 🛡️ ☕ 🍕 🍔 🍺".split(" ");

function emojiPerms() { return (EM.data && EM.data.perms) || {use: false, create: false, manage: false}; }
function emojiUsable(e) {
  const p = emojiPerms();
  if (p.manage) return true;
  const pk = e.pack != null ? EM.data.packs.find(x => x.id === e.pack) : null;
  return e.public !== false && (!pk || pk.public);
}
function syncEmojiBtn() { $("emojiBtn").classList.toggle("hidden", !emojiPerms().use); if (!emojiPerms().use) closeEmojiPanel(); }
async function loadEmojis() {
  try {
    const r = await api("/emojis");
    EM.data = r;
    const pm = new Map((r.packs || []).map(x => [x.id, x]));
    Rich.setEmojis(r.emojis.map(e => { const pk = e.pack != null ? pm.get(e.pack) : null; return pk ? {...e, kind: pk.kind, scale: pk.scale} : e; }), true);
    syncEmojiBtn();
    if (S.active) renderMessages(false);
    renderList();
    if (!$("emojiPanel").classList.contains("hidden")) paintEmojiPanel();
    if (EM.refresh) EM.refresh();
    warmStickers();
  } catch (_) {}
}

const WARM = {done: new Set(), q: [], run: 0};
function warmStickers() {
  try {
    if (!EM.data || S.offline) return;
    const mine = new Set(EM.data.mine || []), urls = [];
    emojiTabs("sticker").forEach(t => (t.items || []).forEach(e => { const i = Rich.emojiList().find(x => x.token === e.token); if (i && i.url && !WARM.done.has(i.url)) urls.push(i.url); }));
    const seen = new Set(); urls.forEach(u => { if (!seen.has(u)) { seen.add(u); WARM.done.add(u); WARM.q.push(u); } });
    const pump = () => {
      while (WARM.run < 3 && WARM.q.length) {
        const u = WARM.q.shift(), im = new Image(); WARM.run++;
        const fin = () => { WARM.run--; (window.requestIdleCallback || (f => setTimeout(f, 60)))(pump); };
        im.onload = im.onerror = fin; im.decoding = "async"; im.src = u;
      }
    };
    (window.requestIdleCallback || (f => setTimeout(f, 300)))(pump);
  } catch (_) {}
}

function insertEmoji(text) {
  const s = inp.selectionStart == null ? inp.value.length : inp.selectionStart, e = inp.selectionEnd == null ? s : inp.selectionEnd;
  if (inp.value.length - (e - s) + text.length > inp.maxLength) { toast("Xabar juda uzun", "warn"); return; }
  inp.setRangeText(text, s, e, "end"); autosize();
  if (!COARSE) inp.focus({preventScroll: true});
}
function emojiPanelOpen() { return !$("emojiPanel").classList.contains("hidden"); }
function closeEmojiPanel() { $("emojiPanel").classList.add("hidden"); $("emojiBtn").classList.remove("on"); if (EM.typing) { EM.typing(); EM.typing = null; } }
function placeEmojiPanel() {
  const b = $("emojiBtn").getBoundingClientRect(), p = $("emojiPanel"), w = Math.min(344, innerWidth - 16);
  p.style.left = Math.max(8, Math.min(b.right - w, innerWidth - w - 8)) + "px";
  p.style.bottom = Math.max(8, innerHeight - b.top + 8) + "px";
}
function emojiTabs(seg, all) {
  const d = EM.data, st = seg === "sticker";
  const tabs = st ? [] : [{k: "std", label: "😀"}];
  const usable = d.emojis.filter(e => !e.builtin ? emojiUsable(e) : true);
  d.packs.forEach(pk => {
    if ((pk.kind === "sticker") !== st) return;
    if (st && !all && !(d.mine || []).includes(pk.id)) return;
    const items = usable.filter(e => e.pack === pk.id);
    if (items.length || (emojiPerms().manage && (!st || all))) tabs.push({k: "p" + pk.id, id: pk.id, label: pk.name, items, icon: items[0], kind: pk.kind || "emoji", scale: pk.scale || 100});
  });
  if (!st) {
    const loose = usable.filter(e => e.pack == null || !d.packs.some(pk => pk.id === e.pack));
    if (loose.length) tabs.push({k: "other", label: tabs.length > 1 ? "Boshqa" : "Emojilar", items: loose, icon: loose[0], kind: "emoji", scale: 100});
  }
  const mine = st ? [] : addedPacks();
  if (mine.length) {
    const head = st ? [] : [tabs[0]], rest = st ? tabs : tabs.slice(1);
    return [...head, ...rest.filter(t => mine.includes(t.k)), ...rest.filter(t => !mine.includes(t.k))];
  }
  return tabs;
}

function addedPacks() { try { const a = JSON.parse(localStorage.getItem("tc_added_packs") || "[]"); return Array.isArray(a) ? a : []; } catch (_) { return []; } }
function setAddedPacks(a) { try { localStorage.setItem("tc_added_packs", JSON.stringify(a)); } catch (_) {} }
function packOfToken(token) {
  if (EM.data) { const t = [...emojiTabs("emoji"), ...emojiTabs("sticker", true)].find(x => x.k !== "std" && (x.items || []).some(e => e.token === token)); if (t) return t; }
  const l = Rich.emojiList().filter(e => e.token); const own = l.find(e => e.token === token);
  return own ? {k: "other", label: "Emoji", items: l.map(e => ({token: e.token, label: e.label}))} : null;
}

function attachHoldPreview(grid, sel) {
  let timer = 0, shown = null, ov = null, sx = 0, sy = 0, down = null;
  const itemAt = (x, y) => { const el = document.elementFromPoint(x, y); return el && el.closest ? el.closest(sel) : null; };
  const tokenOf = it => it && it.dataset ? it.dataset.token : "";
  const show = it => {
    const t = tokenOf(it); if (!t || !Rich.isEmojiToken(t) || !Rich.hasInlineEmoji(t)) return;
    if (!ov) { ov = h("div", {class: "stk-prev"}); document.body.append(ov); requestAnimationFrame(() => ov && ov.classList.add("on")); }
    ov.textContent = ""; const im = Rich.chatEmoji(t, false); im.classList.add("pv"); ov.append(im);
    shown = it; grid._held = true; haptic(8);
  };
  const hide = () => { clearTimeout(timer); timer = 0; down = null; shown = null; if (ov) { const o = ov; ov = null; o.classList.remove("on"); setTimeout(() => o.remove(), 140); } };
  grid.addEventListener("pointerdown", e => {
    if (e.button > 0) return;
    const it = itemAt(e.clientX, e.clientY); if (!it) return;
    down = it; sx = e.clientX; sy = e.clientY; grid._held = false;
    clearTimeout(timer); timer = setTimeout(() => { timer = 0; if (down) show(down); }, 230);
  });
  grid.addEventListener("pointermove", e => {
    if (shown) { const it = itemAt(e.clientX, e.clientY); if (it && it !== shown) show(it); return; }
    if (timer && Math.hypot(e.clientX - sx, e.clientY - sy) > 10) { clearTimeout(timer); timer = 0; down = null; }
  });
  ["pointerup", "pointercancel", "pointerleave"].forEach(ev => grid.addEventListener(ev, hide));
  grid.addEventListener("contextmenu", e => { if (e.target.closest && e.target.closest(sel)) e.preventDefault(); });
  grid.addEventListener("click", e => { if (grid._held) { e.stopImmediatePropagation(); e.preventDefault(); grid._held = false; } }, true);
}

async function toggleStickerPack(pid, on, label) {
  try {
    await api("/emoji-packs/" + pid + "/mine", {method: on ? "PUT" : "DELETE"});
    await loadEmojis();
    toast(on ? "«" + (label || "To'plam") + "» stikerlari qo'shildi" : "«" + (label || "To'plam") + "» olib tashlandi", "ok");
    return true;
  } catch (err) { toast(err.message, "error"); return false; }
}
function openStickerStore() {
  if (!EM.data || !emojiPerms().use) return;
  openModal(() => {
    const all = emojiTabs("sticker", true).filter(t => t.items.length), mine = EM.data.mine || [];
    const list = h("div", {class: "sks-list"});
    if (!all.length) list.append(h("div", {class: "adm-empty", text: "Hozircha stiker to'plamlari yo'q"}));
    all.forEach(t => {
      const on = mine.includes(t.id);
      const pv = h("div", {class: "sks-pv"}); t.items.slice(0, 4).forEach(e => pv.append(Rich.chatEmoji(e.token, false)));
      list.append(h("div", {class: "sks-row"}, pv,
        h("div", {class: "sks-n"}, h("b", {text: t.label}), h("small", {text: t.items.length + " ta stiker" + (on ? " • qo'shilgan" : "")})),
        h("button", {class: "btn sm" + (on ? " ghost" : ""), type: "button", text: on ? "Olib tashlash" : "Qo'shish", onclick: async ev => {
          const b = ev.currentTarget; b.disabled = true;
          if (await toggleStickerPack(t.id, !on, t.label)) { if (S.modal) showModal(S.modal.build()); } else b.disabled = false;
        }})));
    });
    return h("div", {}, sheetHead("Stiker qo'shish", closeModal),
      h("div", {class: "em-dlg"}, h("small", {class: "emx-hint", text: "Qo'shgan to'plamlaringiz emoji tanlagichdagi «Stikerlar» bo'limida chiqadi. Istasangiz keyin olib tashlashingiz mumkin."}), list));
  }, false, false, false);
}
function openStickerPack(token) {
  const pk = packOfToken(token);
  if (!pk || !pk.items.length) return;
  const canUse = !!EM.data && emojiPerms().use;
  openModal(() => {
    const srv = pk.kind === "sticker" && pk.id != null;
    const added = srv ? ((EM.data && EM.data.mine) || []).includes(pk.id) : addedPacks().includes(pk.k);
    const grid = h("div", {class: "spk-grid" + (pk.kind === "sticker" ? " stk" : "")});
    const sendable = pk.kind === "sticker" && !!S.active && !S.offline;
    pk.items.forEach((e, ix) => {
      const im = Rich.chatEmoji(e.token, false); if (ix >= 9) im.loading = "lazy";
      const c = h("div", {class: "spk-it" + (e.token === token ? " cur" : "") + (sendable ? " sendable" : ""), title: e.label || e.token, role: sendable ? "button" : null, tabindex: sendable ? "0" : null}, im);
      c.dataset.token = e.token;
      if (sendable) {
        const go = () => { if (!canUse) { toast("Stiker yuborishga ruxsat yo'q", "warn"); return; } closeModal(); sendSticker(e.token); };
        c.addEventListener("click", go);
        c.addEventListener("keydown", ev => { if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); go(); } });
      }
      grid.append(c);
    });
    attachHoldPreview(grid, ".spk-it");
    const btn = h("button", {class: "spk-add" + (added ? " done" : ""), type: "button", onclick: async () => {
      if (srv) { if (await toggleStickerPack(pk.id, !added, pk.label) && S.modal) showModal(S.modal.build()); return; }
      const a = addedPacks();
      if (added) setAddedPacks(a.filter(k => k !== pk.k)); else setAddedPacks([pk.k, ...a.filter(k => k !== pk.k)]);
      toast(added ? "To'plam olib tashlandi" : "«" + pk.label + "» qo'shildi — emoji tanlagichda birinchi turadi", "ok");
      if (S.modal) showModal(S.modal.build());
    }}, added ? "✓ Qo'shilgan — olib tashlash" : (srv ? "Stiker qo'shish" : "Emoji qo'shish"), added ? null : h("span", {class: "spk-n", text: String(pk.items.length)}));
    return h("div", {class: "spk"},
      h("div", {class: "spk-head"}, h("span", {class: "spk-t", text: pk.label}), h("span", {class: "spk-c", text: pk.items.length + " ta"}),
        h("button", {class: "icon-btn", type: "button", onclick: closeModal, "aria-label": "Yopish"}, icon("close"))),
      grid, canUse ? btn : null);
  }, false, false, true);
}
function paintEmojiPanel(dir) {
  const panel = $("emojiPanel"), d = EM.data, perms = emojiPerms();
  if (!d) return;
  const hasStk = emojiTabs("sticker", true).length > 0;
  if (!hasStk) EM.seg = "emoji";
  const seg = EM.seg === "sticker" ? "sticker" : "emoji", isStk = seg === "sticker";
  const tabs = emojiTabs(seg);
  const tabKey = isStk ? "stab" : "tab";
  if (!tabs.some(t => t.k === EM[tabKey])) EM[tabKey] = isStk ? (tabs[0] ? tabs[0].k : "") : (tabs.length > 1 ? tabs[1].k : "std");
  const oldBar = panel.querySelector(".ep-tabs"), keep = oldBar ? oldBar.scrollLeft : 0;
  panel.textContent = "";
  const go = (k, dr) => {
    const i0 = tabs.findIndex(x => x.k === EM[tabKey]), i1 = tabs.findIndex(x => x.k === k);
    EM[tabKey] = k; paintEmojiPanel(dr || (i1 > i0 ? "r" : "l"));
  };
  const bar = h("div", {class: "ep-tabs", role: "tablist"});
  tabs.forEach(t => {
    const b = h("button", {type: "button", class: t.k === EM[tabKey] ? "on" : "", title: t.label, "aria-label": t.label, role: "tab"});
    if (t.k === "std") b.textContent = t.label; else if (t.icon) b.append(Rich.chatEmoji(t.icon.token, false)); else b.textContent = "📦";
    b.addEventListener("click", () => go(t.k));
    bar.append(b);
  });
  hScroll(bar);
  const cur = tabs.find(t => t.k === EM[tabKey]) || tabs[0];
  const sc = ((cur && cur.scale) || 100) / 100;
  const img = Math.round(Math.min(isStk ? 110 : 56, (isStk ? 64 : 32) * sc)), cell = Math.max(isStk ? 84 : 42, img + (isStk ? 18 : 10));
  const cap = h("div", {class: "ep-cap2", text: !cur ? "" : cur.k === "std" ? "Standart emojilar" : cur.label + " • " + cur.items.length + " ta" + (isStk ? " • stiker" : "")});
  const grid = h("div", {class: "ep-grid" + (isStk ? " stk" : "") + (dir ? " sl-" + dir : "")});
  grid.style.setProperty("--cell", cell + "px"); grid.style.setProperty("--img", img + "px");
  if (!cur) grid.append(h("div", {class: "ep-empty", text: "Sizda stikerlar yo'q. «＋ Stiker qo'shish» tugmasi bilan to'plam qo'shing."}));
  else if (cur.k === "std") STD_EMOJIS.forEach(c => grid.append(h("button", {type: "button", text: c, "aria-label": c, onclick: () => insertEmoji(c)})));
  else if (!cur.items.length) grid.append(h("div", {class: "ep-empty", text: "Bu to'plam hozircha bo'sh"}));
  else cur.items.forEach(e => {
    const im = Rich.chatEmoji(e.token, false); if (isStk && cur.items.indexOf(e) >= 12) im.loading = "lazy";
    const b = h("button", {type: "button", title: e.token, "aria-label": e.label, onclick: () => isStk ? sendSticker(e.token) : insertEmoji(e.token)}, im);
    b.dataset.token = e.token; grid.append(b);
  });
  attachHoldPreview(grid, "button[data-token]");
  onSwipe(grid, dd => { const i = tabs.findIndex(x => x.k === EM[tabKey]) + dd; if (i >= 0 && i < tabs.length) go(tabs[i].k, dd > 0 ? "r" : "l"); });
  if (hasStk) {
    const sg = h("div", {class: "ep-seg"},
      h("button", {type: "button", class: isStk ? "" : "on", text: "Emoji", onclick: () => { EM.seg = "emoji"; paintEmojiPanel(); }}),
      h("button", {type: "button", class: isStk ? "on" : "", text: "Stikerlar", onclick: () => { EM.seg = "sticker"; paintEmojiPanel(); }}));
    panel.append(sg);
  }
  panel.append(bar, cap, grid);
  if (isStk) {
    const sf = h("div", {class: "ep-foot"}, h("button", {class: "btn ghost", type: "button", text: "＋ Stiker qo'shish", onclick: () => { closeEmojiPanel(); openStickerStore(); }}));
    if (cur && cur.id != null) sf.append(h("button", {class: "btn ghost", type: "button", text: "✕ Olib tashlash", onclick: async () => { if (await toggleStickerPack(cur.id, false, cur.label)) paintEmojiPanel(); }}));
    panel.append(sf);
  }
  bar.scrollLeft = keep; keepTabVisible(bar);
  if (perms.create || perms.manage) {
    const foot = h("div", {class: "ep-foot"});
    if (perms.create) foot.append(h("button", {class: "btn ghost", type: "button", text: "＋ Emoji yaratish", onclick: () => { closeEmojiPanel(); openEmojiCreate(); }}));
    if (perms.manage) foot.append(h("button", {class: "btn ghost", type: "button", text: "📦 ZIP to'plam", onclick: () => { closeEmojiPanel(); openEmojiZip(); }}));
    if (perms.manage) foot.append(h("button", {class: "btn ghost", type: "button", text: "⚙ Boshqarish", onclick: () => { closeEmojiPanel(); openAdmin("emoji"); }}));
    panel.append(foot);
  }
}

async function sendSticker(token) {
  if (!S.active || S.sending) return;
  if (S.editing) { toast("Tahrirlash paytida stiker yuborib bo'lmaydi", "warn"); return; }
  if (S.active.kind === "dm" && U(S.active.uid).deleted) { toast("Bu akkaunt o'chirilgan. Xabar yuborib bo'lmaydi", "error"); return; }
  S.sending = true;
  try {
    const payload = {t: token};
    if (S.replying) payload.r = S.replying;
    const pend = Pend.add(S.active, {kind: "text", text: token});
    cancelReply(); haptic(8);
    Pend.go(pend, async p => withTarget({type: "send", cid: p.cid, e2e: await sealFor(await keyForTarget(p.target), payload)}, p.target));
  } catch (err) { toast(err.message, "error"); }
  S.sending = false;
}
function toggleEmojiPanel() {
  if (emojiPanelOpen()) { closeEmojiPanel(); return; }
  if (!EM.data || !emojiPerms().use) return;
  paintEmojiPanel(); placeEmojiPanel();
  $("emojiPanel").classList.remove("hidden"); $("emojiBtn").classList.add("on");
  if (!EM.typing) EM.typing = Typing.hold("emoji");
  const eb = $("emojiPanel").querySelector(".ep-tabs"); if (eb) keepTabVisible(eb);
}
$("emojiBtn").addEventListener("mousedown", e => e.preventDefault());
$("emojiPanel").addEventListener("mousedown", e => { if (!e.target.closest("input,select,textarea")) e.preventDefault(); });
$("emojiBtn").addEventListener("click", toggleEmojiPanel);
document.addEventListener("click", e => {
  if (!emojiPanelOpen()) return;
  const path = e.composedPath ? e.composedPath() : [];
  if (path.includes($("emojiPanel")) || path.includes($("emojiBtn"))) return;
  closeEmojiPanel();
});
document.addEventListener("keydown", e => { if (e.key === "Escape" && emojiPanelOpen()) { e.stopPropagation(); closeEmojiPanel(); } }, true);
addEventListener("resize", () => { if (emojiPanelOpen()) placeEmojiPanel(); });

function openEmojiCreate(back) {
  const d = EM.data;
  if (!d || !d.perms.create) { toast("Emoji yaratishga ruxsatingiz yo'q", "error"); return; }
  const admin = d.perms.manage;
  const st = {file: null, seq: 0, timer: 0, touched: false};
  openModal(() => {
    const pvImg = h("img", {alt: "", draggable: "false", class: "hidden"});
    const hint = h("div", {class: "em-hint", text: "Rasm tanlang: .png (oddiy emoji) yoki .gif (animatsiyali emoji). JPG va WEBP ham mumkin, 20 MB gacha"});
    const pv = h("div", {class: "em-pv"}, pvImg, hint);
    const pick = h("input", {type: "file", accept: ".png,.gif,image/png,image/gif,image/jpeg,image/webp", class: "offscreen"});
    const pickBtn = h("button", {class: "btn ghost", type: "button", text: "🖼 Rasm tanlash", onclick: () => pick.click()});
    const name = h("input", {type: "text", class: "fld", maxlength: "32", placeholder: "masalan: kulgi_1", autocomplete: "off", autocapitalize: "off", spellcheck: "false"});
    const bg = h("input", {type: "checkbox"});
    const bgRow = h("label", {class: "em-chk"}, bg, h("span", {text: "Orqa fonni olib tashlash (remove background)"}));
    const bgNote = h("small", {text: "JPG yoki shaffof bo'lmagan rasm uchun. Bir xil rangli fonda yaxshi ishlaydi."});
    const tolVal = h("b", {text: "30"});
    const tol = h("input", {type: "range", min: "5", max: "80", value: "30"});
    const tolRow = h("div", {class: "em-row hidden"}, h("label", {text: "Fon sezgirligi (kattaroq = ko'proq o'chadi)"}), h("div", {class: "em-range"}, tol, tolVal));
    const anim = h("select", {class: "fld"}, ...BADGE_ANIMS.map(([v, t]) => h("option", {value: v, text: t})));
    const animRow = h("div", {class: "em-row"}, h("label", {text: "Animatsiya"}), anim);
    const packSel = h("select", {class: "fld"}), pub = h("select", {class: "fld"}, h("option", {value: "true", text: "Hamma ishlata oladi"}), h("option", {value: "false", text: "Faqat adminlar"}));
    const fillPacks = sel => {
      packSel.textContent = ""; packSel.append(h("option", {value: "", text: "To'plamsiz"}));
      EM.data.packs.forEach(p => packSel.append(h("option", {value: String(p.id), text: p.name + (p.public ? "" : " (yopiq)")})));
      packSel.value = sel == null ? "" : String(sel);
    };
    fillPacks(EM.tab.startsWith("p") ? Number(EM.tab.slice(1)) : null);
    const newPack = h("button", {class: "btn ghost sm", type: "button", text: "＋ Yangi to'plam", onclick: async () => {
      const nm = await promptDlg("Yangi emoji to'plami", "To'plam nomi (2–24 belgi):", "", {okText: "Yaratish", placeholder: "masalan: Mem emojilar"});
      if (!nm) return;
      try { const r = await api("/emoji-packs", {method: "POST", body: {name: nm, public: true}}); await loadEmojis(); fillPacks(r.id); toast("To'plam yaratildi", "ok"); }
      catch (err) { toast(err.message, "error"); }
    }});
    packSel.addEventListener("change", () => { const p = EM.data.packs.find(x => String(x.id) === packSel.value); if (p) pub.value = String(p.public); });
    const go = h("button", {class: "btn", type: "button", text: "Emoji yaratish", disabled: true});
    const showAnim = () => { BADGE_ANIMS.forEach(([v]) => { if (v) pvImg.classList.remove("a-" + v); }); if (anim.value) pvImg.classList.add("a-" + anim.value); };
    anim.addEventListener("change", showAnim);

    const setBgState = r => {
      const locked = r.source_alpha || r.animated;
      bg.disabled = locked; bgRow.classList.toggle("off", locked);
      if (locked) bg.checked = false;
      bgNote.textContent = r.animated ? "Animatsiyali fayl: orqa fon o'chirilmaydi, animatsiya saqlanadi."
        : r.source_alpha ? "Bu rasm shaffof (PNG): orqa fon yo'q, shundayligicha qoladi."
        : "JPG yoki shaffof bo'lmagan rasm uchun. Bir xil rangli fonda yaxshi ishlaydi.";
      tolRow.classList.toggle("hidden", !bg.checked || locked);
      animRow.classList.toggle("hidden", !!r.animated);
    };
    const preview = async () => {
      if (!st.file) return;
      const my = ++st.seq; pv.classList.add("busy"); go.disabled = true;
      const fd = new FormData(); fd.append("file", st.file); fd.append("remove_bg", bg.checked ? "true" : "false"); fd.append("tolerance", tol.value);
      try {
        const r = await api("/emoji/preview", {method: "POST", body: fd});
        if (my !== st.seq) return;
        pvImg.src = r.image; pvImg.classList.remove("hidden"); showAnim(); setBgState(r);
        hint.textContent = r.bg_removed ? "Orqa fon olib tashlandi" : r.transparent ? "Shaffof fon saqlandi" : "Orqa fon bilan (xohlasangiz, yuqoridan olib tashlang)";
        go.disabled = false;
      } catch (err) {
        if (my !== st.seq) return;
        hint.textContent = err.message; if (!bg.checked) pvImg.classList.add("hidden");
        go.disabled = !bg.checked;
      } finally { if (my === st.seq) pv.classList.remove("busy"); }
    };
    const later = () => { clearTimeout(st.timer); st.timer = setTimeout(preview, 350); };
    pick.addEventListener("change", () => {
      const f = pick.files[0]; pick.value = ""; if (!f) return;
      if (f.size > 20 * 1024 * 1024) { toast("Rasm 20 MB dan oshmasligi kerak", "error"); return; }
      st.file = f; bg.checked = false; tolRow.classList.add("hidden");
      if (!st.touched) { const n = f.name.replace(/\.[^.]+$/, "").toLowerCase().replace(/[^a-z0-9_]+/g, "_").replace(/^_+|_+$/g, "").slice(0, 32); name.value = n.length >= 2 ? n : "emoji"; }
      preview();
    });
    name.addEventListener("input", () => { st.touched = true; });
    bg.addEventListener("change", () => { tolRow.classList.toggle("hidden", !bg.checked); preview(); });
    tol.addEventListener("input", () => { tolVal.textContent = tol.value; later(); });
    go.addEventListener("click", async () => {
      if (!st.file) { toast("Avval rasm tanlang", "error"); return; }
      go.disabled = true; go.textContent = "Yaratilmoqda…";
      const fd = new FormData();
      fd.append("file", st.file); fd.append("name", name.value); fd.append("anim", anim.value); fd.append("remove_bg", bg.checked ? "true" : "false");
      fd.append("tolerance", tol.value);
      if (admin) { fd.append("pack_id", packSel.value); fd.append("public", pub.value); }
      try {
        const r = await api("/emoji", {method: "POST", body: fd});
        toast("Emoji tayyor: :" + r.name + ":", "ok");
        await loadEmojis();
        if (back) back(); else closeModal();
      } catch (err) { toast(err.message, "error"); go.disabled = false; go.textContent = "Emoji yaratish"; }
    });
    return h("div", {}, sheetHead("Emoji yaratish", back || null),
      h("div", {class: "em-dlg"}, pv, pickBtn, pick,
        h("div", {class: "em-row"}, h("label", {text: "Emoji nomi (:nom: ko'rinishida yoziladi)"}), name),
        bgRow, bgNote, tolRow, animRow,
        admin ? h("div", {class: "em-two"}, h("div", {class: "em-row"}, h("label", {text: "To'plam"}), packSel, newPack), h("div", {class: "em-row"}, h("label", {text: "Kim ishlata oladi"}), pub)) : null,
        go));
  });
}

function openEmojiZip(back) {
  const d = EM.data;
  if (!d || !d.perms.manage) { toast("ZIP to'plam yaratish faqat adminlar uchun", "error"); return; }
  const st = {file: null, items: []};
  openModal(() => {
    const pick = h("input", {type: "file", accept: ".zip,application/zip,application/x-zip-compressed", class: "offscreen"});
    const pickBtn = h("button", {class: "btn ghost", type: "button", text: "📦 ZIP fayl tanlash", onclick: () => pick.click()});
    const hint = h("div", {class: "em-hint", text: "ZIP ichida PNG (oddiy emoji) va GIF (animatsiyali emoji) fayllar bo'lsin. Soni cheklanmagan, ZIP 50 MB gacha."});
    const packName = h("input", {type: "text", class: "fld", maxlength: "24", placeholder: "masalan: Mem emojilar", autocomplete: "off"});
    const pub = h("select", {class: "fld"}, h("option", {value: "true", text: "Hamma ishlata oladi"}), h("option", {value: "false", text: "Faqat adminlar"}));
    const kindSel = h("select", {class: "fld"}, h("option", {value: "emoji", text: "Emoji — matn ichida kichik"}), h("option", {value: "sticker", text: "Stiker — yakka, katta"}));
    const list = h("div", {class: "emz-list hidden"}), skipped = h("small", {class: "emz-skip"}), count = h("div", {class: "em-hint hidden"});
    const form = h("div", {class: "hidden"},
      h("div", {class: "em-two"}, h("div", {class: "em-row"}, h("label", {text: "To'plam nomi"}), packName), h("div", {class: "em-row"}, h("label", {text: "Kim ishlata oladi"}), pub)),
      h("div", {class: "em-row"}, h("label", {text: "To'plam turi"}), kindSel));
    const go = h("button", {class: "btn", type: "button", text: "To'plam yaratish", disabled: true});
    const NAME = /^[a-z0-9_]{2,32}$/;
    const check = () => {
      const used = new Map(); let n = 0, bad = false;
      st.items.forEach(it => { if (!it.on) return; n++; used.set(it.name, (used.get(it.name) || 0) + 1); });
      st.items.forEach(it => {
        const e = it.on && (!NAME.test(it.name) || used.get(it.name) > 1 || EM.data.emojis.some(x => x.token === ":" + it.name + ":"));
        it.row.classList.toggle("bad", !!e); if (e) bad = true;
      });
      count.textContent = n + " ta emoji tanlandi" + (bad ? " — qizil nomlarni to'g'rilang (2–32 belgi, a–z, 0–9, _; takrorlanmasin)" : "");
      go.disabled = !n || bad || packName.value.trim().length < 2;
    };
    const paint = r => {
      list.textContent = ""; st.items = [];
      r.items.forEach(x => {
        const it = {file: x.file, name: x.name, on: true};
        const chk = h("input", {type: "checkbox", checked: true, "aria-label": "Qo'shish"});
        const nm = h("input", {type: "text", class: "fld", maxlength: "32", value: x.name, autocomplete: "off", autocapitalize: "off", spellcheck: "false", "aria-label": "Emoji nomi"});
        chk.addEventListener("change", () => { it.on = chk.checked; check(); });
        nm.addEventListener("input", () => { nm.value = nm.value.toLowerCase().replace(/[^a-z0-9_]/g, "_"); it.name = nm.value; check(); });
        it.row = h("div", {class: "emz-row"}, chk, h("img", {src: x.image, alt: "", draggable: "false"}), h("div", {class: "emz-n"}, nm, h("small", {text: x.animated ? "GIF • animatsiyali" : "PNG • oddiy"})));
        st.items.push(it); list.append(it.row);
      });
      skipped.textContent = r.skipped.length ? "O'tkazib yuborildi: " + r.skipped.map(k => k.file + " (" + k.error + ")").join(", ") : "";
      list.classList.remove("hidden"); form.classList.remove("hidden"); count.classList.remove("hidden"); check();
    };
    pick.addEventListener("change", async () => {
      const f = pick.files[0]; pick.value = ""; if (!f) return;
      if (f.size > 12 * 1024 * 1024) { toast("ZIP 12 MB dan oshmasligi kerak", "error"); return; }
      st.file = f; hint.textContent = "Ochilmoqda…"; go.disabled = true;
      const fd = new FormData(); fd.append("file", f);
      try {
        const r = await api("/emoji-pack/zip-preview", {method: "POST", body: fd});
        hint.textContent = f.name + " — " + r.items.length + " ta emoji topildi";
        if (!packName.value) packName.value = f.name.replace(/\.zip$/i, "").replace(/[_]+/g, " ").slice(0, 24);
        paint(r);
      } catch (err) { hint.textContent = err.message; list.classList.add("hidden"); form.classList.add("hidden"); count.classList.add("hidden"); st.items = []; }
    });
    packName.addEventListener("input", () => { if (st.items.length) check(); });
    go.addEventListener("click", async () => {
      const sel = st.items.filter(i => i.on);
      go.disabled = true; go.textContent = "Yaratilmoqda…";
      const fd = new FormData();
      fd.append("file", st.file); fd.append("pack_name", packName.value); fd.append("public", pub.value); fd.append("kind", kindSel.value);
      fd.append("items", JSON.stringify(sel.map(i => ({file: i.file, name: i.name}))));
      try {
        const r = await api("/emoji-pack/zip", {method: "POST", body: fd});
        toast("«" + r.pack + "»: " + r.created.length + " ta emoji qo'shildi" + (r.failed.length ? ", " + r.failed.length + " tasi yaratilmadi" : ""), r.failed.length ? "warn" : "ok");
        await loadEmojis();
        if (back) back(); else closeModal();
      } catch (err) { toast(err.message, "error"); go.disabled = false; go.textContent = "To'plam yaratish"; }
    });
    return h("div", {}, sheetHead("Emoji to'plami (ZIP)", back || null),
      h("div", {class: "em-dlg"}, hint, pickBtn, pick, form, count, list, skipped, go));
  }, false, false, false);
}

const PK_KIND = {emoji: "Emoji", sticker: "Stiker"};
const packOf = id => EM.data && EM.data.packs.find(x => x.id === id);

function emojiEditStrip(e, after) {
  const d = EM.data;
  const pk = h("select", {class: "fld"}, h("option", {value: "", text: "To'plamsiz"}), ...d.packs.map(p => h("option", {value: String(p.id), text: p.name + " (" + PK_KIND[p.kind || "emoji"].toLowerCase() + ")"}))); pk.value = e.pack == null ? "" : String(e.pack);
  const pb = h("select", {class: "fld"}, h("option", {value: "true", text: "Hamma"}), h("option", {value: "false", text: "Faqat adminlar"})); pb.value = String(e.public);
  const an = h("select", {class: "fld", disabled: e.animated}, ...BADGE_ANIMS.map(([v, t]) => h("option", {value: v, text: t}))); an.value = e.anim || "";
  const save = async () => { try { await api("/emoji/" + e.id, {method: "PATCH", body: {anim: an.value, pack_id: pk.value ? Number(pk.value) : null, public: pb.value === "true"}}); toast("Saqlandi", "ok"); } catch (err) { toast(err.message, "error"); } await loadEmojis(); after && after(); };
  [pk, pb, an].forEach(x => x.addEventListener("change", save));
  const del = h("button", {class: "btn danger sm", type: "button", text: "O'chirish", onclick: async () => {
    if (!await confirmDlg(e.token + " emojisi o'chadi. Eski xabarlarda u oddiy matn bo'lib ko'rinadi.", {title: "Emojini o'chirish", okText: "O'chirish", danger: true})) return;
    try { await api("/emoji/" + e.id, {method: "DELETE"}); toast("Emoji o'chirildi", "ok"); } catch (err) { toast(err.message, "error"); }
    await loadEmojis(); after && after(true);
  }});
  return h("div", {class: "emx-edit"},
    h("div", {class: "emx-eh"}, Rich.chatEmoji(e.token, false), h("b", {text: e.token}), h("small", {text: (e.author || "—") + (e.animated ? " • animatsiyali fayl" : "")})),
    h("div", {class: "emx-ef"}, h("label", {text: "To'plam"}), pk, h("label", {text: "Kim ishlatadi"}), pb, h("label", {text: "Animatsiya"}), an), del);
}

function openEmojiEdit(id, back) {
  openModal(() => {
    const e = EM.data && EM.data.emojis.find(x => x.id === id);
    if (!e) { closeModal(); return h("div"); }
    return h("div", {}, sheetHead("Emoji", back || closeModal), h("div", {class: "em-dlg"}, emojiEditStrip(e, gone => { if (gone) (back || closeModal)(); else showModal(S.modal.build()); })));
  }, false, false, false);
}

function openPackWindow(pid, back) {
  const first = packOf(pid); if (!first) return;
  const st = {name: first.name, pub: first.public, kind: first.kind || "emoji", scale: first.scale || 100, sel: null};
  const done = () => { if (back) back(); else closeModal(); };
  openModal(() => {
    const d = EM.data, pk = packOf(pid);
    if (!pk) { done(); return h("div"); }
    const items = d.emojis.filter(e => !e.builtin && e.pack === pid);
    const isStk = st.kind === "sticker";

    const kindBtn = (k, t) => h("button", {type: "button", class: st.kind === k ? "on" : "", text: t, onclick: () => { st.kind = k; showModal(S.modal.build()); }});
    const nm = h("input", {type: "text", class: "fld", maxlength: "24", value: st.name, autocomplete: "off"}); nm.addEventListener("input", () => { st.name = nm.value; });
    const pb = h("select", {class: "fld"}, h("option", {value: "true", text: "Hamma uchun"}), h("option", {value: "false", text: "Faqat adminlar"})); pb.value = String(st.pub); pb.addEventListener("change", () => { st.pub = pb.value === "true"; });

    const prev = h("div", {class: "emx-prev"}), grid = h("div", {class: "ep-grid emx-grid" + (isStk ? " stk" : "")});
    const val = h("b", {class: "emx-val"});
    const paintSize = () => {
      const sc = st.scale / 100;
      val.textContent = st.scale + "%";
      const img = Math.round(Math.min(isStk ? 110 : 56, (isStk ? 64 : 32) * sc)), cell = Math.max(isStk ? 84 : 42, img + (isStk ? 18 : 10));
      grid.style.setProperty("--cell", cell + "px"); grid.style.setProperty("--img", img + "px");
      prev.textContent = "";
      const t = items[0]; if (!t) { prev.append(h("small", {text: "Ko'rinish uchun to'plamga emoji qo'shing"})); return; }

      const fit = inner => {
        if (!inner || !inner.isConnected || !prev.clientWidth) return;
        inner.style.transform = "none";
        const k = Math.min(1, (prev.clientWidth - 16) / (inner.offsetWidth || 1), (prev.clientHeight - 16) / (inner.offsetHeight || 1));
        inner.style.transform = k < 0.999 ? "scale(" + Math.max(0.2, k).toFixed(3) + ")" : "none";
      };
      const put = (...nodes) => { const inner = h("div", {class: "emx-fitin"}, ...nodes); prev.append(inner); fit(inner); requestAnimationFrame(() => fit(inner)); setTimeout(() => fit(inner), 150); };
      const mk = (solo, big) => { const i = Rich.chatEmoji(t.token, false); i.className = "ce" + (big ? " big" : "") + (solo ? " solo" : ""); i.style.setProperty("--es", String(sc)); i.addEventListener("load", () => fit(prev.firstElementChild)); return i; };
      if (isStk) put(h("div", {class: "emx-bub"}, h("div", {class: "btext bigemo bigemo-1 emx-stk"}, mk(false, true))), h("small", {text: "Chatda yakka yuborilganda shunday ko'rinadi (matn bilan aralashmaydi)"}));
      else put(h("div", {class: "emx-bub"}, h("div", {class: "btext emx-line"}, "Salom ", mk(), " qalaysan ", mk(), "?")), h("div", {class: "emx-bub"}, h("div", {class: "btext soloemo soloemo-1"}, mk(true))), h("small", {text: "Matn ichida va yakka yuborilganda"}));
    };
    const rng = h("input", {type: "range", min: "50", max: "200", step: "5", value: String(st.scale), class: "emx-rng", "aria-label": "Hajm"});
    rng.addEventListener("input", () => { st.scale = Number(rng.value); paintSize(); });
    const step = dv => () => { st.scale = Math.max(50, Math.min(200, st.scale + dv)); rng.value = String(st.scale); paintSize(); };
    const size = h("div", {class: "emx-size"},
      h("div", {class: "emx-sh"}, h("span", {text: "Hajm"}), val, h("button", {class: "btn ghost sm", type: "button", text: "100%", onclick: () => { st.scale = 100; rng.value = "100"; paintSize(); }})),
      h("div", {class: "emx-sr"}, h("button", {class: "btn ghost sm", type: "button", text: "−", "aria-label": "Kichiklashtirish", onclick: step(-5)}), rng, h("button", {class: "btn ghost sm", type: "button", text: "＋", "aria-label": "Kattalashtirish", onclick: step(5)})));

    let edit = h("div");
    const paintEdit = () => { const e = items.find(x => x.id === st.sel); const n = e ? emojiEditStrip(e, gone => { if (gone) st.sel = null; showModal(S.modal.build()); }) : h("div"); edit.replaceWith(n); edit = n; };
    items.forEach(e => {
      const b = h("button", {type: "button", class: st.sel === e.id ? "on" : "", title: e.token, "aria-label": e.label, onclick: () => { st.sel = st.sel === e.id ? null : e.id; grid.querySelectorAll("button").forEach(x => x.classList.toggle("on", x.dataset.id === String(st.sel))); paintEdit(); }}, Rich.chatEmoji(e.token, false));
      b.dataset.id = String(e.id); grid.append(b);
    });
    if (!items.length) grid.append(h("div", {class: "ep-empty", text: "Bu to'plam hozircha bo'sh. «Emoji yaratish» yoki ZIP orqali qo'shing."}));
    if (st.sel != null && items.some(x => x.id === st.sel)) edit = emojiEditStrip(items.find(x => x.id === st.sel), gone => { if (gone) st.sel = null; showModal(S.modal.build()); });

    const savePack = h("button", {class: "btn", type: "button", text: "Saqlash", onclick: async () => {
      try { await api("/emoji-packs/" + pid, {method: "PATCH", body: {name: st.name, public: st.pub, kind: st.kind, scale: st.scale}}); toast("Saqlandi", "ok"); await loadEmojis(); done(); }
      catch (err) { toast(err.message, "error"); }
    }});
    const delPack = h("button", {class: "btn danger", type: "button", text: "To'plamni o'chirish", onclick: async () => {
      if (!await confirmDlg("«" + pk.name + "» to'plami o'chadi. Ichidagi emojilar o'chmaydi, to'plamsiz bo'lib qoladi.", {title: "To'plamni o'chirish", okText: "O'chirish", danger: true})) return;
      try { await api("/emoji-packs/" + pid, {method: "DELETE"}); toast("To'plam o'chirildi", "ok"); await loadEmojis(); done(); } catch (err) { toast(err.message, "error"); }
    }});
    paintSize();
    return h("div", {}, sheetHead(pk.name, done),
      h("div", {class: "em-dlg emx-win"},
        h("div", {class: "emx-seg"}, kindBtn("emoji", "Emoji"), kindBtn("sticker", "Stiker")),
        h("small", {class: "emx-hint", text: isStk ? "Stiker: faqat yakka yuboriladi, katta ko'rinadi. Tanlagichda alohida «Stikerlar» bo'limida turadi." : "Emoji: matn ichida kichik turadi. Yakka yuborilsa ham o'rtacha o'lchamda (katta qilinsa xira bo'ladi)."}),
        h("div", {class: "em-two"}, h("div", {class: "em-row"}, h("label", {text: "Nomi"}), nm), h("div", {class: "em-row"}, h("label", {text: "Kim ishlata oladi"}), pb)),
        h("div", {class: "emx-sticky"}, size, prev),
        h("div", {class: "ep-cap2", text: "Ichidagi emojilar • " + items.length + " ta (bosib tahrirlang)"}), grid, edit,
        h("div", {class: "emx-act"}, savePack, delPack)));
  }, false, false, false);
}

function emojiManager(body, alive) {
  const act = async (fn, okText) => { try { await fn(); if (okText) toast(okText, "ok"); } catch (err) { toast(err.message, "error"); } await loadEmojis(); };
  let q = "", usersOpen = false, newKind = "emoji";
  const reopen = () => openAdmin("emoji");
  const paint = () => {
    const d = EM.data;
    body.textContent = "";
    if (!d || !d.perms.manage) { body.append(h("div", {class: "adm-empty", text: "Yuklanmoqda…"})); return; }

    const mode = h("select", {class: "fld"}, h("option", {value: "off", text: "Faqat adminlar (va ruxsat berilganlar)"}), h("option", {value: "use", text: "Hamma ochiq emojilarni ishlatadi"}));
    mode.value = d.global;
    mode.addEventListener("change", () => act(() => api("/emoji-settings", {method: "PUT", body: {mode: mode.value}}), "Saqlandi"));
    const top = h("div", {class: "em-sec emx-top"}, h("div", {class: "emx-row"}, h("label", {text: "Oddiy foydalanuvchilar"}), mode),
      h("div", {class: "ep-row"}, h("button", {class: "btn sm", type: "button", text: "＋ Emoji", onclick: () => openEmojiCreate(reopen)}), h("button", {class: "btn sm", type: "button", text: "📦 ZIP to'plam", onclick: () => openEmojiZip(reopen)})));

    const packs = h("div", {class: "em-sec"}, h("h4", {text: "📦 To'plamlar (" + d.packs.length + ")"}));
    const plist = h("div", {class: "emx-plist"});
    d.packs.forEach(pk => {
      const its = d.emojis.filter(e => !e.builtin && e.pack === pk.id);
      const ic = h("span", {class: "emx-ic"}); if (its[0]) ic.append(Rich.chatEmoji(its[0].token, false)); else ic.textContent = "📦";
      plist.append(h("button", {class: "emx-pack", type: "button", onclick: () => openPackWindow(pk.id, reopen)}, ic,
        h("span", {class: "emx-pn"}, h("b", {text: pk.name}), h("small", {text: (pk.kind === "sticker" ? "Stiker" : "Emoji") + " • " + its.length + " ta • " + (pk.scale || 100) + "%" + (pk.public ? "" : " • yopiq")})),
        h("span", {class: "emx-badge " + (pk.kind === "sticker" ? "stk" : "emo"), text: pk.kind === "sticker" ? "STIKER" : "EMOJI"}), h("span", {class: "emx-go", text: "›"})));
    });
    if (!d.packs.length) plist.append(h("p", {class: "adm-note", text: "Hali to'plam yo'q."}));
    packs.append(plist);
    const newName = h("input", {type: "text", class: "fld", maxlength: "24", placeholder: "Yangi to'plam nomi", autocomplete: "off"});
    const kbox = h("div", {class: "emx-seg sm"});
    [["emoji", "Emoji"], ["sticker", "Stiker"]].forEach(([k, t]) => { const b = h("button", {type: "button", class: newKind === k ? "on" : "", text: t}); b.dataset.k = k; b.addEventListener("click", () => { newKind = k; kbox.querySelectorAll("button").forEach(x => x.classList.toggle("on", x.dataset.k === newKind)); }); kbox.append(b); });
    packs.append(h("div", {class: "emx-new"}, newName, kbox, h("button", {class: "btn sm", type: "button", text: "Yaratish", onclick: () => {
      if (!newName.value.trim()) return;
      act(() => api("/emoji-packs", {method: "POST", body: {name: newName.value, public: true, kind: newKind}}), "To'plam yaratildi");
    }})));

    const loose = d.emojis.filter(e => !e.builtin && (e.pack == null || !d.packs.some(pk => pk.id === e.pack)));
    const looseSec = h("div", {class: "em-sec"});
    if (loose.length) {
      looseSec.append(h("h4", {text: "🖼 To'plamsiz emojilar (" + loose.length + ")"}));
      const g = h("div", {class: "emx-cells"});
      loose.forEach(e => g.append(h("button", {type: "button", title: e.token, onclick: () => openEmojiEdit(e.id, reopen)}, Rich.chatEmoji(e.token, false))));
      looseSec.append(g);
    }

    const users = h("div", {class: "em-sec"}, h("button", {class: "emx-fold", type: "button", onclick: () => { usersOpen = !usersOpen; paint(); }}, h("span", {text: "👤 Foydalanuvchilar ruxsati"}), h("span", {text: usersOpen ? "▾" : "▸"})));
    if (usersOpen) {
      users.append(h("p", {class: "adm-note", text: "«Yaratadi» ruxsati olgan foydalanuvchi o'z emojisini yarata oladi. Adminlarda hammasi doim bor."}));
      const search = h("input", {type: "text", class: "fld", placeholder: "Nickname yoki @username", autocomplete: "off", value: q});
      const ulist = h("div", {});
      const fillUsers = () => {
        ulist.textContent = "";
        const t = q.trim().toLowerCase().replace(/^@/, "");
        const ms = S.members.filter(m => m.role === "user" && !m.deleted && (!t || (m.nickname || "").toLowerCase().includes(t) || (m.username || "").toLowerCase().includes(t))).slice(0, 60);
        if (!ms.length) ulist.append(h("div", {class: "adm-empty", text: "Hech kim topilmadi"}));
        ms.forEach(m => {
          const sel = h("select", {class: "fld"}, h("option", {value: "0", text: "Umumiy sozlama"}), h("option", {value: "1", text: "Ishlatadi"}), h("option", {value: "2", text: "Ishlatadi + yaratadi"}));
          sel.value = String((d.user_perms || {})[String(m.id)] || 0);
          sel.addEventListener("change", () => act(() => api("/emoji-perm/" + m.id, {method: "PUT", body: {perm: Number(sel.value)}}), "Ruxsat saqlandi"));
          ulist.append(h("div", {class: "em-urow"}, h("span", {text: m.nickname + " @" + m.username}), sel));
        });
      };
      search.addEventListener("input", () => { q = search.value; fillUsers(); });
      fillUsers();
      users.append(search, ulist);
    }
    body.append(top, packs, looseSec, users);
  };
  const refresh = () => {
    if (!body.isConnected || (alive && !alive())) { if (EM.refresh === refresh) EM.refresh = null; return; }
    paint();
  };
  EM.refresh = refresh;
  paint();
  if (!EM.data) loadEmojis();
}
function openBadgePicker(u, back) {
  const go = back || (() => openProfile(u.id));
  openModal(() => h("div", {}, sheetHead("Nishon: @" + u.username, go), h("div", {class: "sh-body"}, badgeEditor(U(u.id), go))), false);
}

