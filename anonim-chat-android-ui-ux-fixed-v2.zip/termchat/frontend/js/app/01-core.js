/* =====================================================================
   Anonim Chat by Hevorix — veb-mijoz
   Matn DOM'ga faqat textContent orqali chiqariladi (XSS yo'q, CSP qat'iy).
   ===================================================================== */
const NS = "http://www.w3.org/2000/svg";
const $ = id => document.getElementById(id);
const APP_NAME = "Anonim Chat by Hevorix";
const LS_THEME = "termchat_theme";
const LS_STAY = "termchat_stay";                // "bu qurilmada kirib qolish" yoqilgan bo'lsa — sessiya tokeni (foydalanuvchi o'zi tanlaydi)
const WS_UNAUTHORIZED = 4401, WS_FORBIDDEN = 4403, WS_IP_BLOCKED = 4410;
const IDLE_MS = 5 * 60 * 1000;                   // oyna/chat ochiq, lekin 5 daqiqa tegilmasa — qayta login talab qilinadi
const HB_MS = 15000, HB_DEAD_MS = 40000;         // yurak urishi: har 15 s ping; 40 s server javobi yo'q bo'lsa ulanish o'lik hisoblanadi
const delay = ms => new Promise(r => setTimeout(r, ms));
try { localStorage.removeItem("termchat_token"); } catch (_) {}      // eski versiyada saqlangan token endi ishlatilmaydi
const PALETTE = ["#e17076", "#e0954f", "#a695e7", "#7bc862", "#4fb6b9", "#65aadd", "#ee7aae"];
const MONTHS = ["yanvar", "fevral", "mart", "aprel", "may", "iyun", "iyul", "avgust", "sentabr", "oktabr", "noyabr", "dekabr"];
const COARSE = matchMedia("(pointer: coarse)").matches;
const isMobile = () => matchMedia("(max-width: 760px)").matches;

const S = {
  token: null, me: null, ws: null, retry: 0, wantClose: false, mode: "login",
  users: new Map(),            // id -> foydalanuvchi
  members: [],                 // a'zolar ro'yxati (serverdan)
  online: new Set(),
  group: {msgs: [], unread: 0, more: false},   // more: tepada yana eski xabarlar bor (tepaga chiqilganda yuklanadi)
  dms: new Map(),              // uid -> {msgs, loaded, buffer, unread, last}
  chn: new Map(),              // kanal id -> {msgs, loaded, buffer, unread, last, more} (kanal postlari, umumiy chat bilan bir xil xabar tizimi)
  chList: [],                  // kanallar ro'yxati (serverdan; js/channels.js yangilaydi)
  active: null,                // {kind:"group"} | {kind:"dm", uid} | {kind:"channel", id}
  tab: "chats", query: "", editing: null, away: 0, modal: null,
  replying: null,              // {id, nickname, text, image} — javob berilayotgan xabar
  pendingImg: null,            // {blob, url, name} — yuborishga tayyor rasm
  sending: false,
  rec: null, recBusy: false, recTimer: 0,   // ovoz/video yozilmoqda: Voice.record() yoki VNote.record() obyekti
  recKind: "voice", recMode: "voice", vfacing: "user", starting: false, startAbort: false, flipping: false, noClickUntil: 0,   // recMode: tugma rejimi (voice | video)
  imgs: new Map(),             // xabar id -> "loading" | "open" (rasm yuklash holati)
  sel: null,                   // Set<id> — belgilash rejimi yoqilgan bo'lsa
  played: new Map(),           // xabar id -> blob URL (ijro etilgan video/audio)
  previews: new Map(),         // xabar id -> {kind:"code"|"pcap", ...} — fayl ko'rinishi (faqat matn sifatida, hech narsa ishga tushmaydi)
  fx: new Map(),               // terminal animatsiyasi: kalit -> birinchi chizilgan vaqt (qayta-qayta animatsiya bo'lmasin)
  chat: {slowmode: 0, locked: false},   // umumiy chat moderatsiya holati (serverdan)
};

/* ---------------- yordamchilar ---------------- */
function h(tag, props, ...kids) {
  const e = document.createElement(tag);
  if (props) for (const [k, v] of Object.entries(props)) {
    if (v == null || v === false) continue;
    if (k === "class") e.className = v;
    else if (k === "text") e.textContent = v;
    else if (k.startsWith("on")) e.addEventListener(k.slice(2), v);
    else e.setAttribute(k, v === true ? "" : v);
  }
  for (const c of kids.flat()) {
    if (c == null || c === false) continue;
    e.append(c.nodeType ? c : document.createTextNode(String(c)));
  }
  return e;
}
function svgUse(href, cls) {
  const s = document.createElementNS(NS, "svg"); s.setAttribute("class", cls);
  const u = document.createElementNS(NS, "use"); u.setAttribute("href", href); s.append(u);
  return s;
}
const icon = (name, cls) => svgUse("#i-" + name, cls || "ic");
const pad2 = n => String(n).padStart(2, "0");
const hhmm = ts => { const d = new Date(ts * 1000); return pad2(d.getHours()) + ":" + pad2(d.getMinutes()); };
const dayKey = ts => { const d = new Date(ts * 1000); return d.getFullYear() + "-" + d.getMonth() + "-" + d.getDate(); };
function dayLabel(ts) {
  const d = new Date(ts * 1000), now = new Date();
  if (dayKey(ts) === dayKey(now / 1000)) return "Bugun";
  const y = new Date(now); y.setDate(now.getDate() - 1);
  if (dayKey(ts) === dayKey(y / 1000)) return "Kecha";
  return d.getDate() + "-" + MONTHS[d.getMonth()] + (d.getFullYear() !== now.getFullYear() ? ", " + d.getFullYear() : "");
}
function listTime(ts) {
  const d = new Date(ts * 1000), now = new Date();
  if (dayKey(ts) === dayKey(now / 1000)) return hhmm(ts);
  const y = new Date(now); y.setDate(now.getDate() - 1);
  if (dayKey(ts) === dayKey(y / 1000)) return "Kecha";
  return pad2(d.getDate()) + "." + pad2(d.getMonth() + 1) + "." + String(d.getFullYear()).slice(2);
}
const colorOf = id => PALETTE[Math.abs(id) % PALETTE.length];
const isStaff = u => !!u && (u.role === "owner" || u.role === "admin");
const HEX = /^#[0-9a-f]{6}$/i, TONES = {owner: "#f7b733", admin: "#7b61ff"};
const hexRgb = x => { const n = parseInt(x.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
const mixHex = (x, to, t) => "#" + hexRgb(x).map((v, i) => Math.round(v + (to[i] - v) * t).toString(16).padStart(2, "0")).join("");
function toneOf(u) {
  const base = HEX.test(u.color || "") ? u.color.toLowerCase() : TONES[u.role];
  const [r, g, b] = hexRgb(base);
  return {p2: base, p1: mixHex(base, [255, 255, 255], .55), p3: mixHex(base, [0, 0, 0], .4), pr: r + "," + g + "," + b,
    pt: (0.299 * r + 0.587 * g + 0.114 * b) / 255 > .6 ? "#2b2000" : "#fff"};
}
/** Ega/admin elementiga o'zi tanlagan rangni beradi (CSS o'zgaruvchilari; CSP uchun CSSOM orqali). */
function tint(el, u) {
  if (!isStaff(u)) return el;
  const t = toneOf(u);
  ["p1", "p2", "p3", "pr", "pt"].forEach(k => el.style.setProperty("--" + k, t[k]));
  return el;
}
const roleLabel = r => r === "owner" ? "Platforma egasi" : r === "admin" ? "Administrator" : "";
const U = id => S.users.get(id) || {id, nickname: "Noma'lum", username: "?", role: "user", bio: "", avatar: null};
const isOnline = id => S.me && (id === S.me.id || S.online.has(id));
const onlineCount = () => new Set([...S.online, S.me.id]).size;
const amAdmin = () => isStaff(S.me);
const dmOf = uid => {
  if (!S.dms.has(uid)) S.dms.set(uid, {msgs: [], loaded: false, buffer: [], unread: 0, last: null, more: false});
  return S.dms.get(uid);
};
const chOf = id => {
  if (!S.chn.has(id)) S.chn.set(id, {msgs: [], loaded: false, buffer: [], unread: 0, last: null, more: false});
  return S.chn.get(id);
};
const chInfo = id => S.chList.find(c => c.id === id) || null;
const isActiveChan = id => !!S.active && S.active.kind === "channel" && S.active.id === id;
function upsertUser(u) {
  if (!u || u.id == null) return;
  const merged = Object.assign({}, S.users.get(u.id), u);
  S.users.set(u.id, merged);
  if (S.me && u.id === S.me.id) S.me = Object.assign({}, S.me, u);
}

function toast(text, level) {
  const t = h("div", {class: "toast " + (level || "info"), text});
  $("toasts").append(t);
  while ($("toasts").children.length > 4) $("toasts").firstChild.remove();
  setTimeout(() => t.remove(), level === "error" ? 5000 : 3500);
}

async function api(path, opts = {}) {
  const headers = Object.assign({Authorization: "Bearer " + S.token}, opts.headers || {});
  let body = opts.body;
  if (body && !(body instanceof FormData)) { headers["Content-Type"] = "application/json"; body = JSON.stringify(body); }
  const r = await SC.fetch("/api" + path, {method: opts.method || "GET", headers, body});
  const j = await r.json().catch(() => ({}));
  if (r.status === 401) { showAuth("Sessiya tugagan, qayta kiring"); throw new Error("401"); }
  if (!r.ok) throw new Error(typeof j.detail === "string" ? j.detail : "Xato, qayta urinib ko'ring");
  return j;
}
function wsTry(obj) {                                  // jimjit yuborish: xato/toast yo'q; ulanish bo'lmasa false (xabar navbatda kutadi)
  if (S.offline || !S.ws || S.ws.readyState !== 1) return false;
  try { S.ws.send(JSON.stringify(obj)); return true; } catch (_) { return false; }
}
function wsSend(obj) {
  if (S.offline) { toast("Oflayn rejim: faqat o'qish mumkin", "error"); return false; }
  if (!S.ws || S.ws.readyState !== 1) { toast("Ulanish yo'q, biroz kuting…", "error"); return false; }
  S.ws.send(JSON.stringify(obj));
  return true;
}

