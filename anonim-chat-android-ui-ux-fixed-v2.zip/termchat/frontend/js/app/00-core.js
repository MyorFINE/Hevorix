const NS = "http://www.w3.org/2000/svg";
const $ = id => document.getElementById(id);
const APP_NAME = "Anonim Chat by Hevorix";
const LS_THEME = "termchat_theme";
const LS_STAY = "termchat_stay";
const WS_UNAUTHORIZED = 4401, WS_FORBIDDEN = 4403, WS_IP_BLOCKED = 4410;
const IDLE_MS = 5 * 60 * 1000;
const HB_MS = 15000, HB_DEAD_MS = 40000;
const delay = ms => new Promise(r => setTimeout(r, ms));
try { localStorage.removeItem("termchat_token"); } catch (_) {}
const PALETTE = ["#e17076", "#e0954f", "#a695e7", "#7bc862", "#4fb6b9", "#65aadd", "#ee7aae"];
const MONTHS = ["yanvar", "fevral", "mart", "aprel", "may", "iyun", "iyul", "avgust", "sentabr", "oktabr", "noyabr", "dekabr"];
const COARSE = matchMedia("(pointer: coarse)").matches;
const isMobile = () => matchMedia("(max-width: 760px)").matches;

const S = {
  token: null, me: null, ws: null, retry: 0, wantClose: false, mode: "login",
  users: new Map(),
  members: [],
  online: new Set(),
  group: {msgs: [], unread: 0, more: false},
  dms: new Map(),
  chn: new Map(),
  chList: [],
  active: null,
  tab: "chats", query: "", editing: null, away: 0, modal: null,
  replying: null,
  pendingImg: null,
  sending: false,
  rec: null, recBusy: false, recTimer: 0,
  recKind: "voice", recMode: "voice", vfacing: "user", starting: false, startAbort: false, flipping: false, noClickUntil: 0,
  imgs: new Map(),
  sel: null,
  played: new Map(),
  previews: new Map(),
  fx: new Map(),
  chat: {slowmode: 0, locked: false},
};

