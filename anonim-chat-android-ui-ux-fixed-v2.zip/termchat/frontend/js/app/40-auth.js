function setMode(m) {
  S.mode = m;
  $("tabL").classList.toggle("on", m === "login");
  $("tabR").classList.toggle("on", m === "register");
  $("nickWrap").classList.toggle("hidden", m === "login");
  $("regHint").classList.toggle("hidden", m === "login");
  $("submitBtn").textContent = m === "login" ? "Kirish" : "Ro'yxatdan o'tish";
  $("f_pass").autocomplete = m === "login" ? "current-password" : "new-password";
  $("autherr").textContent = "";
  $("unameChk").classList.add("hidden");
  if (m === "register") $("f_user").dispatchEvent(new Event("input"));
}
let unameTimer = null, unameSeq = 0;
$("f_user").addEventListener("input", () => {
  clearTimeout(unameTimer);
  const chk = $("unameChk"), v = $("f_user").value.trim().replace(/^@/, "");
  if (S.mode !== "register" || !v) { chk.classList.add("hidden"); return; }
  unameTimer = setTimeout(async () => {
    const seq = ++unameSeq;
    try {
      const r = await SC.fetch("/api/username/" + encodeURIComponent(v));
      if (!r.ok) return;
      const j = await r.json();
      if (seq !== unameSeq || S.mode !== "register") return;
      chk.className = "uchk " + (j.available ? "ok" : "bad");
      chk.textContent = j.available ? "✓ Username bo'sh" : "✗ " + j.reason;
    } catch (_) {}
  }, 300);
});
if (!SC.supported()) $("autherr").textContent = "Shifrlash uchun HTTPS (xavfsiz ulanish) kerak. Saytni https:// orqali oching.";
$("tabL").onclick = () => setMode("login");
$("tabR").onclick = () => setMode("register");

const JSON_H = {"Content-Type": "application/json"};
$("form").addEventListener("submit", async e => {
  e.preventDefault();
  const btn = $("submitBtn"); btn.disabled = true; $("autherr").textContent = "";
  const username = $("f_user").value.trim().replace(/^@/, ""), password = $("f_pass").value;
  try {
    if (!SC.supported()) throw new Error("Shifrlash uchun HTTPS (xavfsiz ulanish) kerak");
    $("autherr").textContent = "Shifrlash kalitlari tayyorlanmoqda…";
    await new Promise(r => setTimeout(r, 30));
    let r, gen = null;
    if (S.mode === "register") {
      gen = await xGenerate(username, password, E2E.KDF_DEFAULT);
      r = await SC.fetch("/api/register", {method: "POST", headers: JSON_H, body: JSON.stringify({username, nickname: $("f_nick").value.trim() || username, password: gen.kd.auth, e2ee: gen.keys, remember: $("f_stay").checked})});
    } else {
      const kr = await SC.fetch("/api/kdf", {method: "POST", headers: JSON_H, body: JSON.stringify({username})});
      const kp = await kr.json().catch(() => ({}));
      const secret = kp.auth_v === 0 ? password : (await E2E.deriveFromPassword(username, password, kp.kdf_iter || E2E.KDF_DEFAULT)).auth;
      r = await SC.fetch("/api/login", {method: "POST", headers: JSON_H, body: JSON.stringify({username, password: secret, remember: $("f_stay").checked})});
    }
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(typeof j.detail === "string" ? j.detail : "Xato, qayta urinib ko'ring");
    S.token = j.token; SC.setToken(S.token); S.lastAct = Date.now(); xReset();
    try {
      if (gen) await xInstall(j.me, j.me.username, gen.ident, gen.keys, E2E.KDF_DEFAULT, true);
      else await xUnlock({upgrade: j.upgrade, e2ee: j.e2ee}, j.me, j.me.username, password);
    } catch (err) { try { await SC.fetch("/api/logout", {method: "POST", headers: {Authorization: "Bearer " + S.token}}); } catch (_) {} S.token = null; SC.setToken(null); throw err; }
    $("f_pass").value = ""; $("autherr").textContent = "";
    if ($("f_stay").checked) await persistStay(); else await forgetStay();
    Off.arm({user: username, password, stay: $("f_stay").checked});
    openApp();
  } catch (err) { $("autherr").textContent = err.message; }
  btn.disabled = false;
});

function resetState() {
  S.offline = false; document.body.classList.remove("offline-mode");
  S.me = null; S.users = new Map(); S.members = []; S.online = new Set();
  S.group = {msgs: [], unread: 0, more: false}; S.dms = new Map(); S.chn = new Map(); S.chList = []; S.active = null; S.editing = null; S.query = ""; S.tab = "chats";
  S.replying = null; S.pendingImg = null; S.sending = false; S.sel = null; S.imgs = new Map();
  S.played.forEach(u => URL.revokeObjectURL(u)); S.played = new Map(); S.chat = {slowmode: 0, locked: false}; S.previews = new Map(); S.fx = new Map();
  cancelRecording(); voiceStop(); Pend.clear(); typingReset();
  ["replybar", "imgbar", "editbar"].forEach(id => $(id).classList.add("hidden"));
  $("search").value = ""; $("msgs").textContent = ""; $("inp").value = "";
  EM.data = null; EM.refresh = null; EM.tab = "std"; Rich.setEmojis([], true); $("emojiBtn").classList.add("hidden"); closeEmojiPanel();
}
function showAuth(msg) {
  $("f_user").value = ""; $("f_pass").value = "";
  S.wantClose = true;
  if (S.ws) try { S.ws.close(); } catch (_) {}
  SC.setToken(null); S.token = null; clearInterval(S.hb); S.hb = 0; clearTimeout(S.rt);
  try { localStorage.removeItem(LS_STAY); } catch (_) {} $("f_stay").checked = false;
  E2E.clearIdentity(); xReset(); blobUrls.forEach(p => p.then(u => URL.revokeObjectURL(u)).catch(() => {})); blobUrls.clear();
  closeModal(); closeCtx(); resetPages(); resetState(); Channels.reset(); Gaming.reset(); Checkers.reset();
  document.body.classList.remove("in-chat"); navReset();
  $("app").classList.add("hidden"); $("auth").classList.remove("hidden");
  $("autherr").textContent = msg || "";
  document.title = APP_NAME;
}

