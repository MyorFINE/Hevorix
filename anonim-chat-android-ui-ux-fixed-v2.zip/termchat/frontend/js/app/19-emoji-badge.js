/* ---------- emoji nishon: tanlash (o'zimga yoki foydalanuvchiga) ---------- */
const BADGE_EMOJIS = "👑 ✅ ⭐ 🌟 💎 🔥 ⚡ 🚀 🛡️ 🏆 🎖️ 💜 ❤️ 💙 💚 🧡 😎 🤩 😈 👻 🦄 🐉 🦁 🐺 🦅 🌈 🌙 ☀️ ❄️ 🍀 🎯 🎨 🎧 🎮 💫 ✨ 🔱 ⚜️ 🧿 🪐 🍒 🍉 👾 🤖 🥇 📢 🎉 🌹 🦋 🐱 🐼 🍕".split(" ");
const BADGE_ANIMS = [["", "Yo'q"], ["pulse", "Puls"], ["bounce", "Sakrash"], ["spin", "Aylanish"], ["shake", "Silkinish"], ["float", "Suzish"], ["glow", "Nur"], ["flip", "Aylanma"], ["wave", "Silkitish"], ["rainbow", "Kamalak"]];
/* ---- umumiy yordamchilar: gorizontal surish (g'ildirak, sichqoncha bilan tortish) va barmoq bilan chapga/o'ngga surish ---- */
function hScroll(el) {
  el.addEventListener("wheel", e => { if (Math.abs(e.deltaY) > Math.abs(e.deltaX) && el.scrollWidth > el.clientWidth) { el.scrollLeft += e.deltaY; e.preventDefault(); } }, {passive: false});
  let down = false, moved = false, x0 = 0, s0 = 0;
  el.addEventListener("pointerdown", e => { if (e.pointerType !== "mouse") return; down = true; moved = false; x0 = e.clientX; s0 = el.scrollLeft; });
  el.addEventListener("pointermove", e => { if (!down) return; const dx = e.clientX - x0; if (Math.abs(dx) > 4) moved = true; if (moved) el.scrollLeft = s0 - dx; });
  const up = () => { down = false; };
  el.addEventListener("pointerup", up); el.addEventListener("pointerleave", up); el.addEventListener("pointercancel", up);
  el.addEventListener("click", e => { if (moved) { e.stopPropagation(); e.preventDefault(); moved = false; } }, true);
}
function onSwipe(el, fn) {                                 // fn(+1): chapga surildi (keyingisi), fn(-1): o'ngga (oldingisi)
  let x0 = null, y0 = 0;
  el.addEventListener("touchstart", e => { const t = e.touches[0]; x0 = t.clientX; y0 = t.clientY; }, {passive: true});
  el.addEventListener("touchend", e => { if (x0 == null) return; const t = e.changedTouches[0], dx = t.clientX - x0, dy = Math.abs(t.clientY - y0); x0 = null; if (Math.abs(dx) > 50 && dy < 40) fn(dx < 0 ? 1 : -1); }, {passive: true});
}
function keepTabVisible(bar) {
  const on = bar.querySelector(".on"); if (!on || !bar.clientWidth) return;
  const l = on.offsetLeft, r = l + on.offsetWidth;
  if (l < bar.scrollLeft + 6) bar.scrollLeft = Math.max(0, l - 10);
  else if (r > bar.scrollLeft + bar.clientWidth - 6) bar.scrollLeft = r - bar.clientWidth + 10;
}

/* ---- nishon tanlagich: yuqorida jonli ko'rinish, har bir to'plamning 1-emojisi tab bo'lib turadi, tanlangan to'plam emojilari pastda ---- */
function badgeTabs() {
  const tabs = [{k: "std", label: "Emoji"}];
  if (EM.data) emojiTabs().filter(x => x.k !== "std").forEach(x => tabs.push(x));
  else { const l = Rich.emojiList(); if (l.length) tabs.push({k: "other", label: "Maxsus", items: l, icon: l[0]}); }
  return tabs;
}
function badgeEditor(t, onSaved, mid) {
  const base = () => t.id === S.me.id ? S.me : (U(t.id) || t);
  const cur = {badge: t.badge || "", anim: t.badge_anim || "", tab: "std"};
  const tabs = badgeTabs();
  const found = tabs.find(x => x.items && x.items.some(e => e.token === cur.badge)); if (found) cur.tab = found.k;
  const prev = h("div", {class: "bd-prev"}), bar = h("div", {class: "bd-tabs", role: "tablist"}), cap = h("div", {class: "ep-cap bd-cap"}),
    grid = h("div", {class: "bd-grid"}), anims = h("div", {class: "bd-anims"});
  const custom = h("input", {type: "text", class: "fld", maxlength: "16", placeholder: "Yoki o'z emojingizni yozing", autocomplete: "off", "aria-label": "O'z emojingiz"});
  hScroll(bar); hScroll(anims);
  const paintPrev = () => {
    const u = Object.assign({}, base(), {badge: cur.badge, badge_anim: cur.anim});
    prev.textContent = ""; prev.append(nameEl(u, {big: true}));
    if (!badge(u, true)) prev.append(h("small", {text: "  (nishon yo'q)"}));
  };
  const mark = () => {
    grid.querySelectorAll("button").forEach(x => x.classList.toggle("on", x.dataset.v === cur.badge));
    anims.querySelectorAll("button").forEach(x => x.classList.toggle("on", x.dataset.a === cur.anim));
    if (chk) chk.classList.toggle("on", cur.badge === "check");
  };
  const paint = () => { paintPrev(); mark(); };
  const pick = v => { cur.badge = v; custom.value = ""; paint(); };
  const paintGrid = dir => {
    grid.textContent = ""; grid.className = "bd-grid" + (dir ? " sl-" + dir : "");
    const c = tabs.find(x => x.k === cur.tab) || tabs[0];
    cap.textContent = c.k === "std" ? "Standart emojilar" : c.label + " • " + c.items.length + " ta";
    if (c.k === "std") BADGE_EMOJIS.forEach(e => { const b = h("button", {type: "button", text: e, "aria-label": e, onclick: () => pick(e)}); b.dataset.v = e; grid.append(b); });
    else if (!c.items.length) grid.append(h("div", {class: "ep-empty", text: "Bu to'plam hozircha bo'sh"}));
    else c.items.forEach(e => { const b = h("button", {type: "button", title: e.label || e.token, "aria-label": e.label || e.token, onclick: () => pick(e.token)}, Rich.chatEmoji(e.token, false)); b.dataset.v = e.token; grid.append(b); });
    mark();
  };
  const goTab = (k, dir) => {
    const i0 = tabs.findIndex(x => x.k === cur.tab), i1 = tabs.findIndex(x => x.k === k);
    cur.tab = k; bar.querySelectorAll("button").forEach(x => x.classList.toggle("on", x.dataset.k === k));
    keepTabVisible(bar); paintGrid(dir || (i1 > i0 ? "r" : "l"));
  };
  tabs.forEach(tb => {
    const b = h("button", {type: "button", role: "tab", class: tb.k === cur.tab ? "on" : "", title: tb.label, "aria-label": tb.label, onclick: () => goTab(tb.k)});
    if (tb.k === "std") b.textContent = "😀"; else if (tb.icon) b.append(Rich.chatEmoji(tb.icon.token, false)); else b.textContent = "📦";
    b.dataset.k = tb.k; bar.append(b);
  });
  onSwipe(grid, d => { const i = tabs.findIndex(x => x.k === cur.tab) + d; if (i >= 0 && i < tabs.length) goTab(tabs[i].k, d > 0 ? "r" : "l"); });
  BADGE_ANIMS.forEach(([k, n]) => { const b = h("button", {type: "button", text: n}); b.dataset.a = k; b.addEventListener("click", () => { cur.anim = k; paint(); }); anims.append(b); });
  custom.addEventListener("input", () => { const v = custom.value.trim(); if (v) { cur.badge = v; paint(); } });
  const chk = isStaff(t) ? null : h("button", {class: "bd-chip", type: "button", onclick: () => { cur.badge = "check"; cur.anim = ""; custom.value = ""; paint(); }}, "✔ Galochka");
  const clr = h("button", {class: "bd-chip", type: "button", onclick: () => { cur.badge = ""; cur.anim = ""; custom.value = ""; paint(); }}, isStaff(t) ? "Galochka (standart)" : "Olib tashlash");
  const hide = isStaff(t) ? h("button", {class: "bd-chip", type: "button", onclick: () => { cur.badge = "none"; cur.anim = ""; custom.value = ""; paint(); }}, "Yashirish") : null;
  const save = async () => {
    try {
      let u;
      if (t.id === S.me.id) u = (await api("/profile", {method: "PATCH", body: {badge: cur.badge, badge_anim: cur.anim}})).me;
      else u = (await api("/admin/badge", {method: "POST", body: {user_id: t.id, badge: cur.badge, anim: cur.anim}})).user;
      upsertUser(u); renderList(); renderHeader(); renderMessages(false);
      toast("Nishon saqlandi", "ok"); if (onSaved) onSaved(u);
      paintPrev();
    } catch (err) { toast(err.message, "error"); }
  };
  paintGrid(); paint();
  const root = h("div", {class: "bd"}, prev, mid || null, bar, cap, grid,
    h("div", {class: "bd-quick"}, chk, clr, hide),
    chk ? h("small", {class: "ep-cap", text: "Galochka foydalanuvchini admin qilmasdan beriladi."}) : null,
    h("div", {class: "bd-lab", text: "Animatsiya"}), anims, custom,
    h("div", {class: "bd-act"}, h("button", {class: "btn", type: "button", onclick: save}, "Saqlash")));
  root.repaint = paintPrev;
  requestAnimationFrame(() => keepTabVisible(bar));
  return root;
}
/* Mening akkauntim ichida: rang + nishon bitta ixcham bo'limda (yuqorida jonli ko'rinish) */
function lookSection() {
  let ed;
  const colors = colorSection(() => { if (ed) ed.repaint(); });
  ed = badgeEditor(S.me, null, colors);
  return h("div", {class: "setsec look"}, h("h4", {text: "Profil rangi va nishoni"}), ed);
}

