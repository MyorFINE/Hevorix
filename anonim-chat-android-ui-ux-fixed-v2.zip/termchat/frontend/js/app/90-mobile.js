const haptic = ms => { try { if (navigator.vibrate) navigator.vibrate(ms); } catch (_) {} };
document.addEventListener("touchstart", () => {}, {passive: true});

const NAV = {stack: [], ops: [], busy: false, timer: 0};
const NAV_CLOSE = {
  chat: () => closeChat(), modal: () => closeModal(), lb: () => closeLightbox(), avv: () => closeAvatarViewer(true),
  ctx: () => closeCtx(), sel: () => exitSelect(), dlg: () => { if (S.dlgCancel) S.dlgCancel(); },
  cm: () => Channels.closeComments(true),
  drawer: () => closeDrawerNow(),
  ...Object.fromEntries(Array.from({length: 8}, (_, i) => ["ms" + i, () => msClose()])),
  ...Object.fromEntries(Array.from({length: 12}, (_, i) => ["pg" + i, () => closePage()])),
};
function navKick() {
  while (!NAV.busy && NAV.ops.length) {
    const op = NAV.ops.shift();
    if (op.t === "push") { try { history.pushState({tc: op.d}, ""); } catch (_) {} }
    else {
      NAV.busy = true; clearTimeout(NAV.timer);
      NAV.timer = setTimeout(() => { NAV.busy = false; navKick(); }, 450);
      try { history.back(); } catch (_) { NAV.busy = false; }
    }
  }
}
function navPush(name) {
  if (NAV.stack.includes(name)) return;
  NAV.stack.push(name); NAV.ops.push({t: "push", d: NAV.stack.length}); navKick();
}
function navPop(name) {
  const i = NAV.stack.lastIndexOf(name); if (i < 0) return;
  const top = i === NAV.stack.length - 1;
  NAV.stack.splice(i, 1);
  if (top) { NAV.ops.push({t: "back"}); navKick(); }
}
function navReset() {
  const n = NAV.stack.length; NAV.stack.length = 0; NAV.ops.length = 0;
  if (n) try { history.go(-n); } catch (_) {}
}
addEventListener("popstate", e => {
  if (NAV.busy) { NAV.busy = false; clearTimeout(NAV.timer); navKick(); return; }
  const target = (e.state && e.state.tc) | 0;
  while (NAV.stack.length > target) { const fn = NAV_CLOSE[NAV.stack.pop()]; if (fn) fn(); }
});
try { if (history.state && history.state.tc) history.replaceState(null, ""); } catch (_) {}

const Composer = (() => {
  const vv = window.visualViewport;
  const root = document.documentElement;
  const touchy = () => COARSE || matchMedia("(max-width:760px)").matches || (navigator.maxTouchPoints || 0) > 0;
  const isField = el => !!el && (el.tagName === "TEXTAREA" || (el.tagName === "INPUT" && !/^(checkbox|radio|button|submit|reset|file|range|color|image)$/i.test(el.type)));
  const viewH = () => Math.round(vv ? vv.height : innerHeight);
  const viewTop = () => Math.round(vv ? vv.offsetTop : 0);
  let raf = 0;

  const sync = () => {
    raf = 0;
    if (!touchy() || (vv && vv.scale > 1.02)) {
      root.style.removeProperty("--vvh"); root.style.removeProperty("--vvt"); document.body.classList.remove("kb"); return;
    }
    const hgt = viewH();
    if (hgt >= 120) { root.style.setProperty("--vvh", hgt + "px"); root.style.setProperty("--vvt", viewTop() + "px"); }
    document.body.classList.toggle("kb", innerHeight - hgt > 120 && isField(document.activeElement));
    if (scrollY || document.scrollingElement && document.scrollingElement.scrollTop) scrollTo(0, 0);
    const b = $("msgs"); if (b && b._stick) b.scrollTop = b.scrollHeight;
  };
  const queue = () => { if (!raf) raf = requestAnimationFrame(sync); };

  const guard = () => {
    const chat = $("chat"), c = $("composer"), ta = $("inp");
    if (!chat || !c || !ta) return;
    sync();
    if (!S.active || !S.me) return;
    if (chat.classList.contains("hidden")) { chat.classList.remove("hidden"); $("empty").classList.add("hidden"); }
    if (S.active && isMobile() && !document.body.classList.contains("in-chat") && !PG.list.length) document.body.classList.add("in-chat");
    const gate = syncChatGate();
    if (!S.sel) chat.classList.remove("selecting");
    if (c.classList.contains("recording") && !S.rec && !S.recBusy && !S.starting) setRecUi("off");
    if (S.offline) { if (c.style.display) c.style.removeProperty("display"); return; }
    const gated = gate.chanRO || gate.dead || gate.locked || chat.classList.contains("selecting");
    if (gated) return;
    c.hidden = false; c.removeAttribute("aria-hidden");
    let r = c.getBoundingClientRect();
    const limit = viewTop() + viewH() + 2;
    if (!r.height || r.bottom > limit || r.top < 0) {
      root.style.setProperty("--vvh", viewH() + "px"); root.style.setProperty("--vvt", viewTop() + "px");
      [document.scrollingElement, document.body, $("main"), chat].forEach(e => { if (e && e.scrollTop) e.scrollTop = 0; });
      scrollTo(0, 0);
      void c.offsetHeight;
      r = c.getBoundingClientRect();
      if (!r.height) c.style.setProperty("display", "flex", "important");
    } else if (c.style.display) c.style.removeProperty("display");
    if (!c.classList.contains("recording") && ta.getBoundingClientRect().height < 20) { ta.style.height = ""; autosize(); }
  };

  if (vv) { vv.addEventListener("resize", queue); vv.addEventListener("scroll", queue); }
  addEventListener("resize", queue);
  addEventListener("orientationchange", () => { setTimeout(queue, 350); setTimeout(guard, 600); });
  addEventListener("pageshow", () => { queue(); setTimeout(guard, 50); setTimeout(guard, 500); });
  addEventListener("focus", () => setTimeout(guard, 80));
  addEventListener("online", () => setTimeout(guard, 80));
  document.addEventListener("visibilitychange", () => { if (!document.hidden) { queue(); setTimeout(guard, 60); setTimeout(guard, 500); setTimeout(guard, 1500); } });
  document.addEventListener("focusin", () => setTimeout(queue, 60));
  document.addEventListener("focusout", () => { setTimeout(queue, 120); setTimeout(queue, 500); setTimeout(guard, 700); });
  setInterval(() => { if (!document.hidden && S.active) guard(); }, 1500);
  queue();
  return {guard, sync};
})();

function longPress(el, fn) {
  let t = 0, sx = 0, sy = 0, quiet = 0;
  el.addEventListener("touchstart", e => {
    if (e.touches.length !== 1) return;
    sx = e.touches[0].clientX; sy = e.touches[0].clientY; clearTimeout(t);
    t = setTimeout(() => { quiet = Date.now() + 600; haptic(12); fn(sx, sy); }, 480);
  }, {passive: true});
  el.addEventListener("touchmove", e => { const p = e.touches[0]; if (Math.abs(p.clientX - sx) > 9 || Math.abs(p.clientY - sy) > 9) clearTimeout(t); }, {passive: true});
  ["touchend", "touchcancel"].forEach(ev => el.addEventListener(ev, () => clearTimeout(t), {passive: true}));
  el.addEventListener("click", e => { if (Date.now() < quiet) { e.preventDefault(); e.stopImmediatePropagation(); } }, true);
}

function canSwipeReply(m) {
  const c = $("chat");
  return !S.offline && !S.sel && !m.service && !m.locked && !m.bad && !m.legacy && !c.classList.contains("dead") && !c.classList.contains("locked");
}
function attachTouch(bubble, row, m) {
  const TH = 56;
  let tPress = 0, tCtx = 0, sx = 0, sy = 0, dx = 0, mode = "", ind = null, hit = false, quiet = 0;
  const stopTimers = () => { clearTimeout(tPress); clearTimeout(tCtx); tPress = tCtx = 0; row.classList.remove("pressing"); };
  bubble.addEventListener("click", e => { if (Date.now() < quiet) { e.preventDefault(); e.stopPropagation(); } }, true);
  bubble.addEventListener("touchstart", e => {
    stopTimers(); dx = 0; hit = false;
    if (S.sel || e.touches.length !== 1) { mode = "x"; return; }
    mode = "";
    const t = e.touches[0]; sx = t.clientX; sy = t.clientY;
    tPress = setTimeout(() => row.classList.add("pressing"), 140);
    tCtx = setTimeout(() => { tCtx = 0; mode = "ctx"; row.classList.remove("pressing"); haptic(12); openCtx(sx, sy, m); }, 450);
  }, {passive: true});
  bubble.addEventListener("touchmove", e => {
    if (mode !== "" && mode !== "swipe") return;
    const t = e.touches[0], mx = t.clientX - sx, my = t.clientY - sy;
    if (mode === "") {
      if (Math.abs(mx) < 9 && Math.abs(my) < 9) return;
      stopTimers();
      const skip = e.target.closest && e.target.closest(".vtrack,.vspd,.mplayer,.code-scroll,.term-scroll,.cbtn");
      if (Math.abs(mx) < Math.abs(my) * 1.5 || mx > 0 || skip || !canSwipeReply(m)) { mode = "scroll"; return; }
      mode = "swipe"; bubble.style.transition = "none";
      ind = h("span", {class: "swipe-ind", "aria-hidden": "true"}, icon("reply")); row.append(ind);
    }
    const raw = mx < 0 ? -mx : 0;
    dx = -(raw <= TH ? raw : TH + (raw - TH) * 0.2);
    const k = Math.min(1, raw / TH);
    bubble.style.transform = "translateX(" + dx + "px)";
    ind.style.opacity = String(k); ind.style.transform = "scale(" + (0.6 + 0.4 * k) + ")";
    const nowHit = raw >= TH;
    if (nowHit !== hit) { hit = nowHit; row.classList.toggle("swipe-hit", hit); if (hit) haptic(8); }
  }, {passive: true});
  const end = cancelled => {
    stopTimers();
    if (mode === "ctx") quiet = Date.now() + 600;
    if (mode === "swipe") {
      const fire = !cancelled && hit;
      bubble.style.transition = ""; bubble.style.transform = "";
      if (ind) { const el = ind; el.style.opacity = "0"; setTimeout(() => el.remove(), 220); ind = null; }
      row.classList.remove("swipe-hit");
      quiet = Date.now() + 400;
      if (fire) startReply(m);
    }
    mode = ""; hit = false;
  };
  bubble.addEventListener("touchend", () => end(false), {passive: true});
  bubble.addEventListener("touchcancel", () => end(true), {passive: true});
}

(() => {
  const sheet = $("sheet");
  let y0 = 0, dy = 0, drag = false;
  sheet.addEventListener("touchstart", e => {
    drag = false;
    if (!isMobile() || e.touches.length !== 1 || !e.target.closest(".sh-head, .pbanner")) return;
    y0 = e.touches[0].clientY; dy = 0; drag = true;
  }, {passive: true});
  sheet.addEventListener("touchmove", e => {
    if (!drag) return;
    dy = Math.max(0, e.touches[0].clientY - y0);
    if (dy > 6) { sheet.style.transition = "none"; sheet.style.transform = "translateY(" + dy + "px)"; }
  }, {passive: true});
  const end = () => {
    if (!drag) return; drag = false;
    const close = dy > 110; dy = 0;
    sheet.style.transition = "transform .2s ease";
    sheet.style.transform = close ? "translateY(100%)" : "";
    setTimeout(() => { if (close) closeModal(); sheet.style.transition = ""; sheet.style.transform = ""; }, 200);
  };
  sheet.addEventListener("touchend", end, {passive: true});
  sheet.addEventListener("touchcancel", end, {passive: true});
})();

