/* ---------------- bildirishnomalar (Web Push) ----------------
   Brauzer BUTUNLAY yopiq bo'lsa ham: umumiy chatga yozishsa — umumiy chat haqida, lichkaga yozishsa — lichka haqida bildirishnoma keladi.
   Onlayn bo'lsangiz xabarlar WebSocket orqali oddiy real vaqtda keladi (push yuborilmaydi). */
const notifLabel = () => {
  const st = Push.state();
  if (!st.ok) return st.why === "ios-install" ? "Bildirishnoma (ilovani o'rnating)" : "Bildirishnoma (qo'llab-quvvatlanmaydi)";
  if (st.permission === "denied") return "Bildirishnoma (bloklangan)";
  return st.on ? "Bildirishnomani o'chirish" : "Bildirishnomani yoqish";
};
async function toggleNotifications() {
  const st = Push.state();
  try {
    if (st.on) { await Push.disable(api); toast("Bu qurilmada bildirishnomalar o'chirildi", "info"); }
    else { await Push.enable(api); toast("Bildirishnomalar yoqildi: brauzer yopiq bo'lsa ham xabar keladi", "ok"); }
  } catch (err) { toast(err.message, "error"); }
}
async function askNotifications() {
  if (!S.token || !Push.shouldAsk()) return;
  Push.markAsked();
  const ok = await confirmDlg("Brauzer yopiq bo'lsa ham umumiy chatga yoki lichkangizga yozishsa, darhol xabar olasiz. Xabar matni bildirishnomada ko'rsatilmaydi.",
    {title: "Bildirishnomalarni yoqamizmi?", okText: "Yoqish"});
  if (!ok || !S.token) return;
  try { await Push.enable(api); toast("Bildirishnomalar yoqildi", "ok"); } catch (err) { toast(err.message, "error"); }
}
function applyPendingChannel() { const p = S.pendingOpen; if (p && p.k === "c") { S.pendingOpen = null; Channels.openById(p.u); } }
function openFromNotification(k, u) {                  // bildirishnoma bosildi: tegishli chatni ochamiz
  if (!S.token || !S.me) { S.pendingOpen = {k, u}; return; }
  if (k === "c") { Channels.openById(u); return; }
  if (k === "d" && u && u !== S.me.id) { if (S.users.has(u)) openChat({kind: "dm", uid: u}); else { S.pendingOpen = {k, u}; loadMembers().then(applyPendingOpen); } }
  else openChat({kind: "group"});
}
function applyPendingOpen() {
  const p = S.pendingOpen; if (!p) return;
  if (p.k === "d" && !S.users.has(p.u)) return;
  S.pendingOpen = null; openFromNotification(p.k, p.u);
}
window.addEventListener("ac-open-chat", e => openFromNotification(e.detail.k, e.detail.u));
try {                                                  // brauzer yopiq edi, bildirishnoma bosib ochildi: /?o=g yoki /?o=d12
  const o = new URLSearchParams(location.search).get("o");
  if (o) {
    if (o === "g") S.pendingOpen = {k: "g"};
    else if (/^d\d{1,9}$/.test(o)) S.pendingOpen = {k: "d", u: parseInt(o.slice(1), 10)};
    else if (/^c\d{1,9}$/.test(o)) S.pendingOpen = {k: "c", u: parseInt(o.slice(1), 10)};
    history.replaceState(null, "", "/");
  }
} catch (_) {}
async function logout() {
  try { await Promise.race([Push.onLogout(api), delay(3000)]); } catch (_) {}       // bu qurilmadagi bildirishnoma obunasi olib tashlanadi
  try { await SC.fetch("/api/logout", {method: "POST", headers: {Authorization: "Bearer " + S.token}}); } catch (_) {}
  await Off.wipe();                                                    // aniq "Chiqish": qurilmadagi oflayn xotira ham o'chadi
  showAuth("");
}

/* ---------------- mavzu ---------------- */
/* ---------------- xabar ovozi ("ting") ----------------
   Ilova ochiq bo'lganda (yoki orqa fonda tirik tursa) boshqa suhbatga/yashirin oynaga xabar kelsa qisqa ovoz chiqadi.
   Ilova yopiq bo'lsa ovozni telefonning o'zi (bildirishnoma ovozi) chaladi — veb-push maxsus ovoz faylini qo'llamaydi. */
const LS_SND = "ac_sound";
const LS_MUTED = "ac_muted_dm";                  // ovozi o'chirilgan shaxsiy suhbatlar (faqat shu qurilmada)
const mutedDm = (() => { try { return new Set(JSON.parse(localStorage.getItem(LS_MUTED) || "[]").filter(Number.isInteger)); } catch (_) { return new Set(); } })();
const isMuted = uid => mutedDm.has(uid);
function toggleMute(uid) {
  if (!mutedDm.delete(uid)) mutedDm.add(uid);
  try { localStorage.setItem(LS_MUTED, JSON.stringify([...mutedDm])); } catch (_) {}
  return mutedDm.has(uid);
}
const sndOn = () => { try { return localStorage.getItem(LS_SND) !== "off"; } catch (_) { return true; } };
let actx = null, lastTing = 0;
const audioCtx = () => { if (!actx) { const C = window.AudioContext || window.webkitAudioContext; if (C) { try { actx = new C(); } catch (_) {} } } return actx; };
["pointerdown", "keydown", "touchstart"].forEach(ev => addEventListener(ev, () => { const c = audioCtx(); if (c && c.state === "suspended") c.resume().catch(() => {}); }, {passive: true, capture: true}));
function ting(force) {
  if (!force && !sndOn()) return;
  const c = audioCtx(); if (!c || c.state !== "running") return;
  const t = c.currentTime;
  [[988, 0], [1480, 0.11]].forEach(([f, d]) => {
    const o = c.createOscillator(), g = c.createGain();
    o.type = "sine"; o.frequency.value = f;
    g.gain.setValueAtTime(0.0001, t + d); g.gain.exponentialRampToValueAtTime(0.28, t + d + 0.012); g.gain.exponentialRampToValueAtTime(0.0001, t + d + 0.42);
    o.connect(g); g.connect(c.destination); o.start(t + d); o.stop(t + d + 0.45);
  });
}
function pingSound(viewing) {                       // viewing: xabar kelgan suhbat hozir ochiq va ko'rinib turibdimi
  if (viewing && !document.hidden) return;
  const n = Date.now(); if (n - lastTing < 700) return; lastTing = n;
  ting();
}
function toggleSound() {
  const on = !sndOn();
  try { localStorage.setItem(LS_SND, on ? "on" : "off"); } catch (_) {}
  if (on) ting(true);
  toast(on ? "Xabar ovozi yoqildi" : "Xabar ovozi o'chirildi", "ok");
}
document.addEventListener("visibilitychange", () => { if (!document.hidden) { try { if (navigator.clearAppBadge) navigator.clearAppBadge(); } catch (_) {} } });

function toggleTheme() {
  const t = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
  document.documentElement.dataset.theme = t;
  const mc = document.querySelector('meta[name="theme-color"]'); if (mc) mc.setAttribute("content", t === "dark" ? "#17212b" : "#ffffff");
  try { localStorage.setItem(LS_THEME, t); } catch (_) {}
}

