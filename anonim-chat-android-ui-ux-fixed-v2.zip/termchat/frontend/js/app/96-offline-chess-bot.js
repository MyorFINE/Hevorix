const OffChess = (() => {
  const GLYPH = {k: "♚", q: "♛", r: "♜", b: "♝", n: "♞", p: "♟\uFE0E"};
  const VAL = {p: 1, n: 3, b: 3, r: 5, q: 9, k: 0};
  const START = "RNBQKBNRPPPPPPPP" + ".".repeat(32) + "pppppppprnbqkbnr";
  const LS_GAME = "tc_offchess", LS_CFG = "tc_offchess_cfg", LS_STAT = "tc_offchess_stat";
  const REASON = {
    checkmate: "Mat", stalemate: "Pat — yurish qolmadi", insufficient: "Material yetarli emas", fifty: "50 yurish qoidasi",
    repetition: "Bir xil holat uch marta takrorlandi", resign: "Taslim bo'lindi",
  };
  const LV_INFO = {1: "Xato qiladi — o'rganish uchun", 2: "Ba'zan xato qiladi", 3: "Oddiy o'yinchidek", 4: "Taktikani yaxshi ko'radi", 5: "Eng kuchli • o'ylash uzoqroq"};
  const sqName = i => "abcdefgh"[i & 7] + ((i >> 3) + 1);
  const sqIdx = s => (s.charCodeAt(1) - 49) * 8 + s.charCodeAt(0) - 97;
  const lsGet = (k, d) => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (_) { return d; } };
  const lsSet = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (_) {} };
  const lsDel = k => { try { localStorage.removeItem(k); } catch (_) {} };
  const snd = () => { try { return Gaming.snd; } catch (_) { return null; } };
  const sound = (name, ...a) => { try { const s = snd(); if (s && s[name]) s[name](...a); } catch (_) {} };

  const O = {el: null, main: null, g: null, bd: START.split(""), dom: new Array(64).fill(null), sqs: [], layer: null, boardEl: null, sheet: null,
    worker: null, wOk: true, req: 0, pending: new Map(), top: null, bot: null, hs: null, hList: null, hPrev: null, hNext: null, hLive: null, undoBtn: null, hintBtn: null,
    sel: null, drag: null, askingPromo: false, hintTimer: 0, botTimer: 0};

  function engineOk() { return !!window.TCChess; }
  function ensureWorker() {
    if (O.worker || !O.wOk) return O.worker;
    try {
      const w = new Worker("/static/js/chessbot.js");
      w.onmessage = e => { const d = e.data || {}, p = O.pending.get(d.id); if (p) { O.pending.delete(d.id); clearTimeout(p.t); p.res(d); } };
      w.onerror = () => { O.wOk = false; try { w.terminate(); } catch (_) {} O.worker = null; flushPending(); };
      O.worker = w;
    } catch (_) { O.wOk = false; O.worker = null; }
    return O.worker;
  }
  function flushPending() {
    const list = [...O.pending.values()]; O.pending.clear();
    list.forEach(p => { clearTimeout(p.t); runMain(p.q).then(p.res); });
  }
  function runMain(q) {
    return new Promise(res => setTimeout(() => {
      try { const r = window.TCChess.chooseMove(q.fen, q.moves, q.level, {hint: q.hint}); res({ok: true, uci: r && r.uci}); }
      catch (err) { res({ok: false, error: String(err && err.message || err)}); }
    }, 30));
  }
  function askBot(moves, level, hint) {
    const q = {fen: window.TCChess.START_FEN, moves: moves.slice(), level, hint: !!hint};
    const w = ensureWorker();
    if (!w) return runMain(q);
    return new Promise(res => {
      const id = ++O.req, t = setTimeout(() => {
        if (!O.pending.has(id)) return; O.pending.delete(id); runMain(q).then(res);
      }, 15000);
      O.pending.set(id, {res, t, q});
      try { w.postMessage(Object.assign({id}, q)); } catch (_) { O.pending.delete(id); clearTimeout(t); runMain(q).then(res); }
    });
  }

  const cfg = () => Object.assign({level: 3, side: "r"}, lsGet(LS_CFG, {}));
  const stat = () => Object.assign({w: 0, l: 0, d: 0}, lsGet(LS_STAT, {}));
  function newGame(level, side, moves) {
    const T = window.TCChess, pos = new T.Pos();
    const g = {level, side, pos, moves: [], mv: [], boards: [START], over: null, thinking: false, view: null, last: null, hint: null, token: 0, counted: false};
    for (const u of (moves || [])) { if (!playUci(g, u)) return null; }
    return g;
  }
  function playUci(g, u) {
    const pos = g.pos, list = pos.legal(), m = pos.findUci(u, list); if (!m) return false;
    const f = m & 63, t = (m >> 6) & 63, fl = m >> 16, pr = (m >> 12) & 15, ch = pos.b[f];
    const cap = fl & 2 ? pos.b[t - 8 * pos.turn] : pos.b[t];
    pos.make(m);
    const sym = v => v ? (v > 0 ? "PNBRQK"[v - 1] : "pnbrqk"[-v - 1]) : "";
    const chk = pos.inCheck();
    g.moves.push(u); g.mv.push({ch: sym(ch), f, t, cap: sym(cap), promo: pr ? "pnbrqk"[pr - 1] : "", check: chk});
    g.boards.push(pos.boardString());
    g.last = [f, t];
    const st = pos.status(); if (st.over) g.over = {result: st.result, reason: st.reason};
    return true;
  }
  const myTurn = g => g && !g.over && (g.pos.turn === 1 ? "w" : "b") === g.side;
  const saveGame = () => {
    const g = O.g; if (!g) return;
    lsSet(LS_GAME, {v: 1, side: g.side, level: g.level, moves: g.moves, over: !!g.over, ts: Date.now()});
  };
  function loadSaved() {
    const s = lsGet(LS_GAME, null);
    if (!s || s.v !== 1 || !Array.isArray(s.moves) || s.moves.length > 800 || s.over || !s.moves.length || (s.side !== "w" && s.side !== "b") || !(s.level >= 1 && s.level <= 5)) return null;
    return s;
  }

  const xy = i => { const f = i & 7, r = i >> 3; return O.g && O.g.side === "b" ? [7 - f, r] : [f, 7 - r]; };
  function place(el, i) { const [x, y] = xy(i); el.dataset.x = x; el.dataset.y = y; el.style.transform = "translate(" + x * 100 + "%," + y * 100 + "%)"; }
  function mkPiece(ch, i) {
    const t = ch.toLowerCase(), el = h("div", {class: "gp " + (ch === t ? "pb" : "pw")}, h("span", {text: GLYPH[t]}));
    place(el, i); return el;
  }
  function rebuildPieces() {
    if (!O.layer) return;
    O.layer.textContent = ""; O.dom.fill(null);
    for (let i = 0; i < 64; i++) if (O.bd[i] !== ".") { const el = mkPiece(O.bd[i], i); O.layer.append(el); O.dom[i] = el; }
  }
  function boardBlock() {
    const b = h("div", {class: "gm-board oc-board"}), grid = h("div", {class: "gm-sqs"}), side = O.g.side;
    O.sqs = new Array(64);
    for (let y = 0; y < 8; y++) for (let x = 0; x < 8; x++) {
      const i = side === "b" ? y * 8 + (7 - x) : (7 - y) * 8 + x, dark = ((i & 7) + (i >> 3)) % 2 === 0;
      const s = h("div", {class: "sq " + (dark ? "dk" : "lt")});
      if (x === 0) s.append(h("i", {class: "rk", text: String((i >> 3) + 1)}));
      if (y === 7) s.append(h("i", {class: "fl", text: "abcdefgh"[i & 7]}));
      O.sqs[i] = s; grid.append(s);
    }
    O.layer = h("div", {class: "gm-pcs"}); b.append(grid, O.layer); O.boardEl = b; rebuildPieces();
    b.addEventListener("pointerdown", onDown); b.addEventListener("pointermove", onMove);
    b.addEventListener("pointerup", onUp); b.addEventListener("pointercancel", onUp);
    return b;
  }
  function applyMove(f, t, promo) {
    const el = O.dom[f]; if (!el) { O.bd = O.g.boards[O.g.boards.length - 1].split(""); rebuildPieces(); return false; }
    const ch = O.bd[f], pt = ch.toLowerCase();
    let capEl = O.dom[t], capped = O.bd[t] !== ".";
    if (pt === "p" && (f & 7) !== (t & 7) && O.bd[t] === ".") { const c = ch === "P" ? t - 8 : t + 8; capEl = O.dom[c]; capped = true; O.dom[c] = null; O.bd[c] = "."; }
    if (capEl) { capEl.classList.add("cap"); setTimeout(() => capEl.remove(), 280); }
    O.dom[t] = el; O.dom[f] = null; O.bd[t] = ch; O.bd[f] = ".";
    el.classList.add("mv"); setTimeout(() => el.classList.remove("mv"), 300); place(el, t);
    if (pt === "p" && ((t >> 3) === 0 || (t >> 3) === 7)) { const np = promo || "q"; O.bd[t] = ch === "P" ? np.toUpperCase() : np; el.firstChild.textContent = GLYPH[np]; el.classList.add("promo"); }
    if (pt === "k" && Math.abs(t - f) === 2) {
      const rf = t > f ? f + 3 : f - 4, rt = t > f ? f + 1 : f - 1, rel = O.dom[rf];
      if (rel) { O.dom[rt] = rel; O.dom[rf] = null; O.bd[rt] = O.bd[rf]; O.bd[rf] = "."; rel.classList.add("mv"); setTimeout(() => rel.classList.remove("mv"), 300); place(rel, rt); }
    }
    return capped;
  }
  function targetsOf(i) {
    const g = O.g; if (!g || !myTurn(g)) return [];
    const pos = g.pos, out = [];
    for (const m of pos.legal()) if ((m & 63) === i) out.push((m >> 6) & 63);
    return out;
  }
  function paintMarks() {
    if (!O.sqs.length || !O.sqs[0] || !O.g) return;
    const g = O.g, rv = g.view != null, mvv = rv && g.view > 0 ? g.mv[g.view - 1] : null;
    const last = rv ? (mvv ? [mvv.f, mvv.t] : []) : (g.last || []);
    let chk = -1;
    if (!rv && (!g.over || g.over.reason === "checkmate") && g.pos.inCheck()) chk = g.pos.kp[g.pos.turn === 1 ? 0 : 1];
    const tg = !rv && O.sel != null ? targetsOf(O.sel) : [], hint = !rv && g.hint ? g.hint : [];
    for (let i = 0; i < 64; i++) {
      const c = O.sqs[i].classList, t = tg.includes(i);
      c.toggle("last", last.includes(i)); c.toggle("chk", i === chk); c.toggle("sel", i === O.sel);
      c.toggle("tg", t && O.bd[i] === "."); c.toggle("tgc", t && O.bd[i] !== "."); c.toggle("hint", hint.includes(i));
    }
  }
  function sqAt(e) {
    const r = O.boardEl.getBoundingClientRect();
    const x = Math.floor((e.clientX - r.left) / r.width * 8), y = Math.floor((e.clientY - r.top) / r.height * 8);
    if (x < 0 || x > 7 || y < 0 || y > 7) return -1;
    return O.g.side === "b" ? y * 8 + (7 - x) : (7 - y) * 8 + x;
  }
  function onDown(e) {
    const g = O.g;
    if (!g || g.over || g.thinking || O.askingPromo || g.view != null || e.button > 0 || !myTurn(g)) return;
    const i = sqAt(e); if (i < 0) return;
    if (O.sel != null && targetsOf(O.sel).includes(i)) { doMove(O.sel, i); e.preventDefault(); return; }
    const ch = O.bd[i], own = ch !== "." && (ch === ch.toUpperCase()) === (g.side === "w");
    if (own && O.dom[i] && targetsOf(i).length) {
      O.sel = i; O.drag = {i, el: O.dom[i], x: e.clientX, y: e.clientY, moved: false, id: e.pointerId};
      try { O.boardEl.setPointerCapture(e.pointerId); } catch (_) {}
    } else O.sel = null;
    paintMarks(); e.preventDefault();
  }
  function onMove(e) {
    const d = O.drag; if (!d || e.pointerId !== d.id) return;
    const dx = e.clientX - d.x, dy = e.clientY - d.y;
    if (!d.moved && Math.hypot(dx, dy) > 7) { d.moved = true; d.el.classList.add("drag"); }
    if (d.moved) d.el.style.transform = "translate(calc(" + d.el.dataset.x * 100 + "% + " + dx + "px), calc(" + d.el.dataset.y * 100 + "% + " + dy + "px)) scale(1.18)";
  }
  function onUp(e) {
    const d = O.drag; if (!d || e.pointerId !== d.id) return;
    O.drag = null; d.el.classList.remove("drag");
    if (!d.moved) return;
    const to = sqAt(e);
    if (to >= 0 && targetsOf(d.i).includes(to)) doMove(d.i, to); else place(d.el, d.i);
  }
  function askPromo(white) {
    return new Promise(res => {
      O.askingPromo = true;
      const done = v => { O.askingPromo = false; ov.remove(); res(v); };
      const ov = h("div", {class: "gm-promo", onclick: e => { if (e.target === ov) done(null); }},
        h("div", {class: "gm-pbox"}, ["q", "r", "b", "n"].map(p => h("button", {type: "button", class: "gm-pp " + (white ? "pw" : "pb"), "aria-label": p, onclick: () => done(p)}, GLYPH[p]))));
      O.boardEl.append(ov);
    });
  }
  async function doMove(f, t) {
    const ch = O.bd[f];
    if (ch.toLowerCase() === "p" && ((t >> 3) === 7 || (t >> 3) === 0)) {
      const p = await askPromo(ch === "P");
      if (!p) { if (O.dom[f]) place(O.dom[f], f); return; }
      return commit(f, t, p);
    }
    commit(f, t, "");
  }

  function afterMove(mine) {
    const g = O.g, l = g.mv[g.mv.length - 1];
    const castle = l.ch.toLowerCase() === "k" && Math.abs(l.t - l.f) === 2;
    sound("move", mine, !!l.cap, {castle, promo: l.promo});
    if (!mine) haptic(12);
    if (g.pos.inCheck() && !g.over) sound("check");
    saveGame(); paintMarks(); paintPlayers(); paintHist(); syncButtons();
    if (g.over) return finish();
  }
  function commit(f, t, promo) {
    const g = O.g; if (!g || !myTurn(g)) return;
    const uci = sqName(f) + sqName(t) + (promo || "");
    O.sel = null; g.hint = null; clearTimeout(O.hintTimer);
    if (!playUci(g, uci)) { place(O.dom[f], f); paintMarks(); toast("Bu yurish mumkin emas", "warn"); return; }
    applyMove(f, t, promo);
    afterMove(true);
    if (!g.over) botTurn();
  }
  async function botTurn() {
    const g = O.g; if (!g || g.over || myTurn(g)) return;
    const token = ++g.token; g.thinking = true; paintPlayers(); syncButtons();
    const t0 = performance.now();
    let res;
    try { res = await askBot(g.moves, g.level, false); } catch (err) { res = {ok: false, error: String(err && err.message || err)}; }
    const wait = Math.max(0, (g.level <= 2 ? 450 : 250) - (performance.now() - t0));
    if (wait) await new Promise(r => O.botTimer = setTimeout(r, wait));
    if (O.g !== g || g.token !== token || g.over) return;
    g.thinking = false;
    let uci = res && res.ok && res.uci;
    if (!uci) {
      const l = g.pos.legal(); if (!l.length) { paintPlayers(); return; }
      uci = g.pos.toUci(l[Math.floor(Math.random() * l.length)]);
    }
    const f = sqIdx(uci.slice(0, 2)), t = sqIdx(uci.slice(2, 4)), promo = uci[4] || "";
    if (!playUci(g, uci)) { toast("Bot noto'g'ri yurish qildi — qayta urinilmoqda", "warn"); return botTurn(); }
    if (g.view == null) applyMove(f, t, promo); else {  }
    afterMove(false);
  }
  function finish() {
    const g = O.g, o = g.over; if (!o || g.counted) return; g.counted = true;
    const me = g.side, res = o.result === "d" ? "d" : o.result === me ? "w" : "l";
    const s = stat(); s[res === "w" ? "w" : res === "l" ? "l" : "d"]++; lsSet(LS_STAT, s);
    lsDel(LS_GAME); paintPlayers(); syncButtons();
    const why = o.reason === "resign" ? (res === "w" ? "Bot taslim bo'ldi" : "Siz taslim bo'ldingiz") : REASON[o.reason] || "";
    const card = h("div", {class: "gm-over", onclick: e => { if (e.target === card) card.remove(); }}, h("div", {class: "go-card"},
      h("div", {class: "go-t", text: res === "w" ? "🏆 Siz yutdingiz!" : res === "l" ? "Yutqazdingiz" : "🤝 Durang"}),
      h("div", {class: "go-r", text: why}),
      h("div", {class: "go-nr", text: "Oflayn o'yin — natija faqat shu qurilmada hisoblanadi."}),
      h("div", {class: "go-b"},
        h("button", {class: "btn", type: "button", text: "🔁 Qayta o'ynash", onclick: () => { card.remove(); startNew(g.level, g.side === "w" ? "b" : "w", true); }}),
        h("button", {class: "btn ghost", type: "button", text: "Menyu", onclick: () => { card.remove(); O.g = null; render(); }}))));
    O.el.append(card); O.overCard = card;
    haptic(res === "w" ? [60, 40, 120] : 40);
    setTimeout(() => sound(res === "w" ? "win" : res === "l" ? "lose" : "draw"), 350);
  }
  async function resign() {
    const g = O.g; if (!g || g.over) return;
    if (!await confirmDlg("Taslim bo'lsangiz o'yin tugaydi. Taslim bo'lasizmi?", {title: "Taslim bo'lish", okText: "Taslim bo'lish", danger: true})) return;
    if (O.g !== g || g.over) return;
    g.token++; g.thinking = false; g.over = {result: g.side === "w" ? "b" : "w", reason: "resign"}; finish();
  }
  function undo() {
    const g = O.g; if (!g || !canUndo(g)) return;
    const was = g.over; g.token++; g.thinking = false; clearTimeout(O.botTimer);
    let n = g.moves.length;
    do { n--; } while (n > 0 && ((n % 2 === 0 ? "w" : "b") !== g.side));
    const keep = g.moves.slice(0, n), ng = newGame(g.level, g.side, keep); if (!ng) return;
    ng.counted = false; O.g = ng; if (O.overCard) { O.overCard.remove(); O.overCard = null; }
    if (was) { const s = stat(); const r = was.result === "d" ? "d" : was.result === g.side ? "w" : "l"; if (g.counted) { s[r] = Math.max(0, s[r] - 1); lsSet(LS_STAT, s); } }
    O.bd = ng.boards[ng.boards.length - 1].split(""); rebuildPieces();
    O.sel = null; saveGame(); paintMarks(); paintPlayers(); paintHist(); syncButtons();
    if (!myTurn(ng) && !ng.over) botTurn();
  }
  const canUndo = g => !!g && g.moves.length > (g.side === "w" ? 0 : 1) && !(g.over && g.over.reason === "resign");
  async function hint() {
    const g = O.g; if (!g || g.over || g.thinking || !myTurn(g) || O.hinting) return;
    O.hinting = true; syncButtons(); toast("Maslahat o'ylanmoqda…", "info");
    let r = null; try { r = await askBot(g.moves, 4, true); } catch (_) {}
    O.hinting = false;
    if (O.g !== g || g.over || !myTurn(g)) { syncButtons(); return; }
    if (r && r.ok && r.uci) {
      g.hint = [sqIdx(r.uci.slice(0, 2)), sqIdx(r.uci.slice(2, 4))]; clearTimeout(O.hintTimer);
      O.hintTimer = setTimeout(() => { if (O.g === g) { g.hint = null; paintMarks(); } }, 4000);
      paintMarks(); toast("Maslahat: " + r.uci.slice(0, 2) + "–" + r.uci.slice(2, 4), "ok");
    } else toast("Maslahat topilmadi", "warn");
    syncButtons();
  }

  function setView(k) {
    const g = O.g; if (!g) return;
    const n = g.moves.length; g.view = k == null || k >= n ? null : Math.max(0, k);
    O.sel = null; O.drag = null;
    O.bd = (g.view == null ? g.boards[n] : g.boards[g.view]).split(""); rebuildPieces();
    if (O.boardEl) O.boardEl.classList.toggle("rev", g.view != null);
    paintMarks(); paintHist();
  }
  function buildHist() {
    const mkb = (txt, label, fn) => { const b = h("button", {class: "gm-hb", type: "button", "aria-label": label, text: txt}); b.addEventListener("click", fn); return b; };
    O.hPrev = mkb("◀", "Oldingi yurish", () => { const g = O.g; if (g) setView((g.view == null ? g.moves.length : g.view) - 1); });
    O.hNext = mkb("▶", "Keyingi yurish", () => { const g = O.g; if (g && g.view != null) setView(g.view + 1); });
    O.hLive = mkb("⏭", "Hozirgi holat", () => setView(null));
    O.hList = h("div", {class: "gm-hl"});
    O.hs = h("div", {class: "gm-hist"}, O.hPrev, O.hList, O.hNext, O.hLive);
    paintHist(); return O.hs;
  }
  function paintHist() {
    const g = O.g; if (!O.hs || !O.hList || !g) return;
    const n = g.moves.length, cur = g.view == null ? n : g.view;
    O.hList.textContent = "";
    if (!n) O.hList.append(h("span", {class: "gm-hn", text: "Yurishlar tarixi bu yerda ko'rinadi"}));
    let act = null;
    g.mv.forEach((m, i) => {
      if (i % 2 === 0) O.hList.append(h("span", {class: "gm-hn", text: (i / 2 + 1) + "."}));
      const white = m.ch === m.ch.toUpperCase(), pt = m.ch.toLowerCase();
      const b = h("button", {type: "button", class: "gm-hm " + (white ? "w" : "k") + (i + 1 === cur ? " on" : ""), title: (i + 1) + "-yurish"},
        h("i", {text: GLYPH[pt]}), h("span", {text: sqName(m.f) + (m.cap ? "×" : "–") + sqName(m.t) + (m.promo ? "=" + GLYPH[m.promo] : "") + (m.check ? "+" : "")}));
      b.addEventListener("click", () => setView(i + 1));
      if (i + 1 === cur) act = b;
      O.hList.append(b);
    });
    O.hPrev.disabled = cur <= 0; O.hNext.disabled = g.view == null; O.hLive.disabled = g.view == null;
    O.hs.classList.toggle("rev", g.view != null);
    if (act) O.hList.scrollLeft = act.offsetLeft - O.hList.clientWidth / 2 + act.offsetWidth / 2; else O.hList.scrollLeft = 0;
  }

  function playerRow(side) {
    const bot = side !== O.g.side, cap = h("span", {class: "gm-cap"}), pts = h("span", {class: "gm-pp2"});
    let av;
    if (bot) av = h("div", {class: "gm-botav", text: "🤖"});
    else { try { av = S.me ? avatar(S.me, "m", true) : h("div", {class: "gm-botav", text: "👤"}); } catch (_) { av = h("div", {class: "gm-botav", text: "👤"}); } }
    let name;
    if (bot) name = h("span", {text: "Bot • " + window.TCChess.LEVELS[O.g.level].name});
    else { try { name = S.me ? nameEl(S.me) : h("span", {text: "Siz"}); } catch (_) { name = h("span", {text: "Siz"}); } }
    const el = h("div", {class: "gm-pl"}, av, h("div", {class: "gm-pi"}, h("div", {class: "gm-pn"}, name), cap, pts));
    return {el, side, cap, pts};
  }
  function paintPlayers() {
    const g = O.g; if (!g || !O.top) return;
    const caps = {w: [], b: []};
    g.mv.forEach(m => { if (m.cap) (m.ch === m.ch.toUpperCase() ? caps.w : caps.b).push(m.cap); });
    const sum = a => a.reduce((n, c) => n + VAL[c.toLowerCase()], 0);
    [O.top, O.bot].forEach(r => {
      const mine = caps[r.side], other = caps[r.side === "w" ? "b" : "w"], diff = sum(mine) - sum(other);
      r.cap.textContent = "";
      [...mine].sort((a, b) => VAL[b.toLowerCase()] - VAL[a.toLowerCase()]).forEach(c => r.cap.append(h("span", {class: "gc " + (c === c.toLowerCase() ? "pb" : "pw"), text: GLYPH[c.toLowerCase()]})));
      if (diff > 0) r.cap.append(h("span", {class: "gm-diff", text: "+" + diff}));
      const botRow = r.side !== g.side;
      r.pts.textContent = "";
      if (botRow && g.thinking) r.pts.append(h("span", {class: "oc-think"}, h("i", {class: "pnd-spin", "aria-hidden": "true"}), " o'ylamoqda…"));
      else if (botRow) r.pts.append(h("span", {class: "gm-tot", text: LV_INFO[g.level]}));
      else r.pts.append(h("span", {class: "gm-tot", text: g.pos.turn === (g.side === "w" ? 1 : -1) && !g.over ? "Sizning yurishingiz" : g.over ? "" : "Kuting…"}));
      const turn = !g.over && (g.pos.turn === 1 ? "w" : "b") === r.side;
      r.el.classList.toggle("turn", turn);
    });
  }
  function syncButtons() {
    const g = O.g; if (!g) return;
    if (O.undoBtn) O.undoBtn.disabled = !canUndo(g);
    if (O.hintBtn) O.hintBtn.disabled = !!g.over || g.thinking || !myTurn(g) || !!O.hinting;
  }

  function open() {
    if (O.el) return;
    if (!engineOk()) { toast("Shaxmat dvigateli yuklanmadi. Sahifani yangilang (bir marta internet kerak).", "error"); return; }
    const root = h("div", {id: "ocx", class: "gm oc"});
    O.main = h("div", {class: "gm-main"});
    root.append(
      h("div", {class: "gm-top"},
        h("b", {class: "gm-ttl", text: "🤖 Bot bilan o'ynash"}),
        h("span", {class: "gm-sp"}),
        h("button", {class: "gm-x", type: "button", "aria-label": "Ovoz", onclick: ev => {
          let on = true; try { on = localStorage.getItem("tc_gsnd") !== "off"; } catch (_) {}
          on = !on; try { localStorage.setItem("tc_gsnd", on ? "on" : "off"); } catch (_) {}
          ev.currentTarget.textContent = on ? "🔊" : "🔇"; if (on) sound("start");
        }}, (() => { try { return localStorage.getItem("tc_gsnd") !== "off" ? "🔊" : "🔇"; } catch (_) { return "🔊"; } })()),
        h("button", {class: "gm-x", type: "button", "aria-label": "Yopish", onclick: () => close()}, "✕")),
      O.main);
    document.body.append(root); O.el = root;
    navPush("ocx");
    const saved = loadSaved();
    if (saved) { const g = newGame(saved.level, saved.side, saved.moves); if (g) { O.g = g; O.bd = g.boards[g.boards.length - 1].split(""); render(); if (!myTurn(g) && !g.over) botTurn(); return; } lsDel(LS_GAME); }
    O.g = null; render();
  }
  function close() {
    if (!O.el) return;
    if (O.g) { O.g.token++; O.g.thinking = false; }
    clearTimeout(O.botTimer); clearTimeout(O.hintTimer); O.hinting = false;
    if (O.g && !O.g.over) saveGame();
    O.el.remove(); O.el = null; O.main = null; O.sqs = []; O.boardEl = null; O.layer = null; O.top = O.bot = O.hs = O.undoBtn = O.hintBtn = null; O.overCard = null;
    navPop("ocx");
    if (S.tab === "games") { try { renderList(); } catch (_) {} }
  }
  function render() {
    if (!O.el) return;
    O.main.textContent = ""; O.top = O.bot = O.hs = O.undoBtn = O.hintBtn = null; O.sel = null; O.drag = null; O.sqs = []; O.boardEl = null; O.layer = null;
    if (O.g) buildGame(); else buildLobby();
  }
  function startNew(level, pref, keepPref) {
    if (!window.TCChess) return;
    const side = pref === "r" ? (Math.random() < 0.5 ? "w" : "b") : pref;
    if (O.g) { O.g.token++; O.g.thinking = false; }
    clearTimeout(O.botTimer); O.hinting = false;
    if (!keepPref) lsSet(LS_CFG, {level, side: pref});
    const g = newGame(level, side, []); if (!g) return;
    O.g = g; O.bd = START.split(""); lsDel(LS_GAME);
    if (O.overCard) { O.overCard.remove(); O.overCard = null; }
    render(); sound("start"); haptic([40, 40, 40]);
    if (!myTurn(g)) botTurn();
  }
  function buildLobby() {
    const c = cfg(), st = stat(), T = window.TCChess;
    let level = c.level, side = c.side;
    const lvRow = h("div", {class: "oc-lv"}), sdRow = h("div", {class: "gm-sides"});
    const info = h("p", {class: "gm-note oc-lvinfo"});
    const paintLv = () => {
      lvRow.textContent = "";
      for (let i = 1; i <= 5; i++) lvRow.append(h("button", {type: "button", class: "oc-lvb" + (i === level ? " on" : ""), "aria-pressed": String(i === level), onclick: () => { level = i; paintLv(); }}, h("b", {text: String(i)}), h("small", {text: T.LEVELS[i].name})));
      info.textContent = T.LEVELS[level].name + " — " + LV_INFO[level];
    };
    const paintSd = () => {
      sdRow.textContent = "";
      [["w", "♔", "Oq", "birinchi yurasiz"], ["r", "🎲", "Tasodifiy", "oq yoki qora"], ["b", "♚", "Qora", "bot birinchi yuradi"]].forEach(([k, ic, nm, sub]) =>
        sdRow.append(h("button", {type: "button", class: "gm-sd" + (k === side ? " on" : ""), "aria-pressed": String(k === side), onclick: () => { side = k; paintSd(); }}, h("span", {text: ic}), h("b", {text: nm}), h("small", {text: sub}))));
    };
    paintLv(); paintSd();
    const n = st.w + st.l + st.d;
    const root = h("div", {class: "gm-menu oc-menu"},
      h("div", {class: "gm-mh"}, h("div", {class: "gm-mart", text: "♞"}), h("b", {text: "Bot bilan o'ynash"}), h("small", {text: "5 daraja • internet shart emas"}),
        h("div", {class: "gm-mst"}, h("span", {class: "gm-chip", text: n ? "🏆 " + st.w + " / " + st.l + " / " + st.d + " (yutuq / mag'lub. / durang)" : "Hali o'ynalmagan — birinchi bo'ling!"}))),
      h("div", {class: "oc-sec", text: "Bot darajasi"}), lvRow, info,
      h("div", {class: "oc-sec", text: "Siz qaysi tomonda?"}), sdRow,
      h("button", {class: "btn oc-go", type: "button", text: "▶ O'yinni boshlash", onclick: () => startNew(level, side)}),
      h("p", {class: "gm-note oc-foot", text: "Natijalar va to'xtatilgan o'yin faqat shu qurilmada saqlanadi. Oflayn o'yin ochko bermaydi."}));
    O.main.append(root);
  }
  function buildGame() {
    const g = O.g, opp = g.side === "w" ? "b" : "w";
    O.bd = g.boards[g.moves.length].split("");
    O.top = playerRow(opp); O.bot = playerRow(g.side);
    O.undoBtn = h("button", {class: "gm-undo", type: "button", onclick: undo, title: "Yurishni qaytarish"}, "↩ Orqaga");
    O.hintBtn = h("button", {class: "gm-undo oc-hint", type: "button", onclick: hint}, "💡 Maslahat");
    const act = h("div", {class: "gm-act oc-act"},
      h("button", {class: "gm-resign", type: "button", onclick: resign}, "🏳 Taslim"), O.undoBtn, O.hintBtn,
      h("button", {class: "gm-undo", type: "button", onclick: newMenu}, "☰ Yangi"));
    O.main.append(h("div", {class: "gm-wrap"}, O.top.el, boardBlock(), O.bot.el, buildHist(), act));
    paintMarks(); paintPlayers(); paintHist(); syncButtons();
    if (g.over) { g.counted = true; }
  }
  async function newMenu() {
    const g = O.g; if (!g) return;
    if (!g.over && g.moves.length > 1 && !await confirmDlg("Joriy o'yin tashlab ketiladi (mag'lubiyat hisoblanmaydi). Yangi o'yin boshlaymizmi?", {title: "Yangi o'yin", okText: "Yangi o'yin"})) return;
    if (O.g !== g) return;
    g.token++; g.thinking = false; clearTimeout(O.botTimer); lsDel(LS_GAME); O.g = null; render();
  }
  function reset() {  }
  NAV_CLOSE.ocx = () => close();
  return {open, close, reset, isOpen: () => !!O.el, hasSaved: () => !!loadSaved() || !!(O.g && !O.g.over)};
})();

