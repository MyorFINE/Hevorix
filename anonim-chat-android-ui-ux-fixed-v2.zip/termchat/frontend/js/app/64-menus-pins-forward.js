function openMenu(x, y, items, sheet) {
  S.ctxAt = Date.now();
  const ctx = $("ctx"); ctx.textContent = "";
  items.forEach(it => {
    const b = h("button", {class: "dd-i", type: "button", onclick: () => { closeCtx(); it.fn(); }}, icon(it.ic), it.text);
    if (it.danger) b.style.color = "var(--err)";
    ctx.append(b);
  });
  showCtx(ctx, x, y, false);
}
function showCtx(ctx, x, y, asSheet) {
  ctx.classList.remove("hidden");
  ctx.classList.toggle("as-sheet", asSheet);
  $("ctxBack").classList.toggle("hidden", !asSheet);
  if (isMobile()) navPush("ctx");
  const w = ctx.offsetWidth, hgt = ctx.offsetHeight;
  ctx.style.left = Math.max(8, Math.min(x, innerWidth - w - 8)) + "px";
  ctx.style.top = Math.max(8, Math.min(y, innerHeight - hgt - 8)) + "px";
}
function dmMenu(x, y, uid, sheet) {
  openMenu(x, y, [
    {ic: "user", text: "Profilni ko'rish", fn: () => openProfile(uid)},
    {ic: "trash", text: "Suhbatni o'chirish", danger: true, fn: () => deleteDmChat(uid)},
  ], sheet);
}
$("chMore").addEventListener("click", e => {
  e.stopPropagation();
  if (!S.active || S.active.kind === "group") return;
  const r = $("chMore").getBoundingClientRect();
  if (S.active.kind === "channel") Channels.menu(r.right - 220, r.bottom + 4, S.active.id);
  else dmMenu(r.right - 200, r.bottom + 4, S.active.uid);
});
async function deleteDmChat(uid) {
  const u = U(uid);
  const ok = await confirmDlg("Bu suhbat (" + u.nickname + " bilan) ikkala tomon uchun ham butunlay o'chiriladi: xabarlar va rasmlar ikkalangizdan ham yo'qoladi. Buni qaytarib bo'lmaydi.",
    {title: "Suhbatni o'chirish", okText: "O'chirish", danger: true});
  if (ok) wsSend({type: "delete_dm", with: uid});
}

let renderQueued = false;
function scheduleRender() {
  if (renderQueued) return; renderQueued = true;
  requestAnimationFrame(() => { renderQueued = false; renderMessages(false); renderList(); });
}
function enterSelect(firstId) {
  if (!S.active) return;
  cancelEdit(); cancelReply();
  S.sel = new Set(); if (firstId != null) S.sel.add(firstId);
  $("chat").classList.add("selecting"); navPush("sel");
  renderMessages(false); updateSelBar();
}
function exitSelect() {
  if (!S.sel) return;
  S.sel = null; $("chat").classList.remove("selecting"); navPop("sel");
  renderMessages(false);
}
function toggleSel(m, row) {
  if (!S.sel || !canDelete(m)) return;
  if (S.sel.has(m.id)) S.sel.delete(m.id); else S.sel.add(m.id);
  if (row) row.classList.toggle("selected", S.sel.has(m.id));
  updateSelBar();
}
function updateSelBar() {
  if (!S.sel) return;
  $("selCount").textContent = String(S.sel.size);
  $("selDel").disabled = !S.sel.size;
  const all = currentMsgs().filter(x => !x.service && canDelete(x));
  $("selAll").textContent = all.length && all.every(x => S.sel.has(x.id)) ? "Bekor" : "Hammasi";
}
$("selCancel").addEventListener("click", exitSelect);
$("selAll").addEventListener("click", () => {
  if (!S.sel) return;
  const all = currentMsgs().filter(x => !x.service && canDelete(x));
  if (all.length && all.every(x => S.sel.has(x.id))) S.sel.clear(); else all.forEach(x => S.sel.add(x.id));
  document.querySelectorAll("#msgs .row[data-id]").forEach(r => r.classList.toggle("selected", S.sel.has(Number(r.dataset.id))));
  updateSelBar();
});
$("selDel").addEventListener("click", async () => {
  if (!S.sel || !S.sel.size) return;
  const ids = [...S.sel], n = ids.length;
  const ok = await confirmDlg(n + " ta xabar o'chirilsinmi?", {title: "Xabarlarni o'chirish", okText: "O'chirish", danger: true});
  if (!ok || !S.sel) return;
  for (let i = 0; i < ids.length; i += 200) wsSend({type: "delete_many", ids: ids.slice(i, i + 200)});
  exitSelect();
});
async function clearGroupChat() {
  if (!amAdmin()) return;
  const ok = await confirmDlg("Umumiy chatdagi BARCHA xabarlar hamma uchun o'chiriladi. Buni qaytarib bo'lmaydi.",
    {title: "Chatni tozalash", okText: "Tozalash", danger: true});
  if (ok) wsSend({type: "clear_chat"});
}

function canDelete(m) {
  if (m.ch) return amAdmin();
  if (m.user.id === S.me.id) return true;
  if (m.to != null || !amAdmin()) return false;
  const t = U(m.user.id);
  return t.role === "user" || (t.role === "admin" && S.me.role === "owner");
}
function openCtx(x, y, m) {
  S.ctxAt = Date.now();
  const ctx = $("ctx"); ctx.textContent = ""; ctx._anchorB = null; ctx.style.top = "";
  const add = (ic, text, fn, danger) => {
    const b = h("button", {class: "dd-i", type: "button", onclick: () => { closeCtx(); fn(); }}, icon(ic), text);
    if (danger) b.style.color = "var(--err)";
    ctx.append(b);
  };
  const usable = !m.locked && !m.bad;
  const chan = !!m.ch;
  if (S.offline) {
    if (m.content && usable) add("copy", "Nusxalash", () => copyText(m.content));
    else { toast("Oflayn rejim: bu xabar bilan amal qilib bo'lmaydi", "info"); return; }
    showCtx(ctx, x, y, false); return;
  }
  if (canReact(m)) ctx.append(rxPicker(m));
  if (chan) add("chat", "Izohlar", () => Channels.openComments(m));
  if (usable && !m.legacy && !chan) add("reply", "Javob berish", () => startReply(m));
  if (m.content && usable) add("copy", "Nusxalash", () => copyText(m.content));
  if (usable && canPin(m)) { const pd = isPinned(m); add(pd ? "unpin" : "pin", pd ? "Unpin qilish" : "Pin qilish", () => togglePin(m)); }
  if (usable && (m.image || (m.file && !m.file.vnote))) add("save", "Saqlash (Save as)", () => saveAs(m));
  if (usable && !m.legacy && !m.service && (m.content || m.image || m.file)) add("forward", "Oldinga yuborish", () => forwardMessage(m));
  if (m.user.id !== S.me.id && !chan) add("user", "Profilni ko'rish", () => openProfile(m.user.id));
  if (m.user.id !== S.me.id && m.to == null && !m.service && !chan) add("flag", "Shikoyat qilish", () => reportMessage(m));
  if (m.user.id === S.me.id && usable && !m.legacy) add("edit", "Tahrirlash", () => startEdit(m));
  if (canDelete(m)) add("select", "Belgilash", () => enterSelect(m.id));
  if (canDelete(m)) add("trash", "O'chirish", async () => { if (await confirmDlg("Bu xabar o'chirilsinmi?", {title: "Xabarni o'chirish", okText: "O'chirish", danger: true})) wsSend({type: "delete", id: m.id}); }, true);
  const row = document.querySelector('#msgs .row[data-id="' + Number(m.id) + '"]'); if (row) row.classList.add("ctx-on");
  showCtx(ctx, x, y, false);
}
function closeCtx() {
  const c = $("ctx"); if (c.classList.contains("hidden")) return;
  c.classList.add("hidden"); $("ctxBack").classList.add("hidden");
  document.querySelectorAll("#msgs .row.ctx-on").forEach(r => r.classList.remove("ctx-on"));
  navPop("ctx");
}

const pinSt = () => !S.active ? null : S.active.kind === "group" ? S.group : S.active.kind === "dm" ? dmOf(S.active.uid) : null;
const pinStOf = m => m.to == null ? S.group : dmOf(partnerOf(m));
function canPin(m) { return !!m && !m.ch && !m.service && m.id != null && !m.pending && (m.to != null || amAdmin()); }
function isPinned(m) { const st = pinStOf(m); return !!(st.pins && st.pins.some(p => p.id === m.id)); }
async function togglePin(m) {
  const on = !isPinned(m);
  if (m.to == null) { wsSend({type: "pin", id: m.id, on}); return; }
  const r = await askDialog({title: on ? "Xabarni pin qilish" : "Pinni olib tashlash",
    text: on ? "Xabar sizning suhbatingizda yuqoriga mahkamlanadi." : "Xabar sizdan pin olib tashlanadi.",
    okText: "OK", check: {label: on ? "Suhbatdosh uchun ham pin qilish" : "Suhbatdosh uchun ham olib tashlash", checked: true}});
  if (!r) return;
  wsSend({type: "pin", id: m.id, on, both: !!r.checked});
}
const pinRow = id => $("msgs").querySelector('.row[data-id="' + Number(id) + '"]');
function markPins() {
  const st = pinSt(), box = $("msgs"); if (!st) return;
  const ids = new Set((st.pins || []).map(p => p.id));
  box.querySelectorAll(".row[data-id]").forEach(r => {
    const on = ids.has(Number(r.dataset.id)), meta = r.querySelector(".bubble .meta"), mk = meta && meta.querySelector(".pinmark");
    if (on && meta && !mk) meta.prepend(icon("pin", "ic pinmark"));
    else if (!on && mk) mk.remove();
  });
}
function renderPinBar() {
  const bar = $("pinBar"), st = pinSt(), list = (st && st.pins) || [];
  if (!st || !list.length) { bar.classList.add("hidden"); return; }
  if (st.pinIdx == null || st.pinIdx >= list.length || st.pinIdx < 0) st.pinIdx = list.length - 1;
  const m = list[st.pinIdx];
  $("pinTitle").textContent = "Pin qilingan xabar" + (list.length > 1 ? " #" + (st.pinIdx + 1) + "/" + list.length : "");
  const t = $("pinText"); t.textContent = ""; t.append(...[].concat(previewOf(m, true, false)));
  $("pinX").classList.toggle("hidden", !canPin(m));
  bar.classList.remove("hidden");
}
async function pinGoTo(id) {
  const st = pinSt(); if (!st) return;
  if (!pinRow(id)) {
    let i = st.msgs.findIndex(x => x.id === id);
    for (let n = 0; i < 0 && st.more && n < 30; n++) { await loadOlder(); i = st.msgs.findIndex(x => x.id === id); }
    if (i >= 0) { S.win = Math.max(S.win || WIN0, st.msgs.length - i + 6); renderMessages(false); }
  }
  if (pinRow(id)) jumpTo(id); else toast("Xabar topilmadi (eski yoki o'chirilgan)", "warn");
}
function pinBarClick() {
  const st = pinSt(); if (!st || !st.pins || !st.pins.length) return;
  const m = st.pins[st.pinIdx != null ? st.pinIdx : st.pins.length - 1];
  st.pinIdx = (st.pins.indexOf(m) - 1 + st.pins.length) % st.pins.length;
  renderPinBar(); pinGoTo(m.id);
}
async function pinsRefresh(kind, uid) {
  kind = kind || (S.active && S.active.kind); if (kind !== "group" && kind !== "dm") return;
  uid = uid != null ? uid : (S.active && S.active.uid);
  const st = kind === "group" ? S.group : dmOf(uid);
  try {
    const j = await api(kind === "group" ? "/pins/group" : "/pins/dm/" + uid);
    if (X.ready) await Promise.race([X.ready, delay(8000)]);
    await hydrateAll(j.pins); j.pins.forEach(x => upsertUser(x.user));
    st.pins = j.pins; st.pinIdx = null;
  } catch (_) { return; }
  if (pinSt() === st) { renderPinBar(); markPins(); }
}
function pinsOnEvent(m) { if (m.scope === "g") pinsRefresh("group"); else pinsRefresh("dm", m.with); }
function pinDrop(id) {
  const all = [S.group].concat([...S.dms.values()]);
  all.forEach(st => { if (st.pins && st.pins.some(p => p.id === id)) st.pins = st.pins.filter(p => p.id !== id); });
  if (S.active) renderPinBar();
}
$("pinBarMain").addEventListener("click", pinBarClick);
$("pinX").addEventListener("click", e => { e.stopPropagation(); const st = pinSt(); if (!st || !st.pins) return; const m = st.pins[st.pinIdx != null ? st.pinIdx : st.pins.length - 1]; if (m && canPin(m)) togglePin(m); });

const safeName = n => String(n || "fayl").replace(/[\\/:*?"<>|\u0000-\u001f]/g, "_").replace(/^\.+/, "").trim().slice(0, 120) || "fayl";
async function messageBytes(m) {
  if (m.e2e) return e2eFetchBlob(m);
  const url = m.image || (m.file && m.file.url);
  const r = await SC.fetch(url, {headers: {Authorization: "Bearer " + S.token}});
  if (!r.ok) throw new Error("fayl");
  return r.bytes;
}
async function saveBytesAs(getBytes, name) {
  let handle = null;
  if (window.showSaveFilePicker) {
    try { handle = await window.showSaveFilePicker({suggestedName: name}); }
    catch (err) { if (err && err.name === "AbortError") return false; handle = null; }
  }
  let bytes;
  try { bytes = await getBytes(); } catch (err) { if (handle && handle.remove) handle.remove().catch(() => {}); throw err; }
  if (handle) {
    const w = await handle.createWritable();
    try { await w.write(bytes); await w.close(); } catch (err) { try { await w.abort(); } catch (_) {} throw err; }
    return true;
  }
  const url = URL.createObjectURL(new Blob([bytes], {type: "application/octet-stream"}));
  const a = h("a", {href: url, download: name}); document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60000);
  return true;
}
async function saveAs(m) {
  if (m.file && m.file.vnote) { toast("Dumaloq videoni saqlab bo'lmaydi", "error"); return; }
  const name = safeName((m._f && m._f.name) || (m.file && m.file.name) || (m.image ? "rasm.jpg" : "fayl"));
  try { if (await saveBytesAs(() => messageBytes(m), name)) toast("Saqlandi: " + name, "ok"); }
  catch (_) { toast("Faylni saqlab bo'lmadi", "error"); }
}
function forwardMessage(m) {
  const picked = new Map();
  let filter = "", busy = false;
  const targets = () => [{key: "g", kind: "group"}].concat(S.members.filter(x => x.id !== S.me.id && !x.deleted && !x.banned).map(x => ({key: "u" + x.id, kind: "dm", uid: x.id})));
  const what = m.image ? "📷 Rasm" : m.file ? fileIco(m.file) + fileWhat(m.file) : "";
  openModal(() => {
    const list = h("div", {class: "fwl"}), send = h("button", {class: "btn", type: "button", disabled: true, text: "Yuborish"});
    const noteTxt = (what ? what + (m.content ? " • " : "") : "") + (m.content ? snippetOf(m.content).slice(0, 80) : "");
    const note = h("div", {class: "fw-note"}, Rich.hasInlineEmoji(noteTxt) ? Rich.preview(noteTxt) : noteTxt);
    const upd = () => { send.disabled = busy || !picked.size; send.textContent = picked.size ? "Yuborish (" + picked.size + ")" : "Yuborish"; };
    const fill = () => {
      list.textContent = "";
      const q = filter.trim().toLowerCase().replace(/^@/, "");
      targets().forEach(t => {
        const u = t.kind === "dm" ? U(t.uid) : null;
        if (q && (!u || !(u.nickname.toLowerCase().includes(q) || u.username.toLowerCase().includes(q)))) { if (!(t.kind === "group" && "umumiy chat".includes(q))) return; }
        const ck = h("input", {type: "checkbox", class: "ck", tabindex: "-1", "aria-hidden": "true"}); ck.checked = picked.has(t.key);
        const row = h("button", {class: "frow" + (ck.checked ? " on" : ""), type: "button"},
          u ? avatar(u, "m", true) : groupAvatar("m"),
          h("div", {class: "utx"}, u ? nameEl(u) : h("span", {class: "nt", text: "Umumiy chat"}), h("span", {class: "fsub", text: u ? "@" + u.username : (S.members.length || 1) + " a'zo"})), ck);
        row.addEventListener("click", () => { if (busy) return; if (picked.has(t.key)) picked.delete(t.key); else picked.set(t.key, t); ck.checked = picked.has(t.key); row.classList.toggle("on", ck.checked); upd(); });
        list.append(row);
      });
      if (!list.children.length) list.append(h("div", {class: "none", text: "Hech narsa topilmadi"}));
    };
    const search = h("input", {type: "text", class: "gsearch", placeholder: "Qidirish", autocomplete: "off"});
    search.addEventListener("input", () => { filter = search.value; fill(); });
    send.addEventListener("click", async () => {
      if (busy || !picked.size) return;
      busy = true; upd(); send.textContent = "Shifrlanmoqda…"; search.disabled = true;
      const r = await doForward(m, [...picked.values()]);
      busy = false; closeModal();
      if (r.ok) toast("Oldinga yuborildi" + (r.ok > 1 ? " (" + r.ok + " ta suhbat)" : ""), "ok");
      if (r.errs.length) toast(r.errs[0] + (r.errs.length > 1 ? " (+" + (r.errs.length - 1) + " ta xato)" : ""), "error");
    });
    fill();
    return h("div", {}, sheetHead("Oldinga yuborish"), note, search, list, h("div", {class: "fw-bar"}, send));
  }, false);
}
async function doForward(m, targets) {
  const res = {ok: 0, errs: []};
  let enc = null;
  const fw = m._fw || (m.ch ? {n: (chInfo(m.ch) || {}).nickname || "Kanal", id: 0} : {n: m.user.nickname, id: m.user.id});
  try { if (m._f) enc = await E2E.encryptFile(new Uint8Array(await messageBytes(m))); }
  catch (_) { res.errs.push("Faylni ochib bo'lmadi"); return res; }
  for (const t of targets) {
    const label = t.kind === "group" ? "Umumiy chat" : U(t.uid).nickname;
    try {
      if (t.kind === "group" && S.chat.locked && !amAdmin()) throw new Error("chat qulflangan");
      if (t.kind === "dm" && U(t.uid).deleted) throw new Error("akkaunt o'chirilgan");
      const ctx = await keyForTarget(t), payload = {t: m.content || "", fw};
      let blobName = null;
      if (enc) {
        const r = await SC.fetch("/api/e2ee/blob", {method: "POST", headers: {Authorization: "Bearer " + S.token, "Content-Type": "application/octet-stream"}, body: enc.blob});
        const j = await r.json().catch(() => ({}));
        if (!r.ok) throw new Error(typeof j.detail === "string" ? j.detail : "fayl yuklanmadi");
        blobName = j.blob; payload.f = Object.assign({}, m._f, {k: enc.key});
      }
      const msg = {type: "send", e2e: await sealFor(ctx, payload)};
      if (blobName) msg.blob = blobName;
      withTarget(msg, t);
      if (!wsSend(msg)) throw new Error("ulanish yo'q");
      res.ok++;
    } catch (err) { res.errs.push(label + ": " + err.message); }
  }
  return res;
}
async function reportMessage(m) {
  const reason = await promptDlg("Shikoyat qilish", m.e2e
    ? "Xabarlar shifrlangan, adminlar ularni o'qiy olmaydi. Shikoyat yuborsangiz, FAQAT shu bitta xabarning matni adminlarga ochib beriladi. Nima uchun shikoyat qilyapsiz? (ixtiyoriy)"
    : "Nima uchun shikoyat qilyapsiz? (ixtiyoriy)", "", {okText: "Yuborish", placeholder: "Sabab"});
  if (reason === null) return;
  try { await api("/report", {method: "POST", body: {message_id: m.id, reason, evidence: m.e2e ? (m.content || "") : ""}}); toast("Shikoyat adminlarga yuborildi", "ok"); }
  catch (err) { toast(err.message, "error"); }
}
document.addEventListener("click", e => {
  if (Date.now() - (S.ctxAt || 0) > 350) closeCtx();
});
async function copyText(t) {
  try { await navigator.clipboard.writeText(t); toast("Nusxalandi", "ok"); }
  catch (_) {
    const ta = h("textarea", {class: "offscreen"}); ta.value = t; document.body.append(ta); ta.select();
    try { document.execCommand("copy"); toast("Nusxalandi", "ok"); } catch (_e) {}
    ta.remove();
  }
}

