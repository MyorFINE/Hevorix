/* ---------- Server holati (faqat adminlar): jonli ko'rsatkichlar, har 2 soniyada yangilanadi ---------- */
function openServerStatus() {
  openPage(p => {
    if (p._ss) { p._ss.stop(); }
    const fmtDur = sec => { sec = Math.max(0, Math.floor(sec)); const d = Math.floor(sec / 86400), hh = Math.floor(sec % 86400 / 3600), m = Math.floor(sec % 3600 / 60), ss = sec % 60;
      return (d ? d + " kun " : "") + (d || hh ? hh + " soat " : "") + (m || hh || d ? m + " daq " : "") + ss + " s"; };
    const pct = (a, b) => b ? Math.max(0, Math.min(100, a / b * 100)) : 0;
    const dash = "—";
    const mk = (title) => { const val = h("div", {class: "ss-v", text: dash}), sub = h("div", {class: "ss-s", text: ""}), bar = h("i"), track = h("div", {class: "ss-bar"}, bar);
      const el = h("div", {class: "ss-card"}, h("div", {class: "ss-t", text: title}), val, track, sub);
      return {el, val, sub, bar, track}; };
    const cards = {cpu: mk("Protsessor (CPU)"), mem: mk("Xotira (RAM)"), disk: mk("Disk"), ping: mk("Aloqa tezligi"), ws: mk("Jonli ulanishlar"), http: mk("So'rovlar"), db: mk("Baza (SQLite)"), up: mk("Ishlash vaqti")};
    ["ping", "ws", "http", "db", "up"].forEach(k => cards[k].track.classList.add("hidden"));
    const statePill = h("span", {class: "ss-pill", text: "Yuklanmoqda…"});
    const live = h("span", {class: "ss-live", text: "● jonli"});
    const spark = h("div", {class: "ss-spark"});
    const hist = [];
    const drawSpark = () => {
      if (hist.length < 2) return;
      const mx = Math.max(60, ...hist), pts = hist.map((v, i) => (i / (hist.length - 1) * 300).toFixed(1) + "," + (52 - v / mx * 48).toFixed(1)).join(" ");
      spark.innerHTML = '<svg viewBox="0 0 300 56" preserveAspectRatio="none"><polyline fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" vector-effect="non-scaling-stroke" points="' + pts + '"/></svg>';
    };
    const lvl = (el, v) => { el.classList.toggle("warn", v >= 70 && v < 90); el.classList.toggle("bad", v >= 90); };
    const note = h("p", {class: "adm-note", text: "Ko'rsatkichlar Render serverining o'zidan olinadi va har 2 soniyada yangilanadi. CPU — faqat shu ilova protsessi (1 yadro = 100%)."});
    const body = h("div", {class: "pg-body ss-body"},
      h("div", {class: "ss-top"}, statePill, live),
      h("div", {class: "ss-grid"}, cards.up.el, cards.ping.el, cards.cpu.el, cards.mem.el, cards.disk.el, cards.ws.el, cards.http.el, cards.db.el),
      h("div", {class: "ss-card ss-wide"}, h("div", {class: "ss-t", text: "Aloqa kechikishi (oxirgi 30 o'lchov, ms)"}), spark),
      note);
    const st = {on: true, busy: false, timer: 0, fails: 0, seen: false};
    const tick = async () => {
      if (!st.on) return;
      // openPage quruvchini sahifa DOM'ga qo'shilishidan OLDIN chaqiradi: avval ko'rinishini kutamiz, faqat keyin "yopilgan" deb hisoblaymiz
      if (p.el && p.el.isConnected) st.seen = true;
      if (p.closing || (st.seen && !p.el.isConnected)) { stop(); return; }
      if (!st.seen) return;
      if (st.busy || document.hidden) return;
      st.busy = true;
      const t0 = performance.now();
      try {
        const d = await api("/admin/server-status");
        const rtt = performance.now() - t0; st.fails = 0;
        statePill.textContent = d.ok ? "✅ Server ishlayapti" : "⚠ Bazada muammo"; statePill.className = "ss-pill " + (d.ok ? "ok" : "bad");
        live.classList.remove("off");
        cards.up.val.textContent = fmtDur(d.uptime); cards.up.sub.textContent = "Versiya " + d.version + " • PID " + d.pid + " • oqimlar: " + d.threads;
        cards.ping.val.textContent = Math.round(rtt) + " ms"; cards.ping.val.className = "ss-v" + (rtt > 800 ? " bad" : rtt > 300 ? " warn" : "");
        cards.ping.sub.textContent = rtt > 800 ? "Juda sekin" : rtt > 300 ? "Sekinroq" : "Yaxshi";
        hist.push(Math.round(rtt)); if (hist.length > 30) hist.shift(); drawSpark();
        const c = d.cpu, cp = c.process_pct;
        cards.cpu.val.textContent = cp == null ? dash : cp.toFixed(1) + "%";
        cards.cpu.bar.style.width = Math.min(100, cp || 0) + "%"; lvl(cards.cpu.el, cp || 0);
        cards.cpu.sub.textContent = (c.load ? "Yuklama: " + c.load.map(x => x.toFixed(2)).join(" / ") + " • " : "") + c.cores + " yadro";
        const m = d.mem;
        if (m && m.total) { const pc = pct(m.used, m.total); cards.mem.val.textContent = fmtSize(m.used) + " / " + fmtSize(m.total); cards.mem.bar.style.width = pc + "%"; lvl(cards.mem.el, pc);
          cards.mem.sub.textContent = pc.toFixed(0) + "% band" + (m.process ? " • ilova: " + fmtSize(m.process) : ""); }
        else { cards.mem.val.textContent = m && m.process ? fmtSize(m.process) : dash; cards.mem.sub.textContent = "Ilova protsessi"; }
        const k = d.disk, dt = d.data || {};
        if (k) { const pc = pct(k.used, k.total); cards.disk.val.textContent = fmtSize(k.free) + " bo'sh"; cards.disk.bar.style.width = pc + "%"; lvl(cards.disk.el, pc);
          cards.disk.sub.textContent = "Ma'lumotlar: " + fmtSize(dt.total || 0) + " (baza " + fmtSize(dt.db || 0) + ", media " + fmtSize((dt.media || 0) + (dt.uploads || 0)) + ", emoji " + fmtSize(dt.emoji || 0) + ")"; }
        const w = d.ws; cards.ws.val.textContent = w.connections + " ulanish"; cards.ws.sub.textContent = "Onlayn: " + w.online + " • yashirin (away): " + w.away + " • eng ko'pi: " + w.peak;
        const r = d.http; cards.http.val.textContent = r.rps.toFixed(1) + " /s"; cards.http.sub.textContent = "Jami: " + r.total + " • xatolar (5xx): " + r.errors;
        const b = d.db; cards.db.val.textContent = b.ok ? b.ping_ms.toFixed(1) + " ms" : "XATO"; cards.db.val.className = "ss-v" + (b.ok ? "" : " bad");
        cards.db.sub.textContent = b.users + " foydalanuvchi • " + b.messages + " xabar • " + b.sessions + " sessiya";
      } catch (err) {
        if (err.message === "401") { stop(); return; }
        st.fails++; statePill.textContent = "❌ Server javob bermayapti"; statePill.className = "ss-pill bad"; live.classList.add("off");
      } finally { st.busy = false; }
    };
    const onVis = () => { if (!document.hidden && st.on) tick(); };
    const stop = () => { st.on = false; clearInterval(st.timer); document.removeEventListener("visibilitychange", onVis); };
    p._ss = {stop};
    st.timer = setInterval(tick, 2000);
    requestAnimationFrame(() => requestAnimationFrame(tick));        // sahifa DOM'ga qo'shilgach darhol birinchi o'lchov
    document.addEventListener("visibilitychange", onVis);
    return h("div", {}, pageHead("Server holati"), body);
  });
}


function openInfoPage() {
  openPage(p => {
    const me = S.me;
    const avBox = h("div", {class: "tg-top inf-top"});
    const paintAvatar = () => {
      avBox.textContent = "";
      avBox.append(h("div", {class: "inf-av"}, avatar(S.me, "l"),
        h("button", {class: "inf-cam", type: "button", "aria-label": "Profil rasmini o'zgartirish", onclick: () => $("file").click()}, icon("camera"))));
    };
    paintAvatar();
    const gal = h("div", {class: "gal inf-gal"});
    const nick = h("input", {type: "text", class: "fld", maxlength: "24", "aria-label": "Nickname"}); nick.value = me.nickname;
    const bio = h("textarea", {class: "fld", rows: "3", maxlength: "140", placeholder: "O'zingiz haqingizda…", "aria-label": "Bio"}); bio.value = me.bio || "";
    const cnt = h("span", {class: "inf-cnt", text: String(140 - bio.value.length)});
    bio.addEventListener("input", () => { cnt.textContent = String(140 - bio.value.length); });
    const loadGallery = async () => {
      try {
        const j = await api("/avatars");
        gal.textContent = "";
        j.avatars.forEach(a => {
          const del = h("button", {type: "button", title: "O'chirish", "aria-label": "O'chirish"}, icon("close"));
          del.addEventListener("click", async e => { e.stopPropagation(); try { await api("/avatars/" + a.id, {method: "DELETE"}); loadGallery(); } catch (err) { toast(err.message, "error"); } });
          const g = h("div", {class: "gi" + (a.active ? " act" : ""), title: a.active ? "Faol rasm" : "Faollashtirish"}, h("img", {src: a.url, alt: ""}), del);
          g.addEventListener("click", async () => { if (a.active) return; try { await api("/avatars/" + a.id + "/use", {method: "POST"}); loadGallery(); } catch (err) { toast(err.message, "error"); } });
          gal.append(g);
        });
        if (j.avatars.some(a => a.active)) gal.append(h("button", {class: "btn ghost sm", type: "button", onclick: async () => { try { await api("/avatar/clear", {method: "POST"}); loadGallery(); } catch (err) { toast(err.message, "error"); } }}, "Rasmni olib tashlash"));
        setTimeout(paintAvatar, 500);
      } catch (_) {}
    };
    S.reloadGallery = loadGallery; loadGallery();
    const save = async btn => {
      btn.disabled = true;
      try {
        const j = await api("/profile", {method: "PATCH", body: {nickname: nick.value, bio: bio.value}});
        if (j && j.me) { upsertUser(j.me); renderList(); renderHeader(); renderMessages(false); }
        toast("Profil saqlandi", "ok");
      } catch (err) { toast(err.message, "error"); }
      btn.disabled = false;
    };
    p.refresh = paintAvatar;
    return h("div", {}, pageHead("Ma'lumot"), avBox, gal,
      h("div", {class: "inf-form"},
        h("label", {class: "fl"}, "Nickname", nick),
        h("div", {class: "fl"}, h("span", {class: "inf-lab"}, "Bio", cnt), bio, h("small", {class: "inf-hint", text: "Yosh, kasb yoki shahar kabi qisqa ma'lumot. Havola (https://…) va @username qo'ysangiz, profilingizda bosiladigan bo'ladi."})),
        h("div", {class: "tg-row copy", role: "button", tabindex: "0", title: "Nusxalash", onclick: () => copyText("@" + me.username)},
          h("div", {class: "tg-val", text: "@" + me.username}), h("div", {class: "tg-lab", text: "Username (o'zgarmaydi)"})),
        h("button", {class: "btn", type: "button", onclick: e => save(e.currentTarget)}, "Saqlash")),
      isStaff(me) ? h("div", {class: "inf-look"}, lookSection()) : null);
  });
}

function openNotifPage() {
  openPage(() => {
    const st = Push.state();
    const pushHint = !st.ok ? (st.why === "ios-install" ? "iPhone'da avval ilovani bosh ekranga o'rnating (Ulashish → Bosh ekranga qo'shish)." : "Bu brauzer bildirishnomalarni qo'llab-quvvatlamaydi.")
      : st.permission === "denied" ? "Bildirishnomalar brauzer sozlamalarida bloklangan. Sayt sozlamalaridan ruxsat bering."
      : "Yoqilsa, brauzer yopiq bo'lsa ham xabar keladi. Xabar matni bildirishnomada ko'rsatilmaydi.";
    return h("div", {}, pageHead("Bildirishnomalar va ovozlar"),
      switchRow("bell", "Bildirishnomalar", () => Push.state().on, async on => {
        if (on) { await Push.enable(api); toast("Bildirishnomalar yoqildi", "ok"); }
        else { await Push.disable(api); toast("Bu qurilmada bildirishnomalar o'chirildi", "info"); }
      }, pushHint),
      gapEl(),
      switchRow("speaker", "Xabar ovozi", sndOn, on => {
        try { localStorage.setItem(LS_SND, on ? "on" : "off"); } catch (_) {}
        if (on) ting(true);
      }, "Ilova ochiq bo'lganda boshqa suhbatga xabar kelsa qisqa ovoz chiqadi."));
  });
}

async function changePassword(oldPw, newPw) {          // maxfiy kalitlar yangi parol bilan brauzerda QAYTA O'RALADI
  if (!oldPw) throw new Error("Eski parolni kiriting");
  if (newPw.length < 6) throw new Error("Yangi parol kamida 6 belgi bo'lishi kerak");
  const info = await api("/me"), e = info.e2ee, un = S.me.username;
  const ko = await E2E.deriveFromPassword(un, oldPw, e.kdf_iter || E2E.KDF_DEFAULT);
  let ident; try { ident = await E2E.unwrapIdentity(e.key_blob, ko.kek, un); } catch (_) { throw new Error("Eski parol noto'g'ri"); }
  const kn = await E2E.deriveFromPassword(un, newPw, E2E.KDF_DEFAULT);
  await api("/password", {method: "POST", body: {old: ko.auth, new: kn.auth, key_blob: await E2E.wrapIdentity(ident, kn.kek, un), kdf_iter: E2E.KDF_DEFAULT}});
}
/* Vaqt oralig'i: "2 soat 5 daq" */
function fmtSpan(sec) {
  sec = Math.max(0, Math.floor(sec));
  const d = Math.floor(sec / 86400), hr = Math.floor(sec % 86400 / 3600), m = Math.floor(sec % 3600 / 60);
  if (d) return d + " kun " + hr + " soat";
  if (hr) return hr + " soat " + m + " daq";
  if (m) return m + " daqiqa";
  return "1 daqiqadan kam";
}

/* Maxfiylik va xavfsizlik: faqat 2 ta bo'lim — parolni almashtirish va ulangan qurilmalar */
async function setPrivacy(patchObj) {                         // server saqlaydi va javobda to'liq holatni qaytaradi
  S.priv = await api("/privacy", {method: "POST", body: patchObj});
}
function openPrivacyPage() {
  api("/privacy").then(j => { S.priv = j; const p = PG.list[PG.list.length - 1]; if (p && p.el.textContent.includes("Maxfiylik va xavfsizlik")) paintPage(p); }).catch(() => {});
  openPage(p => {
    p.refresh = null;
    return h("div", {}, pageHead("Maxfiylik va xavfsizlik"),
      secTitle("Kirish"),
      switchRow("lock", "Har kirishda login so'rash", () => !stayOn(), async () => { await toggleStay(); },
        "Yoqilsa, sahifa har safar ochilganda username va parol so'raladi. O'chirilsa, bu qurilmada login so'ralmasdan kirasiz — qurilmani begonalarga bermang."),
      gapEl(),
      secTitle("Ko'rinish"),
      switchRow("eye", "Last seen ni ko'rsatish", () => !(S.priv && S.priv.hide_seen), async on => { await setPrivacy({hide_seen: !on}); },
        "O'chirilsa, boshqalar oxirgi marta qachon onlayn bo'lganingizni ko'rmaydi («yaqinda onlayn bo'lgan» deb chiqadi). Onlayn holatingiz o'zgarmaydi."),
      switchRow("ghost", "Yashirin profil rejimi", () => !!(S.priv && S.priv.ghost), async on => { await setPrivacy({ghost: on}); },
        "Yoqilsa, siz doim oflayn ko'rinasiz: onlayn holat, last seen va «yozmoqda…» belgilari boshqalarga ko'rinmaydi. Siz xabarlarni odatdagidek yozasiz va o'qiysiz."),
      gapEl(),
      secTitle("Xavfsizlik"),
      setRow("key", "Parolni almashtirish", openChangePasswordPage),
      setRow("devices", "Ulangan qurilmalar", openDevicesPage),
      h("p", {class: "tg-hint", text: "Akkauntingizga qaysi qurilmalardan kirilganini ko'ring va keraklisini o'zingiz chiqarib yuboring."}));
  });
}

/* 1-bo'lim: parolni almashtirish (eski parol, yangi parol, yangi parolni takrorlash) */
function openChangePasswordPage() {
  openPage(() => {
    const fld = (label, ac) => { const i = h("input", {type: "password", class: "fld", autocomplete: ac, maxlength: "128", "aria-label": label}); return {i, lab: h("label", {class: "fl"}, label, i)}; };
    const old = fld("Eski parol", "current-password"), nw = fld("Yangi parol (kamida 6 belgi)", "new-password"), rep = fld("Yangi parolni qayta kiriting", "new-password");
    const msg = h("p", {class: "tg-hint flat", role: "alert"});
    const btn = h("button", {class: "btn", type: "button", text: "Parolni almashtirish"});
    const submit = async () => {
      msg.textContent = ""; msg.style.color = "";
      const fail = t => { msg.textContent = t; msg.style.color = "var(--err)"; };
      if (!old.i.value) return fail("Eski parolni kiriting");
      if (nw.i.value.length < 6) return fail("Yangi parol kamida 6 belgi bo'lishi kerak");
      if (nw.i.value !== rep.i.value) return fail("Yangi parollar bir-biriga mos kelmadi");
      if (nw.i.value === old.i.value) return fail("Yangi parol eskisidan farq qilishi kerak");
      btn.disabled = true; btn.textContent = "Almashtirilmoqda…";
      try {
        await changePassword(old.i.value, nw.i.value);
        toast("Parol almashtirildi. Boshqa qurilmalardan chiqarildingiz", "ok");
        closePage();
      } catch (err) { fail(err.message); btn.disabled = false; btn.textContent = "Parolni almashtirish"; }
    };
    btn.addEventListener("click", submit);
    [old, nw, rep].forEach(f => f.i.addEventListener("keydown", e => { if (e.key === "Enter") submit(); }));
    return h("div", {}, pageHead("Parolni almashtirish"),
      h("div", {class: "inf-form"}, old.lab, nw.lab, rep.lab, msg, btn),
      h("p", {class: "tg-hint", text: "Parol almashtirilganda shifrlash kalitlaringiz yangi parol bilan brauzerda qayta o'raladi, boshqa barcha qurilmalar akkauntdan chiqariladi."}));
  });
}

/* 2-bo'lim: akkauntga ulangan qurilmalar (sessiyalar) — qachon kirgan, qancha vaqt onlayn, chiqarib yuborish */
function openDevicesPage() {
  openPage(p => {
    const box = h("div", {class: "dev-list"}, h("div", {class: "none", text: "Yuklanmoqda…"}));
    const load = async () => {
      try {
        const j = await api("/sessions");
        box.textContent = "";
        const cur = j.sessions.find(s => s.current), others = j.sessions.filter(s => !s.current);
        const item = s => h("div", {class: "dev-i"},
          icon(/iPhone|iPad|Android/.test(s.device) ? "phone" : "devices"),
          h("div", {class: "dev-t"},
            h("b", {text: s.device + (s.current ? " (shu qurilma)" : "")}),
            h("small", {text: "Kirgan: " + fmtDay(s.created)}),
            h("small", {text: s.online ? "Hozir onlayn" : "Oxirgi faollik: " + ago(s.last_active)}),
            h("small", {text: "Onlayn bo'lgan vaqt: " + fmtSpan(s.duration)})),
          s.current ? null : h("button", {class: "btn ghost sm", type: "button", onclick: async ev => {
            if (!await confirmDlg(s.device + " qurilmasi akkauntdan chiqariladi.", {title: "Qurilmani chiqarish", okText: "Chiqarish", danger: true})) return;
            ev.target.disabled = true;
            try { await api("/sessions/" + s.id, {method: "DELETE"}); toast("Qurilma chiqarildi", "ok"); } catch (err) { toast(err.message, "error"); }
            load();
          }}, "Chiqarish"));
        if (cur) box.append(secTitle("Hozirgi qurilma"), item(cur));
        box.append(secTitle("Boshqa qurilmalar", others.length));
        if (!others.length) box.append(h("div", {class: "none", text: "Boshqa qurilmalar ulanmagan"}));
        others.forEach(s => box.append(item(s)));
        if (others.length) box.append(h("div", {class: "tg-modwrap"}, h("button", {class: "btn danger sm", type: "button", onclick: async () => {
          if (!await confirmDlg("Hozirgisidan boshqa barcha qurilmalar akkauntdan chiqariladi.", {title: "Boshqa qurilmalardan chiqish", okText: "Hammasini chiqarish", danger: true})) return;
          try { await api("/sessions/revoke-others", {method: "POST"}); toast("Boshqa qurilmalar chiqarildi", "ok"); } catch (err) { toast(err.message, "error"); }
          load();
        }}, "Boshqa barcha qurilmalardan chiqish")));
      } catch (err) { box.textContent = ""; box.append(h("div", {class: "none", text: err.message})); }
    };
    p.refresh = null;
    load();
    const timer = setInterval(() => { if (!p.el.isConnected || p.closing) clearInterval(timer); else load(); }, 30000);     // vaqtlar jonli yangilanadi
    return h("div", {}, pageHead("Ulangan qurilmalar"), box);
  });
}

function openReactionSettings() {
  openPage(() => {
    const mk = e => {
      const b = h("button", {class: "rx-opt" + (e === rxPrefs.emoji ? " on" : ""), type: "button", "aria-label": e}, rxGlyph(e));
      b.addEventListener("click", () => {
        rxPrefs.emoji = e; rxSave();
        pv.querySelectorAll(".rx-opt").forEach(x => x.classList.toggle("on", x === b));
        const r = b.getBoundingClientRect(); rxBurst(e, r.left + r.width / 2, r.top);
      });
      return b;
    };
    const pv = rxPackView(mk, {k: null}, "rx-grid");
    const grid = h("div", {class: "rx-gwrap" + (rxPrefs.dbl ? "" : " off")}, pv);
    return h("div", {}, pageHead("Reaksiya sozlamalari"),
      switchRow("emoji", "Ikki marta bosganda reaksiya", () => rxPrefs.dbl, on => { rxPrefs.dbl = on; rxSave(); grid.classList.toggle("off", !on); },
        "Xabar yoki post ustiga ketma-ket 2 marta bosilsa, pastdagi reaksiya qo'yiladi. O'chirilsa, reaksiyani xabar menyusidan tanlaysiz."),
      gapEl(),
      h("div", {class: "inf-form"}, h("div", {class: "sec-t flat"}, h("span", {text: "Ikki marta bosganda qo'yiladigan reaksiya"})), grid,
        h("p", {class: "tg-hint flat", text: "Bir xabarga bitta reaksiya qo'yiladi. Reaksiya ustiga bosib uni olib tashlash yoki almashtirish mumkin."})));
  });
}

/* Karnay va kamera: qurilmalar haqida ma'lumot, ruxsat berish / ruxsatni o'chirish */
const PERM_TXT = {granted: "Ruxsat berilgan", denied: "Bloklangan", prompt: "Hali so'ralmagan", unknown: "Noma'lum"};
async function permState(name) { try { return (await navigator.permissions.query({name})).state; } catch (_) { return "unknown"; } }
async function requestPerm(kind) {
  if (kind === "notifications") {
    if (!("Notification" in window)) throw new Error("Bu brauzer bildirishnomalarni qo'llab-quvvatlamaydi");
    const r = await Notification.requestPermission();
    if (r !== "granted") throw new Error("Ruxsat berilmadi");
    return;
  }
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) throw new Error("Bu brauzer kamera/mikrofonni qo'llab-quvvatlamaydi (yoki sahifa HTTPS emas)");
  try {
    const s = await navigator.mediaDevices.getUserMedia(kind === "camera" ? {video: true} : {audio: true});
    s.getTracks().forEach(t => t.stop());
  } catch (err) { throw new Error(err && err.name === "NotFoundError" ? "Bunday qurilma topilmadi" : "Ruxsat berilmadi. Brauzerning sayt sozlamalaridan ruxsat bering"); }
}
function openMediaPermPage() {
  openPage(() => {
    const perms = h("div", {}), devs = h("div", {});
    const defs = [["camera", "videocam", "Kamera", "camera"], ["microphone", "mic", "Mikrofon", "microphone"], ["notifications", "bell", "Bildirishnomalar", "notifications"]];
    const load = async () => {
      const rows = [];
      for (const [name, ic, label, kind] of defs) {
        const stt = await permState(name === "notifications" ? "notifications" : name);
        const granted = stt === "granted";
        rows.push(h("div", {class: "perm-i"}, icon(ic), h("div", {class: "perm-t"}, h("b", {text: label}), h("small", {class: "st-" + stt, text: PERM_TXT[stt] || PERM_TXT.unknown})),
          granted
            ? h("button", {class: "btn ghost sm", type: "button", onclick: () => confirmDlg("Brauzer ruxsatni sahifaning o'zidan olib tashlashga yo'l qo'ymaydi. Brauzerda: manzil satridagi qulf (yoki sozlamalar) belgisi → Sayt sozlamalari → «" + label + "» ni «Bloklash» yoki «So'rash» ga o'zgartiring.", {title: label + ": ruxsatni o'chirish", okText: "Tushunarli"})}, "O'chirish")
            : stt === "denied"
              ? h("button", {class: "btn ghost sm", type: "button", onclick: () => confirmDlg("Ruxsat brauzerda bloklangan. Qulf belgisi → Sayt sozlamalari → «" + label + "» ni «Ruxsat berish» ga o'zgartiring, so'ng sahifani yangilang.", {title: label + ": bloklangan", okText: "Tushunarli"})}, "Qanday?")
              : h("button", {class: "btn sm", type: "button", onclick: async () => { try { await requestPerm(kind); toast(label + ": ruxsat berildi", "ok"); } catch (err) { toast(err.message, "error"); } load(); }}, "Ruxsat berish")));
      }
      perms.textContent = ""; perms.append(...rows);
      devs.textContent = "";
      let list = [];
      try { list = navigator.mediaDevices && navigator.mediaDevices.enumerateDevices ? await navigator.mediaDevices.enumerateDevices() : []; } catch (_) {}
      const group = (kindName, ic, title) => {
        const items = list.filter(d => d.kind === kindName);
        devs.append(secTitle(title, items.length));
        if (!items.length) devs.append(h("div", {class: "perm-none", text: kindName === "audiooutput" ? "Brauzer karnaylar ro'yxatini ko'rsatmaydi (standart karnay ishlatiladi)" : "Qurilma topilmadi"}));
        items.forEach((d, i) => devs.append(h("div", {class: "tg-row"}, icon(ic), h("span", {text: d.label || (title.replace(/lar$/, "") + " " + (i + 1) + " (nomi ruxsatdan keyin ko'rinadi)")}))));
      };
      group("audioinput", "mic", "Mikrofonlar"); group("videoinput", "videocam", "Kameralar"); group("audiooutput", "speaker", "Karnaylar");
    };
    load();
    return h("div", {}, pageHead("Karnay va kamera"), secTitle("Ruxsatlar"), perms,
      h("p", {class: "tg-hint", text: "Kamera va mikrofon faqat ovozli yoki video xabar yozganingizda ishlatiladi."}), gapEl(), devs);
  });
}

async function deleteMyAccount() {
  const ok = await confirmDlg("Akkauntingiz butunlay o'chiriladi: profil, rasmlar va parol yo'qoladi. Yozgan xabarlaringiz chatda \"Deleted account\" nomi bilan qoladi. Buni qaytarib bo'lmaydi.",
    {title: "Akkauntni o'chirish", okText: "Davom etish", danger: true});
  if (!ok) return;
  const pw = await promptDlg("Parolni tasdiqlang", "Akkauntni o'chirish uchun parolingizni kiriting:", "", {type: "password", okText: "O'chirish", danger: true});
  if (pw === null) return;
  try {
    const e = (await api("/me")).e2ee, kd = await E2E.deriveFromPassword(S.me.username, pw, e.kdf_iter || E2E.KDF_DEFAULT);
    await api("/account/delete", {method: "POST", body: {password: kd.auth}}); showAuth("Akkauntingiz o'chirildi");
  }
  catch (err) { toast(err.message, "error"); }
}
const PRESETS = ["#f7b733", "#7b61ff", "#ef4444", "#f97316", "#22c55e", "#14b8a6", "#3b82f6", "#ec4899"];
function colorSection(onChange) {
  const sec = h("div", {class: onChange ? "bd-colors" : "setsec"}, onChange ? h("div", {class: "bd-lab", text: "Ism rangi"}) : h("h4", {text: "Profil rangi"}));
  const preview = onChange ? null : h("div", {class: "pname"}), sw = h("div", {class: "swatches"});
  if (preview) { preview.style.fontSize = "17px"; preview.style.margin = "0 0 10px"; }
  hScroll(sw);
  const save = async c => {
    try {
      const j = await api("/profile", {method: "PATCH", body: {color: c}});
      upsertUser(j.me); paint(); renderList(); renderHeader(); renderMessages(false);
      if (onChange) onChange();
      toast(c ? "Rang saqlandi" : "Standart rang tiklandi", "ok");
    } catch (err) { toast(err.message, "error"); }
  };
  const paint = () => {
    if (preview) { preview.textContent = ""; preview.append(nameEl(S.me, {big: true})); }
    sw.textContent = "";
    const cur = (S.me.color || "").toLowerCase();
    PRESETS.forEach(c => {
      const b = h("button", {type: "button", class: "sw" + (cur === c ? " on" : ""), title: c, "aria-label": c});
      b.style.background = c; b.addEventListener("click", () => save(c)); sw.append(b);
    });
    const pick = h("input", {type: "color"}); pick.value = HEX.test(cur) ? cur : TONES[S.me.role];
    pick.addEventListener("change", () => save(pick.value));
    sw.append(h("label", {class: "sw-custom", title: "Boshqa rang tanlash"}, pick),
      h("button", {type: "button", class: "btn ghost sm", text: "Standart", onclick: () => save("")}));
  };
  paint(); sec.append(...(preview ? [preview] : []), sw);
  return sec;
}
$("file").addEventListener("change", async () => {
  const f = $("file").files[0]; $("file").value = ""; if (!f) return;
  if (f.size > 2 * 1024 * 1024) { toast("Rasm 2 MB dan oshmasligi kerak", "error"); return; }
  const fd = new FormData(); fd.append("file", f);
  try { await api("/avatar", {method: "POST", body: fd}); toast("Profil rasmi yangilandi", "ok"); if (S.reloadGallery) S.reloadGallery(); }
  catch (err) { toast(err.message, "error"); }
});

