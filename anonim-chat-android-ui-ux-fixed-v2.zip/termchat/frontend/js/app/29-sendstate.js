/* ---------------- 29-sendstate.js: xabar yuborish bosqichlari (Telegramdagidek) ----------------
   Yuborilayotgan xabar darhol pufak bo'lib chiqadi, pastida vaqt va holat: «shifrlanmoqda…» → «yuborilmoqda…» → ✓.
   Server xabarni qaytargach (haqiqiy xabar) vaqtincha pufak olib tashlanadi va o'rniga haqiqiysi (✓ / ✓✓ bilan) chiqadi.
   Pufaklar faqat ekranda yashaydi (E2EE: ochiq matn xotirada ham, diskda ham saqlanmaydi). */
const Pend = {
  list: [],
  ACK_MS: 25000,                                          // server shuncha vaqt javob bermasa — «yuborilmadi»
  add(target, info) {
    const p = {key: chatKey(target), target, info, stage: "enc", el: null, meta: null, timer: 0, sentAt: 0, t0: Date.now()};
    p.el = Pend.build(p); Pend.list.push(p); Pend.mount(true); return p;
  },
  label(p) { return p.stage === "enc" ? "shifrlanmoqda…" : p.stage === "up" ? "yuborilmoqda…" : p.stage === "fail" ? "yuborilmadi" : ""; },
  build(p) {
    const i = p.info, row = h("div", {class: "row mine last pending" + (p.target.kind === "group" ? "" : " dm")});
    const img = i.kind === "file" && i.isImg && i.url, cap = i.kind === "file" ? (i.text || "") : "";
    const bubble = h("div", {class: "bubble pending" + (img ? " has-img" + (cap ? "" : " img-only") : "") + (i.kind === "file" && !img ? " has-file" : "")
      + (i.kind === "voice" ? " has-file has-voice" : "") + (i.kind === "vnote" ? " has-file has-vnote vn-only" : "")});
    if (i.kind === "text") bubble.append(btextEl("btext", i.text, true));
    else if (img) {                                       // yakuniy xabardagi bilan BIR XIL quti (imgbox): o'lcham sakramaydi; holat faqat pastdagi kapsulada
      const pic = h("img", {alt: "", draggable: "false", decoding: "async"}), box = h("div", {class: "imgbox open pnd-imgbox"}, pic);
      box.style.aspectRatio = "1.333";
      pic.addEventListener("load", () => { if (pic.naturalWidth && pic.naturalHeight) box.style.aspectRatio = String(Math.min(2.4, Math.max(0.8, pic.naturalWidth / pic.naturalHeight))); });
      pic.src = i.url;
      bubble.append(box);
      if (cap) bubble.append(btextEl("btext", cap, true));
    } else if (i.kind === "file") {                       // fayl kartasi: belgi + nom + hajm
      bubble.append(h("div", {class: "pnd-filebox"}, h("span", {class: "pnd-fico"}, h("span", {class: "pnd-ring sm", "aria-hidden": "true"})),
        h("div", {class: "pnd-finfo"}, h("b", {text: i.name || "Fayl"}), h("small", {text: i.size ? fmtSize(i.size) : ""}))));
      if (cap) bubble.append(btextEl("btext", cap, true));
    } else if (i.kind === "voice") {                      // yakuniy ovozli karta bilan bir xil: play tugmasi (spinner bilan), chiziq, davomiylik
      const d = Math.max(0, Math.round(i.dur || 0));
      bubble.append(h("div", {class: "vbox loading pnd-vbox"},
        h("span", {class: "vplay", "aria-hidden": "true"}, icon("play", "ic vi-play"), spinnerEl()),
        h("div", {class: "vmid"}, h("div", {class: "vtrack"}, h("div", {class: "vline"}, h("div", {class: "vfill"}))),
          h("div", {class: "vmeta"}, h("span", {class: "vtime", text: fmtDur(d)})))));
    } else {                                              // dumaloq video: yakuniy xabardagi dumaloq quti (kadr bo'lsa o'sha ko'rinadi)
      const vc = h("div", {class: "vnc"});
      if (i.thumb) vc.append(h("img", {class: "vnth", src: i.thumb, alt: "", draggable: "false"}));
      bubble.append(h("div", {class: "vnbox pnd-vnbox"}, vc));
    }
    p.meta = h("span", {class: "meta pnd-meta"});
    bubble.append(p.meta);
    row.append(h("div", {class: "slot"}), bubble);
    p.el = row; Pend.paint(p);
    return row;
  },
  paint(p) {
    if (!p.meta) return;
    p.meta.textContent = "";
    p.el.classList.toggle("failed", p.stage === "fail");
    p.meta.append(h("span", {class: "lk ok", text: "🔒"}), " ", hhmm(Math.floor((p.t0 || (p.t0 = Date.now())) / 1000)), " ");
    if (p.stage === "sent") p.meta.append(icon("check", "ic pnd-ok"));            // yuborildi, server tasdig'i kutilmoqda
    else p.meta.append(h("span", {class: "pnd-lbl" + (p.stage === "fail" ? " err" : "")}, p.stage === "fail" ? "⚠ " : h("i", {class: "pnd-spin", "aria-hidden": "true"}), Pend.label(p)));
  },
  stage(p, st) { if (!p || p.stage === "fail") return; p.stage = st; Pend.paint(p); },
  sent(p) {
    if (!p) return;
    p.stage = "sent"; p.sentAt = Date.now(); Pend.paint(p);
    p.timer = setTimeout(() => { if (Pend.list.includes(p)) Pend.fail(p); }, Pend.ACK_MS);
  },
  fail(p) {
    if (!p) return;
    clearTimeout(p.timer); p.stage = "fail"; Pend.paint(p);
    p.timer = setTimeout(() => Pend.drop(p), 7000);
  },
  drop(p) {
    clearTimeout(p.timer);
    if (p.info && p.info.url) { try { URL.revokeObjectURL(p.info.url); } catch (_) {} }
    const i = Pend.list.indexOf(p); if (i >= 0) Pend.list.splice(i, 1);
    if (p.el) p.el.remove();
  },
  mount(stick) {                                          // chat qayta chizilganda ham pufaklar pastda, tartibda qoladi
    if (!S.active) return;
    const k = chatKey(S.active), mine = Pend.list.filter(p => p.key === k);
    if (!mine.length) return;
    const box = $("msgs"), blank = box.querySelector(".blank"); if (blank) blank.remove();
    mine.forEach(p => box.append(p.el));
    if (stick || box._stick) { box.scrollTop = box.scrollHeight; box._stick = true; }
  },
  settle(m) {                                             // o'z xabarimiz serverdan qaytdi: eng eski «yuborildi» pufagi almashadi
    if (m.ch) return;
    const k = m.to == null ? "g" : "d" + partnerOf(m);
    const isFile = !!(m.file || m.image), same = x => x.key === k && (x.info.kind === "text") === !isFile;      // fayl xabari — fayl pufagini, matn — matn pufagini almashtiradi
    const p = Pend.list.find(x => same(x) && x.stage === "sent") || Pend.list.find(x => same(x) && x.stage !== "fail") || Pend.list.find(x => x.key === k && x.stage === "sent");
    if (p) Pend.drop(p);
  },
  clear() { Pend.list.slice().forEach(Pend.drop); },
};
