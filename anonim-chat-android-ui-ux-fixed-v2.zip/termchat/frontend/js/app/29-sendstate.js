/* ---------------- 29-sendstate.js: xabar yuborish bosqichlari (Telegramdagidek) ----------------
   Yuborilayotgan xabar darhol pufak bo'lib chiqadi, pastida vaqt va holat: «shifrlanmoqda…» → «yuborilmoqda…» → ✓.
   Server xabarni qaytargach (haqiqiy xabar) vaqtincha pufak olib tashlanadi va o'rniga haqiqiysi (✓ / ✓✓ bilan) chiqadi.
   Pufaklar faqat ekranda yashaydi (E2EE: ochiq matn xotirada ham, diskda ham saqlanmaydi). */
const Pend = {
  list: [],
  ACK_MS: 15000,                                          // server shuncha vaqt javob bermasa — xabar qayta yuboriladi (server takrorni o'tkazmaydi); xato HECH QACHON ko'rsatilmaydi
  MAKE_MS: 60000,                                         // fayl yuklash shuncha vaqtda tugamasa — keyingi urinishga o'tadi
  q: Promise.resolve(), tick: 0,
  add(target, info) {
    const p = {key: chatKey(target), target, info, stage: "enc", el: null, meta: null, timer: 0, sentAt: 0, t0: Date.now(), cid: Pend.rid(), gen: 0, busy: false, msg: null, make: null};
    p.el = Pend.build(p); Pend.list.push(p); Pend.mount(true); return p;
  },
  rid() { const a = new Uint8Array(12); crypto.getRandomValues(a); return Array.from(a, b => b.toString(16).padStart(2, "0")).join(""); },
  label(p) { return p.stage === "enc" ? "shifrlanmoqda…" : p.stage === "up" ? "yuborilmoqda…" : p.stage === "wait" ? "kutilmoqda…" : ""; },
  build(p) {
    const i = p.info, row = h("div", {class: "row mine last pending" + (p.target.kind === "group" ? "" : " dm")});
    const img = i.kind === "file" && i.isImg && i.url, cap = i.kind === "file" ? (i.text || "") : "";
    const bubble = h("div", {class: "bubble pending" + (img ? " has-img" + (cap ? "" : " img-only") : "") + (i.kind === "file" && !img ? " has-file" : "")
      + (i.kind === "voice" ? " has-file has-voice" : "") + (i.kind === "vnote" ? " has-file has-vnote vn-only" : "")});
    if (i.kind === "text") bubble.append(btextEl("btext", i.text, true));
    else if (img) {                                       // yakuniy xabardagi bilan BIR XIL quti (imgbox): o'lcham sakramaydi; holat faqat pastdagi kapsulada
      const pic = h("img", {alt: "", draggable: "false", decoding: "async"}), box = h("div", {class: "imgbox open pnd-imgbox"}, pic);
      box.style.aspectRatio = "1.333";
      pic.addEventListener("load", () => { if (pic.naturalWidth && pic.naturalHeight) box.style.aspectRatio = String(Math.min(2.4, Math.max(0.8, pic.naturalWidth / pic.naturalHeight))); });
      pic.src = i.url;
      bubble.append(box);
      if (cap) bubble.append(btextEl("btext", cap, true));
    } else if (i.kind === "file") {                       // fayl kartasi: belgi + nom + hajm
      bubble.append(h("div", {class: "pnd-filebox"}, h("span", {class: "pnd-fico"}, h("span", {class: "pnd-ring sm", "aria-hidden": "true"})),
        h("div", {class: "pnd-finfo"}, h("b", {text: i.name || "Fayl"}), h("small", {text: i.size ? fmtSize(i.size) : ""}))));
      if (cap) bubble.append(btextEl("btext", cap, true));
    } else if (i.kind === "voice") {                      // yakuniy ovozli karta bilan bir xil: play tugmasi (spinner bilan), chiziq, davomiylik
      const d = Math.max(0, Math.round(i.dur || 0));
      bubble.append(h("div", {class: "vbox loading pnd-vbox"},
        h("span", {class: "vplay", "aria-hidden": "true"}, icon("play", "ic vi-play"), spinnerEl()),
        h("div", {class: "vmid"}, h("div", {class: "vtrack"}, h("div", {class: "vline"}, h("div", {class: "vfill"}))),
          h("div", {class: "vmeta"}, h("span", {class: "vtime", text: fmtDur(d)})))));
    } else {                                              // dumaloq video: yakuniy xabardagi dumaloq quti (kadr bo'lsa o'sha ko'rinadi)
      const vc = h("div", {class: "vnc"});
      if (i.thumb) vc.append(h("img", {class: "vnth", src: i.thumb, alt: "", draggable: "false"}));
      bubble.append(h("div", {class: "vnbox pnd-vnbox"}, vc));
    }
    p.meta = h("span", {class: "meta pnd-meta"});
    bubble.append(p.meta);
    row.append(h("div", {class: "slot"}), bubble);
    p.el = row; Pend.paint(p);
    return row;
  },
  paint(p) {
    if (!p.meta) return;
    p.meta.textContent = "";
    p.meta.append(h("span", {class: "lk ok", text: "🔒"}), " ", hhmm(Math.floor((p.t0 || (p.t0 = Date.now())) / 1000)), " ");
    if (p.stage === "sent") p.meta.append(icon("check", "ic pnd-ok"));            // yuborildi, server tasdig'i kutilmoqda
    else p.meta.append(h("span", {class: "pnd-lbl"}, h("i", {class: "pnd-spin", "aria-hidden": "true"}), Pend.label(p)));
  },
  stage(p, st) { if (!p) return; p.stage = st; Pend.paint(p); },
  sent(p) {
    if (!p) return;
    clearTimeout(p.timer); p.stage = "sent"; p.sentAt = Date.now(); Pend.paint(p);
    p.timer = setTimeout(() => { if (Pend.list.includes(p) && p.stage === "sent") Pend.wait(p); }, Pend.ACK_MS);      // javob kelmadi: qayta yuboriladi (xato emas)
  },
  wait(p) {                                               // internet yo'q/past: xabar navbatda «kutilmoqda…», ulanish bo'lishi bilan o'zi ketadi
    if (!p || !Pend.list.includes(p)) return;
    clearTimeout(p.timer); p.stage = "wait"; Pend.paint(p); Pend.ticker();
  },
  fail(p) { Pend.wait(p); },                              // eski nom: endi hech qachon «yuborilmadi» chiqmaydi
  ticker() { if (!Pend.tick) Pend.tick = setInterval(() => { if (!Pend.list.length) { clearInterval(Pend.tick); Pend.tick = 0; } else Pend.flush(); }, 3000); },
  go(p, make) { p.make = make; Pend.ticker(); return Pend.enqueue(p); },
  enqueue(p) { Pend.q = Pend.q.then(() => Pend.pump(p)).catch(() => {}); return Pend.q; },
  async pump(p) {                                         // bitta xabarni yuboradi; shifrlangan paket (p.msg) saqlanadi — qayta urinish AYNAN shu paketni yuboradi
    if (!Pend.list.includes(p) || p.busy || (p.stage === "sent")) return;
    p.busy = true; const g = ++p.gen;
    try {
      if (!p.msg) {
        Pend.stage(p, "up");
        let tm = 0;
        const msg = await Promise.race([p.make(p), new Promise((_, rej) => { tm = setTimeout(() => rej(new Error("timeout")), Pend.MAKE_MS); })]).finally(() => clearTimeout(tm));
        if (g !== p.gen || !Pend.list.includes(p)) { p.busy = false; return; }
        p.msg = msg;
      }
      if (!wsTry(p.msg)) throw new Error("offline");
      Pend.sent(p);
    } catch (err) {
      if (err && err.final) { toast(err.message, "error"); Pend.drop(p); }      // faqat internetga bog'liq bo'lmagan holat (masalan, fayl juda katta)
      else Pend.wait(p);
    }
    p.busy = false;
  },
  async flush() {                                         // ulanish tiklanganda yoki har 3 soniyada: kutayotganlar TARTIB bilan yuboriladi
    if (S.offline || !S.ws || S.ws.readyState !== 1) return;
    for (const p of Pend.list.slice()) { if (p.stage === "wait" && !p.busy) await Pend.enqueue(p); if (p.stage === "wait") break; }
  },
  onClose() { Pend.list.forEach(p => { if (p.stage === "sent") Pend.wait(p); }); },     // ulanish uzildi: tasdiq kelmaganlar qayta yuboriladi
  nack(m) {                                               // server paketni rad etdi
    const p = Pend.list.find(x => x.cid === m.cid); if (!p) return;
    if (m.final) Pend.drop(p);                           // qoida bo'yicha (mute, qulf...): sababi serverdan alohida xabar bilan keladi
    else Pend.wait(p);                                   // vaqtinchalik server xatosi: keyinroq o'zi qayta urinadi
  },
  drop(p) {
    clearTimeout(p.timer); p.gen++;
    if (p.info && p.info.url) { try { URL.revokeObjectURL(p.info.url); } catch (_) {} }
    const i = Pend.list.indexOf(p); if (i >= 0) Pend.list.splice(i, 1);
    if (p.el) p.el.remove();
  },
  mount(stick) {                                          // chat qayta chizilganda ham pufaklar pastda, tartibda qoladi
    if (!S.active) return;
    const k = chatKey(S.active), mine = Pend.list.filter(p => p.key === k);
    if (!mine.length) return;
    const box = $("msgs"), blank = box.querySelector(".blank"); if (blank) blank.remove();
    mine.forEach(p => box.append(p.el));
    if (stick || box._stick) { box.scrollTop = box.scrollHeight; box._stick = true; }
  },
  settle(m) {                                             // o'z xabarimiz serverdan qaytdi: eng eski «yuborildi» pufagi almashadi
    if (m.ch) return;
    const k = m.to == null ? "g" : "d" + partnerOf(m);
    const isFile = !!(m.file || m.image), same = x => x.key === k && (x.info.kind === "text") === !isFile;      // fayl xabari — fayl pufagini, matn — matn pufagini almashtiradi
    const p = (m.cid && Pend.list.find(x => x.cid === m.cid)) || Pend.list.find(x => same(x) && x.stage === "sent") || Pend.list.find(x => same(x) && x.stage === "wait") || Pend.list.find(x => same(x)) || Pend.list.find(x => x.key === k && x.stage === "sent");
    if (p) Pend.drop(p);
  },
  clear() { Pend.list.slice().forEach(Pend.drop); clearInterval(Pend.tick); Pend.tick = 0; },
};
async function uploadEnc(blob, failText) {               // shifrlangan faylni yuklaydi; tarmoq xatosi — qayta uriniladi, 4xx (fayl katta va h.k.) — yakuniy
  const r = await SC.fetch("/api/e2ee/blob", {method: "POST", headers: {Authorization: "Bearer " + S.token, "Content-Type": "application/octet-stream"}, body: blob});
  const j = await r.json().catch(() => ({}));
  if (!r.ok) { const e = new Error(typeof j.detail === "string" ? j.detail : failText); e.final = r.status >= 400 && r.status < 500 && ![401, 408, 409, 423, 425, 429].includes(r.status); throw e; }
  return j.blob;
}
addEventListener("online", () => { if (Pend.list.length) { reconnectNow(); setTimeout(() => Pend.flush(), 400); } });
document.addEventListener("visibilitychange", () => { if (!document.hidden && Pend.list.length) { if (!S.ws || S.ws.readyState !== 1) reconnectNow(); Pend.flush(); } });
