/* ---------------- Ovozli xabar va dumaloq video: yozish -> (ovozni o'zgartirish) -> shifrlash -> yuborish ----------------
   Mikrofon tugmasi (Telegram kabi):
     bir marta bosish — rejim almashadi (🎤 ovoz <-> 📹 dumaloq video);
     bosib turish — yozish; qo'yib yuborish — yuborish; chapga surish — bekor qilish; yuqoriga surish — qulflash (qo'lsiz yozish).
   Qulflangan yozuvda tugma = yuborish, 🗑 = bekor qilish. Esc ham bekor qiladi. Videoda doirani bosish (yoki 🔄) — old/orqa kamera.
   Xom ovoz (ovozli xabarda ham, videodagi ovozda ham) faqat shu qurilma xotirasida, darhol o'zgartiriladi;
   serverga FAQAT o'zgargan va E2EE bilan shifrlangan fayl boradi. */
const HOLD_MS = 260, CANCEL_DX = 90, LOCK_DY = 70;
const micEl = $("micBtn");
const vibrate = ms => { try { if (navigator.vibrate) navigator.vibrate(ms); } catch (_) {} };
try { S.recMode = localStorage.getItem("tc_recmode") === "video" ? "video" : "voice"; } catch (_) {}
function applyRecMode() {
  const v = S.recMode === "video";
  $("composer").classList.toggle("mode-video", v);
  micEl.setAttribute("aria-label", v ? "Dumaloq video xabar" : "Ovozli xabar");
  micEl.title = v ? "Dumaloq video: bosib turing — yozish, qo'yib yuboring — yuborish. Bir marta bosing — ovozga qaytadi"
                  : "Ovozli xabar: bosib turing — yozish, qo'yib yuboring — yuborish. Bir marta bosing — videoga o'tadi";
}
function toggleRecMode() {
  S.recMode = S.recMode === "video" ? "voice" : "video";
  try { localStorage.setItem("tc_recmode", S.recMode); } catch (_) {}
  applyRecMode(); vibrate(10);
  toast(S.recMode === "video" ? "📹 Dumaloq video — yozish uchun tugmani bosib turing" : "🎤 Ovozli xabar — yozish uchun tugmani bosib turing", "info");
}
applyRecMode();

function resetDragUi() { $("recLock").style.transform = ""; $("recbar").style.transform = ""; $("composer").classList.remove("rec-near-cancel", "rec-near-lock"); }
function showVnUi(on, hint) {                                          // jonli dumaloq ko'rinish: xabarlar maydoni ustida
  const ov = $("vnov");
  if (!on) { ov.classList.add("hidden"); ov.setAttribute("aria-hidden", "true"); return; }
  const r = $("msgs").getBoundingClientRect();
  Object.assign(ov.style, {left: r.left + "px", top: r.top + "px", width: r.width + "px", height: r.height + "px"});
  ov.style.setProperty("--vnd", Math.round(Math.max(140, Math.min(340, r.width * 0.8, r.height - 96))) + "px");
  $("vnHint").textContent = hint || "";
  ov.classList.remove("hidden"); ov.setAttribute("aria-hidden", "false");
}
function setRecUi(mode) {                                              // "off" | "hold" (bosib turilgan) | "lock" (qulflangan) | "busy"
  const c = $("composer"), vid = S.recKind === "video", on = mode !== "off";
  c.classList.toggle("recording", on); c.classList.toggle("rec-hold", mode === "hold");
  c.classList.toggle("rec-lock", mode === "lock" || mode === "busy"); c.classList.toggle("rec-busy", mode === "busy");
  c.classList.toggle("rec-video", on && vid);
  micEl.classList.toggle("on", mode === "hold" || mode === "lock"); micEl.disabled = mode === "busy"; $("recCancel").disabled = mode === "busy";
  micEl.setAttribute("aria-label", mode === "lock" ? "Yuborish" : mode === "off" ? (S.recMode === "video" ? "Dumaloq video xabar" : "Ovozli xabar") : "Yozilmoqda");
  $("recLbl").textContent = mode === "hold" ? "‹ Bekor qilish uchun chapga suring" : mode === "busy" ? (vid ? "Video tayyorlanmoqda…" : "Ovoz tayyorlanmoqda…")
    : mode === "lock" ? (vid ? "Video shifrlanib yuboriladi" : "Ovoz o'zgartirilib shifrlanadi") : "";
  if (mode === "hold" || mode === "lock") { if (!S.recTyping) S.recTyping = Typing.hold(vid ? "vnote" : "voice"); }      // suhbatdoshga "ovozli xabar / dumaloq video yozmoqda…"
  else if (S.recTyping) { S.recTyping(); S.recTyping = null; }
  if (mode !== "hold") resetDragUi();
  if (mode === "off") { $("recTime").textContent = "0:00"; $("vnProg").setAttribute("stroke-dashoffset", "301.6"); }
  showVnUi(vid && (mode === "hold" || mode === "lock"), mode === "hold" ? "↑ qulflash   ← bekor qilish" : mode === "lock" && S.rec && S.rec.canFlip ? "Doirani bosing — old/orqa kamera" : "");
}
function cancelRecording() {
  if (S.starting) S.startAbort = true;                                 // kamera/mikrofon hali ochilmoqda: ochilgach bekor qilinadi
  if (!S.rec || S.recBusy) return;
  const r = S.rec; S.rec = null; clearInterval(S.recTimer);
  Promise.resolve(r.cancel()).catch(() => {}); setRecUi("off");
}
function tickRec() {
  const r = S.rec; if (!r) return;
  const t = r.elapsed(); $("recTime").textContent = fmtDur(t);
  if (S.recKind === "video") $("vnProg").setAttribute("stroke-dashoffset", String(301.6 * (1 - Math.min(1, t / VNote.MAX_SEC))));
}
async function startRecording(kind) {                                  // true: yozuv boshlandi (S.rec o'rnatildi; ko'rinishni chaqiruvchi o'rnatadi)
  if (S.rec || S.recBusy || S.sending || S.starting || !S.active) return false;
  if (S.editing || S.pendingImg || inp.value.trim()) return false;
  if (S.active.kind === "group" && S.chat.locked && !amAdmin()) { toast("Umumiy chat qulflangan", "error"); return false; }
  if (S.active.kind === "dm" && U(S.active.uid).deleted) { toast("Bu akkaunt o'chirilgan. Xabar yuborib bo'lmaydi", "error"); return false; }
  const at = S.active, video = kind === "video"; let rec = null;
  S.starting = true; S.startAbort = false; S.recKind = kind;
  if (video) { $("vnov").classList.add("front"); $("vnov").classList.remove("can-flip"); showVnUi(true, "Kamera ochilmoqda…"); }
  try {
    const cb = {
      onLimit: () => { toast(video ? "Video 1 daqiqaga yetdi, yuborilmoqda" : "Yozuv " + Math.round(Voice.MAX_SEC / 60) + " daqiqaga yetdi, yuborilmoqda", "warn"); finishRecording(); },
      onLost: () => { if (rec && S.rec === rec) { cancelRecording(); toast(video ? "Kamera yoki mikrofon uzildi, yozuv bekor qilindi" : "Mikrofon uzildi, yozuv bekor qilindi", "error"); } },
    };
    rec = video ? await VNote.record(Object.assign({facing: S.vfacing, preview: $("vnPrev")}, cb)) : await Voice.record(cb);
    if (S.startAbort || S.active !== at) { Promise.resolve(rec.cancel()).catch(() => {}); rec = null; showVnUi(false); return false; }   // ruxsat so'ralayotganda bekor qilindi / chat almashtirildi
    S.rec = rec;
    if (video) { $("vnov").classList.toggle("front", rec.facing() === "user"); $("vnov").classList.toggle("can-flip", !!rec.canFlip); }
    S.recTimer = setInterval(tickRec, video ? 100 : 250);
    vibrate(20);
    return true;
  } catch (err) { showVnUi(false); toast(err.message || (video ? "Kamerani ochib bo'lmadi" : "Mikrofonni ochib bo'lmadi"), "error"); return false; }
  finally { S.starting = false; }
}
async function flipCamera() {                                          // yozuv to'xtamasdan old <-> orqa kamera
  const r = S.rec;
  if (!r || S.recKind !== "video" || S.recBusy || S.flipping || !r.canFlip) return;
  S.flipping = true; const st = $("vnStage"); st.classList.add("flipping");
  try {
    const ok = await r.flip();
    if (S.rec !== r) return;
    $("vnov").classList.toggle("front", r.facing() === "user"); S.vfacing = r.facing() === "environment" ? "environment" : "user";
    if (!ok) toast("Kamerani almashtirib bo'lmadi", "warn");
  } finally { st.classList.remove("flipping"); S.flipping = false; }
}
$("vnStage").addEventListener("click", flipCamera);                    // 🔄 tugma ham shu yerga ko'tariladi

async function sendEncryptedFile(ctx, target, e, f, failText, pend) {   // fayl allaqachon shifrlangan (e), xabar konverti ham shifrlanadi
  Pend.stage(pend, "up");
  const r = await SC.fetch("/api/e2ee/blob", {method: "POST", headers: {Authorization: "Bearer " + S.token, "Content-Type": "application/octet-stream"}, body: e.blob});
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(typeof j.detail === "string" ? j.detail : failText);
  const payload = {t: "", f}; if (S.replying) payload.r = S.replying;
  const msg = {type: "send", e2e: await sealFor(ctx, payload), blob: j.blob};
  withTarget(msg, target);
  if (!wsSend(msg)) throw new Error("Ulanish yo'q");
  Pend.sent(pend);
  cancelReply();
}
async function sendVoice(wav, dur) {
  const ctx = await keyForActive(), target = S.active, pend = Pend.add(target, {kind: "voice", size: wav.size, dur});
  try {
    const e = await E2E.encryptFile(new Uint8Array(await wav.arrayBuffer()));
    await sendEncryptedFile(ctx, target, e, {name: "ovozli-xabar.wav", mime: "audio/wav", size: wav.size, img: false, k: e.key, vo: 1, d: Math.round(dur * 10) / 10}, "Ovoz yuklanmadi", pend);
  } catch (err) { Pend.fail(pend); throw err; }
}
async function sendVideoNote(out, wav, dur) {                          // paket: [ovozsiz video] + [o'zgartirilgan ovoz] -> BITTA E2EE fayl
  const ctx = await keyForActive(), target = S.active, pend = Pend.add(target, {kind: "vnote", thumb: out.thumb && THUMB_RE.test(out.thumb) ? out.thumb : null});
  try {
    const packed = VNote.pack(new Uint8Array(await out.video.arrayBuffer()), wav ? new Uint8Array(await wav.arrayBuffer()) : null);
    const e = await E2E.encryptFile(packed);
    const f = {name: "video-xabar.vn", mime: out.mime, size: packed.length, img: false, k: e.key, rv: 1, d: Math.round(dur * 10) / 10};
    if (out.thumb && THUMB_RE.test(out.thumb)) f.th = out.thumb;
    $("recLbl").textContent = "Shifrlanib yuborilmoqda…";
    await sendEncryptedFile(ctx, target, e, f, "Video yuklanmadi", pend);
  } catch (err) { Pend.fail(pend); throw err; }
}
async function finishRecording() {
  const rec = S.rec; if (!rec || S.recBusy) return;
  const kind = S.recKind;
  S.recBusy = true; S.sending = true; clearInterval(S.recTimer); setRecUi("busy");
  const at = S.active;
  try {
    if (kind === "video") {
      const out = await rec.stop();
      if (!out) throw new Error("Yozuv olinmadi");
      if (out.duration < VNote.MIN_SEC) { toast("Video juda qisqa — yuborilmadi", "warn"); return; }
      let wav = null, dur = out.duration;
      if (out.audio) {
        const d = await Voice.disguise(out.audio);                     // asl ovoz shu yerda o'zgaradi
        out.audio = null;
        if (!d) { toast("Video juda qisqa — yuborilmadi", "warn"); return; }
        wav = d.wav; dur = d.duration;
      }
      if (S.active !== at) { toast("Chat almashtirildi — video xabar yuborilmadi", "warn"); return; }
      await sendVideoNote(out, wav, dur);
    } else {
      const raw = await rec.stop();
      if (!raw) throw new Error("Yozuv olinmadi");
      const out = await Voice.disguise(raw);                           // asl ovoz shu yerda o'zgaradi
      if (!out) { toast("Ovoz juda qisqa — yuborilmadi", "warn"); return; }
      if (S.active !== at) { toast("Chat almashtirildi — ovozli xabar yuborilmadi", "warn"); return; }
      await sendVoice(out.wav, out.duration);
    }
  } catch (err) { toast(err.message || (kind === "video" ? "Video xabar yuborilmadi" : "Ovozli xabar yuborilmadi"), "error"); }
  finally { S.rec = null; S.recBusy = false; S.sending = false; setRecUi("off"); syncSend(); }
}

/* --- bosish ishorasi (pointer): tap = rejim, bosib turish = yozish, surish = bekor/qulf --- */
let G = null;
const noClick = () => { S.noClickUntil = Date.now() + 350; };          // bosib turgandan keyin brauzer yuboradigan "click" e'tiborsiz qoladi
async function beginHold(g) {
  if (G !== g || g.aborted) return;
  g.started = true;
  const t0 = performance.now();
  const ok = await startRecording(S.recMode);
  if (!ok) { if (G === g) G = null; return; }
  if (g.released || g.cancelled) {                                     // tugma kamera/mikrofon ruxsati so'ralayotganda qo'yib yuborilgan
    cancelRecording();
    if (performance.now() - t0 > 700) toast("Ruxsat berildi. Endi tugmani bosib turing", "ok");
    return;
  }
  setRecUi(g.locked || performance.now() - t0 > 700 ? "lock" : "hold");   // ruxsat oynasi chiqqan bo'lsa barmoq holati ishonchsiz: qo'lsiz (qulflangan) rejim
}
function endPress(e, cancel) {
  const g = G; if (!g || e.pointerId !== g.id) return;
  G = null; clearTimeout(g.timer); g.timer = 0;
  try { micEl.releasePointerCapture(g.id); } catch (_) {}
  noClick();
  if (!g.started) { if (!g.aborted && !cancel) toggleRecMode(); return; }
  g.released = true;
  if (g.cancelled || g.locked) return;
  if (S.rec && !S.recBusy) {
    if (cancel) cancelRecording();
    else if (S.rec.elapsed() < 0.5) { cancelRecording(); toast("Yozish uchun tugmani bosib turing", "warn"); }
    else finishRecording();
  }
}
micEl.addEventListener("pointerdown", e => {
  if (G && !S.starting && !S.rec) G = null;                            // yo'qolgan eski ishora (pointerup kelmagan) — yangisi boshlanadi
  if ((e.pointerType === "mouse" && e.button !== 0) || G || S.recBusy || S.rec || S.starting) return;   // qulflangan yozuvda tugma "yuborish" (click)
  const g = G = {id: e.pointerId, x0: e.clientX, y0: e.clientY, started: false, released: false, locked: false, cancelled: false, aborted: false, timer: 0};
  try { micEl.setPointerCapture(e.pointerId); } catch (_) {}
  g.timer = setTimeout(() => { g.timer = 0; beginHold(g); }, HOLD_MS);
});
micEl.addEventListener("pointermove", e => {
  const g = G; if (!g || e.pointerId !== g.id) return;
  const dx = e.clientX - g.x0, dy = e.clientY - g.y0;
  if (!g.started) { if (g.timer && Math.hypot(dx, dy) > 16) { clearTimeout(g.timer); g.timer = 0; g.aborted = true; } return; }
  if (!S.rec || S.recBusy || g.locked || g.cancelled) return;
  const c = $("composer");
  c.classList.toggle("rec-near-cancel", dx < -CANCEL_DX * 0.6); c.classList.toggle("rec-near-lock", dy < -LOCK_DY * 0.6);
  $("recbar").style.transform = "translateX(" + Math.max(-110, Math.min(0, dx * 0.7)) + "px)";
  $("recLock").style.transform = "translateY(" + Math.max(-30, Math.min(0, dy * 0.45)) + "px)";
  if (dx < -CANCEL_DX) { g.cancelled = true; vibrate(15); cancelRecording(); }
  else if (dy < -LOCK_DY) { g.locked = true; vibrate(20); setRecUi("lock"); }
});
micEl.addEventListener("pointerup", e => endPress(e, false));
micEl.addEventListener("pointercancel", e => endPress(e, true));
micEl.addEventListener("lostpointercapture", e => endPress(e, true));
micEl.addEventListener("contextmenu", e => e.preventDefault());        // telefonda uzoq bosganda menyu chiqmasin
micEl.addEventListener("click", e => {
  if (Date.now() < S.noClickUntil) return;
  if (S.rec) { if (!S.recBusy) finishRecording(); return; }            // qulflangan yozuv: tugma = yuborish
  if (e.detail === 0 && !S.starting) startRecording(S.recMode).then(ok => { if (ok) setRecUi("lock"); });   // klaviatura: qulflangan yozuv boshlanadi
});
micEl.addEventListener("keydown", e => { if (!S.rec && (e.key === "ArrowLeft" || e.key === "ArrowRight")) { e.preventDefault(); toggleRecMode(); } });   // klaviatura: rejim almashtirish
$("recCancel").addEventListener("click", cancelRecording);
document.addEventListener("keydown", e => { if (e.key === "Escape" && S.rec && !S.recBusy) { e.preventDefault(); e.stopPropagation(); cancelRecording(); } }, true);
document.addEventListener("visibilitychange", () => { if (document.hidden && S.rec && !S.recBusy) { cancelRecording(); toast("Ilovadan chiqilgani uchun yozuv bekor qilindi", "warn"); } });
addEventListener("pagehide", cancelRecording);
document.addEventListener("visibilitychange", () => {
  if (!document.hidden && S.active && S.active.kind === "dm") {
    const dm = dmOf(S.active.uid);
    if (dm.unread) { dm.unread = 0; wsSend({type: "read", with: S.active.uid}); renderList(); }
  }
});


