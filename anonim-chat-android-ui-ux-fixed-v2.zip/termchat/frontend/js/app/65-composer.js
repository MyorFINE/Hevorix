(() => {
  const el = $("inp");
  if (!el || el.tagName === "TEXTAREA") return;
  let plain = true;
  try { el.contentEditable = "plaintext-only"; plain = el.contentEditable === "plaintext-only"; } catch (_) { plain = false; }
  if (!plain) el.contentEditable = "true";
  let max = parseInt(el.getAttribute("data-maxlength") || "3000", 10) || 3000, composing = false, last = null;

  const ser = (node, top = true) => {
    let out = "";
    for (let n = node.firstChild; n; n = n.nextSibling) {
      if (n.nodeType === 3) out += n.nodeValue.replace(/\u00a0/g, " ");
      else if (n.nodeType === 1) {
        if (n.nodeName === "IMG") out += n.dataset.t || n.alt || "";
        else if (n.nodeName === "BR") { if (n.nextSibling || !top) out += "\n"; }
        else {
          if (/^(DIV|P|LI)$/.test(n.nodeName) && out && !out.endsWith("\n")) out += "\n";
          out += ser(n, false);
        }
      }
    }
    return out;
  };
  const emojiImg = token => {
    const i = Rich.chatEmoji(token, false);
    i.className = "ce ci"; i.title = ""; i.dataset.t = token; i.contentEditable = "false"; i.draggable = false;
    return i;
  };
  const frag = text => {
    const f = document.createDocumentFragment(), ms = Rich.emojiMatches(text);
    let at = 0;
    for (const m of ms) {
      if (m.i > at) f.append(document.createTextNode(text.slice(at, m.i)));
      f.append(emojiImg(m.t)); at = m.i + m.t.length;
    }
    if (at < text.length) f.append(document.createTextNode(text.slice(at)));
    return f;
  };
  const selRange = () => {
    const s = getSelection();
    if (!s || !s.rangeCount) return null;
    const r = s.getRangeAt(0);
    return el.contains(r.startContainer) && el.contains(r.endContainer) ? r : null;
  };
  const lenBefore = (node, off) => { const r = document.createRange(); r.selectNodeContents(el); r.setEnd(node, off); return ser(r.cloneContents()).length; };
  const getSel = () => {
    const r = selRange();
    if (r) return (last = [lenBefore(r.startContainer, r.startOffset), lenBefore(r.endContainer, r.endOffset)]);
    const n = ser(el).length;
    return last ? [Math.min(last[0], n), Math.min(last[1], n)] : [n, n];
  };
  const locate = off => {
    let acc = 0;
    const w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT);
    for (let n = w.nextNode(); n; n = w.nextNode()) {
      if (n.nodeType === 3) {
        const len = n.nodeValue.length;
        if (off <= acc + len) return [n, Math.max(0, off - acc)];
        acc += len;
      } else if (n.nodeName === "IMG") {
        const L = (n.dataset.t || "").length, p = n.parentNode, idx = Array.prototype.indexOf.call(p.childNodes, n);
        if (off <= acc) return [p, idx];
        if (off <= acc + L) return [p, idx + 1];
        acc += L;
      }
    }
    return [el, el.childNodes.length];
  };
  const setSel = (a, b) => {
    const s = getSelection(), r = document.createRange(), p = locate(a), q = b === a ? p : locate(b);
    r.setStart(p[0], p[1]); r.setEnd(q[0], q[1]);
    s.removeAllRanges(); s.addRange(r); last = [a, b];
  };
  const fire = () => el.dispatchEvent(new Event("input", {bubbles: true}));

  Object.defineProperty(el, "value", {configurable: true,
    get() { return ser(el); },
    set(v) { v = v == null ? "" : String(v); el.textContent = ""; last = null; if (v) el.append(frag(v)); }});
  Object.defineProperty(el, "selectionStart", {configurable: true, get() { return getSel()[0]; }, set(v) { setSel(v, getSel()[1] < v ? v : getSel()[1]); }});
  Object.defineProperty(el, "selectionEnd", {configurable: true, get() { return getSel()[1]; }, set(v) { setSel(Math.min(getSel()[0], v), v); }});
  Object.defineProperty(el, "placeholder", {configurable: true, get() { return el.dataset.placeholder || ""; }, set(v) { el.dataset.placeholder = v; }});
  Object.defineProperty(el, "maxLength", {configurable: true, get() { return max; }, set(v) { max = (v | 0) || max; }});
  el.setSelectionRange = (a, b) => setSel(a, b == null ? a : b);
  el.setRangeText = (text, s, e, mode) => {
    if (s == null) { const c = getSel(); s = c[0]; e = c[1]; }
    const p = locate(s), q = locate(e), r = document.createRange();
    r.setStart(p[0], p[1]); r.setEnd(q[0], q[1]); r.deleteContents();
    r.insertNode(frag(String(text)));
    el.normalize();
    const end = s + String(text).length;
    if (mode === "select") setSel(s, end); else if (mode === "start") setSel(s, s); else if (mode !== "preserve") setSel(end, end);
  };
  const nativeFocus = el.focus.bind(el);
  el.focus = o => { const had = !!selRange(); nativeFocus(o); if (!had) { const n = last ? getSel()[1] : ser(el).length; setSel(n, n); } };
  const put = text => {
    const c = getSel(), room = max - (ser(el).length - (c[1] - c[0]));
    if (room <= 0) { try { toast("Xabar juda uzun", "warn"); } catch (_) {} return; }
    el.setRangeText(text.length > room ? text.slice(0, room) : text, c[0], c[1], "end"); fire();
  };

  document.addEventListener("selectionchange", () => { if (selRange()) getSel(); });
  el.addEventListener("compositionstart", () => { composing = true; });
  el.addEventListener("compositionend", () => { composing = false; });
  el.addEventListener("beforeinput", e => {
    const t = e.inputType;
    if (t === "insertParagraph" || t === "insertLineBreak") { e.preventDefault(); put("\n"); return; }
    if (t === "insertFromPaste" || t === "insertFromDrop" || t === "insertFromPasteAsQuotation") {
      const txt = (e.dataTransfer && e.dataTransfer.getData("text/plain")) || e.data || "";
      e.preventDefault();
      if (txt) put(txt.replace(/\r\n?/g, "\n"));
      return;
    }
    if (t === "insertText" && e.data && !composing) {
      const c = getSel();
      if (ser(el).length - (c[1] - c[0]) + e.data.length > max) { e.preventDefault(); try { toast("Xabar juda uzun", "warn"); } catch (_) {} }
    }
  });
  el.addEventListener("input", () => {
    if (composing) return;
    const v = ser(el);
    if (!v && el.firstChild) { el.textContent = ""; return; }
    if (v.length > max) { const c = getSel()[0]; el.value = v.slice(0, max); const n = Math.min(c, max); setSel(n, n); }
  });
  el.addEventListener("copy", e => {
    const r = selRange();
    if (!r || r.collapsed || !e.clipboardData) return;
    e.clipboardData.setData("text/plain", ser(r.cloneContents())); e.preventDefault();
  });
  el.addEventListener("cut", e => {
    const r = selRange();
    if (!r || r.collapsed || !e.clipboardData) return;
    e.clipboardData.setData("text/plain", ser(r.cloneContents())); e.preventDefault();
    r.deleteContents(); el.normalize(); fire();
  });
})();

const MEN = {el: null, items: [], sel: 0, start: -1};
const inp = $("inp");
function autosize() { inp.style.height = "auto"; inp.style.height = Math.min(inp.scrollHeight, 140) + "px"; syncSend(); updateMention(); }
function syncSend() {
  $("sendBtn").classList.toggle("on", !!inp.value.trim() || !!S.pendingImg);
  $("composer").classList.toggle("has-text", !!inp.value.trim() || !!S.pendingImg || !!S.editing);
}
inp.addEventListener("input", autosize);
inp.addEventListener("focus", () => setTimeout(() => { const b = $("msgs"); if (b._stick) b.scrollTop = b.scrollHeight; }, 320));
inp.addEventListener("keydown", e => {
  if (mentionKey(e)) return;
  if (e.key === "Enter" && !e.shiftKey && !COARSE && !e.isComposing) { e.preventDefault(); submit(); }
  else if (e.key === "Escape") { if (S.editing) cancelEdit(); else if (S.pendingImg) clearPendingImage(); else if (S.replying) cancelReply(); }
  else if (e.key === "ArrowUp" && !inp.value && S.active) {
    const mine = [...currentMsgs()].reverse().find(x => !x.service && x.user.id === S.me.id && !x.legacy && !x.bad && !x.locked);
    if (mine) { e.preventDefault(); startEdit(mine); }
  }
});
inp.addEventListener("paste", e => {
  const f = (e.clipboardData && e.clipboardData.files || [])[0];
  if (f) { e.preventDefault(); setPendingImage(f); return; }
  const txt = e.clipboardData && e.clipboardData.getData("text/plain");
  const whole = !inp.value.trim() || (inp.selectionStart === 0 && inp.selectionEnd === inp.value.length);
  if (!txt || !whole || S.editing) return;
  const fz = Rich.fenceFor(txt.replace(/\r\n?/g, "\n"));
  if (!fz || fz.text.length > inp.maxLength) return;
  e.preventDefault();
  inp.value = fz.text; inp.setSelectionRange(fz.text.length, fz.text.length); autosize();
  toast("Aniqlandi: " + fz.label + ". Xavfsiz ko'rinishda yuboriladi", "ok");
});

function mentionQuery() {
  const pos = inp.selectionStart;
  if (pos == null || pos !== inp.selectionEnd) return null;
  const m = /(?:^|[\s(])@([A-Za-z0-9_]{0,20})$/.exec(inp.value.slice(0, pos));
  return m ? {q: m[1].toLowerCase(), start: pos - m[1].length - 1, pos} : null;
}
function mentionCandidates(q) {
  const rank = u => { const un = u.username, nn = (u.nickname || "").toLowerCase(); return !q ? 1 : un.startsWith(q) ? 0 : nn.startsWith(q) ? 1 : un.includes(q) ? 2 : nn.includes(q) ? 3 : 9; };
  return S.members.map(m => U(m.id)).filter(u => u.id !== S.me.id && !u.deleted && !u.banned && u.username && rank(u) < 9)
    .sort((a, b) => rank(a) - rank(b) || (a.role === "owner" ? -1 : 0) - (b.role === "owner" ? -1 : 0) || a.username.localeCompare(b.username)).slice(0, 6);
}
function closeMention() { if (MEN.el) { MEN.el.remove(); MEN.el = null; } MEN.items = []; }
function pickMention(u) {
  const q = mentionQuery(); if (!q) { closeMention(); return; }
  const ins = "@" + u.username + " ";
  if (inp.value.length - (q.pos - q.start) + ins.length > inp.maxLength) { toast("Xabar juda uzun", "warn"); return; }
  inp.setRangeText(ins, q.start, q.pos, "end"); closeMention(); autosize();
  if (!COARSE) inp.focus({preventScroll: true});
}
function paintMention() {
  if (!MEN.el) { MEN.el = h("div", {class: "mention-panel", role: "listbox", "aria-label": "Foydalanuvchini belgilash"}); MEN.el.addEventListener("mousedown", e => e.preventDefault()); document.body.append(MEN.el); }
  MEN.el.textContent = "";
  MEN.items.forEach((u, i) => {
    const b = h("button", {class: "mn-i" + (i === MEN.sel ? " on" : ""), type: "button", role: "option", "aria-selected": String(i === MEN.sel)},
      avatar(u, "s"), h("div", {class: "mn-t"}, h("b", {}, nameEl(u)), h("small", {text: "@" + u.username})));
    b.addEventListener("click", () => pickMention(u));
    MEN.el.append(b);
  });
  const r = inp.getBoundingClientRect(), w = Math.min(320, innerWidth - 16);
  MEN.el.style.width = w + "px"; MEN.el.style.left = Math.max(8, Math.min(r.left, innerWidth - w - 8)) + "px"; MEN.el.style.bottom = Math.max(8, innerHeight - r.top + 8) + "px";
}
function updateMention() {
  const q = S.me && !S.editing ? mentionQuery() : null;
  const list = q ? mentionCandidates(q.q) : [];
  if (!list.length) { closeMention(); return; }
  const same = MEN.items.length === list.length && MEN.items.every((u, i) => u.id === list[i].id);
  MEN.items = list; if (!same) MEN.sel = 0;
  paintMention();
}
function mentionKey(e) {
  if (!MEN.el || !MEN.items.length || e.isComposing) return false;
  const n = MEN.items.length;
  if (e.key === "ArrowDown" || e.key === "ArrowUp") { e.preventDefault(); MEN.sel = (MEN.sel + (e.key === "ArrowDown" ? 1 : n - 1)) % n; paintMention(); return true; }
  if (e.key === "Tab" || (e.key === "Enter" && !e.shiftKey && !COARSE)) { e.preventDefault(); pickMention(MEN.items[MEN.sel]); return true; }
  if (e.key === "Escape") { e.preventDefault(); closeMention(); return true; }
  return false;
}
inp.addEventListener("keyup", e => { if (e.key === "ArrowLeft" || e.key === "ArrowRight" || e.key === "Home" || e.key === "End") updateMention(); });
inp.addEventListener("click", updateMention);
inp.addEventListener("blur", () => setTimeout(closeMention, 150));
$("sendBtn").addEventListener("click", submit);

function startEdit(m) {
  cancelReply(); clearPendingImage();
  S.editing = m; inp.value = m.content; autosize(); inp.focus();
  const ebt = m.content ? m.content.replace(/\s+/g, " ") : (m.file ? (m.file.voice ? "🎤 Ovozli xabar izohi" : m.file.vnote ? "📹 Video xabar izohi" : "📎 Fayl izohi") : "📷 Rasm izohi");
  $("ebText").replaceChildren(Rich.hasInlineEmoji(ebt) ? Rich.preview(ebt) : document.createTextNode(ebt));
  $("editbar").classList.remove("hidden");
}
function cancelEdit() {
  if (!S.editing) return;
  S.editing = null; inp.value = ""; autosize(); $("editbar").classList.add("hidden");
}
$("ebCancel").addEventListener("click", cancelEdit);

function startReply(m) {
  if (m.ch) return;
  cancelEdit();
  S.replying = replyInfo(m);
  $("rbName").textContent = m.user.nickname;
  const rbt = (m.image ? "📷 " : m.file ? fileIco(m.file) : "") + (m.content ? m.content.replace(/\s+/g, " ") : (m.file ? fileWhat(m.file) : "Rasm"));
  $("rbText").replaceChildren(Rich.hasInlineEmoji(rbt) ? Rich.preview(rbt) : document.createTextNode(rbt));
  $("replybar").classList.remove("hidden");
  inp.focus();
}
function cancelReply() { S.replying = null; $("replybar").classList.add("hidden"); }
$("rbCancel").addEventListener("click", cancelReply);

const IMG_TYPES = ["image/png", "image/jpeg", "image/webp", "image/gif"], MAX_MEDIA = 50 * 1024 * 1024;
async function shrinkImage(f) {
  if (f.type === "image/gif" || f.size <= 1.5 * 1024 * 1024 || !self.createImageBitmap) return f;
  try {
    const bmp = await createImageBitmap(f), k = Math.min(1, 1920 / Math.max(bmp.width, bmp.height));
    const c = document.createElement("canvas"); c.width = Math.round(bmp.width * k); c.height = Math.round(bmp.height * k);
    const g = c.getContext("2d"); g.fillStyle = "#fff"; g.fillRect(0, 0, c.width, c.height); g.drawImage(bmp, 0, 0, c.width, c.height);
    const blob = await new Promise(r => c.toBlob(r, "image/jpeg", 0.85));
    return blob && blob.size < f.size ? blob : f;
  } catch (_) { return f; }
}
async function setPendingImage(file) {
  if (!S.active || !file) return;
  if (S.active.kind === "group" && S.chat.locked && !amAdmin()) { toast("Umumiy chat qulflangan", "error"); return; }
  const isImg = IMG_TYPES.includes(file.type);
  const blob = isImg ? await shrinkImage(file) : file;
  if (blob.size > MAX_MEDIA) { toast("Fayl 50 MB dan oshmasligi kerak", "error"); return; }
  if (!blob.size) { toast("Fayl bo'sh", "error"); return; }
  cancelEdit(); clearPendingImage();
  const ext = blob.type === "image/jpeg" ? "jpg" : (blob.type.split("/")[1] || "png");
  S.pendingImg = {blob, isImg, url: isImg ? URL.createObjectURL(blob) : null, name: isImg ? "rasm." + ext : (file.name || "fayl")};
  $("ibThumb").classList.toggle("hidden", !isImg); $("ibIcon").classList.toggle("hidden", isImg);
  if (isImg) $("ibThumb").src = S.pendingImg.url; else $("ibThumb").removeAttribute("src");
  $("ibTitle").textContent = isImg ? "Rasm" : S.pendingImg.name;
  $("ibInfo").textContent = "Izoh yozib yuboring (ixtiyoriy) • " + fmtSize(blob.size);
  $("imgbar").classList.remove("hidden");
  syncSend(); inp.focus();
}
function clearPendingImage() {
  if (S.pendingImg && S.pendingImg.url) URL.revokeObjectURL(S.pendingImg.url);
  S.pendingImg = null; $("ibThumb").removeAttribute("src"); $("imgbar").classList.add("hidden"); syncSend();
}
$("attachBtn").addEventListener("click", () => $("imgFile").click());
$("imgFile").addEventListener("change", () => { const f = $("imgFile").files[0]; $("imgFile").value = ""; if (f) setPendingImage(f); });
$("ibCancel").addEventListener("click", clearPendingImage);
["dragenter", "dragover"].forEach(ev => $("chat").addEventListener(ev, e => { if (e.dataTransfer && [...e.dataTransfer.types].includes("Files")) { e.preventDefault(); $("chat").classList.add("drop"); } }));
["dragleave", "drop"].forEach(ev => $("chat").addEventListener(ev, e => { if (ev === "dragleave" && $("chat").contains(e.relatedTarget)) return; $("chat").classList.remove("drop"); }));
$("chat").addEventListener("drop", e => { const f = e.dataTransfer && e.dataTransfer.files[0]; if (f) { e.preventDefault(); setPendingImage(f); } });

async function sendImage(caption) {
  if (S.sending) return;
  const img = S.pendingImg, reply = S.replying;
  const pend = Pend.add(S.active, {kind: "file", name: img.name, size: img.blob.size, isImg: img.isImg, text: caption, url: img.isImg ? URL.createObjectURL(img.blob) : null}), relTy = Typing.hold("file");
  inp.value = ""; clearPendingImage(); cancelReply(); autosize();
  Pend.go(pend, async p => {
    if (!p.fileMeta) {
      let blob = img.blob, f = {name: img.name, mime: blob.type || "application/octet-stream", size: blob.size, img: false};
      if (img.isImg) {
        let c; try { c = await cleanImage(blob); } catch (_) { throw Object.assign(new Error("Rasmni o'qib bo'lmadi"), {final: true}); }
        blob = c.blob; f = Object.assign(f, {mime: blob.type || f.mime, size: blob.size, img: true, w: c.w, h: c.h, th: c.th});
      }
      const e = await E2E.encryptFile(new Uint8Array(await blob.arrayBuffer()));
      f.k = e.key; p.fileMeta = f; p.encBlob = e.blob;
    }
    if (!p.blobName) {
      if (!p.upJob) p.upJob = uploadEnc(p.encBlob, "Fayl yuklanmadi").then(n => { p.blobName = n; p.encBlob = null; return n; }, e => { p.upJob = null; throw e; });
      await p.upJob;
    }
    const payload = {t: caption, f: p.fileMeta}; if (reply) payload.r = reply;
    return withTarget({type: "send", cid: p.cid, e2e: await sealFor(await keyForTarget(p.target), payload), blob: p.blobName}, p.target);
  }).finally(relTy);
}
async function submit() {
  const text = inp.value.trim();
  if (!S.active || S.sending) return;
  if (S.active.kind === "dm" && U(S.active.uid).deleted) { toast("Bu akkaunt o'chirilgan. Xabar yuborib bo'lmaydi", "error"); return; }
  if (S.pendingImg) { sendImage(text); return; }
  if (!S.editing && !text) return;
  if (S.editing && !text && !S.editing._f) return;
  if (S.editing && text === S.editing.content) { cancelEdit(); return; }
  S.sending = true;
  let pend = null;
  try {
    if (S.editing) {
      const ctx = await keyForActive(), payload = {t: text};
      const m = S.editing;
      if (m._r) payload.r = m._r; if (m._f) payload.f = m._f; if (m._fw) payload.fw = m._fw;
      if (wsSend({type: "edit", id: m.id, e2e: await sealFor(ctx, payload)})) cancelEdit();
    } else {
      const payload = {t: text};
      if (S.replying) payload.r = S.replying;
      pend = Pend.add(S.active, {kind: "text", text});
      inp.value = ""; cancelReply(); autosize(); inp.focus(); Typing.stop();
      Pend.go(pend, async p => withTarget({type: "send", cid: p.cid, e2e: await sealFor(await keyForTarget(p.target), payload)}, p.target));
    }
  } catch (err) {
    toast(err.message, "error");
    if (pend) Pend.wait(pend);
  }
  S.sending = false;
}

