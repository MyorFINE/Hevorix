// ---- Advanced: saqlash joyi va avtozagruzka ----
const LS_AUTODL = "termchat_autodl";
const AUTO_MAX = 10 * 1048576;
const autoDlOn = () => { try { return localStorage.getItem(LS_AUTODL) !== "off"; } catch (_) { return true; } };
const autoDlSet = on => { try { localStorage.setItem(LS_AUTODL, on ? "on" : "off"); } catch (_) {} if (on) autoWarmAll(); mcRepaint(); };

// Ochilgan (shifri yechilgan) media baytlari xotirada — tez ochish uchun. Hajm cheklangan.
const MC = {map: new Map(), size: 0, max: 48 * 1048576, bad: new Set(), poster: new Map()};
const mcWarm = id => { const e = MC.map.get(id); return !!(e && e.n > 0); };
function mcRepaint() { try { paintVoices(); paintVNs(); } catch (_) {} }
function fileBytes(m) {
  const id = m.id, cached = typeof id === "number";
  if (cached && MC.map.has(id)) return MC.map.get(id).p;
  const p = (async () => {
    if (m.file.e2e || m.file.vnote) return e2eFetchBlob(m);
    const r = await SC.fetch(m.file.url, {headers: {Authorization: "Bearer " + S.token}});
    if (!r.ok) throw new Error("fayl");
    return r.bytes;
  })();
  if (!cached) return p;
  const e = {p, n: 0};
  MC.map.set(id, e);
  p.then(b => {
    e.n = (b && (b.byteLength || b.length)) || 0; MC.size += e.n;
    for (const [k, v] of MC.map) { if (MC.size <= MC.max) break; if (k === id) continue; MC.size -= v.n; MC.map.delete(k); }
    mcRepaint();
  }).catch(() => { if (MC.map.get(id) === e) MC.map.delete(id); });
  return p;
}
function autoWarm(m) {
  const f = m && m.file;
  if (!f || typeof m.id !== "number" || !autoDlOn() || S.offline || m.expired || MC.map.has(m.id) || MC.bad.has(m.id)) return;
  if (f.size > AUTO_MAX) return;
  fileBytes(m).then(() => { if (f.vnote) vnPoster(m); }).catch(() => MC.bad.add(m.id));
}
function autoWarmAll() {
  [S.group].concat([...S.dms.values()]).forEach(st => (st && st.msgs || []).forEach(autoWarm));
}
// Dumaloq videoning birinchi kadri: tiniq muqova (avtozagruzka yoqilganda)
async function vnPoster(m) {
  if (MC.poster.has(m.id)) return paintPoster(m.id);
  let vurl = null;
  try {
    const parts = VNote.unpack(await fileBytes(m));
    const v = document.createElement("video");
    v.muted = true; v.playsInline = true; v.preload = "auto";
    vurl = URL.createObjectURL(new Blob([parts.video], {type: m.file.mime}));
    v.src = vurl;
    await new Promise((res, rej) => {
      const t = setTimeout(() => rej(new Error("vaqt")), 8000);
      v.addEventListener("loadeddata", () => { clearTimeout(t); res(); }, {once: true});
      v.addEventListener("error", () => { clearTimeout(t); rej(new Error("video")); }, {once: true});
    });
    const cv = document.createElement("canvas"); cv.width = cv.height = 240;
    drawCover(cv, v);
    MC.poster.set(m.id, cv.toDataURL("image/jpeg", 0.8));
    paintPoster(m.id);
  } catch (_) {} finally { if (vurl) URL.revokeObjectURL(vurl); }
}
function paintPoster(id) {
  const box = document.querySelector('.vnbox[data-vnid="' + id + '"]'), src = MC.poster.get(id);
  if (!box || !src) return;
  let th = box.querySelector(".vnth");
  if (!th) { th = h("img", {class: "vnth", alt: "", draggable: "false"}); box.querySelector(".vnc").prepend(th); }
  th.src = src; th.classList.add("sharp");
}

// Saqlash joyi: tanlangan papka (File System Access API) — dastur ruxsat bergan brauzerlarda
const Store = {
  dir: null, name: "", loaded: false,
  supported: () => typeof window.showDirectoryPicker === "function" && !!window.indexedDB,
  _db() {
    return new Promise((res, rej) => {
      const r = indexedDB.open("termchat_prefs", 1);
      r.onupgradeneeded = () => r.result.createObjectStore("kv");
      r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
    });
  },
  async _kv(mode, fn) {
    const db = await this._db();
    return new Promise((res, rej) => {
      const tx = db.transaction("kv", mode), rq = fn(tx.objectStore("kv"));
      tx.oncomplete = () => { db.close(); res(rq && rq.result); }; tx.onerror = tx.onabort = () => { db.close(); rej(tx.error); };
    });
  },
  async load() {
    if (this.loaded || !this.supported()) { this.loaded = true; return; }
    try { const h = await this._kv("readonly", s => s.get("dl_dir")); if (h && h.kind === "directory") { this.dir = h; this.name = h.name; } } catch (_) {}
    this.loaded = true;
  },
  async pick() {
    const h = await window.showDirectoryPicker({id: "termchat", mode: "readwrite"});
    await this._kv("readwrite", s => s.put(h, "dl_dir"));
    this.dir = h; this.name = h.name;
  },
  async reset() { this.dir = null; this.name = ""; try { await this._kv("readwrite", s => s.delete("dl_dir")); } catch (_) {} },
  async ready(ask) {
    if (!this.dir) return null;
    try {
      const o = {mode: "readwrite"};
      if (await this.dir.queryPermission(o) === "granted") return this.dir;
      if (ask && await this.dir.requestPermission(o) === "granted") return this.dir;
    } catch (_) {}
    return null;
  },
  async _unique(dir, name) {
    const i = name.lastIndexOf("."), base = i > 0 ? name.slice(0, i) : name, ext = i > 0 ? name.slice(i) : "";
    for (let n = 0; n < 200; n++) {
      const cand = n ? base + " (" + n + ")" + ext : name;
      try { await dir.getFileHandle(cand); } catch (e) { if (e && e.name === "NotFoundError") return cand; throw e; }
    }
    return Date.now() + "-" + name;
  },
  async write(dir, name, bytes) {
    const fh = await dir.getFileHandle(await this._unique(dir, name), {create: true}), w = await fh.createWritable();
    try { await w.write(bytes); await w.close(); } catch (err) { try { await w.abort(); } catch (_) {} throw err; }
  },
};
function anchorSave(bytes, name, type) {
  const url = URL.createObjectURL(new Blob([bytes], {type: type || "application/octet-stream"}));
  const a = h("a", {href: url, download: name}); document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60000);
}
// Fayl yuklash: tanlangan papka bo'lsa — o'sha yerga, bo'lmasa brauzerning odatiy yuklamalariga
async function saveToChosen(bytes, name) {
  const dir = await Store.ready(false);
  if (dir) { try { await Store.write(dir, name, bytes); return Store.name || true; } catch (_) {} }
  anchorSave(bytes, name);
  return false;
}
