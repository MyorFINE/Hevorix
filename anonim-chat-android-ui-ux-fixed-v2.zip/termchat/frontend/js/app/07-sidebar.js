/* ---------------- chap panel: ro'yxat ---------------- */
function itemEl({av, title, sub, subOn, time, unread, active, onclick, onctx}) {
  const el = h("div", {class: "item" + (active ? " active" : ""), onclick, oncontextmenu: onctx ? e => { e.preventDefault(); e.stopPropagation(); onctx(e.clientX, e.clientY); } : null},
    av,
    h("div", {class: "i-mid"},
      h("div", {class: "i-top"}, h("div", {class: "i-title"}, title), time ? h("span", {class: "i-time", text: time}) : null),
      h("div", {class: "i-bot"}, h("div", {class: "i-sub" + (subOn ? " on" : "")}, sub),
        unread ? h("span", {class: "pill", text: unread > 99 ? "99+" : String(unread)}) : null)));
  if (onctx) longPress(el, (x, y) => onctx(x, y, true));
  return el;
}
const typingSub = key => { const t = typingLabel(key); return t ? h("span", {class: "typing"}, t) : null; };       // ro'yxatda oxirgi xabar o'rnida "yozmoqda…"
function previewOf(m, withAuthor, plain) {
  if (!m) return "";
  const mine = !plain && m.user.id === S.me.id;
  let body = m.locked ? "🔒 Shifrlangan xabar" : m.bad ? "⚠ Shifrni ochib bo'lmadi" : m.content;
  if (!m.locked && !m.bad && m.content) {                                // kod / buyruq xabarlari ro'yxatda qisqa belgi bilan ko'rinadi
    const rp = Rich.parse(m.content), rc = rp.find(x => x.k !== "text");
    if (rc) body = (rc.k === "term" ? "⌨ Linux buyruq: " + Rich.copyTextOf(rc).split("\n")[0] : "‹/› " + (rc.label || "Kod") + ": " + rc.code.split("\n")[0]);
  }
  const text = (m.image ? "📷 " : m.file ? fileIco(m.file) : "") + (body ? body.replace(/\s+/g, " ") : (m.image ? "Rasm" : m.file ? fileWhat(m.file) : ""));
  if (mine) return [h("b", {text: "Siz: "}), text];
  return withAuthor ? [h("b", {text: m.user.nickname + ": "}), text] : text;
}
function groupItem() {
  const last = [...S.group.msgs].reverse().find(x => !x.service);
  return itemEl({
    av: groupAvatar("m"), title: h("span", {class: "nt", text: "Umumiy chat"}),
    sub: typingSub("g") || (last ? previewOf(last, true) : "Hozircha xabar yo'q"), subOn: !!typingLabel("g"), time: last ? listTime(last.ts) : "",
    unread: S.group.unread, active: isActiveGroup(), onclick: () => openChat({kind: "group"}),
  });
}
function dmItem(u, dm) {
  return itemEl({
    av: avatar(u, "m", true), title: nameEl(u), sub: typingSub("d" + u.id) || previewOf(dm.last, false), subOn: !!typingLabel("d" + u.id), time: listTime(dm.last.ts),
    unread: dm.unread, active: isActiveDm(u.id), onclick: () => openChat({kind: "dm", uid: u.id}),
    onctx: (x, y, touch) => dmMenu(x, y, u.id, touch),
  });
}
function chanItem(c) {
  const st = chOf(c.id), last = st.last;
  return itemEl({
    av: chanAvatar(c, "m"), title: [h("span", {class: "nt", text: c.nickname}), c.private ? icon("lock", "ic ch-lock") : null],
    sub: last ? previewOf(last, false, true) : c.posts ? c.posts + " post" : "Hozircha post yo'q",
    time: last ? listTime(last.ts) : "", unread: st.unread, active: isActiveChan(c.id), onclick: () => openChat({kind: "channel", id: c.id}),
  });
}
function memberItem(u) {
  const sub = (isStaff(u) ? roleLabel(u.role) + " • " : "") + statusText(u);
  return itemEl({
    av: avatar(u, "m", true), title: nameEl(u), sub, subOn: isOnline(u.id),
    active: isActiveDm(u.id), onclick: () => openChat({kind: "dm", uid: u.id}),
  });
}
function renderList() {
  if (!S.me) return;
  Off.dirty();                                        // oflayn xotira: o'zgarish bo'lsa keyinroq (fonda) shifrlab saqlanadi
  const list = $("list"), top = list.scrollTop;
  list.textContent = "";
  const q = S.query.trim().toLowerCase();
  const match = u => !q || u.nickname.toLowerCase().includes(q) || u.username.toLowerCase().includes(q);
  if (S.tab === "chats") {
    if (!q || "umumiy chat".includes(q)) list.append(groupItem());
    const dms = [...S.dms.entries()].filter(([, d]) => d.last).sort((a, b) => b[1].last.ts - a[1].last.ts);
    dms.forEach(([id, d]) => { const u = U(id); if (match(u)) list.append(dmItem(u, d)); });
    if (q) {
      const shown = new Set(dms.map(([id]) => id));
      const others = S.members.filter(m => m.id !== S.me.id && !shown.has(m.id) && match(m));
      if (others.length) { list.append(h("div", {class: "sect", text: "A'zolar"})); others.forEach(m => list.append(memberItem(U(m.id)))); }
    }
    if (!list.children.length) list.append(h("div", {class: "none", text: "Hech narsa topilmadi"}));
  } else if (S.tab === "channels") {
    list.append(h("div", {class: "chn-bar"},
      amAdmin() ? h("button", {class: "btn ghost sm", type: "button", onclick: () => Channels.create()}, icon("plus"), " Kanal yaratish") : null,
      h("button", {class: "btn ghost sm", type: "button", onclick: () => Channels.join()}, icon("lock"), " Shaxsiy kanalga qo'shilish")));
    const cs = S.chList.filter(c => !q || c.nickname.toLowerCase().includes(q) || c.username.toLowerCase().includes(q));
    cs.forEach(c => list.append(chanItem(c)));
    if (!cs.length) list.append(h("div", {class: "none", text: S.chList.length ? "Hech narsa topilmadi" : "Hozircha kanallar yo'q"}));
  } else {
    const all = S.members.filter(m => m.id !== S.me.id && match(m)).map(m => U(m.id));
    const on = all.filter(u => isOnline(u.id)), off = all.filter(u => !isOnline(u.id));
    if (on.length) { list.append(h("div", {class: "sect", text: "Onlayn — " + on.length})); on.forEach(u => list.append(memberItem(u))); }
    if (off.length) { list.append(h("div", {class: "sect", text: "Oflayn"})); off.forEach(u => list.append(memberItem(u))); }
    if (!all.length) list.append(h("div", {class: "none", text: S.members.length > 1 ? "Hech narsa topilmadi" : "Hozircha boshqa a'zolar yo'q"}));
  }
  list.scrollTop = top;
  updateBadges();
}
function updateBadges() {
  let total = S.group.unread, ctot = 0;
  S.dms.forEach(d => { total += d.unread; });
  S.chn.forEach(c => { ctot += c.unread; });
  const b = $("chatsBadge");
  b.classList.toggle("hidden", !total); b.textContent = total > 99 ? "99+" : String(total);
  const cb = $("chnBadge");
  cb.classList.toggle("hidden", !ctot); cb.textContent = ctot > 99 ? "99+" : String(ctot);
  document.title = (total + ctot ? "(" + (total + ctot) + ") " : "") + APP_NAME;
}
document.querySelectorAll(".tabs button[data-tab]").forEach(btn => btn.addEventListener("click", () => {
  S.tab = btn.dataset.tab;
  document.querySelectorAll(".tabs button").forEach(x => x.classList.toggle("on", x === btn));
  renderList();
  if (S.tab === "channels") Channels.loadList();
}));
$("search").addEventListener("input", e => { S.query = e.target.value; renderList(); });

/* ---------------- admin sozlamalari: chap menyu (3 chiziqcha) → Sozlamalar ostida ----------------
   Har bir bo'lim alohida sahifa bo'lib o'ngdan chapga suriladi (openPage tizimi). */
const ADM_SECTIONS = [
  ["ips", "shield", "IP lar va profillar"],
  ["users", "user", "Foydalanuvchilar, nishon va zaxira"],
  ["log", "list", "Harakatlar logi"],
  ["blocks", "ban", "Bloklangan IP lar"],
  ["media", "attach", "Media boshqaruvi"],
  ["reports", "flag", "Shikoyatlar"],
  ["mod", "shield", "Moderatsiya sozlamalari"],
];
const ADM_TITLES = {msgs: "Xabarlar", emoji: "Emoji boshqaruvi"};
ADM_SECTIONS.forEach(([k, , t]) => { ADM_TITLES[k] = t; });
function openAdminHome() {
  if (!amAdmin()) return;
  openPage(() => {
    const wrap = h("div", {}, pageHead("Admin sozlamalari"), gapEl());
    ADM_SECTIONS.forEach(([k, ic, t]) => wrap.append(setRow(ic, t, () => openAdmin(k))));
    wrap.append(gapEl(), setRow("chat", "Xabarlar", () => openAdmin("msgs")), setRow("emoji", "Emoji boshqaruvi", () => openAdmin("emoji")));
    wrap.append(gapEl(), setRow("trash", "Umumiy chatni tozalash", () => clearGroupChat(), null, true));
    return wrap;
  });
}

