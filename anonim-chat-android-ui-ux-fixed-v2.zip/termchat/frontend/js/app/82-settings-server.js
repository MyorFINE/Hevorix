function openInspector(tab) {
  openPage(() => {
    const st = {tab: tab || "flow"};
    const tabs = h("div", {class: "adm-tabs"}), body = h("div", {class: "adm-body enc"});
    const defs = [["flow", "Xabar yo'li"], ["server", "Server ko'radi"], ["keys", "Kalitlar"], ["limits", "Halol chegaralar"]];
    const paint = () => { tabs.textContent = ""; defs.forEach(([k, t]) => tabs.append(h("button", {type: "button", class: st.tab === k ? "on" : "", text: t, onclick: () => { st.tab = k; paint(); load(); }}))); };
    const load = () => { body.textContent = ""; ({flow: encFlow, server: encServer, keys: encKeys, limits: encLimits})[st.tab](body); };
    paint(); load();
    return h("div", {}, pageHead("🔒 Shifrlash: nima sodir bo'layapti?"), tabs, body);
  });
}
const mono = (t, cls) => h("div", {class: "enc-mono" + (cls ? " " + cls : ""), text: t});
const step = (n, title, ...kids) => h("div", {class: "enc-step"}, h("div", {class: "enc-n", text: String(n)}), h("div", {class: "enc-b"}, h("b", {text: title}), ...kids));
const shortId = s => s && s.length > 28 ? s.slice(0, 22) + "…" + s.slice(-6) : (s || "");

function encFlow(body) {
  const out = h("div", {});
  const inp2 = h("textarea", {class: "fld", rows: "2", maxlength: "200"}); inp2.value = "Salom! Bu sinov matni 🙂";
  const go = h("button", {class: "btn", type: "button", text: "Shifrlab ko'rish (yuborilmaydi)"});
  go.onclick = async () => {
    out.textContent = "";
    try {
      if (!S.active) throw new Error("Avval biror suhbatni oching (guruh yoki lichka) — kalit shu suhbatniki");
      const ctx = await keyForActive(), text = inp2.value.slice(0, 200);
      const env = await sealFor(ctx, {t: text}), t = E2E.trace[E2E.trace.length - 1];
      const dm = S.active.kind === "dm", p = dm ? await peer(S.active.uid) : null;
      const pkt = JSON.stringify(Object.assign({type: "send", e2e: env}, dm ? {to: S.active.uid} : {}));
      out.append(
        step(1, "Sizning matningiz (faqat qurilmangizda)", mono(t.plain), h("small", {text: "Uzunlik yashirilishi uchun " + t.plainBytes + " baytgacha to'ldiriladi."})),
        step(2, dm ? "Kalit: ikkingiz orasidagi ECDH kaliti" : "Kalit: guruh kaliti (avlod " + ctx.ep + ")",
          mono(dm ? "Sizning xavfsizlik raqamingiz: " + X.fp + "\n" + U(S.active.uid).nickname + ": " + p.fp : "Kalit ID: " + (X.keyIds.get(ctx.ep) || "?") + "  (kalitning o'zi emas, faqat belgisi)"),
          h("small", {text: dm ? "Bu kalit faqat sizning va suhbatdoshingizning maxfiy kalitlaridan hosil bo'ladi; server ikkalasini ham bilmaydi." : "Guruh kaliti serverda yo'q: har bir a'zo uchun uning ommaviy kaliti bilan o'ralgan nusxasi bor."})),
        step(3, "AES-256-GCM bilan shifrlash", mono("IV (tasodifiy): " + t.iv + "\nShifr: " + t.ctBytes + " bayt (shu jumladan 16 baytlik tekshiruv tegi)")),
        step(4, "ECDSA imzosi (yuboruvchi — siz)", mono(t.sigBytes + " bayt. Hech kim sizning nomingizdan soxta xabar yarata olmaydi.")),
        step(5, "Serverga ketadigan paket (ilova darajasida)", mono(shortId(pkt) === pkt ? pkt : pkt.slice(0, 90) + " … " + pkt.slice(-40), "net"),
          h("small", {text: "Mana shu — serverga boradigan hamma narsa: matn yo'q, faqat shifr. To'liq konvert:"}), mono(env, "net long")));
    } catch (err) { out.append(h("div", {class: "adm-empty", text: err.message})); }
  };
  const wire = h("div", {});
  const paintWire = () => {
    wire.textContent = "";
    const fr = SC.wire.slice(-4).reverse();
    if (!fr.length) wire.append(h("div", {class: "adm-empty", text: "Hozircha kadr yo'q"}));
    fr.forEach(f => wire.append(h("div", {class: "enc-frame"},
      h("b", {text: (f.dir === "→" ? "Siz → server" : "server → siz") + " • " + new Date(f.ts).toLocaleTimeString() + " • " + f.bytes + " belgi"}),
      h("small", {text: "Server (kanal ochilgach) ko'radigan ilova JSON'i:"}), mono(f.app, "net"),
      h("small", {text: "Tarmoqda (Chrome Network, Wireshark) ko'rinadigani:"}), mono(f.net + "…", "net"))));
  };
  paintWire();
  body.append(
    h("p", {class: "adm-note", text: "Xabaringiz brauzeringizda shifrlanadi va faqat shifr serverga boradi. Sinab ko'ring: matn kiriting — pastda shifrlash qadamlari haqiqiy kalitingiz bilan ko'rsatiladi (xabar yuborilmaydi)."}),
    inp2, go, out,
    h("h4", {class: "enc-h", text: "Tarmoqdagi oxirgi haqiqiy kadrlar"}),
    h("p", {class: "adm-note", text: "Ikki qatlam: tashqi — brauzer↔server kanali (Wireshark shuni ko'radi); ichki — xabar konverti, uni faqat suhbat a'zolari ocha oladi. Server kanalni ochadi, lekin konvertni ocha olmaydi."}),
    h("button", {class: "btn ghost sm", type: "button", text: "Yangilash", onclick: paintWire}), wire);
}

async function encServer(body) {
  body.append(h("div", {class: "adm-empty", text: "Serverdan so'ralmoqda…"}));
  let j;
  try { j = await api("/e2ee/server-view" + (S.active && S.active.kind === "dm" ? "?to=" + S.active.uid : "")); }
  catch (err) { body.textContent = ""; admErr(body, err); return; }
  body.textContent = "";
  const scope = j.scope === "group" ? "Umumiy chat" : "Lichka: " + (S.active ? U(S.active.uid).nickname : "");
  body.append(h("p", {class: "adm-note", text: scope + " — serverning o'z bazasidagi so'nggi qatorlar (server aynan shuni qaytardi). Chap tomonda — qurilmangizda ochilgan matn, o'ngda — server va admin ko'radigani."}));
  const mine = new Map(currentMsgs().map(m => [m.id, m]));
  if (!j.rows.length) body.append(h("div", {class: "adm-empty", text: "Bu suhbatda hali xabar yo'q"}));
  j.rows.forEach(r => {
    const local = mine.get(r.id);
    const you = local ? (local.locked ? "🔒 (kalit kutilmoqda)" : local.bad ? "⚠ (ochib bo'lmadi)" : (local.content || (local.image ? "📷 rasm" : local.file ? (local.file.voice ? "🎤 ovozli xabar" : local.file.vnote ? "📹 video xabar" : "📎 " + local.file.name) : ""))) : "(bu xabar yuklanmagan)";
    body.append(h("div", {class: "enc-row"},
      h("div", {class: "enc-rh"}, h("b", {text: "#" + r.id + " • @" + r.from}), h("span", {text: " • " + fmtDT(r.ts) + " • " + r.stored_bytes + " bayt" + (r.blob_bytes ? " • fayl " + fmtSize(r.blob_bytes) + " (shifrlangan)" : "") + (r.deleted ? " • o'chirilgan" : "") + (r.edited ? " • tahrirlangan" : "")}),
        r.e2e ? null : h("span", {class: "flag b", text: "ESKI: server o'qiy oladi"})),
      h("div", {class: "enc-cols"},
        h("div", {}, h("small", {text: "SIZ KO'RASIZ (qurilmada ochilgan)"}), h("div", {class: "enc-you", text: you})),
        h("div", {}, h("small", {text: "SERVER BAZASIDA"}), mono(r.stored, "net")),
        h("div", {}, h("small", {text: "ADMIN LOGIDA"}), mono(r.admin_sees, "net")))));
  });
  const li = arr => h("ul", {class: "enc-ul"}, ...arr.map(t => h("li", {text: t})));
  body.append(
    h("h4", {class: "enc-h", text: "Server biladi"}), li(j.knows.biladi),
    h("h4", {class: "enc-h", text: "Server bilmaydi"}), li(j.knows.bilmaydi),
    h("h4", {class: "enc-h", text: "Sizning yozuvingiz serverda"}),
    mono("Ommaviy kalit (ECDH): " + shortId(j.me.ecdh_pub) + "\nOmmaviy kalit (imzo): " + shortId(j.me.sign_pub) + "\nMaxfiy kalitlar zaxirasi: " + j.me.key_blob_bytes + " bayt, parolingiz kalitida shifrlangan — serverda ochib bo'lmaydi" +
      "\nGuruh kaliti (sizga o'ralgan nusxa): " + (j.room.my_wrap ? "avlod " + j.room.my_wrap.epoch + ", o'ragan: @" + (U(j.room.my_wrap.by).username || j.room.my_wrap.by) : "hali yo'q"), "net"),
    h("h4", {class: "enc-h", text: "Harakatlaringiz logi (adminga ko'rinadigan)"}),
    ...(j.activity.length ? j.activity.map(a => h("div", {class: "enc-act", text: fmtDT(a.ts) + " • " + a.ip + " • " + a.action + (a.detail ? " • " + a.detail : "")})) : [h("div", {class: "adm-empty", text: "Yozuv yo'q"})]),
    j.legacy_messages ? h("p", {class: "adm-note warn", text: "⚠ Bazada hali " + j.legacy_messages + " ta ESKI (E2EE'dan oldingi) xabar bor — ularni server o'qiy oladi. Ega ularni Moderatsiya bo'limidan o'chira oladi."}) : h("p", {class: "adm-note ok", text: "✅ Bazada server o'qiy oladigan xabar yo'q."}));
}

async function encKeys(body) {
  const cur = X.epoch;
  body.append(
    h("p", {class: "adm-note", text: "Barmoq izi — kalitingizning qisqa belgisi. Suhbatdoshingiz bilan uni boshqa kanalda (yuzma-yuz, telefon) solishtiring: mos kelsa, o'rtada hech kim yo'q."}),
    h("h4", {class: "enc-h", text: "Sizning barmoq izingiz"}), mono(X.fp || "—", "fp"),
    h("button", {class: "btn ghost sm", type: "button", text: "Nusxalash", onclick: () => copyText(X.fp)}),
    h("h4", {class: "enc-h", text: "Guruh kaliti"}),
    mono("Joriy avlod: " + (cur || "yo'q") + (X.rooms.has(cur) ? " • sizda bor • kalit ID: " + X.keyIds.get(cur) : " • sizda hali yo'q") + "\nSizda bor avlodlar: " + ([...X.rooms.keys()].join(", ") || "—")));
  const changed = [...X.changed.entries()];
  if (changed.length) {
    body.append(h("p", {class: "adm-note warn", text: "⚠ Quyidagi foydalanuvchilarning kaliti ilgari ko'rganingizdan FARQ QILADI. Bu server almashtirgan kalit bo'lishi mumkin. Barmoq izini tekshirmaguncha ularga yozmang."}));
    changed.forEach(([uid, c]) => body.append(h("div", {class: "enc-row"}, h("b", {text: "@" + U(uid).username}), mono("Avval: " + c.old + "\nHozir: " + c.now),
      h("button", {class: "btn danger sm", type: "button", text: "Yangi kalitni qabul qilish", onclick: () => { acceptKeyChange(uid); toast("Qabul qilindi", "ok"); renderHeader(); body.textContent = ""; encKeys(body); }}))));
  }
  body.append(h("h4", {class: "enc-h", text: "A'zolar barmoq izlari"}));
  const list = h("div", {}); body.append(list);
  const members = S.members.filter(m => m.ek && m.id !== S.me.id).slice(0, 80);
  for (const m of members) {
    try {
      const p = await peer(m.id);
      list.append(h("div", {class: "enc-mem"}, h("b", {text: m.nickname + " @" + m.username}), mono(p.fp + (p.changed ? "   ⚠ O'ZGARGAN" : ""), p.changed ? "bad" : "fp")));
    } catch (_) {}
  }
  if (!members.length) list.append(h("div", {class: "adm-empty", text: "Boshqa a'zo yo'q"}));
}

function encLimits(body) {
  const li = arr => h("ul", {class: "enc-ul"}, ...arr.map(t => h("li", {text: t})));
  body.append(
    h("p", {class: "adm-note", text: "Haqiqiy E2EE nimani kafolatlaydi va nimani kafolatlamaydi — halol ro'yxat:"}),
    h("h4", {class: "enc-h", text: "✅ Kafolat"}),
    li(["Server, hosting egasi va admin xabar matnini, fayl mazmunini va nomini o'qiy olmaydi: ular faqat shifrni ko'radi.",
        "Parolingiz serverga umuman bormaydi — faqat undan olingan qaytarib bo'lmaydigan kirish kaliti boradi. Maxfiy kalitlaringiz parol kalitida shifrlangan.",
        "Har bir xabar imzolangan: server yoki boshqa a'zo sizning nomingizdan soxta xabar yarata olmaydi.",
        "Ban qilingan a'zodan keyin guruh kaliti yangilanadi: u yangi xabarlarni o'qiy olmaydi."]),
    h("h4", {class: "enc-h", text: "⚠ Cheklovlar"}),
    li(["Guruhga qo'shilgan har kim (admin ham, agar a'zo bo'lsa) o'z qurilmasida xabarlarni ko'radi — bu ochiq guruh: ro'yxatdan o'tgan har kim kalit oladi.",
        "Server yashirincha SOXTA a'zo qo'shib, unga kalit o'ratishi mumkin. Himoya: «Kalitlar» bo'limida barmoq izlarini tekshiring; ilgari ko'rilgan kalit o'zgarsa, ogohlantirish chiqadi.",
        "Bu sahifaning kodini ham server beradi. Zararli server kodni almashtirishi mumkin: SRI faqat tashqi o'zgarishdan himoya qiladi. To'liq ishonch uchun kodni tekshiring yoki serverni o'zingiz yuriting.",
        "Metama'lumotlar ko'rinadi: kim, qachon, kimga (lichkada), xabar hajmi, IP. Profil (nickname, bio, rasm) ochiq.",
        "Parolni yo'qotsangiz, eski xabarlarni tiklab bo'lmaydi (kalit zaxirasi faqat parol bilan ochiladi).",
        "Lichkada «oldinga maxfiylik» yo'q (kalit doimiy). Shikoyat yuborganingizda faqat o'sha bitta xabar ixtiyoriy ochib beriladi."]));
}
$("encBtn").addEventListener("click", () => openInspector("flow"));

function openSettingsPage() {
  openPage(() => {
    const me = S.me, dark = document.documentElement.dataset.theme === "dark";
    const wrap = h("div", {}, pageHead("Sozlamalar"));
    wrap.append(h("button", {class: "set-card", type: "button", onclick: () => openProfile(me.id)},
      avatar(me, "m"), h("div", {class: "sc-t"}, h("b", {}, nameEl(me)), h("small", {text: "@" + me.username}))));
    wrap.append(gapEl(),
      setRow("user", "Mening akkauntim", openInfoPage),
      setRow("bell", "Bildirishnomalar va ovozlar", openNotifPage),
      setRow("battery", "Batareya va animatsiyalar", openAnimPage),
      setRow("box", "Inventar (missiya sovg'alari)", () => Missions.inventory()),
      setRow("edit", "Profil dizayni", () => openProfileEditor(S.me.id)),
      ...(amAdmin() ? [setRow("gear", "Server holati", openServerStatus)] : []),
      setRow("lock", "Maxfiylik va xavfsizlik", openPrivacyPage),
      setRow("emoji", "Reaksiya sozlamalari", openReactionSettings),
      setRow("speaker", "Karnay va kamera", openMediaPermPage),
      gapEl(),
      switchRow("moon", "Tungi mavzu", () => document.documentElement.dataset.theme === "dark", () => { toggleTheme(); }));
    wrap.append(gapEl(), setRow("logout", "Chiqish", () => { closeAllPages(); logout(); }, null, true));
    if (me.role !== "owner") wrap.append(setRow("trash", "Akkauntni o'chirish", deleteMyAccount, null, true));
    return wrap;
  }, true);
}

function openServerStatus() {
  openPage(p => {
    if (p._ss) { p._ss.stop(); }
    const fmtDur = sec => { sec = Math.max(0, Math.floor(sec)); const d = Math.floor(sec / 86400), hh = Math.floor(sec % 86400 / 3600), m = Math.floor(sec % 3600 / 60), ss = sec % 60;
      return (d ? d + " kun " : "") + (d || hh ? hh + " soat " : "") + (m || hh || d ? m + " daq " : "") + ss + " s"; };
    const pct = (a, b) => b ? Math.max(0, Math.min(100, a / b * 100)) : 0;
    const dash = "—";
    const mk = (title) => { const val = h("div", {class: "ss-v", text: dash}), sub = h("div", {class: "ss-s", text: ""}), bar = h("i"), track = h("div", {class: "ss-bar"}, bar);
      const el = h("div", {class: "ss-card"}, h("div", {class: "ss-t", text: title}), val, track, sub);
      return {el, val, sub, bar, track}; };
    const cards = {cpu: mk("Protsessor (CPU)"), mem: mk("Xotira (RAM)"), disk: mk("Disk"), ping: mk("Aloqa tezligi"), ws: mk("Jonli ulanishlar"), http: mk("So'rovlar"), db: mk("Baza (SQLite)"), up: mk("Ishlash vaqti")};
    ["ping", "ws", "http", "db", "up"].forEach(k => cards[k].track.classList.add("hidden"));
    const statePill = h("span", {class: "ss-pill", text: "Yuklanmoqda…"});
    const live = h("span", {class: "ss-live", text: "● jonli"});
    const spark = h("div", {class: "ss-spark"});
    const hist = [];
    const drawSpark = () => {
      if (hist.length < 2) return;
      const mx = Math.max(60, ...hist), pts = hist.map((v, i) => (i / (hist.length - 1) * 300).toFixed(1) + "," + (52 - v / mx * 48).toFixed(1)).join(" ");
      spark.innerHTML = '<svg viewBox="0 0 300 56" preserveAspectRatio="none"><polyline fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" vector-effect="non-scaling-stroke" points="' + pts + '"/></svg>';
    };
    const lvl = (el, v) => { el.classList.toggle("warn", v >= 70 && v < 90); el.classList.toggle("bad", v >= 90); };
    const note = h("p", {class: "adm-note", text: "Ko'rsatkichlar Render serverining o'zidan olinadi va har 2 soniyada yangilanadi. CPU — faqat shu ilova protsessi (1 yadro = 100%)."});
    const body = h("div", {class: "pg-body ss-body"},
      h("div", {class: "ss-top"}, statePill, live),
      h("div", {class: "ss-grid"}, cards.up.el, cards.ping.el, cards.cpu.el, cards.mem.el, cards.disk.el, cards.ws.el, cards.http.el, cards.db.el),
      h("div", {class: "ss-card ss-wide"}, h("div", {class: "ss-t", text: "Aloqa kechikishi (oxirgi 30 o'lchov, ms)"}), spark),
      note);
    const st = {on: true, busy: false, timer: 0, fails: 0, seen: false};
    const tick = async () => {
      if (!st.on) return;

      if (p.el && p.el.isConnected) st.seen = true;
      if (p.closing || (st.seen && !p.el.isConnected)) { stop(); return; }
      if (!st.seen) return;
      if (st.busy || document.hidden) return;
      st.busy = true;
      const t0 = performance.now();
      try {
        const d = await api("/admin/server-status");
        const rtt = performance.now() - t0; st.fails = 0;
        statePill.textContent = d.ok ? "✅ Server ishlayapti" : "⚠ Bazada muammo"; statePill.className = "ss-pill " + (d.ok ? "ok" : "bad");
        live.classList.remove("off");
        cards.up.val.textContent = fmtDur(d.uptime); cards.up.sub.textContent = "Versiya " + d.version + " • PID " + d.pid + " • oqimlar: " + d.threads;
        cards.ping.val.textContent = Math.round(rtt) + " ms"; cards.ping.val.className = "ss-v" + (rtt > 800 ? " bad" : rtt > 300 ? " warn" : "");
        cards.ping.sub.textContent = rtt > 800 ? "Juda sekin" : rtt > 300 ? "Sekinroq" : "Yaxshi";
        hist.push(Math.round(rtt)); if (hist.length > 30) hist.shift(); drawSpark();
        const c = d.cpu, cp = c.process_pct;
        cards.cpu.val.textContent = cp == null ? dash : cp.toFixed(1) + "%";
        cards.cpu.bar.style.width = Math.min(100, cp || 0) + "%"; lvl(cards.cpu.el, cp || 0);
        cards.cpu.sub.textContent = (c.load ? "Yuklama: " + c.load.map(x => x.toFixed(2)).join(" / ") + " • " : "") + c.cores + " yadro";
        const m = d.mem;
        if (m && m.total) { const pc = pct(m.used, m.total); cards.mem.val.textContent = fmtSize(m.used) + " / " + fmtSize(m.total); cards.mem.bar.style.width = pc + "%"; lvl(cards.mem.el, pc);
          cards.mem.sub.textContent = pc.toFixed(0) + "% band" + (m.process ? " • ilova: " + fmtSize(m.process) : ""); }
        else { cards.mem.val.textContent = m && m.process ? fmtSize(m.process) : dash; cards.mem.sub.textContent = "Ilova protsessi"; }
        const k = d.disk, dt = d.data || {};
        if (k) { const pc = pct(k.used, k.total); cards.disk.val.textContent = fmtSize(k.free) + " bo'sh"; cards.disk.bar.style.width = pc + "%"; lvl(cards.disk.el, pc);
          cards.disk.sub.textContent = "Ma'lumotlar: " + fmtSize(dt.total || 0) + " (baza " + fmtSize(dt.db || 0) + ", media " + fmtSize((dt.media || 0) + (dt.uploads || 0)) + ", emoji " + fmtSize(dt.emoji || 0) + ")"; }
        const w = d.ws; cards.ws.val.textContent = w.connections + " ulanish"; cards.ws.sub.textContent = "Onlayn: " + w.online + " • yashirin (away): " + w.away + " • eng ko'pi: " + w.peak;
        const r = d.http; cards.http.val.textContent = r.rps.toFixed(1) + " /s"; cards.http.sub.textContent = "Jami: " + r.total + " • xatolar (5xx): " + r.errors;
        const b = d.db; cards.db.val.textContent = b.ok ? b.ping_ms.toFixed(1) + " ms" : "XATO"; cards.db.val.className = "ss-v" + (b.ok ? "" : " bad");
        cards.db.sub.textContent = b.users + " foydalanuvchi • " + b.messages + " xabar • " + b.sessions + " sessiya";
      } catch (err) {
        if (err.message === "401") { stop(); return; }
        st.fails++; statePill.textContent = "❌ Server javob bermayapti"; statePill.className = "ss-pill bad"; live.classList.add("off");
      } finally { st.busy = false; }
    };
    const onVis = () => { if (!document.hidden && st.on) tick(); };
    const stop = () => { st.on = false; clearInterval(st.timer); document.removeEventListener("visibilitychange", onVis); };
    p._ss = {stop};
    st.timer = setInterval(tick, 2000);
    requestAnimationFrame(() => requestAnimationFrame(tick));
    document.addEventListener("visibilitychange", onVis);
    return h("div", {}, pageHead("Server holati"), body);
  });
}

function openInfoPage() {
  openPage(p => {
    const me = S.me;
    const avBox = h("div", {class: "tg-top inf-top"});
    const paintAvatar = () => {
      avBox.textContent = "";
      avBox.append(h("div", {class: "inf-av"}, avatar(S.me, "l"),
        h("button", {class: "inf-cam", type: "button", "aria-label": "Profil rasmini o'zgartirish", onclick: () => $("file").click()}, icon("camera"))));
    };
    paintAvatar();
    const gal = h("div", {class: "gal inf-gal"});
    const nick = h("input", {type: "text", class: "fld", maxlength: "24", "aria-label": "Nickname"}); nick.value = me.nickname;
    const bio = h("textarea", {class: "fld", rows: "3", maxlength: "140", placeholder: "O'zingiz haqingizda…", "aria-label": "Bio"}); bio.value = me.bio || "";
    const cnt = h("span", {class: "inf-cnt", text: String(140 - bio.value.length)});
    bio.addEventListener("input", () => { cnt.textContent = String(140 - bio.value.length); });
    const loadGallery = async () => {
      try {
        const j = await api("/avatars");
        gal.textContent = "";
        j.avatars.forEach(a => {
          const del = h("button", {type: "button", title: "O'chirish", "aria-label": "O'chirish"}, icon("close"));
          del.addEventListener("click", async e => { e.stopPropagation(); try { await api("/avatars/" + a.id, {method: "DELETE"}); loadGallery(); } catch (err) { toast(err.message, "error"); } });
          const g = h("div", {class: "gi" + (a.active ? " act" : ""), title: a.active ? "Faol rasm" : "Faollashtirish"}, h("img", {src: a.url, alt: ""}), del);
          g.addEventListener("click", async () => { if (a.active) return; try { await api("/avatars/" + a.id + "/use", {method: "POST"}); loadGallery(); } catch (err) { toast(err.message, "error"); } });
          gal.append(g);
        });
        if (j.avatars.some(a => a.active)) gal.append(h("button", {class: "btn ghost sm", type: "button", onclick: async () => { try { await api("/avatar/clear", {method: "POST"}); loadGallery(); } catch (err) { toast(err.message, "error"); } }}, "Rasmni olib tashlash"));
        setTimeout(paintAvatar, 500);
      } catch (_) {}
    };
    S.reloadGallery = loadGallery; loadGallery();
    const save = async btn => {
      btn.disabled = true;
      try {
        const j = await api("/profile", {method: "PATCH", body: {nickname: nick.value, bio: bio.value}});
        if (j && j.me) { upsertUser(j.me); renderList(); renderHeader(); renderMessages(false); }
        toast("Profil saqlandi", "ok");
      } catch (err) { toast(err.message, "error"); }
      btn.disabled = false;
    };
    p.refresh = paintAvatar;
    return h("div", {}, pageHead("Ma'lumot"), avBox, gal,
      h("div", {class: "inf-form"},
        h("label", {class: "fl"}, "Nickname", nick),
        h("div", {class: "fl"}, h("span", {class: "inf-lab"}, "Bio", cnt), bio, h("small", {class: "inf-hint", text: "Yosh, kasb yoki shahar kabi qisqa ma'lumot. Havola (https://…) va @username qo'ysangiz, profilingizda bosiladigan bo'ladi."})),
        h("div", {class: "tg-row copy", role: "button", tabindex: "0", title: "Nusxalash", onclick: () => copyText("@" + me.username)},
          h("div", {class: "tg-val", text: "@" + me.username}), h("div", {class: "tg-lab", text: "Username (o'zgarmaydi)"})),
        h("button", {class: "btn", type: "button", onclick: e => save(e.currentTarget)}, "Saqlash")),
      isStaff(me) ? h("div", {class: "inf-look"}, lookSection()) : null);
  });
}

function openAnimPage() {
  openPage(() => {
    const AP = window.AnimPrefs;
    const sw = (ic, title, k, hint) => switchRow(ic, title, () => AP.on(k), on => { AP.set(k, on); }, hint);
    return h("div", {}, pageHead("Batareya va animatsiyalar"),
      sw("emoji", "Animatsion stikerlar", "stk",
        "O'chirilsa, stikerlar harakatlanmaydi — animatsiyasiz, oddiy rasm kabi ko'rinadi."),
      sw("emoji", "Animatsion emojilar", "emo",
        "O'chirilsa, animatsiyali emojilar harakatlanmaydi — oddiy emoji kabi ko'rinadi."),
      sw("battery", "Interfeys animatsiyalari", "ui",
        "O'chirilsa, oynalar, menyular, xabarlar va tugmalardagi animatsiyalar o'chiriladi."),
      h("p", {class: "tg-hint", text: "Animatsiyalarni o'chirish batareyani tejaydi va kuchsizroq qurilmalarda ilovani tezlashtiradi. Bu sozlamalar faqat shu qurilmada saqlanadi."}));
  });
}

function openNotifPage() {
  openPage(() => {
    const st = Push.state();
    const pushHint = !st.ok ? (st.why === "ios-install" ? "iPhone'da avval ilovani bosh ekranga o'rnating (Ulashish → Bosh ekranga qo'shish)." : "Bu brauzer bildirishnomalarni qo'llab-quvvatlamaydi.")
      : st.permission === "denied" ? "Bildirishnomalar brauzer sozlamalarida bloklangan. Sayt sozlamalaridan ruxsat bering."
      : "Yoqilsa, brauzer yopiq bo'lsa ham xabar keladi. Xabar matni bildirishnomada ko'rsatilmaydi.";
    return h("div", {}, pageHead("Bildirishnomalar va ovozlar"),
      switchRow("bell", "Bildirishnomalar", () => Push.state().on, async on => {
        if (on) { await Push.enable(api); toast("Bildirishnomalar yoqildi", "ok"); }
        else { await Push.disable(api); toast("Bu qurilmada bildirishnomalar o'chirildi", "info"); }
      }, pushHint),
      gapEl(),
      switchRow("speaker", "Xabar ovozi", sndOn, on => {
        try { localStorage.setItem(LS_SND, on ? "on" : "off"); } catch (_) {}
        if (on) ting(true);
      }, "Ilova ochiq bo'lganda boshqa suhbatga xabar kelsa qisqa ovoz chiqadi."));
  });
}

async function changePassword(oldPw, newPw) {
  if (!oldPw) throw new Error("Eski parolni kiriting");
  if (newPw.length < 6) throw new Error("Yangi parol kamida 6 belgi bo'lishi kerak");
  const info = await api("/me"), e = info.e2ee, un = S.me.username;
  const ko = await E2E.deriveFromPassword(un, oldPw, e.kdf_iter || E2E.KDF_DEFAULT);
  let ident; try { ident = await E2E.unwrapIdentity(e.key_blob, ko.kek, un); } catch (_) { throw new Error("Eski parol noto'g'ri"); }
  const kn = await E2E.deriveFromPassword(un, newPw, E2E.KDF_DEFAULT);
  await api("/password", {method: "POST", body: {old: ko.auth, new: kn.auth, key_blob: await E2E.wrapIdentity(ident, kn.kek, un), kdf_iter: E2E.KDF_DEFAULT}});
}

function fmtSpan(sec) {
  sec = Math.max(0, Math.floor(sec));
  const d = Math.floor(sec / 86400), hr = Math.floor(sec % 86400 / 3600), m = Math.floor(sec % 3600 / 60);
  if (d) return d + " kun " + hr + " soat";
  if (hr) return hr + " soat " + m + " daq";
  if (m) return m + " daqiqa";
  return "1 daqiqadan kam";
}

async function setPrivacy(patchObj) {
  S.priv = await api("/privacy", {method: "POST", body: patchObj});
}
function openPrivacyPage() {
  api("/privacy").then(j => { S.priv = j; const p = PG.list[PG.list.length - 1]; if (p && p.el.textContent.includes("Maxfiylik va xavfsizlik")) paintPage(p); }).catch(() => {});
  openPage(p => {
    p.refresh = null;
    return h("div", {}, pageHead("Maxfiylik va xavfsizlik"),
      secTitle("Kirish"),
      switchRow("lock", "Har kirishda login so'rash", () => !stayOn(), async () => { await toggleStay(); },
        "Yoqilsa, sahifa har safar ochilganda username va parol so'raladi. O'chirilsa, bu qurilmada login so'ralmasdan kirasiz — qurilmani begonalarga bermang."),
      gapEl(),
      secTitle("Ko'rinish"),
      switchRow("eye", "Last seen ni ko'rsatish", () => !(S.priv && S.priv.hide_seen), async on => { await setPrivacy({hide_seen: !on}); },
        "O'chirilsa, boshqalar oxirgi marta qachon onlayn bo'lganingizni ko'rmaydi («yaqinda onlayn bo'lgan» deb chiqadi). Onlayn holatingiz o'zgarmaydi."),
      switchRow("ghost", "Yashirin profil rejimi", () => !!(S.priv && S.priv.ghost), async on => { await setPrivacy({ghost: on}); },
        "Yoqilsa, siz doim oflayn ko'rinasiz: onlayn holat, last seen va «yozmoqda…» belgilari boshqalarga ko'rinmaydi. Siz xabarlarni odatdagidek yozasiz va o'qiysiz."),
      gapEl(),
      secTitle("Xabarlar"),
      switchRow("timer", "Xabarlarimni avtomatik o'chirish", () => !!(S.priv && S.priv.auto_del), async on => {
        if (on && !await confirmDlg("Shu paytdan boshlab yozgan xabarlaringiz 24 soatdan keyin hammada o'chib ketadi. Bu qaytarilmaydi.", {title: "Avtomatik o'chirish", okText: "Yoqish"})) return;
        await setPrivacy({auto_del: on});
      }, "Yoqilsa, shundan keyin yozgan xabarlaringiz 24 soatdan so'ng o'zi o'chadi. Yoqishdan oldingi xabarlarga tegilmaydi. Muddatidan oldin o'chirsangiz ham, yoqilgan va o'chirilgan vaqt orasida yozilgan xabarlar o'z vaqtida tozalanadi."),
      switchRow("ban", "Menga yozishni cheklash", () => !!(S.priv && S.priv.dm_closed), async on => { await setPrivacy({dm_closed: on}); },
        "Yoqilsa, sizga shaxsiy xabarni faqat admin yoza oladi. Siz o'zingiz yozgan odam esa sizga javob yoza oladi. O'chirilsa, hamma yoza oladi."),
      gapEl(),
      secTitle("Xavfsizlik"),
      setRow("key", "Parolni almashtirish", openChangePasswordPage),
      setRow("devices", "Ulangan qurilmalar", openDevicesPage),
      h("p", {class: "tg-hint", text: "Akkauntingizga qaysi qurilmalardan kirilganini ko'ring va keraklisini o'zingiz chiqarib yuboring."}));
  });
}

function openChangePasswordPage() {
  openPage(() => {
    const fld = (label, ac) => { const i = h("input", {type: "password", class: "fld", autocomplete: ac, maxlength: "128", "aria-label": label}); return {i, lab: h("label", {class: "fl"}, label, i)}; };
    const old = fld("Eski parol", "current-password"), nw = fld("Yangi parol (kamida 6 belgi)", "new-password"), rep = fld("Yangi parolni qayta kiriting", "new-password");
    const msg = h("p", {class: "tg-hint flat", role: "alert"});
    const btn = h("button", {class: "btn", type: "button", text: "Parolni almashtirish"});
    const submit = async () => {
      msg.textContent = ""; msg.style.color = "";
      const fail = t => { msg.textContent = t; msg.style.color = "var(--err)"; };
      if (!old.i.value) return fail("Eski parolni kiriting");
      if (nw.i.value.length < 6) return fail("Yangi parol kamida 6 belgi bo'lishi kerak");
      if (nw.i.value !== rep.i.value) return fail("Yangi parollar bir-biriga mos kelmadi");
      if (nw.i.value === old.i.value) return fail("Yangi parol eskisidan farq qilishi kerak");
      btn.disabled = true; btn.textContent = "Almashtirilmoqda…";
      try {
        await changePassword(old.i.value, nw.i.value);
        toast("Parol almashtirildi. Boshqa qurilmalardan chiqarildingiz", "ok");
        closePage();
      } catch (err) { fail(err.message); btn.disabled = false; btn.textContent = "Parolni almashtirish"; }
    };
    btn.addEventListener("click", submit);
    [old, nw, rep].forEach(f => f.i.addEventListener("keydown", e => { if (e.key === "Enter") submit(); }));
    return h("div", {}, pageHead("Parolni almashtirish"),
      h("div", {class: "inf-form"}, old.lab, nw.lab, rep.lab, msg, btn),
      h("p", {class: "tg-hint", text: "Parol almashtirilganda shifrlash kalitlaringiz yangi parol bilan brauzerda qayta o'raladi, boshqa barcha qurilmalar akkauntdan chiqariladi."}));
  });
}

function openDevicesPage() {
  openPage(p => {
    const box = h("div", {class: "dev-list"}, h("div", {class: "none", text: "Yuklanmoqda…"}));
    const load = async () => {
      try {
        const j = await api("/sessions");
        box.textContent = "";
        const cur = j.sessions.find(s => s.current), others = j.sessions.filter(s => !s.current);
        const item = s => h("div", {class: "dev-i"},
          icon(/iPhone|iPad|Android/.test(s.device) ? "phone" : "devices"),
          h("div", {class: "dev-t"},
            h("b", {text: s.device + (s.current ? " (shu qurilma)" : "")}),
            h("small", {text: "Kirgan: " + fmtDay(s.created)}),
            h("small", {text: s.online ? "Hozir onlayn" : "Oxirgi faollik: " + ago(s.last_active)}),
            h("small", {text: "Onlayn bo'lgan vaqt: " + fmtSpan(s.duration)})),
          s.current ? null : h("button", {class: "btn ghost sm", type: "button", onclick: async ev => {
            if (!await confirmDlg(s.device + " qurilmasi akkauntdan chiqariladi.", {title: "Qurilmani chiqarish", okText: "Chiqarish", danger: true})) return;
            ev.target.disabled = true;
            try { await api("/sessions/" + s.id, {method: "DELETE"}); toast("Qurilma chiqarildi", "ok"); } catch (err) { toast(err.message, "error"); }
            load();
          }}, "Chiqarish"));
        if (cur) box.append(secTitle("Hozirgi qurilma"), item(cur));
        box.append(secTitle("Boshqa qurilmalar", others.length));
        if (!others.length) box.append(h("div", {class: "none", text: "Boshqa qurilmalar ulanmagan"}));
        others.forEach(s => box.append(item(s)));
        if (others.length) box.append(h("div", {class: "tg-modwrap"}, h("button", {class: "btn danger sm", type: "button", onclick: async () => {
          if (!await confirmDlg("Hozirgisidan boshqa barcha qurilmalar akkauntdan chiqariladi.", {title: "Boshqa qurilmalardan chiqish", okText: "Hammasini chiqarish", danger: true})) return;
          try { await api("/sessions/revoke-others", {method: "POST"}); toast("Boshqa qurilmalar chiqarildi", "ok"); } catch (err) { toast(err.message, "error"); }
          load();
        }}, "Boshqa barcha qurilmalardan chiqish")));
      } catch (err) { box.textContent = ""; box.append(h("div", {class: "none", text: err.message})); }
    };
    p.refresh = null;
    load();
    const timer = setInterval(() => { if (!p.el.isConnected || p.closing) clearInterval(timer); else load(); }, 30000);
    return h("div", {}, pageHead("Ulangan qurilmalar"), box);
  });
}

function openReactionSettings() {
  openPage(() => {
    const mk = e => {
      const b = h("button", {class: "rx-opt" + (e === rxPrefs.emoji ? " on" : ""), type: "button", "aria-label": e}, rxGlyph(e));
      b.addEventListener("click", () => {
        rxPrefs.emoji = e; rxSave();
        pv.querySelectorAll(".rx-opt").forEach(x => x.classList.toggle("on", x === b));
        const r = b.getBoundingClientRect(); rxBurst(e, r.left + r.width / 2, r.top);
      });
      return b;
    };
    const pv = rxPackView(mk, {k: null}, "rx-grid");
    const grid = h("div", {class: "rx-gwrap" + (rxPrefs.dbl ? "" : " off")}, pv);
    return h("div", {}, pageHead("Reaksiya sozlamalari"),
      switchRow("emoji", "Ikki marta bosganda reaksiya", () => rxPrefs.dbl, on => { rxPrefs.dbl = on; rxSave(); grid.classList.toggle("off", !on); },
        "Xabar yoki post ustiga ketma-ket 2 marta bosilsa, pastdagi reaksiya qo'yiladi. O'chirilsa, reaksiyani xabar menyusidan tanlaysiz."),
      gapEl(),
      h("div", {class: "inf-form"}, h("div", {class: "sec-t flat"}, h("span", {text: "Ikki marta bosganda qo'yiladigan reaksiya"})), grid,
        h("p", {class: "tg-hint flat", text: "Bir xabarga bitta reaksiya qo'yiladi. Reaksiya ustiga bosib uni olib tashlash yoki almashtirish mumkin."})));
  });
}

const PERM_TXT = {granted: "Ruxsat berilgan", denied: "Bloklangan", prompt: "Hali so'ralmagan", unknown: "Noma'lum"};
async function permState(name) { try { return (await navigator.permissions.query({name})).state; } catch (_) { return "unknown"; } }
async function requestPerm(kind) {
  if (kind === "notifications") {
    if (!("Notification" in window)) throw new Error("Bu brauzer bildirishnomalarni qo'llab-quvvatlamaydi");
    const r = await Notification.requestPermission();
    if (r !== "granted") throw new Error("Ruxsat berilmadi");
    return;
  }
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) throw new Error("Bu brauzer kamera/mikrofonni qo'llab-quvvatlamaydi (yoki sahifa HTTPS emas)");
  try {
    const s = await navigator.mediaDevices.getUserMedia(kind === "camera" ? {video: true} : {audio: true});
    s.getTracks().forEach(t => t.stop());
  } catch (err) { throw new Error(err && err.name === "NotFoundError" ? "Bunday qurilma topilmadi" : "Ruxsat berilmadi. Brauzerning sayt sozlamalaridan ruxsat bering"); }
}
function openMediaPermPage() {
  openPage(() => {
    const perms = h("div", {}), devs = h("div", {});
    const defs = [["camera", "videocam", "Kamera", "camera"], ["microphone", "mic", "Mikrofon", "microphone"], ["notifications", "bell", "Bildirishnomalar", "notifications"]];
    const load = async () => {
      const rows = [];
      for (const [name, ic, label, kind] of defs) {
        const stt = await permState(name === "notifications" ? "notifications" : name);
        const granted = stt === "granted";
        rows.push(h("div", {class: "perm-i"}, icon(ic), h("div", {class: "perm-t"}, h("b", {text: label}), h("small", {class: "st-" + stt, text: PERM_TXT[stt] || PERM_TXT.unknown})),
          granted
            ? h("button", {class: "btn ghost sm", type: "button", onclick: () => confirmDlg("Brauzer ruxsatni sahifaning o'zidan olib tashlashga yo'l qo'ymaydi. Brauzerda: manzil satridagi qulf (yoki sozlamalar) belgisi → Sayt sozlamalari → «" + label + "» ni «Bloklash» yoki «So'rash» ga o'zgartiring.", {title: label + ": ruxsatni o'chirish", okText: "Tushunarli"})}, "O'chirish")
            : stt === "denied"
              ? h("button", {class: "btn ghost sm", type: "button", onclick: () => confirmDlg("Ruxsat brauzerda bloklangan. Qulf belgisi → Sayt sozlamalari → «" + label + "» ni «Ruxsat berish» ga o'zgartiring, so'ng sahifani yangilang.", {title: label + ": bloklangan", okText: "Tushunarli"})}, "Qanday?")
              : h("button", {class: "btn sm", type: "button", onclick: async () => { try { await requestPerm(kind); toast(label + ": ruxsat berildi", "ok"); } catch (err) { toast(err.message, "error"); } load(); }}, "Ruxsat berish")));
      }
      perms.textContent = ""; perms.append(...rows);
      devs.textContent = "";
      let list = [];
      try { list = navigator.mediaDevices && navigator.mediaDevices.enumerateDevices ? await navigator.mediaDevices.enumerateDevices() : []; } catch (_) {}
      const group = (kindName, ic, title) => {
        const items = list.filter(d => d.kind === kindName);
        devs.append(secTitle(title, items.length));
        if (!items.length) devs.append(h("div", {class: "perm-none", text: kindName === "audiooutput" ? "Brauzer karnaylar ro'yxatini ko'rsatmaydi (standart karnay ishlatiladi)" : "Qurilma topilmadi"}));
        items.forEach((d, i) => devs.append(h("div", {class: "tg-row"}, icon(ic), h("span", {text: d.label || (title.replace(/lar$/, "") + " " + (i + 1) + " (nomi ruxsatdan keyin ko'rinadi)")}))));
      };
      group("audioinput", "mic", "Mikrofonlar"); group("videoinput", "videocam", "Kameralar"); group("audiooutput", "speaker", "Karnaylar");
    };
    load();
    return h("div", {}, pageHead("Karnay va kamera"), secTitle("Ruxsatlar"), perms,
      h("p", {class: "tg-hint", text: "Kamera va mikrofon faqat ovozli yoki video xabar yozganingizda ishlatiladi."}), gapEl(), devs);
  });
}

async function deleteMyAccount() {
  const ok = await confirmDlg("Akkauntingiz butunlay o'chiriladi: profil, rasmlar va parol yo'qoladi. Yozgan xabarlaringiz chatda \"Deleted account\" nomi bilan qoladi. Buni qaytarib bo'lmaydi.",
    {title: "Akkauntni o'chirish", okText: "Davom etish", danger: true});
  if (!ok) return;
  const pw = await promptDlg("Parolni tasdiqlang", "Akkauntni o'chirish uchun parolingizni kiriting:", "", {type: "password", okText: "O'chirish", danger: true});
  if (pw === null) return;
  try {
    const e = (await api("/me")).e2ee, kd = await E2E.deriveFromPassword(S.me.username, pw, e.kdf_iter || E2E.KDF_DEFAULT);
    await api("/account/delete", {method: "POST", body: {password: kd.auth}}); showAuth("Akkauntingiz o'chirildi");
  }
  catch (err) { toast(err.message, "error"); }
}
const PRESETS = ["#f7b733", "#7b61ff", "#ef4444", "#f97316", "#22c55e", "#14b8a6", "#3b82f6", "#ec4899"];
function colorSection(onChange) {
  const sec = h("div", {class: onChange ? "bd-colors" : "setsec"}, onChange ? h("div", {class: "bd-lab", text: "Ism rangi"}) : h("h4", {text: "Profil rangi"}));
  const preview = onChange ? null : h("div", {class: "pname"}), sw = h("div", {class: "swatches"});
  if (preview) { preview.style.fontSize = "17px"; preview.style.margin = "0 0 10px"; }
  hScroll(sw);
  const save = async c => {
    try {
      const j = await api("/profile", {method: "PATCH", body: {color: c}});
      upsertUser(j.me); paint(); renderList(); renderHeader(); renderMessages(false);
      if (onChange) onChange();
      toast(c ? "Rang saqlandi" : "Standart rang tiklandi", "ok");
    } catch (err) { toast(err.message, "error"); }
  };
  const paint = () => {
    if (preview) { preview.textContent = ""; preview.append(nameEl(S.me, {big: true})); }
    sw.textContent = "";
    const cur = (S.me.color || "").toLowerCase();
    PRESETS.forEach(c => {
      const b = h("button", {type: "button", class: "sw" + (cur === c ? " on" : ""), title: c, "aria-label": c});
      b.style.background = c; b.addEventListener("click", () => save(c)); sw.append(b);
    });
    const pick = h("input", {type: "color"}); pick.value = HEX.test(cur) ? cur : TONES[S.me.role];
    pick.addEventListener("change", () => save(pick.value));
    sw.append(h("label", {class: "sw-custom", title: "Boshqa rang tanlash"}, pick),
      h("button", {type: "button", class: "btn ghost sm", text: "Standart", onclick: () => save("")}));
  };
  paint(); sec.append(...(preview ? [preview] : []), sw);
  return sec;
}
$("file").addEventListener("change", async () => {
  const f = $("file").files[0]; $("file").value = ""; if (!f) return;
  if (f.size > 2 * 1024 * 1024) { toast("Rasm 2 MB dan oshmasligi kerak", "error"); return; }
  const fd = new FormData(); fd.append("file", f);
  try { await api("/avatar", {method: "POST", body: fd}); toast("Profil rasmi yangilandi", "ok"); if (S.reloadGallery) S.reloadGallery(); }
  catch (err) { toast(err.message, "error"); }
});

