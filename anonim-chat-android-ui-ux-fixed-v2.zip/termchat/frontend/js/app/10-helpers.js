function h(tag, props, ...kids) {
  const e = document.createElement(tag);
  if (props) for (const [k, v] of Object.entries(props)) {
    if (v == null || v === false) continue;
    if (k === "class") e.className = v;
    else if (k === "text") e.textContent = v;
    else if (k.startsWith("on")) e.addEventListener(k.slice(2), v);
    else e.setAttribute(k, v === true ? "" : v);
  }
  for (const c of kids.flat()) {
    if (c == null || c === false) continue;
    e.append(c.nodeType ? c : document.createTextNode(String(c)));
  }
  return e;
}
function svgUse(href, cls) {
  const s = document.createElementNS(NS, "svg"); s.setAttribute("class", cls);
  const u = document.createElementNS(NS, "use"); u.setAttribute("href", href); s.append(u);
  return s;
}
const icon = (name, cls) => svgUse("#i-" + name, cls || "ic");
const pad2 = n => String(n).padStart(2, "0");
const hhmm = ts => { const d = new Date(ts * 1000); return pad2(d.getHours()) + ":" + pad2(d.getMinutes()); };
const dayKey = ts => { const d = new Date(ts * 1000); return d.getFullYear() + "-" + d.getMonth() + "-" + d.getDate(); };
function dayLabel(ts) {
  const d = new Date(ts * 1000), now = new Date();
  if (dayKey(ts) === dayKey(now / 1000)) return "Bugun";
  const y = new Date(now); y.setDate(now.getDate() - 1);
  if (dayKey(ts) === dayKey(y / 1000)) return "Kecha";
  return d.getDate() + "-" + MONTHS[d.getMonth()] + (d.getFullYear() !== now.getFullYear() ? ", " + d.getFullYear() : "");
}
function listTime(ts) {
  const d = new Date(ts * 1000), now = new Date();
  if (dayKey(ts) === dayKey(now / 1000)) return hhmm(ts);
  const y = new Date(now); y.setDate(now.getDate() - 1);
  if (dayKey(ts) === dayKey(y / 1000)) return "Kecha";
  return pad2(d.getDate()) + "." + pad2(d.getMonth() + 1) + "." + String(d.getFullYear()).slice(2);
}
const colorOf = id => PALETTE[Math.abs(id) % PALETTE.length];
const isStaff = u => !!u && (u.role === "owner" || u.role === "admin");
const HEX = /^#[0-9a-f]{6}$/i, TONES = {owner: "#f7b733", admin: "#7b61ff"};
const hexRgb = x => { const n = parseInt(x.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
const mixHex = (x, to, t) => "#" + hexRgb(x).map((v, i) => Math.round(v + (to[i] - v) * t).toString(16).padStart(2, "0")).join("");
function toneOf(u) {
  const base = HEX.test(u.color || "") ? u.color.toLowerCase() : TONES[u.role];
  const [r, g, b] = hexRgb(base);
  return {p2: base, p1: mixHex(base, [255, 255, 255], .55), p3: mixHex(base, [0, 0, 0], .4), pr: r + "," + g + "," + b,
    pt: (0.299 * r + 0.587 * g + 0.114 * b) / 255 > .6 ? "#2b2000" : "#fff"};
}

function tint(el, u) {
  if (!isStaff(u)) return el;
  const t = toneOf(u);
  ["p1", "p2", "p3", "pr", "pt"].forEach(k => el.style.setProperty("--" + k, t[k]));
  return el;
}
const roleLabel = r => r === "owner" ? "Platforma egasi" : r === "admin" ? "Administrator" : "";
const U = id => S.users.get(id) || {id, nickname: "Noma'lum", username: "?", role: "user", bio: "", avatar: null};
const isOnline = id => S.me && (id === S.me.id || S.online.has(id));
const onlineCount = () => new Set([...S.online, S.me.id]).size;
const amAdmin = () => isStaff(S.me);
const dmOf = uid => {
  if (!S.dms.has(uid)) S.dms.set(uid, {msgs: [], loaded: false, buffer: [], unread: 0, last: null, more: false});
  return S.dms.get(uid);
};
const chOf = id => {
  if (!S.chn.has(id)) S.chn.set(id, {msgs: [], loaded: false, buffer: [], unread: 0, last: null, more: false});
  return S.chn.get(id);
};
const chInfo = id => S.chList.find(c => c.id === id) || null;
const isActiveChan = id => !!S.active && S.active.kind === "channel" && S.active.id === id;
function upsertUser(u) {
  if (!u || u.id == null) return;
  const merged = Object.assign({}, S.users.get(u.id), u);
  S.users.set(u.id, merged);
  if (S.me && u.id === S.me.id) S.me = Object.assign({}, S.me, u);
}

function toast(text, level) {
  const t = h("div", {class: "toast " + (level || "info"), text});
  $("toasts").append(t);
  while ($("toasts").children.length > 4) $("toasts").firstChild.remove();
  setTimeout(() => t.remove(), level === "error" ? 5000 : 3500);
}

async function api(path, opts = {}) {
  const headers = Object.assign({Authorization: "Bearer " + S.token}, opts.headers || {});
  let body = opts.body;
  if (body && !(body instanceof FormData)) { headers["Content-Type"] = "application/json"; body = JSON.stringify(body); }
  const r = await SC.fetch("/api" + path, {method: opts.method || "GET", headers, body});
  const j = await r.json().catch(() => ({}));
  if (r.status === 401) { showAuth("Sessiya tugagan, qayta kiring"); throw new Error("401"); }
  if (!r.ok) throw new Error(typeof j.detail === "string" ? j.detail : "Xato, qayta urinib ko'ring");
  return j;
}
function wsTry(obj) {
  if (S.offline || !S.ws || S.ws.readyState !== 1) return false;
  try { S.ws.send(JSON.stringify(obj)); return true; } catch (_) { return false; }
}
function wsSend(obj) {
  if (S.offline) { toast("Oflayn rejim: faqat o'qish mumkin", "error"); return false; }
  if (!S.ws || S.ws.readyState !== 1) { toast("Ulanish yo'q, biroz kuting…", "error"); return false; }
  S.ws.send(JSON.stringify(obj));
  return true;
}

