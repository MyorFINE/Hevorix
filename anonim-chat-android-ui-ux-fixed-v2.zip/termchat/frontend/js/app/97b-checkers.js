// Rus shashkasi (Gaming bo'limi). Bitta ekran, ikki rejim: "online" (haqiqiy o'yinchi, server qoidalarni tekshiradi) va "bot" (qurilmada, internet shart emas).
// Qoidalar dvigateli: js/checkers.js (window.TCDraughts) — server bilan bir xil.
const Checkers = (() => {
  const LS_GAME = "tc_offck", LS_CFG = "tc_offck_cfg", LS_STAT = "tc_offck_stat";
  const STEP = 300;
  const LV_INFO = {1: "Ko'p xato qiladi — o'rganish uchun", 2: "Ba'zan xato qiladi", 3: "Oddiy o'yinchidek", 4: "Taktikani yaxshi ko'radi", 5: "Eng kuchli • o'ylash uzoqroq"};
  const REASON = {
    no_moves: "Yurish qolmadi", repetition: "Bir xil holat uch marta takrorlandi", kings15: "15 yurish davomida faqat damkalar yurdi",
    timeout: "Vaqt tugadi", abandon: "Aloqa uzilib qoldi", abort: "O'yin boshlanmadi — bekor qilindi",
  };
  let START = "";
  for (let i = 0; i < 64; i++) { const r = i >> 3, f = i & 7; START += (f + r) % 2 === 0 ? (r < 3 ? "w" : r > 4 ? "b" : ".") : "."; }
  const sqName = i => "abcdefgh"[i & 7] + ((i >> 3) + 1);
  const sqIdx = s => (s.charCodeAt(1) - 49) * 8 + s.charCodeAt(0) - 97;
  const lsGet = (k, d) => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (_) { return d; } };
  const lsSet = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (_) {} };
  const lsDel = k => { try { localStorage.removeItem(k); } catch (_) {} };
  const snd = (n, ...a) => { try { Gaming.snd[n](...a); } catch (_) {} };
  const eng = () => window.TCDraughts;
  const ckIcon = () => h("span", {class: "ck-ico"}, h("i"), h("i"));

  const C = {
    el: null, main: null, mode: null, me: "w", bd: START.split(""), dom: new Array(64).fill(null), sqs: [], layer: null, boardEl: null,
    sel: null, path: [], drag: null, waiting: false, wt: 0, legal: {}, turn: "w", last: null, hint: null, sheet: null,
    hist: [], histKey: "", boards: [START], mv: [], view: null, hs: null, hList: null, hPrev: null, hNext: null, hLive: null,
    top: null, bot: null, undoBtn: null, hintBtn: null,
    st: null, out: null, inc: null, incTimer: 0, tick: 0, clock: null, overFor: null, tickSec: 0, overCard: null,
    g: null, worker: null, wOk: true, req: 0, pending: new Map(), botTimer: 0,
  };
  const send = o => { if (wsTry(o)) return true; toast("Ulanish yo'q, biroz kutib qayta urinib ko'ring", "error"); return false; };
  const online = () => C.mode === "online" && !!C.st;
  const botGame = () => C.mode === "bot" && !!C.g;

  // ---------- taxta ----------
  const xy = i => { const f = i & 7, r = i >> 3; return C.me === "b" ? [7 - f, r] : [f, 7 - r]; };
  function place(el, i) { const [x, y] = xy(i); el.dataset.x = x; el.dataset.y = y; el.style.transform = "translate(" + x * 100 + "%," + y * 100 + "%)"; }
  function mkPiece(ch, i) {
    const king = ch === "W" || ch === "B", white = ch.toLowerCase() === "w";
    const el = h("div", {class: "gp " + (white ? "cw" : "cb") + (king ? " k" : "")}, h("i", {class: "ckd"}, h("b", {text: "♛"})));
    place(el, i); return el;
  }
  function rebuildPieces() {
    C.layer.textContent = ""; C.dom.fill(null);
    for (let i = 0; i < 64; i++) if (C.bd[i] !== ".") { const el = mkPiece(C.bd[i], i); C.layer.append(el); C.dom[i] = el; }
  }
  function boardBlock() {
    const b = h("div", {class: "gm-board"}), grid = h("div", {class: "gm-sqs"});
    C.sqs = new Array(64);
    for (let y = 0; y < 8; y++) for (let x = 0; x < 8; x++) {
      const i = C.me === "b" ? y * 8 + (7 - x) : (7 - y) * 8 + x, dark = ((i & 7) + (i >> 3)) % 2 === 0;
      const s = h("div", {class: "sq " + (dark ? "dk" : "lt")});
      if (x === 0) s.append(h("i", {class: "rk", text: String((i >> 3) + 1)}));
      if (y === 7) s.append(h("i", {class: "fl", text: "abcdefgh"[i & 7]}));
      C.sqs[i] = s; grid.append(s);
    }
    C.layer = h("div", {class: "gm-pcs"});
    b.append(grid, C.layer); C.boardEl = b; rebuildPieces();
    b.addEventListener("pointerdown", onDown); b.addEventListener("pointermove", onMove);
    b.addEventListener("pointerup", onUp); b.addEventListener("pointercancel", onUp);
    return b;
  }
  function capBetween(a, b, skip) {
    const df = Math.sign((b & 7) - (a & 7)), dr = Math.sign((b >> 3) - (a >> 3));
    let f = (a & 7) + df, r = (a >> 3) + dr;
    while (f !== (b & 7) && r !== (b >> 3)) { const i = r * 8 + f; if (i !== skip && C.bd[i] !== ".") return i; f += df; r += dr; }
    return -1;
  }
  function capsOf(full) {
    const caps = [];
    for (let k = 1; k < full.length; k++) { const c = capBetween(full[k - 1], full[k], full[0]); if (c >= 0) caps.push(c); }
    return caps;
  }
  function fadeOut(el) { el.classList.add("cap"); setTimeout(() => el.remove(), 300); }
  // Yurishni animatsiya bilan o'ynaydi; mantiqiy taxta darhol yangilanadi
  function animate(full, caps, promo) {
    const from = full[0], to = full[full.length - 1], el = C.dom[from];
    if (!el) return;
    const stepCap = full.map((_, k) => k ? capBetween(full[k - 1], full[k], from) : -1);
    const capEls = new Map();
    caps.forEach(c => { capEls.set(c, C.dom[c]); C.dom[c] = null; C.bd[c] = "."; });
    const ch = C.bd[from];
    C.bd[from] = "."; C.bd[to] = promo ? ch.toUpperCase() : ch; C.dom[from] = null; C.dom[to] = el;
    el.classList.add("mv");
    for (let k = 1; k < full.length; k++) {
      setTimeout(() => { place(el, full[k]); const e = capEls.get(stepCap[k]); if (e) fadeOut(e); }, (k - 1) * STEP);
    }
    setTimeout(() => {
      el.classList.remove("mv");
      capEls.forEach(e => { if (e && e.isConnected && !e.classList.contains("cap")) fadeOut(e); });
      if (promo) { el.classList.add("k", "promo"); setTimeout(() => el.classList.remove("promo"), 600); }
    }, (full.length - 1) * STEP + 20);
  }

  // ---------- yurish tanlash (bir necha urishli yo'l ham) ----------
  const seqsOf = i => C.legal[sqName(i)] || [];
  const samePrefix = (s, path) => path.every((p, j) => sqName(p) === s[j]);
  function nextTargets() {
    if (C.sel == null) return [];
    const k = C.path.length, out = new Set();
    for (const s of seqsOf(C.sel)) if (s.length > k && samePrefix(s, C.path)) out.add(sqIdx(s[k]));
    return [...out];
  }
  const complete = () => seqsOf(C.sel).some(s => s.length === C.path.length && samePrefix(s, C.path));
  function mustOrigins() {
    const set = new Set();
    for (const k in C.legal) { const f = sqIdx(k); if (C.legal[k].some(s => capBetween(f, sqIdx(s[0]), f) >= 0)) set.add(f); }
    return set;
  }
  function canMove() {
    if (C.view != null) return false;
    if (online()) return !C.st.over && !C.waiting && C.st.turn === C.me;
    if (botGame()) { const g = C.g; return !g.over && !g.thinking && g.pos.turn === (g.side === "w" ? 1 : -1); }
    return false;
  }
  function paintMarks() {
    if (!C.sqs.length || !C.sqs[0]) return;
    const rv = C.view != null, mvv = rv && C.view > 0 ? C.mv[C.view - 1] : null;
    const lp = rv ? (mvv ? mvv.path : []) : (C.last ? C.last.path.map(sqIdx) : []);
    const last = lp.length ? [lp[0], lp[lp.length - 1]] : [];
    const tg = !rv ? nextTargets() : [], mid = new Set(rv ? [] : C.path), must = !rv && canMove() && C.sel == null ? mustOrigins() : new Set();
    const hint = !rv && C.hint ? C.hint : [];
    const capd = new Set();
    if (!rv && C.sel != null && C.path.length) { const full = [C.sel, ...C.path]; capsOf(full).forEach(c => capd.add(c)); }
    for (let i = 0; i < 64; i++) {
      const c = C.sqs[i].classList;
      c.toggle("last", last.includes(i)); c.toggle("sel", i === C.sel); c.toggle("tg", tg.includes(i));
      c.toggle("pth", mid.has(i)); c.toggle("must", must.has(i)); c.toggle("hint", hint.includes(i));
      if (C.dom[i]) C.dom[i].classList.toggle("capd", capd.has(i));
    }
  }
  function sqAt(e) {
    const r = C.boardEl.getBoundingClientRect();
    const x = Math.floor((e.clientX - r.left) / r.width * 8), y = Math.floor((e.clientY - r.top) / r.height * 8);
    if (x < 0 || x > 7 || y < 0 || y > 7) return -1;
    return C.me === "b" ? y * 8 + (7 - x) : (7 - y) * 8 + x;
  }
  function pickTarget(i) {
    C.path.push(i); C.hint = null;
    if (complete()) { const origin = C.sel, lands = C.path.slice(); commit(origin, lands); return; }
    snd("tick"); paintMarks();
  }
  function onDown(e) {
    if (!canMove() || e.button > 0) return;
    const i = sqAt(e); if (i < 0) return;
    if (C.sel != null && nextTargets().includes(i)) { pickTarget(i); e.preventDefault(); return; }
    const ch = C.bd[i], own = ch !== "." && ch.toLowerCase() === C.me;
    if (C.path.length) {                       // ko'p urishli yo'l boshlangan: boshlang'ich toshni bossangiz bekor bo'ladi
      if (i === C.sel) C.path = [];
      paintMarks(); e.preventDefault(); return;
    }
    if (own && seqsOf(i).length) {
      C.sel = i; C.hint = null;
      C.drag = {i, el: C.dom[i], x: e.clientX, y: e.clientY, moved: false, id: e.pointerId};
      try { C.boardEl.setPointerCapture(e.pointerId); } catch (_) {}
    } else {
      C.sel = null;
      if (own && Object.keys(C.legal).length && mustOrigins().size) toast("Urish majburiy — urishi mumkin bo'lgan toshni tanlang", "warn");
    }
    paintMarks(); e.preventDefault();
  }
  function onMove(e) {
    const d = C.drag; if (!d || e.pointerId !== d.id || !d.el) return;
    const dx = e.clientX - d.x, dy = e.clientY - d.y;
    if (!d.moved && Math.hypot(dx, dy) > 7) { d.moved = true; d.el.classList.add("drag"); }
    if (d.moved) d.el.style.transform = "translate(calc(" + d.el.dataset.x * 100 + "% + " + dx + "px), calc(" + d.el.dataset.y * 100 + "% + " + dy + "px)) scale(1.12)";
  }
  function onUp(e) {
    const d = C.drag; if (!d || e.pointerId !== d.id) return;
    C.drag = null;
    if (d.el) d.el.classList.remove("drag");
    if (!d.moved) return;
    const to = sqAt(e);
    if (d.el) place(d.el, d.i);
    if (to >= 0 && canMove() && nextTargets().includes(to)) pickTarget(to); else paintMarks();
  }
  function commit(origin, lands) {
    const full = [origin, ...lands], caps = capsOf(full), ch = C.bd[origin], white = ch.toLowerCase() === "w";
    const promo = ch === ch.toLowerCase() && full.some(i => (i >> 3) === (white ? 7 : 0));
    C.sel = null; C.path = []; C.legal = {}; C.last = {path: full.map(sqName), caps: caps.map(sqName), promo};
    if (C.dom[origin]) C.dom[origin].classList.remove("capd");
    animate(full, caps, promo);
    snd("move", true, caps.length > 0, {promo}); paintMarks();
    if (online()) {
      C.waiting = true; clearTimeout(C.wt);
      C.wt = setTimeout(() => { if (C.waiting) { C.waiting = false; wsTry({type: "ck_sync"}); } }, 2500);
      send({type: "ck_move", gid: C.st.gid, path: full.map(sqName)});
    } else if (botGame()) localMoved(full);
  }

  // ---------- yurishlar tarixi ----------
  function refreshHist(hist) {
    const key = hist.join(",");
    if (key === C.histKey) return;
    C.histKey = key; C.hist = hist.slice(); C.boards = [START]; C.mv = [];
    const E = eng(), pos = new E.Pos();
    for (const s of hist) {
      const m = pos.find(E.pathOf(s)); if (!m) break;
      C.mv.push({side: pos.turn === 1 ? "w" : "b", path: m.p.slice(), cap: m.c.length > 0});
      pos.make(m); C.boards.push(pos.boardString());
    }
  }
  function curBoard() { return botGame() ? C.g.pos.boardString() : (C.st ? C.st.board : START); }
  function setView(k) {
    const n = C.mv.length;
    C.view = k == null || k >= n ? null : Math.max(0, k);
    C.sel = null; C.path = []; C.drag = null; C.hint = null;
    if (C.layer) { C.bd = (C.view == null ? curBoard() : C.boards[C.view]).split(""); rebuildPieces(); }
    if (C.boardEl) C.boardEl.classList.toggle("rev", C.view != null);
    paintMarks(); paintHist();
  }
  function buildHist() {
    const mkb = (txt, label, fn) => { const b = h("button", {class: "gm-hb", type: "button", "aria-label": label, text: txt}); b.addEventListener("click", fn); return b; };
    C.hPrev = mkb("◀", "Oldingi yurish", () => setView((C.view == null ? C.mv.length : C.view) - 1));
    C.hNext = mkb("▶", "Keyingi yurish", () => { if (C.view != null) setView(C.view + 1); });
    C.hLive = mkb("⏭", "Hozirgi holat", () => setView(null));
    C.hList = h("div", {class: "gm-hl"});
    C.hs = h("div", {class: "gm-hist"}, C.hPrev, C.hList, C.hNext, C.hLive);
    paintHist(); return C.hs;
  }
  function paintHist() {
    if (!C.hs || !C.hList) return;
    const n = C.mv.length, cur = C.view == null ? n : C.view;
    C.hList.textContent = "";
    if (!n) C.hList.append(h("span", {class: "gm-hn", text: "Yurishlar tarixi bu yerda ko'rinadi"}));
    let act = null;
    C.mv.forEach((m, i) => {
      if (i % 2 === 0) C.hList.append(h("span", {class: "gm-hn", text: (i / 2 + 1) + "."}));
      const b = h("button", {type: "button", class: "gm-hm" + (i + 1 === cur ? " on" : ""), title: (i + 1) + "-yurish"},
        h("i", {class: "ckm " + m.side}), h("span", {text: m.path.map(sqName).join(m.cap ? "×" : "–")}));
      b.addEventListener("click", () => setView(i + 1));
      if (i + 1 === cur) act = b;
      C.hList.append(b);
    });
    C.hPrev.disabled = cur <= 0; C.hNext.disabled = C.view == null; C.hLive.disabled = C.view == null;
    C.hs.classList.toggle("rev", C.view != null);
    if (act) C.hList.scrollLeft = act.offsetLeft - C.hList.clientWidth / 2 + act.offsetWidth / 2; else C.hList.scrollLeft = 0;
  }

  // ---------- o'yinchilar paneli ----------
  function playerRow(side) {
    let av, nm, withClock = online();
    if (botGame() && side !== C.g.side) { av = h("div", {class: "gm-botav", text: "🤖"}); nm = "Bot • " + eng().LEVELS[C.g.level].name; }
    else {
      const uid = online() ? (side === "w" ? C.st.white : C.st.black) : S.me.id, u = U(uid);
      av = avatar(u, "m", true); nm = nameEl(u);
    }
    const cnt = h("span", {class: "gm-cap"}), sub = h("span", {class: "gm-pp2"}), clk = withClock ? h("div", {class: "gm-clk", text: "10:00"}) : null;
    const el = h("div", {class: "gm-pl"}, av, h("div", {class: "gm-pi"}, h("div", {class: "gm-pn"}, nm), cnt, sub), clk);
    return {el, side, cnt, sub, clk};
  }
  function paintPlayers() {
    if (!C.top || !C.bot) return;
    const cnt = {w: 0, W: 0, b: 0, B: 0};
    C.bd.forEach(c => { if (c in cnt) cnt[c]++; });
    [C.top, C.bot].forEach(r => {
      const man = r.side === "w" ? cnt.w : cnt.b, king = r.side === "w" ? cnt.W : cnt.B;
      r.cnt.textContent = "";
      r.cnt.append(h("span", {class: "ckc " + r.side}), h("span", {class: "ckn", text: (man + king) + " tosh" + (king ? " • " + king + " damka" : "")}));
      r.sub.textContent = "";
      if (online()) {
        const st = C.st;
        r.sub.append(h("span", {class: "gm-tot", title: "Jami ochko", text: "🏆 " + st.base[r.side]}), h("span", {class: "gm-up", title: "Yutsa olinadigan ochko", text: "+10"}), h("span", {class: "gm-dn", title: "Yutqazsa", text: "−10"}));
      } else if (botGame() && r.side !== C.g.side && C.g.thinking) r.sub.append(h("span", {class: "oc-think", text: "● o'ylamoqda…"}));
      const turn = online() ? !C.st.over && C.st.turn === r.side : botGame() ? !C.g.over && (C.g.pos.turn === 1 ? "w" : "b") === r.side : false;
      r.el.classList.toggle("turn", turn);
    });
  }
  const fmt = ms => { const s = Math.ceil(Math.max(0, ms) / 1000); return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0"); };
  function tickClocks() {
    if (!C.el || !online() || !C.clock) return;
    const c = C.clock, el = performance.now() - c.at;
    [C.top, C.bot].forEach(r => {
      if (!r || !r.clk) return;
      let ms = c[r.side]; if (c.running && c.turn === r.side) ms -= el;
      r.clk.textContent = fmt(ms); r.clk.classList.toggle("low", ms < 20000);
      if (r === C.bot && c.running && c.turn === r.side && ms > 0 && ms < 10000) { const sec = Math.ceil(ms / 1000); if (C.tickSec !== sec) { C.tickSec = sec; snd("tick"); } }
    });
  }
  const startTick = () => { if (!C.tick) C.tick = setInterval(tickClocks, 250); };
  const stopTick = () => { clearInterval(C.tick); C.tick = 0; };

  // ---------- ekran ----------
  function openScreen() {
    if (C.el) return;
    if (C.st && C.st.over) { C.st = null; C.clock = null; C.waiting = false; C.overFor = null; C.mode = null; }
    const root = h("div", {id: "ck", class: "gm ck"});
    C.main = h("div", {class: "gm-main"});
    root.append(
      h("div", {class: "gm-top"}, h("b", {class: "gm-ttl", text: "Shashka"}), h("span", {class: "gm-sp"}),
        h("button", {class: "gm-x", type: "button", "aria-label": "Ovoz", onclick: ev => {
          const on = !Gaming.sndOn(); try { localStorage.setItem("tc_gsnd", on ? "on" : "off"); } catch (_) {}
          ev.currentTarget.textContent = on ? "🔊" : "🔇"; if (on) snd("start");
        }}, Gaming.sndOn() ? "🔊" : "🔇"),
        h("button", {class: "gm-x", type: "button", "aria-label": "Yopish", onclick: () => closeScreen()}, "✕")),
      C.main);
    document.body.append(root); C.el = root;
    navPush("ck");
    if (!C.mode && !C.st) {
      const saved = loadSaved();
      if (saved && eng()) { const g = restore(saved); if (g) { C.mode = "bot"; C.g = g; if (g.pos.turn !== (g.side === "w" ? 1 : -1) && !g.over) setTimeout(botTurn, 400); } else lsDel(LS_GAME); }
    }
    render(); startTick();
    if (botGame() && !C.g.over && !C.g.thinking && C.g.pos.turn !== (C.g.side === "w" ? 1 : -1)) setTimeout(botTurn, 400);
  }
  function closeScreen() {
    if (!C.el) return;
    if (C.st && C.st.over) { C.st = null; C.clock = null; C.waiting = false; C.overFor = null; if (C.mode === "online") C.mode = null; }
    if (botGame()) { C.g.token++; C.g.thinking = false; clearTimeout(C.botTimer); if (!C.g.over) saveGame(); else { C.g = null; C.mode = null; } }
    closeSheet(); C.el.remove(); C.el = null; C.main = null; C.sqs = []; C.boardEl = null; C.layer = null; C.overCard = null;
    C.top = C.bot = C.hs = C.undoBtn = C.hintBtn = null;
    navPop("ck"); stopTick();
    if (S.tab === "games") renderList();
  }
  function render() {
    if (!C.el) return;
    C.main.textContent = ""; C.top = C.bot = C.hs = C.undoBtn = C.hintBtn = null; C.sel = null; C.path = []; C.drag = null; C.view = null; C.hint = null; C.sqs = []; C.boardEl = null; C.layer = null;
    if (online() || botGame()) buildGame(); else buildMenu();
  }
  function menuItem(ico, title, sub, fn) {
    return h("button", {class: "gm-mi", type: "button", onclick: fn},
      h("span", {class: "gm-mic", text: ico}), h("span", {class: "gm-mt"}, h("b", {text: title}), h("small", {text: sub})), h("span", {class: "gm-mgo", text: "›"}));
  }
  function buildMenu() {
    C.me = "w"; C.bd = START.split("");
    const off = !!S.offline, n = off ? 0 : S.members.filter(m => m.id !== S.me.id && !m.deleted && isOnline(m.id)).length;
    const stats = h("div", {class: "gm-mst"}), saved = !!loadSaved();
    const root = h("div", {class: "gm-menu"},
      h("div", {class: "gm-mh"}, h("div", {class: "gm-mart ck-art"}, ckIcon()), h("b", {text: "Rus shashkasi"}), h("small", {text: off ? "Internet yo'q — faqat bot bilan o'ynash mumkin" : "Damka oldinga va orqaga uradi • urish majburiy"}), stats),
      off ? null : menuItem("➕", "Taklif qilish", (n ? n + " ta onlayn • " : "") + "javob uchun 60 soniya • har biriga 10 daqiqa", openInvite),
      menuItem("🤖", "Bot bilan o'ynash", saved ? "● To'xtatilgan o'yin bor — davom eting" : "5 daraja • maslahat • orqaga • missiya ochkosi (internet bilan)", openBotSheet),
      off ? null : menuItem("🏆", "Score board", "Faqat haqiqiy o'yinchilar o'rtasidagi o'yinlar", openScore),
      off ? null : menuItem("🎯", "Missiyalar", "Botni yuting — sovg'alar oling", () => Missions.open()),
      h("button", {class: "gm-ml", type: "button", onclick: openRules}, "ℹ️ Qoidalar"));
    C.main.append(root);
    if (off) return;
    api("/games/checkers/scoreboard").then(j => {
      if (!root.isConnected) return; const me = j.me, k = me.wins + me.losses + me.draws;
      stats.textContent = "";
      if (!k) { stats.append(h("span", {class: "gm-chip", text: "Hali o'ynalmagan — birinchi bo'ling!"})); return; }
      stats.append(h("span", {class: "gm-chip", text: "🏆 " + me.points + " ochko"}), h("span", {class: "gm-chip", text: me.rank ? "# " + me.rank + " o'rin" : "— o'rin"}), h("span", {class: "gm-chip", text: me.wins + " / " + me.losses + " / " + me.draws}));
    }).catch(() => {});
  }
  function buildGame() {
    if (botGame()) C.me = C.g.side;
    else C.me = C.st.white === S.me.id ? "w" : "b";
    const opp = C.me === "w" ? "b" : "w";
    C.bd = curBoard().split("");
    C.top = playerRow(opp); C.bot = playerRow(C.me);
    const act = h("div", {class: "gm-act oc-act"}, h("button", {class: "gm-resign", type: "button", onclick: resign}, "🏳 Taslim"));
    if (botGame()) {
      C.undoBtn = h("button", {class: "gm-undo", type: "button", onclick: undo, title: "Yurishni qaytarish"}, "↩ Orqaga");
      C.hintBtn = h("button", {class: "gm-undo oc-hint", type: "button", onclick: hint}, "💡 Maslahat");
      act.append(C.undoBtn, C.hintBtn, h("button", {class: "gm-undo", type: "button", onclick: newMenu}, "☰ Yangi"));
    } else act.append(h("span", {class: "gm-botnote", text: "Yurish uchun tosh ustiga bosing"}));
    C.main.append(h("div", {class: "gm-wrap"}, C.top.el, boardBlock(), C.bot.el, buildHist(), act));
    paintMarks(); paintPlayers(); paintHist(); tickClocks(); syncButtons();
  }
  function syncButtons() {
    if (!botGame()) return;
    const g = C.g, mine = g.pos.turn === (g.side === "w" ? 1 : -1);
    if (C.undoBtn) C.undoBtn.disabled = g.thinking || !userMoved(g);
    if (C.hintBtn) C.hintBtn.disabled = !!g.over || g.thinking || !mine || !!C.hinting;
  }
  const userMoved = g => g.moves.length > (g.side === "w" ? 0 : 1);

  // ---------- oflayn bot ----------
  const cfg = () => Object.assign({level: 3, side: "r"}, lsGet(LS_CFG, {}));
  const stat = () => Object.assign({w: 0, l: 0, d: 0}, lsGet(LS_STAT, {}));
  function loadSaved() { const s = lsGet(LS_GAME, null); return s && Array.isArray(s.moves) && s.level >= 1 && s.level <= 5 && (s.side === "w" || s.side === "b") ? s : null; }
  function saveGame() { const g = C.g; if (!g || g.over) { lsDel(LS_GAME); return; } const m = g.mis || {}; lsSet(LS_GAME, {level: g.level, side: g.side, moves: g.moves, tok: m.tok || null, hints: m.hints | 0, undos: m.undos | 0, sent: !!m.sent}); }
  function restore(s) {
    const g = newGame(s.level, s.side, s.moves); if (!g) return null;
    g.mis = {tok: s.tok || null, p: null, hints: s.hints | 0, undos: s.undos | 0, sent: !!s.sent};
    return g;
  }
  function newGame(level, side, moves) {
    const E = eng(), g = {game: "checkers", level, side, pos: new E.Pos(), moves: [], over: null, thinking: false, token: 0, reps: {}, mis: null};
    g.reps[g.pos.key()] = 1;
    for (const s of (moves || [])) { const m = g.pos.find(E.pathOf(s)); if (!m) return null; g.pos.make(m); g.moves.push(s); g.reps[g.pos.key()] = (g.reps[g.pos.key()] || 0) + 1; }
    checkOver(g);
    refreshHist(g.moves);
    return g;
  }
  function checkOver(g) {
    g.over = null;
    const E = eng(), L = g.pos.legal();
    if (!L.length) g.over = {result: g.pos.turn === 1 ? "b" : "w", reason: "no_moves"};
    else if (g.reps[g.pos.key()] >= 3) g.over = {result: "d", reason: "repetition"};
    else if (g.pos.half >= E.KING_ONLY_PLIES) g.over = {result: "d", reason: "kings15"};
  }
  function ensureWorker() {
    if (C.worker || !C.wOk) return C.worker;
    try {
      const w = new Worker("/static/js/checkers.js");
      w.onmessage = e => { const d = e.data || {}, p = C.pending.get(d.id); if (p) { C.pending.delete(d.id); clearTimeout(p.t); p.res(d); } };
      w.onerror = () => { C.wOk = false; try { w.terminate(); } catch (_) {} C.worker = null; flushPending(); };
      C.worker = w;
    } catch (_) { C.wOk = false; C.worker = null; }
    return C.worker;
  }
  function flushPending() { const list = [...C.pending.values()]; C.pending.clear(); list.forEach(p => { clearTimeout(p.t); runMain(p.q).then(p.res); }); }
  function runMain(q) {
    return new Promise(res => setTimeout(() => {
      try {
        const E = eng(), pos = E.replay(q.moves), m = pos && E.chooseMove(pos, q.level, {hint: q.hint});
        res({ok: !!pos, path: m ? m.p.map(sqName) : null});
      } catch (err) { res({ok: false, error: String(err && err.message || err)}); }
    }, 30));
  }
  function askBot(moves, level, hint) {
    const q = {moves: moves.slice(), level, hint: !!hint}, w = ensureWorker();
    if (!w) return runMain(q);
    return new Promise(res => {
      const id = ++C.req, t = setTimeout(() => { if (!C.pending.has(id)) return; C.pending.delete(id); runMain(q).then(res); }, 15000);
      C.pending.set(id, {res, t, q});
      try { w.postMessage(Object.assign({id}, q)); } catch (_) { C.pending.delete(id); clearTimeout(t); runMain(q).then(res); }
    });
  }
  function applyLocal(g, full, animateIt) {
    const E = eng(), m = g.pos.find(full.map(sqName));
    if (!m) return false;
    const mover = g.pos.turn === 1 ? "w" : "b";
    g.pos.make(m); g.moves.push(E.pathStr(m)); g.reps[g.pos.key()] = (g.reps[g.pos.key()] || 0) + 1;
    C.last = {path: full.map(sqName), caps: m.c.map(sqName), promo: m.k};
    checkOver(g); refreshHist(g.moves);
    if (animateIt && C.layer) { animate(full, m.c, m.k); snd("move", mover === g.side, m.c.length > 0, {promo: m.k}); }
    C.legal = g.over || g.pos.turn !== (g.side === "w" ? 1 : -1) ? {} : g.pos.legalMap();
    saveGame();
    return true;
  }
  // foydalanuvchi yurdi (animatsiya commit() da boshlangan)
  function localMoved(full) {
    const g = C.g;
    if (!applyLocal(g, full, false)) { C.bd = g.pos.boardString().split(""); rebuildPieces(); return; }
    afterMove();
  }
  function afterMove() {
    const g = C.g;
    paintMarks(); paintPlayers(); paintHist(); syncButtons();
    if (g.over) { finishBot(); return; }
    if (g.pos.turn !== (g.side === "w" ? 1 : -1)) botTurn(); else C.legal = g.pos.legalMap();
    paintMarks();
  }
  async function botTurn() {
    const g = C.g; if (!g || g.over || g.thinking) return;
    g.thinking = true; const tok = ++g.token; C.legal = {}; paintPlayers(); syncButtons();
    const t0 = Date.now(), r = await askBot(g.moves, g.level, false);
    const wait = Math.max(0, 450 - (Date.now() - t0));
    await new Promise(res => { C.botTimer = setTimeout(res, wait); });
    if (C.g !== g || g.token !== tok || g.over) return;
    g.thinking = false;
    if (!r || !r.ok || !r.path) { toast("Bot yurisha olmadi, qayta urinib ko'ring", "error"); syncButtons(); paintPlayers(); return; }
    if (C.layer && C.view != null) setView(null);
    applyLocal(g, r.path.map(sqIdx), !!C.layer);
    haptic(12); afterMove();
  }
  function finishBot() {
    const g = C.g; if (!g || !g.over || g.counted) return;
    g.counted = true; lsDel(LS_GAME);
    const o = g.over, res = o.result === "d" ? "d" : o.result === g.side ? "w" : "l";
    if (g.moves.length > 1 || o.reason === "resign") { const s = stat(); s[res]++; lsSet(LS_STAT, s); }
    setTimeout(() => { if (C.g === g) showOverCard({res, why: o.reason === "resign" ? "Siz taslim bo'ldingiz" : REASON[o.reason] || "", bot: true, mission: res === "w" && o.reason === "no_moves" && !!g.mis, again: () => startBot(g.level, cfg().side, true)}); }, o.reason === "resign" ? 0 : 800);
  }
  function startBot(level, pref, keep) {
    if (!eng()) { toast("Shashka dvigateli yuklanmadi. Sahifani yangilang (bir marta internet kerak).", "error"); return; }
    if (online() && !C.st.over) { toast("Avval joriy o'yinni tugating", "warn"); return; }
    const side = pref === "r" ? (Math.random() < 0.5 ? "w" : "b") : pref;
    if (C.g) { C.g.token++; C.g.thinking = false; }
    clearTimeout(C.botTimer); C.hinting = false;
    if (!keep) lsSet(LS_CFG, {level, side: pref});
    const g = newGame(level, side, []); if (!g) return;
    // Missiya: server o'yin chiptasini beradi (faqat onlayn); g'alaba shu chipta bilan tekshiriladi
    g.mis = {tok: null, p: null, hints: 0, undos: 0, sent: false};
    g.mis.p = Missions.begin(level, side, "checkers").then(t => { g.mis.tok = t; saveGame(); return t; });
    lsDel(LS_GAME); closeSheet(); removeOverCard();
    C.mode = "bot"; C.g = g; C.last = null; C.legal = side === "w" ? g.pos.legalMap() : {};
    if (!C.el) openScreen();
    C.histKey = ""; refreshHist([]);
    render(); snd("start"); haptic([40, 40, 40]);
    if (side === "b") botTurn();
  }
  function undo() {
    const g = C.g; if (!g || g.thinking || !userMoved(g)) return;
    const moves = g.moves.slice();
    while (moves.length) {                      // oxirgi o'z yurishimizgacha (botning javobi bilan) qaytaramiz
      const by = (moves.length - 1) % 2 === 0 ? "w" : "b";
      moves.pop();
      if (by === g.side) break;
    }
    const ng = newGame(g.level, g.side, moves); if (!ng) return;
    ng.mis = g.mis; if (ng.mis) ng.mis.undos++;
    g.token++; clearTimeout(C.botTimer); C.g = ng; C.last = null; C.hint = null; removeOverCard(); lsDel(LS_GAME);
    C.legal = ng.over || ng.pos.turn !== (ng.side === "w" ? 1 : -1) ? {} : ng.pos.legalMap(); saveGame();
    render(); snd("tick");
    if (!ng.over && ng.pos.turn !== (ng.side === "w" ? 1 : -1)) botTurn();
  }
  async function hint() {
    const g = C.g; if (!g || g.over || g.thinking || C.hinting || g.pos.turn !== (g.side === "w" ? 1 : -1)) return;
    if (g.mis) g.mis.hints++;
    C.hinting = true; syncButtons();
    const r = await askBot(g.moves, 5, true);
    C.hinting = false;
    if (C.g !== g || g.over) return;
    if (r && r.ok && r.path) { C.hint = [sqIdx(r.path[0]), sqIdx(r.path[1])]; C.sel = null; C.path = []; paintMarks(); setTimeout(() => { C.hint = null; paintMarks(); }, 4000); }
    syncButtons();
  }
  async function newMenu() {
    const g = C.g; if (!g) return;
    if (!g.over && g.moves.length > 1 && !await confirmDlg("Joriy o'yin tashlab ketiladi (mag'lubiyat hisoblanmaydi). Yangi o'yin boshlaymizmi?", {title: "Yangi o'yin", okText: "Yangi o'yin"})) return;
    if (C.g !== g) return;
    g.token++; g.thinking = false; clearTimeout(C.botTimer); lsDel(LS_GAME); C.g = null; C.mode = null; removeOverCard(); render();
  }
  async function resign() {
    if (botGame()) {
      const g = C.g; if (g.over) return;
      if (!await confirmDlg("Taslim bo'lsangiz o'yin tugaydi. Taslim bo'lasizmi?", {title: "Taslim bo'lish", okText: "Taslim bo'lish", danger: true})) return;
      if (C.g !== g || g.over) return;
      g.token++; g.thinking = false; clearTimeout(C.botTimer); g.over = {result: g.side === "w" ? "b" : "w", reason: "resign"};
      paintPlayers(); syncButtons(); finishBot(); return;
    }
    if (!online() || C.st.over) return;
    if (await confirmDlg("Taslim bo'lsangiz o'yin tugaydi va 10 ochko ayriladi. Taslim bo'lasizmi?", {title: "Taslim bo'lish", okText: "Taslim bo'lish", danger: true})) send({type: "ck_resign", gid: C.st.gid});
  }
  function openBotSheet() {
    if (online() && !C.st.over) { toast("Avval joriy o'yinni tugating", "warn"); return; }
    if (!eng()) { toast("Shashka dvigateli yuklanmadi. Sahifani yangilang (bir marta internet kerak).", "error"); return; }
    const c = cfg(), st = stat(), E = eng(), saved = loadSaved();
    let level = c.level, side = c.side;
    const lvRow = h("div", {class: "oc-lv"}), sdRow = h("div", {class: "gm-sides"}), info = h("p", {class: "gm-note oc-lvinfo"});
    const paintLv = () => {
      lvRow.textContent = "";
      for (let i = 1; i <= 5; i++) lvRow.append(h("button", {type: "button", class: "oc-lvb" + (i === level ? " on" : ""), "aria-pressed": String(i === level), onclick: () => { level = i; paintLv(); }}, h("b", {text: String(i)}), h("small", {text: E.LEVELS[i].name})));
      info.textContent = E.LEVELS[level].name + " — " + LV_INFO[level];
    };
    const paintSd = () => {
      sdRow.textContent = "";
      [["w", "⚪", "Oq", "birinchi yurasiz"], ["r", "🎲", "Tasodifiy", "oq yoki qora"], ["b", "⚫", "Qora", "bot birinchi yuradi"]].forEach(([k, ic, nm, sub]) =>
        sdRow.append(h("button", {type: "button", class: "gm-sd" + (k === side ? " on" : ""), "aria-pressed": String(k === side), onclick: () => { side = k; paintSd(); }}, h("span", {text: ic}), h("b", {text: nm}), h("small", {text: sub}))));
    };
    paintLv(); paintSd();
    const n = st.w + st.l + st.d;
    openSheet("🤖 Bot bilan o'ynash", h("div", {class: "oc-menu"},
      n ? h("div", {class: "gm-mst"}, h("span", {class: "gm-chip", text: "🏆 " + st.w + " / " + st.l + " / " + st.d + " (yutuq / mag'lub. / durang)"})) : null,
      saved ? h("button", {class: "btn oc-go", type: "button", text: "▶ To'xtatilgan o'yinni davom ettirish", onclick: () => { closeSheet(); const g = restore(saved); if (!g) { lsDel(LS_GAME); return; } C.mode = "bot"; C.g = g; C.last = null; C.legal = g.pos.turn === (g.side === "w" ? 1 : -1) ? g.pos.legalMap() : {}; render(); if (g.pos.turn !== (g.side === "w" ? 1 : -1) && !g.over) botTurn(); }}) : null,
      h("div", {class: "oc-sec", text: "Bot darajasi"}), lvRow, info,
      h("div", {class: "oc-sec", text: "Siz qaysi tomonda?"}), sdRow,
      h("button", {class: "btn oc-go", type: "button", text: "▶ O'yinni boshlash", onclick: () => startBot(level, side)}),
      h("p", {class: "gm-note oc-foot", text: "Natijalar va to'xtatilgan o'yin faqat shu qurilmada saqlanadi. Bot bilan o'yin ochko bermaydi."})), {kind: "bot"});
  }

  // ---------- natija kartasi ----------
  function removeOverCard() { if (C.overCard) { C.overCard.remove(); C.overCard = null; } }
  function showOverCard({res, why, bot, pts, total, rated, again, close, mission}) {
    if (!C.el) return;
    removeOverCard();
    const mbox = mission ? h("div", {class: "go-ms"}) : null;
    const num = h("div", {class: "go-pts " + (pts > 0 ? "up" : pts < 0 ? "dn" : "")}, "0");
    const card = h("div", {class: "gm-over"}, h("div", {class: "go-card"},
      h("div", {class: "go-t", text: res === "w" ? "🏆 Siz yutdingiz!" : res === "l" ? "Yutqazdingiz" : "🤝 Durang"}),
      h("div", {class: "go-r", text: why || ""}),
      bot ? h("div", {class: "go-nr", text: "Bot bilan o'yin — Score boardga yozilmaydi, faqat missiya ochkosi beriladi."}) : num, mbox,
      !bot && !rated && res !== "d" ? h("div", {class: "go-nr", text: "Ochko berilmadi: o'yin juda qisqa edi yoki bu raqib bilan bugun juda ko'p o'ynalgan."}) : null,
      bot ? null : h("div", {class: "go-tot", text: "Jami: " + total + " ochko"}),
      h("div", {class: "go-b"},
        h("button", {class: "btn", type: "button", text: "🔁 Qayta o'ynash", onclick: () => { removeOverCard(); again(); }}),
        h("button", {class: "btn ghost", type: "button", text: "Yopish", onclick: () => { removeOverCard(); (close || leaveGame)(); }}))));
    C.el.append(card); C.overCard = card;
    if (mbox && C.g) Missions.submit(C.g, mbox);
    if (!bot) { const t0 = performance.now(); const step = now => { const k = Math.min(1, (now - t0) / 700); num.textContent = (pts > 0 ? "+" : pts < 0 ? "−" : "") + Math.round(Math.abs(pts) * k); if (k < 1 && num.isConnected) requestAnimationFrame(step); }; requestAnimationFrame(step); }
    haptic(res === "w" ? [60, 40, 120] : 40);
    setTimeout(() => snd(res === "w" ? "win" : res === "l" ? "lose" : "draw"), 350);
    if (S.tab === "games") renderList();
  }
  function leaveGame() {
    if (botGame()) { C.g = null; C.mode = null; lsDel(LS_GAME); }
    else { C.st = null; C.clock = null; C.waiting = false; if (C.mode === "online") C.mode = null; }
    if (C.el) render();
    if (S.tab === "games") renderList();
  }

  // ---------- onlayn o'yin ----------
  function onState(st) {
    const prev = C.st, first = !prev || prev.gid !== st.gid;
    if (first && botGame()) { C.g.token++; C.g.thinking = false; clearTimeout(C.botTimer); if (!C.g.over) saveGame(); C.g = null; }
    C.mode = "online"; C.st = st; C.waiting = false; clearTimeout(C.wt); C.me = st.white === S.me.id ? "w" : "b"; C.sel = null; C.path = []; C.hint = null;
    refreshHist(st.hist || []);
    C.legal = st.legal || {}; C.turn = st.turn; C.last = st.last;
    if (first) {
      C.overFor = null; removeOverCard(); closeSheet(); hideInvite(); C.out = null;
      if (!C.el) openScreen(); else render();
      haptic([40, 40, 40]); snd("start");
      if (S.tab === "games") renderList();
    } else {
      const l = st.last, adv = !!l && st.plies === prev.plies + 1;
      if (st.plies < prev.plies) C.view = null;
      if (C.view == null && C.layer) {
        if (adv && C.bd.join("") !== st.board) { animate(l.path.map(sqIdx), l.caps.map(sqIdx), l.promo); snd("move", false, l.caps.length > 0, {promo: l.promo}); haptic(12); }
        if (C.bd.join("") !== st.board) { C.bd = st.board.split(""); rebuildPieces(); }
        if (C.boardEl) C.boardEl.classList.remove("rev");
      } else if (adv && C.layer) snd("move", false, l.caps.length > 0, {promo: l.promo});
    }
    C.clock = Object.assign({}, st.clock, {at: performance.now()});
    paintMarks(); paintPlayers(); tickClocks(); paintHist();
    if (st.over) showOnlineOver(st);
  }
  function showOnlineOver(st) {
    if (C.overFor === st.gid || !C.el) return;
    C.overFor = st.gid;
    const o = st.over, me = C.me, res = o.result === "d" ? "d" : o.result === me ? "w" : "l";
    let why = REASON[o.reason] || "";
    if (o.reason === "resign") why = res === "w" ? "Raqib taslim bo'ldi" : "Siz taslim bo'ldingiz";
    const opp = me === "w" ? st.black : st.white;
    setTimeout(() => showOverCard({res, why, pts: o.pts[me], total: o.total[me], rated: o.rated, again: () => { leaveGame(); send({type: "ck_invite", to: opp}); }}), C.view == null ? 900 : 0);
  }

  // ---------- takliflar ----------
  function openInvite() {
    if (online() && !C.st.over) { toast("Avval joriy o'yinni tugating", "warn"); return; }
    if (C.out) { toast("Avvalgi taklifga javob kutilmoqda", "warn"); return; }
    const list = h("div", {class: "gm-list"});
    const q = h("input", {class: "gm-q", type: "search", placeholder: "Foydalanuvchini qidirish", autocomplete: "off", autocapitalize: "none", spellcheck: "false"});
    const draw = () => {
      list.textContent = "";
      const t = q.value.trim().toLowerCase();
      const all = S.members.filter(m => m.id !== S.me.id && !m.deleted).map(m => U(m.id))
        .filter(u => !t || u.nickname.toLowerCase().includes(t) || u.username.toLowerCase().includes(t))
        .sort((a, b) => a.nickname.localeCompare(b.nickname));
      const on = all.filter(u => isOnline(u.id)), off = all.filter(u => !isOnline(u.id));
      const row = (u, isOn) => h("div", {class: "gm-u"}, avatar(u, "m", true),
        h("div", {class: "gm-un"}, nameEl(u), h("small", {text: isOn ? "onlayn" : "oflayn • bildirishnoma yuboriladi"})),
        h("button", {class: "btn sm" + (isOn ? "" : " ghost"), type: "button", text: "Taklif", onclick: () => send({type: "ck_invite", to: u.id})}));
      if (on.length) { list.append(h("div", {class: "sect", text: "Onlayn — " + on.length})); on.forEach(u => list.append(row(u, true))); }
      if (off.length) { list.append(h("div", {class: "sect", text: "Oflayn"})); off.forEach(u => list.append(row(u, false))); }
      if (!all.length) list.append(h("div", {class: "none", text: "Hech kim topilmadi"}));
    };
    q.addEventListener("input", draw); draw();
    openSheet("➕ Shashkaga taklif", h("div", {}, q, list), {kind: "invite"});
  }
  function showWaiting(m) {
    if (!C.el) openScreen();
    const u = U(m.to), ttl = Math.max(1, (m.ttl || 60)) * 1000, bar = h("i"); bar.style.animationDuration = ttl + "ms";
    const cancel = () => { if (C.out) send({type: "ck_cancel", id: C.out.id}); };
    openSheet("Taklif yuborildi", h("div", {class: "gm-wait"},
      avatar(u, "l"), h("div", {class: "gw-n"}, nameEl(u)),
      h("div", {class: "gw-s", text: isOnline(m.to) ? "Javob kutilmoqda…" : "Foydalanuvchi oflayn — bildirishnoma yuborildi. Javob kutilmoqda…"}),
      h("div", {class: "gm-bar big"}, bar),
      h("button", {class: "btn ghost", type: "button", text: "Bekor qilish", onclick: cancel})), {kind: "wait", onClose: cancel});
  }
  function hideInvite() { clearTimeout(C.incTimer); if (C.inc) { C.inc.el.remove(); C.inc = null; } }
  function showInvite(m) {
    hideInvite();
    const u = U(m.frm), ttl = Math.max(1, (m.ttl || 60)) * 1000, bar = h("i"); bar.style.animationDuration = ttl + "ms";
    const answer = ok => { send({type: "ck_reply", id: m.id, accept: ok}); hideInvite(); };
    const el = h("div", {class: "gm-inv", role: "alertdialog", "aria-label": "Shashka taklifi"},
      avatar(u, "m"),
      h("div", {class: "gm-ivt"}, h("b", {text: "Shashkaga taklif"}), h("span", {}, nameEl(u), " sizni o'yinga taklif qildi")),
      h("div", {class: "gm-ivb"}, h("button", {class: "btn sm", type: "button", text: "Qabul qilish", onclick: () => answer(true)}), h("button", {class: "btn sm ghost", type: "button", text: "Rad etish", onclick: () => answer(false)})),
      h("div", {class: "gm-bar"}, bar));
    document.body.append(el); C.inc = {id: m.id, el};
    haptic([70, 50, 70]);
    C.incTimer = setTimeout(hideInvite, ttl + 400);
  }
  function inviteEnd(m) {
    if (C.inc && C.inc.id === m.id) hideInvite();
    if (C.out && C.out.id === m.id) {
      C.out = null; closeSheet("wait");
      const nm = U(m.to).nickname;
      const t = {declined: nm + " taklifni rad etdi", expired: nm + " javob bermadi — taklif rad etildi", busy: nm + " hozir band", cancelled: "Taklif bekor qilindi"}[m.status];
      if (t) toast(t, m.status === "cancelled" ? "info" : "warn");
    }
  }

  // ---------- varaqlar ----------
  function closeSheet(kind) { if (!C.sheet || (kind && C.sheet.kind !== kind)) return; C.sheet.el.remove(); C.sheet = null; }
  function openSheet(title, body, opts = {}) {
    if (!C.el) openScreen();
    closeSheet();
    const back = h("div", {class: "gm-sheet", onclick: e => { if (e.target === back) dismiss(); }});
    const dismiss = () => { const s = C.sheet; closeSheet(); if (s && s.onClose) s.onClose(); };
    back.append(h("div", {class: "gm-panel"}, h("div", {class: "gm-ph"}, h("b", {text: title}), h("button", {class: "gm-x", type: "button", "aria-label": "Yopish", onclick: dismiss}, "✕")), body));
    C.el.append(back); C.sheet = {el: back, kind: opts.kind || "", onClose: opts.onClose};
  }
  async function openScore() {
    const body = h("div", {class: "gm-score"}, h("div", {class: "none", text: "Yuklanmoqda…"}));
    openSheet("🏆 Shashka — Score board", body, {kind: "score"});
    try {
      const j = await api("/games/checkers/scoreboard");
      if (!C.sheet || C.sheet.kind !== "score") return;
      body.textContent = "";
      const me = j.me;
      body.append(h("div", {class: "gs-me"},
        h("div", {}, h("b", {text: String(me.points)}), h("small", {text: "ochko"})),
        h("div", {}, h("b", {text: me.rank ? "#" + me.rank : "—"}), h("small", {text: "o'rin"})),
        h("div", {}, h("b", {text: me.wins + " / " + me.losses + " / " + me.draws}), h("small", {text: "yutuq / mag'lubiyat / durang"}))));
      if (!j.top.length) body.append(h("div", {class: "none", text: "Hali o'yin bo'lmagan. Birinchi bo'ling!"}));
      j.top.forEach((r, n) => {
        const u = U(r.uid), medal = ["🥇", "🥈", "🥉"][n] || String(n + 1);
        body.append(h("div", {class: "gs-row" + (r.uid === S.me.id ? " me" : "")},
          h("span", {class: "gs-n", text: medal}), avatar(u, "s"), h("div", {class: "gs-u"}, nameEl(u), h("small", {text: r.wins + " yutuq • " + r.losses + " mag'lub. • " + r.draws + " durang"})),
          h("b", {class: "gs-p", text: String(r.points)})));
      });
    } catch (err) { if (C.sheet && C.sheet.kind === "score") { body.textContent = ""; body.append(h("div", {class: "none", text: err.message})); } }
  }
  function openRules() {
    const li = (ico, t) => h("div", {class: "gm-rl"}, h("span", {text: ico}), h("div", {text: t}));
    openSheet("ℹ️ Qoidalar va ochkolar", h("div", {class: "gm-rules"},
      li("⚪", "Oq birinchi yuradi. Shashka faqat oldinga, bir katak, qora (qorong'i) kataklar bo'ylab yuradi."),
      li("⚔️", "Urish majburiy. Shashka oldinga ham, orqaga ham uradi. Bir necha toshni ketma-ket urish mumkin — boshlangan urishni oxirigacha davom ettirish shart: ketma-ket kataklarni birin-ketin bosing."),
      li("👑", "Oxirgi qatorga yetgan shashka damka bo'ladi. Urish paytida damka bo'lsa, o'sha yurishda urishni damka sifatida davom ettiradi."),
      li("♛", "Damka istalgan masofaga yuradi va uzoqdan uradi: urilgan tosh ortidagi istalgan bo'sh katakka tushadi. Davom etib urish mumkin bo'lgan katakni tanlash shart."),
      li("🚫", "Bir tosh bir yurishda ikki marta urilmaydi (urilgan toshlar yurish tugaguncha taxtada turadi va yo'lni to'sadi)."),
      li("🏁", "Yurish qolmasa (toshlar tugasa yoki qamalsa) — yutqazasiz."),
      li("🤝", "Durang: bir xil holat 3 marta takrorlansa yoki 15 yurish davomida faqat damkalar bilan (urishsiz) yurilsa."),
      li("⏱", "Online o'yinda har bir o'yinchiga 10 daqiqa. Taklif 60 soniya kutiladi. Oflayn foydalanuvchiga bildirishnoma boradi."),
      li("🏆", "Online o'yinda yutsangiz +10 ochko, yutqazsangiz −10, durangda o'zgarmaydi. 8 yarim yurishdan qisqa o'yinlar va bir juftlik bilan kuniga 5 tadan ortiq o'yin ochko bermaydi."),
      li("🤖", "Bot bilan o'yin Score boardga yozilmaydi. Internet bilan boshlangan o'yinda botni yutsangiz missiya ochkosi beriladi (3-5 daraja; admin sozlaydi). 💡 Maslahat yoki ↩ Orqaga ishlatilsa, missiya hisoblanmasligi mumkin.")), {kind: "rules"});
  }

  // ---------- tashqi interfeys ----------
  function onWs(m) {
    switch (m.type) {
      case "ck_invite": showInvite(m); snd("invite"); break;
      case "ck_invite_sent": C.out = {id: m.id, to: m.to}; showWaiting(m); break;
      case "ck_invite_end": inviteEnd(m); break;
      case "ck_state": onState(m); break;
    }
  }
  function tabList(list) {
    const live = online() && !C.st.over, saved = !!loadSaved() || (botGame() && !C.g.over);
    if (S.offline) {
      list.append(h("button", {class: "gcard ck-card", type: "button", onclick: openScreen},
        h("div", {class: "gc-art"}, ckIcon()),
        h("div", {class: "gc-t"}, h("b", {text: "Rus shashkasi"}), h("small", {class: saved ? "live" : "", text: saved ? "● To'xtatilgan bot o'yini bor" : "Oflayn: faqat bot bilan o'ynash"})),
        h("span", {class: "gc-on", text: "oflayn"})));
      return;
    }
    const n = S.members.filter(m => m.id !== S.me.id && !m.deleted && isOnline(m.id)).length;
    list.append(h("button", {class: "gcard ck-card", type: "button", onclick: openScreen},
      h("div", {class: "gc-art"}, ckIcon()),
      h("div", {class: "gc-t"}, h("b", {text: "Rus shashkasi"}), h("small", {class: live || saved ? "live" : "", text: live ? "● O'yin davom etmoqda — qaytish" : saved ? "● To'xtatilgan bot o'yini bor" : "Do'stlar bilan real vaqtda yoki bot bilan"})),
      h("span", {class: "gc-on", text: n + " onlayn"})));
  }
  function openFromPush() {
    S.tab = "games";
    document.querySelectorAll(".tabs button").forEach(x => x.classList.toggle("on", x.dataset.tab === "games"));
    renderList(); openScreen();
  }
  function reset() {
    hideInvite(); closeScreen();
    if (C.g) { C.g.token++; C.g = null; }
    C.st = null; C.out = null; C.clock = null; C.overFor = null; C.mode = null; C.histKey = "";
  }
  NAV_CLOSE.ck = () => closeScreen();
  return {tabList, onWs, openFromPush, reset, sync: () => wsTry({type: "ck_sync"})};
})();
