/* =====================================================================
   Maxsus emojilar: tanlagich (yuborish tugmasi yonida), yaratish (rasm yuklab), boshqarish (admin)
   Xabarda emoji `:nom:` matni sifatida yuboriladi (E2EE ichida), ko'rsatishda rasmga aylanadi.
   ===================================================================== */
const EM = {data: null, tab: "std", refresh: null};
const STD_EMOJIS = "😀 😃 😄 😁 😆 😅 😂 🤣 🙂 😉 😊 😇 🥰 😍 🤩 😘 😋 😛 😜 🤪 😎 🤓 🥳 😏 😒 😞 😔 😟 😕 🙁 😣 😖 😫 😩 🥺 😢 😭 😤 😠 😡 🤬 🤯 😳 🥵 🥶 😱 😨 😰 😥 😓 🤗 🤔 🤭 🤫 😶 😐 😑 😬 🙄 😯 😲 🥱 😴 🤤 😪 😵 🤐 🥴 🤢 🤮 🤧 😷 🤒 🤕 😈 👿 👹 👺 💀 👻 👽 🤖 💩 🙈 🙉 🙊 👍 👎 👌 ✌️ 🤞 🤟 🤘 👏 🙌 🙏 💪 👀 🧠 ❤️ 🧡 💛 💚 💙 💜 🖤 💔 💯 ✨ 🔥 ⚡ 🌈 ⭐ 🎉 🎁 🏆 🚀 💻 🔒 🔑 🛡️ ☕ 🍕 🍔 🍺".split(" ");

function emojiPerms() { return (EM.data && EM.data.perms) || {use: false, create: false, manage: false}; }
function emojiUsable(e) {                                  // tanlagichda ko'rinadimi (admin hammasini ko'radi)
  const p = emojiPerms();
  if (p.manage) return true;
  const pk = e.pack != null ? EM.data.packs.find(x => x.id === e.pack) : null;
  return e.public !== false && (!pk || pk.public);
}
function syncEmojiBtn() { $("emojiBtn").classList.toggle("hidden", !emojiPerms().use); if (!emojiPerms().use) closeEmojiPanel(); }
async function loadEmojis() {
  try {
    const r = await api("/emojis");
    EM.data = r; Rich.setEmojis(r.emojis, true);
    syncEmojiBtn();
    if (S.active) renderMessages(false);                     // yangi/o'chirilgan emojilar xabarlarda darrov o'zgaradi
    if (!$("emojiPanel").classList.contains("hidden")) paintEmojiPanel();
    if (EM.refresh) EM.refresh();
  } catch (_) {}
}

function insertEmoji(text) {
  const s = inp.selectionStart == null ? inp.value.length : inp.selectionStart, e = inp.selectionEnd == null ? s : inp.selectionEnd;
  if (inp.value.length - (e - s) + text.length > inp.maxLength) { toast("Xabar juda uzun", "warn"); return; }
  inp.setRangeText(text, s, e, "end"); autosize();
  if (!COARSE) inp.focus({preventScroll: true});            // telefonda klaviatura o'zi chiqib ketmasin
}
function emojiPanelOpen() { return !$("emojiPanel").classList.contains("hidden"); }
function closeEmojiPanel() { $("emojiPanel").classList.add("hidden"); $("emojiBtn").classList.remove("on"); }
function placeEmojiPanel() {
  const b = $("emojiBtn").getBoundingClientRect(), p = $("emojiPanel"), w = Math.min(344, innerWidth - 16);
  p.style.left = Math.max(8, Math.min(b.right - w, innerWidth - w - 8)) + "px";
  p.style.bottom = Math.max(8, innerHeight - b.top + 8) + "px";
}
function emojiTabs() {
  const d = EM.data, tabs = [{k: "std", label: "😀"}];
  const usable = d.emojis.filter(e => !e.builtin ? emojiUsable(e) : true);
  d.packs.forEach(pk => {
    const items = usable.filter(e => e.pack === pk.id);
    if (items.length || emojiPerms().manage) tabs.push({k: "p" + pk.id, label: pk.name, items, icon: items[0]});
  });
  const loose = usable.filter(e => e.pack == null || !d.packs.some(pk => pk.id === e.pack));
  if (loose.length) tabs.push({k: "other", label: tabs.length > 1 ? "Boshqa" : "Emojilar", items: loose, icon: loose[0]});
  return tabs;
}
function paintEmojiPanel(dir) {
  const panel = $("emojiPanel"), d = EM.data, perms = emojiPerms();
  if (!d) return;
  const tabs = emojiTabs();
  if (!tabs.some(t => t.k === EM.tab)) EM.tab = tabs.length > 1 ? tabs[1].k : "std";
  const oldBar = panel.querySelector(".ep-tabs"), keep = oldBar ? oldBar.scrollLeft : 0;   // tab almashganda ro'yxat boshiga sakramasin
  panel.textContent = "";
  const go = (k, dr) => {
    const i0 = tabs.findIndex(x => x.k === EM.tab), i1 = tabs.findIndex(x => x.k === k);
    EM.tab = k; paintEmojiPanel(dr || (i1 > i0 ? "r" : "l"));
  };
  const bar = h("div", {class: "ep-tabs", role: "tablist"});
  tabs.forEach(t => {                                       // har bir to'plam: faqat 1-emojisi; nomi — sarlavhada
    const b = h("button", {type: "button", class: t.k === EM.tab ? "on" : "", title: t.label, "aria-label": t.label, role: "tab"});
    if (t.k === "std") b.textContent = t.label; else if (t.icon) b.append(Rich.chatEmoji(t.icon.token, false)); else b.textContent = "📦";
    b.addEventListener("click", () => go(t.k));
    bar.append(b);
  });
  hScroll(bar);
  const cur = tabs.find(t => t.k === EM.tab) || tabs[0];
  const cap = h("div", {class: "ep-cap2", text: cur.k === "std" ? "Standart emojilar" : cur.label + " • " + cur.items.length + " ta"});
  const grid = h("div", {class: "ep-grid" + (dir ? " sl-" + dir : "")});
  if (cur.k === "std") STD_EMOJIS.forEach(c => grid.append(h("button", {type: "button", text: c, "aria-label": c, onclick: () => insertEmoji(c)})));
  else if (!cur.items.length) grid.append(h("div", {class: "ep-empty", text: "Bu to'plam hozircha bo'sh"}));
  else cur.items.forEach(e => {
    const b = h("button", {type: "button", title: e.token, "aria-label": e.label, onclick: () => insertEmoji(e.token)}, Rich.chatEmoji(e.token, false));
    grid.append(b);
  });
  onSwipe(grid, dd => { const i = tabs.findIndex(x => x.k === EM.tab) + dd; if (i >= 0 && i < tabs.length) go(tabs[i].k, dd > 0 ? "r" : "l"); });
  panel.append(bar, cap, grid);
  bar.scrollLeft = keep; keepTabVisible(bar);
  if (perms.create || perms.manage) {
    const foot = h("div", {class: "ep-foot"});
    if (perms.create) foot.append(h("button", {class: "btn ghost", type: "button", text: "＋ Emoji yaratish", onclick: () => { closeEmojiPanel(); openEmojiCreate(); }}));
    if (perms.manage) foot.append(h("button", {class: "btn ghost", type: "button", text: "📦 ZIP to'plam", onclick: () => { closeEmojiPanel(); openEmojiZip(); }}));
    if (perms.manage) foot.append(h("button", {class: "btn ghost", type: "button", text: "⚙ Boshqarish", onclick: () => { closeEmojiPanel(); openAdmin("emoji"); }}));
    panel.append(foot);
  }
}
function toggleEmojiPanel() {
  if (emojiPanelOpen()) { closeEmojiPanel(); return; }
  if (!EM.data || !emojiPerms().use) return;
  paintEmojiPanel(); placeEmojiPanel();
  $("emojiPanel").classList.remove("hidden"); $("emojiBtn").classList.add("on");
  const eb = $("emojiPanel").querySelector(".ep-tabs"); if (eb) keepTabVisible(eb);
}
$("emojiBtn").addEventListener("mousedown", e => e.preventDefault());           // yozish maydonidan fokus ketmasin
$("emojiPanel").addEventListener("mousedown", e => { if (!e.target.closest("input,select,textarea")) e.preventDefault(); });
$("emojiBtn").addEventListener("click", toggleEmojiPanel);
document.addEventListener("click", e => {            // katalog (tab) almashganda panel qayta chiziladi: bosilgan tugma DOM'dan chiqib ketadi, shuning uchun yo'lni hodisa vaqtidagi holatdan olamiz
  if (!emojiPanelOpen()) return;
  const path = e.composedPath ? e.composedPath() : [];
  if (path.includes($("emojiPanel")) || path.includes($("emojiBtn"))) return;
  closeEmojiPanel();
});
document.addEventListener("keydown", e => { if (e.key === "Escape" && emojiPanelOpen()) { e.stopPropagation(); closeEmojiPanel(); } }, true);
addEventListener("resize", () => { if (emojiPanelOpen()) placeEmojiPanel(); });

/* ---------- emoji yaratish: rasm tanlash -> (kerak bo'lsa) orqa fonni olib tashlash -> animatsiya -> saqlash ---------- */
function openEmojiCreate(back) {
  const d = EM.data;
  if (!d || !d.perms.create) { toast("Emoji yaratishga ruxsatingiz yo'q", "error"); return; }
  const admin = d.perms.manage;
  const st = {file: null, seq: 0, timer: 0, touched: false};
  openModal(() => {
    const pvImg = h("img", {alt: "", draggable: "false", class: "hidden"});
    const hint = h("div", {class: "em-hint", text: "Rasm tanlang: .png (oddiy emoji) yoki .gif (animatsiyali emoji). JPG va WEBP ham mumkin, 20 MB gacha"});
    const pv = h("div", {class: "em-pv"}, pvImg, hint);
    const pick = h("input", {type: "file", accept: ".png,.gif,image/png,image/gif,image/jpeg,image/webp", class: "offscreen"});
    const pickBtn = h("button", {class: "btn ghost", type: "button", text: "🖼 Rasm tanlash", onclick: () => pick.click()});
    const name = h("input", {type: "text", class: "fld", maxlength: "32", placeholder: "masalan: kulgi_1", autocomplete: "off", autocapitalize: "off", spellcheck: "false"});
    const bg = h("input", {type: "checkbox"});
    const bgRow = h("label", {class: "em-chk"}, bg, h("span", {text: "Orqa fonni olib tashlash (remove background)"}));
    const bgNote = h("small", {text: "JPG yoki shaffof bo'lmagan rasm uchun. Bir xil rangli fonda yaxshi ishlaydi."});
    const tolVal = h("b", {text: "30"});
    const tol = h("input", {type: "range", min: "5", max: "80", value: "30"});
    const tolRow = h("div", {class: "em-row hidden"}, h("label", {text: "Fon sezgirligi (kattaroq = ko'proq o'chadi)"}), h("div", {class: "em-range"}, tol, tolVal));
    const anim = h("select", {class: "fld"}, ...BADGE_ANIMS.map(([v, t]) => h("option", {value: v, text: t})));
    const animRow = h("div", {class: "em-row"}, h("label", {text: "Animatsiya"}), anim);
    const packSel = h("select", {class: "fld"}), pub = h("select", {class: "fld"}, h("option", {value: "true", text: "Hamma ishlata oladi"}), h("option", {value: "false", text: "Faqat adminlar"}));
    const fillPacks = sel => {
      packSel.textContent = ""; packSel.append(h("option", {value: "", text: "To'plamsiz"}));
      EM.data.packs.forEach(p => packSel.append(h("option", {value: String(p.id), text: p.name + (p.public ? "" : " (yopiq)")})));
      packSel.value = sel == null ? "" : String(sel);
    };
    fillPacks(EM.tab.startsWith("p") ? Number(EM.tab.slice(1)) : null);
    const newPack = h("button", {class: "btn ghost sm", type: "button", text: "＋ Yangi to'plam", onclick: async () => {
      const nm = await promptDlg("Yangi emoji to'plami", "To'plam nomi (2–24 belgi):", "", {okText: "Yaratish", placeholder: "masalan: Mem emojilar"});
      if (!nm) return;
      try { const r = await api("/emoji-packs", {method: "POST", body: {name: nm, public: true}}); await loadEmojis(); fillPacks(r.id); toast("To'plam yaratildi", "ok"); }
      catch (err) { toast(err.message, "error"); }
    }});
    packSel.addEventListener("change", () => { const p = EM.data.packs.find(x => String(x.id) === packSel.value); if (p) pub.value = String(p.public); });
    const go = h("button", {class: "btn", type: "button", text: "Emoji yaratish", disabled: true});
    const showAnim = () => { BADGE_ANIMS.forEach(([v]) => { if (v) pvImg.classList.remove("a-" + v); }); if (anim.value) pvImg.classList.add("a-" + anim.value); };
    anim.addEventListener("change", showAnim);

    const setBgState = r => {
      const locked = r.source_alpha || r.animated;
      bg.disabled = locked; bgRow.classList.toggle("off", locked);
      if (locked) bg.checked = false;
      bgNote.textContent = r.animated ? "Animatsiyali fayl: orqa fon o'chirilmaydi, animatsiya saqlanadi."
        : r.source_alpha ? "Bu rasm shaffof (PNG): orqa fon yo'q, shundayligicha qoladi."
        : "JPG yoki shaffof bo'lmagan rasm uchun. Bir xil rangli fonda yaxshi ishlaydi.";
      tolRow.classList.toggle("hidden", !bg.checked || locked);
      animRow.classList.toggle("hidden", !!r.animated);
    };
    const preview = async () => {
      if (!st.file) return;
      const my = ++st.seq; pv.classList.add("busy"); go.disabled = true;
      const fd = new FormData(); fd.append("file", st.file); fd.append("remove_bg", bg.checked ? "true" : "false"); fd.append("tolerance", tol.value);
      try {
        const r = await api("/emoji/preview", {method: "POST", body: fd});
        if (my !== st.seq) return;
        pvImg.src = r.image; pvImg.classList.remove("hidden"); showAnim(); setBgState(r);
        hint.textContent = r.bg_removed ? "Orqa fon olib tashlandi" : r.transparent ? "Shaffof fon saqlandi" : "Orqa fon bilan (xohlasangiz, yuqoridan olib tashlang)";
        go.disabled = false;
      } catch (err) {
        if (my !== st.seq) return;
        hint.textContent = err.message; if (!bg.checked) pvImg.classList.add("hidden");
        go.disabled = !bg.checked;                           // fon xatosida sozlamani o'zgartirib qayta urinish mumkin
      } finally { if (my === st.seq) pv.classList.remove("busy"); }
    };
    const later = () => { clearTimeout(st.timer); st.timer = setTimeout(preview, 350); };
    pick.addEventListener("change", () => {
      const f = pick.files[0]; pick.value = ""; if (!f) return;
      if (f.size > 20 * 1024 * 1024) { toast("Rasm 20 MB dan oshmasligi kerak", "error"); return; }
      st.file = f; bg.checked = false; tolRow.classList.add("hidden");
      if (!st.touched) { const n = f.name.replace(/\.[^.]+$/, "").toLowerCase().replace(/[^a-z0-9_]+/g, "_").replace(/^_+|_+$/g, "").slice(0, 32); name.value = n.length >= 2 ? n : "emoji"; }
      preview();
    });
    name.addEventListener("input", () => { st.touched = true; });
    bg.addEventListener("change", () => { tolRow.classList.toggle("hidden", !bg.checked); preview(); });
    tol.addEventListener("input", () => { tolVal.textContent = tol.value; later(); });
    go.addEventListener("click", async () => {
      if (!st.file) { toast("Avval rasm tanlang", "error"); return; }
      go.disabled = true; go.textContent = "Yaratilmoqda…";
      const fd = new FormData();
      fd.append("file", st.file); fd.append("name", name.value); fd.append("anim", anim.value); fd.append("remove_bg", bg.checked ? "true" : "false");
      fd.append("tolerance", tol.value);
      if (admin) { fd.append("pack_id", packSel.value); fd.append("public", pub.value); }
      try {
        const r = await api("/emoji", {method: "POST", body: fd});
        toast("Emoji tayyor: :" + r.name + ":", "ok");
        await loadEmojis();
        if (back) back(); else closeModal();
      } catch (err) { toast(err.message, "error"); go.disabled = false; go.textContent = "Emoji yaratish"; }
    });
    return h("div", {}, sheetHead("Emoji yaratish", back || null),
      h("div", {class: "em-dlg"}, pv, pickBtn, pick,
        h("div", {class: "em-row"}, h("label", {text: "Emoji nomi (:nom: ko'rinishida yoziladi)"}), name),
        bgRow, bgNote, tolRow, animRow,
        admin ? h("div", {class: "em-two"}, h("div", {class: "em-row"}, h("label", {text: "To'plam"}), packSel, newPack), h("div", {class: "em-row"}, h("label", {text: "Kim ishlata oladi"}), pub)) : null,
        go));
  });
}

/* ---------- ZIP to'plam: ZIP tanlash -> ichidagi PNG/GIF ro'yxati -> har emojiga nom -> kim ishlata oladi -> yaratish ---------- */
function openEmojiZip(back) {
  const d = EM.data;
  if (!d || !d.perms.manage) { toast("ZIP to'plam yaratish faqat adminlar uchun", "error"); return; }
  const st = {file: null, items: []};
  openModal(() => {
    const pick = h("input", {type: "file", accept: ".zip,application/zip,application/x-zip-compressed", class: "offscreen"});
    const pickBtn = h("button", {class: "btn ghost", type: "button", text: "📦 ZIP fayl tanlash", onclick: () => pick.click()});
    const hint = h("div", {class: "em-hint", text: "ZIP ichida PNG (oddiy emoji) va GIF (animatsiyali emoji) fayllar bo'lsin. Soni cheklanmagan, ZIP 50 MB gacha."});
    const packName = h("input", {type: "text", class: "fld", maxlength: "24", placeholder: "masalan: Mem emojilar", autocomplete: "off"});
    const pub = h("select", {class: "fld"}, h("option", {value: "true", text: "Hamma ishlata oladi"}), h("option", {value: "false", text: "Faqat adminlar"}));
    const list = h("div", {class: "emz-list hidden"}), skipped = h("small", {class: "emz-skip"}), count = h("div", {class: "em-hint hidden"});
    const form = h("div", {class: "hidden"},
      h("div", {class: "em-two"}, h("div", {class: "em-row"}, h("label", {text: "To'plam nomi"}), packName), h("div", {class: "em-row"}, h("label", {text: "Kim ishlata oladi"}), pub)));
    const go = h("button", {class: "btn", type: "button", text: "To'plam yaratish", disabled: true});
    const NAME = /^[a-z0-9_]{2,32}$/;
    const check = () => {                                    // tanlangan emojilar nomi to'g'ri va takrorlanmaganmi
      const used = new Map(); let n = 0, bad = false;
      st.items.forEach(it => { if (!it.on) return; n++; used.set(it.name, (used.get(it.name) || 0) + 1); });
      st.items.forEach(it => {
        const e = it.on && (!NAME.test(it.name) || used.get(it.name) > 1 || EM.data.emojis.some(x => x.token === ":" + it.name + ":"));
        it.row.classList.toggle("bad", !!e); if (e) bad = true;
      });
      count.textContent = n + " ta emoji tanlandi" + (bad ? " — qizil nomlarni to'g'rilang (2–32 belgi, a–z, 0–9, _; takrorlanmasin)" : "");
      go.disabled = !n || bad || packName.value.trim().length < 2;
    };
    const paint = r => {
      list.textContent = ""; st.items = [];
      r.items.forEach(x => {
        const it = {file: x.file, name: x.name, on: true};
        const chk = h("input", {type: "checkbox", checked: true, "aria-label": "Qo'shish"});
        const nm = h("input", {type: "text", class: "fld", maxlength: "32", value: x.name, autocomplete: "off", autocapitalize: "off", spellcheck: "false", "aria-label": "Emoji nomi"});
        chk.addEventListener("change", () => { it.on = chk.checked; check(); });
        nm.addEventListener("input", () => { nm.value = nm.value.toLowerCase().replace(/[^a-z0-9_]/g, "_"); it.name = nm.value; check(); });
        it.row = h("div", {class: "emz-row"}, chk, h("img", {src: x.image, alt: "", draggable: "false"}), h("div", {class: "emz-n"}, nm, h("small", {text: x.animated ? "GIF • animatsiyali" : "PNG • oddiy"})));
        st.items.push(it); list.append(it.row);
      });
      skipped.textContent = r.skipped.length ? "O'tkazib yuborildi: " + r.skipped.map(k => k.file + " (" + k.error + ")").join(", ") : "";
      list.classList.remove("hidden"); form.classList.remove("hidden"); count.classList.remove("hidden"); check();
    };
    pick.addEventListener("change", async () => {
      const f = pick.files[0]; pick.value = ""; if (!f) return;
      if (f.size > 12 * 1024 * 1024) { toast("ZIP 12 MB dan oshmasligi kerak", "error"); return; }
      st.file = f; hint.textContent = "Ochilmoqda…"; go.disabled = true;
      const fd = new FormData(); fd.append("file", f);
      try {
        const r = await api("/emoji-pack/zip-preview", {method: "POST", body: fd});
        hint.textContent = f.name + " — " + r.items.length + " ta emoji topildi";
        if (!packName.value) packName.value = f.name.replace(/\.zip$/i, "").replace(/[_]+/g, " ").slice(0, 24);
        paint(r);
      } catch (err) { hint.textContent = err.message; list.classList.add("hidden"); form.classList.add("hidden"); count.classList.add("hidden"); st.items = []; }
    });
    packName.addEventListener("input", () => { if (st.items.length) check(); });
    go.addEventListener("click", async () => {
      const sel = st.items.filter(i => i.on);
      go.disabled = true; go.textContent = "Yaratilmoqda…";
      const fd = new FormData();
      fd.append("file", st.file); fd.append("pack_name", packName.value); fd.append("public", pub.value);
      fd.append("items", JSON.stringify(sel.map(i => ({file: i.file, name: i.name}))));
      try {
        const r = await api("/emoji-pack/zip", {method: "POST", body: fd});
        toast("«" + r.pack + "»: " + r.created.length + " ta emoji qo'shildi" + (r.failed.length ? ", " + r.failed.length + " tasi yaratilmadi" : ""), r.failed.length ? "warn" : "ok");
        await loadEmojis();
        if (back) back(); else closeModal();
      } catch (err) { toast(err.message, "error"); go.disabled = false; go.textContent = "To'plam yaratish"; }
    });
    return h("div", {}, sheetHead("Emoji to'plami (ZIP)", back || null),
      h("div", {class: "em-dlg"}, hint, pickBtn, pick, form, count, list, skipped, go));
  }, false, false, false);
}

/* ---------- emoji boshqaruvi (admin paneli, «Emoji» bo'limi) ---------- */
function emojiManager(body, alive) {
  const ANIM_OPTS = BADGE_ANIMS.map(([v, t]) => [v, t]);
  const act = async (fn, okText) => { try { await fn(); if (okText) toast(okText, "ok"); } catch (err) { toast(err.message, "error"); } await loadEmojis(); };
  let q = "";
  const paint = () => {
    const d = EM.data;
    body.textContent = "";
    if (!d || !d.perms.manage) { body.append(h("div", {class: "adm-empty", text: "Yuklanmoqda…"})); return; }

    const mode = h("select", {class: "fld"}, h("option", {value: "off", text: "Yopiq — faqat adminlar (va ruxsat berilganlar)"}), h("option", {value: "use", text: "Ochiq — hamma ochiq emojilarni ishlatadi"}));
    mode.value = d.global;
    mode.addEventListener("change", () => act(() => api("/emoji-settings", {method: "PUT", body: {mode: mode.value}}), "Saqlandi"));
    const top = h("div", {class: "em-sec"}, h("h4", {text: "😀 Oddiy foydalanuvchilar"}),
      h("p", {text: "Ochiq bo'lsa, hamma foydalanuvchida yuborish tugmasi yonida emoji tanlagich chiqadi (faqat «hamma ishlata oladi» deb belgilangan emojilar). Yaratish ruxsatini pastda alohida foydalanuvchiga berasiz."}), mode,
      h("div", {class: "ep-row"}, h("button", {class: "btn sm", type: "button", text: "＋ Emoji yaratish", onclick: () => openEmojiCreate(() => openAdmin("emoji"))}),
        h("button", {class: "btn sm", type: "button", text: "📦 ZIP to'plam", onclick: () => openEmojiZip(() => openAdmin("emoji"))})));

    const packs = h("div", {class: "em-sec"}, h("h4", {text: "📦 Emoji to'plamlari (pack)"}), h("p", {text: "To'plam emojilarni guruhlaydi. To'plamni yopsangiz, ichidagi emojilar faqat adminlarga ko'rinadi."}));
    d.packs.forEach(pk => {
      const nm = h("input", {type: "text", class: "fld", maxlength: "24", value: pk.name});
      const pb = h("select", {class: "fld"}, h("option", {value: "true", text: "Hamma uchun"}), h("option", {value: "false", text: "Faqat adminlar"})); pb.value = String(pk.public);
      packs.append(h("div", {class: "em-item"}, h("span", {text: "📦"}), nm, h("div", {class: "em-ctl"}, pb,
        h("button", {class: "btn ghost sm", type: "button", text: "Saqlash", onclick: () => act(() => api("/emoji-packs/" + pk.id, {method: "PATCH", body: {name: nm.value, public: pb.value === "true"}}), "Saqlandi")}),
        h("button", {class: "btn danger sm", type: "button", text: "O'chirish", onclick: async () => {
          if (!await confirmDlg("«" + pk.name + "» to'plami o'chadi. Ichidagi emojilar o'chmaydi, to'plamsiz bo'lib qoladi.", {title: "To'plamni o'chirish", okText: "O'chirish", danger: true})) return;
          act(() => api("/emoji-packs/" + pk.id, {method: "DELETE"}), "To'plam o'chirildi");
        }}))));
    });
    const newName = h("input", {type: "text", class: "fld", maxlength: "24", placeholder: "Yangi to'plam nomi", autocomplete: "off"});
    packs.append(h("div", {class: "ep-row"}, newName, h("button", {class: "btn sm", type: "button", text: "Yaratish", onclick: () => {
      if (!newName.value.trim()) return;
      act(() => api("/emoji-packs", {method: "POST", body: {name: newName.value, public: true}}), "To'plam yaratildi");
    }})));

    const list = h("div", {class: "em-sec"}, h("h4", {text: "🖼 Maxsus emojilar (" + d.emojis.filter(e => !e.builtin).length + ")"}));
    const mine = d.emojis.filter(e => !e.builtin);
    if (!mine.length) list.append(h("p", {text: "Hali emoji yo'q. «Emoji yaratish» tugmasi bilan rasm yuklab yarating."}));
    mine.forEach(e => {
      const pk = h("select", {class: "fld"}, h("option", {value: "", text: "To'plamsiz"}), ...d.packs.map(p => h("option", {value: String(p.id), text: p.name}))); pk.value = e.pack == null ? "" : String(e.pack);
      const pb = h("select", {class: "fld"}, h("option", {value: "true", text: "Hamma"}), h("option", {value: "false", text: "Faqat adminlar"})); pb.value = String(e.public);
      const an = h("select", {class: "fld", disabled: e.animated}, ...ANIM_OPTS.map(([v, t]) => h("option", {value: v, text: t}))); an.value = e.anim || "";
      const save = () => act(() => api("/emoji/" + e.id, {method: "PATCH", body: {anim: an.value, pack_id: pk.value ? Number(pk.value) : null, public: pb.value === "true"}}), "Saqlandi");
      [pk, pb, an].forEach(s => s.addEventListener("change", save));
      list.append(h("div", {class: "em-item"}, Rich.chatEmoji(e.token, false),
        h("div", {}, h("b", {text: e.token}), h("div", {class: "em-lbl", text: (e.author ? e.author : "—") + (e.animated ? " • animatsiyali fayl" : "")})),
        h("div", {class: "em-ctl"}, pk, pb, an, h("button", {class: "btn danger sm", type: "button", text: "O'chirish", onclick: async () => {
          if (!await confirmDlg(e.token + " emojisi o'chadi. Eski xabarlarda u oddiy matn bo'lib ko'rinadi.", {title: "Emojini o'chirish", okText: "O'chirish", danger: true})) return;
          act(() => api("/emoji/" + e.id, {method: "DELETE"}), "Emoji o'chirildi");
        }}))));
    });

    const users = h("div", {class: "em-sec"}, h("h4", {text: "👤 Foydalanuvchilar ruxsati"}),
      h("p", {text: "«Yaratadi» ruxsati olgan foydalanuvchi o'z emojisini yarata oladi (eng ko'pi bilan " + 30 + " ta, hamma ko'radi). Adminlarda hammasi doim bor."}));
    const search = h("input", {type: "text", class: "fld", placeholder: "Nickname yoki @username", autocomplete: "off", value: q});
    const ulist = h("div", {});
    const fillUsers = () => {
      ulist.textContent = "";
      const t = q.trim().toLowerCase().replace(/^@/, "");
      const ms = S.members.filter(m => m.role === "user" && !m.deleted && (!t || (m.nickname || "").toLowerCase().includes(t) || (m.username || "").toLowerCase().includes(t))).slice(0, 60);
      if (!ms.length) ulist.append(h("div", {class: "adm-empty", text: "Hech kim topilmadi"}));
      ms.forEach(m => {
        const sel = h("select", {class: "fld"}, h("option", {value: "0", text: "Umumiy sozlama"}), h("option", {value: "1", text: "Ishlatadi"}), h("option", {value: "2", text: "Ishlatadi + yaratadi"}));
        sel.value = String((d.user_perms || {})[String(m.id)] || 0);
        sel.addEventListener("change", () => act(() => api("/emoji-perm/" + m.id, {method: "PUT", body: {perm: Number(sel.value)}}), "Ruxsat saqlandi"));
        ulist.append(h("div", {class: "em-urow"}, h("span", {text: m.nickname + " @" + m.username}), sel));
      });
    };
    search.addEventListener("input", () => { q = search.value; fillUsers(); });
    fillUsers();
    users.append(search, ulist);
    body.append(top, packs, list, users);
  };
  const refresh = () => {                              // katalog o'zgarganda (WS) faqat «Emoji» bo'limi ochiq turganda qayta chiziladi
    if (!body.isConnected || (alive && !alive())) { if (EM.refresh === refresh) EM.refresh = null; return; }
    paint();
  };
  EM.refresh = refresh;
  paint();
  if (!EM.data) loadEmojis();
}
function openBadgePicker(u, back) {
  const go = back || (() => openProfile(u.id));
  openModal(() => h("div", {}, sheetHead("Nishon: @" + u.username, go), h("div", {class: "sh-body"}, badgeEditor(U(u.id), go))), false);
}

