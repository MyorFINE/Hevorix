const LS_PINS = "termchat_pins";
const X = {id: 0, username: "", priv: null, ecdhPub: "", signPub: "", fp: "", iter: 0, self: null, rooms: new Map(), keyIds: new Map(),
           epoch: 0, state: null, peers: new Map(), peerReq: new Map(), pending: new Set(), changed: new Map(), ready: null, serving: false, rotating: false};
function xReset() {
  X.id = 0; X.priv = null; X.self = null; X.rooms = new Map(); X.keyIds = new Map(); X.epoch = 0; X.state = null; X.peers = new Map(); X.peerReq = new Map();
  X.pending = new Set(); X.changed = new Map(); X.ready = null; X.serving = false; X.rotating = false;
}
const pinStore = () => { try { return JSON.parse(localStorage.getItem(LS_PINS + "_" + X.id) || "{}"); } catch (_) { return {}; } };
const savePins = p => { try { localStorage.setItem(LS_PINS + "_" + X.id, JSON.stringify(p)); } catch (_) {} };

async function xInstall(me, username, ident, pubs, iter, remember) {
  const priv = await E2E.importPrivate(ident);
  X.id = me.id; X.username = username; X.priv = priv; X.ecdhPub = pubs.ecdh_pub; X.signPub = pubs.sign_pub; X.iter = iter;
  X.self = await E2E.importPeer({e: pubs.ecdh_pub, s: pubs.sign_pub}); X.fp = X.self.fp;

}
async function xGenerate(username, password, iter) {
  const kd = await E2E.deriveFromPassword(username, password, iter);
  const ident = await E2E.generateIdentity();
  const keys = {ecdh_pub: ident.ecdhPub, sign_pub: ident.signPub, key_blob: await E2E.wrapIdentity(ident, kd.kek, username), kdf_iter: iter};
  return {kd, ident, keys};
}

async function xUnlock(info, me, username, password) {
  if (info.upgrade) {
    const g = await xGenerate(username, password, E2E.KDF_DEFAULT);
    await api("/e2ee/setup", {method: "POST", body: {old: password, auth: g.kd.auth, keys: g.keys}});
    await xInstall(me, username, g.ident, g.keys, E2E.KDF_DEFAULT, true);
    return;
  }
  const e = info.e2ee, kd = await E2E.deriveFromPassword(username, password, e.kdf_iter || E2E.KDF_DEFAULT);
  let ident;
  try { ident = await E2E.unwrapIdentity(e.key_blob, kd.kek, username); } catch (_) { throw new Error("Parol noto'g'ri (kalitlarni ochib bo'lmadi)"); }
  await xInstall(me, username, ident, e, e.kdf_iter || E2E.KDF_DEFAULT, true);
}

async function xRestore(info, me) {
  if (!info.upgrade && info.e2ee.ecdh_pub) {
    const rec = await E2E.loadIdentity(me.id);
    if (rec && rec.ecdhPub === info.e2ee.ecdh_pub && rec.signPub === info.e2ee.sign_pub) {
      X.id = me.id; X.username = me.username; X.priv = {ecdhPriv: rec.ecdhPriv, signPriv: rec.signPriv};
      X.ecdhPub = rec.ecdhPub; X.signPub = rec.signPub; X.iter = rec.iter || info.e2ee.kdf_iter;
      X.self = await E2E.importPeer({e: rec.ecdhPub, s: rec.signPub}); X.fp = X.self.fp;
      return true;
    }
  }
  for (let tries = 0; tries < 5; tries++) {
    const pw = await promptDlg(info.upgrade ? "Shifrlashni yoqish" : "Kalitlarni ochish",
      info.upgrade ? "Xabarlaringiz endi uchdan-uchga shifrlanadi. Davom etish uchun parolingizni kiriting (kalitlar shu qurilmada yaratiladi)."
        : "Shifrlash kalitlari bu qurilmada yo'q. Ularni ochish uchun parolingizni kiriting.", "", {type: "password", okText: "Ochish"});
    if (pw === null) return false;
    try { await xUnlock(info, me, me.username, pw); return true; } catch (err) { toast(err.message, "error"); }
  }
  return false;
}

function peer(uid) {
  if (uid === X.id) return Promise.resolve(X.self);
  const p = X.peers.get(uid);
  if (p) return Promise.resolve(p);
  let req = X.peerReq.get(uid);
  if (!req) { req = loadPeer(uid).finally(() => X.peerReq.delete(uid)); X.peerReq.set(uid, req); }
  return req;
}
async function loadPeer(uid) {
  let p;
  const m = S.members.find(x => x.id === uid);
  let keys = m && m.ek ? {e: m.ek, s: m.sk} : null;
  if (!keys) { const j = await api("/e2ee/keys?ids=" + uid); keys = j.keys[String(uid)]; }
  if (!keys) throw new Error("Bu foydalanuvchida E2EE kalitlari yo'q");
  p = await E2E.importPeer(keys);
  const pins = pinStore();
  if (pins[uid] && pins[uid] !== p.fp) { p.changed = true; X.changed.set(uid, {old: pins[uid], now: p.fp}); }
  else if (!pins[uid]) { pins[uid] = p.fp; savePins(pins); }
  X.peers.set(uid, p);
  return p;
}
function acceptKeyChange(uid) {
  const c = X.changed.get(uid); if (!c) return;
  const pins = pinStore(); pins[uid] = c.now; savePins(pins);
  X.changed.delete(uid); const p = X.peers.get(uid); if (p) p.changed = false;
}

async function loadRoom() {
  const st = await api("/e2ee/room"); X.state = st; X.epoch = st.epoch;
  for (const w of st.mine) {
    if (X.rooms.has(w.epoch)) continue;
    const ep = st.epochs.find(e => e.epoch === w.epoch);
    try {
      const wp = await peer(w.by);
      const key = await E2E.unwrapRoomKey(w.wrapped, w.epoch, X.priv.ecdhPriv, X.id, wp.ecdh, w.by);
      if (!ep || !(await E2E.verifyEpochCheck(ep.check, key, w.epoch))) throw new Error("tekshiruv");
      X.rooms.set(w.epoch, key); X.keyIds.set(w.epoch, await E2E.keyId(key));
    } catch (_) {
      try { await api("/e2ee/room/wrap/" + w.epoch, {method: "DELETE"}); } catch (__) {}
    }
  }
  if (st.epoch === 0) await initRoom();
  else if (X.rooms.has(st.epoch)) { rehydratePending(); serveWraps(); }
  if (!X.rooms.has(X.epoch) && X.epoch) renderHeader();
}
async function initRoom() {
  const key = await E2E.newRoomKey(), withKeys = S.members.filter(m => m.ek && !m.banned && !m.deleted);
  const list = withKeys.some(m => m.id === X.id) ? withKeys : withKeys.concat([{id: X.id, ek: X.ecdhPub}]);
  const wraps = [];
  for (const m of list) wraps.push({user_id: m.id, wrapped: await E2E.wrapRoomKey(key, 1, X.priv.ecdhPriv, X.id, (await peer(m.id)).ecdh, m.id)});
  try { await api("/e2ee/room/init", {method: "POST", body: {check: await E2E.epochCheck(key, 1), wraps}}); }
  catch (_) {  }
  const st = await api("/e2ee/room"); if (st.epoch) { X.state = st; X.epoch = st.epoch; await loadRoomKeysOnly(); }
}
async function loadRoomKeysOnly() { if (X.epoch) await loadRoom(); }
async function serveWraps() {
  if (X.serving || !X.rooms.size) return;
  X.serving = true;
  try {
    const j = await api("/e2ee/room/missing"), byEp = new Map();
    j.missing.forEach(m => { if (X.rooms.has(m.epoch) && m.user_id !== X.id) (byEp.get(m.epoch) || byEp.set(m.epoch, []).get(m.epoch)).push(m); });
    for (const [ep, list] of byEp) {
      const wraps = [];
      for (const m of list.slice(0, 100)) {
        try {
          const pk = await E2E.importEcdhPub(m.ecdh_pub);
          wraps.push({user_id: m.user_id, wrapped: await E2E.wrapRoomKey(X.rooms.get(ep), ep, X.priv.ecdhPriv, X.id, pk, m.user_id)});
        } catch (_) {}
      }
      if (wraps.length) await api("/e2ee/room/wrap", {method: "POST", body: {epoch: ep, wraps}});
    }
  } catch (_) {}
  X.serving = false;
}
async function rotateRoom(reason) {
  if (X.rotating || !amAdmin() || !X.rooms.has(X.epoch)) return;
  X.rotating = true;
  try {
    await loadMembers();
    const key = await E2E.newRoomKey(), ep = X.epoch + 1, wraps = [];
    for (const m of S.members.filter(m => m.ek && !m.banned && !m.deleted))
      wraps.push({user_id: m.id, wrapped: await E2E.wrapRoomKey(key, ep, X.priv.ecdhPriv, X.id, (await peer(m.id)).ecdh, m.id)});
    await api("/e2ee/room/rotate", {method: "POST", body: {from_epoch: X.epoch, check: await E2E.epochCheck(key, ep), wraps, reason: (reason || "rotate").slice(0, 20)}});
    toast("Guruh kaliti yangilandi (yangi xabarlar eski a'zolar uchun yopiq)", "ok");
  } catch (_) {}
  X.rotating = false;
  try { await loadRoom(); } catch (_) {}
}

const fileIco = f => f.voice ? "🎤 " : f.vnote ? "📹 " : "📎 ";
const fileWhat = f => f.voice ? "Ovozli xabar" : f.vnote ? "Video xabar" : f.name;
const THUMB_RE = /^data:image\/jpeg;base64,[A-Za-z0-9+/]{16,4200}={0,2}$/;
const replyInfo = m => ({id: m.id, uid: m.user.id, nickname: m.user.nickname, text: snippetOf(m.content), image: !!m.image, file: !!m.file, voice: !!(m.file && m.file.voice), vnote: !!(m.file && m.file.vnote), file_name: m.file ? fileWhat(m.file) : null});
async function hydrate(m) {
  if (!m || m.service || !m.e2e) { if (m && !m.service && !m.e2e) m.legacy = true; return m; }
  m.locked = false; m.bad = false; m.verified = false;
  try {
    const env = E2E.parseEnvelope(m.e2e), sender = m.user.id, me = X.id;
    let key;
    if (m.ch || m.to == null) {
      key = X.rooms.get(env.ep);
      if (!key) { m.locked = true; m.content = ""; X.pending.add(m); return m; }
    } else {
      const other = sender === me ? m.to : sender, op = await peer(other);
      if (op.changed) throw new Error("kalit o'zgargan");
      key = await E2E.dmKey(X.priv.ecdhPriv, op.ecdh, sender, m.to);
    }
    const sp = await peer(sender);
    const r = await E2E.openMessage(m.e2e, {sender, peer: m.to, key, signKey: sp.sign, room: m.ch ? "c:" + m.ch : undefined});
    const p = r.payload; m.verified = r.verified && !sp.changed;
    m.content = typeof p.t === "string" ? p.t : "";
    m.reply = p.r ? Object.assign({deleted: false}, p.r) : null;
    m._r = p.r || null; m._f = p.f || null;
    m._fw = p.fw && typeof p.fw === "object" && typeof p.fw.n === "string" ? {n: p.fw.n.slice(0, 40), id: Number.isInteger(p.fw.id) ? p.fw.id : 0} : null;
    m.fwd = m._fw;
    if (p.f) {
      m.mkey = p.f.k;
      if (p.f.img) { m.image = "e2e"; m.thumb = p.f.th || null; m.w = p.f.w || null; m.h = p.f.h || null; }
      else m.file = {url: m.blob ? m.blob.url : "", name: p.f.name || "fayl", size: p.f.size || 0, mime: p.f.mime || "application/octet-stream", e2e: true, key: p.f.k,
        voice: p.f.vo === 1 && p.f.mime === "audio/wav", dur: typeof p.f.d === "number" && p.f.d > 0 && p.f.d < 900 ? p.f.d : 0,
        vnote: p.f.rv === 1 && (p.f.mime === "video/webm" || p.f.mime === "video/mp4"), th: typeof p.f.th === "string" && THUMB_RE.test(p.f.th) ? p.f.th : null};
    }
    X.pending.delete(m);
  } catch (err) { m.bad = true; m.content = ""; X.pending.delete(m); }
  return m;
}
async function rehydratePending() {
  const list = [...X.pending]; if (!list.length) return;
  for (const m of list) await hydrate(m);
  renderMessages(false); renderList();
}
const hydrateAll = list => Promise.all(list.map(hydrate));

async function hydrateComment(c) {
  if (!c.e2e) { c.text = typeof c.content === "string" ? c.content : ""; c.verified = false; c.legacy = true; return c; }
  c.locked = false; c.bad = false; c.verified = false; c.text = "";
  try {
    const env = E2E.parseEnvelope(c.e2e), key = X.rooms.get(env.ep);
    if (!key) { c.locked = true; return c; }
    const sp = await peer(c.user.id);
    const r = await E2E.openMessage(c.e2e, {sender: c.user.id, peer: null, key, signKey: sp.sign, room: "k:" + c.post});
    c.verified = r.verified && !sp.changed;
    c.text = typeof r.payload.t === "string" ? r.payload.t : "";
  } catch (_) { c.bad = true; }
  return c;
}
async function sealComment(postId, text) {
  const key = X.rooms.get(X.epoch);
  if (!key) throw new Error(X.epoch ? "Guruh kaliti hali kelmagan. Biroz kuting…" : "Guruh kaliti yaratilmoqda, biroz kuting…");
  return E2E.sealMessage({sender: X.id, peer: null, ep: X.epoch, key, signKey: X.priv.signPriv, payload: {t: text}, room: "k:" + postId, kind: "c"});
}

async function e2eFetchBlob(m) {
  const url = m.blob ? m.blob.url : (m.file && m.file.url);
  if (m.expired || !url) { const ex = new Error("expired"); ex.expired = true; throw ex; }
  const r = await SC.fetch(url, {headers: {Authorization: "Bearer " + S.token}});
  if (!r.ok) throw new Error("fayl");
  return E2E.decryptFile(r.bytes, m.mkey || m.file.key);
}
const EXPIRED_MSG = "Fayl muddati tugagan (24 soatdan keyin o'chiriladi)";
const blobUrls = new Map();
function e2eImageUrl(m) {
  if (!blobUrls.has(m.id)) blobUrls.set(m.id, e2eFetchBlob(m).then(b => URL.createObjectURL(new Blob([b], {type: (m._f && m._f.mime) || "image/jpeg"}))).catch(e => { blobUrls.delete(m.id); throw e; }));
  return blobUrls.get(m.id);
}
const imgSrcOf = m => m.e2e ? e2eImageUrl(m) : Promise.resolve(m.image);

async function cleanImage(blob) {
  const out = {blob, w: 0, h: 0, th: null};
  try {
    const bmp = await createImageBitmap(blob);
    out.w = bmp.width; out.h = bmp.height;
    if (blob.type !== "image/gif") {
      const c = document.createElement("canvas"); c.width = bmp.width; c.height = bmp.height;
      c.getContext("2d").drawImage(bmp, 0, 0);
      const png = blob.type === "image/png", re = await new Promise(r => c.toBlob(r, png ? "image/png" : "image/jpeg", 0.92));
      if (re) out.blob = re;
    }
    const k = 40 / Math.max(bmp.width, bmp.height), t = document.createElement("canvas");
    t.width = Math.max(1, Math.round(bmp.width * k)); t.height = Math.max(1, Math.round(bmp.height * k));
    t.getContext("2d").drawImage(bmp, 0, 0, t.width, t.height);
    out.th = t.toDataURL("image/jpeg", 0.5);
  } catch (_) {}
  return out;
}

async function keyForActive() { return keyForTarget(S.active); }
async function keyForTarget(tg) {
  if (tg.kind === "channel") {
    if (!amAdmin()) throw new Error("Kanalga faqat adminlar post yoza oladi");
    const key = X.rooms.get(X.epoch);
    if (!key) throw new Error(X.epoch ? "Guruh kaliti hali kelmagan: kalitli a'zo onlayn bo'lishi kerak. Biroz kuting…" : "Guruh kaliti yaratilmoqda, biroz kuting…");
    return {key, peer: null, ep: X.epoch, room: "c:" + tg.id, kind: "c"};
  }
  if (tg.kind === "group") {
    const key = X.rooms.get(X.epoch);
    if (!key) throw new Error(X.epoch ? "Guruh kaliti hali kelmagan: kalitli a'zo onlayn bo'lishi kerak. Biroz kuting…" : "Guruh kaliti yaratilmoqda, biroz kuting…");
    return {key, peer: null, ep: X.epoch};
  }
  const uid = tg.uid, p = await peer(uid);
  if (p.changed) throw new Error("Bu foydalanuvchining shifrlash kaliti o'zgargan! 🔒 tugmasida tekshirib, qabul qiling");
  return {key: await E2E.dmKey(X.priv.ecdhPriv, p.ecdh, X.id, uid), peer: uid, ep: 0};
}
async function sealFor(ctx, payload) {
  return E2E.sealMessage({sender: X.id, peer: ctx.peer, ep: ctx.ep, key: ctx.key, signKey: X.priv.signPriv, payload, room: ctx.room, kind: ctx.kind});
}
function withTarget(msg, tg) {
  if (tg.kind === "dm") msg.to = tg.uid; else if (tg.kind === "channel") msg.ch = tg.id;
  return msg;
}

