const BANNERS = [["aurora", "Aurora"], ["sunset", "Shafaq"], ["ocean", "Okean"], ["forest", "O'rmon"], ["midnight", "Yarim tun"],
  ["rose", "Atirgul"], ["gold", "Oltin"], ["fire", "Olov"], ["ice", "Muz"], ["violet", "Binafsha"]];
const FRAMES = [["gold", "Oltin"], ["rainbow", "Kamalak"], ["fire", "Olov"], ["ice", "Muz"], ["emerald", "Zumrad"], ["rose", "Atirgul"]];
// Missiya sovg'alari (x_ bilan boshlanadi): tanlash ro'yxatida yo'q, faqat inventardan kiyiladi (server ham shuni talab qiladi).
const PREM_BANNERS = ["x_nebula", "x_lava", "x_matrix", "x_sakura", "x_abyss", "x_royal"];
const PREM_FRAMES = ["x_neon", "x_galaxy", "x_royal", "x_toxic", "x_plasma", "x_glacier"];
const PREM_TXT = ["x_neon", "x_lava", "x_royal", "x_rainbow", "x_frost", "x_glow"];
const PREM_FX = {nick: PREM_TXT, bio: PREM_TXT, msg: ["x_glow", "x_flow", "x_sparkle", "x_pulse", "x_neon", "x_royal"],
  avatar: ["x_pulse", "x_float", "x_swing", "x_heartbeat", "x_glitch", "x_spin"]};
const BANNER_KEYS = new Set(BANNERS.map(x => x[0])), FRAME_KEYS = new Set(FRAMES.map(x => x[0]));
const BANNER_ALL = new Set([...BANNER_KEYS, ...PREM_BANNERS]), FRAME_ALL = new Set([...FRAME_KEYS, ...PREM_FRAMES]);
const FX_TXT = [["shimmer", "Yaltirash"], ["aurora", "Aurora"], ["sunrise", "Shafaq"], ["ocean", "Okean"], ["gold", "Oltin"], ["candy", "Konfet"],
  ["glitch", "Glitch"], ["float", "Suzish"], ["pulse", "Puls"]];
const FX = {
  nick: {label: "Nickname", items: FX_TXT.concat([["wave", "To'lqin"]])},
  user: {label: "Username", items: FX_TXT},
  bio: {label: "Bio", items: FX_TXT.slice(0, 6).concat([["breathe", "Nafas"]])},
  page: {label: "Profil sahifasi", items: [["flow", "Oqma fon"], ["stars", "Yulduzlar"], ["float", "Suzuvchi avatar"]]},
  reply: {label: "Reply", items: [["line", "Oqma chiziq"], ["tint", "Rangli fon"], ["stripes", "Yo'l-yo'l"], ["slidein", "Sirpanib kirish"]]},
  link: {label: "Havola", items: [["run", "Chiziq yugurishi"], ["pill", "Kapsula"], ["flow", "Oqma rang"], ["arrow", "↗ Strelka"]]},
};
const FX_AREAS = Object.keys(FX);
const FX_AREAS_ALL = FX_AREAS.concat(["msg", "avatar"]);
const FX_KEYS = {}; FX_AREAS.forEach(k => { FX_KEYS[k] = new Set(FX[k].items.map(x => x[0])); });
Object.keys(PREM_FX).forEach(k => { FX_KEYS[k] = new Set([...(FX_KEYS[k] || []), ...PREM_FX[k]]); });
const FX_GRAD = new Set(["shimmer", "aurora", "sunrise", "ocean", "gold", "candy", "x_neon", "x_lava", "x_royal", "x_rainbow", "x_frost"]);
const FX_MQ = typeof matchMedia === "function" ? matchMedia("(prefers-reduced-motion: reduce)") : null;
const fxOf = (u, area) => !(FX_MQ && FX_MQ.matches) && u && !u.deleted && u.fx && typeof u.fx === "object" && typeof u.fx[area] === "string" && FX_KEYS[area] && FX_KEYS[area].has(u.fx[area]) ? u.fx[area] : null;
const fxMap = u => { const o = {}; FX_AREAS_ALL.forEach(a => { o[a] = fxOf(u, a) || ""; }); return o; };
function fxText(el, key) {
  if (!key) return el;
  if (FX_GRAD.has(key)) el.classList.add("fxt", "fxg-" + key); else el.classList.add("fxa-" + key);
  return el;
}
function fxWave(nt, text) {
  nt.textContent = ""; nt.setAttribute("aria-label", text);
  Array.from(text).forEach((ch, i) => { const sp = h("span", {class: "fxw", "aria-hidden": "true", text: ch}); sp.style.setProperty("--i", String(Math.min(i, 40))); nt.append(sp); });
  return nt;
}
function fxBubble(bubble, u) {
  const l = fxOf(u, "link");
  if (l) bubble.classList.add("fxl-" + l);
  const m = fxOf(u, "msg");
  if (m) bubble.classList.add("fxm-" + m);
  return bubble;
}
function fxPlay(el, ms) {
  el.classList.remove("fxgo"); void el.offsetWidth; el.classList.add("fxgo");
  clearTimeout(el._fxT); el._fxT = setTimeout(() => el.classList.remove("fxgo"), ms || 3400);
}
const pageCls = u => { const k = fxOf(u, "page"); return k ? " fxp-" + k : ""; };
const bannerCls = u => u && !u.deleted && BANNER_ALL.has(u.banner) ? " bn-" + u.banner : "";
const avatarFxCls = u => { const k = fxOf(u, "avatar"); return k ? " fxav-" + k : ""; };
const titleEl = u => u && !u.deleted && u.title ? h("div", {class: "ptitle", text: u.title}) : null;

function openProfileEditor(uid) {
  openPage(() => {
    const t0 = U(uid), self = uid === S.me.id, staff = isStaff(t0), admin = amAdmin();
    const trustOf = x => x.trust === 1 ? "new" : x.trust === 0 ? "trusted" : "auto";
    const base = {fx: fxMap(t0), banner: BANNER_ALL.has(t0.banner) ? t0.banner : "",
      frame: FRAME_ALL.has(t0.frame) ? t0.frame : "", title: t0.title || "", color: HEX.test(t0.color || "") ? t0.color.toLowerCase() : "", trust: trustOf(t0)};
    const d = Object.assign({}, base, {fx: Object.assign({}, base.fx)});
    const prev = h("div", {class: "pe-prev"});
    const paintPrev = play => {
      const cur = U(uid), autoNew = base.trust === "auto" ? !!cur.new : (Date.now() / 1000 - (cur.joined || 0)) < 7 * 86400;
      const pu = Object.assign({}, cur, {fx: d.fx, banner: d.banner || null, frame: d.frame || null,
        title: d.title.trim() || null, color: d.color || cur.color, new: d.trust === "new" ? true : d.trust === "trusted" ? false : autoNew});
      prev.textContent = "";
      const top = tint(h("div", {class: "tg-top" + (isStaff(pu) ? " prem " + pu.role : "") + bannerCls(pu) + pageCls(pu)}), pu);
      top.append(avatar(pu, "l"), h("div", {class: "pname"}, nameEl(pu, {big: true})), titleEl(pu), h("div", {class: "pstat on", text: "onlayn"}));
      top.append(fxText(h("div", {class: "pe-un", text: "@" + pu.username}), fxOf(pu, "user")));
      if (pu.new && !isStaff(pu)) top.append(h("div", {class: "chip warn", text: "⚠ Yangi foydalanuvchi — hali ishonish qiyin"}));
      top.append(fxText(h("div", {class: "pe-bio", text: pu.bio || "Bio shunday ko'rinadi ✨"}), fxOf(pu, "bio")));
      const mk = kind => {
        const b = fxBubble(h("div", {class: "bubble pe-bub"}), pu);
        b.append(h("div", {class: "bname"}, nameEl(pu, {colored: true})));
        if (kind === "reply") b.append(replyQuote({nickname: "Aziz", text: "Salom, qalaysan?"}, pu));
        b.append(btextEl("btext", kind === "reply" ? "Yaxshi, rahmat! Reply shunday ko'rinadi" : kind === "link" ? "Mana havola: https://example.com/dizayn" : "Salom! Xabarim shunday ko'rinadi ✨", true));
        b.append(h("span", {class: "meta", text: "12:00"}));
        return h("div", {class: "pe-msg"}, b);
      };
      const msgs = h("div", {class: "pe-msgs"}, mk("plain"), mk("reply"), mk("link"));
      msgs.addEventListener("click", e => { if (e.target.closest("a")) e.preventDefault(); }, true);
      const again = h("button", {class: "btn ghost sm pe-again", type: "button", text: "▶ Qayta ko'rsatish"});
      again.addEventListener("click", () => fxPlay(msgs, 3400));
      prev.append(top, msgs, h("div", {class: "pe-row pe-pad"}, again));
      if (play) fxPlay(msgs, 3400);
    };
    const set = (k, v) => { d[k] = v; paintPrev(); };
    const setFx = (area, k) => { d.fx[area] = k; paintPrev(area === "reply"); };
    const field = (label, k, o = {}) => {
      const i = h("input", {class: "fld", maxlength: String(o.max), placeholder: o.ph || "", "aria-label": label});
      i.value = d[k]; i.addEventListener("input", () => set(k, i.value));
      return h("label", {class: "fl"}, label, i);
    };
    const seg = (items, cur, onPick) => {
      const box = h("div", {class: "pe-seg", role: "radiogroup"});
      const paint = () => { box.textContent = ""; items.forEach(([k, t]) => { const b = h("button", {type: "button", class: "pe-sg" + (k === cur() ? " on" : ""), role: "radio", "aria-checked": String(k === cur()), text: t}); b.addEventListener("click", () => { onPick(k); paint(); }); box.append(b); }); };
      paint(); return box;
    };
    const apply = j => { upsertUser(j.user); if (S.members.some(x => x.id === uid)) S.members = S.members.map(x => x.id === uid ? Object.assign({}, x, j.user, {trust: j.trust}) : x); S.users.set(uid, Object.assign({}, S.users.get(uid), {trust: j.trust})); renderList(); renderMessages(false); };

    const checkRow = staff || !admin || self ? null : switchRow("check", "Tasdiqlangan galochka", () => U(uid).badge === "check", async () => {
      const on = U(uid).badge === "check";
      try { const j = await api("/admin/badge", {method: "POST", body: {user_id: uid, badge: on ? "" : "check", anim: ""}}); upsertUser(j.user); renderList(); renderMessages(false); paintPrev(); }
      catch (err) { toast(err.message, "error"); }
    }, "Ismi yonida ko'k galochka chiqadi. Emoji nishon uchun pastdagi tugmani bosing.");

    const bnSw = h("div", {class: "pe-sws"}), frSw = h("div", {class: "pe-sws"});
    const paintBn = () => {
      bnSw.textContent = "";
      const none = h("button", {type: "button", class: "pe-bn pe-off" + (!d.banner ? " on" : ""), title: "Fonsiz", "aria-label": "Fonsiz", text: "∅"}); none.addEventListener("click", () => { set("banner", ""); paintBn(); }); bnSw.append(none);
      BANNERS.forEach(([k, n]) => { const b = h("button", {type: "button", class: "pe-bn bn-" + k + (d.banner === k ? " on" : ""), title: n, "aria-label": n}); b.addEventListener("click", () => { set("banner", k); paintBn(); }); bnSw.append(b); });
    };
    const paintFr = () => {
      frSw.textContent = "";
      const none = h("button", {type: "button", class: "pe-fr pe-off" + (!d.frame ? " on" : ""), title: "Ramkasiz", "aria-label": "Ramkasiz", text: "∅"}); none.addEventListener("click", () => { set("frame", ""); paintFr(); }); frSw.append(none);
      FRAMES.forEach(([k, n]) => { const b = h("button", {type: "button", class: "pe-fr" + (d.frame === k ? " on" : ""), title: n, "aria-label": n}, h("span", {class: "av av-s fr-" + k})); b.addEventListener("click", () => { set("frame", k); paintFr(); }); frSw.append(b); });
    };
    paintBn(); paintFr();

    const colSw = h("div", {class: "pe-sws"});
    const paintCol = () => {
      colSw.textContent = "";
      PRESETS.forEach(c => { const b = h("button", {type: "button", class: "sw" + (d.color === c ? " on" : ""), title: c, "aria-label": c}); b.style.background = c; b.addEventListener("click", () => { set("color", c); paintCol(); }); colSw.append(b); });
      const pick = h("input", {type: "color"}); pick.value = d.color || TONES[t0.role] || "#7b61ff"; pick.addEventListener("input", () => set("color", pick.value)); pick.addEventListener("change", paintCol);
      colSw.append(h("label", {class: "sw-custom", title: "Boshqa rang"}, pick), h("button", {type: "button", class: "btn ghost sm", text: "Standart", onclick: () => { set("color", ""); paintCol(); }}));
    };
    paintCol();

    const save = h("button", {class: "btn", type: "button", text: "Saqlash"});
    save.addEventListener("click", async () => {
      // O'z dizayni: hamma /profile/design orqali. Unvon va ishonch belgisi: faqat admin, /admin/user/profile orqali.
      const own = {}, adm = {};
      if (self) {
        ["banner", "frame", "color"].forEach(k => { if (d[k] !== base[k]) own[k] = d[k]; });
        const fx = {}; FX_AREAS.forEach(a => { if ((d.fx[a] || "") !== (base.fx[a] || "")) fx[a] = d.fx[a] || ""; });
        if (Object.keys(fx).length) own.fx = fx;
      }
      if (admin) ["title", "trust"].forEach(k => { if (d[k] !== base[k] && (!self || k === "title")) adm[k] = d[k]; });
      if (!Object.keys(own).length && !Object.keys(adm).length) { toast("O'zgarish yo'q", "info"); return; }
      save.disabled = true; save.textContent = "Saqlanmoqda…";
      try {
        let j = null;
        if (Object.keys(own).length) j = await api("/profile/design", {method: "POST", body: own});
        if (Object.keys(adm).length) j = await api("/admin/user/profile", {method: "POST", body: Object.assign({user_id: uid}, adm)});
        apply(j); toast("Saqlandi", "ok"); closePage();
      }
      catch (err) { toast(err.message, "error"); save.disabled = false; save.textContent = "Saqlash"; }
    });
    paintPrev();
    const hint = (t) => h("p", {class: "tg-hint", text: t});
    const fxSec = (area, note) => h("div", {}, secTitle(FX[area].label), seg([["", "Yo'q"]].concat(FX[area].items), () => d.fx[area] || "", k => setFx(area, k)), note ? hint(note) : null);
    const reduced = FX_MQ && FX_MQ.matches ? hint("Bu qurilmada «animatsiyani kamaytirish» yoqilgan, shuning uchun effektlar namunada ko'rinmaydi. Saqlansa, boshqalarda ishlaydi.") : null;
    const titleSec = h("div", {}, secTitle("Unvon"), h("div", {class: "inf-form"}, field("Ism ostidagi qisqa yozuv", "title", {max: 24, ph: "Masalan: Moderator, VIP, Yordamchi"})));
    const saveRow = h("div", {class: "pe-save"}, save);
    const body = self
      ? h("div", {class: "pg-body pe-body"}, prev, reduced,
          admin ? null : hint("Nishon, unvon va ishonch belgisini faqat adminlar beradi. Qolgan dizaynni o'zingiz sozlaysiz."),
          fxSec("nick"), fxSec("user"), fxSec("bio"),
          fxSec("page", "Profil sahifasining o'zi uchun. Fon rangi va avatar ramkasi pastda alohida tanlanadi."),
          fxSec("reply", "Reply qilganingizda iqtibos qutisi shunday ko'rinadi."),
          fxSec("link", "Siz yuborgan havolalar shunday ko'rinadi."),
          secTitle("Profil foni"), bnSw,
          secTitle("Avatar ramkasi"), frSw,
          staff ? h("div", {}, secTitle("Profil rangi"), colSw) : null,
          admin ? titleSec : null,
          saveRow)
      : h("div", {class: "pg-body pe-body"}, prev,
          hint("Admin foydalanuvchiga dizayn bermaydi — dizaynni har kim o'zi sozlaydi. Bu yerda faqat unvon, ishonch belgisi va nishon beriladi."),
          staff ? null : h("div", {}, secTitle("Ishonch belgisi"),
            seg([["auto", "Avtomatik"], ["trusted", "Ishonchli"], ["new", "Yangi (ogohlantirish)"]], () => d.trust, k => set("trust", k)),
            hint("Avtomatik: akkaunt yoshi bo'yicha. «Ishonchli» — «⚠ Yangi» belgisi yo'qoladi. «Yangi» — eski akkauntda ham belgi ko'rsatiladi.")),
          checkRow ? h("div", {}, secTitle("Galochka va nishon"), checkRow) : secTitle("Nishon"),
          h("div", {class: "pe-row pe-pad"}, h("button", {class: "btn ghost sm", type: "button", onclick: () => openBadgePicker(U(uid), () => openProfileEditor(uid))}, "Emoji nishon tanlash")),
          titleSec,
          saveRow);
    return h("div", {}, pageHead(self ? "Profil dizayni" : "Unvon va ishonch: @" + t0.username), body);
  });
}

