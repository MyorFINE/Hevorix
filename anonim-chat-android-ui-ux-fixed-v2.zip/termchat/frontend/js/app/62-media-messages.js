function imageBox(m, mine) {
  const ratio = Math.min(2.4, Math.max(0.8, m.w && m.h ? m.w / m.h : 4 / 3));

  if (mine && !S.imgs.has(m.id)) S.imgs.set(m.id, "open");
  const st = S.imgs.get(m.id);
  const box = h("div", {class: "imgbox" + (st === "open" ? " open" : st === "loading" ? " loading" : ""), role: "button", tabindex: "0",
    "aria-label": st === "open" ? "Rasmni kattalashtirish" : "Rasmni yuklash"});
  box.style.aspectRatio = String(ratio);
  if (st !== "open") {
    const th = h("img", {class: "mthumb", alt: "", draggable: "false"});
    th.addEventListener("error", () => { th.remove(); box.classList.add("nothumb"); });
    if (m.thumb) th.src = m.thumb; else box.classList.add("nothumb");
    const dl = h("span", {class: "mdl", "aria-hidden": "true"}, icon("dl"), spinnerEl());
    box.append(th, dl);
  } else {
    box.append(fullImg(m));
  }
  const act = e => {
    e.stopPropagation();
    const cur = S.imgs.get(m.id);
    if (cur === "open") { imgSrcOf(m).then(openLightbox).catch(e => toast(e && e.expired ? EXPIRED_MSG : "Rasmni ochib bo'lmadi", "error")); return; }
    if (cur === "loading") return;
    startImageLoad(m, box);
  };
  box.addEventListener("click", act);
  box.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); act(e); } });
  return box;
}

const fmtSize = n => n < 1024 ? n + " B" : n < 1048576 ? Math.round(n / 1024) + " KB" : (n / 1048576).toFixed(1) + " MB";
const fileExt = name => { const i = (name || "").lastIndexOf("."); return i > 0 && i < name.length - 1 ? name.slice(i + 1, i + 5).toUpperCase() : "FAYL"; };
const PLAYABLE = /^(video\/(mp4|webm|ogg|quicktime)|audio\/(mpeg|mp3|ogg|wav|x-wav|webm|mp4|aac|flac|x-m4a))$/;
async function fetchFileBlob(m, type) {
  if (m.file.e2e) return new Blob([await e2eFetchBlob(m)], {type});
  const r = await SC.fetch(m.file.url, {headers: {Authorization: "Bearer " + S.token}});
  if (!r.ok) throw new Error("fayl");
  return new Blob([r.bytes], {type});
}
async function downloadFile(m, box) {
  if (box.classList.contains("loading")) return;
  box.classList.add("loading");
  try {
    const blob = await fetchFileBlob(m, "application/octet-stream");
    const url = URL.createObjectURL(blob), a = h("a", {href: url, download: m.file.name});
    document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  } catch (e) { toast(e && e.expired ? EXPIRED_MSG : "Faylni yuklab bo'lmadi", "error"); }
  box.classList.remove("loading");
}
async function playFile(m, box) {
  if (box.classList.contains("loading")) return;
  box.classList.add("loading");
  try {
    const blob = await fetchFileBlob(m, m.file.mime);
    S.played.set(m.id, URL.createObjectURL(blob));
    renderMessages(false);
  } catch (e) { toast(e && e.expired ? EXPIRED_MSG : "Faylni yuklab bo'lmadi", "error"); box.classList.remove("loading"); }
}
const fxNow = (key, ts) => {
  const seen = S.fx.get(key);
  if (seen) return Date.now() - seen < 4000;
  S.fx.set(key, Date.now());
  return !ts || Date.now() / 1000 - ts < 90;
};
async function copyQuiet(t) {
  try { await navigator.clipboard.writeText(t); return true; }
  catch (_) {
    const ta = h("textarea", {class: "offscreen"}); ta.value = t; document.body.append(ta); ta.select();
    let ok = false; try { ok = document.execCommand("copy"); } catch (_e) {}
    ta.remove(); return ok;
  }
}
async function togglePreview(m, box) {
  if (S.previews.has(m.id)) { S.previews.delete(m.id); renderMessages(false); return; }
  if (box.classList.contains("loading")) return;
  const fk = Rich.fileKind(m.file.name); if (!fk) return;
  const limit = fk.kind === "pcap" ? MAX_MEDIA : 400 * 1024;
  if (m.file.size > limit) { toast("Fayl juda katta: ko'rish uchun yuklab oling (" + fmtSize(limit) + " gacha ko'rsatiladi)", "error"); return; }
  box.classList.add("loading");
  try {
    const blob = await fetchFileBlob(m, "application/octet-stream");
    const bytes = new Uint8Array(await blob.arrayBuffer());
    if (fk.kind === "pcap") S.previews.set(m.id, {kind: "pcap", info: Rich.parsePcap(bytes)});
    else {
      if (!Rich.isTextual(bytes)) { toast("Bu fayl matn emas: faqat yuklab olish mumkin", "error"); box.classList.remove("loading"); return; }
      let text = new TextDecoder("utf-8").decode(bytes).replace(/\r\n?/g, "\n"), cut = false;
      if (text.length > 120000) { text = text.slice(0, 120000); cut = true; }
      S.previews.set(m.id, {kind: "code", lang: fk.lang, label: fk.label, text, cut});
    }
    renderMessages(false);
  } catch (err) { toast(err && /pcap|qisqa/i.test(err.message || "") ? err.message : "Faylni ochib bo'lmadi", "error"); }
  box.classList.remove("loading");
}
function previewEl(m, pv) {
  const u = U(m.user.id);
  if (pv.kind === "pcap") {
    const info = pv.info;
    return Rich.terminal(Rich.pcapLines(info, m.file.name), {user: u.username, host: "kali", kali: true, tag: "PCAP", fx: fxNow("pv" + m.id), copy: copyQuiet,
      copyText: Rich.pcapText(info, m.file.name), info: info.count + " paket • " + info.linkName + " • faqat o'qiladi"});
  }
  const box = Rich.codeBlock(pv.text, pv.lang, {label: pv.label + " • " + m.file.name, copy: copyQuiet});
  if (pv.cut) box.append(h("div", {class: "cfoot-i cut", text: "Fayl katta: faqat boshi ko'rsatildi. To'liq nusxa uchun yuklab oling."}));
  return box;
}
function fileBox(m) {
  if (m.file.voice) return voiceBox(m);
  if (m.file.vnote) return vnoteBox(m);
  const f = m.file, playable = PLAYABLE.test(f.mime), fk = playable ? null : Rich.fileKind(f.name);
  if (playable && S.played.has(m.id)) {
    const el = h(f.mime.startsWith("video/") ? "video" : "audio", {controls: true, preload: "metadata", playsinline: true});
    el.src = S.played.get(m.id);
    return h("div", {class: "mplayer"}, el, h("div", {class: "mpn", text: f.name + " • " + fmtSize(f.size)}));
  }
  const box = h("div", {class: "filebox" + (fk ? " kind-" + fk.kind : ""), role: "button", tabindex: "0", "aria-label": "Faylni yuklab olish: " + f.name});
  if (fk) box.style.setProperty("--lc", fk.color);
  const act = h("span", {class: "fdl", "aria-hidden": "true"}, icon("dl"), spinnerEl());
  box.append(h("span", {class: "fico"}, h("b", {text: fk ? fk.ext.toUpperCase().slice(0, 6) : fileExt(f.name)})),
    h("span", {class: "fmeta"}, h("b", {class: "fname", text: f.name}),
      h("small", {text: fk ? (fk.kind === "pcap" ? "Linux • tcpdump/Wireshark • " : fk.label + " • faqat ko'rish • ") + fmtSize(f.size) : fmtSize(f.size)})));
  if (playable) {
    const pl = h("button", {class: "fplay", type: "button", title: "Ijro etish", "aria-label": "Ijro etish"}, icon("play"));
    pl.addEventListener("click", e => { e.stopPropagation(); playFile(m, box); });
    box.append(pl);
  }
  if (fk) {
    const open = S.previews.has(m.id), t = open ? "Yopish" : fk.kind === "pcap" ? "Tahlil qilish" : "Kodni ko'rish";
    const vw = h("button", {class: "fplay fview" + (open ? " on" : ""), type: "button", title: t, "aria-label": t}, icon(open ? "close" : "eye"));
    vw.addEventListener("click", e => { e.stopPropagation(); togglePreview(m, box); });
    for (const ev of ["pointerdown", "touchstart"]) vw.addEventListener(ev, e => e.stopPropagation(), {passive: true});
    box.append(vw);
  }
  box.append(act);
  const go = e => { e.stopPropagation(); downloadFile(m, box); };
  box.addEventListener("click", go);
  box.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); go(e); } });
  if (!fk) return box;
  const wrap = h("div", {class: "cfile kind-" + fk.kind}, box);
  const pv = S.previews.get(m.id);
  if (pv) wrap.append(previewEl(m, pv));
  return wrap;
}
function spinnerEl() {
  const NSV = "http://www.w3.org/2000/svg";
  const s = document.createElementNS(NSV, "svg"); s.setAttribute("class", "mspin"); s.setAttribute("viewBox", "0 0 50 50");
  const c = document.createElementNS(NSV, "circle");
  [["cx", 25], ["cy", 25], ["r", 22], ["fill", "none"], ["stroke-width", 3], ["stroke-linecap", "round"]].forEach(([k, v]) => c.setAttribute(k, v));
  s.append(c); return s;
}

const VP = {id: null, audio: null, url: null, rate: 1, loading: false, pending: null};
const fmtDur = s => { s = Math.max(0, Math.round(s || 0)); return Math.floor(s / 60) + ":" + pad2(s % 60); };
function voiceStop() {
  if (VP.audio) { try { VP.audio.pause(); VP.audio.removeAttribute("src"); VP.audio.load(); } catch (_) {} }
  if (VP.url) URL.revokeObjectURL(VP.url);
  VP.id = VP.audio = VP.url = null; VP.loading = false; VP.pending = null;
  paintVoices();
  vnStop();
}
function paintVoice(box) {
  const id = +box.dataset.vid, cur = VP.id === id, a = cur ? VP.audio : null;
  const dur = a && isFinite(a.duration) && a.duration > 0 ? a.duration : +box.dataset.dur;
  box.classList.toggle("active", !!a);
  box.classList.toggle("playing", !!a && !a.paused);
  box.classList.toggle("loading", cur && VP.loading);
  const dragging = typeof box._drag === "number";
  box.querySelector(".vfill").style.width = (dragging ? box._drag * 100 : a && dur ? Math.min(100, a.currentTime / dur * 100) : 0) + "%";
  box.querySelector(".vtime").textContent = dragging ? fmtDur(box._drag * dur) + " / " + fmtDur(dur) : a && (a.currentTime > 0 || !a.paused) ? fmtDur(a.currentTime) + " / " + fmtDur(dur) : fmtDur(dur);
  box.querySelector(".vspd").textContent = VP.rate + "x";
}
function paintVoices() { document.querySelectorAll(".vbox").forEach(paintVoice); }
function voiceSeek(m, frac) {
  frac = Math.max(0, Math.min(1, frac));
  const a = VP.id === m.id ? VP.audio : null;
  if (a && isFinite(a.duration) && a.duration > 0) { a.currentTime = frac * a.duration; if (a.paused) a.play().catch(() => {}); paintVoices(); return; }
  const p = VP.id === m.id && VP.audio ? null : voiceToggle(m);
  VP.pending = {id: m.id, frac};
  if (p) p.catch(() => {});
}
async function voiceToggle(m) {
  if (VP.id === m.id && VP.audio) { if (VP.audio.paused) VP.audio.play().catch(() => {}); else VP.audio.pause(); paintVoices(); return; }
  if (VP.loading) return;
  voiceStop();
  VP.id = m.id; VP.loading = true; paintVoices();
  try {
    const blob = await fetchFileBlob(m, "audio/wav");
    if (VP.id !== m.id) return;
    const url = URL.createObjectURL(blob), a = new Audio();
    a.preload = "auto"; a.src = url; a.playbackRate = VP.rate;
    ["timeupdate", "play", "pause", "loadedmetadata", "durationchange"].forEach(ev => a.addEventListener(ev, paintVoices));
    a.addEventListener("loadedmetadata", () => {
      const pd = VP.pending; if (!pd || pd.id !== m.id || VP.audio !== a) return;
      const d = isFinite(a.duration) && a.duration > 0 ? a.duration : (m.file.dur || 0);
      if (d) { try { a.currentTime = pd.frac * d; } catch (_) {} }
      VP.pending = null;
    });
    a.addEventListener("ended", () => { a.currentTime = 0; paintVoices(); });
    a.addEventListener("error", () => { if (VP.audio === a) { toast("Ovozni ijro etib bo'lmadi", "error"); voiceStop(); } });
    VP.audio = a; VP.url = url; VP.loading = false; paintVoices();
    await a.play().catch(() => {});
  } catch (_) { if (VP.id === m.id) { toast("Ovozni yuklab bo'lmadi", "error"); voiceStop(); } }
}
function voiceBox(m) {
  const f = m.file, dur = f.dur || Math.max(1, (f.size - 44) / 32000);
  const box = h("div", {class: "vbox"});
  box.dataset.vid = m.id; box.dataset.dur = dur;
  const play = h("button", {class: "vplay", type: "button", "aria-label": "Ovozli xabarni ijro etish"}, icon("play", "ic vi-play"), icon("pause", "ic vi-pause"), spinnerEl());
  play.addEventListener("click", e => { e.stopPropagation(); voiceToggle(m); });
  const fill = h("div", {class: "vfill"}), track = h("div", {class: "vtrack", role: "slider", tabindex: "0", "aria-label": "Ovozli xabar vaqti", "aria-valuemin": "0", "aria-valuemax": "100"}, h("div", {class: "vline"}, fill));
  const fracOf = e => { const r = track.getBoundingClientRect(); return r.width ? Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)) : 0; };
  let drag = null;
  track.addEventListener("pointerdown", e => {
    if (e.button) return; e.stopPropagation();
    try { track.setPointerCapture(e.pointerId); } catch (_) {}
    drag = e.pointerId; box._drag = fracOf(e); box.classList.add("seeking"); paintVoice(box);
  });
  track.addEventListener("pointermove", e => { if (drag !== e.pointerId) return; box._drag = fracOf(e); paintVoice(box); });
  const endDrag = (e, ok) => {
    if (drag !== e.pointerId) return;
    const f = box._drag; drag = null; box._drag = null; box.classList.remove("seeking");
    if (ok && typeof f === "number") voiceSeek(m, f);
    paintVoices();
  };
  track.addEventListener("pointerup", e => endDrag(e, true));
  track.addEventListener("pointercancel", e => endDrag(e, false));
  track.addEventListener("click", e => e.stopPropagation());
  track.addEventListener("keydown", e => {
    if (e.key !== "ArrowLeft" && e.key !== "ArrowRight") return;
    const a = VP.id === m.id ? VP.audio : null; if (!a || !isFinite(a.duration) || a.duration <= 0) return;
    e.preventDefault(); e.stopPropagation(); a.currentTime = Math.max(0, Math.min(a.duration, a.currentTime + (e.key === "ArrowRight" ? 5 : -5))); paintVoices();
  });
  const spd = h("button", {class: "vspd", type: "button", title: "Tezlik", "aria-label": "Ijro tezligi"});
  spd.addEventListener("click", e => { e.stopPropagation(); VP.rate = VP.rate === 1 ? 1.5 : VP.rate === 1.5 ? 2 : 1; if (VP.audio) VP.audio.playbackRate = VP.rate; paintVoices(); });
  box.append(play, h("div", {class: "vmid"}, track, h("div", {class: "vmeta"}, h("span", {class: "vtime"}), spd)));
  paintVoice(box);
  return box;
}

const VN = {id: null, video: null, audio: null, vurl: null, aurl: null, loading: false, ended: false, raf: 0, seq: 0};
let vnHost = null;
function vnHostEl() { if (!vnHost) { vnHost = h("div", {class: "vn-host", "aria-hidden": "true"}); document.body.append(vnHost); } return vnHost; }
const vnMaster = () => VN.audio || VN.video;
function vnStop() {
  VN.seq++; if (VN.raf) cancelAnimationFrame(VN.raf);
  const {video: v, audio: a, vurl, aurl} = VN;
  if (a) { try { a.pause(); a.removeAttribute("src"); a.load(); } catch (_) {} }
  if (v) { try { v.pause(); v.removeAttribute("src"); v.load(); } catch (_) {} v.remove(); }
  [vurl, aurl].forEach(u => { if (u) URL.revokeObjectURL(u); });
  Object.assign(VN, {id: null, video: null, audio: null, vurl: null, aurl: null, loading: false, ended: false, raf: 0});
  paintVNs();
}
function drawCover(cv, v) {
  const w = v.videoWidth, hh = v.videoHeight; if (!w || !hh) return;
  const s = Math.min(w, hh), n = cv.width;
  cv.getContext("2d").drawImage(v, (w - s) / 2, (hh - s) / 2, s, s, 0, 0, n, n);
}
function paintVN(box) {
  const id = +box.dataset.vnid, cur = VN.id === id, v = cur ? VN.video : null, a = cur ? vnMaster() : null;
  const ready = !!(cur && v && !VN.loading), playing = ready && !!a && !a.paused && !VN.ended;
  const total = +box.dataset.dur || (a && isFinite(a.duration) ? a.duration : 0), t = ready && !VN.ended && a ? a.currentTime : 0;
  box.classList.toggle("ready", ready); box.classList.toggle("playing", playing); box.classList.toggle("loading", cur && VN.loading);
  box.querySelector(".vnr-fg").setAttribute("stroke-dashoffset", String(301.6 * (1 - (total ? Math.min(1, t / total) : 0))));
  box.querySelector(".vndur").textContent = ready && (playing || t > 0) ? fmtDur(t) + " / " + fmtDur(total) : fmtDur(total);
  if (ready && v.readyState >= 2) drawCover(box.querySelector("canvas"), v);
}
function paintVNs() { document.querySelectorAll(".vnbox").forEach(paintVN); }
function vnTick() {
  VN.raf = 0;
  const v = VN.video, a = VN.audio; if (!v) return;
  if (a && !a.paused && !v.seeking) {
    if (v.paused && !v.ended) v.play().catch(() => {});
    if (Math.abs(v.currentTime - a.currentTime) > 0.25) { try { v.currentTime = a.currentTime; } catch (_) {} }
  }
  paintVNs();
  const m = vnMaster();
  if (m && !m.paused && !VN.ended) VN.raf = requestAnimationFrame(vnTick);
}
const vnKick = () => { if (!VN.raf) VN.raf = requestAnimationFrame(vnTick); };
async function vnPlayBoth() {
  const v = VN.video, a = VN.audio; if (!v) return;
  try { await Promise.all([v.play(), a ? a.play() : null]); vnKick(); }
  catch (_) { try { v.pause(); if (a) a.pause(); } catch (__) {} toast("Ijro etib bo'lmadi. Yana bir bor bosing", "error"); }
  paintVNs();
}
async function vnToggle(m) {
  if (VN.id === m.id) {
    if (VN.loading || !VN.video) return;
    const v = VN.video, a = VN.audio;
    if (VN.ended) { VN.ended = false; try { v.currentTime = 0; if (a) a.currentTime = 0; } catch (_) {} await vnPlayBoth(); }
    else if (vnMaster().paused) await vnPlayBoth();
    else { v.pause(); if (a) a.pause(); }
    paintVNs(); return;
  }
  voiceStop();
  const token = VN.seq; VN.id = m.id; VN.loading = true; paintVNs();
  const alive = () => VN.seq === token && VN.id === m.id;
  let v = null, a = null, vurl = null, aurl = null, adopted = false;
  try {
    const parts = VNote.unpack(await e2eFetchBlob(m));
    if (!alive()) return;
    v = document.createElement("video");
    if (!v.canPlayType(m.file.mime)) throw new Error("format");
    v.muted = true; v.playsInline = true; v.preload = "auto"; v.disablePictureInPicture = true; v.disableRemotePlayback = true;
    v.setAttribute("controlsList", "nodownload noremoteplayback"); v.oncontextmenu = e => { e.preventDefault(); return false; };
    v.setAttribute("playsinline", ""); v.setAttribute("webkit-playsinline", "");
    vurl = URL.createObjectURL(new Blob([parts.video], {type: m.file.mime}));
    if (parts.audio) { aurl = URL.createObjectURL(new Blob([parts.audio], {type: "audio/wav"})); a = new Audio(); a.preload = "auto"; a.src = aurl; }
    vnHostEl().append(v); v.src = vurl;
    await new Promise((res, rej) => {
      if (v.readyState >= 2) return res();
      const t = setTimeout(() => rej(new Error("vaqt")), 15000);
      v.addEventListener("loadeddata", () => { clearTimeout(t); res(); }, {once: true});
      v.addEventListener("error", () => { clearTimeout(t); rej(new Error("video")); }, {once: true});
    });
    if (!alive()) return;
    adopted = true;
    Object.assign(VN, {video: v, audio: a, vurl, aurl, loading: false, ended: false});
    const mst = a || v;
    ["play", "pause", "seeked", "loadedmetadata"].forEach(ev => mst.addEventListener(ev, () => { paintVNs(); if (!mst.paused) vnKick(); }));
    v.addEventListener("seeked", paintVNs);
    mst.addEventListener("ended", () => {
      if (VN.video !== v) return;
      VN.ended = true; v.pause(); if (a) a.pause();
      try { v.currentTime = 0; } catch (_) {}
      paintVNs();
    });
    if (a) a.addEventListener("error", () => { if (VN.audio === a) { toast("Ovozni ijro etib bo'lmadi", "error"); vnStop(); } });
    v.addEventListener("error", () => { if (VN.video === v) { toast("Videoni ijro etib bo'lmadi", "error"); vnStop(); } });
    paintVNs();
    await vnPlayBoth();
  } catch (_) {
    if (!adopted) { if (v) v.remove(); [vurl, aurl].forEach(u => { if (u) URL.revokeObjectURL(u); }); }
    if (alive()) { toast("Video xabarni ochib bo'lmadi", "error"); vnStop(); }
  }
}
function vnoteBox(m) {
  const f = m.file, NSV = "http://www.w3.org/2000/svg";
  const box = h("div", {class: "vnbox", role: "button", tabindex: "0", "aria-label": "Video xabarni ijro etish"});
  box.dataset.vnid = m.id; box.dataset.dur = f.dur || 0;
  const c = h("div", {class: "vnc"});
  if (f.th) c.append(h("img", {class: "vnth", alt: "", draggable: "false", src: f.th}));
  c.append(h("canvas", {width: 360, height: 360}), h("span", {class: "vnplay", "aria-hidden": "true"}, icon("play", "ic"), spinnerEl()), h("span", {class: "vndur"}));
  const ring = document.createElementNS(NSV, "svg"); ring.setAttribute("class", "vnring"); ring.setAttribute("viewBox", "0 0 100 100"); ring.setAttribute("aria-hidden", "true");
  [["vnr-bg", false], ["vnr-fg", true]].forEach(([cls, fg]) => {
    const ci = document.createElementNS(NSV, "circle"); ci.setAttribute("class", cls); ci.setAttribute("cx", 50); ci.setAttribute("cy", 50); ci.setAttribute("r", 48);
    if (fg) ci.setAttribute("stroke-dashoffset", "301.6"); ring.append(ci);
  });
  box.append(c, ring);
  ["contextmenu", "dragstart", "selectstart"].forEach(ev => box.addEventListener(ev, e => e.preventDefault()));
  const go = e => { e.stopPropagation(); vnToggle(m); };
  box.addEventListener("click", go);
  box.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); go(e); } });
  paintVN(box);
  return box;
}
function fullImg(m) {
  const img = h("img", {class: "mimg", alt: "Rasm", draggable: "false"});
  img.addEventListener("load", () => { const b = $("msgs"); if (b._stick) b.scrollTop = b.scrollHeight; });
  imgSrcOf(m).then(u => { img.src = u; }).catch(() => {});
  return img;
}
function startImageLoad(m, box) {
  S.imgs.set(m.id, "loading"); box.classList.add("loading");
  const t0 = performance.now(), pre = new Image();
  const done = (ok, err) => {
    const wait = Math.max(0, 550 - (performance.now() - t0));
    setTimeout(() => {
      if (!ok) {
        S.imgs.delete(m.id); toast(err && err.expired ? EXPIRED_MSG : "Rasmni yuklab bo'lmadi", "error");
        const b = document.querySelector('#msgs .row[data-id="' + m.id + '"] .imgbox'); if (b) b.classList.remove("loading");
        return;
      }
      S.imgs.set(m.id, "open");
      const cur = document.querySelector('#msgs .row[data-id="' + m.id + '"] .imgbox');
      if (!cur) return;
      const img = fullImg(m); img.classList.add("reveal");
      cur.classList.remove("loading"); cur.classList.add("open"); cur.setAttribute("aria-label", "Rasmni kattalashtirish");
      cur.append(img);
      void cur.offsetWidth;
      requestAnimationFrame(() => cur.classList.add("clear"));
      setTimeout(() => cur.querySelectorAll(".mthumb,.mdl").forEach(x => x.remove()), 450);
    }, wait);
  };
  pre.onload = () => done(true); pre.onerror = () => done(false);
  imgSrcOf(m).then(u => { pre.src = u; }).catch(e => done(false, e));
}

