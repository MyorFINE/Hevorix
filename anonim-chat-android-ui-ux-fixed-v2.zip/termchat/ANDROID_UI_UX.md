# Android UI/UX updates

This build adds a touch-first responsive layer to the existing web chat without changing API routes, DOM IDs, encryption logic, or application event handlers.

## Improvements
- Android viewport and safe-area handling (`100dvh`, system inset padding).
- Larger touch targets for chat header, message composer, tabs, and auth form.
- Mobile login/register layout tuned for narrow screens and landscape orientation.
- Chat list and conversation remain separate full-screen views on small screens.
- Composer uses 16px text to avoid browser auto-zoom and respects device safe areas.
- Bottom-sheet behavior for dialogs, safer scrolling, and reduced-motion support.
- Touch feedback, focus-visible styles, and responsive spacing for compact devices.

## Verification
- Existing DOM IDs and JS handlers are preserved.
- CSS is additive; no backend/API or cryptography changes are included in this UI pass.
- Manual QA recommended on Android Chrome at 360x800, 390x844, 412x915, and landscape 800x360; test with keyboard open, long messages, file picker, voice recording, modals, and both light/dark themes.

## Qo‘shimcha tuzatish — kesiladigan modal oynalar

- Android Chrome `visualViewport` orqali haqiqiy ko‘rinadigan balandlik kuzatiladi; manzil paneli yoki virtual klaviatura ochilganda modal qayta moslashadi.
- Profil, guruh ma’lumoti, admin va boshqa modal oynalar ekran balandligidan oshmaydi; uzun kontent ichida aylantiriladi.
- Tasdiqlash/prompt dialoglari va rasm lightbox ham past ekranlarda kesilib qolmasligi uchun cheklangan balandlik va ichki scroll oladi.
- Qisqa ekran va landscape rejimi uchun alohida qoidalar qo‘shilgan.

