# Anonim Chat — qo'ng'iroq audiosi bo'yicha audit

## Tuzatilgan joylar
- Mobil brauzerda `getUserMedia` uchun qattiq `channelCount: 1` talabi olib tashlandi.
- `AudioWorklet`/`AudioContext` ishga tushmasa, qo'ng'iroq endi butunlay to'xtamaydi: standart mikrofon treki E2EE WebRTC transform orqali yuboriladi. Ovoz effekti ishlamaganida UI ogohlantiradi.
- `AudioContext` va analyser ixtiyoriy qilindi; analyser yo'qligi audio uzatishni to'xtatmaydi.
- Mikrofon treki yo'qligi va async ochilish vaqtida qo'ng'iroq bekor qilingan holatlar tekshirildi.
- Masofaviy audio `MediaStream` bilan yoki `e.track` orqali keladigan brauzerlarning ikkala ko'rinishi ham qo'llab-quvvatlanadi; track unmute bo'lganda playback qayta boshlanadi.
- AudioContext bo'lmagan mikrofon fallback holatida cleanup xavfsiz qilindi.

## Tekshiruv
Muvaffaqiyatli:
- `node --check` — static JavaScript fayllari sintaksisi.
- `tests/call_flow_test.mjs`
- `tests/call_crypto_test.mjs`
- `tests/call_fx_test.mjs`
- `tests/call_server_test.py`
- Python `compileall` — `app/`.

Butun pytest to'plamida 154 test o'tdi, 14 test yiqildi. Ular qo'ng'iroq testlari emas; asosan API testlaridagi response key farqlari, test DB/emoji state ifloslanishi, backup/E2EE/session va secure-log kutishlari bilan bog'liq. Ularni qo'ng'iroq patchi bilan bog'liq deb ko'rsatib bo'lmaydi va alohida audit talab qiladi.

## Render / TURN konfiguratsiyasi
Kod quyidagi nomlarni o'qiydi:
- `CALL_TURN_KEY_ID`
- `CALL_TURN_KEY_TOKEN`
Ixtiyoriy coturn fallback:
- `CALL_TURN_URLS`
- `CALL_TURN_USERNAME`
- `CALL_TURN_CREDENTIAL`
Ixtiyoriy STUN:
- `CALL_STUN_URLS`

`CALL_TURN_KEY_ID` — Cloudflare Realtime TURN key ID; `CALL_TURN_KEY_TOKEN` — TURN credentials yaratish endpointiga ruxsati bor Cloudflare API bearer token. Bu qiymatlar server tomonda qolishi kerak, frontendga joylanmasin.

## Muhim
Bu patch koddagi mobil audio compatibility va remote playback muammolarini yumshatadi, lekin haqiqiy ikki qurilmali qo'ng'iroqni Render/Cloudflare orqali ushbu muhitdan sinab bo'lmaydi. Deploydan keyin ikkala qurilmada sahifani to'liq yangilab, yangi SRI versiyali `call.js` yuklanganini tekshirish kerak. Qo'ng'iroq oynasidagi diagnostika satrida:
- `mik` — mikrofon kirish darajasi;
- `↑` — yuborilgan audio RTP baytlari;
- `↓` — qabul qilingan RTP baytlari;
- `dekod` / `tovush` — qabul qilingan va dekodlangan audio holati.
