#!/usr/bin/env python3
"""To'liq ma'lumotlar zaxirasi: yaratish, tekshirish, tiklash. (app/datasnap.py ning buyruq satri shakli)

    python tools/datasnap.py backup  [--data data] [--out zaxira.tar.gz] [--db-only]
    python tools/datasnap.py verify  zaxira.tar.gz
    python tools/datasnap.py restore zaxira.tar.gz [--data data] [--force]     (avval serverni TO'XTATING)

Arxivga master.key / vapid.key KIRMAYDI — ularni alohida saqlang (ularsiz server-shifrlangan ma'lumotlar ochilmaydi).
"""
import argparse
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from app import datasnap  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    b = sub.add_parser("backup")
    b.add_argument("--data", default="data")
    b.add_argument("--out", default=None)
    b.add_argument("--db-only", action="store_true", help="faqat baza (fayllarsiz)")
    v = sub.add_parser("verify")
    v.add_argument("archive")
    r = sub.add_parser("restore")
    r.add_argument("archive")
    r.add_argument("--data", default="data")
    r.add_argument("--force", action="store_true")
    a = ap.parse_args()
    try:
        if a.cmd == "backup":
            out = Path(a.out or f"termchat-backup-{time.strftime('%Y%m%d-%H%M%S')}.tar.gz")
            m = datasnap.create(Path(a.data), out, include_files=not a.db_only)
            print(f"OK: {out}  ({len(m['files'])} fayl, {m['counts']})")
        elif a.cmd == "verify":
            m = datasnap.verify(Path(a.archive))
            print(f"OK: arxiv butun ({len(m['files'])} fayl, {m['counts']})")
        else:
            res = datasnap.restore(Path(a.archive), Path(a.data), force=a.force)
            print(f"OK: {res['restored']} fayl tiklandi. Oldingi ma'lumotlar: {res['previous_moved_to'] or 'yo`q edi'}")
    except datasnap.SnapshotError as e:
        print(f"XATO: {e}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
