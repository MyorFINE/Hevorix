#!/usr/bin/env python3
"""Anonim Chat foydalanuvchilar zaxirasini (.acdb) ochish — js/backup.js bilan bir xil format.

    python tools/decode_backup.py anonim-chat-users-20261029.acdb            # JSON'ni stdout'ga (parol-ibora so'raladi)
    python tools/decode_backup.py zaxira.acdb --summary                      # faqat ro'yxat: username, nickname, rol, qo'shilgan

Format: "ACDB1\\n" | tuz(16) | PBKDF2 aylanishlari u32 BE | iv(12) | AES-256-GCM(JSON); AAD = sarlavha.
Kalit: PBKDF2-SHA256(NFKC(parol-ibora) UTF-8, tuz, aylanishlar). Faqat `cryptography` kerak.
"""
from __future__ import annotations

import argparse
import getpass
import json
import sys
import time
import unicodedata

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

MAGIC = b"ACDB1\n"
SALT, IV = 16, 12
MIN_ITER, MAX_ITER = 100_000, 3_000_000


def _key(passphrase: str, salt: bytes, iterations: int) -> bytes:
    kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=iterations)
    return kdf.derive(unicodedata.normalize("NFKC", passphrase).encode("utf-8"))


def seal(obj, passphrase: str, iterations: int = 600_000) -> bytes:
    """Sinov uchun (brauzer faylni o'zi yaratadi)."""
    import os
    salt, iv = os.urandom(SALT), os.urandom(IV)
    head = MAGIC + salt + iterations.to_bytes(4, "big")
    ct = AESGCM(_key(passphrase, salt, iterations)).encrypt(iv, json.dumps(obj, separators=(",", ":")).encode(), head)
    return head + iv + ct


def open_backup(data: bytes, passphrase: str):
    hl = len(MAGIC) + SALT + 4
    if len(data) < hl + IV + 16 or not data.startswith(MAGIC):
        raise ValueError("Bu Anonim Chat zaxira fayli emas")
    salt = data[len(MAGIC):len(MAGIC) + SALT]
    iterations = int.from_bytes(data[len(MAGIC) + SALT:hl], "big")
    if not MIN_ITER <= iterations <= MAX_ITER:
        raise ValueError("Zaxira fayli buzilgan")
    try:
        plain = AESGCM(_key(passphrase, salt, iterations)).decrypt(data[hl:hl + IV], data[hl + IV:], data[:hl])
    except InvalidTag:
        raise ValueError("Parol-ibora noto'g'ri yoki fayl o'zgartirilgan/buzilgan") from None
    return json.loads(plain.decode("utf-8"))


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("file")
    ap.add_argument("--summary", action="store_true", help="faqat qisqa ro'yxat")
    args = ap.parse_args()
    with open(args.file, "rb") as f:
        raw = f.read()
    try:
        data = open_backup(raw, getpass.getpass("Parol-ibora: "))
    except ValueError as e:
        print(e, file=sys.stderr)
        return 1
    if args.summary:
        for u in data.get("users", []):
            ago = (time.time() - u["joined"]) / 86400
            print(f'@{u["username"]:<20} {u["nickname"]:<24} {u["role"]:<6} {ago:7.1f} kun oldin qo\'shilgan  rasm: {"bor" if u.get("avatar") else "yo\'q"}')
    else:
        for u in data.get("users", []):                       # rasm va kirish ma'lumotini ekranga bosib yubormaymiz
            if u.get("avatar"):
                u["avatar"] = {"ext": u["avatar"]["ext"], "bytes": len(u["avatar"]["data"]) * 3 // 4}
            u["cred"] = "(yashirildi)"
        json.dump(data, sys.stdout, ensure_ascii=False, indent=1)
        print()
    return 0


if __name__ == "__main__":
    sys.exit(main())
