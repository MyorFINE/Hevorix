"""Realtime, tarix sahifalash, faolsizlik sessiyasi, onlayn/oflayn, media boshqaruvi, yangi foydalanuvchi belgisi
(FastAPI talab qilinmaydi)."""
import asyncio
import json
import time

import pytest

import app.realtime.manager as mgr
from app.errors import ChatError
from app.realtime.manager import manager
from app.repositories import e2ee as e2ee_repo
from app.repositories import messages, sessions, users
from app.security import hash_token
from app.services import auth, bootstrap, chat, mediamgr, views


class FakeWS:
    def __init__(self, hang=False):
        self.sent, self.closed, self.hang = [], None, hang

    async def send_text(self, s):
        if self.hang:
            await asyncio.sleep(3600)                 # javob bermaydigan (qotgan) mijoz
        self.sent.append(json.loads(s))

    async def close(self, code):
        self.closed = code


_n = [0]


def _user():
    _n[0] += 1
    tok, me = auth.register(f"rt{_n[0]}", "RT", "secret12")
    return tok, users.get(me["id"])


def test_initial_history_is_10_and_older_pages_load_on_scroll():
    _, u = _user()
    ids = [chat.post(u, f"x{i}")["id"] for i in range(47)]
    first, more = chat.history_page()
    assert len(first) == 10 and more and [m["id"] for m in first] == ids[-10:]           # dastlab faqat 10 ta
    page2, more2 = chat.history_page(before=first[0]["id"], limit=30)                     # tepaga chiqilganda oldingilari
    assert more2 and len(page2) == 30 and page2[-1]["id"] < first[0]["id"]
    assert [m["id"] for m in page2] == sorted(m["id"] for m in page2)                      # tartib: eskidan yangiga
    seen = {m["id"] for m in first} | {m["id"] for m in page2}
    rest, more3 = chat.history_page(before=page2[0]["id"], limit=30)
    assert not seen & {m["id"] for m in rest}                                              # takrorlanmaydi
    assert not more3 or len(rest) == 30


def test_dm_history_paging():
    _, a = _user(); _, b = _user()
    ids = [chat.post(a if i % 2 else b, f"dm{i}", to=(b if i % 2 else a)["id"])["id"] for i in range(25)]
    last, more = chat.dm_history_page(a, b["id"])
    assert len(last) == 10 and more and last[-1]["id"] == ids[-1]
    older, more2 = chat.dm_history_page(a, b["id"], before=last[0]["id"], limit=30)
    assert len(older) == 15 and not more2 and older[-1]["id"] < last[0]["id"]


def test_session_expires_after_idle_and_active_ping_extends_it():
    tok, u = _user()
    th = hash_token(tok)
    assert auth.authenticate(tok)
    sessions.touch(th, time.time() - auth.idle_limit() - 5)                              # 5+ daqiqa tegilmagan
    assert auth.authenticate(tok) is None
    tok2, _ = auth.login(u["username"], "secret12")                                      # qayta login — yangi sessiya
    assert auth.authenticate(tok2)
    sessions.touch(hash_token(tok2), time.time() - auth.idle_limit() + 30)               # tugashiga oz qoldi
    auth._touched.clear()
    assert auth.authenticate(tok2, active=True)                                          # faol harakat — muddat yangilanadi
    assert auth.authenticate(tok2)


def test_purge_idle_sessions():
    tok, _ = _user()
    sessions.touch(hash_token(tok), time.time() - 10_000)
    assert auth.purge_idle_sessions() >= 1
    assert sessions.get_user(hash_token(tok)) is None


def test_away_means_offline_and_back_means_online():
    _, u = _user()
    ws1, ws2 = FakeWS(), FakeWS()
    assert manager.connect(u["id"], ws1) is True and u["id"] in manager.online_ids()
    assert manager.set_away(u["id"], ws1, True) is True and u["id"] not in manager.online_ids()   # sahifa yashirildi -> oflayn
    assert manager.connect(u["id"], ws2) is True                                          # boshqa faol ulanish -> yana onlayn
    assert manager.set_away(u["id"], ws1, False) is False                                 # allaqachon onlayn
    assert manager.disconnect(u["id"], ws2) is False and u["id"] in manager.online_ids()
    assert manager.disconnect(u["id"], ws1) is True and u["id"] not in manager.online_ids()


def test_one_stuck_client_does_not_block_others():
    _, a = _user(); _, b = _user()
    stuck, fine = FakeWS(hang=True), FakeWS()
    manager.connect(a["id"], stuck); manager.connect(b["id"], fine)
    old = mgr.SEND_TIMEOUT
    mgr.SEND_TIMEOUT = 0.2
    try:
        t0 = time.monotonic()
        asyncio.run(manager.broadcast({"type": "message", "id": 1}))
        assert time.monotonic() - t0 < 2                                                   # qotgan mijoz kutdirmadi
    finally:
        mgr.SEND_TIMEOUT = old
        manager.disconnect(a["id"], stuck); manager.disconnect(b["id"], fine)
    assert fine.sent == [{"type": "message", "id": 1}] and stuck.closed == 1011


def test_media_manager_lists_and_deletes_e2ee_files():
    """Oldin e2e ustuni so'ralmagani uchun ro'yxat server xatosi (500) berardi."""
    bootstrap.ensure_owner()
    admin = users.get_by_username("hevorix")
    _, u = _user()
    e2ee_repo.add_blob("e" * 32 + ".e2e", u["id"], 1234)
    mid = messages.create(u["id"], "e2e1:xxxx", time.time(), None, None, None, None, None, "e" * 32 + ".e2e", None, None, 1234, e2e=True)
    items = mediamgr.listing()["items"]
    row = [i for i in items if i["id"] == mid][0]
    assert row["kind"] == "e2e" and row["size"] == 1234
    done = mediamgr.remove(admin, [mid])
    assert [(r["id"], gone) for r, gone in done] == [(mid, True)]
    assert e2ee_repo.get_blob("e" * 32 + ".e2e") is None and messages.get_active(mid) is None


def test_new_users_are_marked_untrusted_but_staff_is_not():
    bootstrap.ensure_owner()
    _, u = _user()
    assert views.user_view(u["id"])["new"] is True
    owner = users.get_by_username("hevorix")
    assert views.user_view(owner["id"])["new"] is False
    from app.config import settings
    users_conn = __import__("app.db", fromlist=["db"]).db
    users_conn.run("UPDATE users SET created_at=? WHERE id=?", (time.time() - (settings.new_user_days + 1) * 86400, u["id"]))
    assert views.user_view(u["id"])["new"] is False                                       # vaqt o'tgach ishonchli bo'ladi


def test_banned_words_filter_is_gone():
    from app.services import modsettings
    assert "words" not in modsettings.get() and not hasattr(modsettings, "set_words")
    _, u = _user()
    chat.post(u, "istalgan matn o'tadi")
