"""Web Push: RFC 8291 shifrlash (qabul qiluvchi tomoni mustaqil yozilgan), VAPID imzo va endpoint himoyasi."""
import base64
import json
import os

import pytest
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.utils import encode_dss_signature
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

from app.errors import ChatError
from app.services import webpush


def b64d(s): return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))
def b64e(b): return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def make_ua():
    priv = ec.generate_private_key(ec.SECP256R1())
    pub = priv.public_key().public_bytes(serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint)
    auth = os.urandom(16)
    return priv, pub, auth


def decrypt(body: bytes, ua_priv, ua_pub: bytes, auth: bytes) -> bytes:
    salt, rs, idlen = body[:16], int.from_bytes(body[16:20], "big"), body[20]
    as_pub, ct = body[21:21 + idlen], body[21 + idlen:]
    assert rs == 4096 and idlen == 65
    shared = ua_priv.exchange(ec.ECDH(), ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(), as_pub))
    ikm = HKDF(hashes.SHA256(), 32, auth, b"WebPush: info\x00" + ua_pub + as_pub).derive(shared)
    cek = HKDF(hashes.SHA256(), 16, salt, b"Content-Encoding: aes128gcm\x00").derive(ikm)
    nonce = HKDF(hashes.SHA256(), 12, salt, b"Content-Encoding: nonce\x00").derive(ikm)
    plain = AESGCM(cek).decrypt(nonce, ct, None)
    assert plain.endswith(b"\x02")
    return plain[:-1]


def test_encrypt_roundtrip():
    priv, pub, auth = make_ua()
    msg = json.dumps({"k": "g", "n": "Ali"}).encode()
    body = webpush.encrypt(msg, b64e(pub), b64e(auth))
    assert decrypt(body, priv, pub, auth) == msg
    assert webpush.encrypt(msg, b64e(pub), b64e(auth)) != body          # har safar yangi tuz/kalit


def test_encrypt_rejects_bad_keys():
    with pytest.raises(ValueError):
        webpush.encrypt(b"x", b64e(b"\x04" + b"0" * 10), b64e(os.urandom(16)))


def test_vapid_signature_verifies():
    hdr = webpush._vapid_header("https://fcm.googleapis.com/fcm/send/abc")
    t = hdr.split("t=")[1].split(",")[0]
    k = hdr.split("k=")[1]
    head, claims, sig = t.split(".")
    assert json.loads(b64d(head)) == {"typ": "JWT", "alg": "ES256"}
    c = json.loads(b64d(claims))
    assert c["aud"] == "https://fcm.googleapis.com" and c["exp"] > 0
    raw = b64d(sig)
    assert len(raw) == 64
    pub = ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(), b64d(k))
    pub.verify(encode_dss_signature(int.from_bytes(raw[:32], "big"), int.from_bytes(raw[32:], "big")),
               f"{head}.{claims}".encode(), ec.ECDSA(hashes.SHA256()))
    assert k == webpush.public_key()


@pytest.mark.parametrize("url", [
    "https://fcm.googleapis.com/fcm/send/xyz",
    "https://updates.push.services.mozilla.com/wpush/v2/abc",
    "https://web.push.apple.com/QWERTY",
    "https://wns2-par02p.notify.windows.com/w/?token=abc",
])
def test_endpoint_allowed(url):
    assert webpush.validate_endpoint(url) == url


@pytest.mark.parametrize("url", [
    "http://fcm.googleapis.com/x", "https://127.0.0.1/x", "https://localhost/x", "https://evil.com/x",
    "https://fcm.googleapis.com.evil.com/x", "https://user:pw@fcm.googleapis.com/x", "https://fcm.googleapis.com:8443/x",
    "https://evilgoogleapis.com/x", "ftp://fcm.googleapis.com/x", "",
])
def test_endpoint_blocked(url):
    with pytest.raises(ChatError):
        webpush.validate_endpoint(url)
