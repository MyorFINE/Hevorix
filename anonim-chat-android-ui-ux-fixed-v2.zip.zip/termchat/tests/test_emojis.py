"""Maxsus rasmli emoji nishonlar (:kali: :linux: :anon: :ghost:)."""
import pytest

from app import emojis
from app.errors import ChatError
from app.services import badges


def test_builtin_emojis_present():
    emojis.reset_cache()
    names = set(emojis.available())
    assert {"kali", "linux", "anon", "ghost"} <= names
    assert all(e["token"] == f":{e['name']}:" for e in emojis.listing())


def test_clean_accepts_custom_token_with_anim():
    emojis.reset_cache()
    assert badges.clean(":kali:", "glow") == (":kali:", "glow")
    assert badges.clean(":ghost:", "") == (":ghost:", None)


@pytest.mark.parametrize("bad", [":nope:", ":../x:", ":kali", "kali:", ":KALI:", ":a:", ":kali:x", "::", ":" + "a" * 20 + ":"])
def test_clean_rejects_unknown_tokens(bad):
    emojis.reset_cache()
    with pytest.raises(ChatError):
        badges.clean(bad, "")


def test_new_emoji_picked_up_from_folder(tmp_path, monkeypatch):
    (tmp_path / "nmap.svg").write_text("<svg xmlns='http://www.w3.org/2000/svg'/>")
    (tmp_path / "Bad Name.svg").write_text("<svg/>")
    (tmp_path / "x.svg").write_text("<svg/>")                     # juda qisqa nom
    monkeypatch.setattr(emojis, "EMOJI_DIR", tmp_path)
    emojis.reset_cache()
    assert list(emojis.available()) == ["nmap"]
    assert badges.clean(":nmap:", "")[0] == ":nmap:"
    monkeypatch.undo()
    emojis.reset_cache()
