// Reaksiya chiplarini yangilash (rxSync): qayta yaratmasdan yangilash, yangi chip "in", yo'qolgani "out", son o'zgarishi, tartib.
import fs from "node:fs";
import vm from "node:vm";
import assert from "node:assert/strict";

const src = fs.readFileSync(new URL("../app/static/js/app.js", import.meta.url), "utf8");
const a = src.indexOf("function rxChip(e)"), b = src.indexOf("function reactionsEl(m)");
assert.ok(a > 0 && b > a);

class El {
  constructor(tag) { this.tag = tag; this.kids = []; this.parent = null; this.cl = new Set(); this.dataset = {}; this.ls = {}; this.text = ""; this.attrs = {};
    this.classList = {add: (...c) => c.forEach(x => this.cl.add(x)), remove: (...c) => c.forEach(x => this.cl.delete(x)), contains: c => this.cl.has(c), toggle: (c, on) => { (on ? this.cl.add(c) : this.cl.delete(c)); return on; }}; }
  get children() { return this.kids; } get firstElementChild() { return this.kids[0] || null; }
  get nextElementSibling() { if (!this.parent) return null; const k = this.parent.kids; return k[k.indexOf(this) + 1] || null; }
  append(...n) { n.forEach(x => { if (typeof x === "string") return; if (x.parent) x.remove(); x.parent = this; this.kids.push(x); }); }
  insertBefore(n, ref) { if (n.parent) n.remove(); n.parent = this; const i = ref ? this.kids.indexOf(ref) : -1; if (i < 0) this.kids.push(n); else this.kids.splice(i, 0, n); }
  remove() { if (this.parent) { this.parent.kids.splice(this.parent.kids.indexOf(this), 1); this.parent = null; } }
  addEventListener(t, f) { this.ls[t] = f; } setAttribute(k, v) { this.attrs[k] = v; }
  set textContent(v) { this.text = String(v); } get textContent() { return this.text + this.kids.map(k => k.textContent).join(""); }
  querySelector(sel) { return this.querySelectorAll(sel)[0] || null; }
  querySelectorAll(sel) { const out = []; const walk = n => n.kids.forEach(k => { if (sel === "span" ? k.tag === "span" : k.cl.has(sel.slice(1))) out.push(k); walk(k); }); walk(this); return out; }
}
const h = (tag, at = {}, ...kids) => { const e = new El(tag); (at.class || "").split(" ").filter(Boolean).forEach(c => e.cl.add(c)); if (at.text != null) e.text = at.text; if (at.type) e.attrs.type = at.type; e.append(...kids); return e; };
const log = [];
const ctx = {h, S: {me: {id: 1}}, U: id => ({nickname: "u" + id}), rxGlyph: e => h("span", {class: "rx-e", text: e}), rxMine: m => { for (const [e, ids] of Object.entries(m.rx)) if (ids.includes(1)) return e; return null; },
  haptic() {}, rxBurst: () => {}, reactTo: (m, e) => log.push(e), setTimeout, Object, Number, Set, Map};
vm.createContext(ctx);
vm.runInContext(src.slice(a, b), ctx);
const sleep = ms => new Promise(r => setTimeout(r, ms));
const cnt = c => c.querySelector(".cnt").dataset.n;
const order = box => box.children.filter(c => !c.cl.has("out")).map(c => c.dataset.e).join("");

const m = {id: 5, rx: {"❤️": [2, 3], "👍": [4]}};
const box = h("div", {class: "rxs"});
ctx.rxSync(box, m, false);                                   // birinchi chizish: animatsiyasiz
assert.equal(order(box), "❤️👍"); assert.equal(cnt(box.children[0]), "2");
assert.ok(box.children.every(c => !c.cl.has("in")), "boshlang'ich chizishda animatsiya bo'lmasligi kerak");
const heart = box.children[0];

m.rx = {"❤️": [2, 3, 4], "👍": [4], "🔥": [2]};              // son o'zgardi + yangi chip
ctx.rxSync(box, m, true);
assert.equal(box.children[0], heart, "chip qayta yaratilmasligi kerak");
assert.equal(cnt(heart), "3"); assert.ok(heart.cl.has("bump"), "boshqa odam qo'shsa to'lqin");
assert.equal(order(box), "❤️👍🔥"); assert.ok(box.children[2].cl.has("in"), "yangi chip 'in' animatsiyasi bilan");
assert.ok(heart.querySelectorAll("span").some(s => s.cl.has("up-in")), "son 'yumalab' o'zgarishi");

m.rx = {"👍": [4, 1], "❤️": [2]};                            // o'zim qo'ydim + tartib o'zgardi + 🔥 yo'qoldi
ctx.rxSync(box, m, true);
const thumb = box.children.find(c => c.dataset.e === "👍");
assert.ok(thumb.cl.has("mine")); assert.ok(thumb.firstElementChild.cl.has("pop"), "o'zim qo'ysam emoji 'sakraydi'");
assert.equal(order(box), "👍❤️");
assert.ok(box.children.some(c => c.dataset.e === "🔥" && c.cl.has("out")), "yo'qolgan chip 'out' bilan ketadi");
await sleep(320);
assert.equal(box.children.length, 2, "out chip DOMdan olib tashlanadi");

thumb.ls.click({stopPropagation() {}, });                    // o'z reaksiyamni bossam serverga ketadi (olib tashlash uchun)
assert.deepEqual(log, ["👍"]);
m.rx = {}; ctx.rxSync(box, m, true); await sleep(300); assert.equal(box.children.length, 0);
console.log("reactions_sync_test: OK");
