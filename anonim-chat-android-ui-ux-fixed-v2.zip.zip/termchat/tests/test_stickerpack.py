"""ZIP dan sticker to'plami (.gif / .png): faqat admin, nomlash, o'tkazib yuboriladigan fayllar, kadrlarni kamaytirish."""
import io
import zipfile

import pytest
from PIL import Image

from app.errors import ChatError
from app.repositories import emojis as repo
from app.repositories import users as users_repo
from app.services import emojimaker, stickerpack


def _png():
    b = io.BytesIO(); Image.new("RGBA", (64, 64), (200, 0, 0, 255)).save(b, "PNG"); return b.getvalue()


def _gif(frames=4):
    fs = [Image.new("RGB", (32, 32), ((i * 7) % 255, 0, 0)).convert("P") for i in range(frames)]
    b = io.BytesIO(); fs[0].save(b, "GIF", save_all=True, append_images=fs[1:], duration=80, loop=0); return b.getvalue()


def _zip(files: dict) -> bytes:
    b = io.BytesIO()
    with zipfile.ZipFile(b, "w") as z:
        for k, v in files.items():
            z.writestr(k, v)
    return b.getvalue()


@pytest.fixture(scope="module")
def people():
    admin = users_repo.get(users_repo.create("sp_admin", "A", "x", "admin", 1.0))
    bob = users_repo.get(users_repo.create("sp_bob", "B", "x", "user", 1.0))
    users_repo.set_emoji_perm(bob["id"], 2)                      # yaratish ruxsati bor oddiy foydalanuvchi ham to'plam yarata olmaydi
    return admin, users_repo.get(bob["id"])


@pytest.fixture(autouse=True)
def direct(monkeypatch):
    monkeypatch.setattr(stickerpack, "ISOLATE", False)


def test_admin_imports_mixed_zip(people):
    admin, _ = people
    z = _zip({"a/b/Heart 2.PNG": _png(), "dance.gif": _gif(), "__MACOSX/x.png": b"junk", ".hidden.png": b"j",
              "readme.txt": b"hi", "10.png": _png(), "2.png": _png(), "old.tgs": b"x"})
    r = stickerpack.import_zip(admin, z, "Mem stikerlar")
    assert r["pack"] == "Mem stikerlar" and r["animated"] == 1 and len(r["added"]) == 4
    assert {"heart_2", "dance"} <= set(r["added"])
    assert sorted(s["file"] for s in r["skipped"]) == ["old.tgs", "readme.txt"]
    assert "gif" in [s for s in r["skipped"] if s["file"] == "old.tgs"][0]["reason"]
    rows = [e for e in repo.all_emojis() if e["pack_id"] == r["pack_id"]]
    assert len(rows) == 4 and repo.get_by_name("dance")["file"].endswith(".webp")


def test_only_admin_and_validation(people):
    admin, bob = people
    z = _zip({"x.png": _png()})
    with pytest.raises(ChatError) as e:
        stickerpack.import_zip(bob, z, "Bob pack")
    assert e.value.status == 403
    for bad in (b"not a zip", _zip({"a.txt": b"x"}), _zip({"bad.gif": b"nope"})):
        with pytest.raises(ChatError):
            stickerpack.import_zip(admin, bad, "Yaroqsiz pack")
    assert not [p for p in repo.all_packs() if p["name"] in ("Bob pack", "Yaroqsiz pack")]
    stickerpack.import_zip(admin, z, "Takror pack")
    with pytest.raises(ChatError):
        stickerpack.import_zip(admin, z, "Takror pack")


def test_bad_file_skipped_rest_added(people):
    admin, _ = people
    r = stickerpack.import_zip(admin, _zip({"ok_one.png": _png(), "broken.gif": b"zzz"}), "Qisman pack")
    assert r["added"] == ["ok_one"] and len(r["skipped"]) == 1


def test_long_gif_downsampled_not_rejected():
    m = emojimaker.make(_gif(150))
    im = Image.open(io.BytesIO(m.data))
    assert m.animated and 1 < im.n_frames <= emojimaker.MAX_FRAMES


def test_single_gif_wrapped(people):
    admin, _ = people
    r = stickerpack.import_zip(admin, stickerpack.wrap_single(_gif(), "Mening Gifim.gif"), "Yakka pack")
    assert len(r["added"]) == 1 and r["animated"] == 1
    assert stickerpack.wrap_single(b"PK\x03\x04rest", "x.zip") == b"PK\x03\x04rest"


def test_isolated_child_process(people, monkeypatch):
    admin, _ = people
    monkeypatch.setattr(stickerpack, "ISOLATE", True)
    try:
        r = stickerpack.import_zip(admin, _zip({"iso_a.png": _png(), "iso_b.gif": _gif()}), "Izolyatsiya pack")
        assert sorted(r["added"]) == ["iso_a", "iso_b"]
    finally:
        stickerpack._drop_pool()


def test_child_crash_does_not_kill_server(people, monkeypatch):
    from concurrent.futures.process import BrokenProcessPool
    admin, _ = people
    monkeypatch.setattr(stickerpack, "ISOLATE", True)
    calls = {"n": 0}

    class Pool:
        def submit(self, fn, raw, ext):
            calls["n"] += 1
            class F:
                def result(_, timeout=None):
                    if calls["n"] == 1:
                        raise BrokenProcessPool("crash")
                    return fn(raw, ext)
            return F()

    monkeypatch.setattr(stickerpack, "_get_pool", lambda: Pool())
    monkeypatch.setattr(stickerpack, "_drop_pool", lambda: None)
    r = stickerpack.import_zip(admin, _zip({"a_crash.gif": _gif(), "b_ok.png": _png()}), "Qulash pack")
    assert r["added"] == ["b_ok"] and "to'xtadi" in r["skipped"][0]["reason"]
