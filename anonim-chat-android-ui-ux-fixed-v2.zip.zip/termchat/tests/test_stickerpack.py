"""ZIP dan sticker to'plami (.tgs / .png / .gif): faqat admin, nomlash, o'tkazib yuboriladigan fayllar, zip-bomba himoyasi."""
import gzip
import io
import json
import zipfile

import pytest
from PIL import Image, ImageDraw

from app.errors import ChatError
from app.repositories import emojis as repo
from app.repositories import users as users_repo
from app.services import emojimaker, stickerpack


class FakeLottie:
    """rlottie-python o'rniga: 40 kadrli, 60 fps animatsiya (testda haqiqiy kutubxona shart emas)."""
    @classmethod
    def from_data(cls, text):
        assert json.loads(text)["layers"] is not None
        return cls()

    def lottie_animation_get_totalframe(self): return 40
    def lottie_animation_get_framerate(self): return 60

    def render_pillow_frame(self, i, w, h):
        im = Image.new("RGBA", (w, h), (0, 0, 0, 0)); ImageDraw.Draw(im).ellipse((i, i, w - 20, h - 20), fill=(0, 160, 255, 255)); return im


def _tgs(layers=True):
    return gzip.compress(json.dumps({"v": "5.5.2", "fr": 60, "w": 512, "h": 512, "layers": [] if layers else None}).encode())


def _png():
    b = io.BytesIO(); Image.new("RGBA", (64, 64), (200, 0, 0, 255)).save(b, "PNG"); return b.getvalue()


def _gif():
    fs = [Image.new("RGB", (32, 32), (i * 40, 0, 0)).convert("P") for i in range(4)]
    b = io.BytesIO(); fs[0].save(b, "GIF", save_all=True, append_images=fs[1:], duration=80, loop=0); return b.getvalue()


def _zip(files: dict) -> bytes:
    b = io.BytesIO()
    with zipfile.ZipFile(b, "w") as z:
        for k, v in files.items():
            z.writestr(k, v)
    return b.getvalue()


@pytest.fixture(scope="module")
def people():
    admin = users_repo.get(users_repo.create("sp_admin", "A", "x", "admin", 1.0))
    bob = users_repo.get(users_repo.create("sp_bob", "B", "x", "user", 1.0))
    users_repo.set_emoji_perm(bob["id"], 2)                      # yaratish ruxsati bor oddiy foydalanuvchi ham to'plam yarata olmaydi
    return admin, users_repo.get(bob["id"])


@pytest.fixture(autouse=True)
def fake_rlottie(monkeypatch):
    monkeypatch.setattr(emojimaker, "LottieAnimation", FakeLottie)


def test_admin_imports_mixed_zip(people):
    admin, _ = people
    z = _zip({"smile.tgs": _tgs(), "a/b/Heart 2.PNG": _png(), "dance.gif": _gif(), "__MACOSX/x.png": b"junk", ".hidden.png": b"j",
              "readme.txt": b"hi", "10.png": _png(), "2.png": _png()})
    r = stickerpack.import_zip(admin, z, "Mem stikerlar")
    assert r["pack"] == "Mem stikerlar" and r["animated"] == 2
    assert set(r["added"]) >= {"smile", "heart_2", "dance"} and len(r["added"]) == 5
    assert [s["file"] for s in r["skipped"]] == ["readme.txt"]       # papka/yashirin/macOS jim o'tkaziladi, begona format sababi bilan
    pid = r["pack_id"]
    rows = [e for e in repo.all_emojis() if e["pack_id"] == pid]
    assert len(rows) == 5 and all(e["public"] == 1 for e in rows)
    tgs_row = repo.get_by_name("smile")
    assert tgs_row["animated"] == 1 and tgs_row["file"].endswith(".webp")
    assert all(n for n in r["added"] if 2 <= len(n) <= 14)           # raqamli nomlar ("2", "10") -> to'plam_N


def test_only_admin_and_validation(people):
    admin, bob = people
    z = _zip({"x.png": _png()})
    with pytest.raises(ChatError) as e:
        stickerpack.import_zip(bob, z, "Bob pack")
    assert e.value.status == 403
    with pytest.raises(ChatError):
        stickerpack.import_zip(admin, b"not a zip", "Yaroqsiz zip")
    with pytest.raises(ChatError):
        stickerpack.import_zip(admin, _zip({"a.txt": b"x"}), "Bosh pack")
    with pytest.raises(ChatError):
        stickerpack.import_zip(admin, _zip({"bad.tgs": b"nope", "bad2.png": b"nope"}), "Buzuq pack")
    assert not [p for p in repo.all_packs() if p["name"] in ("Bob pack", "Yaroqsiz zip", "Bosh pack", "Buzuq pack")]   # xato bo'lsa to'plam qolmaydi
    stickerpack.import_zip(admin, z, "Takror pack")
    with pytest.raises(ChatError):
        stickerpack.import_zip(admin, z, "Takror pack")              # nom band


def test_bad_file_skipped_rest_added(people):
    admin, _ = people
    r = stickerpack.import_zip(admin, _zip({"ok_one.png": _png(), "broken.tgs": b"zzz", "broken2.png": b"zzz"}), "Qisman pack")
    assert r["added"] == ["ok_one"] and len(r["skipped"]) == 2


def test_tgs_downsamples_frames(people):
    m = emojimaker.make_tgs(_tgs())
    assert m.animated and m.ext == "webp"
    im = Image.open(io.BytesIO(m.data)); assert 1 < im.n_frames <= emojimaker.MAX_FRAMES


def test_tgs_bomb_and_missing_lib(monkeypatch):
    big = gzip.compress(b"0" * (emojimaker.MAX_TGS_JSON + 10))
    with pytest.raises(ChatError):
        emojimaker.make_tgs(big)
    monkeypatch.setattr(emojimaker, "LottieAnimation", None)
    with pytest.raises(ChatError):
        emojimaker.make_tgs(_tgs())
