"""HTTP + WebSocket integratsion testlari (fastapi, httpx kerak)."""
import json

import pytest

pytest.importorskip("fastapi")
pytest.importorskip("httpx")
from fastapi.testclient import TestClient  # noqa: E402

from app.main import app  # noqa: E402
from secure_client import SecureClient, SecWS  # noqa: E402


def _real_png(size=(8, 8)):
    import io
    from PIL import Image
    b = io.BytesIO(); Image.new("RGB", size, (30, 120, 200)).save(b, "PNG"); return b.getvalue()

@pytest.fixture(scope="module")
def client():
    with TestClient(app) as c:
        yield c


def recv_where(ws, pred, limit=30):
    for _ in range(limit):
        m = ws.receive_json()
        if pred(m):
            return m
    raise AssertionError("kutilgan hodisa kelmadi")


def test_pages_and_health(client):
    assert client.get("/").status_code == 200
    assert client.get("/healthz").json()["status"] == "ok"
    assert client.head("/healthz").status_code == 200 and client.head("/").status_code == 200   # UptimeRobot HEAD yuboradi
    h = client.head("/healthz"); assert h.status_code == 200 and h.content == b"" and h.headers["cache-control"] == "no-store"
    assert client.get("/static/js/app.js").status_code == 200
    csp = client.get("/").headers["content-security-policy"]
    assert "default-src 'none'" in csp and "script-src 'self'" in csp and "object-src 'none'" in csp
    index = client.get("/").text
    assert 'integrity="sha384-' in index and "Anonim Chat by Hevorix" in index and "data-sri" not in index
    # ovozli xabar: skript SRI bilan beriladi, mikrofon FAQAT shu sayt uchun ochiq (boshqa ruxsatlar yopiq), media faqat self/blob
    assert client.get("/static/js/voice.js").status_code == 200 and "/static/js/voice.js?v=" in index
    pp = client.get("/").headers["permissions-policy"]
    assert "microphone=(self)" in pp and "camera=(self)" in pp and "geolocation=()" in pp
    assert "media-src 'self' blob:" in csp


def test_register_login_flow(client):
    r = client.post("/api/register", json={"username": "api_alice", "nickname": "A", "password": "secret12"})
    assert r.status_code == 200
    assert client.post("/api/register", json={"username": "API_ALICE", "nickname": "B", "password": "secret12"}).status_code == 409
    assert client.post("/api/login", json={"username": "api_alice", "password": "bad-pass"}).status_code == 401
    token = r.json()["token"]
    assert client.get("/api/me", headers={"Authorization": f"Bearer {token}"}).json()["me"]["username"] == "api_alice"
    assert client.get("/api/me").status_code == 401


def test_websocket_chat_and_ban(client):
    a = client.post("/api/login", json={"username": "hevorix", "password": "owner-pass-1"}).json()["token"]
    b = client.post("/api/register", json={"username": "api_bob", "nickname": "B", "password": "secret12"}).json()["token"]
    with SecWS(client, a) as wa, SecWS(client, b) as wb:
        assert wa.receive_json()["type"] == "init"
        assert wb.receive_json()["type"] == "init"
        wb.send_json({"text": "salom"})
        assert recv_where(wa, lambda m: m["type"] == "message")["content"] == "salom"
        wa.send_json({"type": "cmd", "text": "/ban api_bob test"})
        assert recv_where(wb, lambda m: m["type"] == "banned")["reason"] == "test"
    assert client.post("/api/login", json={"username": "api_bob", "password": "secret12"}).status_code == 403


def test_avatar_upload_validation(client):
    t = client.post("/api/login", json={"username": "api_alice", "password": "secret12"}).json()["token"]
    h = {"Authorization": f"Bearer {t}"}
    png = _real_png()
    assert client.post("/api/avatar", headers=h, files={"file": ("a.png", png, "image/png")}).status_code == 200
    assert client.post("/api/avatar", headers=h, files={"file": ("a.png", b"not an image", "image/png")}).status_code == 400
    for _ in range(2):
        client.post("/api/avatar", headers=h, files={"file": ("a.png", png, "image/png")})
    assert client.post("/api/avatar", headers=h, files={"file": ("a.png", png, "image/png")}).status_code == 400   # 3 tadan oshdi


def test_direct_message_over_websocket(client):
    a = client.post("/api/login", json={"username": "api_alice", "password": "secret12"}).json()["token"]
    c = client.post("/api/register", json={"username": "api_carol", "nickname": "C", "password": "secret12"}).json()
    d = client.post("/api/register", json={"username": "api_dave", "nickname": "D", "password": "secret12"}).json()
    ha = {"Authorization": f"Bearer {a}"}
    hc = {"Authorization": f"Bearer {c['token']}"}
    with SecWS(client, a) as wa, \
         SecWS(client, c['token']) as wc, \
         SecWS(client, d['token']) as wd:
        for w in (wa, wc, wd):
            assert w.receive_json()["type"] == "init"
        wc.send_json({"type": "send", "text": "lichka", "to": client.get("/api/me", headers=ha).json()["me"]["id"]})
        got = recv_where(wa, lambda m: m["type"] == "message")
        assert got["content"] == "lichka" and got["user"]["username"] == "api_carol"
        assert recv_where(wc, lambda m: m["type"] == "message")["id"] == got["id"]     # yuboruvchiga ham keladi
        # uchinchi odam hech narsa olmaydi: umumiy xabar yuboramiz va faqat u kelishini tekshiramiz
        wa.send_json({"type": "send", "text": "hammaga"})
        assert recv_where(wd, lambda m: m["type"] == "message")["content"] == "hammaga"
        # o'qilgan deb belgilash
        wa.send_json({"type": "read", "with": got["user"]["id"]})
        assert recv_where(wc, lambda m: m["type"] == "read")["by"] == got["to"]
    hist = client.get(f"/api/dm/{got['user']['id']}", headers=ha).json()["history"]
    assert [h["content"] for h in hist] == ["lichka"] and hist[0]["read"] is True
    assert client.get(f"/api/dm/{got['to']}", headers={"Authorization": f"Bearer {d['token']}"}).json()["history"] == []
    assert client.get("/api/dialogs", headers=ha).json()["dialogs"][0]["user"]["username"] == "api_carol"
    members = client.get("/api/members", headers=hc).json()["members"]
    assert {"api_alice", "api_carol", "api_dave"} <= {m["username"] for m in members}


def test_profile_update_api(client):
    t = client.post("/api/login", json={"username": "api_alice", "password": "secret12"}).json()["token"]
    h = {"Authorization": f"Bearer {t}"}
    r = client.patch("/api/profile", headers=h, json={"nickname": "Alisa", "bio": "salom"})
    assert r.status_code == 200 and r.json()["me"]["nickname"] == "Alisa" and r.json()["me"]["bio"] == "salom"
    assert client.patch("/api/profile", headers=h, json={}).status_code == 400
    assert client.get("/api/avatars", headers=h).json()["max"] == 3


def _owner(client):
    t = client.post("/api/login", json={"username": "HEVORIX", "password": "owner-pass-1"}).json()["token"]
    return {"Authorization": f"Bearer {t}"}


def test_username_check_is_case_insensitive(client):
    for name in ("hevorix", "HEVORIX", "Hevorix"):
        assert client.get(f"/api/username/{name}").json() == {"available": False, "reason": "Bu username band"}
    assert client.get("/api/username/ozod_nom").json()["available"] is True
    assert client.post("/api/register", json={"username": "HeVoRiX", "nickname": "x", "password": "secret12"}).status_code == 409


def test_image_reply_color_over_http(client):
    h = _owner(client)
    png = _real_png()
    r = client.post("/api/messages/image", headers=h, files={"file": ("a.png", png, "image/png")}, data={"caption": "izoh"})
    assert r.status_code == 200
    mid = r.json()["id"]
    assert client.post("/api/messages/image", headers=h, files={"file": ("a.png", b"", "image/png")}).status_code == 400   # bo'sh fayl
    assert client.get("/uploads/nope.png", headers=h).status_code == 404
    assert client.get("/uploads/" + "a" * 32 + ".png").status_code == 401                                           # tizimga kirmagan — yo'q
    doc = client.post("/api/messages/media", headers=h, files={"file": ("hisobot.pdf", b"%PDF-1.4 x", "application/pdf")})
    assert doc.status_code == 200
    with SecWS(client, h["Authorization"].split()[1]) as w:
        init = w.receive_json()
        img = [m for m in init["history"] if m["id"] == mid][0]
        assert img["image"].startswith("/uploads/") and img["content"] == "izoh"
        w.send_json({"type": "send", "text": "javob", "reply_to": mid})
        got = recv_where(w, lambda m: m["type"] == "message")
        assert got["reply"]["id"] == mid
    assert client.get(img["image"], headers=h).status_code == 200
    me = client.patch("/api/profile", headers=h, json={"color": "#22cc88"}).json()["me"]
    assert me["color"] == "#22cc88"
    bob = client.post("/api/login", json={"username": "api_alice", "password": "secret12"}).json()["token"]
    assert client.patch("/api/profile", headers={"Authorization": f"Bearer {bob}"}, json={"color": "#112233"}).status_code == 403


def test_admin_logs_and_ip_blocking(client):
    h = _owner(client)
    user_h = {"Authorization": "Bearer " + client.post("/api/login", json={"username": "api_alice", "password": "secret12"}).json()["token"]}
    assert client.get("/api/admin/ips", headers=user_h).status_code == 403          # oddiy foydalanuvchi kira olmaydi
    ips = client.get("/api/admin/ips", headers=h).json()["ips"]
    assert ips and any(p["username"].lower() == "hevorix" and p["logins"] >= 1 for e in ips for p in e["profiles"])
    log = client.get("/api/admin/activity?action=login", headers=h).json()
    assert log["items"] and all(i["action"] == "login" for i in log["items"])
    # begona IP'ni bloklash: keyin shu IP'dan so'rovlar rad etiladi
    assert client.post("/api/admin/blocks", headers=h, json={"ip": "203.0.113.50", "reason": "spam"}).status_code == 200
    spam = {"CF-Connecting-IP": "203.0.113.50"}
    assert client.get("/", headers=spam).status_code == 403
    assert client.post("/api/login", headers=spam, json={"username": "x", "password": "y"}).status_code == 403
    assert client.get("/healthz", headers=spam).status_code == 200
    assert [b["ip"] for b in client.get("/api/admin/blocks", headers=h).json()["blocks"]] == ["203.0.113.50"]
    assert client.post("/api/admin/unblock", headers=h, json={"ip": "203.0.113.50"}).status_code == 200
    assert client.get("/", headers=spam).status_code == 200


def test_tunnel_over_real_app_and_plain_access_refused(client):
    from app.config import settings
    sc = SecureClient.handshake(client)
    st, body = sc.call(client, "POST", "/api/login", json_body={"username": "hevorix", "password": "owner-pass-1"})
    assert st == 200
    token = json.loads(body)["token"]
    st, body = sc.call(client, "GET", "/api/me", token=token)
    assert st == 200 and json.loads(body)["me"]["username"].lower() == "hevorix"
    assert sc.call(client, "GET", "/api/me")[0] == 401                                   # token yo'q
    object.__setattr__(settings, "require_tunnel", True)
    try:
        assert client.get("/api/me", headers={"Authorization": f"Bearer {token}"}).status_code == 403
        assert client.get("/uploads/x.png").status_code == 403
        assert client.get("/healthz").status_code == 200
    finally:
        object.__setattr__(settings, "require_tunnel", False)


def test_admin_sees_only_ciphertext_in_message_log(client):
    from app.repositories import users
    from app.services import chat
    h = _owner(client)
    owner = users.get_by_username("hevorix")
    m = chat.post(owner, "log sinov birinchi")
    chat.edit(owner, m["id"], "log sinov ikkinchi")
    chat.delete(owner, m["id"])
    items = client.get("/api/admin/messages?state=deleted", headers=h).json()["items"]
    row = next(i for i in items if i["id"] == m["id"])
    assert "text" not in row and row["deleted"] and row["edited"] and row["legacy"]
    assert row["cipher"].startswith("enc1:") and "log sinov" not in row["cipher"]          # adminga ochiq matn berilmaydi
    assert [x["type"] for x in row["history"]] == ["edit", "delete"]
    assert all("log sinov" not in x["old"] + x["new"] for x in row["history"])
    user_h = {"Authorization": "Bearer " + client.post("/api/login", json={"username": "api_alice", "password": "secret12"}).json()["token"]}
    assert client.get("/api/admin/messages", headers=user_h).status_code == 403


def test_custom_emoji_api_flow(client):
    """Admin rasm yuklab emoji yaratadi; oddiy foydalanuvchi ruxsatsiz yarata olmaydi, ruxsat berilgach yaratadi."""
    a = client.post("/api/login", json={"username": "hevorix", "password": "owner-pass-1"}).json()["token"]
    b = client.post("/api/register", json={"username": "emo_api_bob", "nickname": "B", "password": "secret12"}).json()["token"]
    ha, hb = {"Authorization": f"Bearer {a}"}, {"Authorization": f"Bearer {b}"}
    png = _real_png((32, 32))
    r = client.post("/api/emoji", headers=ha, files={"file": ("x.png", png, "image/png")}, data={"name": "api_emoji", "anim": "pulse"})
    assert r.status_code == 200, r.text
    cat = client.get("/api/emojis", headers=hb).json()
    e = next(x for x in cat["emojis"] if x["token"] == ":api_emoji:")
    assert e["anim"] == "pulse" and cat["perms"] == {"use": False, "create": False, "manage": False}
    img = client.get(e["url"])
    assert img.status_code == 200 and img.headers["content-type"] == "image/png" and "immutable" in img.headers["cache-control"]
    assert client.post("/api/emoji", headers=hb, files={"file": ("x.png", png, "image/png")}, data={"name": "bob_emoji"}).status_code == 403
    assert client.put("/api/emoji-settings", headers=hb, json={"mode": "use"}).status_code == 403
    bob_id = client.get("/api/me", headers=hb).json()["me"]["id"]
    assert client.put(f"/api/emoji-perm/{bob_id}", headers=ha, json={"perm": 2}).status_code == 200
    assert client.post("/api/emoji", headers=hb, files={"file": ("x.png", png, "image/png")}, data={"name": "bob_emoji"}).status_code == 200
    pv = client.post("/api/emoji/preview", headers=hb, files={"file": ("x.png", png, "image/png")}, data={"remove_bg": "false"}).json()
    assert pv["image"].startswith("data:image/png;base64,")
    assert client.delete(f"/api/emoji/{e['id']}", headers=hb).status_code == 403     # begonanikini o'chira olmaydi
    assert client.delete(f"/api/emoji/{e['id']}", headers=ha).status_code == 200


def test_pwa_install_assets(client):
    r = client.get("/sw.js")
    assert r.status_code == 200 and "javascript" in r.headers["content-type"]
    assert r.headers.get("service-worker-allowed") == "/"
    assert "worker-src 'self'" in r.headers["content-security-policy"]
    html = client.get("/").text
    assert 'data-install' in html and '/static/js/install.js' in html and '/static/js/push.js' in html
    assert 'id="instGo"' in html and 'id="instProg"' in html           # 10 soniyalik yuklash oynasi
    assert client.get("/static/manifest.json").json()["display"] == "standalone"
    sw = client.get("/sw.js").text
    assert "addEventListener(\"push\"" in sw and "notificationclick" in sw       # yopiq brauzerda ham bildirishnoma


def test_push_subscribe_flow(client):
    """Push: ochiq kalit, obuna, begona (ruxsatsiz) endpoint rad etilishi, bekor qilish."""
    import base64
    import os
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric import ec
    b64 = lambda b: base64.urlsafe_b64encode(b).rstrip(b"=").decode()
    tok = client.post("/api/register", json={"username": "pushu1", "nickname": "Push1", "password": "secret12"}).json()["token"]
    h = {"Authorization": f"Bearer {tok}"}
    assert client.get("/api/push/key").status_code == 401
    key = client.get("/api/push/key", headers=h).json()["key"]
    assert len(base64.urlsafe_b64decode(key + "==")) == 65
    pub = ec.generate_private_key(ec.SECP256R1()).public_key().public_bytes(serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint)
    body = {"endpoint": "https://fcm.googleapis.com/fcm/send/test-1", "p256dh": b64(pub), "auth": b64(os.urandom(16))}
    assert client.post("/api/push/subscribe", headers=h, json=body).status_code == 200
    assert client.post("/api/push/check", headers=h, json={"endpoint": body["endpoint"]}).json()["subscribed"] is True
    bad = dict(body, endpoint="https://127.0.0.1/evil")                         # SSRF: ichki manzilga so'rov yubormaymiz
    assert client.post("/api/push/subscribe", headers=h, json=bad).status_code == 400
    bad = dict(body, auth=b64(b"short"))
    assert client.post("/api/push/subscribe", headers=h, json=bad).status_code == 400
    assert client.post("/api/push/unsubscribe", headers=h, json={"endpoint": body["endpoint"]}).status_code == 200
    assert client.post("/api/push/check", headers=h, json={"endpoint": body["endpoint"]}).json()["subscribed"] is False


def test_push_targets_offline_only(client, monkeypatch):
    """Umumiy chat: yozuvchidan tashqari hamma OFLAYN obunachiga; lichka: faqat qabul qiluvchiga. Onlayn bo'lsa push yuborilmaydi."""
    import asyncio
    import base64
    import os
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric import ec
    from app.realtime.manager import manager
    from app.services import webpush
    b64 = lambda b: base64.urlsafe_b64encode(b).rstrip(b"=").decode()
    ids, heads = {}, {}
    for n in ("pa", "pb", "pc"):
        j = client.post("/api/register", json={"username": f"push_{n}", "nickname": n.upper(), "password": "secret12"}).json()
        ids[n], heads[n] = j["me"]["id"], {"Authorization": f"Bearer {j['token']}"}
        pub = ec.generate_private_key(ec.SECP256R1()).public_key().public_bytes(serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint)
        r = client.post("/api/push/subscribe", headers=heads[n], json={"endpoint": f"https://fcm.googleapis.com/fcm/send/{n}", "p256dh": b64(pub), "auth": b64(os.urandom(16))})
        assert r.status_code == 200
    sent = []

    async def fake_send(sub, payload, topic, urgency):
        sent.append((sub["user_id"], payload, topic))
    monkeypatch.setattr(webpush, "_send_one", fake_send)
    monkeypatch.setattr(manager, "is_online", lambda uid: uid == ids["pc"])     # pc hozir onlayn

    msg = {"id": 1, "to": None, "user": {"nickname": "PA", "username": "push_pa"}}
    asyncio.run(webpush.notify_message(msg, ids["pa"]))
    assert {u for u, _, _ in sent} >= {ids["pb"]} and ids["pa"] not in {u for u, _, _ in sent} and ids["pc"] not in {u for u, _, _ in sent}
    assert all(b'"k":"g"' in p for _, p, _ in sent)
    sent.clear()
    asyncio.run(webpush.notify_message({"id": 2, "to": ids["pb"], "user": {"nickname": "PA", "username": "push_pa"}}, ids["pa"]))
    assert [u for u, _, _ in sent] == [ids["pb"]] and b'"k":"d"' in sent[0][1] and b"secret" not in sent[0][1]
    sent.clear()
    asyncio.run(webpush.notify_message({"id": 3, "to": ids["pc"], "user": {"nickname": "PA", "username": "push_pa"}}, ids["pa"]))
    assert sent == []                                                          # pc onlayn: xabarni WebSocket orqali oladi


def test_channels_http_and_realtime(client):
    """Kanallar: admin yaratadi; shaxsiy kanal oddiy foydalanuvchiga ko'rinmaydi; parol bilan qo'shilish; post, ko'rishlar, kommentlar."""
    adm = {"Authorization": "Bearer " + client.post("/api/login", json={"username": "hevorix", "password": "owner-pass-1"}).json()["token"]}
    u1 = client.post("/api/register", json={"username": "chu_one", "nickname": "One", "password": "secret12"}).json()
    u2 = client.post("/api/register", json={"username": "chu_two", "nickname": "Two", "password": "secret12"}).json()
    h1, h2 = ({"Authorization": "Bearer " + u["token"]} for u in (u1, u2))
    assert client.post("/api/channels", headers=h1, json={"username": "nope_ch", "nickname": "X"}).status_code == 403
    pub = client.post("/api/channels", headers=adm, json={"username": "news_ch", "nickname": "Yangiliklar"}).json()["channel"]
    prv = client.post("/api/channels", headers=adm, json={"username": "secret_ch", "nickname": "Yopiq", "private": True, "password": "sir1234"}).json()["channel"]
    assert [c["id"] for c in client.get("/api/channels", headers=h1).json()["channels"]] == [pub["id"]]       # shaxsiy ko'rinmaydi
    assert {pub["id"], prv["id"]} <= {c["id"] for c in client.get("/api/channels", headers=adm).json()["channels"]}
    assert client.get(f"/api/channels/{prv['id']}/posts", headers=h1).status_code == 404
    assert client.post("/api/channels/join", headers=h1, json={"username": "secret_ch", "password": "xato"}).status_code == 404
    assert client.post("/api/channels/join", headers=h1, json={"username": "@Secret_CH", "password": "sir1234"}).status_code == 200
    assert client.get(f"/api/channels/{prv['id']}/posts", headers=h1).status_code == 200
    assert client.get(f"/api/channels/{prv['id']}/posts", headers=h2).status_code == 404
    # post, ko'rish, komment
    assert client.post(f"/api/channels/{pub['id']}/posts", headers=h1, json={"text": "men yoza olmayman"}).status_code == 403
    pid = client.post(f"/api/channels/{pub['id']}/posts", headers=adm, json={"text": "Salom!"}).json()["post"]["id"]
    assert client.post(f"/api/channels/{pub['id']}/views", headers=h1, json={"ids": [pid]}).status_code == 200
    p = client.get(f"/api/channels/{pub['id']}/posts", headers=h2).json()["posts"][-1]
    assert p["text"] == "Salom!" and p["views"] == 1 and p["comments"] == 0
    r = client.post(f"/api/channels/{pub['id']}/posts/{pid}/comments", headers=h2, json={"text": "Zo'r"}).json()
    assert r["count"] == 1 and r["comment"]["user"]["username"] == "chu_two"
    # kommentlar faqat post ostida: umumiy chat tarixiga tushmaydi
    assert all("Zo'r" not in str(m) for m in client.get("/api/history", headers=h1).json().get("messages", [])) if client.get("/api/history", headers=h1).status_code == 200 else True
    assert client.get(f"/api/channels/{pub['id']}/posts/{pid}/comments", headers=h1).json()["comments"][0]["text"] == "Zo'r"
    assert client.delete(f"/api/channels/{pub['id']}/posts/{pid}", headers=h1).status_code == 403
    assert client.delete(f"/api/channels/{pub['id']}", headers=adm).status_code == 200
