// Node: Telegram uslubidagi profil ko'rinishi (profileView) — app.js dan kerakli qismlar ajratib olinib, minimal soxta DOM bilan ishga tushiriladi.
import fs from "node:fs";
import assert from "node:assert/strict";

class N { constructor(t) { this.tag = t; this._c = []; this.attrs = {}; this.cls = ""; this.ls = {}; this._t = ""; this.style = {setProperty() {}}; }
  set className(v) { this.cls = v; } get className() { return this.cls; }
  set textContent(v) { this._t = String(v); this._c = []; } get textContent() { return this._t + this._c.map(c => c.textContent).join(""); }
  append(...k) { for (const c of k) this._c.push(c); } setAttribute(k, v) { this.attrs[k] = v; }
  addEventListener(e, f) { (this.ls[e] = this.ls[e] || []).push(f); } get nodeType() { return 1; } }
globalThis.document = {createElement: t => new N(t), createElementNS: (n, t) => new N(t), createTextNode: t => ({nodeType: 3, textContent: String(t)})};
const store = {}; globalThis.localStorage = {getItem: k => store[k] ?? null, setItem: (k, v) => { store[k] = v; }};

const src = fs.readFileSync(new URL("../app/static/js/app.js", import.meta.url), "utf8");
const cut = (from, to) => { const a = src.indexOf(from), b = src.indexOf(to, a); assert.ok(a >= 0 && b > a, "topilmadi: " + from); return src.slice(a, b); };
const code = [
  cut("function h(tag, props", "const icon ="), "const icon = (name, cls) => svgUse(\"#i-\" + name, cls || \"ic\");",
  cut("const LS_MUTED", "  return mutedDm.has(uid);\n}") + "  return mutedDm.has(uid);\n}",
  cut("function mediaStats", "function modPanel"),
].join("\n").replace(/^function pingSound[\s\S]*$/m, "");
const all = (n, out = []) => { out.push(n); (n._c || []).forEach(c => c.nodeType === 1 && all(c, out)); return out; };
const text = n => n.textContent;

function load(S, extra = {}) {
  const calls = [];
  const env = {S, MONTHS: ["yan", "fev", "mar", "apr", "may", "iyun", "iyul", "avg", "sen", "okt", "noy", "dek"], NS: "ns",
    U: id => S.users.get(id), avatar: () => new N("av"), nameEl: u => { const e = new N("span"); e.textContent = u.nickname; return e; }, tint: e => e,
    isStaff: u => u.role === "admin" || u.role === "owner", hasEmoji: () => false, badge: () => null, isVerified: () => false, roleLabel: r => r,
    statusText: () => "onlayn", isOnline: () => true, amAdmin: () => false, modPanel: () => new N("mod"), openSettings: () => calls.push("settings"),
    openChat: t => calls.push(["chat", t]), closeModal: () => calls.push("close"), toast: m => calls.push(["toast", m]), copyText: t => calls.push(["copy", t]),
    showModal: () => calls.push("rerender"), svgUse: (href, cls) => { const e = new N("svg"); e.attrs.href = href; e.cls = cls; return e; }, ...extra};
  const fn = new Function(...Object.keys(env), code + "\nreturn {profileView, toggleMute, isMuted, mediaStats};");
  return {...fn(...Object.values(env)), calls, S};
}

const msg = (o) => ({id: Math.random(), user: {id: 7}, ...o});
const S = {me: {id: 1, role: "user"}, modal: {build: () => null}, users: new Map([
  [1, {id: 1, username: "me", nickname: "Men", role: "user"}],
  [7, {id: 7, username: "olim_0406", nickname: "Olimjon", role: "user", bio: "Salom", joined: 1700000000}]]),
  dms: new Map([[7, {loaded: true, more: false, msgs: [msg({image: "x"}), msg({image: "y"}), msg({image: "z"}),
    msg({file: {voice: true}}), msg({file: {voice: true}}), msg({file: {name: "a.pdf"}}), msg({content: "matn"}), msg({image: "d", deleted: true})]}]])};

const L = load(S);
const view = L.profileView(7, null);
const t = text(view);
for (const bad of ["Call", "Qo'ng'iroq", "More", "Ko'proq", "Block", "Bloklash", "Add to contacts", "QR"]) assert.ok(!t.includes(bad), "bo'lmasligi kerak: " + bad);
const buttons = all(view).filter(n => n.tag === "button");
const labels = buttons.map(text);
assert.ok(labels.includes("Xabar") && labels.includes("Mute"), "Xabar va Mute bo'lishi kerak: " + labels);
assert.equal(buttons.filter(b => b.cls.includes("tg-act")).length, 2, "faqat 2 ta amal tugmasi");
assert.ok(t.includes("@olim_0406") && t.includes("Username"), "username ko'rinishi kerak");
assert.ok(t.includes("3 ta rasm") && t.includes("2 ta ovozli xabar") && t.includes("1 ta fayl"), "media sanog'i: " + t);
assert.ok(!t.includes("video xabar"), "nol bo'lgan kategoriya ko'rsatilmaydi");

// username bosilsa nusxalanadi
const row = all(view).find(n => n.cls.includes("copy") && text(n).includes("@olim_0406"));
row.ls.click[0](); assert.deepEqual(L.calls.at(-1), ["copy", "@olim_0406"]);

// Xabar tugmasi: oyna yopilib, suhbat ochiladi
buttons.find(b => text(b) === "Xabar").ls.click[0]();
assert.deepEqual(L.calls.slice(-2), ["close", ["chat", {kind: "dm", uid: 7}]]);

// Mute: yoqiladi, saqlanadi, tugma matni o'zgaradi
buttons.find(b => text(b) === "Mute").ls.click[0]();
assert.ok(L.isMuted(7)); assert.equal(store["ac_muted_dm"], "[7]");
const v2 = L.profileView(7, null);
assert.ok(all(v2).filter(n => n.tag === "button").map(text).includes("Ovoz yoq"));
all(v2).filter(n => n.tag === "button").find(b => text(b) === "Ovoz yoq").ls.click[0]();
assert.ok(!L.isMuted(7)); assert.equal(store["ac_muted_dm"], "[]");

// Tarixning davomi bor bo'lsa "+" qo'yiladi; yuklanmagan DM'da media qatorlari yo'q
S.dms.get(7).more = true; assert.ok(text(L.profileView(7, null)).includes("3+ ta rasm"));
S.dms.get(7).loaded = false; assert.ok(!text(L.profileView(7, null)).includes("ta rasm"));

// O'z profilim: Mute/Xabar yo'q, faqat Tahrirlash; media qatorlari yo'q
const mine = L.profileView(1, null);
const mb = all(mine).filter(n => n.tag === "button" && n.cls.includes("tg-act")).map(text);
assert.deepEqual(mb, ["Tahrirlash"]);

// Orqaga tugmasi (onBack berilganda) va yopish
let back = 0; const vb = L.profileView(7, () => back++);
all(vb).find(n => n.cls === "tg-back").ls.click[0](); assert.equal(back, 1);
console.log("profile_view_test: OK");
