// Node: richtext.js sinovi (kod/buyruq aniqlash, tokenizer, pcap tahlilchisi). Ishga tushirish: node tests/richtext_test.mjs
import {createRequire} from "node:module";
import assert from "node:assert/strict";
const require = createRequire(import.meta.url);
const R = require("../app/static/js/richtext.js");
let n = 0;
const t = (name, fn) => { try { fn(); n++; } catch (e) { console.error("FAIL:", name, "\n", e.message); process.exitCode = 1; } };
const kind = s => R.parse(s).map(p => p.k + (p.lang ? ":" + p.lang : "")).join(",");

t("fayl turlari", () => {
  assert.equal(R.fileKind("exploit.py").lang, "python");
  assert.equal(R.fileKind("main.CPP").lang, "cpp");
  assert.equal(R.fileKind("app.js").lang, "javascript");
  assert.equal(R.fileKind("boot.asm").lang, "asm");
  assert.equal(R.fileKind("run.sh").lang, "bash");
  assert.equal(R.fileKind("dump.pcap").kind, "pcap");
  assert.equal(R.fileKind("dump.pcapng").kind, "pcap");
  assert.equal(R.fileKind("rasm.png"), null);
  assert.equal(R.fileKind("hujjat.pdf"), null);
});
t("```bloklar", () => {
  assert.equal(kind("```python\nprint(1)\n```"), "code:python");
  assert.equal(kind("```bash\nnmap -sV 10.0.0.1\n```"), "term");
  assert.equal(kind("Mana:\n```c\nint main(){return 0;}\n```\nshu"), "text,code:c,text");
  assert.equal(kind("```js\nlet a=1"), "code:javascript");              // yopilmagan blok
  assert.equal(kind("```\nSELECT * FROM users WHERE id=1;\n```"), "code:sql");
});
t("qo'yilgan kod (``` siz)", () => {
  assert.equal(kind('def add(a, b):\n    return a + b\n\nif __name__ == "__main__":\n    print(add(1, 2))'), "code:python");
  assert.equal(kind('#include <iostream>\nusing namespace std;\nint main() {\n  cout << "hi";\n}'), "code:cpp");
  assert.equal(kind('#include <stdio.h>\nint main(void) {\n  printf("hi\\n");\n  return 0;\n}'), "code:c");
  assert.equal(kind("const a = 5;\nconsole.log(a);\nconst f = (x) => x * 2;"), "code:javascript");
  assert.equal(kind("section .text\nglobal _start\n_start:\n  mov eax, 1\n  xor ebx, ebx\n  int 0x80"), "code:asm");
  assert.equal(kind('{\n  "a": 1,\n  "b": [1, 2]\n}'), "code:json");
  assert.equal(kind("SELECT name FROM users WHERE id = 1;"), "code:sql");
  assert.equal(kind("package main\n\nimport \"fmt\"\n\nfunc main() {\n  fmt.Println(\"hi\")\n}"), "code:go");
  assert.equal(kind("<!DOCTYPE html>\n<html><body><div>x</div></body></html>"), "code:html");
});
t("Linux/Kali buyruqlari", () => {
  for (const c of ["nmap -sV 192.168.1.1", "sudo apt update", "sudo apt install nmap -y", "ls -la /var/www", "msfconsole", "cd /var/www\nls -la",
    "$ whoami", "┌──(kali㉿kali)-[~]\n└─$ nmap -sS -p- 10.10.10.5", "git clone https://github.com/a/b", "cat /etc/passwd | grep root",
    "hydra -l admin -P rockyou.txt ssh://10.0.0.1", "chmod +x exploit.sh && ./exploit.sh", "root@kali:~# airmon-ng start wlan0", "sqlmap -u http://x.com/?id=1 --dbs"])
    assert.equal(kind(c), "term", c);
});
t("oddiy suhbat — matn bo'lib qoladi", () => {
  for (const c of ["salom, qalaysan?", "cat", "man up", "python is great", "ping me tomorrow", "# Sarlavha", "$ 5 dollars", "Men bugun nmap haqida o'qidim.",
    "sudo", "ls", "top 10 film", "id kerak", "select a name from the list", "Ertaga soat 5 da uchrashamiz. Kod yozaman.", "git", "echo", "hello world\nhow are you\nfine"])
    assert.equal(kind(c), "text", c);
});
t("tokenizer: sinflar va yo'qotishsiz", () => {
  const tk = R.tokenize('x = "salom" # izoh\ndef f(a): return 42', "python");
  const has = (c, s) => tk.some(([k, v]) => k === c && v.includes(s));
  assert.ok(has("s", '"salom"')); assert.ok(has("c", "# izoh")); assert.ok(has("k", "def")); assert.ok(has("n", "42")); assert.ok(has("f", "f"));
  const samples = {python: "a='x'\n'''m\nl'''", cpp: '#include <a>\n/* c\nd */ int x = 0x1F; // e', asm: "_start:\n  mov rax, 60 ; k\n  syscall", html: '<a href="x">t</a><!-- c -->', css: "a:hover { color: #fff; margin: 0 auto }", json: '{"k": [1, true, null]}', bash: "echo $HOME | grep -i 'x' > /dev/null #c", sql: "select * from t where a = 'x'; -- c", php: "<?php $a = 1; echo $a; ?>", rust: "fn main() { println!(\"x\"); }"};
  for (const [lang, src] of Object.entries(samples)) assert.equal(R.tokenize(src, lang).map(x => x[1]).join(""), src, lang);
  assert.ok(R.tokenize("`x${y}` /* ", "javascript").length > 0);
  const big = "int a = 1; // x\n".repeat(20000);
  const t0 = Date.now(); R.tokenize(big, "c"); assert.ok(Date.now() - t0 < 3000, "sekin");
  assert.equal(R.tokenize("</script><img src=x onerror=alert(1)>", "html").map(x => x[1]).join(""), "</script><img src=x onerror=alert(1)>");   // faqat matn
});
t("avtomatik ``` o'rash", () => {
  const f = R.fenceFor("def a():\n    return 1\n");
  assert.ok(f && f.text.startsWith("```python\n") && f.text.endsWith("\n```"));
  assert.equal(R.fenceFor("oddiy gap"), null);
  assert.equal(R.fenceFor("```x\ny\n```"), null);
});
t("nusxalash matni: terminalda faqat buyruqlar", () => {
  const p = R.parse("$ nmap -sV 10.0.0.1\nStarting Nmap 7.94\n$ whoami")[0];
  assert.equal(p.k, "term");
  assert.equal(R.copyTextOf(p), "nmap -sV 10.0.0.1\nwhoami");
});

// ---- pcap ----
const u32 = (n, le) => { const b = Buffer.alloc(4); le ? b.writeUInt32LE(n) : b.writeUInt32BE(n); return b; };
const u16 = (n, le) => { const b = Buffer.alloc(2); le ? b.writeUInt16LE(n) : b.writeUInt16BE(n); return b; };
const eth = (type, payload) => Buffer.concat([Buffer.from("aabbccddeeff112233445566", "hex"), u16(type, false), payload]);
const ipv4 = (proto, payload, src = [10, 0, 0, 1], dst = [10, 0, 0, 2]) => Buffer.concat([Buffer.from([0x45, 0, 0, 0]), Buffer.from([0, 0, 0, 0, 64, proto, 0, 0]), Buffer.from(src), Buffer.from(dst), payload]).fill ? (() => { const b = Buffer.concat([Buffer.from([0x45, 0, 0, 0, 0, 0, 0, 0, 64, proto, 0, 0]), Buffer.from(src), Buffer.from(dst), payload]); b.writeUInt16BE(b.length, 2); return b; })() : null;
const tcp = (sp, dp, flags, data = Buffer.alloc(0)) => { const b = Buffer.alloc(20); b.writeUInt16BE(sp, 0); b.writeUInt16BE(dp, 2); b[12] = 0x50; b[13] = flags; return Buffer.concat([b, data]); };
const arp = Buffer.concat([u16(1), u16(0x0800), Buffer.from([6, 4]), u16(1), Buffer.from("aabbccddeeff", "hex"), Buffer.from([10, 0, 0, 1]), Buffer.alloc(6), Buffer.from([10, 0, 0, 2])]);
const pkts = [eth(0x0800, ipv4(6, tcp(51234, 443, 0x02))), eth(0x0806, arp), eth(0x0800, ipv4(6, tcp(80, 51000, 0x18, Buffer.from("GET /")))), eth(0x0800, ipv4(1, Buffer.from([8, 0, 0, 0, 0, 0, 0, 0])))];
const classic = le => Buffer.concat([u32(0xa1b2c3d4, le), u16(2, le), u16(4, le), u32(0, le), u32(0, le), u32(65535, le), u32(1, le),
  ...pkts.flatMap((p, i) => [u32(1700000000 + i, le), u32(250000, le), u32(p.length, le), u32(p.length, le), p])]);
t("pcap (little va big endian)", () => {
  for (const le of [true, false]) {
    const info = R.parsePcap(classic(le));
    assert.equal(info.format, "pcap"); assert.equal(info.count, 4); assert.equal(info.linkName, "Ethernet"); assert.equal(info.version, "2.4");
    assert.equal(info.packets[0].proto, "TLS"); assert.ok(info.packets[0].text.includes("10.0.0.1:51234 → 10.0.0.2:443  [S]  len 0"), info.packets[0].text);
    assert.equal(info.packets[1].proto, "ARP"); assert.ok(info.packets[1].text.includes("who has 10.0.0.2? tell 10.0.0.1"));
    assert.equal(info.packets[2].proto, "HTTP"); assert.ok(info.packets[2].text.includes("[P.]") && info.packets[2].text.endsWith("len 5"), info.packets[2].text);
    assert.equal(info.packets[3].proto, "ICMP"); assert.ok(info.packets[3].text.includes("echo request"));
    assert.equal(info.stats.ARP, 1); assert.ok(Math.abs(info.duration - 3) < 1e-6);
  }
  const txt = R.pcapText(R.parsePcap(classic(true)), "dump.pcap");
  assert.ok(txt.startsWith("tcpdump -nn -r dump.pcap"));
});
t("pcap: kesilgan va noto'g'ri fayllar", () => {
  const full = classic(true);
  const cut = R.parsePcap(full.subarray(0, full.length - 3));
  assert.equal(cut.truncated, true); assert.equal(cut.count, 3);
  assert.throws(() => R.parsePcap(Buffer.from("MZ" + "x".repeat(100))), /pcap/);
  assert.throws(() => R.parsePcap(Buffer.alloc(10)), /qisqa/);
});
t("pcapng", () => {
  const blk = (type, body) => { const len = 12 + body.length; return Buffer.concat([u32(type, true), u32(len, true), body, u32(len, true)]); };
  const shb = blk(0x0a0d0d0a, Buffer.concat([u32(0x1a2b3c4d, true), u16(1, true), u16(0, true), Buffer.alloc(8, 0xff)]));
  const idb = blk(1, Buffer.concat([u16(1, true), u16(0, true), u32(65535, true)]));
  const p = pkts[0], padn = (4 - (p.length % 4)) % 4;
  const epb = blk(6, Buffer.concat([u32(0, true), u32(0, true), u32(1000000, true), u32(p.length, true), u32(p.length, true), p, Buffer.alloc(padn)]));
  const info = R.parsePcap(Buffer.concat([shb, idb, epb]));
  assert.equal(info.format, "pcapng"); assert.equal(info.count, 1); assert.equal(info.packets[0].proto, "TLS");
});
t("maxsus emoji nomlari", () => {
  assert.ok(R.isEmojiToken(":kali:")); assert.ok(!R.isEmojiToken("kali")); assert.ok(!R.isEmojiToken(":a:")); assert.ok(!R.isEmojiToken(":../x:"));
  R.setEmojis([{token: ":evil:", file: "../../x.svg"}, {token: ":nmap:", file: "nmap.svg", label: "Nmap"}]);
  const l = R.emojiList();
  assert.ok(l.some(e => e.token === ":kali:")); assert.ok(l.some(e => e.token === ":nmap:")); assert.ok(!l.some(e => e.token === ":evil:"));
});
t("matn ichidagi emojilar", () => {
  R.setEmojis([{token: ":kulgi_1:", url: "/emoji-files/0123456789abcdef0123.png", label: "kulgi"}, {token: ":bad:", url: "https://evil.example/x.png"}, {token: ":bad2:", url: "/emoji-files/../../x.png"}], true);
  const l = R.emojiList();
  assert.ok(l.some(e => e.token === ":kulgi_1:")); assert.ok(!l.some(e => e.token === ":bad:")); assert.ok(!l.some(e => e.token === ":bad2:"));
  assert.ok(l.some(e => e.token === ":kali:"));                                  // tayyor emojilar replace'dan keyin ham qoladi
  assert.deepEqual(R.emojiMatches("salom :kulgi_1: va :soat: va :kali:").map(m => m.t), [":kulgi_1:", ":kali:"]);
  assert.deepEqual(R.emojiMatches(":nomalum:kali:").map(m => m.t), [":kali:"]);   // noma'lum nomdan keyin ham qidiriladi
  assert.equal(R.hasInlineEmoji("12:30:45"), false); assert.equal(R.hasInlineEmoji("oddiy matn"), false);
});
console.log(process.exitCode ? "XATO bor" : `richtext: ${n} guruh test OK`);
