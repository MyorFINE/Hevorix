// Dumaloq video xabar paketini tekshiradi: aylanib-qaytish, ovozsiz holat, buzilgan/begona ma'lumotni rad etish.
// Ishlatish: node tests/vnote_pack_test.mjs
import fs from "node:fs"; import vm from "node:vm"; import assert from "node:assert/strict";
const src = fs.readFileSync(new URL("../app/static/js/vnote.js", import.meta.url).pathname, "utf8");
vm.runInThisContext(src);
const {pack, unpack, MAX_SEC, MIN_SEC} = globalThis.VNote;

const rnd = n => { const a = new Uint8Array(n); for (let i = 0; i < n; i++) a[i] = (i * 31 + 7) & 255; return a; };

// 1) video + ovoz
{
  const v = rnd(5000), a = rnd(777), p = pack(v, a), u = unpack(p);
  assert.equal(p.length, 12 + 5000 + 777);
  assert.deepEqual([...u.video], [...v]); assert.deepEqual([...u.audio], [...a]);
}
// 2) ovozsiz
{
  const v = rnd(123), u = unpack(pack(v, null));
  assert.deepEqual([...u.video], [...v]); assert.equal(u.audio, null);
}
// 3) ArrayBuffer ham qabul qilinadi
{
  const v = rnd(50), u = unpack(pack(v.buffer, rnd(9).buffer)); assert.equal(u.video.length, 50); assert.equal(u.audio.length, 9);
}
// 4) buzilgan/begona paketlar rad etiladi
{
  const good = pack(rnd(100), rnd(40));
  assert.throws(() => unpack(new Uint8Array(0)));
  assert.throws(() => unpack(new Uint8Array(12)));                                   // sarlavha bor, video yo'q
  assert.throws(() => unpack(good.subarray(0, good.length - 1)));                    // qisqartirilgan
  const longer = new Uint8Array(good.length + 1); longer.set(good); assert.throws(() => unpack(longer));   // ortiqcha baytlar
  const badMagic = good.slice(); badMagic[0] = 0x00; assert.throws(() => unpack(badMagic));
  const huge = good.slice(); new DataView(huge.buffer).setUint32(4, 0xffffffff); assert.throws(() => unpack(huge));  // uzunlik yolg'on
  const zeroVideo = good.slice(); new DataView(zeroVideo.buffer).setUint32(4, 0); assert.throws(() => unpack(zeroVideo));
  assert.throws(() => pack(new Uint8Array(0), rnd(5)));                              // bo'sh video
}
// 5) subarray (byteOffset != 0) ustida ham to'g'ri ishlaydi
{
  const p = pack(rnd(64), rnd(16)), big = new Uint8Array(200); big.set(p, 37);
  const u = unpack(big.subarray(37, 37 + p.length)); assert.equal(u.video.length, 64); assert.equal(u.audio.length, 16);
}
assert.equal(MAX_SEC, 60); assert.ok(MIN_SEC >= 1);
console.log("vnote pack: OK");
