"""Xavfsizlik mustahkamlash testlari (unittest: pytest ham, `python -m unittest tests.test_hardening` ham ishlaydi).

Bu testlar FastAPI'ga bog'liq emas va har biri o'z vaqtinchalik papkasida ishlaydi (umumiy holat yo'q).
"""
import asyncio
import base64
import hashlib
import io
import json
import os
import secrets
import sqlite3
import sys
import tarfile
import tempfile
import time
import unittest
from pathlib import Path

os.environ.setdefault("TERMCHAT_DATA_DIR", tempfile.mkdtemp(prefix="termchat-hard-"))
os.environ.setdefault("TERMCHAT_REQUIRE_E2EE", "0")
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app import datasnap  # noqa: E402
from app import security  # noqa: E402


class PasswordHashTests(unittest.TestCase):
    def test_new_hash_roundtrip_and_parameters_inside(self):
        h = security.hash_password("sirli-parol")
        self.assertTrue(h.startswith("s2$"))
        self.assertTrue(security.verify_password("sirli-parol", h))
        self.assertFalse(security.verify_password("boshqa", h))
        self.assertFalse(security.needs_rehash(h))

    def test_same_password_gives_different_hashes(self):
        self.assertNotEqual(security.hash_password("a-b-c-1"), security.hash_password("a-b-c-1"))

    def test_legacy_hash_still_verifies_and_is_flagged_for_rehash(self):
        salt = secrets.token_bytes(16)
        legacy = f"{salt.hex()}${hashlib.scrypt(b'eski-parol', salt=salt, n=2 ** 14, r=8, p=1).hex()}"
        self.assertTrue(security.verify_password("eski-parol", legacy))
        self.assertFalse(security.verify_password("xato", legacy))
        self.assertTrue(security.needs_rehash(legacy))

    def test_malformed_or_hostile_hashes_are_rejected_not_crashing(self):
        for bad in ("", "garbage", "s2$99$8$1$00$00", "s2$15$8$1$zz$00", "x$15$8$1$00$00", "a$b$c"):
            self.assertFalse(security.verify_password("x", bad), bad)
            self.assertFalse(security.needs_rehash(bad), bad)

    def test_backup_restore_accepts_both_hash_formats(self):
        """Zaxirani tiklash yangi ("s2$...") hash'ni yaroqsiz deb rad etmasligi kerak (foydalanuvchi kirish ma'lumoti yo'qolmasin)."""
        salt = secrets.token_bytes(16)
        legacy = f"{salt.hex()}${hashlib.scrypt(b'x', salt=salt, n=2 ** 14, r=8, p=1).hex()}"
        self.assertTrue(security.valid_hash_shape(legacy))
        self.assertTrue(security.valid_hash_shape(security.hash_password("yangi-parol")))
        for bad in ("plain", "", None, 123, "s2$15$8$1$00$00", "a" * 300):
            self.assertFalse(security.valid_hash_shape(bad), bad)

    def test_burn_verify_does_not_raise(self):
        security.burn_verify("hech narsa")


class TransportNonceTests(unittest.TestCase):
    def _session(self):
        from app.transport import CryptoSession
        return CryptoSession("kid", secrets.token_bytes(32), secrets.token_bytes(32))

    def test_http_nonces_are_unique_and_structured(self):
        s = self._session()
        ivs = [s.next_http_iv() for _ in range(5000)]
        self.assertEqual(len(set(ivs)), 5000)
        self.assertTrue(all(len(i) == 12 and i[:4] == b"\0\0\0\0" for i in ivs))

    def test_websocket_streams_never_share_nonce_space(self):
        s = self._session()
        prefixes = [s.new_stream() for _ in range(100)]
        self.assertEqual(len(set(prefixes)), 100)
        self.assertNotIn(b"\0\0\0\0", prefixes)                # 0 — faqat HTTP javoblari uchun

    def test_response_nonce_not_reused(self):
        from app import transport
        s = self._session()
        a, b = transport.seal_response(s, 200, "x", b"1"), transport.seal_response(s, 200, "x", b"1")
        self.assertNotEqual(a[:12], b[:12])

    def test_oversized_websocket_frame_is_rejected_before_decrypting(self):
        from app import transport

        class FakeRaw:
            def __init__(self, text): self.text = text
            async def receive_text(self): return self.text

        ws = transport.SecureWS(FakeRaw("A" * (transport.max_ws_frame() + 1)), self._session())
        with self.assertRaises(transport.FrameTooBig):
            asyncio.run(ws.receive_text())

    def test_websocket_replay_and_tamper_detected(self):
        from app import transport
        s = self._session()
        iv = secrets.token_bytes(4) + (1).to_bytes(8, "big")
        frame = base64.b64encode(iv + s.up.encrypt(iv, b'{"a":1}', transport.AAD_WS_C2S)).decode()

        class Raw:
            def __init__(self, frames): self.frames = list(frames)
            async def receive_text(self): return self.frames.pop(0)

        ws = transport.SecureWS(Raw([frame, frame]), s)
        self.assertEqual(asyncio.run(ws.receive_text()), '{"a":1}')
        with self.assertRaises(ValueError):                    # ayni kadrni qayta yuborish (replay)
            asyncio.run(ws.receive_text())
        raw = bytearray(base64.b64decode(frame)); raw[-1] ^= 1
        ws2 = transport.SecureWS(Raw([base64.b64encode(bytes(raw)).decode()]), s)
        with self.assertRaises(Exception):                     # shifrlangan ma'lumot o'zgartirildi (GCM teg)
            asyncio.run(ws2.receive_text())


class ImageLimitsTests(unittest.TestCase):
    def setUp(self):
        try:
            from PIL import Image  # noqa: F401
        except ImportError:
            self.skipTest("Pillow yo'q")

    def test_big_multiframe_gif_is_rejected(self):
        from PIL import Image
        from app.errors import ChatError
        from app.services import imgclean
        frames = [Image.new("P", (3000, 3000), i) for i in range(15)]
        buf = io.BytesIO(); frames[0].save(buf, "GIF", save_all=True, append_images=frames[1:])
        with self.assertRaises(ChatError):
            imgclean.clean(buf.getvalue())

    def test_exif_is_stripped(self):
        from PIL import Image
        from app.services import imgclean
        exif = Image.Exif(); exif[0x010f] = "SecretCameraMaker"
        buf = io.BytesIO(); Image.new("RGB", (80, 60), (5, 5, 5)).save(buf, "JPEG", exif=exif.tobytes())
        self.assertNotIn(b"SecretCameraMaker", imgclean.clean(buf.getvalue()).data)


class DigitParsingTests(unittest.TestCase):
    def test_unicode_digits_do_not_crash_parsers(self):
        from app.errors import ChatError
        from app.commands.base import parse_id
        from app.services import moderation
        self.assertEqual(parse_id("#12"), 12)
        with self.assertRaises(ChatError):
            parse_id("²")                                      # '²'.isdigit() == True, lekin int('²') xato berardi
        # '²' endi raqam hisoblanmaydi: standart davomiylikka tushadi (xato ko'tarilmaydi)
        seconds, _, _ = moderation.parse_mute("²")
        self.assertGreater(seconds, 0)


def _make_data_dir(root: Path, users: int = 2) -> Path:
    d = root / "data"
    (d / "media").mkdir(parents=True)
    (d / "avatars").mkdir()
    conn = sqlite3.connect(d / "chat.db")
    conn.executescript("CREATE TABLE users(id INTEGER PRIMARY KEY, username TEXT);"
                       "CREATE TABLE messages(id INTEGER PRIMARY KEY, content TEXT);")
    for i in range(users):
        conn.execute("INSERT INTO users(username) VALUES(?)", (f"u{i}",))
    conn.execute("INSERT INTO messages(content) VALUES('e2e1:abc')")
    conn.commit(); conn.close()
    (d / "media" / "a.e2e").write_bytes(b"\x01" * 1000)
    (d / "media" / "b.enc").write_bytes(b"\x02" * 500)
    (d / "media" / "half.tmp").write_bytes(b"partial")
    (d / "master.key").write_text("SUPER-SECRET-MASTER-KEY-VALUE")
    (d / "vapid.key").write_text("SUPER-SECRET-VAPID")
    return d


class SnapshotTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.root = Path(self._tmp.name)
        self.data = _make_data_dir(self.root)

    def tearDown(self):
        self._tmp.cleanup()

    def test_secret_keys_and_tmp_files_never_enter_archive(self):
        arc = self.root / "s.tar.gz"
        m = datasnap.create(self.data, arc)
        with tarfile.open(arc) as t:
            names = t.getnames()
            blob = b"".join(t.extractfile(n).read() for n in names if t.getmember(n).isreg())
        self.assertNotIn("master.key", " ".join(names))
        self.assertNotIn("vapid.key", " ".join(names))
        self.assertNotIn(b"SUPER-SECRET", blob)
        self.assertFalse(any(n.endswith(".tmp") for n in names))
        self.assertEqual({e["name"] for e in m["files"]}, {"chat.db", "files/media/a.e2e", "files/media/b.enc"})
        self.assertEqual(m["counts"]["users"], 2)
        self.assertEqual(oct(arc.stat().st_mode & 0o777), "0o600")

    def test_verify_ok_then_detects_corruption(self):
        arc = self.root / "s.tar.gz"
        datasnap.create(self.data, arc)
        datasnap.verify(arc)
        bad = self.root / "bad.tar.gz"                          # bitta faylning mazmunini almashtiramiz, manifest o'zgarishsiz
        with tarfile.open(arc) as src, tarfile.open(bad, "w:gz") as dst:
            for m in src:
                body = src.extractfile(m).read()
                if m.name == "files/media/a.e2e":
                    body = b"\x09" * len(body)
                info = tarfile.TarInfo(m.name); info.size = len(body)
                dst.addfile(info, io.BytesIO(body))
        with self.assertRaises(datasnap.SnapshotError):
            datasnap.verify(bad)

    def test_verify_rejects_path_traversal_and_garbage(self):
        evil = self.root / "evil.tar.gz"
        with tarfile.open(evil, "w:gz") as t:
            body = b"x"; info = tarfile.TarInfo("../../etc/evil"); info.size = 1
            t.addfile(info, io.BytesIO(body))
        with self.assertRaises(datasnap.SnapshotError):
            datasnap.verify(evil)
        junk = self.root / "junk.tar.gz"; junk.write_bytes(b"not an archive")
        with self.assertRaises(datasnap.SnapshotError):
            datasnap.verify(junk)

    def test_restore_into_empty_dir_reproduces_data(self):
        arc = self.root / "s.tar.gz"
        datasnap.create(self.data, arc)
        target = self.root / "new"
        res = datasnap.restore(arc, target)
        self.assertIsNone(res["previous_moved_to"])
        c = sqlite3.connect(target / "chat.db")
        self.assertEqual(c.execute("SELECT COUNT(*) FROM users").fetchone()[0], 2)
        c.close()
        self.assertEqual((target / "media" / "a.e2e").read_bytes(), b"\x01" * 1000)
        self.assertFalse((target / "master.key").exists())

    def test_restore_never_overwrites_existing_data_silently(self):
        arc = self.root / "s.tar.gz"
        datasnap.create(self.data, arc)
        existing = _make_data_dir(self.root / "other", users=5)
        with self.assertRaises(datasnap.SnapshotError):
            datasnap.restore(arc, existing)
        c = sqlite3.connect(existing / "chat.db")                # hech narsa o'zgarmadi
        self.assertEqual(c.execute("SELECT COUNT(*) FROM users").fetchone()[0], 5)
        c.close()
        res = datasnap.restore(arc, existing, force=True)         # force: eski nusxa saqlanadi
        old = existing / res["previous_moved_to"]
        c = sqlite3.connect(old / "chat.db")
        self.assertEqual(c.execute("SELECT COUNT(*) FROM users").fetchone()[0], 5)
        c.close()
        c = sqlite3.connect(existing / "chat.db")
        self.assertEqual(c.execute("SELECT COUNT(*) FROM users").fetchone()[0], 2)
        c.close()
        self.assertTrue((existing / "master.key").exists())       # maxfiy kalitga tegilmaydi

    def test_corrupt_archive_does_not_touch_target(self):
        arc = self.root / "s.tar.gz"
        datasnap.create(self.data, arc)
        raw = bytearray(arc.read_bytes()); raw[len(raw) // 2] ^= 0xFF
        broken = self.root / "broken.tar.gz"; broken.write_bytes(bytes(raw))
        existing = _make_data_dir(self.root / "keep", users=3)
        with self.assertRaises(datasnap.SnapshotError):
            datasnap.restore(broken, existing, force=True)
        c = sqlite3.connect(existing / "chat.db")
        self.assertEqual(c.execute("SELECT COUNT(*) FROM users").fetchone()[0], 3)
        c.close()
        self.assertFalse(list(existing.glob("pre-restore-*")))

    def test_db_only_backup(self):
        arc = self.root / "d.tar.gz"
        m = datasnap.create(self.data, arc, include_files=False)
        self.assertEqual([e["name"] for e in m["files"]], ["chat.db"])
        datasnap.verify(arc)


class MaintenanceTests(unittest.TestCase):
    def test_sweep_tmp_removes_only_old_tmp_files(self):
        from app.config import settings
        from app.services import maintenance
        old, fresh, keep = settings.media_dir / "old.tmp", settings.media_dir / "fresh.tmp", settings.media_dir / "keep.enc"
        for p in (old, fresh, keep):
            p.write_bytes(b"x")
        past = time.time() - 7200
        os.utime(old, (past, past))
        try:
            self.assertGreaterEqual(maintenance.sweep_tmp(3600), 1)
            self.assertFalse(old.exists()); self.assertTrue(fresh.exists()); self.assertTrue(keep.exists())
        finally:
            for p in (old, fresh, keep):
                p.unlink(missing_ok=True)


class AvatarSizeTests(unittest.TestCase):
    def test_big_avatar_is_shrunk_in_place_and_small_left_alone(self):
        try:
            from PIL import Image
        except ImportError:
            self.skipTest("Pillow yo'q")
        from app.config import settings
        from app.services import maintenance
        big, small = settings.avatars_dir / "zz_big.jpg", settings.avatars_dir / "zz_small.jpg"
        Image.new("RGB", (2400, 1800), (9, 9, 9)).save(big, "JPEG")
        Image.new("RGB", (200, 200), (9, 9, 9)).save(small, "JPEG")
        before = small.read_bytes()
        try:
            maintenance.shrink_avatars(limit=100)
            self.assertLessEqual(max(Image.open(big).size), 512)
            self.assertEqual(small.read_bytes(), before)
        finally:
            big.unlink(missing_ok=True); small.unlink(missing_ok=True)


class AutoBackupTests(unittest.TestCase):
    def test_rolling_backup_keeps_only_latest_and_is_verified(self):
        from app.services import maintenance
        with tempfile.TemporaryDirectory() as d:
            first = maintenance.auto_backup(hours=1, keep=2, directory=d)
            self.assertIsNotNone(first)
            self.assertIsNone(maintenance.auto_backup(hours=1, keep=2, directory=d))     # hali vaqti kelmagan
            self.assertIsNone(maintenance.auto_backup(hours=0, keep=2, directory=d))     # o'chiq
            for i in range(3):                                                           # eski nusxalarni "qarilashtiramiz"
                p = sorted(Path(d).glob("auto-*.tar.gz"))[-1]
                os.utime(p, (time.time() - 7200, time.time() - 7200))
                time.sleep(1.1)
                self.assertIsNotNone(maintenance.auto_backup(hours=1, keep=2, directory=d))
            files = sorted(Path(d).glob("auto-*.tar.gz"))
            self.assertEqual(len(files), 2)
            datasnap.verify(files[-1])
            self.assertFalse(any("live-" in x.name for x in Path(d).iterdir()))         # vaqtinchalik papka qolmadi


class SessionManagementTests(unittest.TestCase):
    def test_list_and_revoke_only_own_sessions(self):
        from app.errors import ChatError
        from app.repositories import users
        from app.services import auth
        tag = secrets.token_hex(3)
        ta1, _ = auth.register(f"sa{tag}", "A", "parol123")
        ta2, _ = auth.login(f"sa{tag}", "parol123")
        tb, _ = auth.register(f"sb{tag}", "B", "parol123")
        a, b = users.get_by_username(f"sa{tag}"), users.get_by_username(f"sb{tag}")
        rows = auth.list_sessions(a, ta1)
        self.assertEqual(len(rows), 2)
        self.assertEqual([r["current"] for r in rows].count(True), 1)
        self.assertNotIn(ta1, json.dumps(rows))                   # token ro'yxatda ko'rinmaydi
        other = next(r for r in rows if not r["current"])
        with self.assertRaises(ChatError):                        # B, A ning sessiyasini bekor qila olmaydi
            auth.revoke_session(b, other["id"])
        self.assertEqual(len(auth.list_sessions(a, ta1)), 2)
        auth.revoke_session(a, other["id"])
        self.assertEqual(len(auth.list_sessions(a, ta1)), 1)
        revoked = ta2 if other["id"] == security.hash_token(ta2)[:16] else ta1
        self.assertIsNone(auth.authenticate(revoked))             # bekor qilingan token endi ishlamaydi
        with self.assertRaises(ChatError):
            auth.revoke_session(a, "../../x")                     # noto'g'ri identifikator
        self.assertEqual(len(auth.list_sessions(b, tb)), 1)       # B ga tegilmadi

    def test_revoke_others_keeps_current(self):
        from app.repositories import users
        from app.services import auth
        tag = secrets.token_hex(3)
        t1, _ = auth.register(f"sc{tag}", "C", "parol123")
        t2, _ = auth.login(f"sc{tag}", "parol123")
        t3, _ = auth.login(f"sc{tag}", "parol123")
        u = users.get_by_username(f"sc{tag}")
        auth.revoke_other_sessions(u, t2)
        self.assertIsNone(auth.authenticate(t1))
        self.assertIsNone(auth.authenticate(t3))
        self.assertIsNotNone(auth.authenticate(t2))

    def test_logout_invalidates_token(self):
        from app.services import auth
        t, _ = auth.register(f"sd{secrets.token_hex(3)}", "D", "parol123")
        self.assertIsNotNone(auth.authenticate(t))
        auth.logout(t)
        self.assertIsNone(auth.authenticate(t))

    def test_idle_session_expires(self):
        from app.db import db
        from app.services import auth
        t, _ = auth.register(f"se{secrets.token_hex(3)}", "E", "parol123")
        db.run("UPDATE sessions SET last_active=?, created_at=? WHERE token_hash=?",
               (time.time() - auth.idle_limit() - 5, time.time() - auth.idle_limit() - 5, security.hash_token(t)))
        self.assertIsNone(auth.authenticate(t))


if __name__ == "__main__":
    unittest.main()
