// js/backup.js <-> tools/decode_backup.py moslik sinovi:  node tests/backup_interop.mjs
import {readFileSync, writeFileSync, mkdtempSync} from "node:fs";
import {tmpdir} from "node:os";
import {join} from "node:path";
import {spawnSync} from "node:child_process";
import vm from "node:vm";
import {webcrypto} from "node:crypto";

const ctx = {crypto: webcrypto, TextEncoder, TextDecoder, window: {}, Uint8Array, JSON, String, Math};
vm.createContext(ctx);
vm.runInContext(readFileSync(new URL("../app/static/js/backup.js", import.meta.url), "utf8"), ctx);
const B = ctx.window.Backup;
const eq = (a, b, m) => { if (JSON.stringify(a) !== JSON.stringify(b)) { console.error("XATO:", m); process.exit(1); } };

const sample = {v: 1, app: "anonim-chat", users: [{username: "ali", nickname: "Ali ✅ ўзбек", role: "user", joined: 1700000000}]};
const bytes = await B.seal(sample, "kuchli parol-ibora 123");
eq(await B.open(bytes, "kuchli parol-ibora 123"), sample, "JS aylanish");

let bad = false; try { await B.open(bytes, "noto'g'ri parol"); } catch (e) { bad = /noto'g'ri/.test(e.message); }
eq(bad, true, "noto'g'ri parol rad etilishi");
const t = bytes.slice(); t[t.length - 3] ^= 1; bad = false; try { await B.open(t, "kuchli parol-ibora 123"); } catch (_) { bad = true; }
eq(bad, true, "o'zgartirilgan fayl rad etilishi");
const h = bytes.slice(); h[8] ^= 1; bad = false; try { await B.open(h, "kuchli parol-ibora 123"); } catch (_) { bad = true; }
eq(bad, true, "sarlavha (AAD) o'zgarishi rad etilishi");
bad = false; try { await B.seal(sample, "qisqa"); } catch (_) { bad = true; }
eq(bad, true, "qisqa parol-ibora rad etilishi");

// JS yaratgan fayl -> Python ochadi; Python yaratgan -> JS ochadi
const dir = mkdtempSync(join(tmpdir(), "acdb-"));
writeFileSync(join(dir, "a.acdb"), bytes);
const py = `
import sys, json; sys.path.insert(0, "tools")
from decode_backup import open_backup, seal
d = open_backup(open(sys.argv[1], "rb").read(), "kuchli parol-ibora 123")
open(sys.argv[2], "wb").write(seal(d, "kuchli parol-ibora 123", 600000))
print(json.dumps(d, ensure_ascii=False))`;
const r = spawnSync("python3", ["-c", py, join(dir, "a.acdb"), join(dir, "b.acdb")], {cwd: new URL("..", import.meta.url).pathname, encoding: "utf8"});
if (r.status !== 0) { console.error(r.stderr); process.exit(1); }
eq(JSON.parse(r.stdout), sample, "Python ochgan JSON");
eq(await B.open(new Uint8Array(readFileSync(join(dir, "b.acdb"))), "kuchli parol-ibora 123"), sample, "JS Python faylini ochdi");
console.log("backup interop: OK");
