/* Anonim Chat by Hevorix — foydalanuvchilar zaxirasini shifrlash/ochish (faqat brauzerda, WebCrypto).
   Fayl (.acdb) tuzilishi:  "ACDB1\n" (6) | tuz (16) | PBKDF2 aylanishlari u32 BE (4) | iv (12) | AES-256-GCM shifr+teg
   Kalit: PBKDF2-SHA256(parol-ibora NFKC/UTF-8, tuz, 600 000) -> AES-256-GCM. AAD = sarlavha (magic|tuz|aylanishlar).
   Parol-ibora serverga HECH QACHON yuborilmaydi: server faqat ochiq yozuvlarni beradi/qabul qiladi, fayl esa shu yerda yopiladi.
   Python nusxasi: tools/decode_backup.py (xuddi shu format). */
"use strict";
(() => {
const MAGIC = new TextEncoder().encode("ACDB1\n"), SALT = 16, IV = 12, ITER = 600000, MIN_ITER = 100000, MAX_ITER = 3000000;
const cat = (...p) => { const o = new Uint8Array(p.reduce((n, x) => n + x.length, 0)); let k = 0; for (const x of p) { o.set(x, k); k += x.length; } return o; };
const subtle = () => crypto.subtle;
async function keyFrom(pass, salt, iter) {
  const raw = new TextEncoder().encode(String(pass).normalize("NFKC"));
  const base = await subtle().importKey("raw", raw, "PBKDF2", false, ["deriveKey"]);
  return subtle().deriveKey({name: "PBKDF2", hash: "SHA-256", salt, iterations: iter}, base, {name: "AES-GCM", length: 256}, false, ["encrypt", "decrypt"]);
}
const u32 = n => new Uint8Array([(n >>> 24) & 255, (n >>> 16) & 255, (n >>> 8) & 255, n & 255]);
async function seal(obj, pass) {
  if (typeof pass !== "string" || pass.length < 8) throw new Error("Parol-ibora kamida 8 belgi bo'lishi kerak");
  const salt = crypto.getRandomValues(new Uint8Array(SALT)), iv = crypto.getRandomValues(new Uint8Array(IV));
  const head = cat(MAGIC, salt, u32(ITER));
  const ct = new Uint8Array(await subtle().encrypt({name: "AES-GCM", iv, additionalData: head}, await keyFrom(pass, salt, ITER), new TextEncoder().encode(JSON.stringify(obj))));
  return cat(head, iv, ct);
}
async function open(bytes, pass) {
  const hl = MAGIC.length + SALT + 4;
  if (!(bytes instanceof Uint8Array) || bytes.length < hl + IV + 16 || MAGIC.some((b, i) => bytes[i] !== b)) throw new Error("Bu Anonim Chat zaxira fayli emas");
  const salt = bytes.slice(MAGIC.length, MAGIC.length + SALT), o = MAGIC.length + SALT;
  const iter = ((bytes[o] << 24) | (bytes[o + 1] << 16) | (bytes[o + 2] << 8) | bytes[o + 3]) >>> 0;
  if (iter < MIN_ITER || iter > MAX_ITER) throw new Error("Zaxira fayli buzilgan");
  let plain;
  try {
    plain = await subtle().decrypt({name: "AES-GCM", iv: bytes.slice(hl, hl + IV), additionalData: bytes.slice(0, hl)}, await keyFrom(pass, salt, iter), bytes.slice(hl + IV));
  } catch (_) { throw new Error("Parol-ibora noto'g'ri yoki fayl o'zgartirilgan/buzilgan"); }
  try { return JSON.parse(new TextDecoder().decode(plain)); } catch (_) { throw new Error("Zaxira fayli buzilgan"); }
}
window.Backup = {seal, open, ITER};
})();
