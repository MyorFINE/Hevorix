/* Kanallar. Kanal ro'yxati chap panelda («Kanallar» tabi), kanal esa asosiy chat oynasida ochiladi (Telegramdagidek):
   postlar umumiy chat bilan BIR XIL xabar tizimida (E2EE, rasm, fayl, ovoz, dumaloq video) — ularni app.js chizadi va yuboradi.
   Bu fayl: ro'yxatni yuklash, kanal yaratish/sozlash/qo'shilish oynalari, ko'rishlar sanog'i, post ostidagi izohlar paneli (E2EE)
   va kanal hodisalari. Matn DOM'ga faqat textContent orqali chiqariladi (XSS yo'q, CSP qat'iy). */
(() => {
  "use strict";
  let B = null;                                   // app.js bergan ko'prik (api, h, icon, toast, ...)
  const st = {sent: new Map(), pend: new Map(), timer: 0, io: null, ioBox: null, ioCh: 0, seen: new WeakSet(), cm: null};
  const $ = id => document.getElementById(id);
  const admin = () => !!B.amAdmin();
  const fail = err => B.toast(err && err.message ? err.message : "Xato, qayta urinib ko'ring", "error");
  const nearBottom = el => el.scrollHeight - el.scrollTop - el.clientHeight < 120;

  /* ---------------- ro'yxat ---------------- */
  async function loadList() {
    if (!B) return;
    let list;
    try { list = (await B.api("/channels")).channels; } catch (err) { if (!B.list().length) fail(err); return; }
    const a = B.active();
    if (a && a.kind === "channel" && !list.some(c => c.id === a.id)) {     // ochiq kanal endi ko'rinmasa (shaxsiy qilingan/o'chirilgan)
      B.toast("Kanal endi mavjud emas yoki sizga yopilgan", "warn");
      B.closeChat();
    }
    await B.setChannelList(list);
  }

  /* ---------------- ko'rishlar: ekranga chiqqan postlar sanaladi ---------------- */
  function scheduleViews() {
    if (st.timer) return;
    st.timer = setTimeout(async () => {
      st.timer = 0;
      for (const [cid, ids] of [...st.pend]) {
        if (!ids.size) continue;
        const list = [...ids].slice(0, 50); st.pend.set(cid, new Set([...ids].slice(50)));
        const sent = st.sent.get(cid) || st.sent.set(cid, new Set()).get(cid);
        list.forEach(i => sent.add(i));
        try { await B.api("/channels/" + cid + "/views", {method: "POST", body: {ids: list}}); } catch (_) { list.forEach(i => sent.delete(i)); }
      }
      if ([...st.pend.values()].some(s => s.size)) scheduleViews();
    }, 1200);
  }
  /** app.js post qatorlarini chizgach chaqiradi: yangi qatorlar kuzatiladi. */
  function track(box, cid) {
    if (st.ioBox !== box || st.ioCh !== cid) {
      if (st.io) st.io.disconnect();
      st.ioBox = box; st.ioCh = cid; st.seen = new WeakSet();
      st.io = new IntersectionObserver(es => es.forEach(e => {
        if (!e.isIntersecting || document.hidden) return;
        const id = +e.target.dataset.id, sent = st.sent.get(cid);
        if (sent && sent.has(id)) return;
        (st.pend.get(cid) || st.pend.set(cid, new Set()).get(cid)).add(id); scheduleViews();
      }), {root: box, threshold: 0.5});
    }
    box.querySelectorAll(".row.chan[data-id]").forEach(r => { if (!st.seen.has(r)) { st.seen.add(r); st.io.observe(r); } });
  }

  /* ---------------- kanal ma'lumoti va menyu ---------------- */
  function info(id) {
    const c = B.info(id); if (!c) return;
    const h = B.h;
    B.openModal(() => {
      const rows = [
        h("div", {class: "ch-inf-av"}, B.chanAvatar(c, "l")),
        h("div", {class: "ch-inf-n", text: c.nickname}),
        h("div", {class: "ch-inf-u", text: "@" + c.username}),
        h("div", {class: "ch-inf-r"}, h("span", {text: "Turi"}), h("b", {text: c.private ? "Shaxsiy (yashirin)" : "Ommaviy"})),
        h("div", {class: "ch-inf-r"}, h("span", {text: "Postlar"}), h("b", {text: String(c.posts)})),
        c.can_manage && c.private ? h("div", {class: "ch-inf-r"}, h("span", {text: "A'zolar"}), h("b", {text: String(c.members || 0)})) : null,
        h("div", {class: "hint", text: "Postlar va izohlar uchdan-uchga shifrlangan: server ularning mazmunini ko'rmaydi."}),
      ];
      if (c.can_manage) rows.push(h("button", {class: "btn ch-wide", type: "button", text: "Kanal sozlamalari", onclick: () => { B.closeModal(); setTimeout(() => formModal(c), 0); }}));
      else if (c.private && c.joined) rows.push(h("button", {class: "btn ghost ch-wide dangerline", type: "button", text: "Kanaldan chiqish", onclick: () => { B.closeModal(); leave(c); }}));
      return h("div", {}, B.sheetHead("Kanal haqida"), h("div", {class: "sh-body"}, rows));
    }, false);
  }
  function menu(x, y, id) {
    const c = B.info(id); if (!c) return;
    const items = [{ic: "megaphone", text: "Kanal haqida", fn: () => info(id)}];
    if (c.can_manage) items.push({ic: "edit", text: "Kanal sozlamalari", fn: () => formModal(c)});
    else if (c.private && c.joined) items.push({ic: "logout", text: "Kanaldan chiqish", danger: true, fn: () => leave(c)});
    B.openMenu(x, y, items, true);
  }
  async function leave(c) {
    if (!await B.confirmDlg("Kanaldan chiqsangiz, qayta qo'shilish uchun username va parol kerak bo'ladi.", {title: "Kanaldan chiqish", okText: "Chiqish", danger: true})) return;
    try { await B.api("/channels/" + c.id + "/leave", {method: "POST"}); B.closeChat(); loadList(); } catch (err) { fail(err); }
  }

  /* ---------------- admin va qo'shilish oynalari ---------------- */
  function formModal(ch) {
    const h = B.h, editing = !!ch;
    B.openModal(() => {
      const nick = h("input", {type: "text", class: "fld", maxlength: "40", placeholder: "Masalan: Yangiliklar"}); nick.value = ch ? ch.nickname : "";
      const user = h("input", {type: "text", class: "fld", maxlength: "20", autocapitalize: "none", autocorrect: "off", spellcheck: "false", placeholder: "kanal_nomi"}); user.value = ch ? ch.username : "";
      const priv = h("input", {type: "checkbox", id: "chPriv"}); priv.checked = ch ? ch.private : false;
      const pw = h("input", {type: "password", class: "fld", maxlength: "64", autocomplete: "new-password", placeholder: editing && ch.private ? "Bo'sh qoldirsangiz o'zgarmaydi" : "Kamida 4 belgi"});
      const pwWrap = h("label", {class: "fl"}, "Kanal paroli", pw);
      const hint = h("div", {class: "hint", text: ""});
      const file = h("input", {type: "file", accept: "image/png,image/jpeg,image/webp,image/gif", class: "hidden"});
      const picked = h("small", {class: "ch-picked", text: ch && ch.avatar ? "Hozirgi rasm saqlanadi" : "Rasm tanlanmagan"});
      file.addEventListener("change", () => {
        const f = file.files[0];
        if (f && f.size > 2 * 1024 * 1024) { B.toast("Rasm 2 MB dan oshmasligi kerak", "error"); file.value = ""; picked.textContent = "Rasm tanlanmagan"; return; }
        picked.textContent = f ? f.name : "Rasm tanlanmagan";
      });
      const sync = () => {
        pwWrap.classList.toggle("hidden", !priv.checked);
        hint.textContent = priv.checked
          ? "Shaxsiy kanal ro'yxatda ko'rinmaydi: faqat adminlar ko'radi. Boshqalar kanal username'i va shu parol bilan qo'shiladi."
          : "Ommaviy kanalni barcha a'zolar ko'radi, o'qiydi va izoh yoza oladi. Post yozish faqat adminlarda.";
      };
      priv.addEventListener("change", sync); sync();
      const save = async btn => {
        btn.disabled = true;
        try {
          const body = {nickname: nick.value, username: user.value, private: priv.checked};
          if (priv.checked && pw.value) body.password = pw.value;
          const j = await B.api(editing ? "/channels/" + ch.id : "/channels", {method: editing ? "PATCH" : "POST", body});
          let saved = j.channel;
          if (file.files[0]) { const fd = new FormData(); fd.append("file", file.files[0]); saved = (await B.api("/channels/" + saved.id + "/avatar", {method: "POST", body: fd})).channel; }
          B.closeModal(); B.toast(editing ? "Kanal saqlandi" : "Kanal yaratildi", "ok");
          await loadList();
          if (!editing) B.openChat({kind: "channel", id: saved.id});
        } catch (err) { fail(err); }
        btn.disabled = false;
      };
      const saveBtn = h("button", {class: "btn ch-wide", type: "button", text: editing ? "Saqlash" : "Kanal yaratish", onclick: e => save(e.currentTarget)});
      const removeAv = editing && ch.avatar ? h("button", {class: "btn ghost sm", type: "button", text: "Rasmni olib tashlash", onclick: async () => {
        try { await B.api("/channels/" + ch.id + "/avatar", {method: "DELETE"}); ch.avatar = null; picked.textContent = "Rasm yo'q"; loadList(); } catch (err) { fail(err); }
      }}) : null;
      const del = editing ? h("div", {class: "setsec"}, h("button", {class: "btn ghost dangerline", type: "button", text: "Kanalni o'chirish", onclick: async () => {
        if (!await B.confirmDlg("Kanal, uning barcha postlari, fayllari va izohlari butunlay o'chiriladi. Buni qaytarib bo'lmaydi.", {title: "Kanalni o'chirish", okText: "O'chirish", danger: true})) return;
        try {
          await B.api("/channels/" + ch.id, {method: "DELETE"}); B.closeModal(); B.toast("Kanal o'chirildi", "ok");
          const a = B.active(); if (a && a.kind === "channel" && a.id === ch.id) B.closeChat();
          loadList();
        } catch (err) { fail(err); }
      }})) : null;
      return h("div", {}, B.sheetHead(editing ? "Kanal sozlamalari" : "Yangi kanal"),
        h("div", {class: "sh-body"},
          h("label", {class: "fl"}, "Kanal nomi (nickname)", nick),
          h("label", {class: "fl"}, "Kanal username'i", user),
          h("div", {class: "fl"}, "Kanal rasmi", h("div", {class: "ch-pick"}, h("button", {class: "btn ghost sm", type: "button", onclick: () => file.click()}, B.icon("camera", "ic vb"), " Rasm tanlash"), removeAv, picked), file),
          h("label", {class: "ch-chk"}, priv, h("span", {text: " Shaxsiy kanal (yashirin)"})),
          pwWrap, hint, saveBtn, del));
    }, false);
  }
  function joinModal() {
    const h = B.h;
    B.openModal(() => {
      const user = h("input", {type: "text", class: "fld", maxlength: "21", autocapitalize: "none", autocorrect: "off", spellcheck: "false", placeholder: "@kanal_nomi"});
      const pw = h("input", {type: "password", class: "fld", maxlength: "64", autocomplete: "off", placeholder: "Kanal paroli"});
      const go = async btn => {
        btn.disabled = true;
        try {
          const j = await B.api("/channels/join", {method: "POST", body: {username: user.value, password: pw.value}});
          B.closeModal(); B.toast("Kanalga qo'shildingiz", "ok");
          await loadList(); B.openChat({kind: "channel", id: j.channel.id});
        } catch (err) { fail(err); }
        btn.disabled = false;
      };
      return h("div", {}, B.sheetHead("Shaxsiy kanalga qo'shilish"), h("div", {class: "sh-body"},
        h("div", {class: "hint", text: "Shaxsiy kanallar ro'yxatda ko'rinmaydi. Admin bergan kanal username'i va parolini kiriting."}),
        h("label", {class: "fl"}, "Kanal username'i", user), h("label", {class: "fl"}, "Parol", pw),
        h("button", {class: "btn ch-wide", type: "button", text: "Qo'shilish", onclick: e => go(e.currentTarget)})));
    }, false);
  }

  /* ---------------- post ostidagi izohlar (asosiy oyna ichidagi panel) ---------------- */
  function snippet(m) {
    if (m.locked) return "🔒 Shifrlangan post";
    if (m.bad) return "⚠ Shifrni ochib bo'lmadi";
    const t = (m.content || "").replace(/\s+/g, " ").trim();
    const pre = m.image ? "📷 " : m.file ? (m.file.voice ? "🎤 " : m.file.vnote ? "📹 " : "📎 ") : "";
    return pre + (t ? t.slice(0, 300) : m.image ? "Rasm" : m.file ? (m.file.voice ? "Ovozli xabar" : m.file.vnote ? "Video xabar" : m.file.name) : "");
  }
  async function openComments(post) {
    const panel = $("cmPanel"); if (!panel || !post || !post.ch) return;
    const wasOpen = !panel.classList.contains("hidden");
    st.cm = {ch: post.ch, post, items: [], more: false};
    panel.classList.remove("hidden"); $("main").classList.add("cm-open");
    if (!wasOpen) B.navPush("cm");
    $("cmInp").value = ""; $("cmInp").style.height = "auto";
    renderComments();
    await loadComments(false);
    const body = $("cmBody"); body.scrollTop = body.scrollHeight;
  }
  function closeComments(fromNav) {
    if (!st.cm) return;
    st.cm = null; $("cmPanel").classList.add("hidden"); $("main").classList.remove("cm-open");
    if (!fromNav) B.navPop("cm");
  }
  async function loadComments(older) {
    const m = st.cm; if (!m) return;
    const first = m.items.length ? m.items[0].id : 0;
    try {
      const j = await B.api("/channels/" + m.ch + "/posts/" + m.post.id + "/comments" + (older && first ? "?before=" + first : ""));
      await Promise.all(j.comments.map(B.hydrateComment));
      if (st.cm !== m) return;
      m.more = j.more; m.items = older ? j.comments.concat(m.items) : j.comments;
      const body = $("cmBody"), prevH = body.scrollHeight, prevT = body.scrollTop;
      renderComments();
      if (older) body.scrollTop = prevT + (body.scrollHeight - prevH);
    } catch (err) { fail(err); }
  }
  function renderComments() {
    const m = st.cm; if (!m) return;
    const h = B.h, body = $("cmBody"), me = B.me();
    body.textContent = "";
    const c = B.info(m.ch);
    body.append(h("div", {class: "cm-post"},
      h("b", {text: c ? c.nickname : "Kanal"}), h("div", {class: "cm-post-t", text: snippet(m.post)}), h("small", {text: B.hhmm(m.post.ts)})));
    if (m.more) body.append(h("button", {class: "btn ghost sm ch-more", type: "button", text: "Oldingi izohlar", onclick: () => loadComments(true)}));
    const list = h("div", {class: "cm-list", id: "cmList"});
    m.items.forEach(x => list.append(commentEl(x, me)));
    if (!m.items.length) list.append(h("div", {class: "ch-none sm", text: "Hali izoh yo'q. Birinchi bo'ling!"}));
    body.append(list);
    paintCount();
  }
  function paintCount() {
    const m = st.cm; if (!m) return;
    const n = m.post.comments != null ? m.post.comments : m.items.length;
    $("cmSub").textContent = n + " ta izoh";
  }
  function commentEl(c, me) {
    const h = B.h, own = me && c.user.id === me.id;
    const del = (own || admin()) ? h("button", {class: "icon-btn sm", type: "button", "aria-label": "O'chirish", onclick: () => delComment(c)}, B.icon("trash")) : null;
    const shown = c.locked ? "🔒 Izoh kaliti kutilmoqda…" : c.bad ? "⚠ Shifrni ochib bo'lmadi" : c.text;
    const lk = c.legacy ? null : h("span", {class: "lk" + (c.locked ? "" : (c.verified && !c.bad ? " ok" : " bad")), text: c.verified && !c.bad ? "🔒" : c.locked ? "🔒" : "⚠",
      title: c.verified && !c.bad ? "Uchdan-uchga shifrlangan, imzosi tasdiqlangan" : c.locked ? "Shifrlangan, kalit kutilmoqda" : "Imzo yoki shifrni tekshirib bo'lmadi!"});
    return h("div", {class: "cm-i", "data-id": String(c.id)}, B.avatar(c.user, "s"),
      h("div", {class: "cm-b"},
        h("div", {class: "cm-h"}, B.nameEl(c.user, {colored: true}), h("small", {}, lk, " ", B.hhmm(c.ts)), del),
        h("div", {class: "cm-t" + (c.locked || c.bad ? " dim" : ""), text: shown})));
  }
  async function sendComment() {
    const m = st.cm, inp = $("cmInp"), text = inp.value.trim(); if (!m || !text) return;
    inp.disabled = true; $("cmSend").disabled = true;
    try {
      const e2e = await B.sealComment(m.post.id, text);
      await B.api("/channels/" + m.ch + "/posts/" + m.post.id + "/comments", {method: "POST", body: {e2e}});
      inp.value = ""; inp.style.height = "auto";          // izoh WebSocket hodisasi bilan chiqadi (takrorlanmaydi)
    } catch (err) { fail(err); }
    inp.disabled = false; $("cmSend").disabled = false; inp.focus();
  }
  async function delComment(c) {
    const m = st.cm; if (!m) return;
    if (!await B.confirmDlg("Izoh o'chirilsinmi?", {title: "Izohni o'chirish", okText: "O'chirish", danger: true})) return;
    try { await B.api("/channels/" + m.ch + "/posts/" + m.post.id + "/comments/" + c.id, {method: "DELETE"}); } catch (err) { fail(err); }
  }
  function bindPanel() {
    const inp = $("cmInp");
    $("cmBack").addEventListener("click", () => closeComments(false));
    $("cmSend").addEventListener("click", sendComment);
    inp.addEventListener("input", () => { inp.style.height = "auto"; inp.style.height = Math.min(inp.scrollHeight, 120) + "px"; });
    inp.addEventListener("keydown", e => { if (e.key === "Enter" && !e.shiftKey && !matchMedia("(pointer: coarse)").matches && !e.isComposing) { e.preventDefault(); sendComment(); } });
  }

  /** Post o'chirildi (app.js xabar hodisasidan): ochiq izohlar paneli yopiladi. */
  function postGone(ch, id) {
    if (st.cm && st.cm.ch === ch && st.cm.post.id === id) { closeComments(false); B.toast("Post o'chirildi", "info"); }
  }

  /* ---------------- real vaqt hodisalari ---------------- */
  async function onEvent(m) {
    if (!B) return false;
    switch (m.type) {
      case "channels_changed": loadList(); return true;
      case "channel_views":
        Object.entries(m.views).forEach(([id, n]) => B.patchPost(m.ch, +id, {views: n}));
        return true;
      case "channel_comment": {
        B.patchPost(m.ch, m.post, {comments: m.count});
        const cm = st.cm;
        if (cm && cm.ch === m.ch && cm.post.id === m.post && !cm.items.some(i => i.id === m.comment.id)) {
          await B.hydrateComment(m.comment);
          if (st.cm !== cm || cm.items.some(i => i.id === m.comment.id)) return true;
          const body = $("cmBody"), stick = nearBottom(body), mine = B.me() && m.comment.user.id === B.me().id;
          cm.post.comments = m.count; cm.items.push(m.comment);
          const list = $("cmList"); list.querySelectorAll(".ch-none").forEach(e => e.remove());
          list.append(commentEl(m.comment, B.me())); paintCount();
          if (stick || mine) body.scrollTop = body.scrollHeight;
        }
        return true; }
      case "channel_comment_deleted": {
        B.patchPost(m.ch, m.post, {comments: m.count});
        const cm = st.cm;
        if (cm && cm.ch === m.ch && cm.post.id === m.post) {
          cm.items = cm.items.filter(i => i.id !== m.id); cm.post.comments = m.count;
          const el = $("cmList").querySelector('[data-id="' + m.id + '"]'); if (el) el.remove();
          paintCount();
        }
        return true; }
    }
    return false;
  }

  function reset() {
    closeComments(true);
    if (st.io) { st.io.disconnect(); st.io = null; st.ioBox = null; }
    clearTimeout(st.timer); st.timer = 0; st.sent.clear(); st.pend.clear(); st.seen = new WeakSet();
  }

  let bound = false;
  window.Channels = {
    init(bridge) { B = bridge; if (!bound) { bound = true; bindPanel(); } },
    loadList, reset, onEvent, track, info, menu, openComments, closeComments, postGone,
    create: () => formModal(null), join: joinModal,
    openById(id) { loadList().then(() => { if (B.info(id)) B.openChat({kind: "channel", id}); }); },
  };
})();
