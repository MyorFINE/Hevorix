"use strict";
/* =====================================================================
   Anonim Chat — boy matn: kod / Linux buyruqlari / .pcap / maxsus emoji
   ---------------------------------------------------------------------
   XAVFSIZLIK: bu modul hech qachon kodni ishga tushirmaydi. Hamma narsa
   matn sifatida o'qiladi va DOM'ga FAQAT textContent bilan chiqariladi
   (innerHTML, eval, Function, inline uslub/skript yo'q — qat'iy CSP bilan mos).
   Fayllar (.py, .sh, .pcap ...) faqat matn/baytlar sifatida tahlil qilinadi.
   ===================================================================== */
(function (root) {
  const R = {};
  const set = s => new Set(s.split(/\s+/).filter(Boolean));
  const esc = s => s.replace(/[.*+?^${}()|[\]\\\/]/g, "\\$&");

  /* ------------------------------------------------------------------
     1. Tillar: kalit so'zlar, ranglar, kengaytmalar
     ------------------------------------------------------------------ */
  const NUM = "0[xX][0-9a-fA-F_]+|0[bB][01_]+|\\d[\\d_]*\\.?\\d*(?:[eE][+-]?\\d+)?[uUlLfFdD]*";
  const OPS = "[+\\-*/%=<>!&|^~?]+";
  const CKW = "break case continue default do else for goto if return sizeof static struct switch typedef union volatile while enum extern const inline register restrict auto NULL true false";
  const CTYPES = "int char short long float double void unsigned signed size_t ssize_t uint8_t uint16_t uint32_t uint64_t int8_t int16_t int32_t int64_t bool FILE";
  const CBI = "printf scanf malloc free calloc realloc memcpy memset strlen strcpy strncpy strcmp strcat puts gets fgets fopen fclose fprintf sprintf snprintf exit main";

  const LANGS = {
    python: {name: "Python", color: "#3776ab", ext: "py pyw pyi", alias: "py python3 python2 py3", lc: ["#"], str: ['"""', "'''", '"', "'"], pyprefix: true, pascal: true, deco: true,
      kw: set("and as assert async await break class continue def del elif else except finally for from global if import in is lambda nonlocal not or pass raise return try while with yield True False None match case"),
      bi: set("print len range int str float list dict set tuple open input type isinstance enumerate zip map filter sum min max abs sorted reversed super self cls bool bytes Exception ValueError KeyError __name__ __init__ __main__ os sys re json")},
    c: {name: "C", color: "#5c6bc0", ext: "c h", alias: "", lc: ["//"], bc: ["/*", "*/"], str: ['"', "'"], pre: true,
      kw: set(CKW), types: set(CTYPES), bi: set(CBI)},
    cpp: {name: "C++", color: "#00599c", ext: "cpp cc cxx c++ hpp hh hxx ino", alias: "c++ cplusplus cxx", lc: ["//"], bc: ["/*", "*/"], str: ['"', "'"], pre: true, pascal: true,
      kw: set(CKW + " alignas catch class constexpr const_cast decltype delete dynamic_cast explicit export final friend mutable namespace new noexcept nullptr operator override private protected public reinterpret_cast static_assert static_cast template this throw try typeid typename using virtual and or not"),
      types: set(CTYPES + " string vector map unordered_map set list array unique_ptr shared_ptr wstring ostream istream auto"), bi: set(CBI + " std cout cin cerr endl")},
    javascript: {name: "JavaScript", color: "#f7df1e", ext: "js mjs cjs jsx", alias: "js node nodejs jsx", lc: ["//"], bc: ["/*", "*/"], str: ['"', "'", "`"], pascal: true, dollar: true,
      kw: set("break case catch class const continue debugger default delete do else export extends finally for function if import in instanceof let new return super switch this throw try typeof var void while with yield async await of static get set from as true false null undefined NaN Infinity"),
      bi: set("console window document Math JSON Object Array String Number Promise Map Set Date RegExp Error require module exports process Buffer setTimeout setInterval fetch alert eval")},
    typescript: {name: "TypeScript", color: "#3178c6", ext: "ts tsx", alias: "ts", lc: ["//"], bc: ["/*", "*/"], str: ['"', "'", "`"], pascal: true, dollar: true,
      kw: set("break case catch class const continue debugger default delete do else export extends finally for function if import in instanceof let new return super switch this throw try typeof var void while with yield async await of static get set from as true false null undefined interface type enum implements private public protected readonly namespace declare abstract keyof infer is"),
      types: set("any number string boolean unknown never object symbol bigint void"), bi: set("console window document Math JSON Object Array Promise Map Set Date Error require module process")},
    java: {name: "Java", color: "#e76f00", ext: "java", alias: "", lc: ["//"], bc: ["/*", "*/"], str: ['"', "'"], pascal: true, deco: true,
      kw: set("abstract assert break case catch class const continue default do else enum extends final finally for goto if implements import instanceof interface native new package private protected public return static strictfp super switch synchronized this throw throws transient try volatile while true false null var record"),
      types: set("int long short byte float double char boolean void String Integer Long Double List Map Set ArrayList HashMap Object"), bi: set("System out println print")},
    csharp: {name: "C#", color: "#68217a", ext: "cs", alias: "cs c# dotnet", lc: ["//"], bc: ["/*", "*/"], str: ['"', "'"], pascal: true, pre: true,
      kw: set("abstract as base break case catch checked class const continue default delegate do else enum event explicit extern false finally fixed for foreach goto if implicit in interface internal is lock namespace new null operator out override params private protected public readonly ref return sealed sizeof stackalloc static struct switch this throw true try typeof unchecked unsafe using virtual volatile while var async await get set"),
      types: set("bool byte char decimal double float int long object sbyte short string uint ulong ushort void"), bi: set("Console Math List Dictionary")},
    go: {name: "Go", color: "#00add8", ext: "go", alias: "golang", lc: ["//"], bc: ["/*", "*/"], str: ['"', "'", "`"], pascal: true,
      kw: set("break case chan const continue default defer else fallthrough for func go goto if import interface map package range return select struct switch type var true false nil iota"),
      types: set("int int8 int16 int32 int64 uint uint8 uint16 uint32 uint64 uintptr float32 float64 string bool byte rune error any"), bi: set("fmt Println Printf Sprintf len cap make new append copy delete panic recover close")},
    rust: {name: "Rust", color: "#dea584", ext: "rs", alias: "rs", lc: ["//"], bc: ["/*", "*/"], str: ['"'], pascal: true, attr: true, macro: true,
      kw: set("as async await break const continue crate dyn else enum extern false fn for if impl in let loop match mod move mut pub ref return self Self static struct super trait true type unsafe use where while"),
      types: set("i8 i16 i32 i64 i128 isize u8 u16 u32 u64 u128 usize f32 f64 bool char str String Vec Option Result Box Rc Arc"), bi: set("println print format vec panic assert Some None Ok Err")},
    php: {name: "PHP", color: "#777bb4", ext: "php phtml", alias: "", lc: ["//", "#"], bc: ["/*", "*/"], str: ['"', "'"], pascal: true, ci: true, phpvar: true,
      kw: set("abstract and array as break callable case catch class clone const continue declare default do echo else elseif empty extends final finally fn for foreach function global goto if implements include include_once instanceof interface isset list match namespace new or print private protected public readonly require require_once return static switch throw trait try unset use var while xor yield true false null"),
      bi: set("strlen count array_map array_filter explode implode str_replace preg_match json_encode json_decode var_dump print_r exit die")},
    sql: {name: "SQL", color: "#e38c00", ext: "sql", alias: "mysql postgres postgresql sqlite psql", lc: ["--"], bc: ["/*", "*/"], str: ["'", '"'], ci: true,
      kw: set("select from where insert into values update set delete create table drop alter add column index primary key foreign references join inner left right outer full on group by order having limit offset union all distinct as and or not null is in like between exists case when then else end asc desc default unique database use show describe truncate grant revoke begin commit rollback if"),
      types: set("int integer varchar char text date datetime timestamp boolean float double decimal bigint serial"), bi: set("count sum avg min max now coalesce")},
    html: {name: "HTML", color: "#e34c26", ext: "html htm xhtml xml svg vue", alias: "xml markup", noId: true, str: ['"', "'"],
      extra: [["c", "<!--[\\s\\S]*?(?:-->|$)"], ["p", "<![A-Za-z][^>]*>"], ["k", "<\\/?[A-Za-z][\\w:-]*"], ["k", "\\/?>"], ["t", "[A-Za-z_:@][\\w:.-]*(?=\\s*=)"], ["n", "&#?\\w+;"]]},
    css: {name: "CSS", color: "#264de4", ext: "css scss less", alias: "scss sass less", noId: true, bc: ["/*", "*/"], str: ['"', "'"],
      extra: [["k", "@[\\w-]+"], ["n", "#[0-9a-fA-F]{3,8}\\b"], ["n", "-?\\d*\\.?\\d+(?:px|em|rem|%|vh|vw|s|ms|deg|pt|fr)?"], ["t", "[\\w-]+(?=\\s*:)"], ["f", "[.#][\\w-]+"], ["p", "!important"]]},
    json: {name: "JSON", color: "#9aa0a6", ext: "json jsonl geojson", alias: "jsonc json5", str: ['"'], keyStr: true,
      kw: set("true false null")},
    bash: {name: "Bash", color: "#4eaa25", ext: "sh bash zsh fish ksh", alias: "sh shell zsh fish ksh console terminal kali linux cmd shellscript shell-session", lc: ["#"], str: ['"', "'"], shell: true,
      kw: set("if then else elif fi for while until do done case esac in function select time return exit break continue local export readonly declare unset source alias set shift trap eval exec"),
      bi: set("echo cd pwd ls cat grep sed awk find chmod chown mkdir rm cp mv sudo kill curl wget ssh tar head tail sort uniq xargs printf read test")},
    asm: {name: "Assembly", color: "#c678dd", ext: "asm s nasm masm inc", alias: "assembly nasm masm gas x86 x86_64 arm arm64 intel att", lc: [";", "//"], bc: ["/*", "*/"], str: ['"', "'"], ci: true, asm: true,
      kw: set("mov movzx movsx lea push pop pushad popad call ret retn jmp je jne jz jnz jg jge jl jle ja jae jb jbe js jns jc jnc loop add sub mul imul div idiv inc dec neg not and or xor shl shr sal sar rol ror cmp test nop int syscall sysenter leave enter xchg cdq cqo cbw cwd rep repe repne movs stos lods scas cmps setz setnz sete setne cmov cmove cmovne cmovg cmovl bswap hlt cli sti in out clc stc cld std ldr str ldrb strb ldp stp bl blr br b bx cbz cbnz svc mvn adds subs eor orr bic lsl lsr asr cmn tst adr adrp movk movz fld fst fadd addss addsd movss movaps movups pxor paddd"),
      types: set("byte word dword qword tbyte ptr short near far offset"),
      bi: set("section segment global globl extern db dw dd dq equ times bits default align resb resw resd resq org proc endp ends assume text data bss rodata")},
    lua: {name: "Lua", color: "#5b6bd6", ext: "lua", alias: "", lc: ["--"], bc: ["--[[", "]]"], str: ['"', "'"],
      kw: set("and break do else elseif end false for function goto if in local nil not or repeat return then true until while"), bi: set("print pairs ipairs require table string math os io tostring tonumber type")},
    ruby: {name: "Ruby", color: "#cc342d", ext: "rb", alias: "rb", lc: ["#"], str: ['"', "'"], pascal: true,
      kw: set("alias and begin break case class def defined do else elsif end ensure false for if in module next nil not or redo rescue retry return self super then true undef unless until when while yield"), bi: set("puts print require attr_accessor attr_reader lambda proc")},
    generic: {name: "Kod", color: "#8b949e", ext: "kt kts swift dart scala pl pm r m vb ps1 bat cmd ini toml yaml yml", alias: "text txt plaintext kotlin swift dart scala perl", lc: ["//", "#"], bc: ["/*", "*/"], str: ['"', "'"], pascal: true,
      kw: set("if else for while do return function fun func def class struct enum interface import package var val let const new null nil true false this self super try catch throw switch case break continue in is as public private protected static void int string bool")},
  };
  const KEYS = Object.keys(LANGS);
  const EXT = {}, ALIAS = {};
  for (const k of KEYS) {
    const L = LANGS[k];
    L.kw = L.kw || set(""); L.types = L.types || set(""); L.bi = L.bi || set("");
    L.key = k;
    ALIAS[k] = k; (L.alias || "").split(/\s+/).filter(Boolean).forEach(a => { ALIAS[a] = k; });
    L.ext.split(/\s+/).filter(Boolean).forEach(e => { if (!EXT[e]) EXT[e] = k; });
  }
  ALIAS.js = "javascript"; ALIAS.ts = "typescript"; ALIAS["c#"] = "csharp"; ALIAS["c++"] = "cpp"; EXT.h = EXT.h || "c";
  EXT.cmd = "generic"; EXT.bat = "generic"; EXT.ps1 = "generic";
  const PCAP_EXT = set("pcap pcapng cap dmp");
  const TERMLANG = set("bash sh shell zsh fish ksh console terminal kali linux shellscript shell-session");

  R.LANGS = LANGS;
  R.normalizeLang = x => ALIAS[String(x || "").toLowerCase().trim()] || null;
  R.extOf = name => { const m = /\.([A-Za-z0-9+#_-]{1,10})$/.exec(String(name || "")); return m ? m[1].toLowerCase() : ""; };
  R.fileKind = name => {
    const e = R.extOf(name);
    if (PCAP_EXT.has(e)) return {kind: "pcap", ext: e, label: e === "pcapng" ? "PCAPNG" : "PCAP", color: "#00e5ff"};
    const k = EXT[e];
    if (k) return {kind: "code", ext: e, lang: k, label: LANGS[k].name, color: LANGS[k].color};
    return null;
  };
  R.isTextual = bytes => {                                       // ikkilik (binar) fayl emasligini tekshiradi
    const n = Math.min(bytes.length, 8192);
    for (let i = 0; i < n; i++) if (bytes[i] === 0) return false;
    return true;
  };

  /* ------------------------------------------------------------------
     2. Sintaksis bo'yash (tokenizer): natija — [[sinf, matn], ...]
     ------------------------------------------------------------------ */
  function buildRules(L) {
    const rules = [], add = (cls, src, flags) => rules.push([cls, new RegExp(src, "y" + (flags || ""))]);
    add("", "[ \\t]+");
    if (L.asm) add("l", "^[ \\t]*[.A-Za-z_$@][\\w$@.]*:", "m");
    (L.extra || []).forEach(([c, s]) => { if (c === "c") add(c, s); });
    if (L.bc) add("c", esc(L.bc[0]) + "[\\s\\S]*?(?:" + esc(L.bc[1]) + "|$)");
    if (L.lc) add("c", "(?:" + L.lc.map(esc).join("|") + ")[^\\n]*");
    if (L.asm) add("c", "#\\s[^\\n]*");
    if (L.pre) add("p", "^[ \\t]*#\\s*\\w+[^\\n]*", "m");
    if (L.attr) add("p", "#!?\\[[^\\]\\n]*\\]");
    if (L.deco) add("p", "@[A-Za-z_][\\w.]*");
    if (L.pyprefix) add("s", "(?:[rRbBfFuU]{1,2})(?=[\"'])");
    if (L.keyStr) add("t", '"(?:\\\\.|[^"\\\\\\n])*"(?=\\s*:)');
    (L.str || []).forEach(q => {
      if (q.length === 3) add("s", esc(q) + "[\\s\\S]*?(?:" + esc(q) + "|$)");
      else if (q === "`") add("s", "`(?:\\\\[\\s\\S]|[^`\\\\])*(?:`|$)");
      else add("s", esc(q) + "(?:\\\\.|[^" + esc(q) + "\\\\\\n])*(?:" + esc(q) + "|$)");
    });
    (L.extra || []).forEach(([c, s]) => { if (c !== "c") add(c, s); });
    if (L.shell) { add("v", "\\$\\{?[A-Za-z_][\\w]*\\}?|\\$[0-9@#?!*$]"); add("t", "-{1,2}[A-Za-z][\\w-]*"); }
    if (L.phpvar) { add("v", "\\$[A-Za-z_]\\w*"); add("p", "<\\?php|<\\?=|\\?>"); }
    if (L.asm) add("n", "0[xX][0-9a-fA-F]+|[0-9][0-9a-fA-F]*[hH]\\b|\\$[0-9a-fA-F]+|#?-?\\d+");
    else if (!L.noId || L.extra) add("n", NUM);
    if (!L.noId) add("id", L.dollar ? "[A-Za-z_$][\\w$]*" : "[A-Za-z_]\\w*");
    if (!L.noId) add("o", OPS);
    add("", "[(){}\\[\\],.;:@]+");
    return rules;
  }
  const nextCh = (code, i) => { while (i < code.length && (code[i] === " " || code[i] === "\t")) i++; return code[i]; };
  const ASM_REG = /^(?:[re]?(?:ax|bx|cx|dx|si|di|sp|bp|ip)|[abcd][lh]|[sd]il|[sb]pl|r(?:[89]|1[0-5])[dwb]?|[xyz]mm\d+|[cdefgs]s|x(?:[12]?\d|30|zr)|w(?:[12]?\d|30|zr)|lr|pc|fp|eflags|cr[0-4])$/i;
  function classify(L, w, code, end) {
    const lw = L.ci ? w.toLowerCase() : w;
    if (L.asm && ASM_REG.test(w)) return "v";
    if (L.kw.has(lw)) return "k";
    if (L.types.has(lw)) return "t";
    if (L.bi.has(lw)) return "b";
    const nc = nextCh(code, end);
    if (L.macro && nc === "!") return "f";
    if (nc === "(") return "f";
    if (L.pascal && /^[A-Z][A-Za-z0-9]*[a-z]/.test(w)) return "t";
    return "";
  }
  const MAX_HL = 60000;
  function tokenize(code, langKey) {
    const L = LANGS[langKey] || LANGS.generic;
    const rules = L._rules || (L._rules = buildRules(L));
    const out = [], n = Math.min(code.length, MAX_HL);
    const push = (c, t) => { const last = out[out.length - 1]; if (last && last[0] === c) last[1] += t; else out.push([c, t]); };
    let i = 0;
    while (i < n) {
      let hit = false;
      for (let r = 0; r < rules.length; r++) {
        const re = rules[r][1]; re.lastIndex = i;
        const m = re.exec(code);
        if (m && m[0].length) {
          const cls = rules[r][0];
          push(cls === "id" ? classify(L, m[0], code, i + m[0].length) : cls, m[0]);
          i += m[0].length; hit = true; break;
        }
      }
      if (!hit) { push("", code[i]); i++; }
    }
    if (n < code.length) push("", code.slice(n));
    return out;
  }
  R.tokenize = tokenize;

  /* ------------------------------------------------------------------
     3. Tilni aniqlash (qo'yilgan matn kodmi?)
     ------------------------------------------------------------------ */
  const SIG = {
    python: [[/^\s*def\s+\w+\s*\(.*\)\s*(->\s*[\w\[\], .]+)?\s*:/m, 4], [/^\s*(import\s+[\w.]+|from\s+[\w.]+\s+import\s)/m, 3], [/^\s*class\s+\w+(\(.*\))?\s*:/m, 4],
      [/^\s*(if|elif|else|for|while|try|except|finally|with)\b[^\n]*:\s*$/m, 2], [/\bprint\s*\(/, 1], [/^\s*@\w+/m, 1], [/\bself\.\w+/, 2], [/if\s+__name__\s*==\s*["']__main__["']\s*:/, 5], [/\b(None|True|False)\b/, 1], [/\bf["'][^"'\n]*\{/, 2], [/^\s*(return|raise|pass)\b/m, 1]],
    cpp: [[/#include\s*[<"][\w./]+[>"]/, 5], [/\bstd::\w+/, 4], [/\b(cout|cin)\s*(<<|>>)/, 4], [/\busing\s+namespace\s+\w+/, 4], [/\btemplate\s*</, 4], [/\bclass\s+\w+\s*(:\s*(public|private)\s+\w+\s*)?\{/, 3], [/\bint\s+main\s*\(/, 4], [/\b(nullptr|constexpr|unique_ptr|shared_ptr)\b/, 3]],
    c: [[/#include\s*<(stdio|stdlib|string|unistd|stdint|sys\/[\w.]+|netinet\/[\w.]+|arpa\/[\w.]+)\.h>/, 6], [/#include\s*"[\w./]+\.h"/, 3], [/\bint\s+main\s*\(.*\)\s*\{?/, 4], [/\b(printf|scanf|malloc|free|memcpy|strcpy|fprintf)\s*\(/, 3], [/\b(unsigned\s+(char|int|long)|uint(8|16|32|64)_t|size_t)\b/, 2], [/\b(void|int|char|long)\s+\*?\w+\s*\([^)]*\)\s*\{/, 3], [/^\s*#define\s+\w+/m, 2], [/\bstruct\s+\w+\s*\{/, 3], [/\bNULL\b/, 1]],
    javascript: [[/\b(const|let|var)\s+[\w{}\[\], ]+\s*=/, 3], [/=>/, 2], [/\bfunction\s*\w*\s*\(/, 3], [/\bconsole\.\w+\(/, 4], [/\brequire\(["'][^"']+["']\)/, 4], [/\bimport\s+[\w{},* ]+\s+from\s+["']/, 4], [/\b(document|window)\.\w+/, 3], [/\b(await|async)\b/, 2], [/===|!==/, 2], [/\bexport\s+(default|const|function|class)\b/, 3], [/\bmodule\.exports\b/, 3]],
    typescript: [[/\binterface\s+\w+\s*\{/, 4], [/:\s*(string|number|boolean|any|unknown|void)\b/, 3], [/\btype\s+\w+\s*=/, 3], [/\bimplements\s+\w+/, 2], [/<\w+(\[\])?>\s*\(/, 1]],
    java: [[/\bpublic\s+(static\s+)?(final\s+)?(class|void|int|String)\b/, 4], [/System\.out\.print(ln)?\(/, 5], [/^\s*import\s+java\.[\w.*]+;/m, 5], [/\bpublic\s+static\s+void\s+main\s*\(/, 6], [/^\s*package\s+[\w.]+;/m, 3], [/@(Override|Autowired|Test)\b/, 3]],
    csharp: [[/^\s*using\s+System[\w.]*;/m, 5], [/\bConsole\.Write(Line)?\(/, 5], [/\bstatic\s+(void|int|async\s+Task)\s+Main\s*\(/, 5], [/\bnamespace\s+[\w.]+\s*(\{|;)/, 3], [/\b(string|int)\[\]\s+args\b/, 2]],
    go: [[/^\s*package\s+\w+\s*$/m, 5], [/\bfunc\s+(\(\w+\s+\*?\w+\)\s*)?\w+\s*\(/, 4], [/\w+\s*:=\s*/, 3], [/\bfmt\.(Print|Sprint|Fprint|Errorf)\w*\(/, 4], [/^\s*import\s+(\(|")/m, 3]],
    rust: [[/\bfn\s+\w+\s*(<[^>]*>)?\s*\(/, 4], [/\blet\s+(mut\s+)?\w+/, 3], [/\bprintln!\s*\(/, 5], [/\buse\s+std::[\w:{}, ]+;/, 5], [/\bimpl(\s*<[^>]*>)?\s+\w+/, 3], [/\bpub\s+(fn|struct|enum|mod)\b/, 3], [/->\s*(Result|Option|i32|u8|String)\b/, 2]],
    php: [[/<\?php/, 7], [/\$\w+\s*=\s*[^=]/, 2], [/\b(echo|require_once|include_once)\b/, 2], [/\$_(GET|POST|SERVER|REQUEST|COOKIE|FILES)\b/, 4], [/->\w+\(/, 1]],
    sql: [[/\bSELECT\b[\s\S]*?\bFROM\b/, 5], [/\bselect\s+(\*|[\w.,\s`"]+?)\s+from\s+[\w."`]+(\s+(where|join|group|order|limit)\b|\s*;)/i, 5], [/\bINSERT\s+INTO\b/i, 5], [/\bCREATE\s+(TABLE|DATABASE|INDEX)\b/i, 5], [/\bUPDATE\s+\w+\s+SET\b/i, 5], [/\bDELETE\s+FROM\b/i, 5], [/\bDROP\s+(TABLE|DATABASE)\b/i, 4], [/\bUNION\s+(ALL\s+)?SELECT\b/i, 5]],
    html: [[/<!DOCTYPE\s+html/i, 7], [/<\/?(div|span|html|head|body|script|a|p|ul|ol|li|form|input|button|h[1-6]|table|tr|td|img|style|link|meta|title|nav|section)\b[^>]*>/i, 3]],
    css: [[/(^|[}\s])[.#]?[A-Za-z][\w-]*(\s*[>+~,.:#][\w-]+)*\s*\{[^{}]*:[^{}]*;[^{}]*\}/, 5], [/@(media|import|keyframes|font-face)\b/, 3], [/\b(margin|padding|display|color|background|border|font-size|width|height)\s*:\s*[^;]+;/, 3]],
    bash: [[/^#!\s*\/(usr\/)?bin\/(env\s+)?(ba|z|da)?sh\b/, 9], [/^\s*if\s+\[\[?\s.*\]\]?\s*;?\s*then\b/m, 4], [/^\s*(fi|done|esac)\s*$/m, 3], [/^\s*for\s+\w+\s+in\s+.+;\s*do\b/m, 4], [/\$\{?\w+\}?/, 1], [/^\s*(export|source|alias)\s+\w+/m, 2]],
    asm: [[/^\s*(section|segment)\s+\.(text|data|bss|rodata)/mi, 6], [/^\s*(global|globl|\.globl|\.global)\s+[\w.]+/mi, 5], [/\b(_start|main)\s*:/, 3], [/^\s*\.(intel_syntax|att_syntax|text|data|bss|align|string|asciz|byte|quad|long)\b/m, 5], [/^\s*bits\s+(16|32|64)\b/mi, 5], [/\b(syscall|int\s+0x80|int\s+80h)\b/i, 4]],
    lua: [[/\blocal\s+\w+\s*=/, 3], [/^\s*function\s+[\w.:]+\s*\(.*\)\s*$/m, 4], [/\bend\s*$/m, 1], [/\bthen\s*$/m, 2], [/\bprint\s*\(/, 1], [/\bnil\b/, 1]],
    ruby: [[/^\s*def\s+\w+[!?]?(\(.*\))?\s*$/m, 4], [/^\s*end\s*$/m, 2], [/\bputs\s+/, 2], [/\|\w+(,\s*\w+)*\|/, 2], [/\battr_(accessor|reader|writer)\b/, 4], [/^\s*require\s+["']/m, 3]],
  };
  const ASM_LINE = /^\s*(mov|push|pop|call|jmp|je|jne|jz|jnz|add|sub|xor|cmp|lea|ret|int|syscall|nop|inc|dec|mul|div|imul|and|or|test|shl|shr|ldr|str|bl|svc|adr|ldp|stp|cbz|cbnz|eor|orr|movz|movk)\b[ \t]+[\w\[\].,$%@+\-*#:! ]+/gmi;
  R.guessLang = text => {
    const lines = text.split("\n").length;
    const sc = {};
    for (const k of Object.keys(SIG)) { let s = 0; for (const [re, w] of SIG[k]) if (re.test(text)) s += w; if (s) sc[k] = s; }
    const asmLines = (text.match(ASM_LINE) || []).length;
    if (asmLines >= 3) sc.asm = (sc.asm || 0) + 6 + Math.min(asmLines, 6);
    else if (asmLines && sc.asm) sc.asm += 2;
    if (lines >= 2 && /^\s*[\[{]/.test(text) && /[\]}]\s*$/.test(text)) { try { const j = JSON.parse(text); if (j && typeof j === "object") sc.json = 8 + Math.min(lines, 4); } catch (_) { /* JSON emas */ } }
    if (sc.cpp && sc.c) { if (/\bstd::|\bcout\b|\bclass\b|\btemplate\b|\bnamespace\b|<iostream>|<vector>|<string>/.test(text)) sc.c -= 3; else sc.cpp -= 3; }
    if (sc.typescript && sc.javascript) sc.typescript += 1;
    let best = null, bs = 0;
    for (const k in sc) if (sc[k] > bs) { bs = sc[k]; best = k; }
    if (best === "typescript" && !sc.javascript) bs -= 2;
    const need = lines >= 2 ? 5 : 6;
    return bs >= need ? {lang: best, score: bs} : null;
  };

  /* ------------------------------------------------------------------
     4. Linux / Kali buyruqlarini aniqlash
     ------------------------------------------------------------------ */
  const KALI = set("nmap msfconsole msfvenom msfdb sqlmap hydra john hashcat aircrack-ng airmon-ng airodump-ng aireplay-ng wifite reaver bettercap ettercap gobuster dirb dirbuster nikto wpscan burpsuite setoolkit searchsploit tshark wireshark tcpdump netcat nc ncat crackmapexec enum4linux smbclient smbmap responder impacket-smbserver mimikatz ffuf wfuzz masscan zmap theharvester recon-ng maltego autopsy binwalk foremost volatility steghide exiftool sherlock proxychains tor macchanger arpspoof dnsenum dnsrecon fierce whatweb nuclei metasploit evil-winrm chisel ligolo hping3 scapy medusa patator cewl crunch ophcrack radare2 r2 gdb objdump strings ltrace strace ghidra");
  const STRONG = set("sudo su apt apt-get apt-cache aptitude dpkg pacman yum dnf zypper systemctl service journalctl chmod chown chgrp ifconfig iwconfig iwlist ip iptables nft ufw nmcli iw rfkill ss netstat lsof lsblk fdisk mkfs mount umount useradd usermod passwd visudo crontab uname lsmod modprobe dmesg ln tar gzip gunzip unzip zip nohup screen tmux export source");
  const WEAK = set("ls cd pwd cat man top who id kill finger write tail head find sort make less more host echo date time touch cut join wait free yes test ping dig whois traceroute ssh scp rsync curl wget git python python3 pip pip3 npm node docker grep sed awk cp mv rm mkdir rmdir ps df du clear exit history env which whoami hostname uptime sleep xargs tee diff wc nano vim vi gcc g++ cargo go java php ruby perl base64 md5sum sha256sum openssl gpg nslookup");
  const UNIQUE = set("msfconsole ifconfig iwconfig setoolkit wifite airmon-ng airodump-ng whoami");
  const PROSE = set("is are was were am be been the a an and or but of to in on at for with this that these those it its i you he she we they my your our their bu va bilan ham yoki lekin uchun degan deb edi ekan emas bor yoq yo'q nima qanday qanaqa nega");
  const SUBCMD = /^(?:git\s+(?:clone|pull|push|commit|checkout|init|status|add|log|diff|branch|merge|rebase|remote|fetch|stash)\b|pip3?\s+(?:install|uninstall|list|freeze)\b|npm\s+(?:install|i|run|start|init|test)\b|docker\s+(?:run|ps|build|pull|exec|compose|images|stop|rm)\b|python3?\s+[\w./-]+\.py\b|ssh\s+\S+@\S+|(?:curl|wget)\s+(?:-\S+\s+)*\S+\.\S+)/;
  const EVIDENCE = /(^|\s)-{1,2}[A-Za-z0-9]|[|><]|\$[\w{(]|~\/|\s\/[\w.]|(^|\s)\.{1,2}\/|:\/\/|&&|;\s*\w|\s[\w.-]+\.\w{1,5}(\s|$)|\b\d{1,3}(\.\d{1,3}){3}\b/;
  const PROMPT = /^\s*(?:┌──\([^)]*\)-\[[^\]]*\]\s*|└─|[\w.-]+@[\w.-]+(?::[^\s#$%>]*)?\s*(?=[#$%>])|\(\w+\)\s*)*([#$%>])\s+(?=\S)/;
  const firstWord = s => { const m = /^[^\s]+/.exec(s); return m ? m[0] : ""; };

  function stripPrompt(line) {
    const m = PROMPT.exec(line);
    return m ? {text: line.slice(m[0].length), prompted: true, root: m[1] === "#", ch: m[1], host: m[0].includes("@")} : {text: line.trim(), prompted: false, root: false, ch: "", host: false};
  }
  function cmdScore(line) {                                 // 2 = aniq buyruq, 1 = ehtimol, 0 = buyruq emas
    const {text, prompted, ch, host} = stripPrompt(line);
    const t = text.trim();
    if (!t || t.length > 400) return 0;
    let words = t.split(/\s+/);
    if (words.length > 40) return 0;
    let first = words[0];
    if (/^[A-Za-z_][\w]*=\S*$/.test(first) && words.length > 1) { words = words.slice(1); first = words[0]; }       // VAR=val buyruq
    if (first === "sudo" && words.length > 1) { first = words[1]; if (first.startsWith("-")) first = (words.find((w, i) => i > 1 && !w.startsWith("-")) || first); }
    const lf = first.toLowerCase();
    const second = (words[1] || "").toLowerCase();
    const prose = PROSE.has(second) || (/[.!?]$/.test(t) && !EVIDENCE.test(t));
    const known = KALI.has(lf) || STRONG.has(lf) || WEAK.has(lf);
    if (prompted) {
      if (known) return 2;
      if ((host || ch === "$") && /^[A-Za-z_.\/~][\w.\/~-]*$/.test(first) && !prose && (EVIDENCE.test(t) || words.length === 1)) return 2;
      return 0;
    }
    if (/^(\.{1,2}|~)?\/[\w./-]+/.test(first) && !/^\/\w+\/?$/.test(first) ) return 2;                      // ./exploit, /usr/bin/x, ~/run.sh
    if (KALI.has(lf)) return (words.length >= 2 && !prose) || UNIQUE.has(lf) ? 2 : 0;
    if (STRONG.has(lf)) return words.length >= 2 && !prose ? 2 : 0;
    if (SUBCMD.test(words.join(" ")) && !prose) return 2;
    if (WEAK.has(lf)) return words.length >= 2 && !prose && EVIDENCE.test(t) ? 1 : 0;
    return 0;
  }
  R.cmdScore = cmdScore;
  const KALI_TOP = /^┌──\([^)]*\)-\[[^\]]*\]$/;              // Kali promptining birinchi qatori
  function looksLikeCommands(text) {
    const lines = text.split("\n").map(s => s.trim()).filter(s => s && !KALI_TOP.test(s));
    if (!lines.length || lines.length > 40) return false;
    let strong = 0, weak = 0;
    for (const l of lines) { const s = cmdScore(l); if (s === 2) strong++; else if (s === 1) weak++; }
    if (!strong) {
      if (lines.length === 1) { if (!(weak === 1 && /\s-{1,2}\w|\||>/.test(lines[0]))) return false; }
      else if (weak < 2) return false;
    }
    return (strong + weak) / lines.length >= 0.6;
  }
  R.looksLikeCommands = looksLikeCommands;

  function parseShell(text, user) {                       // [{k:"cmd"|"out"|"cmt"|"blank", t}]
    const out = [];
    let root = false, kali = false;
    for (const raw of text.replace(/\s+$/, "").split("\n")) {
      const line = raw.replace(/\r$/, "");
      if (!line.trim()) { out.push({k: "blank", t: ""}); continue; }
      if (KALI_TOP.test(line.trim())) continue;
      const s = stripPrompt(line);
      const sc = cmdScore(line);
      if (s.prompted && sc) { out.push({k: "cmd", t: s.text}); if (s.root) root = true; }
      else if (sc) out.push({k: "cmd", t: s.text});
      else if (/^\s*#/.test(line)) out.push({k: "cmt", t: line.trim()});
      else out.push({k: "out", t: line});
      const last = out[out.length - 1];
      if (last.k === "cmd") { const w = last.t.trim().split(/\s+/).map(x => x.toLowerCase()); if (w.some(x => KALI.has(x))) kali = true; }
    }
    return {lines: out, root, kali};
  }
  R.parseShell = parseShell;

  /* ------------------------------------------------------------------
     5. Xabarni qismlarga ajratish: matn / kod / terminal
     ------------------------------------------------------------------ */
  const FENCE = /```([^\n`]*)\n([\s\S]*?)(?:\n?```|$)/g;
  function classifyBlock(code, info) {
    let lang = R.normalizeLang((info || "").trim().split(/\s+/)[0]);
    if (!lang) { const g = R.guessLang(code); lang = g ? g.lang : null; if (!lang && looksLikeCommands(code)) lang = "bash"; }
    if (lang === "bash" || TERMLANG.has((info || "").trim().toLowerCase())) return {k: "term", code};
    return {k: "code", lang: lang || "generic", code, label: lang ? LANGS[lang].name : "Kod"};
  }
  const cache = new Map();
  R.parse = function (text) {
    if (typeof text !== "string" || !text) return [{k: "text", t: ""}];
    const hit = cache.get(text);
    if (hit) return hit;
    let parts = [];
    if (text.includes("```")) {
      let last = 0, m;
      FENCE.lastIndex = 0;
      while ((m = FENCE.exec(text))) {
        if (m.index > last) parts.push({k: "text", t: text.slice(last, m.index).replace(/^\n+|\n+$/g, "")});
        if (m[2].trim()) parts.push(classifyBlock(m[2].replace(/\n$/, ""), m[1]));
        last = m.index + m[0].length;
        if (m[0].length === 0) FENCE.lastIndex++;
      }
      if (last < text.length) parts.push({k: "text", t: text.slice(last).replace(/^\n+|\n+$/g, "")});
      parts = parts.filter(p => p.k !== "text" || p.t.trim());
      if (!parts.length) parts = [{k: "text", t: text}];
    } else {
      const body = text.replace(/\s+$/, "");
      if (body && looksLikeCommands(body)) parts = [{k: "term", code: body}];
      else if (body.includes("\n") || body.length > 25) {
        const g = R.guessLang(body);
        parts = g ? [{k: g.lang === "bash" ? "term" : "code", lang: g.lang, code: body, label: LANGS[g.lang].name}] : [{k: "text", t: text}];
      } else parts = [{k: "text", t: text}];
    }
    if (cache.size > 400) cache.clear();
    cache.set(text, parts);
    return parts;
  };
  R.hasRich = parts => parts.some(p => p.k !== "text");
  R.fenceFor = text => {                                  // yopishtirilgan matnni avtomatik ``` ichiga olish uchun
    const body = text.replace(/\s+$/, "");
    if (!body || body.includes("```")) return null;
    if (!(body.includes("\n") || body.length > 25)) return null;
    if (looksLikeCommands(body)) return {lang: "bash", label: "Linux buyruqlari", text: "```bash\n" + body + "\n```"};
    const g = R.guessLang(body);
    if (g) return {lang: g.lang, label: LANGS[g.lang].name, text: "```" + g.lang + "\n" + body + "\n```"};
    return null;
  };
  R.copyTextOf = part => {
    if (part.k === "term") { const c = parseShell(part.code).lines.filter(l => l.k === "cmd").map(l => l.t); return c.length ? c.join("\n") : part.code; }
    return part.code;
  };

  /* ------------------------------------------------------------------
     6. DOM yasash (faqat textContent)
     ------------------------------------------------------------------ */
  const SVGNS = "http://www.w3.org/2000/svg";
  const el = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
  const icon = name => { const s = document.createElementNS(SVGNS, "svg"); s.setAttribute("class", "ic"); const u = document.createElementNS(SVGNS, "use"); u.setAttribute("href", "#i-" + name); s.append(u); return s; };
  function copyBtn(getText, copyFn, label) {
    const b = el("button", "cbtn"); b.type = "button";
    b.setAttribute("aria-label", "Nusxalash");
    const t = el("span", null, label || "Nusxalash");
    b.append(icon("copy"), t);
    let tm = 0;
    b.addEventListener("click", async e => {
      e.stopPropagation(); e.preventDefault();
      const ok = await copyFn(getText());
      t.textContent = ok === false ? "Xato" : "Nusxalandi"; b.classList.add("done");
      clearTimeout(tm); tm = setTimeout(() => { t.textContent = label || "Nusxalash"; b.classList.remove("done"); }, 1600);
    });
    for (const ev of ["pointerdown", "touchstart", "mousedown"]) b.addEventListener(ev, e => e.stopPropagation(), {passive: true});
    return b;
  }
  const lineCount = s => (s.match(/\n/g) || []).length + 1;

  function codeLines(code, lang) {
    const body = el("div", "code-body");
    let line = el("div", "cl");
    const flush = () => { body.append(line); line = el("div", "cl"); };
    for (const [cls, text] of tokenize(code, lang)) {
      const chunks = text.split("\n");
      chunks.forEach((c, idx) => {
        if (idx > 0) flush();
        if (!c) return;
        if (cls) line.append(el("span", "tk-" + cls, c)); else line.append(document.createTextNode(c));
      });
    }
    body.append(line);
    return body;
  }
  /* kod bloki: sarlavha (til) + kod + pastda alohida kichik «Nusxalash» tugmasi */
  R.codeBlock = function (code, lang, ctx) {
    ctx = ctx || {};
    const L = LANGS[lang] || LANGS.generic;
    const wrap = el("div", "code-block"); wrap.dataset.lang = L.key;
    wrap.style.setProperty("--lc", L.color);
    const bar = el("div", "code-bar");
    bar.append(el("span", "code-dot"), el("span", "code-lang", ctx.label || L.name), el("span", "code-safe", "xavfsiz ko'rinish • ishga tushmaydi"));
    const scroll = el("div", "code-scroll");
    scroll.append(codeLines(code, lang));
    const foot = el("div", "cfoot");
    foot.append(el("span", "cfoot-i", lineCount(code) + " qator • " + code.length + " belgi"), copyBtn(() => code, ctx.copy || (async () => false)));
    wrap.append(bar, scroll, foot);
    return wrap;
  };

  /* terminal bloki (Kali/Linux): hacker uslubi + yozilish animatsiyasi */
  const SHELLTOK = /\s+|"(?:\\.|[^"\\])*"?|'[^']*'?|\$\{?\w+\}?|\|\||&&|[|;&]|>>?|<|[^\s|;&<>"']+/g;
  function shellSpans(t, parent) {
    let expect = true, n = 0, inCmt = false;
    const toks = t.match(SHELLTOK) || [];
    for (const w of toks) {
      let cls = "";
      if (/^\s+$/.test(w)) { parent.append(document.createTextNode(w)); continue; }
      if (inCmt || (w[0] === "#" && n > 0)) { cls = "cmt"; inCmt = true; }
      else if (w === "|" || w === "||" || w === "&&" || w === ";" || w === "&") { cls = "op"; expect = true; }
      else if (w === ">" || w === ">>" || w === "<") cls = "op";
      else if (w[0] === '"' || w[0] === "'") cls = "str";
      else if (w[0] === "$") cls = "var";
      else if (expect) { cls = w === "sudo" || w === "su" ? "sudo" : "cmd"; expect = w === "sudo" || /^[A-Za-z_]\w*=/.test(w); }
      else if (/^-{1,2}[A-Za-z0-9]/.test(w)) cls = "flag";
      else if (/^[a-z]+:\/\//i.test(w)) cls = "url";
      else if (/^\d{1,3}(\.\d{1,3}){3}(\/\d+)?(:\d+)?$/.test(w)) cls = "ip";
      else if (/^(~|\.{1,2})?\/[\w.\-/@%+=:,]*$/.test(w) || /^[\w.-]+\/[\w./-]+$/.test(w)) cls = "path";
      else if (/^\d+$/.test(w)) cls = "num";
      parent.append(cls ? el("span", "tc-" + cls, w) : document.createTextNode(w));
      n++;
    }
  }
  /* lines: [{k:'cmd'|'out'|'cmt'|'blank', t, cls?}] */
  R.terminal = function (lines, o) {
    o = o || {};
    const user = String(o.user || "user").replace(/[^\w.-]/g, "").slice(0, 20) || "user";
    const host = o.host || "kali";
    const root = !!o.root;
    const wrap = el("div", "term" + (o.fx ? " fx" : "") + (o.kali ? " kali" : ""));
    const bar = el("div", "term-bar");
    const dots = el("span", "term-dots"); dots.append(el("i"), el("i"), el("i"));
    bar.append(dots, el("span", "term-title", (root ? "root" : user) + "@" + host + ": ~"), el("span", "term-tag", o.tag || (o.kali ? "KALI" : "LINUX")));
    bar.title = "Animatsiyani qayta ko'rish";
    const body = el("div", "term-body");
    const scan = el("div", "term-scan"); scan.setAttribute("aria-hidden", "true");
    let idx = 0, delay = 0.15, cmdSeen = false;
    const mk = (cls) => { const d = el("div", "tl " + cls); d.style.setProperty("--d", delay.toFixed(2) + "s"); return d; };
    for (const l of lines) {
      if (l.k === "blank") { body.append(el("div", "tl blank", "\u00a0")); continue; }
      if (l.k === "cmd") {
        const top = el("div", "tl tp", "┌──(" + (root ? "root" : user) + "㉿" + host + ")-[~]");
        top.style.setProperty("--d", delay.toFixed(2) + "s"); delay += 0.05;
        const d = mk("tcmd");
        const dur = Math.min(2.2, Math.max(0.35, l.t.length * 0.03));
        d.style.setProperty("--dur", dur.toFixed(2) + "s");
        d.append(el("span", "pr", "└─" + (root ? "# " : "$ ")));
        const code = el("span", "tc"); shellSpans(l.t, code); d.append(code);
        delay = Math.min(delay + dur + 0.15, 3); cmdSeen = true;
        body.append(top, d);
      } else {
        const d = mk((l.k === "cmt" ? "tcm" : "tout") + (l.cls ? " " + l.cls : ""));
        d.style.setProperty("--dur", "0.25s");
        d.append(el("span", "to", l.t || "\u00a0"));
        delay = Math.min(delay + 0.08, 3);
        body.append(d);
      }
      idx++;
    }
    if (!cmdSeen && !lines.length) body.append(el("div", "tl tout", "\u00a0"));
    const kids = body.children; if (kids.length) kids[kids.length - 1].classList.add("last");
    bar.addEventListener("click", e => { e.stopPropagation(); wrap.classList.remove("fx"); void wrap.offsetWidth; wrap.classList.add("fx"); });
    const scroll = el("div", "term-scroll"); scroll.append(body);
    const foot = el("div", "cfoot");
    const nc = lines.filter(l => l.k === "cmd").length;
    foot.append(el("span", "cfoot-i", o.info || (nc ? nc + " ta buyruq • faqat ko'rsatiladi, bajarilmaydi" : "faqat ko'rsatiladi, bajarilmaydi")),
      copyBtn(() => (o.copyText != null ? o.copyText : lines.filter(l => l.k === "cmd").map(l => l.t).join("\n")), o.copy || (async () => false)));
    wrap.append(bar, scroll, scan, foot);
    return wrap;
  };
  R.shellPart = function (part, o) {
    const p = parseShell(part.code, o && o.user);
    const lines = p.lines.some(l => l.k === "cmd") ? p.lines : p.lines.map(l => l.k === "out" ? {k: "cmd", t: l.t} : l);
    return R.terminal(lines, Object.assign({}, o, {root: p.root, kali: p.kali, host: p.kali ? "kali" : "linux", copyText: R.copyTextOf(part)}));
  };
  R.render = function (part, o) {
    if (part.k === "term") return R.shellPart(part, o);
    if (part.k === "code") return R.codeBlock(part.code, part.lang, Object.assign({label: part.label}, o));
    return null;
  };

  /* ------------------------------------------------------------------
     7. .pcap / .pcapng — faqat o'qiladi (Wireshark/tcpdump uslubida)
     ------------------------------------------------------------------ */
  const LINK = {0: "NULL", 1: "Ethernet", 101: "Raw IP", 105: "IEEE 802.11", 113: "Linux cooked (SLL)", 127: "802.11 + radiotap", 228: "Raw IPv4", 229: "Raw IPv6", 276: "Linux cooked v2"};
  const SERVICE = {20: "FTP-DATA", 21: "FTP", 22: "SSH", 23: "TELNET", 25: "SMTP", 53: "DNS", 67: "DHCP", 68: "DHCP", 80: "HTTP", 110: "POP3", 123: "NTP", 137: "NBNS", 143: "IMAP", 161: "SNMP", 443: "TLS", 445: "SMB", 993: "IMAPS", 1900: "SSDP", 3306: "MySQL", 3389: "RDP", 5353: "mDNS", 8080: "HTTP", 8443: "TLS"};
  const hex2 = n => n.toString(16).padStart(2, "0");
  const ip4 = (b, o) => b[o] + "." + b[o + 1] + "." + b[o + 2] + "." + b[o + 3];
  const mac = (b, o) => Array.from(b.subarray(o, o + 6), hex2).join(":");
  function ip6(b, o) {
    const g = []; for (let i = 0; i < 8; i++) g.push(((b[o + i * 2] << 8) | b[o + i * 2 + 1]).toString(16));
    let bs = -1, bl = 0;
    for (let i = 0; i < 8;) { if (g[i] === "0") { let j = i; while (j < 8 && g[j] === "0") j++; if (j - i > bl) { bs = i; bl = j - i; } i = j; } else i++; }
    if (bl < 2) return g.join(":");
    return g.slice(0, bs).join(":") + "::" + g.slice(bs + bl).join(":");
  }
  function tcpFlags(f) { let s = ""; if (f & 1) s += "F"; if (f & 2) s += "S"; if (f & 4) s += "R"; if (f & 8) s += "P"; if (f & 32) s += "U"; if (f & 16) s += "."; return s || "none"; }
  function l4(b, o, proto, seg, src, dst) {                 // seg — L4 segment uzunligi (IP sarlavhasisiz)
    if (proto === 6 && b.length >= o + 20) {
      const sp = (b[o] << 8) | b[o + 1], dp = (b[o + 2] << 8) | b[o + 3], fl = b[o + 13], hl = (b[o + 12] >> 4) * 4;
      const len = Math.max(0, seg - hl);
      return {proto: SERVICE[dp] || SERVICE[sp] || "TCP", text: src + ":" + sp + " → " + dst + ":" + dp + "  [" + tcpFlags(fl) + "]  len " + len};
    }
    if (proto === 17 && b.length >= o + 8) {
      const sp = (b[o] << 8) | b[o + 1], dp = (b[o + 2] << 8) | b[o + 3], ul = (b[o + 4] << 8) | b[o + 5];
      return {proto: SERVICE[dp] || SERVICE[sp] || "UDP", text: src + ":" + sp + " → " + dst + ":" + dp + "  UDP  len " + Math.max(0, ul - 8)};
    }
    if (proto === 1 && b.length >= o + 2) {
      const t = b[o], names = {0: "echo reply", 3: "unreachable", 8: "echo request", 11: "ttl exceeded"};
      return {proto: "ICMP", text: src + " → " + dst + "  ICMP " + (names[t] || "type " + t)};
    }
    if (proto === 58 && b.length >= o + 2) return {proto: "ICMPv6", text: src + " → " + dst + "  ICMPv6 type " + b[o]};
    return {proto: "IP", text: src + " → " + dst + "  proto " + proto};
  }
  function decodeNet(b, o, et) {
    if (et === 0x8100 && b.length >= o + 4) { et = (b[o + 2] << 8) | b[o + 3]; o += 4; }
    if (et === 0x0800 && b.length >= o + 20) {
      const ihl = (b[o] & 15) * 4, total = (b[o + 2] << 8) | b[o + 3], proto = b[o + 9];
      const src = ip4(b, o + 12), dst = ip4(b, o + 16);
      if (((b[o + 6] & 0x1f) << 8 | b[o + 7]) !== 0) return {proto: "IPv4", text: src + " → " + dst + "  fragment"};
      return l4(b, o + ihl, proto, total - ihl, src, dst);
    }
    if (et === 0x86dd && b.length >= o + 40) {
      const nh = b[o + 6], src = ip6(b, o + 8), dst = ip6(b, o + 24), pl = (b[o + 4] << 8) | b[o + 5];
      if ([0, 43, 44, 60].includes(nh)) return {proto: "IPv6", text: src + " → " + dst + "  ext header " + nh};
      return l4(b, o + 40, nh, pl, src, dst);
    }
    if (et === 0x0806 && b.length >= o + 28) {
      const op = (b[o + 6] << 8) | b[o + 7];
      return {proto: "ARP", text: op === 1 ? "who has " + ip4(b, o + 24) + "? tell " + ip4(b, o + 14) : ip4(b, o + 14) + " is at " + mac(b, o + 8)};
    }
    return {proto: "L2", text: "ethertype 0x" + (et & 0xffff).toString(16).padStart(4, "0")};
  }
  function decodePacket(b, lt) {
    try {
      if (lt === 1 && b.length >= 14) return decodeNet(b, 14, (b[12] << 8) | b[13]);
      if (lt === 113 && b.length >= 16) return decodeNet(b, 16, (b[14] << 8) | b[15]);
      if (lt === 276 && b.length >= 20) return decodeNet(b, 20, (b[0] << 8) | b[1]);
      if ((lt === 101 || lt === 228 || lt === 229) && b.length >= 20) return decodeNet(b, 0, (b[0] >> 4) === 6 ? 0x86dd : 0x0800);
      if (lt === 0 && b.length >= 24) return decodeNet(b, 4, b[0] === 2 || b[3] === 2 ? 0x0800 : 0x86dd);
    } catch (_) { /* buzilgan paket */ }
    return {proto: "?", text: "(" + (LINK[lt] || "link " + lt) + ", " + b.length + " bayt)"};
  }
  const pad = (n, w) => String(n).padStart(w, "0");
  const clock = ts => { const d = new Date(Math.floor(ts * 1000)); return pad(d.getUTCHours(), 2) + ":" + pad(d.getUTCMinutes(), 2) + ":" + pad(d.getUTCSeconds(), 2) + "." + pad(Math.floor((ts % 1) * 1e6), 6); };
  const MAX_DECODE = 20000, SHOW = 200;
  R.parsePcap = function (input) {
    const u8 = input instanceof Uint8Array ? input : new Uint8Array(input);
    if (u8.length < 24) throw new Error("Fayl juda qisqa");
    const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
    const info = {format: "", linktype: 0, snaplen: 0, version: "", count: 0, bytes: 0, first: 0, last: 0, truncated: false, stats: {}, packets: []};
    const add = (ts, caplen, origlen, data, lt) => {
      info.count++; info.bytes += origlen;
      if (!info.first || ts < info.first) info.first = ts;
      if (ts > info.last) info.last = ts;
      if (info.count <= MAX_DECODE) {
        const d = decodePacket(data, lt);
        info.stats[d.proto] = (info.stats[d.proto] || 0) + 1;
        if (info.packets.length < SHOW) info.packets.push({n: info.count, ts, len: origlen, proto: d.proto, text: d.text});
      }
    };
    const magic = dv.getUint32(0, false);
    const classic = {0xa1b2c3d4: [false, 1e6], 0xd4c3b2a1: [true, 1e6], 0xa1b23c4d: [false, 1e9], 0x4d3cb2a1: [true, 1e9]}[magic];
    if (classic) {
      const [le, res] = classic;
      info.format = "pcap"; info.version = dv.getUint16(4, le) + "." + dv.getUint16(6, le);
      info.snaplen = dv.getUint32(16, le); info.linktype = dv.getUint32(20, le) & 0xffff;
      let o = 24;
      while (o + 16 <= u8.length) {
        const sec = dv.getUint32(o, le), frac = dv.getUint32(o + 4, le), cap = dv.getUint32(o + 8, le), orig = dv.getUint32(o + 12, le);
        if (cap > 0x4000000 || o + 16 + cap > u8.length) { info.truncated = true; break; }
        add(sec + frac / res, cap, orig, u8.subarray(o + 16, o + 16 + cap), info.linktype);
        o += 16 + cap;
      }
    } else if (magic === 0x0a0d0d0a) {
      info.format = "pcapng";
      const bom = dv.getUint32(8, true), le = bom === 0x1a2b3c4d;
      if (!le && bom !== 0x4d3c2b1a) throw new Error("pcapng bayt tartibi noma'lum");
      info.version = dv.getUint16(12, le) + "." + dv.getUint16(14, le);
      const ifs = [];
      let o = 0;
      while (o + 12 <= u8.length) {
        const type = dv.getUint32(o, le), len = dv.getUint32(o + 4, le);
        if (len < 12 || o + len > u8.length) { info.truncated = true; break; }
        if (type === 1) {
          const f = {lt: dv.getUint16(o + 8, le), snap: dv.getUint32(o + 12, le), res: 1e6};
          let p = o + 16;
          while (p + 4 <= o + len - 4) {
            const code = dv.getUint16(p, le), l = dv.getUint16(p + 2, le);
            if (code === 0) break;
            if (code === 9 && l >= 1) { const v = u8[p + 4]; f.res = v & 0x80 ? Math.pow(2, v & 0x7f) : Math.pow(10, v); }
            p += 4 + ((l + 3) & ~3);
          }
          ifs.push(f);
          if (ifs.length === 1) { info.linktype = f.lt; info.snaplen = f.snap; }
        } else if (type === 6 && len >= 32) {
          const f = ifs[dv.getUint32(o + 8, le)] || ifs[0] || {lt: 1, res: 1e6};
          const ts = (dv.getUint32(o + 12, le) * 4294967296 + dv.getUint32(o + 16, le)) / f.res;
          const cap = dv.getUint32(o + 20, le), orig = dv.getUint32(o + 24, le);
          if (o + 28 + cap <= o + len) add(ts, cap, orig, u8.subarray(o + 28, o + 28 + cap), f.lt);
        } else if (type === 3) {
          const f = ifs[0] || {lt: 1}, orig = dv.getUint32(o + 8, le), cap = Math.min(orig, len - 16);
          add(0, cap, orig, u8.subarray(o + 12, o + 12 + cap), f.lt);
        }
        o += (len + 3) & ~3;
      }
    } else throw new Error("Bu pcap/pcapng formati emas");
    info.linkName = LINK[info.linktype] || "link " + info.linktype;
    info.duration = info.count ? info.last - info.first : 0;
    return info;
  };
  R.pcapLines = function (info, name) {
    const L = [];
    L.push({k: "cmd", t: "tcpdump -nn -r " + (String(name || "capture.pcap").replace(/[^\w.\-]/g, "_"))});
    const top = Object.entries(info.stats).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([k, v]) => k + "=" + v).join("  ");
    L.push({k: "out", t: "reading from file, format " + info.format + " " + info.version + ", link-type " + info.linkName + " (" + info.linktype + ")", cls: "tinfo"});
    L.push({k: "out", t: "paketlar: " + info.count + (info.truncated ? " (fayl kesilgan)" : "") + "   hajm: " + info.bytes + " bayt   davomiyligi: " + info.duration.toFixed(3) + " s", cls: "tinfo"});
    if (top) L.push({k: "out", t: "protokollar: " + top, cls: "tinfo"});
    L.push({k: "blank", t: ""});
    for (const p of info.packets) L.push({k: "out", t: pad(p.n, 4) + "  " + clock(p.ts) + "  " + p.proto.padEnd(7) + " " + p.text, cls: "pk-" + (/^(TCP|HTTP|TLS|SSH|SMB|FTP|TELNET|RDP|SMTP|IMAP|POP3|MySQL)/.test(p.proto) ? "tcp" : /^(UDP|DNS|DHCP|NTP|mDNS|SSDP|NBNS|SNMP)/.test(p.proto) ? "udp" : /ICMP/.test(p.proto) ? "icmp" : p.proto === "ARP" ? "arp" : "oth")});
    if (info.count > info.packets.length) L.push({k: "out", t: "… yana " + (info.count - info.packets.length) + " ta paket (ko'rsatilmadi)", cls: "tinfo"});
    return L;
  };
  R.pcapText = (info, name) => R.pcapLines(info, name).map(l => l.t).join("\n");

  /* ------------------------------------------------------------------
     8. Maxsus emoji nishonlar (:kali: :linux: :anon: :ghost: ...)
     ------------------------------------------------------------------ */
  const BUILTIN = [
    [":kali:", {url: "/static/emoji/kali.svg", label: "Kali Linux"}], [":linux:", {url: "/static/emoji/linux.svg", label: "Linux (Tux)"}],
    [":anon:", {url: "/static/emoji/anon.svg", label: "Anonymous niqobi"}], [":ghost:", {url: "/static/emoji/ghost.svg", label: "Ghost (Simon Riley)"}],
  ];
  const EMOJI = new Map(BUILTIN);
  const EMOJI_TOKEN = /^:[a-z0-9_]{2,14}:$/;
  const EMOJI_URL = /^\/(?:static\/emoji\/[a-z0-9_]{2,14}|emoji-files\/[0-9a-f]{20})\.(?:svg|png|webp)$/;     // faqat o'z serverimizdagi rasm yo'llari
  const EMOJI_ANIMS = new Set(["pulse", "bounce", "spin", "shake", "float", "glow", "flip", "wave", "rainbow"]);
  R.isEmojiToken = t => typeof t === "string" && EMOJI_TOKEN.test(t);
  /* list: server katalogi [{token, url | file, label, anim}]. replace=true: eski (o'chirilgan) emojilar ham yo'qoladi */
  R.setEmojis = (list, replace) => {
    if (replace) { EMOJI.clear(); for (const [t, v] of BUILTIN) EMOJI.set(t, v); }
    for (const e of list || []) {
      if (!e || !R.isEmojiToken(e.token)) continue;
      const url = e.url || (/^[a-z0-9_]{2,14}\.(svg|png|webp)$/.test(e.file || "") ? "/static/emoji/" + e.file : "");
      if (!EMOJI_URL.test(url)) continue;
      EMOJI.set(e.token, {url, label: e.label || e.token, anim: EMOJI_ANIMS.has(e.anim) ? e.anim : ""});
    }
  };
  R.emojiList = () => Array.from(EMOJI, ([token, v]) => ({token, url: v.url, file: v.url.split("/").pop(), label: v.label, anim: v.anim || ""}));
  R.emojiEl = (token, cls, title) => {
    const info = EMOJI.get(token) || {url: "/static/emoji/" + token.slice(1, -1) + ".svg", label: token};
    const img = document.createElement("img");
    img.className = cls; img.src = info.url; img.alt = info.label; img.title = title || info.label;
    img.draggable = false; img.decoding = "async"; img.width = 20; img.height = 20;
    img.addEventListener("error", () => { const s = document.createElement("span"); s.className = cls; s.textContent = "◈"; img.replaceWith(s); }, {once: true});
    return img;
  };

  /* ------------------------------------------------------------------
     9. Xabar matni ichidagi emojilar: «salom :kulgi_1:» -> matn + rasm.
        Faqat ro'yxatda BOR emoji nomlari almashtiriladi (oddiy ":soat:" kabi matnlar o'z holicha qoladi).
        Xabar faqat 1–3 ta emojidan iborat bo'lsa, ular katta chiqadi. Hammasi DOM orqali (innerHTML yo'q).
     ------------------------------------------------------------------ */
  const TOKEN_G = /:[a-z0-9_]{2,14}:/g;
  R.emojiMatches = text => {
    const out = [];
    if (typeof text !== "string" || text.indexOf(":") < 0 || !EMOJI.size) return out;
    TOKEN_G.lastIndex = 0;
    let m;
    while ((m = TOKEN_G.exec(text))) {
      if (EMOJI.has(m[0])) out.push({i: m.index, t: m[0]});
      else TOKEN_G.lastIndex = m.index + 1;                  // ":a:b_c:" kabi holatda ikkinchi ":" dan qayta qidiriladi
    }
    return out;
  };
  R.hasInlineEmoji = text => R.emojiMatches(text).length > 0;
  R.chatEmoji = (token, big) => {
    const info = EMOJI.get(token);
    const img = document.createElement("img");
    img.className = "ce" + (big ? " big" : "") + (info.anim ? " a-" + info.anim : "");
    img.src = info.url; img.alt = token; img.title = info.label; img.draggable = false; img.decoding = "async";
    img.addEventListener("error", () => img.replaceWith(document.createTextNode(token)), {once: true});
    return img;
  };
  R.inline = text => {
    const frag = document.createDocumentFragment();
    const ms = R.emojiMatches(text);
    if (!ms.length) { frag.append(document.createTextNode(text)); return frag; }
    let rest = text;
    for (let k = ms.length - 1; k >= 0; k--) rest = rest.slice(0, ms[k].i) + rest.slice(ms[k].i + ms[k].t.length);
    const big = ms.length <= 3 && rest.trim() === "";
    let last = 0;
    for (const m of ms) {
      if (m.i > last) frag.append(document.createTextNode(text.slice(last, m.i)));
      frag.append(R.chatEmoji(m.t, big));
      last = m.i + m.t.length;
    }
    if (last < text.length) frag.append(document.createTextNode(text.slice(last)));
    return frag;
  };

  if (typeof module !== "undefined" && module.exports) module.exports = R; else root.Rich = R;
})(typeof window !== "undefined" ? window : globalThis);
