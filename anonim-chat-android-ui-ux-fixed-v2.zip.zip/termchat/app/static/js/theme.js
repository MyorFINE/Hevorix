"use strict";
// Mavzuni sahifa chizilishidan oldin o'rnatadi (miltillashning oldini oladi) va brauzer/status-bar rangini moslaydi.
(() => {
  let t = null;
  try { t = localStorage.getItem("termchat_theme"); } catch (_) {}
  if (t !== "dark" && t !== "light") t = matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  document.documentElement.dataset.theme = t;
  const m = document.querySelector('meta[name="theme-color"]');
  if (m) m.setAttribute("content", t === "dark" ? "#17212b" : "#ffffff");
  // Zaif/arzon telefonlar (kam RAM, <=4 yadro) yoki "Data saver": bezak (cheksiz) animatsiyalar o'chadi — asosiy o'tishlar qoladi.
  try {
    const c = navigator.connection, lowMem = (navigator.deviceMemory || 4) <= 2, lowCpu = (navigator.hardwareConcurrency || 8) <= 4;
    if (lowMem || lowCpu || (c && c.saveData)) document.documentElement.classList.add("lite");
  } catch (_) {}
})();
