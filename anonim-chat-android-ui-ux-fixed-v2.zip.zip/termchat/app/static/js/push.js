/* Bildirishnomalar (Web Push): brauzer butunlay yopiq bo'lsa ham umumiy chat va lichka xabarlari haqida xabar beradi.
   Server push ichida xabar matnini ko'rmaydi/yubormaydi (E2EE) — faqat "kim yozdi" va "qayerga". */
(() => {
  "use strict";
  const LS = "ac_push";                 // "on" | "off" — shu qurilmadagi tanlov
  const LS_ASK = "ac_push_ask";         // oxirgi marta so'ralgan vaqt
  const ASK_EVERY = 3 * 24 * 3600 * 1000;
  const ua = navigator.userAgent || "";
  const isIOS = /iPad|iPhone|iPod/.test(ua) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
  const standalone = () => matchMedia("(display-mode: standalone)").matches || navigator.standalone === true;
  const supported = "serviceWorker" in navigator && "PushManager" in window && "Notification" in window;
  const get = k => { try { return localStorage.getItem(k); } catch (_) { return null; } };
  const set = (k, v) => { try { localStorage.setItem(k, v); } catch (_) {} };

  const b64d = s => { const p = "=".repeat((4 - s.length % 4) % 4); const r = atob((s + p).replace(/-/g, "+").replace(/_/g, "/")); return Uint8Array.from(r, c => c.charCodeAt(0)); };
  const b64e = buf => btoa(String.fromCharCode(...new Uint8Array(buf))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  const sameKey = (a, b) => { if (!a || a.byteLength !== b.length) return false; const x = new Uint8Array(a); return b.every((v, i) => v === x[i]); };

  async function registration() {
    const reg = await Promise.race([navigator.serviceWorker.ready, new Promise(r => setTimeout(() => r(null), 8000))]);
    return reg;
  }

  /** iPhone'da bildirishnoma faqat bosh ekranga o'rnatilgan ilovada ishlaydi (iOS 16.4+). */
  function needsInstall() { return isIOS && !standalone(); }

  function state() {
    if (!supported) return {ok: false, why: needsInstall() ? "ios-install" : "unsupported", permission: "denied", on: false};
    if (needsInstall()) return {ok: false, why: "ios-install", permission: Notification.permission, on: false};
    return {ok: true, why: "", permission: Notification.permission, on: Notification.permission === "granted" && get(LS) !== "off"};
  }

  async function subscribe(api) {
    const reg = await registration();
    if (!reg) throw new Error("Xizmat tayyor emas, birozdan so'ng qayta urinib ko'ring");
    const {key} = await api("/push/key");
    const appKey = b64d(key);
    let sub = await reg.pushManager.getSubscription();
    if (sub && !sameKey(sub.options && sub.options.applicationServerKey, appKey)) { try { await sub.unsubscribe(); } catch (_) {} sub = null; }   // server kaliti almashgan
    if (!sub) sub = await reg.pushManager.subscribe({userVisibleOnly: true, applicationServerKey: appKey});
    const j = sub.toJSON();
    await api("/push/subscribe", {method: "POST", body: {endpoint: j.endpoint, p256dh: j.keys.p256dh, auth: j.keys.auth}});
    return sub;
  }

  /** Kirgandan keyin: ruxsat berilgan bo'lsa, obuna serverda borligiga ishonch hosil qiladi (jimgina). */
  async function sync(api) {
    const s = state();
    if (!s.ok || !s.on) return s;
    try { await subscribe(api); } catch (_) {}
    return state();
  }

  /** Foydalanuvchi bosganda: ruxsat so'raydi va obuna bo'ladi. */
  async function enable(api) {
    const s = state();
    if (!s.ok) throw new Error(s.why === "ios-install" ? "iPhone'da avval ilovani bosh ekranga o'rnating (Ulashish → Bosh ekranga qo'shish)" : "Bu brauzer bildirishnomalarni qo'llab-quvvatlamaydi");
    let perm = Notification.permission;
    if (perm === "default") perm = await Notification.requestPermission();
    if (perm !== "granted") { set(LS_ASK, String(Date.now())); throw new Error(perm === "denied" ? "Bildirishnomalar brauzer sozlamalarida bloklangan. Sayt sozlamalaridan ruxsat bering" : "Ruxsat berilmadi"); }
    await subscribe(api);
    set(LS, "on");
    return state();
  }

  /** Qurilmada o'chirish (menyudan): serverdan ham, brauzerdan ham olib tashlanadi. */
  async function disable(api) {
    set(LS, "off");
    await dropSub(api);
    return state();
  }

  async function dropSub(api) {
    try {
      const reg = await registration(); const sub = reg && await reg.pushManager.getSubscription();
      if (sub) { try { await api("/push/unsubscribe", {method: "POST", body: {endpoint: sub.endpoint}}); } catch (_) {} try { await sub.unsubscribe(); } catch (_) {} }
    } catch (_) {}
  }

  /** "Chiqish" bosilganda: bu qurilma shu akkaunt bildirishnomalarini olmasin (tanlov saqlanadi). */
  async function onLogout(api) { await dropSub(api); }

  function shouldAsk() {
    const s = state();
    if (!s.ok || s.permission !== "default" || get(LS) === "off") return false;
    const t = Number(get(LS_ASK) || 0);
    return !t || Date.now() - t > ASK_EVERY;
  }
  const markAsked = () => set(LS_ASK, String(Date.now()));

  /** Sahifa yashirin, lekin push hali yetib kelmagan qisqa oraliq: bildirishnomani shu yerning o'zida ko'rsatamiz. */
  async function local(d) {
    const s = state();
    if (!s.ok || s.permission !== "granted" || get(LS) === "off") return;
    const reg = await registration();
    if (reg && reg.active) reg.active.postMessage({type: "local-notify", d});
  }

  // Bildirishnoma bosilganda ochiq oynaga chatni ochish buyrug'i keladi
  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.addEventListener("message", e => {
      const m = e.data;
      if (m && m.type === "open-chat") window.dispatchEvent(new CustomEvent("ac-open-chat", {detail: {k: m.k, u: m.u}}));
    });
  }

  window.Push = {supported, state, sync, enable, disable, onLogout, shouldAsk, markAsked, local, needsInstall};
})();
