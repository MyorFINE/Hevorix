"""Maxsus (rasmli) emoji nishonlar: Kali Linux, Linux, Anonymous niqobi, Ghost va h.k.

Qanday ishlaydi:
  * Har bir maxsus emoji — `app/static/emoji/<nom>.svg` fayli. Nom: kichik harf, raqam va `_` (2–14 belgi).
  * Nishon bazada `:nom:` ko'rinishida saqlanadi (masalan `:kali:`) va mijozda rasm sifatida chiqadi.
  * YANGI emoji qo'shish: SVG (yoki PNG) faylni shu papkaga tashlang — server qayta ishga tushganda (yoki ~10 s ichida)
    ro'yxatga avtomatik kiradi. Kodni o'zgartirish shart emas. Chiroyli nom uchun `LABELS` ga qator qo'shing.
  * Faqat admin/ega nishon bera oladi (oddiy foydalanuvchi o'ziga bera olmaydi) — `badges.set_for` tekshiradi.
Xavfsizlik: rasm faqat <img> orqali yuklanadi (SVG ichidagi skript ishlamaydi), CSP o'zgarmagan, nomlar qat'iy regex bilan tekshiriladi.
"""
from __future__ import annotations

import re
import time

from app.config import ROOT

EMOJI_DIR = ROOT / "app" / "static" / "emoji"
NAME = re.compile(r"^[a-z0-9_]{2,32}$")
TOKEN = re.compile(r"^:([a-z0-9_]{2,32}):$")
EXTS = (".svg", ".png", ".webp")
MAX_FILE_BYTES = 256 * 1024
_TTL = 10.0

LABELS = {
    "kali": "Kali Linux",
    "linux": "Linux (Tux)",
    "anon": "Anonymous niqobi",
    "ghost": "Ghost (Simon Riley)",
}
_cache: tuple[float, dict[str, str]] = (0.0, {})


def _custom() -> dict[str, str]:
    """Admin / ruxsat berilganlar yaratgan emojilar (bazadan): {nom: fayl_nomi}."""
    try:
        from app.repositories import emojis as repo
        return {r["name"]: r["file"] for r in repo.all_emojis()}
    except Exception:                                   # baza hali tayyor emas (import tartibi) — faqat tayyor emojilar
        return {}


def _scan() -> dict[str, str]:
    found: dict[str, str] = {}
    if EMOJI_DIR.is_dir():
        for p in sorted(EMOJI_DIR.iterdir()):
            if p.suffix.lower() in EXTS and p.is_file() and NAME.match(p.stem) and p.stat().st_size <= MAX_FILE_BYTES:
                found.setdefault(p.stem, p.name)
    return found


def builtin() -> dict[str, str]:
    """static/emoji/ papkasidagi tayyor emojilar {nom: fayl} — papka har ~10 soniyada qayta o'qiladi."""
    global _cache
    now = time.monotonic()
    if now - _cache[0] > _TTL:
        _cache = (now, _scan())
    return _cache[1]


def available() -> dict[str, str]:
    """Hamma emoji nomlari {nom: fayl}: tayyorlari + bazadagi maxsuslari (maxsus tayyorini bosib o'tmaydi)."""
    return {**_custom(), **builtin()}


def listing() -> list[dict]:
    """Tayyor emojilar (rasmlari /static/emoji/ da). Maxsuslar app.services.emoji.catalog() orqali beriladi."""
    return [{"name": n, "token": f":{n}:", "file": f, "url": f"/static/emoji/{f}", "label": LABELS.get(n, n.replace("_", " ").title()),
             "builtin": True} for n, f in builtin().items()]


def is_token(value: str) -> bool:
    m = TOKEN.match(value or "")
    return bool(m) and m.group(1) in available()


def reset_cache() -> None:
    global _cache
    _cache = (0.0, {})
