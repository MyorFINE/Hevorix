"""Anonim Chat by Hevorix."""
__version__ = "3.4.0"
