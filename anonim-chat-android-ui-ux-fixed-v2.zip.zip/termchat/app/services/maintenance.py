"""Davriy tozalash: qoldiq vaqtinchalik fayllar, biriktirilmagan shifrlangan fayllar, muddati o'tgan sessiyalar.

Ishga tushganda bir marta, keyin har `INTERVAL` soniyada fon vazifasi sifatida bajariladi. Foydalanuvchi ma'lumotlari
(xabarlar, biriktirilgan fayllar, akkauntlar) hech qachon bu yerda o'chirilmaydi.
"""
from __future__ import annotations

import asyncio
import logging
import time

from app.config import settings

log = logging.getLogger("termchat.maintenance")

INTERVAL = 30 * 60
TMP_MAX_AGE = 3600            # shundan eski *.tmp fayllar (yozish chala qolgan) o'chiriladi
BLOB_MAX_AGE = 3600           # yuklangan, lekin hech bir xabarga biriktirilmagan shifrlangan fayllar


def sweep_tmp(max_age: float = TMP_MAX_AGE) -> int:
    """Yozish paytida uzilib qolgan vaqtinchalik fayllarni o'chiradi."""
    n, now = 0, time.time()
    for d in (settings.media_dir, settings.avatars_dir, settings.emoji_dir):
        try:
            entries = list(d.glob("*.tmp"))
        except OSError:
            continue
        for p in entries:
            try:
                if p.is_file() and now - p.stat().st_mtime > max_age:
                    p.unlink()
                    n += 1
            except OSError:
                pass
    return n


def sweep_blobs(max_age: float = BLOB_MAX_AGE) -> int:
    """Biriktirilmagan shifrlangan fayllarni diskdan va bazadan olib tashlaydi."""
    from app.repositories import e2ee as e2ee_repo
    from app.services import media
    n = 0
    for r in e2ee_repo.stale_blobs(time.time() - max_age):
        media.remove(r["name"])
        e2ee_repo.drop_blob(r["name"])
        n += 1
    return n


def auto_backup(hours: int | None = None, keep: int | None = None, directory=None) -> str | None:
    """Oxirgi nusxadan `hours` soat o'tgan bo'lsa, bazaning (fayllarsiz) tekshirilgan nusxasini `data/backups/` ga yozadi va faqat
    eng so'nggi `keep` tasini qoldiradi. Foydalanuvchi ma'lumotlari bilan bir xil papkada (0600) turadi; maxfiy kalitlar kirmaydi.
    Yozilgan fayl nomini yoki None (hali vaqti kelmagan / o'chiq) qaytaradi."""
    import tempfile
    from pathlib import Path
    from app import datasnap
    from app.db import db
    hours = settings.auto_backup_hours if hours is None else hours
    keep = max(1, settings.auto_backup_keep if keep is None else keep)
    if hours <= 0:
        return None
    d = Path(directory) if directory else settings.backups_dir
    d.mkdir(parents=True, exist_ok=True)
    existing = sorted(d.glob("auto-*.tar.gz"))
    if existing and time.time() - existing[-1].stat().st_mtime < hours * 3600:
        return None
    name = d / time.strftime("auto-%Y%m%d-%H%M%S.tar.gz")
    with tempfile.TemporaryDirectory(prefix="live-", dir=str(d)) as tmp:
        live = Path(tmp) / "chat.db"
        db.snapshot(live)
        datasnap.create(settings.data_dir, name, include_files=False, db_file=live)
    datasnap.verify(name)                              # yozilgan nusxa darhol tekshiriladi: buzuq nusxa eskisini siqib chiqarmasin
    for old in sorted(d.glob("auto-*.tar.gz"))[:-keep]:
        old.unlink(missing_ok=True)
    log.info("Avtomatik zaxira: %s", name.name)
    return name.name


def shrink_avatars(limit: int = 20) -> int:
    """Eski, katta (2560 px gacha) profil rasmlarini joyida 512 px ga kichraytiradi (fayl nomi o'zgarmaydi; metadata ham tozalanadi).
    Katta rasmni dekodlash profil/ro'yxat ochilganda kadrlarni tushirib yuborardi. Har safar ko'pi bilan `limit` ta."""
    from app.services import imgclean
    from app.services.avatars import AVATAR_SIDE
    n = 0
    for p in settings.avatars_dir.iterdir():
        if n >= limit:
            break
        if not p.is_file() or p.suffix.lower() not in (".jpg", ".png", ".webp", ".gif"):
            continue
        try:
            raw = p.read_bytes()
            from PIL import Image
            from io import BytesIO
            with Image.open(BytesIO(raw)) as im:
                if max(im.size) <= AVATAR_SIDE:
                    continue
            img = imgclean.clean(raw, AVATAR_SIDE)
            if img.ext != p.suffix.lower().lstrip("."):
                continue
            tmp = p.with_name(p.name + ".tmp")
            tmp.write_bytes(img.data)
            tmp.replace(p)
            n += 1
        except Exception:
            log.warning("Avatar kichraytirilmadi: %s", p.name)
    return n


def run_once() -> dict:
    from app.services import auth
    out = {"tmp": sweep_tmp(), "blobs": sweep_blobs(), "sessions": auth.purge_idle_sessions(), "avatars": shrink_avatars()}
    try:
        out["backup"] = auto_backup()
    except Exception:
        log.exception("Avtomatik zaxira xatosi")
    if any(out.values()):
        log.info("Tozalash: %s", out)
    return out


async def loop() -> None:
    while True:
        try:
            await asyncio.to_thread(run_once)
        except Exception:
            log.exception("Davriy tozalash xatosi")
        await asyncio.sleep(INTERVAL)
