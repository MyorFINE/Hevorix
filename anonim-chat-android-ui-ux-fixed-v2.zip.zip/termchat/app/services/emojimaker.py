"""Rasmdan emoji yasash: qayta kodlash (metadata o'chadi), kichraytirish, kerak bo'lsa orqa fonni olib tashlash.

Qoidalar:
  * PNG (yoki shaffoflikli WEBP/GIF) — shaffof joylari SAQLANADI, orqa fon yo'q bo'lib qoladi (hech narsa o'chirilmaydi).
  * JPG yoki shaffofligi yo'q rasm — "orqa fonni olib tashlash" yoqilgan bo'lsa fon o'chiriladi, aks holda rasm shundayligicha qoladi.
  * Animatsiyali GIF/WEBP — animatsiya saqlanadi (kadrlar kichraytiriladi, WEBP ga o'giriladi).
  * Telegram stikeri (.tgs = gzip bilan siqilgan Lottie) — serverda kadrlarga chizilib, animatsiyali WEBP ga o'giriladi
    (brauzer CSP skript yuklashga ruxsat bermaydi, shuning uchun o'girish serverda; `rlottie-python` kerak).
  * Oddiy rasmga animatsiya (pulse, bounce, ...) CSS orqali beriladi — fayl o'zgarmaydi (animatsiyani mijoz chizadi).

Orqa fonni olib tashlash tashqi xizmat yoki neyron tarmoqsiz ishlaydi: rasm chetidagi rang fon deb olinadi va
chetdan boshlab unga yaqin rangli ulangan piksellar shaffof qilinadi. Bir xil (oq, yashil ekran, to'q) fonda yaxshi ishlaydi;
murakkab fotofon uchun emas — bunday rasmda fon aniqlanmaydi va aniq xabar qaytadi.
"""
from __future__ import annotations

import gzip
import json
import math
from collections import deque
from dataclasses import dataclass
from io import BytesIO

from app.errors import ChatError

try:
    from PIL import Image, ImageFilter, ImageOps, ImageSequence
except ImportError:                                   # pragma: no cover
    Image = None

try:
    from rlottie_python import LottieAnimation        # .tgs ni kadrlarga chizadi
except Exception:                                     # pragma: no cover — o'rnatilmagan bo'lsa .tgs rad etiladi, qolgan fayllar ishlayveradi
    LottieAnimation = None

ANIMS = ("pulse", "bounce", "spin", "shake", "float", "glow", "flip", "wave", "rainbow")
MAX_RAW = 5 * 1024 * 1024
MAX_PIXELS = 25_000_000
STATIC_SIDE = 256
ANIM_SIDE = 160
MAX_FRAMES = 60
MAX_OUT = 256 * 1024
MAX_TGS_JSON = 8 * 1024 * 1024        # .tgs ochilgandan keyingi Lottie JSON chegarasi (gzip-bomba himoyasi)
TGS_MAX_FPS = 30
TOL_DEFAULT = 30
_FMT = ("PNG", "JPEG", "WEBP", "GIF")
BAD = "Rasm buzilgan yoki qo'llab-quvvatlanmaydi (PNG, JPG, WEBP yoki GIF kerak)"


@dataclass
class Made:
    data: bytes
    ext: str
    animated: bool
    width: int
    height: int
    transparent: bool          # natijada shaffof joylar bor
    bg_removed: bool           # orqa fon aynan shu jarayonda olib tashlandi
    source_alpha: bool         # asl rasmning o'zida shaffoflik bor edi


def _need_pillow() -> None:
    if Image is None:
        raise ChatError("Serverda rasmlarni qayta ishlash moduli (Pillow) o'rnatilmagan", 500)


def _has_alpha(im) -> bool:
    """Rasmda HAQIQIY shaffof piksellar bormi (faqat rejimga qarab emas)."""
    if im.mode in ("RGBA", "LA"):
        return im.getchannel("A").getextrema()[0] < 250
    if im.mode == "P" and "transparency" in im.info:
        return im.convert("RGBA").getchannel("A").getextrema()[0] < 250
    return False


def _open(raw: bytes):
    _need_pillow()
    if not raw or len(raw) > MAX_RAW:
        raise ChatError(f"Rasm {MAX_RAW // (1024 * 1024)} MB dan oshmasligi kerak")
    Image.MAX_IMAGE_PIXELS = MAX_PIXELS
    try:
        im = Image.open(BytesIO(raw))
        if im.format not in _FMT:
            raise ChatError(BAD)
        if im.width < 1 or im.height < 1 or im.width * im.height > MAX_PIXELS:
            raise ChatError("Rasm o'lchami juda katta")
        im.load() if not getattr(im, "is_animated", False) else None
        return im
    except ChatError:
        raise
    except Exception:
        raise ChatError(BAD)


def _fit(im, side: int):
    if max(im.size) > side:
        im = im.copy()
        im.thumbnail((side, side), Image.LANCZOS)
    return im


def _trim(im):
    """Shaffof chetlarni qirqadi (emoji kvadratda to'liq ko'rinsin)."""
    box = im.getchannel("A").point(lambda a: 255 if a > 8 else 0).getbbox()
    return im.crop(box) if box else im


# ------------------------------------------------------------------------------------------ orqa fonni olib tashlash
def remove_background(im, tolerance: int = TOL_DEFAULT):
    """RGBA rasm qaytaradi: chetdan ulangan fon rangi shaffof. (rasm, olib tashlangan ulush)."""
    w, h = im.size
    rgb = im.convert("RGB").tobytes()
    thr2 = (max(1, min(100, int(tolerance))) * 2.2) ** 2

    def at(x, y):
        i = (y * w + x) * 3
        return rgb[i], rgb[i + 1], rgb[i + 2]

    border = [(x, 0) for x in range(w)] + [(x, h - 1) for x in range(w)] + [(0, y) for y in range(1, h - 1)] + [(w - 1, y) for y in range(1, h - 1)]
    cols = [at(x, y) for x, y in border]
    ref = tuple(sorted(c[k] for c in cols)[len(cols) // 2] for k in range(3))        # chet piksellarining medianasi = fon rangi

    def near(c) -> bool:
        return (c[0] - ref[0]) ** 2 + (c[1] - ref[1]) ** 2 + (c[2] - ref[2]) ** 2 <= thr2

    seeds = [p for p, c in zip(border, cols) if near(c)]
    if len(seeds) < max(4, len(border) // 8):
        raise ChatError("Orqa fonni aniqlab bo'lmadi: rasm chetlari bir xil rangda emas. Fon bir xil bo'lgan rasm tanlang yoki shaffof PNG yuklang")
    seen = bytearray(w * h)
    q = deque()
    for x, y in seeds:
        if not seen[y * w + x]:
            seen[y * w + x] = 1
            q.append((x, y))
    while q:
        x, y = q.popleft()
        for nx, ny in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
            if 0 <= nx < w and 0 <= ny < h and not seen[ny * w + nx] and near(at(nx, ny)):
                seen[ny * w + nx] = 1
                q.append((nx, ny))
    removed = sum(seen) / (w * h)
    if removed > 0.97:
        raise ChatError("Rasmning deyarli hammasi fon deb topildi. Fon sezgirligini kamaytirib ko'ring")
    mask = Image.frombytes("L", (w, h), bytes(0 if v else 255 for v in seen))
    mask = mask.filter(ImageFilter.MinFilter(3)).filter(ImageFilter.GaussianBlur(0.7))   # chetdagi fon "hoshiyasi" yo'qoladi, chiziq yumshoq
    out = im.convert("RGBA")
    old = out.getchannel("A")
    out.putalpha(Image.composite(mask, Image.new("L", (w, h), 0), old.point(lambda a: 255 if a else 0)))
    return out, removed


# ------------------------------------------------------------------------------------------ asosiy funksiya
def _png(im) -> bytes:
    out = BytesIO()
    im.save(out, "PNG", optimize=True)
    return out.getvalue()


def _static(im, remove_bg: bool, tolerance: int) -> Made:
    from PIL import ImageOps
    im = ImageOps.exif_transpose(im)
    src_alpha = _has_alpha(im)
    rgba = im.convert("RGBA")
    rgba = _fit(rgba, 640 if (remove_bg and not src_alpha) else STATIC_SIDE)         # fonni aniqroq ajratish uchun biroz kattaroqda ishlanadi
    bg_removed = False
    if remove_bg and not src_alpha:
        rgba, _ = remove_background(rgba, tolerance)
        bg_removed = True
    transparent = src_alpha or bg_removed
    if transparent:
        rgba = _trim(rgba)
    rgba = _fit(rgba, STATIC_SIDE)
    side = STATIC_SIDE
    data = _png(rgba)
    while len(data) > MAX_OUT and side > 48:                       # juda og'ir bo'lsa kichraytiriladi
        side = int(side * 0.8)
        rgba = _fit(rgba, side)
        data = _png(rgba)
    if len(data) > MAX_OUT:
        raise ChatError("Emoji fayli juda og'ir chiqdi, soddaroq rasm tanlang")
    return Made(data, "png", False, rgba.width, rgba.height, transparent, bg_removed, src_alpha)


def _encode_frames(frames, durs) -> Made:
    """RGBA kadrlar -> animatsiyali WEBP (hajm MAX_OUT dan oshmaguncha kichraytiriladi)."""
    side = ANIM_SIDE
    while True:
        small = [_fit(f, side) for f in frames]
        out = BytesIO()
        small[0].save(out, "WEBP", save_all=True, append_images=small[1:], duration=durs, loop=0, quality=80, method=4)
        data = out.getvalue()
        if len(data) <= MAX_OUT or side <= 64:
            break
        side = int(side * 0.75)
    if len(data) > MAX_OUT:
        raise ChatError("Animatsiya juda og'ir, kadrlari kamroq yoki kichikroq fayl tanlang")
    return Made(data, "webp", True, small[0].width, small[0].height, True, False, True)


def _animated(im) -> Made:
    n = getattr(im, "n_frames", 1)
    if n > MAX_FRAMES:
        raise ChatError(f"Animatsiya juda uzun (eng ko'pi bilan {MAX_FRAMES} kadr)")
    frames, durs = [], []
    for f in ImageSequence.Iterator(im):
        durs.append(max(20, int(f.info.get("duration", im.info.get("duration", 80)) or 80)))
        frames.append(f.convert("RGBA"))
    return _encode_frames(frames, durs)


# ------------------------------------------------------------------------------------------ Telegram .tgs
def is_tgs(raw: bytes) -> bool:
    return raw[:2] == b"\x1f\x8b"


def make_tgs(raw: bytes) -> Made:
    """Telegram stikeri (.tgs) -> animatsiyali WEBP. Kadrlar ko'p bo'lsa, tekis oraliqda kamaytiriladi (tezlik saqlanadi)."""
    _need_pillow()
    if LottieAnimation is None:
        raise ChatError(".tgs ni o'girish moduli o'rnatilmagan (serverda: pip install rlottie-python)", 500)
    if not raw or len(raw) > MAX_RAW:
        raise ChatError(f"Fayl {MAX_RAW // (1024 * 1024)} MB dan oshmasligi kerak")
    try:
        with gzip.GzipFile(fileobj=BytesIO(raw)) as z:
            text = z.read(MAX_TGS_JSON + 1)
    except Exception:
        raise ChatError("TGS fayl buzilgan (gzip emas)")
    if len(text) > MAX_TGS_JSON:
        raise ChatError("TGS fayl juda katta (ochilgach 8 MB dan oshdi)")
    try:
        doc = json.loads(text)
        if not isinstance(doc, dict) or not isinstance(doc.get("layers"), list):
            raise ValueError
    except Exception:
        raise ChatError("TGS ichida Lottie animatsiya topilmadi")
    try:
        anim = LottieAnimation.from_data(text.decode("utf-8"))
        total = int(anim.lottie_animation_get_totalframe())
        fps = float(anim.lottie_animation_get_framerate()) or 30.0
        if total < 1:
            raise ValueError
        step = max(1, math.ceil(total / MAX_FRAMES), math.ceil(fps / TGS_MAX_FPS))
        dur = max(20, int(round(1000.0 * step / fps)))
        frames = [anim.render_pillow_frame(i, ANIM_SIDE, ANIM_SIDE).convert("RGBA") for i in range(0, total, step)]
    except ChatError:
        raise
    except Exception:
        raise ChatError("TGS animatsiyani chizib bo'lmadi")
    if not frames:
        raise ChatError("TGS animatsiyada kadr yo'q")
    return _encode_frames(frames, [dur] * len(frames))


def make(raw: bytes, remove_bg: bool = False, tolerance: int = TOL_DEFAULT) -> Made:
    im = _open(raw)
    if getattr(im, "is_animated", False) and getattr(im, "n_frames", 1) > 1:
        return _animated(im)
    return _static(im, remove_bg, tolerance)
