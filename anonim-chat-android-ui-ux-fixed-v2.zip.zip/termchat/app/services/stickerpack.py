"""Tayyor .zip dan sticker (emoji) to'plami yaratish — FAQAT adminlar.

ZIP ichida .gif (animatsiyali), .png (va .webp, .jpg) fayllar bo'ladi. Har bir fayl alohida emoji bo'ladi,
hammasi bitta yangi to'plamga (pack) qo'shiladi; to'plam nomini admin kiritadi.

  * .gif  -> animatsiyali WEBP (kadrlar ko'p bo'lsa kamaytiriladi), .png/.webp/.jpg -> qayta kodlangan PNG (metadata o'chadi)
Emoji nomi fayl nomidan olinadi (`kulgi.gif` -> `:kulgi:`); nom yaroqsiz yoki band bo'lsa `<to'plam>_<tartib>` beriladi.
Xavfsizlik: fayllar diskka ochilmaydi (yo'l hujumi yo'q), har bir yozuv hajmi o'qishda cheklanadi (zip-bomba), parolli/yashirin/
begona fayllar o'tkazib yuboriladi va sababi qaytariladi. Biror fayl yaroqsiz bo'lsa, qolganlari baribir qo'shiladi.
"""
from __future__ import annotations

import concurrent.futures as cf
import multiprocessing as mp
import re
import secrets
import threading
import time
import zipfile
from concurrent.futures.process import BrokenProcessPool
from io import BytesIO
from pathlib import PurePosixPath

from app import emojis
from app.config import settings
from app.errors import ChatError
from app.repositories import emojis as repo
from app.services import emoji as svc, emojimaker

MAX_ZIP = 50 * 1024 * 1024               # yuklanadigan .zip hajmi
MAX_FILES = 500                          # bitta to'plamga ko'pi bilan
MAX_UNPACKED = 250 * 1024 * 1024         # hamma yaroqli fayllarning ochilgan jami hajmi
EXTS = (".png", ".gif", ".webp", ".jpg", ".jpeg")

# Fayllarni o'girish ALOHIDA jarayonda bajariladi: Pillow/xotira muammosida (masalan, buzuq yoki juda og'ir GIF),
# faqat o'sha jarayon o'ladi — chat serveri (va undagi ulanishlar) ishlayveradi. Testlarda ISOLATE=False.
ISOLATE = True
JOB_TIMEOUT = 40                          # bitta fayl uchun soniya
_pool: cf.ProcessPoolExecutor | None = None
_plock = threading.Lock()
_import_lock = threading.Lock()           # bir vaqtda bitta ZIP (xotira va CPU ni tejaydi)


def _get_pool() -> cf.ProcessPoolExecutor:
    global _pool
    with _plock:
        if _pool is None:
            _pool = cf.ProcessPoolExecutor(max_workers=1, mp_context=mp.get_context("spawn"))
        return _pool


def _drop_pool() -> None:
    global _pool
    with _plock:
        p, _pool = _pool, None
    if p is not None:
        for pr in list(getattr(p, "_processes", {}).values()):
            try:
                pr.kill()
            except Exception:
                pass
        p.shutdown(wait=False, cancel_futures=True)


def _natural(s: str):
    return [int(t) if t.isdigit() else t for t in re.split(r"(\d+)", s.lower())]


def wrap_single(raw: bytes, filename: str) -> bytes:
    """Zip emas, yakka .gif/.png/.webp/.jpg yuborilsa — bitta fayllik zip qilib beradi (to'plamda 1 ta sticker bo'ladi)."""
    if raw[:2] == b"PK":
        return raw
    ext = PurePosixPath((filename or "").replace("\\", "/")).suffix.lower()
    if ext not in EXTS:
        ext = ".png" if raw[:8] == b"\x89PNG\r\n\x1a\n" else ".gif" if raw[:3] == b"GIF" else ext
    if ext not in EXTS:
        return raw
    stem = PurePosixPath((filename or "sticker").replace("\\", "/")).stem or "sticker"
    b = BytesIO()
    with zipfile.ZipFile(b, "w") as z:
        z.writestr(stem + ext, raw)
    return b.getvalue()


def _slug(pack: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "_", pack.lower()).strip("_")
    return (s[:8].strip("_") or "pack")


def _stem(path: str) -> str:
    return re.sub(r"[^a-z0-9_]+", "_", PurePosixPath(path).stem.lower()).strip("_")[:14]


def _pick_name(stem: str, slug: str, taken: set[str], counter: list[int]) -> str:
    if svc.NAME_OK.match(stem) and stem not in taken:
        return stem
    while True:
        counter[0] += 1
        n = f"{slug}_{counter[0]}"[:14]
        if svc.NAME_OK.match(n) and n not in taken:
            return n


def _read_limited(zf: zipfile.ZipFile, info: zipfile.ZipInfo) -> bytes:
    with zf.open(info) as f:
        data = f.read(emojimaker.MAX_RAW + 1)
    if len(data) > emojimaker.MAX_RAW:
        raise ChatError(f"Fayl {emojimaker.MAX_RAW // (1024 * 1024)} MB dan oshmasligi kerak")
    return data


def _convert(raw: bytes, ext: str) -> emojimaker.Made:
    if not ISOLATE:
        kind, val = emojimaker.convert_job(raw, ext)
    else:
        try:
            kind, val = _get_pool().submit(emojimaker.convert_job, raw, ext).result(timeout=JOB_TIMEOUT)
        except cf.TimeoutError:
            _drop_pool()
            raise ChatError("Fayl juda uzoq ishlandi (animatsiya juda murakkab)")
        except BrokenProcessPool:
            _drop_pool()
            raise ChatError("Fayl o'girilayotganda ishlov jarayoni to'xtadi (fayl yaroqsiz yoki juda og'ir)")
        except Exception:
            _drop_pool()
            raise ChatError("Faylni o'girib bo'lmadi")
    if kind == "err":
        raise ChatError(val)
    return val


def _convert_all(zf, items, skipped, ready, taken, slug, counter) -> None:
    for i in items:
        base = PurePosixPath(i.filename.replace("\\", "/")).name
        try:
            made = _convert(_read_limited(zf, i), PurePosixPath(base).suffix.lower())
        except ChatError as e:
            skipped.append({"file": base, "reason": e.message})
            continue
        except Exception:
            skipped.append({"file": base, "reason": "faylni o'qib bo'lmadi"})
            continue
        n = _pick_name(_stem(base), slug, taken, counter)
        taken.add(n)
        ready.append((n, made))


def import_zip(user, raw: bytes, pack_name: str, public: bool = True) -> dict:
    if not svc.perms_of(user)["manage"]:
        raise ChatError("Sticker to'plamini faqat adminlar yarata oladi", 403)
    name = svc._pack_name(pack_name)
    if repo.pack_by_name(name):
        raise ChatError("Bunday nomli to'plam bor")
    if len(repo.all_packs()) >= svc.MAX_PACKS:
        raise ChatError(f"To'plamlar soni chegarasi ({svc.MAX_PACKS} ta) to'ldi")
    if not raw or len(raw) > MAX_ZIP:
        raise ChatError(f"ZIP fayl {MAX_ZIP // (1024 * 1024)} MB dan oshmasligi kerak")
    try:
        zf = zipfile.ZipFile(BytesIO(raw))
        infos = zf.infolist()
    except Exception:
        raise ChatError("Bu ZIP fayl emas yoki buzilgan")

    skipped: list[dict] = []
    items: list[zipfile.ZipInfo] = []
    for i in infos:
        base = PurePosixPath(i.filename.replace("\\", "/"))
        if i.is_dir() or "__MACOSX" in base.parts or base.name.startswith("."):
            continue                                              # papka / macOS chiqindisi / yashirin fayl — jim o'tkaziladi
        if base.suffix.lower() == ".tgs":
            skipped.append({"file": base.name, "reason": "Telegram .tgs qo'llab-quvvatlanmaydi — uni .gif qilib oling"})
        elif base.suffix.lower() not in EXTS:
            skipped.append({"file": base.name, "reason": "qo'llab-quvvatlanmaydigan format (.gif yoki .png kerak)"})
        elif i.flag_bits & 0x1:
            skipped.append({"file": base.name, "reason": "parol bilan himoyalangan"})
        else:
            items.append(i)
    if not items:
        raise ChatError("ZIP ichida .gif yoki .png fayl topilmadi" + (" (Telegram .tgs qo'llab-quvvatlanmaydi, .gif qiling)" if skipped else ""))
    if len(items) > MAX_FILES:
        raise ChatError(f"ZIP ichida {len(items)} ta fayl bor, bitta to'plamga ko'pi bilan {MAX_FILES} ta")
    if sum(i.file_size for i in items) > MAX_UNPACKED:
        raise ChatError("ZIP ichidagi fayllar jami hajmi juda katta")
    room = svc.MAX_EMOJIS - len(repo.all_emojis())
    if len(items) > room:
        raise ChatError(f"Emojilar chegarasi ({svc.MAX_EMOJIS} ta): yana {max(room, 0)} ta emoji sig'adi, ZIP da {len(items)} ta bor")

    items.sort(key=lambda i: _natural(PurePosixPath(i.filename.replace("\\", "/")).name))
    taken, slug, counter = set(emojis.available()), _slug(name), [0]
    ready: list[tuple[str, emojimaker.Made]] = []
    with _import_lock:
        _convert_all(zf, items, skipped, ready, taken, slug, counter)
    if not ready:
        first = skipped[0]["reason"] if skipped else "fayllar yaroqsiz"
        raise ChatError(f"Hech bir fayl qo'shilmadi: {first}")

    pid = repo.add_pack(name, public, user["id"], time.time())
    written: list[str] = []
    added: list[str] = []
    try:
        for n, made in ready:
            file = f"{secrets.token_hex(10)}.{made.ext}"
            (settings.emoji_dir / file).write_bytes(made.data)
            written.append(file)
            repo.add(n, file, None, made.animated, pid, public, user["id"], time.time())
            added.append(n)
    except Exception:                                             # yarim holda qolmasin: to'plam va yozilgan fayllar qaytariladi
        for n in added:
            e = repo.get_by_name(n)
            if e:
                repo.remove(e["id"])
        repo.remove_pack(pid)
        for f in written:
            (settings.emoji_dir / f).unlink(missing_ok=True)
        emojis.reset_cache()
        raise ChatError("To'plamni saqlashda xato, qayta urinib ko'ring", 500)
    emojis.reset_cache()
    return {"pack_id": pid, "pack": name, "added": added, "skipped": skipped,
            "animated": sum(1 for _, m in ready if m.animated)}
