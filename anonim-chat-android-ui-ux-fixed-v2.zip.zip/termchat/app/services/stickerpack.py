"""Tayyor .zip dan sticker (emoji) to'plami yaratish — FAQAT adminlar.

ZIP ichida .tgs (Telegram animatsiyali), .png, .gif (va .webp, .jpg) fayllar bo'ladi. Har bir fayl alohida emoji bo'ladi,
hammasi bitta yangi to'plamga (pack) qo'shiladi; to'plam nomini admin kiritadi.

  * .tgs  -> animatsiyali WEBP (serverda `rlottie-python` bilan chiziladi)
  * .gif  -> animatsiyali WEBP, .png/.webp/.jpg -> qayta kodlangan PNG (metadata o'chadi)
Emoji nomi fayl nomidan olinadi (`kulgi.tgs` -> `:kulgi:`); nom yaroqsiz yoki band bo'lsa `<to'plam>_<tartib>` beriladi.
Xavfsizlik: fayllar diskka ochilmaydi (yo'l hujumi yo'q), har bir yozuv hajmi o'qishda cheklanadi (zip-bomba), parolli/yashirin/
begona fayllar o'tkazib yuboriladi va sababi qaytariladi. Biror fayl yaroqsiz bo'lsa, qolganlari baribir qo'shiladi.
"""
from __future__ import annotations

import re
import secrets
import time
import zipfile
from io import BytesIO
from pathlib import PurePosixPath

from app import emojis
from app.config import settings
from app.errors import ChatError
from app.repositories import emojis as repo
from app.services import emoji as svc, emojimaker

MAX_ZIP = 20 * 1024 * 1024               # yuklanadigan .zip hajmi
MAX_FILES = 100                          # bitta to'plamga ko'pi bilan
MAX_UNPACKED = 60 * 1024 * 1024          # hamma yaroqli fayllarning ochilgan jami hajmi
EXTS = (".tgs", ".png", ".gif", ".webp", ".jpg", ".jpeg")


def _natural(s: str):
    return [int(t) if t.isdigit() else t for t in re.split(r"(\d+)", s.lower())]


def _slug(pack: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "_", pack.lower()).strip("_")
    return (s[:8].strip("_") or "pack")


def _stem(path: str) -> str:
    return re.sub(r"[^a-z0-9_]+", "_", PurePosixPath(path).stem.lower()).strip("_")[:14]


def _pick_name(stem: str, slug: str, taken: set[str], counter: list[int]) -> str:
    if svc.NAME_OK.match(stem) and stem not in taken:
        return stem
    while True:
        counter[0] += 1
        n = f"{slug}_{counter[0]}"[:14]
        if svc.NAME_OK.match(n) and n not in taken:
            return n


def _read_limited(zf: zipfile.ZipFile, info: zipfile.ZipInfo) -> bytes:
    with zf.open(info) as f:
        data = f.read(emojimaker.MAX_RAW + 1)
    if len(data) > emojimaker.MAX_RAW:
        raise ChatError(f"Fayl {emojimaker.MAX_RAW // (1024 * 1024)} MB dan oshmasligi kerak")
    return data


def _convert(raw: bytes, ext: str) -> emojimaker.Made:
    if ext == ".tgs" or emojimaker.is_tgs(raw):
        return emojimaker.make_tgs(raw)
    return emojimaker.make(raw)


def import_zip(user, raw: bytes, pack_name: str, public: bool = True) -> dict:
    if not svc.perms_of(user)["manage"]:
        raise ChatError("Sticker to'plamini faqat adminlar yarata oladi", 403)
    name = svc._pack_name(pack_name)
    if repo.pack_by_name(name):
        raise ChatError("Bunday nomli to'plam bor")
    if len(repo.all_packs()) >= svc.MAX_PACKS:
        raise ChatError(f"To'plamlar soni chegarasi ({svc.MAX_PACKS} ta) to'ldi")
    if not raw or len(raw) > MAX_ZIP:
        raise ChatError(f"ZIP fayl {MAX_ZIP // (1024 * 1024)} MB dan oshmasligi kerak")
    try:
        zf = zipfile.ZipFile(BytesIO(raw))
        infos = zf.infolist()
    except Exception:
        raise ChatError("Bu ZIP fayl emas yoki buzilgan")

    skipped: list[dict] = []
    items: list[zipfile.ZipInfo] = []
    for i in infos:
        base = PurePosixPath(i.filename.replace("\\", "/"))
        if i.is_dir() or "__MACOSX" in base.parts or base.name.startswith("."):
            continue                                              # papka / macOS chiqindisi / yashirin fayl — jim o'tkaziladi
        if base.suffix.lower() not in EXTS:
            skipped.append({"file": base.name, "reason": "qo'llab-quvvatlanmaydigan format (.tgs, .png, .gif kerak)"})
        elif i.flag_bits & 0x1:
            skipped.append({"file": base.name, "reason": "parol bilan himoyalangan"})
        else:
            items.append(i)
    if not items:
        raise ChatError("ZIP ichida .tgs, .png yoki .gif fayl topilmadi")
    if len(items) > MAX_FILES:
        raise ChatError(f"ZIP ichida {len(items)} ta fayl bor, bitta to'plamga ko'pi bilan {MAX_FILES} ta")
    if sum(i.file_size for i in items) > MAX_UNPACKED:
        raise ChatError("ZIP ichidagi fayllar jami hajmi juda katta")
    room = svc.MAX_EMOJIS - len(repo.all_emojis())
    if len(items) > room:
        raise ChatError(f"Emojilar chegarasi ({svc.MAX_EMOJIS} ta): yana {max(room, 0)} ta emoji sig'adi, ZIP da {len(items)} ta bor")

    items.sort(key=lambda i: _natural(PurePosixPath(i.filename.replace("\\", "/")).name))
    taken, slug, counter = set(emojis.available()), _slug(name), [0]
    ready: list[tuple[str, emojimaker.Made]] = []
    for i in items:
        base = PurePosixPath(i.filename.replace("\\", "/")).name
        try:
            made = _convert(_read_limited(zf, i), PurePosixPath(base).suffix.lower())
        except ChatError as e:
            skipped.append({"file": base, "reason": e.message})
            continue
        except Exception:
            skipped.append({"file": base, "reason": "faylni o'qib bo'lmadi"})
            continue
        n = _pick_name(_stem(base), slug, taken, counter)
        taken.add(n)
        ready.append((n, made))
    if not ready:
        first = skipped[0]["reason"] if skipped else "fayllar yaroqsiz"
        raise ChatError(f"Hech bir fayl qo'shilmadi: {first}")

    pid = repo.add_pack(name, public, user["id"], time.time())
    written: list[str] = []
    added: list[str] = []
    try:
        for n, made in ready:
            file = f"{secrets.token_hex(10)}.{made.ext}"
            (settings.emoji_dir / file).write_bytes(made.data)
            written.append(file)
            repo.add(n, file, None, made.animated, pid, public, user["id"], time.time())
            added.append(n)
    except Exception:                                             # yarim holda qolmasin: to'plam va yozilgan fayllar qaytariladi
        for n in added:
            e = repo.get_by_name(n)
            if e:
                repo.remove(e["id"])
        repo.remove_pack(pid)
        for f in written:
            (settings.emoji_dir / f).unlink(missing_ok=True)
        emojis.reset_cache()
        raise ChatError("To'plamni saqlashda xato, qayta urinib ko'ring", 500)
    emojis.reset_cache()
    return {"pack_id": pid, "pack": name, "added": added, "skipped": skipped,
            "animated": sum(1 for _, m in ready if m.animated)}
