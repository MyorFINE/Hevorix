"""Maxsus emojilar: katalog, yaratish (rasm yuklab), to'plamlar, ruxsatlar."""
import base64

from fastapi import APIRouter, Depends, File, Form, Request, UploadFile
from fastapi.concurrency import run_in_threadpool
from pydantic import BaseModel, Field

from app.api.deps import admin_user, client_ip, current_user
from app.realtime.manager import manager
from app.services import activity, emoji as svc, emojimaker, stickerpack

router = APIRouter(prefix="/api", tags=["emoji"])


async def _changed() -> None:
    await manager.broadcast({"type": "emoji_update"})          # hamma mijoz katalogni qayta yuklaydi


@router.get("/emojis")
def catalog(user=Depends(current_user)):
    return svc.catalog(user)


async def _raw(file: UploadFile) -> bytes:
    return await file.read(emojimaker.MAX_RAW + 1)


@router.post("/emoji/preview")
async def preview(file: UploadFile = File(...), remove_bg: bool = Form(False), tolerance: int = Form(emojimaker.TOL_DEFAULT),
                  user=Depends(current_user)):
    """Saqlamasdan natijani ko'rsatadi (orqa fon olib tashlangan holda) — sezgirlikni sozlash uchun."""
    raw = await _raw(file)
    made = await run_in_threadpool(svc.preview, user, raw, remove_bg, tolerance)
    mime = "image/webp" if made.ext == "webp" else "image/png"
    return {"image": f"data:{mime};base64," + base64.b64encode(made.data).decode(), "w": made.width, "h": made.height,
            "transparent": made.transparent, "bg_removed": made.bg_removed, "source_alpha": made.source_alpha, "animated": made.animated}


@router.post("/emoji")
async def create(request: Request, file: UploadFile = File(...), name: str = Form(...), anim: str = Form(""),
                 remove_bg: bool = Form(False), tolerance: int = Form(emojimaker.TOL_DEFAULT),
                 pack_id: str = Form(""), public: bool = Form(True), user=Depends(current_user)):
    raw = await _raw(file)
    r = await run_in_threadpool(lambda: svc.create(user, raw, name, anim=anim, remove_bg=remove_bg, tolerance=tolerance,
                                                    pack_id=pack_id, public=public))
    activity.record("emoji", ip=client_ip(request), user=user, detail=f"yaratdi :{r['name']}:")
    await _changed()
    return {"ok": True, **r}


class EmojiEdit(BaseModel):
    anim: str = Field("", max_length=16)
    pack_id: int | None = None
    public: bool = True


@router.patch("/emoji/{eid}")
async def edit(eid: int, data: EmojiEdit, request: Request, user=Depends(current_user)):
    svc.edit(user, eid, anim=data.anim, pack_id=data.pack_id, public=data.public)
    activity.record("emoji", ip=client_ip(request), user=user, detail=f"tahrirladi #{eid}")
    await _changed()
    return {"ok": True}


@router.delete("/emoji/{eid}")
async def delete(eid: int, request: Request, user=Depends(current_user)):
    e = svc.delete(user, eid)
    activity.record("emoji", ip=client_ip(request), user=user, detail=f"o'chirdi :{e['name']}:")
    await _changed()
    return {"ok": True}


@router.post("/emoji-packs/import")
async def pack_import(request: Request, file: UploadFile = File(...), name: str = Form(...), public: bool = Form(True),
                      user=Depends(current_user)):
    """Admin: tayyor .zip (.gif / .png) dan yangi sticker to'plami yaratadi."""
    raw = await file.read(stickerpack.MAX_ZIP + 1)
    raw = stickerpack.wrap_single(raw, file.filename or "") if len(raw) <= stickerpack.MAX_ZIP else raw      # yakka .gif/.png ham qabul
    r = await run_in_threadpool(lambda: stickerpack.import_zip(user, raw, name, public))
    activity.record("emoji", ip=client_ip(request), user=user, detail=f"ZIP to'plam «{r['pack']}»: {len(r['added'])} ta emoji")
    await _changed()
    return {"ok": True, **r}


class PackIn(BaseModel):
    name: str = Field(max_length=40)
    public: bool = True


@router.post("/emoji-packs")
async def pack_create(data: PackIn, request: Request, user=Depends(current_user)):
    pid = svc.create_pack(user, data.name, data.public)
    activity.record("emoji", ip=client_ip(request), user=user, detail=f"to'plam yaratdi «{data.name}»")
    await _changed()
    return {"ok": True, "id": pid}


@router.patch("/emoji-packs/{pid}")
async def pack_edit(pid: int, data: PackIn, request: Request, user=Depends(current_user)):
    svc.edit_pack(user, pid, data.name, data.public)
    activity.record("emoji", ip=client_ip(request), user=user, detail=f"to'plamni tahrirladi #{pid}")
    await _changed()
    return {"ok": True}


@router.delete("/emoji-packs/{pid}")
async def pack_delete(pid: int, request: Request, user=Depends(current_user)):
    svc.delete_pack(user, pid)
    activity.record("emoji", ip=client_ip(request), user=user, detail=f"to'plamni o'chirdi #{pid}")
    await _changed()
    return {"ok": True}


class ModeIn(BaseModel):
    mode: str = Field(max_length=8)


@router.put("/emoji-settings")
async def set_mode(data: ModeIn, request: Request, admin=Depends(admin_user)):
    mode = svc.set_global_mode(admin, data.mode)
    activity.record("emoji", ip=client_ip(request), user=admin, detail=f"oddiy foydalanuvchilar emojisi: {mode}")
    await _changed()
    return {"ok": True, "mode": mode}


class PermIn(BaseModel):
    perm: int


@router.put("/emoji-perm/{uid}")
async def set_perm(uid: int, data: PermIn, request: Request, admin=Depends(admin_user)):
    t = svc.set_user_perm(admin, uid, data.perm)
    activity.record("emoji", ip=client_ip(request), user=admin, detail=f"@{t['username']} emoji ruxsati: {data.perm}")
    await _changed()
    return {"ok": True}
