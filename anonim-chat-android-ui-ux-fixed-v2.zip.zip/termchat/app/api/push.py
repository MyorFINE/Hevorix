"""Web Push endpointlari: ochiq kalit, obuna bo'lish/bekor qilish (barchasi shifrlangan kanal ichida)."""
from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field

from app.api.deps import current_user
from app.config import settings
from app.repositories import push as push_repo
from app.services import webpush

router = APIRouter(prefix="/api/push", tags=["push"])


class SubscribeIn(BaseModel):
    endpoint: str = Field(max_length=1024)
    p256dh: str = Field(max_length=200)
    auth: str = Field(max_length=64)


class UnsubscribeIn(BaseModel):
    endpoint: str = Field(max_length=1024)


@router.get("/key")
def key(user=Depends(current_user)):
    return {"key": webpush.public_key()}


@router.post("/subscribe")
def subscribe(data: SubscribeIn, user=Depends(current_user)):
    webpush.validate_endpoint(data.endpoint)
    webpush.validate_keys(data.p256dh, data.auth)
    push_repo.upsert(user["id"], data.endpoint, data.p256dh, data.auth, settings.push_max_devices)
    return {"ok": True}


@router.post("/unsubscribe")
def unsubscribe(data: UnsubscribeIn, user=Depends(current_user)):
    push_repo.remove(data.endpoint, user["id"])
    return {"ok": True}


@router.post("/check")
def check(data: UnsubscribeIn, user=Depends(current_user)):
    """Qurilma serverda obunami? (mijoz holatni to'g'ri ko'rsatishi uchun)"""
    return {"subscribed": push_repo.has(user["id"], data.endpoint)}
