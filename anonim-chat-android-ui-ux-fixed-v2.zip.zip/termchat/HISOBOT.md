# TermChat v3.3.0 — xavfsizlik va barqarorlik hisoboti

Asos: `anonim-chat-android-ui-ux-fixed-v2.zip`. Papka tuzilishi saqlangan. Render/hosting fayllariga (`render.yaml`, `Dockerfile`, `deploy/`) tegilmagan; yangi kutubxona qo'shilmagan (faqat standart kutubxona + mavjud `cryptography`, `Pillow`).

## 0. MUHIM: nima tekshirilmagan

Bu muhitda internet yo'q, **FastAPI, uvicorn, httpx, pytest o'rnatilmagan**. Shuning uchun mavjud backend test to'plami (`tests/test_core.py`, `test_api.py`, `test_secure.py`, `test_e2ee.py`, `test_realtime.py`, `test_channels.py`, `test_reactions.py`, `test_emoji*.py`, `test_webpush.py`, `test_backup.py`) **ISHGA TUSHIRILMAGAN** — ham o'zgartirishdan oldin, ham keyin.
`app/api/ws.py`, `app/api/auth.py`, `app/transport.py`, `app/main.py` o'zgarishlari: sintaksis + stub bilan import tekshirildi, mantiq esa FastAPI'siz unit-testlar bilan sinaldi; **to'liq HTTP/WebSocket oqimi sinalmagan**. Joylashtirishdan oldin: `pip install -r requirements-dev.txt && pytest`.

## 1. O'zgartirilgan va yangi fayllar

**Yangi:** `app/datasnap.py`, `app/services/maintenance.py`, `tools/datasnap.py`, `tests/test_hardening.py`, `HISOBOT.md`
**O'zgargan:** `app/__init__.py` (3.3.0), `app/security.py`, `app/services/auth.py`, `app/api/auth.py`, `app/api/ws.py`, `app/transport.py`, `app/realtime/manager.py`, `app/services/imgclean.py`, `app/services/media.py`, `app/services/backup.py`, `app/services/moderation.py`, `app/services/avatars.py`, `app/api/e2ee.py`, `app/commands/base.py`, `app/commands/moderation.py`, `app/db.py`, `app/config.py`, `app/main.py`, `run.py`, `app/repositories/sessions.py`, `.env.example`, `README.md`
**Frontend (JS/CSS/HTML): o'zgartirilmagan** (sabab: 5-bo'limda).

## 2. Muhim o'zgarishlar (fayl · muammo · o'zgarish · sabab · test · natija)

| # | Fayl | Muammo | O'zgarish / sabab | Test → natija |
|---|------|--------|-------------------|---------------|
| 1 | `security.py`, `services/auth.py` | scrypt N=2¹⁴ (zaif); hash formati o'zgarmas | N=2¹⁵, parametrlar hash ichida (`s2$…`); eski hash tekshiriladi va kirishda avtomatik yangilanadi (moslik saqlandi). Buzuq/zararli parametrlar rad etiladi | `PasswordHashTests` (5 ta) + haqiqiy sxemada login→rehash tekshirildi → **OK** |
| 2 | `services/backup.py` | (1-o'zgarish keltirib chiqaradigan regressiya): zaxirani tiklash yangi hash shaklini «yaroqsiz» deb rad etardi | `valid_hash_shape()` eski va yangi shaklni qabul qiladi | `test_backup_restore_accepts_both_hash_formats` + export→o'chirish→restore→login → **OK** |
| 3 | `services/auth.py` | Mavjud bo'lmagan username'da scrypt hisoblanmasdi (vaqt farqi) | `burn_verify()`; ~110 ms ikkala holatda | qo'lda o'lchandi (113/104 ms) → **OK** |
| 4 | `api/auth.py` | Faqat (IP, username) cheklovi bor edi: bitta IP'dan turli username sinash cheklanmagan | qo'shimcha `login-ip` cheklovi (IP uchun 80/5 daqiqa) | kod ko'rib chiqildi; HTTP darajasida **sinalmagan** |
| 5 | `transport.py` | Server→mijoz AES-GCM nonce tasodifiy (takrorlanmasligi kafolatsiz); WS prefiksi 4 bayt tasodifiy | nonce = oqim raqami + hisoblagich; HTTP = oqim 0, har WS o'z oqimi. Mijoz kodi o'zgarmadi (u faqat hisoblagichni tekshiradi) | `TransportNonceTests` (5 ta) → **OK** |
| 6 | `transport.py`, `run.py` | WS kadr hajmi cheklanmagan (uvicorn standarti 16 MB) | `max_ws_frame()` (kadr dekodlanmasdan rad), `ws_max_size=1 MB` (`run.py`) | `test_oversized_websocket_frame…`, replay/tamper testi → **OK** |
| 7 | `transport.py` | Katta shifrlangan tanalar to'liq RAMga o'qiladi; bir vaqtda ko'pi → xotira tugashi | umumiy hajm byudjeti va ≤3 bir vaqtdagi yuklab olish; ortig'i 503 | kod ko'rib chiqildi; yuklama ostida **sinalmagan** |
| 8 | `api/ws.py`, `realtime/manager.py` | Kutilmagan xato (masalan baza) ulanishni uzardi; `cmd`/kadrlar tezligi cheklanmagan; ulanishlar soni cheksiz | xato ushlanadi («Server xatosi»); kadr 150/10 s, `cmd` 20/10 s; ≤10 ulanish (1013); oversize → 1009 | stub bilan import tekshirildi; **ishga tushirib sinalmagan** |
| 9 | 6 ta fayl (`moderation`, `avatars`, `e2ee` API, `commands/*`) | `'²'.isdigit()` True, `int('²')` xato → WS uziladi / 500 | faqat ASCII raqam | `DigitParsingTests` → **OK** |
| 10 | `services/imgclean.py` | Ko'p kadrli katta GIF (300×40 Mpx) xotirani to'ldirishi mumkin; katta JPEG to'liq dekodlanadi | kadrlar piksellari yig'indisi ≤30 M; JPEG `draft()` | `ImageLimitsTests` (GIF rad etiladi, EXIF olib tashlanadi, oddiy GIF/JPEG ishlaydi) → **OK** |
| 11 | `services/maintenance.py` (yangi), `main.py`, `media.py` | Chala `*.tmp`, biriktirilmagan `.e2e` fayllar va yetim `e2e_blobs` qatorlari yig'ilib qolardi | startup + har 30 daqiqada tozalash; xabarlarga tegilmaydi | `test_sweep_tmp…` → **OK** (lifespan ulanishi sinalmagan) |
| 12 | `app/datasnap.py`, `tools/datasnap.py` (yangi) | Faqat akkauntlar zaxirasi bor edi; xabarlar/kanallar/reaksiyalar/media zaxirasi yo'q | to'liq zaxira (baza + shifrlangan fayllar), SHA-256 manifest, tekshirish, xavfsiz tiklash (mavjud ma'lumotni jimgina o'chirmaydi, `--force` da eski nusxa saqlanadi), maxfiy kalitlar kirmaydi | `SnapshotTests` (7 ta) + CLI smoke (backup/verify/restore/rad etish/force) → **OK** |
| 13 | `maintenance.auto_backup`, `config.py` | Avtomatik zaxira yo'q | `TERMCHAT_AUTO_BACKUP_HOURS` (standart 0 = o'chiq), aylanma, yozilgach tekshiriladi | `AutoBackupTests` → **OK** |
| 14 | `repositories/sessions.py`, `services/auth.py`, `api/auth.py` | Qurilmalar sessiyalarini ko'rish/bekor qilish yo'q | `GET /api/sessions`, `DELETE /api/sessions/{id}`, `POST /api/sessions/revoke-others` (faqat o'zinikini; token ko'rsatilmaydi) | `SessionManagementTests` (4 ta: egalik, revoke-others, logout, idle tugash) → **OK** (servis darajasida) |
| 15 | `db.py` | `synchronous` va `busy_timeout` aniq emas; zaxira/butunlik API yo'q | `synchronous=NORMAL` (WAL), `busy_timeout`, `snapshot()`, `integrity_check()` | haqiqiy sxemada `integrity_check()==[]`, snapshot → **OK** |

## 3. Muvaffaqiyatli testlar (men ishga tushirganlarim)

- Python `compileall` (app, tests, tools, run.py): **OK**
- JavaScript `node --check` (barcha `static/js/*.js`, `sw.js`): **OK**
- Node testlar (avvalgi holat bilan bir xil, o'zgarishdan keyin ham): `backup_interop`, `e2e_glue_test`, `reactions_sync`, `reactions_tap`, `richtext_dom`, `richtext`, `vnote_pack`, `voice_dsp` — **hammasi OK**. (`e2e_js_interop.mjs` chiqish bermaydi, chiqish kodi 0 — o'zgarishdan oldin ham shunday edi.)
- Yangi `tests/test_hardening.py`: **27 ta test, hammasi OK** (har biri o'z vaqtinchalik papkasida).

## 4. Muvaffaqiyatsiz / o'tkazilmagan testlar

- **O'tkazilmagan** (kutubxona yo'q): mavjud pytest to'plami (yuqoridagi 0-bo'lim). Muvaffaqiyatsiz deb topilgani yo'q — shunchaki ishga tushmagan.
- Statik xavfsizlik vositalari (bandit va h.k.) mavjud emas; qo'lda ko'rib chiqildi (SQL so'rovlarida faqat parametrlar; frontendda `innerHTML`/`eval` yo'q — avvaldan shunday).
- `e2e_js_interop.mjs` Python drayveri bilan ishlaydi — ishga tushirilmadi.

## 5. Qasddan qilinmagan ishlar (sabab bilan)

- **Frontend o'zgartirilmadi.** Brauzer/qurilma yo'q, shuning uchun UI o'zgarishlarini ko'rib tekshira olmayman; tekshirilmagan UI o'zgartirishi ishlayotgan interfeysni buzishi mumkin. Audit: `innerHTML`/`eval` yo'q, qat'iy CSP, offline paneli (`connbar`), 38 ta `aria-`/`role`, klaviatura boshqaruvi — mavjud. `app.js` (4067 qator) modullarga **bo'linmadi** — sinab bo'lmaydigan katta qayta yozish xavfi.
- **Virtual scrolling qo'shilmadi** (xavfsiz sinab bo'lmasdi); tarix sahifalab yuklanadi (10 + 30).
- **Kriptografik protokol (E2EE) formati o'zgartirilmadi** — eski xabarlar ochilishi buzilmasligi uchun. Faqat server→mijoz nonce tuzilmasi o'zgardi (mijoz moslashtirishi shart emas).
- Hujjat: E2EE protokoli README'da mavjud; yangi o'zgarishlar README «v3.3.0» bo'limida.

## 6. Hali qolgan kamchiliklar

1. **Test izolyatsiyasi:** mavjud `conftest.py` butun sessiya uchun BITTA umumiy bazadan foydalanadi (sozlamalar import vaqtida o'qiladi). Har bir test uchun alohida baza qilish arxitekturani o'zgartirishni talab qiladi — qilinmadi. Yangi testlar izolyatsiyalangan.
2. **`TRUST_PROXY` standarti `True`:** Cloudflare ortida bo'lmagan serverda mijoz `CF-Connecting-IP`ni soxtalashtirib, tezlik cheklovi va IP bloklashdan qochishi mumkin. Render uchun to'g'ri bo'lgani sababli standart o'zgarmadi; `.env.example`da ogohlantirish qo'shildi.
3. **Egasining boshlang'ich paroli** birinchi ishga tushirishda logga yoziladi (`bootstrap.py`). Yangi o'rnatishda egasi kirishi uchun kerak; `TERMCHAT_ADMIN_PASSWORD` bering va logni oching.
4. **Server→mijoz tomonida nonce kafolatlangan, mijoz→server tomonida** esa mijoz tasodifiy 4 baytli prefiks ishlatadi (ikki ulanish prefiksi to'qnashuvi ehtimoli ~2⁻³², va hisoblagichlar ham mos kelishi kerak). Takroriy kadrlar serverda rad etiladi. To'liq kafolat uchun mijoz kodini o'zgartirish kerak (qilinmadi).
5. **Tunnel katta fayllarni RAMga o'qiydi** (AES-GCM yaxlit teg tufayli). Byudjet bilan cheklandi, lekin to'liq oqimli (chunked) shifrlash uchun protokolni o'zgartirish kerak.
6. **Adminlar o'z amallari logini o'chira oladi** (`/api/admin/activity/delete`; faqat ega yozuvlari himoyalangan). Yozilmas (append-only) audit qilinmadi.
7. **Sessiyalar UI:** qurilmalarni ko'rish/bekor qilish faqat API; interfeysda tugma yo'q.
8. **To'liq zaxira interfeysda yo'q** (CLI + avtomatik nusxa). Brauzerdan yuklab olish qasddan qo'shilmadi: arxivda parol hash'lari bor va u shifrlanmagan.
9. **E2EE mustaqil auditdan o'tmagan** — uni mutlaq xavfsiz deb hisoblamang. Server kim kimga, qachon, qancha yozganini ko'radi (metama'lumot), reaksiyalar ochiq.
10. Bepul tarifdagi vaqtinchalik diskda `data/` har qayta ishga tushirishda yo'qolishi mumkin — zaxirani tashqariga ko'chirib turing.

## 7. Qo'lda bajarilishi kerak bo'lgan ishlar

1. `pip install -r requirements-dev.txt && pytest` — mavjud backend testlarini ishga tushiring va natijani tekshiring.
2. `python -m unittest tests.test_hardening -v` va `node tests/*.mjs`.
3. Joylashtirishdan oldin `data/` va `master.key`ni zaxiralang (`python tools/datasnap.py backup`); `master.key`ni arxivdan **alohida** saqlang.
4. Cloudflare/Render ortida bo'lmasangiz: `TERMCHAT_TRUST_PROXY=0`.
5. Ixtiyoriy: `TERMCHAT_AUTO_BACKUP_HOURS=24`.
6. Brauzerda qo'lda sinang: login, xabar, rasm/fayl/ovoz yuborish, qayta ulanish — frontend o'zgarmagan, lekin server→mijoz nonce tuzilmasi o'zgargani uchun WebSocket va fayl yuklab olishni jonli tekshirish zarur.

---
## v3.3.1 — profil ochilishidagi qotish (FPS) tuzatildi

**Sabablar (kodda topilgan):**
1. Profil oynasi «jonli» (`live`) edi: har bir `presence`/a'zolar yangilanishida butunlay QAYTA QURILARDI — ochilish animatsiyasi paytida DOM almashib, avatar rasmi qayta yuklanib/dekodlanardi.
2. Profil rasmlari 2560 px gacha saqlanardi, ekranda esa 96 px ko'rinadi: katta JPEG'ni dekodlash asosiy oqimni to'xtatardi (ayniqsa kuchsiz telefonda).
3. Oyna animatsiyasi GPU qatlamiga ko'tarilmagan edi.

**O'zgarishlar:** `static/js/app.js` (`refreshModal` birlashtiriladi va animatsiya tugaguncha ~450 ms kutadi; avatar `decoding="async"`), `static/css/style.css` (`will-change`, kuchsiz qurilmada qisqa animatsiya), `services/imgclean.py` + `services/avatars.py` (yangi profil rasmlari ≤512 px), `services/maintenance.py` (eski katta profil rasmlari joyida 512 px ga kichraytiriladi, har 30 daqiqada ≤20 ta; fayl nomi o'zgarmaydi).
**Test:** `test_big_avatar_is_shrunk_in_place…` (28 ta unittest OK), `node --check app.js` OK, barcha Node testlar OK.
**Sinalmagan:** haqiqiy telefonda FPS o'lchanmagan (qurilma yo'q). Taxmin kodga asoslangan; yaxshilanish bo'lmasa, Chrome DevTools → Performance bilan profil ochilishini yozib yuboring.

---
## v3.4.0 — Telegram uslubidagi profil ko'rinishi

**Talab:** skrinshotdagidek profil; Call, More, QR, Add contact, Block user bo'lmasin; Message va Mute bo'lsin; username ko'rinsin; rasmlar / ovozli xabarlar / fayllar qolsin.
**Fayllar:** `static/js/app.js` (`profileView`, `openProfile`, yangi `mediaStats`, mute holati), `static/css/style.css` (`.tgp`, `.tg-*`), `static/index.html` (`i-bell-off` belgisi), yangi `tests/profile_view_test.mjs`.

- **Tuzilma:** yuqorida orqaga (←) tugmasi, katta avatar, ism, holat (onlayn/oflayn), nishon chiplari; ostida ikkita tugma — **Xabar** va **Mute**; qalin ajratgich; **@username** qatori (bosilsa nusxalanadi); bio va qo'shilgan sana (bor bo'lsa); ajratgich; **N ta rasm / ovozli xabar / fayl** qatorlari (nol bo'lgani ko'rsatilmaydi; video xabar bo'lsa alohida qator). Mobilda butun ekran (≤760 px), kompyuterda oyna. O'z profilimda faqat «Tahrirlash». Adminlar uchun moderatsiya paneli pastda saqlandi; ega/admin rangi tepada yengil fon sifatida qoldi.
- **Mute:** shu suhbatdan kelgan xabarlarda tovush va mahalliy bildirishnoma o'chadi (tugma «Ovoz yoq» ga aylanadi). Holat faqat shu qurilmada (`localStorage: ac_muted_dm`) saqlanadi.
- **Cheklovlar (halol):** (1) Mute **serverdan keladigan push-bildirishnomalarga ta'sir qilmaydi** (push E2EE tufayli yuboruvchisiz va umumiy) — buning uchun serverda alohida sozlama kerak, qilinmadi. (2) Media sanog'i faqat **qurilmaga yuklangan** xabarlardan hisoblanadi (E2EE: server shifrlangan xabarni o'qiy olmaydi); tarixning davomi bo'lsa «3+ ta rasm» ko'rinadi. (3) Qatorlar bosilganda galereya ochilmaydi (galereya yo'q). (4) «Last seen» yo'q: tizimda oxirgi ko'rilgan vaqt saqlanmaydi, shuning uchun faqat onlayn/oflayn ko'rsatiladi.
- **Test:** `node tests/profile_view_test.mjs` — Call/More/Block/QR yo'qligi, 2 ta tugma, username va nusxalash, media sanog'i (o'chirilgan xabar hisoblanmaydi, «+»), Mute yoqish/o'chirish va saqlash, o'z profilim, orqaga tugmasi: **OK**. Brauzer/telefonda ko'rinishi **ko'zdan kechirilmagan** (qurilma yo'q) — iltimos, o'zingiz tekshiring.
