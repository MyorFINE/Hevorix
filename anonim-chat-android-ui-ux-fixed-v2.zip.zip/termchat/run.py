"""Ishga tushirish: python run.py"""
import uvicorn

from app.config import settings

if __name__ == "__main__":
    uvicorn.run("app.main:app", host=settings.host, port=settings.port, proxy_headers=True, forwarded_allow_ips="*",
                ws_max_size=1024 * 1024)       # WebSocket kadri 1 MB dan oshmasin (standart 16 MB)
